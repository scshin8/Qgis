from qgis.PyQt import uic, QtWidgets

from PyQt5.QtCore import (QSettings,
                          Qt)

from PyQt5.QtGui import QIcon

from PyQt5.QtWidgets import (QLabel,
                             QToolButton)

import os.path

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'Add_Values_dialog_val.ui'))

class AddValuesdialogval(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(AddValuesdialogval, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.CTool=CTool
        self.Settings=QSettings()

        icon_path = QIcon(os.path.dirname(__file__) + "/icons/setting.png")
        self.toolButton_setting.setIcon(icon_path)
        self.toolButton_setting.clicked.connect(self.CTool.setpopup)

        # 20개의 입력 버튼 및 아이콘 설정 (반복문 통합)
        for i in range(20):
            btn_name = f'toolButton_{i}'
            label_name = f'label_{i}'
            btn = self.findChild(QToolButton, btn_name)
            
            if btn:
                # 아이콘 설정
                icon_path = os.path.join(os.path.dirname(__file__), f"icons/icon{i+1}.png")
                btn.setIcon(QIcon(icon_path))
                # 클릭 이벤트 연결 (i=i를 통해 클로저 문제 방지)
                btn.clicked.connect(lambda checked=False, idx=i: self.CTool.run(idx, 1))

        # 데이터 초기화 로직 실행
        self.init_data_display()

        # 커넥트 설정
        self.comboBox.currentIndexChanged.connect(self.layercomboBox)
        self.checkBox_msg.stateChanged.connect(self.checkBoxmsg)
        self.checkBox_save.stateChanged.connect(self.checkBoxsave)

    def init_data_display(self):
        """초기 데이터 로드 및 UI 업데이트"""
        self.layer_comboBox = self.Settings.value('addvalues/layer_comboBox_list', ['Default'])
        self.comboBox.clear()
        self.comboBox.addItems(self.layer_comboBox)
        
        layer_index = int(self.Settings.value('addvalues/layer_comboBox', 0))
        self.comboBox.setCurrentIndex(layer_index)
        
        # 체크박스 상태 복구
        self.checkBox_msg.setCheckState(int(self.Settings.value('addvalues/checkBox_msg', Qt.Checked)))
        self.checkBox_save.setCheckState(int(self.Settings.value('addvalues/checkBox_save', Qt.Checked)))
        
        self.update_labels(layer_index)

    def update_labels(self, layer_index):
        """레이어 인덱스에 따른 레이블 텍스트 및 툴팁 업데이트"""
        suffix = '' if layer_index == 0 else str(layer_index)
        for i in range(20):
            col = self.Settings.value(f'addvalues/Tab{i+1}_lineEdit_cols{suffix}', '')
            val = self.Settings.value(f'addvalues/Tab{i+1}_lineEdit_vals{suffix}', '')
            view = self.Settings.value(f'addvalues/Tab{i+1}_lineEdit_views{suffix}', '')
            
            label = self.findChild(QLabel, f'label_{i}')
            if label:
                label.setToolTip(str(col))
                if not val:
                    label.setText(str(view) if view else ('NULL' if col else ''))
                else:
                    label.setText(f"{view} [{val}]" if view else str(val))

    def checkBoxmsg(self):
        self.Settings.setValue('addvalues/checkBox_msg', self.checkBox_msg.checkState())
        self.CTool.dlg.checkBox_msg.setCheckState(self.checkBox_msg.checkState())

    def checkBoxsave(self):
        self.Settings.setValue('addvalues/checkBox_save', self.checkBox_save.checkState())
        self.CTool.dlg.checkBox_save.setCheckState(self.checkBox_save.checkState())

    def layercomboBox(self):
        idx = self.comboBox.currentIndex()
        self.Settings.setValue('addvalues/layer_comboBox', idx)
        self.Settings.setValue('addvalues/layer_Text', self.comboBox.currentText())
        
        # 메인 툴바와 설정창 동기화
        self.CTool.layer_combo.setCurrentIndex(idx)
        self.CTool.layercha(idx)