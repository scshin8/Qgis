from qgis.PyQt import uic, QtWidgets

from PyQt5.QtCore import (QSettings,
                          Qt)

from PyQt5.QtGui import QIcon

from PyQt5.QtWidgets import (QLabel,
                             QToolButton)

import os.path

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'Add_Values_dialog_val.ui'))

class AddValuesdialogval(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(AddValuesdialogval, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool

        self.Settings=QSettings()

        icon_path = QIcon(os.path.dirname(__file__) + "/icons/setting.png")
        self.toolButton_setting.setIcon(icon_path)
        self.toolButton_setting.clicked.connect(self.CTool.setpopup)

    # 패널 아이콘 설정
        for i in range(20):
            ToolButton='toolButton_'+str(i)
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon"+ str(i+1) +".png")
            self.findChild(QToolButton,ToolButton).setIcon(icon_path)
            # ToolButton='toolButtonEdit_'+str(i)
            # icon_path = QIcon(os.path.dirname(__file__) + "/icons/edit.png")
            # self.findChild(QToolButton,ToolButton).setIcon(icon_path)

    # 레이어값 가져오기
        self.layer_comboBox = self.Settings.value('addvalues/layer_comboBox_list', 0)
    # 레이어값이 없다면 기본레이어로 설정함
        if not isinstance( self.layer_comboBox, list):
            self.layer_comboBox = []
            self.layer_comboBox.append('Default')

    # 레이어 콤보박스 재설정
        self.comboBox.clear()
        self.comboBox.addItems(self.layer_comboBox)
        layer_Index = int(self.Settings.value('addvalues/layer_comboBox',0))
        self.layer_Text = self.Settings.value('addvalues/layer_Text', '')
        self.comboBox.setCurrentIndex(layer_Index)

    # 레이어에 맞춰 입력값 가져오기
        for t in range(0,20):
            Tab_LineEdit_cols='Tab'+str(t+1)+'_lineEdit_cols' + str( '' if layer_Index == 0 else layer_Index)
            Tab_LineEdit_vals='Tab'+str(t+1)+'_lineEdit_vals' + str( '' if layer_Index==0 else layer_Index)
            Tab_LineEdit_views='Tab'+str(t+1)+'_lineEdit_views' + str( '' if layer_Index==0 else layer_Index)
            col = str(self.Settings.value('addvalues/' + Tab_LineEdit_cols,''))
            val = str(self.Settings.value('addvalues/' + Tab_LineEdit_vals,''))
            view = str(self.Settings.value('addvalues/' + Tab_LineEdit_views,''))
            labelvalue='label_'+str(t)
            self.findChild(QLabel,labelvalue).setToolTip(col)

        # 패널표시 설정
            if val == '': # 값이 없다면 빈값으로 저장
                if col =='':
                    self.findChild(QLabel,labelvalue).setText('')
                else:
                    if view == '':
                        self.findChild(QLabel,labelvalue).setText('NULL')
                    else:
                        self.findChild(QLabel,labelvalue).setText(str(view))

            else: # 값이 있다면
                if view == '': # 설명 값이 없다면 - 값
                    self.findChild(QLabel,labelvalue).setText(str(val))
                else: # 설명 값이 있다면 - 설명 [ 값 ]
                    self.findChild(QLabel,labelvalue).setText(str(view + ' [' + val + ']'))

    # 입력 레이어 수정 커넥트
        self.comboBox.currentIndexChanged.connect(self.layercomboBox)

    # 확인창 표시 체크박스 커넥트
        self.checkBox_msg.stateChanged.connect(self.checkBoxmsg)
        # 체크값 설정
        self.checkBox_msg.setCheckState(int(self.Settings.value('addvalues/checkBox_msg', Qt.Checked))) #Qt.Unchecked

    # 자동저장 체크박스 커넥트
        self.checkBox_save.stateChanged.connect(self.checkBoxsave)
        # 체크값 설정
        self.checkBox_save.setCheckState(int(self.Settings.value('addvalues/checkBox_save', Qt.Checked))) #Qt.Unchecked

    # 값 입력 커넥트
        self.toolButton_0.clicked.connect(lambda : self.CTool.run(0))
        self.toolButton_1.clicked.connect(lambda : self.CTool.run(1))
        self.toolButton_2.clicked.connect(lambda : self.CTool.run(2))
        self.toolButton_3.clicked.connect(lambda : self.CTool.run(3))
        self.toolButton_4.clicked.connect(lambda : self.CTool.run(4))
        self.toolButton_5.clicked.connect(lambda : self.CTool.run(5))
        self.toolButton_6.clicked.connect(lambda : self.CTool.run(6))
        self.toolButton_7.clicked.connect(lambda : self.CTool.run(7))
        self.toolButton_8.clicked.connect(lambda : self.CTool.run(8))
        self.toolButton_9.clicked.connect(lambda : self.CTool.run(9))
        self.toolButton_10.clicked.connect(lambda : self.CTool.run(10))
        self.toolButton_11.clicked.connect(lambda : self.CTool.run(11))
        self.toolButton_12.clicked.connect(lambda : self.CTool.run(12))
        self.toolButton_13.clicked.connect(lambda : self.CTool.run(13))
        self.toolButton_14.clicked.connect(lambda : self.CTool.run(14))
        self.toolButton_15.clicked.connect(lambda : self.CTool.run(15))
        self.toolButton_16.clicked.connect(lambda : self.CTool.run(16))
        self.toolButton_17.clicked.connect(lambda : self.CTool.run(17))
        self.toolButton_18.clicked.connect(lambda : self.CTool.run(18))
        self.toolButton_19.clicked.connect(lambda : self.CTool.run(19))

    # 값 수정 커넥트
        # self.toolButtonEdit_0.clicked.connect(lambda : self.CTool.changevalueEdit(0))
        # self.toolButtonEdit_1.clicked.connect(lambda : self.CTool.changevalueEdit(1))
        # self.toolButtonEdit_2.clicked.connect(lambda : self.CTool.changevalueEdit(2))
        # self.toolButtonEdit_3.clicked.connect(lambda : self.CTool.changevalueEdit(3))
        # self.toolButtonEdit_4.clicked.connect(lambda : self.CTool.changevalueEdit(4))
        # self.toolButtonEdit_5.clicked.connect(lambda : self.CTool.changevalueEdit(5))
        # self.toolButtonEdit_6.clicked.connect(lambda : self.CTool.changevalueEdit(6))
        # self.toolButtonEdit_7.clicked.connect(lambda : self.CTool.changevalueEdit(7))
        # self.toolButtonEdit_8.clicked.connect(lambda : self.CTool.changevalueEdit(8))
        # self.toolButtonEdit_9.clicked.connect(lambda : self.CTool.changevalueEdit(9))
        # self.toolButtonEdit_10.clicked.connect(lambda : self.CTool.changevalueEdit(10))
        # self.toolButtonEdit_11.clicked.connect(lambda : self.CTool.changevalueEdit(11))
        # self.toolButtonEdit_12.clicked.connect(lambda : self.CTool.changevalueEdit(12))
        # self.toolButtonEdit_13.clicked.connect(lambda : self.CTool.changevalueEdit(13))
        # self.toolButtonEdit_14.clicked.connect(lambda : self.CTool.changevalueEdit(14))
        # self.toolButtonEdit_15.clicked.connect(lambda : self.CTool.changevalueEdit(15))
        # self.toolButtonEdit_16.clicked.connect(lambda : self.CTool.changevalueEdit(16))
        # self.toolButtonEdit_17.clicked.connect(lambda : self.CTool.changevalueEdit(17))
        # self.toolButtonEdit_18.clicked.connect(lambda : self.CTool.changevalueEdit(18))
        # self.toolButtonEdit_19.clicked.connect(lambda : self.CTool.changevalueEdit(19))

    def checkBoxmsg(self):
        self.Settings.setValue('addvalues/checkBox_msg', self.checkBox_msg.checkState())
        self.CTool.dlg.checkBox_msg.setCheckState(int(self.Settings.value('addvalues/checkBox_msg', Qt.Checked)))

    def checkBoxsave(self):
        self.Settings.setValue('addvalues/checkBox_save', self.checkBox_save.checkState())
        self.CTool.dlg.checkBox_save.setCheckState(int(self.Settings.value('addvalues/checkBox_save', Qt.Checked)))

    def layercomboBox(self):
        layer_Index=self.comboBox.currentIndex()
        layer_Text = self.comboBox.currentText()
        self.Settings.setValue('addvalues/layer_comboBox', int(layer_Index))
        self.Settings.setValue('addvalues/layer_Text', layer_Text)
        self.CTool.layer_combo.setCurrentIndex(layer_Index)

        self.CTool.layercha(layer_Index)

        # for t in range(0,20):
        #     Tab_LineEdit_cols='Tab'+str(t+1)+'_lineEdit_cols' + str( '' if layer_Index == 0 else layer_Index)
        #     Tab_LineEdit_vals='Tab'+str(t+1)+'_lineEdit_vals' + str( '' if layer_Index==0 else layer_Index)
        #     Tab_LineEdit_views='Tab'+str(t+1)+'_lineEdit_views' + str( '' if layer_Index==0 else layer_Index)

        #     labelvalue='label_'+str(t)

        #     self.findChild(QLabel,labelvalue).setToolTip(str(locale.value('addvalues/' + Tab_LineEdit_cols,'')))
        #     self.findChild(QLabel,labelvalue).setText(str(locale.value('addvalues/' + Tab_LineEdit_views,'')))

