from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject)

from PyQt5.QtCore import (QSettings,
                          Qt,
                          QUrl)

from PyQt5.QtGui import QIcon

from PyQt5.QtWidgets import (QApplication,
                             QLineEdit,
                             QLabel,
                             QToolButton)

from qgis.PyQt.QtWidgets import QMessageBox

import os.path

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'Add_Values_dialog_val.ui'))

class AddValuesdialogval(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(AddValuesdialogval, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool

        locale=QSettings()

        self.toolButton_setting.setIcon(QIcon(os.path.dirname(__file__) + "/icons/setting.png"))
        self.toolButton_setting.clicked.connect(self.CTool.setpopup)

        self.layer_comboBox = locale.value('/locale/addvalues/layer_comboBox_list', 0)
        if not isinstance( self.layer_comboBox, list):
            self.layer_comboBox = []
            self.layer_comboBox.append('Default')

        self.comboBox.clear()
        self.comboBox.addItems(self.layer_comboBox)
        layer_Index = int(locale.value('/locale/addvalues/layer_comboBox',0))
        self.layer_Text = locale.value('/locale/addvalues/layer_Text', '')
        self.comboBox.setCurrentIndex(layer_Index)

        for t in range(0,20):
            Tab_LineEdit_cols='Tab'+str(t+1)+'_lineEdit_cols' + str( '' if layer_Index == 0 else layer_Index)
            Tab_LineEdit_vals='Tab'+str(t+1)+'_lineEdit_vals' + str( '' if layer_Index==0 else layer_Index)
            Tab_LineEdit_views='Tab'+str(t+1)+'_lineEdit_views' + str( '' if layer_Index==0 else layer_Index)

            labelvalue='label_'+str(t)
            self.findChild(QLabel,labelvalue).setToolTip(str(locale.value('/locale/addvalues/' + Tab_LineEdit_cols,'')))

            valtext = str(locale.value('/locale/addvalues/' + Tab_LineEdit_vals,''))
            viewtext = str(locale.value('/locale/addvalues/' + Tab_LineEdit_views,''))

            if viewtext != '' :
                viewtext = viewtext + ' [' + valtext  + ']' 
                labelvalue='label_'+str(t)
                self.findChild(QLabel,labelvalue).setText(str(viewtext))
            else:
                labelvalue='label_'+str(t)
                self.findChild(QLabel,labelvalue).setText(str(valtext))

        self.comboBox.currentIndexChanged.connect(self.layercomboBox)

        self.toolButton_0.clicked.connect(lambda : self.CTool.run(0))
        self.toolButton_1.clicked.connect(lambda : self.CTool.run(1))
        self.toolButton_2.clicked.connect(lambda : self.CTool.run(2))
        self.toolButton_3.clicked.connect(lambda : self.CTool.run(3))
        self.toolButton_4.clicked.connect(lambda : self.CTool.run(4))
        self.toolButton_5.clicked.connect(lambda : self.CTool.run(5))
        self.toolButton_6.clicked.connect(lambda : self.CTool.run(6))
        self.toolButton_7.clicked.connect(lambda : self.CTool.run(7))
        self.toolButton_8.clicked.connect(lambda : self.CTool.run(8))
        self.toolButton_9.clicked.connect(lambda : self.CTool.run(9))
        self.toolButton_10.clicked.connect(lambda : self.CTool.run(10))
        self.toolButton_11.clicked.connect(lambda : self.CTool.run(11))
        self.toolButton_12.clicked.connect(lambda : self.CTool.run(12))
        self.toolButton_13.clicked.connect(lambda : self.CTool.run(13))
        self.toolButton_14.clicked.connect(lambda : self.CTool.run(14))
        self.toolButton_15.clicked.connect(lambda : self.CTool.run(15))
        self.toolButton_16.clicked.connect(lambda : self.CTool.run(16))
        self.toolButton_17.clicked.connect(lambda : self.CTool.run(17))
        self.toolButton_18.clicked.connect(lambda : self.CTool.run(18))
        self.toolButton_19.clicked.connect(lambda : self.CTool.run(19))

        self.checkBox_msg.stateChanged.connect(self.checkBoxmsg)
        self.checkBox_save.stateChanged.connect(self.checkBoxsave)
        
        self.checkBox_save.stateChanged.connect(self.checkBoxsave)


        self.checkBox_msg.setCheckState(int(locale.value('/locale/addvalues/checkBox_msg', Qt.Checked))) #Qt.Unchecked
        self.checkBox_save.setCheckState(int(locale.value('/locale/addvalues/checkBox_save', Qt.Checked))) #Qt.Unchecked

    def checkBoxmsg(self):
        locale=QSettings()
        locale.setValue('/locale/addvalues/checkBox_msg', self.checkBox_msg.checkState())
        self.CTool.dlg.checkBox_msg.setCheckState(int(locale.value('/locale/addvalues/checkBox_msg', Qt.Checked)))

    def checkBoxsave(self):
        locale=QSettings()
        locale.setValue('/locale/addvalues/checkBox_save', self.checkBox_save.checkState())
        self.CTool.dlg.checkBox_save.setCheckState(int(locale.value('/locale/addvalues/checkBox_save', Qt.Checked)))

    def layercomboBox(self):
        locale=QSettings()
        layer_Index=self.comboBox.currentIndex()
        layer_Text = self.comboBox.currentText()
        locale.setValue('/locale/addvalues/layer_comboBox', int(layer_Index))
        locale.setValue('/locale/addvalues/layer_Text', layer_Text)
        self.CTool.layer_combo.setCurrentIndex(layer_Index)

        for t in range(0,20):
            Tab_LineEdit_cols='Tab'+str(t+1)+'_lineEdit_cols' + str( '' if layer_Index == 0 else layer_Index)
            Tab_LineEdit_vals='Tab'+str(t+1)+'_lineEdit_vals' + str( '' if layer_Index==0 else layer_Index)
            Tab_LineEdit_views='Tab'+str(t+1)+'_lineEdit_views' + str( '' if layer_Index==0 else layer_Index)

            labelvalue='label_'+str(t)

            self.findChild(QLabel,labelvalue).setToolTip(str(locale.value('/locale/addvalues/' + Tab_LineEdit_cols,'')))
            self.findChild(QLabel,labelvalue).setText(str(locale.value('/locale/addvalues/' + Tab_LineEdit_views,'')))

