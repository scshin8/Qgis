from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from qgis.PyQt.QtCore import *

from qgis.PyQt.QtCore import*
from qgis.PyQt.QtGui import*
from qgis.PyQt.QtWidgets import*
from PyQt5.QtCore import *
from PyQt5.QtWidgets import*
from PyQt5.QtGui import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import plugins, reloadPlugin, updateAvailablePlugins, unloadPlugin, loadPlugin, startPlugin
from qgis.PyQt.QtWidgets import QTableWidgetItem

# Import the code for the dialog
from .Add_Values_dialog_base_05 import AddValuesDialogbase05
from .Add_Values_dialog_base_10 import AddValuesDialogbase10
from .Add_Values_dialog_base_15 import AddValuesDialogbase15
from .Add_Values_dialog_base_20 import AddValuesDialogbase20
import os.path

class AddValues:

    def __init__(self, iface):

        # Save reference to the QGIS interface
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        
        # tb=self.iface.mainWindow().findChild(QToolBar,'toolbar1')
        # if tb == None :
        #     self.toolbar = self.iface.addToolBar('toolbar1')
        #     self.toolbar.setObjectName('toolbar1')
        #     tb=self.iface.mainWindow().findChild(QToolBar,'toolbar1')
        #     # self.toolbar.setObjectName('toolbar1')
        # self.toolbar = tb
        
        self.toolbar = self.iface.addToolBar('속성입력 툴바')
        self.toolbar.setObjectName('속성입력 툴바')
        
        self.plugin_dir = os.path.dirname(__file__)

        locale= QSettings()
        
        # locale_path = os.path.join(self.plugin_dir,'i18n','AddValues_{}.qm'.format(locale))

        self.addval_set_idx = int(locale.value('/locale/addvalues/AddValuesDialogbase',0))
        
        if self.addval_set_idx == 0:
            self.dlg = AddValuesDialogbase05()
        elif self.addval_set_idx == 1:
            self.dlg = AddValuesDialogbase10()
        elif self.addval_set_idx == 2:
            self.dlg = AddValuesDialogbase15()
        elif self.addval_set_idx == 3:
            self.dlg = AddValuesDialogbase20()
        
        # if os.path.exists(locale_path):
        #     self.translator = QTranslator()
        #     self.translator.load(locale_path)
        #     QCoreApplication.installTranslator(self.translator)

        self.dlg.buttonBox.button(QDialogButtonBox.Save).clicked.connect(self.save)
        self.dlg.buttonBox.button(QDialogButtonBox.Reset).clicked.connect(self.reset)
        self.dlg.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.close)

        self.dlg.tabWidget_2.currentChanged.connect(self.layerlist)
        
        icon = QIcon(os.path.dirname(__file__) + "/icons/F5.png")
        self.dlg.F5_toolButton.setIcon(icon)
        self.dlg.F5_toolButton.clicked.connect(self.refresh)
        
        self.dlg.comboBox_layers.currentIndexChanged.connect(self.layerlist)
        
        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.toggle)
        
        # self.dlg.del_pushButton.clicked.connect(self.del_tabWidget)
        # self.dlg.save_pushButton.clicked.connect(self.save_tabWidget)

        # self.dlg.col_comboBox.currentIndexChanged.connect(self.colunmnChange)
        # self.dlg.val_comboBox.currentIndexChanged.connect(self.valueChange)

        # self.col_comboBox = locale.value('/locale/addvalues/col_comboBox', 0)
        # if not isinstance(self.col_comboBox, list):
        #     self.col_comboBox = []
        #     self.col_comboBox.insert(0,'')
        # self.val_comboBox = locale.value('/locale/addvalues/val_comboBox', 0)
        # if not isinstance(self.val_comboBox, list):
        #     self.val_comboBox = []
        #     self.val_comboBox.insert(0,'')
        
        self.actions = []
        
        self.menu = self.tr(u'&Add_Values')

        self.Plugin='add_values_ver2'
        
        self.dlg.addval_set_comboBox.currentIndexChanged.connect(self.setcomboBox)

        self.first_start = None

    def tr(self, message):
        return QCoreApplication.translate('AddValues', message)

    def tabWidgetChange(self):
        print('tabWidgetChange')

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        # if add_to_toolbar:
        #     # Adds plugin icon to Plugins toolbar
        #     self.iface.addToolBarIcon(action)

        # if add_to_menu:
        #     self.iface.addPluginToMenu(
        #         self.menu,
        #         action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        locale=QSettings()
        self.addval_set_idx = int(locale.value('/locale/addvalues/AddValuesDialogbase',0))
        
        print(self.addval_set_idx)
        
        self.add_values_toolbar0 = QToolButton(self.toolbar)
        self.add_values_toolbar0.setPopupMode(QToolButton.MenuButtonPopup)
        self.add_values_toolbar0.setObjectName("add_values_toolbarButton")
        
        if self.addval_set_idx >= 1:
            self.add_values_toolbar1 = QToolButton(self.toolbar)
            self.add_values_toolbar1.setPopupMode(QToolButton.MenuButtonPopup)
            self.add_values_toolbar1.setObjectName("add_values_toolbarButton")
            
        if self.addval_set_idx >= 2:
            self.add_values_toolbar2 = QToolButton(self.toolbar)
            self.add_values_toolbar2.setPopupMode(QToolButton.MenuButtonPopup)
            self.add_values_toolbar2.setObjectName("add_values_toolbarButton")
            
        if self.addval_set_idx == 3:
            self.add_values_toolbar3 = QToolButton(self.toolbar)
            self.add_values_toolbar3.setPopupMode(QToolButton.MenuButtonPopup)
            self.add_values_toolbar3.setObjectName("add_values_toolbarButton")
            
        icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon1.png")
        self.add_action(
            icon_path,
            text=self.tr(u'입력1'),
            callback=(lambda : self.run(0)),
            parent=self.iface.mainWindow())
        self.iface.registerMainWindowAction(self.actions[0], "1")
        
        icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon2.png")
        self.add_action(
            icon_path,
            text=self.tr(u'입력2'),
            callback=(lambda : self.run(1)),
            parent=self.iface.mainWindow())
        self.iface.registerMainWindowAction(self.actions[1], "2")
        
        icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon3.png")
        self.add_action(
            icon_path,
            text=self.tr(u'입력3'),
            callback=(lambda : self.run(2)),
            parent=self.iface.mainWindow())
        self.iface.registerMainWindowAction(self.actions[2], "3")

        icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon4.png")
        self.add_action(
            icon_path,
            text=self.tr(u'입력4'),
            callback=(lambda : self.run(3)),
            parent=self.iface.mainWindow())
        self.iface.registerMainWindowAction(self.actions[3], "4")
        
        icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon5.png")
        self.add_action(
            icon_path,
            text=self.tr(u'입력5'),
            callback=(lambda : self.run(4)),
            parent=self.iface.mainWindow())
        self.iface.registerMainWindowAction(self.actions[4], "5")
        
        if self.addval_set_idx >= 1:
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon6.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력6'),
                callback=(lambda : self.run(5)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[5], "6")
            
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon7.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력7'),
                callback=(lambda : self.run(6)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[6], "7")
            
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon8.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력8'),
                callback=(lambda : self.run(7)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[7], "8")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon9.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력9'),
                callback=(lambda : self.run(8)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[8], "9")
            
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon10.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력10'),
                callback=(lambda : self.run(9)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[9], "0")

        if self.addval_set_idx >= 2 :
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon11.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력11'),
                callback=(lambda : self.run(10)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[10], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon12.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력12'),
                callback=(lambda : self.run(11)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[11], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon13.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력13'),
                callback=(lambda : self.run(12)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[12], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon14.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력14'),
                callback=(lambda : self.run(13)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[13], "")
            
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon15.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력15'),
                callback=(lambda : self.run(14)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[14], "")
        
        if self.addval_set_idx == 3:
            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon16.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력16'),
                callback=(lambda : self.run(15)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[15], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon17.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력17'),
                callback=(lambda : self.run(16)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[16], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon18.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력18'),
                callback=(lambda : self.run(17)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[17], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon19.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력19'),
                callback=(lambda : self.run(18)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[18], "")

            icon_path = QIcon(os.path.dirname(__file__) + "/icons/icon20.png")
            self.add_action(
                icon_path,
                text=self.tr(u'입력20'),
                callback=(lambda : self.run(19)),
                parent=self.iface.mainWindow())
            self.iface.registerMainWindowAction(self.actions[19], "")

        icon_path = QIcon(os.path.dirname(__file__) + "/icons/setting.png")
        self.add_action(
            icon_path,
            text=self.tr(u'설정'),
            callback=self.setpopup,
            parent=self.iface.mainWindow())
        #self.toolbar.addAction(self.actions[3])
        print('툴바셋팅')
        
        for i in range(5):
            if i == 0:
                self.add_values_toolbar0.setDefaultAction(self.actions[i])
            else:
                self.add_values_toolbar0.addAction(self.actions[i])
        self.toolbar.addWidget( self.add_values_toolbar0)

        if self.addval_set_idx >= 1:        
            for i in range(5,10):
                if i == 5:
                    self.add_values_toolbar1.setDefaultAction(self.actions[i])
                else:
                    self.add_values_toolbar1.addAction(self.actions[i])
            self.toolbar.addWidget( self.add_values_toolbar1)
            
        if self.addval_set_idx >= 2:        
            for i in range(10,15):
                if i == 10:
                    self.add_values_toolbar2.setDefaultAction(self.actions[i])
                else:
                    self.add_values_toolbar2.addAction(self.actions[i])
            self.toolbar.addWidget( self.add_values_toolbar2)
            
        if self.addval_set_idx == 3:        
            for i in range(15,20):
                if i == 15:
                    self.add_values_toolbar3.setDefaultAction(self.actions[i])
                else:
                    self.add_values_toolbar3.addAction(self.actions[i])
            self.toolbar.addWidget( self.add_values_toolbar3)

        self.toolbar.addAction(self.actions[-1])
        self.first_start = True
        self.toggle()
        
    def toggle(self):
        # 현재 레이어층 가져오기
        layer = self.canvas.currentLayer()
        
        if layer and layer.type() == layer.VectorLayer:
            try:
                layer.editingStarted.disconnect(self.toggle)
            except:
                pass
            try:
                layer.editingStopped.disconnect(self.toggle)
            except:
                pass
            
            # 현재 도면층이 편집 가능하고 선택한 피쳐가 있는지 확인
            # 그리고 플러그인 버튼을 활성화할지 비활성화할지 결정합니다.
            # 도면층 편집 활성화
            if layer.isEditable():
                if layer.selectedFeatureCount() > 0:
                    for i in range(len(self.actions)-1):
                        self.actions[i].setEnabled(True)
                else:
                    for i in range(len(self.actions)-1):
                        self.actions[i].setEnabled(False)
                layer.editingStopped.connect(self.toggle)
            # 도면층을 편집 비활성화
            else:
                for i in range(len(self.actions)-1):
                    self.actions[i].setEnabled(False)
                layer.editingStarted.connect(self.toggle)
        else:
            for i in range(len(self.actions)-1):
                self.actions[i].setEnabled(False)
            
    def close(self):
        self.dlg.close()

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Add_Values'),
                action)
            self.iface.removeToolBarIcon(action)
            self.action = None
            self.iface.unregisterMainWindowAction(action)
        del self.toolbar

    def fieldtype(self,layer,colunmns,values,idx):
        # Integer /Integer64 / Real / String / Date
        type=layer.fields()[layer.fields().indexFromName(colunmns[idx])].typeName()
        if str(type)=='Integer' or str(type)=='Integer64':
            return int(float(values[idx]))
        else:
            return values[idx]

    def changeValue(self, colunmns, values,inputNo):
        layer = self.iface.activeLayer()
        self.canvas.refresh()
        layer.beginEditCommand("Feature triangulation")
        cLen=int(len(colunmns))-1
        if(layer):
            nF = layer.selectedFeatureCount()
            
            # 레이어 편집모드 확인
            bEditable = layer.isEditable()
                
            if (nF > 0):
                ob = layer.selectedFeatureIds()
                for i in ob:
                    idx=0
                    while idx <= cLen:
                        if layer.fields().indexFromName(colunmns[idx]) >= 0:
                            layer.changeAttributeValue(int(i), layer.fields().indexFromName(colunmns[idx]), self.fieldtype(layer,colunmns,values,idx), True)
                            idx += 1
                        else:
                            reply = QMessageBox.question(None,
                                                        self.tr("Error"),
                                                        self.tr("\n입력"+str(inputNo)+"의 ["+ str(colunmns[idx]) +"] 필드가 레이어에 없습니다.\n\n해당 필드를 추가하시겠습니까?\n"),
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

                            # QMessageBox.critical(self.iface.mainWindow(), "Error", "입력"+str(inputNo)+"의 "+ str(colunmnval) +" 필드가 입력레이어에 없습니다.")#"입력"+str(inputNo)+"의 "+ str(colunmnval) +" 필드가 없습니다.\n 필드 생성 'Yes'\n 입력값수정 'No'"
                            if reply == QMessageBox.Yes:
                                vLayer = self.iface.activeLayer()
                                name=str(colunmns[idx])
                                vLayer.dataProvider().addAttributes([QgsField(name, QVariant.String,'',30)])
                                vLayer.updateFields()
                                layer.changeAttributeValue(int(i), layer.fields().indexFromName(colunmns[idx]), self.fieldtype(layer,colunmns,values,idx), True)
                                idx += 1
                            else:
                                self.showTab(int(inputNo)-1)
                                return None

            else:
                # QMessageBox.critical(self.iface.mainWindow(), "Error", "Please select at least one feature from current layer")
                self.iface.messageBar().pushMessage("", "Please select at least one feature from current layer", level=Qgis.Warning, duration=4)
                return None
            
            
            if bEditable:
                if self.dlg.checkBox_save.isChecked():
                    layer.commitChanges()
                    layer.endEditCommand()
                    layer.startEditing()
                else:
                    layer.endEditCommand()

            self.canvas.refresh()
            # QMessageBox.information(self.iface.mainWindow(), "ok", '')
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "Please select a layer")
            return None

    def run(self,ids):
        locale=QSettings()
        inputNo=ids+1
        print('입력'+str(inputNo))
        Tab_LineEdit_cols='Tab'+str(inputNo)+'_lineEdit_cols'
        colunmn=locale.value('/locale/addvalues/'+Tab_LineEdit_cols,"")
        Tab_LineEdit_vals='Tab'+str(inputNo)+'_lineEdit_vals'
        value=locale.value('/locale/addvalues/'+Tab_LineEdit_vals,"")
        
        if inputNo <= 5 :
            self.add_values_toolbar=self.add_values_toolbar0
        elif inputNo <= 10 :
            self.add_values_toolbar=self.add_values_toolbar1
        elif inputNo <= 15 :
            self.add_values_toolbar=self.add_values_toolbar1
        elif inputNo <= 20 :
            self.add_values_toolbar=self.add_values_toolbar1
        self.add_values_toolbar.setDefaultAction(self.actions[ids])

        if colunmn != '':
            colunmns=colunmn.split('/')
            values=value.split('/')
            
            if self.dlg.checkBox_msg.isChecked():
            
                msg=''
                for col,val in zip(colunmns,values):
                    # col=f'{col:6}'
                    msg += msg + col +' : '+ val +'\n'

                reply = QMessageBox.question(None,
                                        self.tr(f"입력{inputNo}"),
                                        self.tr(msg),
                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
                
                if reply == QMessageBox.Yes:
                    self.changeValue(colunmns,values,inputNo)
                    
            else:
                
                self.changeValue(colunmns,values,inputNo)
                
                
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Error", '입력'+str(inputNo)+"의 설정 값이 없습니다.")
            self.showTab(int(inputNo)-1)
            return None

    def setpopup(self):
        self.dlg.show()
        self.setting()
        
    def layerlist(self):
        if self.chk1==0:
            print('layerlist')
            t=self.dlg.tabWidget_2.currentIndex()+1
            # self.dlg.save_pushButton.setText('입력'+ str(t) + ' 저장')
            # self.dlg.del_pushButton.setText('입력'+ str(t) + ' 삭제')
            layers = self.iface.mapCanvas().layers() 
            i=int(self.dlg.comboBox_layers.currentIndex())
            if len(layers)>0:
                Layer=layers[i-1]
                print(Layer.type())
                if Layer.type() == QgsMapLayerType.VectorLayer and i > 0 :
                    self.backupState(Layer)
                else:
                    self.dlg.tableWidget.setColumnCount(2)
                    table_column1=["추가" , "필드명"]
                    self.dlg.tableWidget.setHorizontalHeaderLabels(table_column1)
                    self.dlg.tableWidget.setRowCount(0)
                    self.dlg.tableWidget.resizeColumnsToContents()

    def backupState(self, Layer):
        self.Buttons=[]
        tabNo=self.dlg.tabWidget_2.currentIndex()+1
        self.fieldNamestab=[field.name() for field in Layer.fields()]
        print(Layer)
        print(self.fieldNamestab)
        field=len(self.fieldNamestab)
        self.dlg.tableWidget.setColumnCount(2)
        self.dlg.tableWidget.setRowCount(field)
        for row in range (field):
            btn=QPushButton("추가")
            self.Buttons.append(btn)
            button=self.Buttons[row]
            button.clicked.connect(self.btn_fun)
            button.setCheckable(True)
            self.dlg.tableWidget.setCellWidget(row,0,button) # 추가 버튼 추가
            self.dlg.tableWidget.setItem(row, 1, QTableWidgetItem(str(self.fieldNamestab[row])))
            colname=str(self.fieldNamestab[row])
            for i in range(10):
                lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i))
                if lineEdit.text() == colname:
                    button.setText('삭제')
                    button.setChecked(True)
                    break

        for i in range(2):
            self.dlg.tableWidget.resizeColumnToContents(i)
        self.dlg.tableWidget.setAlternatingRowColors(True)
        
    def btn_fun(self):
        button = self.dlg.tableWidget.sender()
        name=button.text()
        tabNo=self.dlg.tabWidget_2.currentIndex()+1
        idx = self.dlg.tableWidget.indexAt(button.pos()).row()
        # rowCount=self.dlg.tableWidget.rowCount()
        colname=self.dlg.tableWidget.item( idx,1 ).text()

        if name == '추가':
            self.addcolname(tabNo,idx,colname)
            button.setText('삭제')
            button.setChecked(True)
        else:
            self.delcolname(tabNo,idx,colname)
            button.setText('추가')
        # self.layerlist()
          
    def addcolname(self,tabNo,idx,colname):
            chk=False
            print('btn_fun'+str(idx)+"추가")
            # 중복값 확인
            for i in range(10):
                lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i))
                if lineEdit.text() == colname:
                    chk=True
                    break
            # 중복값이 없다면 빈자리 찾아서 필드명 추가
            if chk==False:
                print("False")
                for i in range(10):
                    lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i))
                    if lineEdit.text() == '':
                        lineEdit.setText(colname)
                        break
        
    def delcolname(self,tabNo,idx,colname):
        print('btn_fun'+str(idx)+'삭제')
        # chk=False
        for i in range(10):
            lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i))
            if lineEdit.text() == colname:
                lineEdit.clear()
                self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_val_'+str(i)).clear()

                for i in range(i,9):
                    colF_lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i))
                    valF_lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_val_'+str(i))
                    colR_lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_col_'+str(i+1))
                    valR_lineEdit=self.dlg.findChild(QLineEdit,'Tab' +str(tabNo)+'_lineEdit_val_'+str(i+1))
                    colF_lineEdit.setText(colR_lineEdit.text())
                    valF_lineEdit.setText(valR_lineEdit.text())
                    colR_lineEdit.clear()
                    valR_lineEdit.clear()

    # def colunmnChange(self):
    #     if self.chk1==0:
    #         print('colunmnChange')
    #         locale=QSettings()
    #         t=self.dlg.tabWidget_2.currentIndex()+1
    #         idx=int(self.dlg.col_comboBox.currentIndex())
    #         if idx > 0:
    #             colunmns = locale.value('/locale/addvalues/col_comboBox',0)[idx].strip()
    #             colunmn=colunmns.split('/')
                
    #             for i in range(10):
    #                 self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_col_'+str(i)).clear()
                    
    #             for i in range(len(colunmn)):
    #                 self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_col_'+str(i)).setText(colunmn[i])
                    
    #         self.dlg.col_comboBox.setCurrentIndex(0)

    # def valueChange(self):
    #     if self.chk1==0:
    #         print('valueChange')
    #         locale=QSettings()
    #         t=self.dlg.tabWidget_2.currentIndex()+1
    #         idx=int(self.dlg.val_comboBox.currentIndex())
    #         if idx > 0:
    #             values = locale.value('/locale/addvalues/val_comboBox',0)[idx].strip()
    #             value=values.split('/')
                
    #             for i in range(10):
    #                 self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_val_'+str(i)).clear()
                    
    #             for i in range(len(value)):
    #                 self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_val_'+str(i)).setText(value[i])
                    
    #         self.dlg.val_comboBox.setCurrentIndex(0)

    # def save_tabWidget(self):
    #     print('save_tabWidget')
    #     locale=QSettings()
    #     t=self.dlg.tabWidget_2.currentIndex()+1
    #     Scols=[]
    #     Svals=[]
    #     cols=''
    #     vals=''
    #     for i in range(10):
    #         LineEdit_col='Tab'+str(t)+'_lineEdit_col_'+str(i)
    #         col=self.dlg.findChild(QLineEdit,LineEdit_col).text()
    #         LineEdit_val='Tab'+str(t)+'_lineEdit_val_'+str(i)
    #         val=self.dlg.findChild(QLineEdit,LineEdit_val).text()
    #         if col != '' :
    #             if cols == '':
    #                 cols = col
    #                 vals = val
    #             else:
    #                 cols = cols + '/' + col
    #                 vals = vals+ '/' + val

    #     Tab_LineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
    #     locale.setValue('/locale/addvalues/'+Tab_LineEdit_cols,cols)
    #     Tab_LineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
    #     locale.setValue('/locale/addvalues/'+Tab_LineEdit_vals,vals)

    #     Scols.append(cols)
    #     Svals.append(vals)

    #     self.layerlist()
        # self.comboBox(Scols,Svals,1)
    #     msgs=''
    #     if Lcol != cols:
    #         if Lval != vals:
    #             msg = str('입력'+str(i+1)+' 수정 \n 필드명 : [ ' + str(Lcol) +' ] 에서 [ ' +str(cols)+' ] 으로 변경 \n 입력값 : [ '+ str(Lval) +'] 에서 [ ' +str(vals)+' ] 으로 변경\n')
    #         else:
    #             msg = str('입력'+str(i+1)+' 수정 \n 필드명 : [ ' + str(Lcol) +' ] 에서 [ ' +str(cols)+' ] 으로 변경\n')
    #     elif  Lcol == cols:
    #         if Lval != vals:
    #             msg = str('입력'+str(i+1)+' 수정 \n 입력값 : [ '+ str(Lval) +' ] 에서 [ ' +str(vals)+' ] 으로 변경\n')
    #         else:
    #             msg = ''
    #     msgs = str(msgs) + str(msg)
    #     msg = ''

    #     if msgs == '':
    #         QMessageBox.information(self.iface.mainWindow(), "None", '변경된 값이 없습니다.')
    #     else:
    #         QMessageBox.information(self.iface.mainWindow(), "ok", str(msgs))  

    #     self.dlg.show()
    
    def setcomboBox(self):
        locale=QSettings()
        if self.set_idx==0:
            locale.setValue('/locale/addvalues/AddValuesDialogbase', int(self.dlg.addval_set_comboBox.currentIndex()))
            self.dlg.close()
            unloadPlugin(self.Plugin)
            loadPlugin(self.Plugin)
            startPlugin(self.Plugin)
        
    # def del_tabWidget(self):
    #     print('del_tabWidget')
    #     locale=QSettings()
    #     t=self.dlg.tabWidget_2.currentIndex()+1
    #     for i in range(10):
    #         self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_col_'+str(i)).clear()
    #         self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_val_'+str(i)).clear()

    #     Tab_LineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
    #     locale.setValue('/locale/addvalues/'+Tab_LineEdit_cols,'')
    #     Tab_LineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
    #     locale.setValue('/locale/addvalues/'+Tab_LineEdit_vals,'')
    #     self.layerlist()

    def refresh(self):
        print('refresh')
        layers = self.iface.mapCanvas().layers()  # 활성화된 레이어
        self.chk1=1
        layer_list = [layer.name() for layer in layers]
        layer_list.insert(0,'')
        self.dlg.comboBox_layers.clear()
        self.dlg.comboBox_layers.addItems(layer_list)
        self.dlg.comboBox_layers.setCurrentIndex(0)
        self.chk1=0
        
        t=self.dlg.tabWidget_2.currentIndex()+1
        lineEdit_col_txt=[]
        lineEdit_val_txt=[]

        for i in range(10):
            LineEdit_col='Tab' +str(t)+'_lineEdit_col_'+str(i)
            LineEdit_val='Tab' +str(t)+'_lineEdit_val_'+str(i)
            lineEdit_col_text=self.dlg.findChild(QLineEdit,LineEdit_col).text()
            lineEdit_val_text=self.dlg.findChild(QLineEdit,LineEdit_val).text()
            lineEdit_col_txt.append(lineEdit_col_text)
            lineEdit_val_txt.append(lineEdit_val_text)
            self.dlg.findChild(QLineEdit,LineEdit_col).clear()
            self.dlg.findChild(QLineEdit,LineEdit_val).clear()
        idx=0
        for i in range(10):
            if lineEdit_col_txt[i] != '':
                lineEdit_col=self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_col_'+str(idx))
                lineEdit_col.setText(lineEdit_col_txt[i])
                lineEdit_val=self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_val_'+str(idx))
                lineEdit_val.setText(lineEdit_val_txt[i])
                idx += 1
        self.layerlist()
        
    def showTab(self, tab):
        print('showTab')
        self.dlg.show()
        self.setting()
        self.dlg.tabWidget_2.setCurrentIndex(tab)

    def setting(self):
        print('setting')
        locale=QSettings()

        layers = self.iface.mapCanvas().layers()  # 활성화된 레이어
        # layers = QgsProject.instance().mapLayers().values() # 레이어 패널의 모든 레이어
        self.chk1=1
        layer_list = [layer.name() for layer in layers]
        layer_list.insert(0,'')
        self.dlg.comboBox_layers.clear()
        self.dlg.comboBox_layers.addItems(layer_list)
        self.dlg.comboBox_layers.setCurrentIndex(0)
        
        self.dlg.checkBox_msg.setCheckState(int(locale.value('/locale/addvalues/checkBox_msg',Qt.Checked)))
        self.dlg.checkBox_save.setCheckState(int(locale.value('/locale/addvalues/checkBox_save',Qt.Unchecked)))
        
        # self.dlg.comboBox_fields.clear()
        
        # self.dlg.col_comboBox.clear()
        # self.dlg.col_comboBox.addItems(self.col_comboBox)
        # self.dlg.col_comboBox.setCurrentIndex(0)

        # self.dlg.val_comboBox.clear()
        # self.dlg.val_comboBox.addItems(self.val_comboBox)
        # self.dlg.val_comboBox.setCurrentIndex(0)

        # t=self.dlg.tabWidget_2.currentIndex()+1
        # self.dlg.save_pushButton.setText('입력'+ str(t) + ' 저장')
        # self.dlg.del_pushButton.setText('입력'+ str(t) + ' 삭제')
# 테이블 초기화===================================================================================
        print('테이블 초기화')
        self.dlg.tableWidget.setColumnCount(2)
        self.dlg.tableWidget.setRowCount(0)
        table_column1=["추가" , "필드명"]
        self.dlg.tableWidget.setHorizontalHeaderLabels(table_column1)
        self.dlg.tableWidget.resizeColumnsToContents()

        for t in range(1,len(self.actions)):
            Tab_lineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
            Tab_lineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
            Tab_lineEdit_col=str(locale.value('/locale/addvalues/'+str(Tab_lineEdit_cols),''))
            Tab_lineEdit_val=str(locale.value('/locale/addvalues/'+str(Tab_lineEdit_vals),''))
            cols=Tab_lineEdit_col.split('/')
            vals=Tab_lineEdit_val.split('/')
            idx=len(cols)
            if idx >= 1 :
                for i in range(len(cols)):
                    col=cols[i]
                    val=vals[i]
                    LineEdit_col='Tab'+str(t)+'_lineEdit_col_'+str(i)
                    LineEdit_val='Tab'+str(t)+'_lineEdit_val_'+str(i)
                    self.dlg.findChild(QLineEdit,LineEdit_col).setText(col)
                    self.dlg.findChild(QLineEdit,LineEdit_val).setText(val)

                for i in range(i+1,10):
                    LineEdit_col='Tab'+str(t)+'_lineEdit_col_'+str(i)
                    LineEdit_val='Tab'+str(t)+'_lineEdit_val_'+str(i)
                    self.dlg.findChild(QLineEdit,LineEdit_col).setText('')
                    self.dlg.findChild(QLineEdit,LineEdit_val).setText('')
                    
        self.set_idx=1
        self.addval_set_idx = int(locale.value('/locale/addvalues/AddValuesDialogbase',0))
        self.dlg.addval_set_comboBox.setCurrentIndex(self.addval_set_idx)
        self.set_idx=0
        self.chk1=0

    def save(self):
        locale=QSettings()
        print('save')
        locale.setValue('/locale/addvalues/checkBox_msg', str(self.dlg.checkBox_msg.checkState()))
        locale.setValue('/locale/addvalues/checkBox_save', str(self.dlg.checkBox_save.checkState()))
        # Lcols=[]
        # Lvals=[]
        Scols=[]
        Svals=[]
        for t in range(1,len(self.actions)):
            Tab_LineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
            Tab_LineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
            # Lcol=locale.value('/locale/addvalues/'+Tab_LineEdit_cols,'')
            # Lval=locale.value('/locale/addvalues/'+Tab_LineEdit_vals,'')
            # Lcols.append(Lcol)
            # Lvals.append(Lval)
            cols=''
            vals=''
            for i in range(10):
                LineEdit_col='Tab'+str(t)+'_lineEdit_col_'+str(i)
                LineEdit_val='Tab'+str(t)+'_lineEdit_val_'+str(i)
                col=self.dlg.findChild(QLineEdit,LineEdit_col).text()
                val=self.dlg.findChild(QLineEdit,LineEdit_val).text()
                if col != '' :
                    if cols == '':
                        cols = col
                        vals = val
                    else:
                        cols = cols + '/' + col
                        vals = vals+ '/' + val
            locale.setValue('/locale/addvalues/'+Tab_LineEdit_cols,cols)       
            locale.setValue('/locale/addvalues/'+Tab_LineEdit_vals,vals)    
            
            
                
            # Scols.append(cols)
            # Svals.append(vals)

        # msgs=''
        # for i in range(len(self.actions)-1):
        #     if Lcols[i] != Scols[i]:
        #         if Lvals[i] != Svals[i]:
        #             msg = str('입력'+str(i+1)+' 수정 \n 필드명 : [ ' + str(Lcols[i]) +' ] 에서 [ ' +str(Scols[i])+' ] 으로 변경 \n 입력값 : [ '+ str(Lvals[i]) +'] 에서 [ ' +str(Svals[i])+' ] 으로 변경\n')

        #         else:
        #             msg = str('입력'+str(i+1)+' 수정 \n 필드명 : [ ' + str(Lcols[i]) +' ] 에서 [ ' +str(Scols[i])+' ] 으로 변경\n')
        #             # locale.setValue('/locale/addvalues/colunmn'+str(i), Scols[i])
        #     elif  Lcols[i] == Scols[i]:
        #         if Lvals[i] != Svals[i]:
        #             msg = str('입력'+str(i+1)+' 수정 \n 입력값 : [ '+ str(Lvals[i]) +' ] 에서 [ ' +str(Svals[i])+' ] 으로 변경\n')
 
        #         else:
        #             msg = ''
        #     msgs = str(msgs) + str(msg)
        #     msg = ''

        # if msgs == '':
        #     QMessageBox.information(self.iface.mainWindow(), "None", '변경된 값이 없습니다.')
        # else:
        #     QMessageBox.information(self.iface.mainWindow(), "ok", str(msgs)) 

        # self.comboBox(Scols,Svals,len(self.actions)-1)
        locale.setValue('/locale/addvalues/AddValuesDialogbase', int(self.dlg.addval_set_comboBox.currentIndex()))
        print('close')
        self.dlg.close()

#     def comboBox(self,Scols,Svals,idx):
#         print('comboBox')
#         print(Scols)
#         print(Svals)
#         locale=QSettings()
# # 컬럼명 입력값 취합
#         for i in range(idx):
#             if Scols[i] != '':
#                 self.col_comboBox.insert(1,Scols[i])
# # 컬럼명 입력값 정렬_최신 10개 항목만 남기고 나머지 삭제
#         colresult = []
#         fid=0
#         for ii in range(len(self.col_comboBox)):
#             value = self.col_comboBox[ii]
#             if value not in colresult:
#                 if value !='':
#                     colresult.append(value)
#                     fid += 1
#             if fid == 10:
#                 break
# # 빈목록 추가 / 컬럼목록 저장
#         colresult.insert(0,'')
#         locale.setValue('/locale/addvalues/col_comboBox',colresult)
#         self.col_comboBox = locale.value('/locale/addvalues/col_comboBox', 0)
#         self.dlg.col_comboBox.clear()
#         self.dlg.col_comboBox.addItems(colresult)

# # 입력값 취합
#         for i in range(idx):    
#             if Svals[i] != '':
#                 self.val_comboBox.insert(1,Svals[i])
# # 입력값 정렬_최신 10개 항목만 남기고 나머지 삭제
#         valresult = []
#         fid=0
#         for ii in range(len(self.val_comboBox)):
#             value = self.val_comboBox[ii]
#             if value not in valresult:
#                 if value !='':
#                     valresult.append(value)
#                     fid += 1
#             if fid == 10:
#                 break
# # 빈목록 추가 / 입력값 목록 저장
#         valresult.insert(0,'')
#         locale.setValue('/locale/addvalues/val_comboBox',valresult)
#         self.val_comboBox = locale.value('/locale/addvalues/val_comboBox', 0)
#         self.dlg.val_comboBox.clear()
#         self.dlg.val_comboBox.addItems(valresult)

        
# 입력 초기화=====================================================================================
    def reset(self):
        
        reply = QMessageBox.question(None,
                                    self.tr("Warning"),
                                    self.tr("\n모든 설정값을 초기화 합니다"),
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

                            # QMessageBox.critical(self.iface.mainWindow(), "Error", "입력"+str(inputNo)+"의 "+ str(colunmnval) +" 필드가 입력레이어에 없습니다.")#"입력"+str(inputNo)+"의 "+ str(colunmnval) +" 필드가 없습니다.\n 필드 생성 'Yes'\n 입력값수정 'No'"
        if reply == QMessageBox.Yes:
            print('reset')
            locale=QSettings()
    # 레이어 필드 목록 초기화 ==========================================================================
            print('레이어 필드 목록 초기화')
            layers = self.iface.mapCanvas().layers()  # 활성화된 레이어
            # layers = QgsProject.instance().mapLayers().values() # 레이어 패널의 모든 레이어
            self.chk1=1
            layer_list = [layer.name() for layer in layers]
            layer_list.insert(0,'')
            
            self.dlg.comboBox_layers.clear()
            self.dlg.comboBox_layers.addItems(layer_list)
            self.dlg.comboBox_layers.setCurrentIndex(0)
    # 입력값 초기화 ====================================================================================
            print('입력값 초기화')
            
            for t in range(1,len(self.actions)):
                for i in range(10):
                    self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_col_'+str(i)).clear()
                    self.dlg.findChild(QLineEdit,'Tab' +str(t)+'_lineEdit_val_'+str(i)).clear()
                    
                Tab_LineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
                locale.setValue('/locale/addvalues/'+Tab_LineEdit_cols,'')
                Tab_LineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
                locale.setValue('/locale/addvalues/'+Tab_LineEdit_vals,'')
                
            for t in range(t+1,21):
                Tab_LineEdit_cols='Tab'+str(t)+'_lineEdit_cols'
                locale.setValue('/locale/addvalues/'+Tab_LineEdit_cols,'')
                Tab_LineEdit_vals='Tab'+str(t)+'_lineEdit_vals'
                locale.setValue('/locale/addvalues/'+Tab_LineEdit_vals,'')
                
    # 콤보박스 초기화 
            # print('콤보박스 초기화')
            # result = []
            # result.insert(0,'')
            
            # locale.setValue('/locale/addvalues/col_comboBox',result)
            # self.col_comboBox = locale.value('/locale/addvalues/col_comboBox', 0)
            # self.dlg.col_comboBox.clear()
            # self.dlg.col_comboBox.addItems(result)
            
            # locale.setValue('/locale/addvalues/val_comboBox',result)
            # self.val_comboBox = locale.value('/locale/addvalues/val_comboBox', 0)
            # self.dlg.val_comboBox.clear()
            # self.dlg.val_comboBox.addItems(result)
            
    # 테이블 초기화===================================================================================
            print('테이블 초기화')
            self.dlg.tableWidget.setColumnCount(2)
            self.dlg.tableWidget.setRowCount(0)
            table_column1=["추가" , "필드명"]
            self.dlg.tableWidget.setHorizontalHeaderLabels(table_column1)
            self.dlg.tableWidget.resizeColumnsToContents()
            self.chk1=0
            # self.add_values_toolbar.setDefaultAction(self.actions[0])
            self.dlg.tabWidget_2.setCurrentIndex(0)
            print('close')
            self.dlg.close()
        else:
            pass