import os
import socket
from PyQt5.QtCore import QSettings, QTimer
from PyQt5.QtWidgets import QAction, QMessageBox, QInputDialog
from PyQt5.QtGui import QIcon
from qgis.core import QgsApplication, QgsMessageLog, Qgis
from qgis.utils import iface

from .core.kk_network import KKNetworkManager
from .core.kk_indexer import KKIndexingEngine
from .core.kk_peer_manager import KKPeerManager
from .ui.kk_main_dialog import KKMainDialog

_plugin_instance = None

class KKPlugin:

    def __init__(self, iface):
        global _plugin_instance

        if _plugin_instance is not None:
            QMessageBox.information(
                iface.mainWindow(),
                "PIPI2 알림",
                "PIPI2 플러그인이 이미 실행 중입니다.\n다른 QGIS 창에서 실행 중인 PIPI2를 사용해주세요."
            )
            return

        if self._check_port_in_use():
            QMessageBox.warning(
                iface.mainWindow(),
                "PIPI2 경고",
                "PIPI2에서 사용하는 포트(45454, 45455)가 이미 사용 중입니다.\n"
                "다른 PIPI2 인스턴스가 실행 중이거나 다른 프로그램이 해당 포트를 사용하고 있습니다."
            )
            return
            
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.settings = QSettings()
        self._init_my_info()
        self.kk_peer_manager = KKPeerManager()
        self.kk_network = KKNetworkManager()
        self.kk_indexer = KKIndexingEngine()
        self.kk_dialog = None
        self.kk_action = None
        
        _plugin_instance = self
        
    def _check_port_in_use(self):
        ports = [45454, 45455]
        
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.bind(('', port))
                sock.close()
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.bind(('', port))
                sock.close()
                
            except OSError:
                return True
                
        return False

    def _init_my_info(self):
        self.kk_my_name = self.settings.value('PIPI/my_name', '')
        self.kk_my_ip = self.settings.value('PIPI/my_ip', '')
        
        if not self.kk_my_name or not self.kk_my_ip:
            self._setup_my_info()
            
    def _setup_my_info(self):
        name, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "설정",
            "이름:",
            text=self.kk_my_name
        )
        
        if ok and name:
            self.kk_my_name = name
            self.settings.setValue('PIPI/my_name', name)
            
        ip, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "설정", 
            "내 IP :\n(예: 10.206.111.0)",
            text=self.kk_my_ip
        )
        
        if ok and ip:
            self.kk_my_ip = ip
            self.settings.setValue('PIPI/my_ip', ip)

    def initGui(self):
        if not hasattr(self, 'kk_network'):
            return
            
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
        else:
            icon = QIcon()

        self.kk_action = QAction(icon, "삐삐2", self.iface.mainWindow())
        self.kk_action.triggered.connect(self.kk_show_dialog)
        self.kk_action.setShortcut("Ctrl+Shift+K")

        self.kk_settings_action = QAction("설정", self.iface.mainWindow())
        self.kk_settings_action.triggered.connect(self._setup_my_info)

        self.iface.addToolBarIcon(self.kk_action)
        self.iface.addPluginToMenu("삐삐2", self.kk_action)
        self.iface.addPluginToMenu("삐삐2", self.kk_settings_action)

        self.kk_network.set_my_ip(self.kk_my_ip)
        
        known_peer_ips = [ip for ip in self.kk_peer_manager.DEFAULT_PEERS.keys()]
        self.kk_network.set_known_peers(known_peer_ips)
        
        self.kk_network.start()
        
        QgsMessageLog.logMessage(
            f"시작 - {self.kk_my_name} ({self.kk_my_ip})", 
            'PIPI', 
            Qgis.Info
        )
        
        QTimer.singleShot(10000, self._initial_status_check)

    def _initial_status_check(self):
        QgsMessageLog.logMessage("초기 온라인 상태 확인 시작", 'PIPI', Qgis.Info)
        self.kk_network.kk_check_online_status()

    def unload(self):
        global _plugin_instance

        if not hasattr(self, 'kk_network'):
            _plugin_instance = None
            return
            
        if self.kk_dialog:
            self.kk_dialog.close()

        self.kk_network.stop()
        
        if hasattr(self, 'kk_action') and self.kk_action:
            self.iface.removeToolBarIcon(self.kk_action)
            self.iface.removePluginMenu("삐삐2", self.kk_action)
            
        if hasattr(self, 'kk_settings_action') and self.kk_settings_action:
            self.iface.removePluginMenu("삐삐2", self.kk_settings_action)

        _plugin_instance = None
        
        QgsMessageLog.logMessage("종료", 'PIPI', Qgis.Info)

    def kk_show_dialog(self):
        if not self.kk_my_name or not self.kk_my_ip:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "설정 필요",
                "먼저 사용자 정보를 설정해주세요"
            )
            self._setup_my_info()
            return
            
        if not self.kk_dialog:
            self.kk_dialog = KKMainDialog(self)

        self.kk_dialog.show()
        self.kk_dialog.raise_()
        self.kk_dialog.activateWindow()
        
        QTimer.singleShot(1000, self.kk_network.kk_check_online_status)