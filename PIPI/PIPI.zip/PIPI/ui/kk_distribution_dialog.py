from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                            QComboBox, QPushButton, QGroupBox,
                            QTableWidget, QTableWidgetItem, QHeaderView,
                            QDialogButtonBox, QMessageBox)
from PyQt5.QtCore import Qt, QDateTime, QDate
from PyQt5.QtGui import QFont
from qgis.core import QgsProject, QgsVectorLayer
import time
from ..core.kk_field_mapping import KKFieldMapping

class KKDistributionDialog(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.kk_selected_layer = None
        self.kk_selected_fields = []
        self.kk_key_field = None

        self.kk_init_ui()
        self.kk_load_layers()

    def kk_init_ui(self):
        self.setWindowTitle("📦 Distribution Settings")
        self.setMinimumSize(700, 600)
        
        default_font = QFont("현대하모니L", 10)
        self.setFont(default_font)

        layout = QVBoxLayout(self)

        layer_group = QGroupBox("1️⃣ Layer Selection")
        layer_layout = QVBoxLayout(layer_group)

        self.kk_layer_combo = QComboBox()
        self.kk_layer_combo.currentIndexChanged.connect(self.kk_on_layer_changed)
        layer_layout.addWidget(QLabel("Target Layer:"))
        layer_layout.addWidget(self.kk_layer_combo)

        self.kk_layer_info = QLabel("Please select a layer")
        self.kk_layer_info.setStyleSheet("QLabel { color: #666; padding: 5px; font-family: '현대하모니L'; }")
        layer_layout.addWidget(self.kk_layer_info)

        layout.addWidget(layer_group)

        key_group = QGroupBox("2️⃣ Key Field (Identifier)")
        key_layout = QVBoxLayout(key_group)

        self.kk_key_combo = QComboBox()
        key_layout.addWidget(self.kk_key_combo)
        key_layout.addWidget(QLabel("<small>💡 Generally use 'key' field</small>"))

        layout.addWidget(key_group)

        field_group = QGroupBox("3️⃣ Field Selection for Transfer")
        field_layout = QVBoxLayout(field_group)

        essential_label = QLabel(
            f"<b>Essential Fields:</b> {', '.join(KKFieldMapping.ESSENTIAL_FIELDS)}"
        )
        essential_label.setStyleSheet("""
            QLabel {
                background-color: #E3F2FD;
                padding: 8px;
                border-radius: 4px;
                color: #1976D2;
                font-family: '현대하모니L';
            }
        """)
        field_layout.addWidget(essential_label)

        btn_layout = QHBoxLayout()

        select_all_btn = QPushButton("Select All")
        select_all_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        select_all_btn.clicked.connect(self.kk_select_all_fields)

        select_none_btn = QPushButton("Select None")
        select_none_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        select_none_btn.clicked.connect(self.kk_select_no_fields)

        select_essential_btn = QPushButton("Essential Only")
        select_essential_btn.clicked.connect(self.kk_select_essential_fields)
        select_essential_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-family: '현대하모니L';
            }
        """)

        btn_layout.addWidget(select_all_btn)
        btn_layout.addWidget(select_none_btn)
        btn_layout.addWidget(select_essential_btn)
        btn_layout.addStretch()

        field_layout.addLayout(btn_layout)

        self.kk_field_table = QTableWidget()
        self.kk_field_table.setColumnCount(4)
        self.kk_field_table.setHorizontalHeaderLabels(['Select', 'Field Name', 'Type', 'Essential'])
        self.kk_field_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.kk_field_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.kk_field_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)

        field_layout.addWidget(self.kk_field_table)

        layout.addWidget(field_group)

        info_group = QGroupBox("4️⃣ Selection Summary")
        info_layout = QVBoxLayout(info_group)
        
        self.kk_selection_info = QLabel("Selected Objects: 0")
        self.kk_selection_info.setStyleSheet("QLabel { font-size: 14px; font-weight: bold; font-family: '현대하모니L'; }")
        info_layout.addWidget(self.kk_selection_info)
        
        self.kk_field_info = QLabel("Selected Fields: 0")
        info_layout.addWidget(self.kk_field_info)
        
        layout.addWidget(info_group)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.kk_validate_and_accept)
        button_box.rejected.connect(self.reject)

        layout.addWidget(button_box)

        self.KK_ESSENTIAL_FIELDS = KKFieldMapping.ESSENTIAL_FIELDS

    def kk_load_layers(self):
        self.kk_layer_combo.clear()

        ing_layers = []
        other_layers = []

        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'ING' in layer.name():
                    ing_layers.append((layer.name(), layer.id()))
                else:
                    other_layers.append((layer.name(), layer.id()))

        for name, layer_id in sorted(ing_layers):
            self.kk_layer_combo.addItem(f"⭐ {name}", layer_id)

        if ing_layers and other_layers:
            self.kk_layer_combo.insertSeparator(len(ing_layers))

        for name, layer_id in sorted(other_layers):
            self.kk_layer_combo.addItem(name, layer_id)

    def kk_on_layer_changed(self, index):
        if index < 0:
            return

        layer_id = self.kk_layer_combo.currentData()
        self.kk_selected_layer = QgsProject.instance().mapLayer(layer_id)

        if not self.kk_selected_layer:
            return

        selected_count = self.kk_selected_layer.selectedFeatureCount()
        total_count = self.kk_selected_layer.featureCount()
        
        self.kk_layer_info.setText(
            f"📊 전체: {total_count:,}개 / 선택: {selected_count:,}개"
        )
        self.kk_selection_info.setText(f"Selected Objects: {selected_count:,}")

        self.kk_update_fields()
        self.kk_update_field_count()

    def kk_update_fields(self):
        if not self.kk_selected_layer:
            return

        self.kk_key_combo.clear()

        self.kk_field_table.setRowCount(0)

        fields = self.kk_selected_layer.fields()
        for i, field in enumerate(fields):
            self.kk_field_table.insertRow(i)

            check_item = QTableWidgetItem()
            check_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)

            is_essential = field.name() in self.KK_ESSENTIAL_FIELDS
            if is_essential:
                check_item.setCheckState(Qt.Checked)
            else:
                check_item.setCheckState(Qt.Unchecked)

            self.kk_field_table.setItem(i, 0, check_item)

            name_item = QTableWidgetItem(field.name())
            if is_essential:
                font = QFont("현대하모니L", -1, QFont.Bold)
                name_item.setFont(font)
            self.kk_field_table.setItem(i, 1, name_item)

            self.kk_field_table.setItem(i, 2, QTableWidgetItem(field.typeName()))

            essential_item = QTableWidgetItem("✓" if is_essential else "")
            essential_item.setTextAlignment(Qt.AlignCenter)
            if is_essential:
                essential_item.setForeground(Qt.green)
            self.kk_field_table.setItem(i, 3, essential_item)

            self.kk_key_combo.addItem(field.name())

        for i in range(self.kk_key_combo.count()):
            if self.kk_key_combo.itemText(i).lower() == 'key':
                self.kk_key_combo.setCurrentIndex(i)
                break

    def kk_select_all_fields(self):
        for i in range(self.kk_field_table.rowCount()):
            self.kk_field_table.item(i, 0).setCheckState(Qt.Checked)
        self.kk_update_field_count()

    def kk_select_no_fields(self):
        for i in range(self.kk_field_table.rowCount()):
            self.kk_field_table.item(i, 0).setCheckState(Qt.Unchecked)
        self.kk_update_field_count()

    def kk_select_essential_fields(self):
        for i in range(self.kk_field_table.rowCount()):
            field_name = self.kk_field_table.item(i, 1).text()
            if field_name in self.KK_ESSENTIAL_FIELDS:
                self.kk_field_table.item(i, 0).setCheckState(Qt.Checked)
            else:
                self.kk_field_table.item(i, 0).setCheckState(Qt.Unchecked)
        self.kk_update_field_count()

    def kk_update_field_count(self):
        count = 0
        for i in range(self.kk_field_table.rowCount()):
            if self.kk_field_table.item(i, 0).checkState() == Qt.Checked:
                count += 1
        self.kk_field_info.setText(f"Selected Fields: {count}")

    def kk_validate_and_accept(self):
        if not self.kk_selected_layer:
            QMessageBox.warning(self, "Warning", "Please select a layer")
            return

        if self.kk_selected_layer.selectedFeatureCount() == 0:
            QMessageBox.warning(self, "Warning", "No objects selected")
            return

        self.kk_key_field = self.kk_key_combo.currentText()
        if not self.kk_key_field:
            QMessageBox.warning(self, "Warning", "Please select Key field")
            return

        self.kk_selected_fields = []
        for i in range(self.kk_field_table.rowCount()):
            if self.kk_field_table.item(i, 0).checkState() == Qt.Checked:
                self.kk_selected_fields.append(self.kk_field_table.item(i, 1).text())

        if not self.kk_selected_fields:
            QMessageBox.warning(self, "Warning", "Please select at least one field")
            return

        missing_essential = []
        for field in self.KK_ESSENTIAL_FIELDS:
            if field not in self.kk_selected_fields and field in [f.name() for f in self.kk_selected_layer.fields()]:
                missing_essential.append(field)

        if missing_essential:
            reply = QMessageBox.question(
                self, 
                "Missing Essential Fields",
                f"Following essential fields are not selected:\n{', '.join(missing_essential)}\n\nContinue?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return

        if self.kk_key_field not in self.kk_selected_fields:
            self.kk_selected_fields.append(self.kk_key_field)

        self.accept()

    def kk_get_distribution_data(self):
        if not self.kk_selected_layer:
            return None

        keys = []
        data = []

        for feature in self.kk_selected_layer.selectedFeatures():
            key = str(feature[self.kk_key_field])
            keys.append(key)

            feature_data = {}
            for field in self.kk_selected_fields:
                value = feature[field]
                formatted_value = KKFieldMapping.format_value(field, value)
                feature_data[field] = formatted_value

            data.append(feature_data)

        return {
            'layer_name': self.kk_selected_layer.name(),
            'key_field': self.kk_key_field,
            'fields': self.kk_selected_fields,
            'keys': keys,
            'data': data,
            'timestamp': time.time()
        }