from PyQt5.QtWidgets import (QListWidget, QListWidgetItem, QWidget, QVBoxLayout, QLabel, 
                            QHBoxLayout, QSizePolicy, QTextEdit, QDialog, QPushButton,
                            QScrollArea, QApplication, QMessageBox)
from PyQt5.QtCore import Qt, QByteArray, QBuffer, QIODevice, QSize, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QPixmap, QCursor
from datetime import datetime
import base64
import os

class KKClickableImageLabel(QLabel):
    clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.setToolTip("클릭하면 이미지를 확대할 수 있습니다\n\n확대 뷰어에서:\n- Ctrl + 마우스 휠: 확대/축소\n- +/-: 확대/축소\n- 0: 원본 크기\n- Ctrl+S: 저장\n- ESC: 닫기")
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

class KKImageViewerDialog(QDialog):
    
    def __init__(self, pixmap, parent=None):
        super().__init__(parent)
        self.original_pixmap = pixmap
        self.current_scale = 1.0
        self.kk_setup_ui()
        
    def kk_setup_ui(self):
        self.setWindowTitle("이미지 뷰어")
        self.setModal(True)
        
        self.resize(300, 300)
        
        default_font = QFont("현대하모니L", 10)
        self.setFont(default_font)
        
        layout = QVBoxLayout(self)
        
        button_layout = QHBoxLayout()
        
        self.zoom_in_btn = QPushButton("🔍+ 확대")
        self.zoom_in_btn.clicked.connect(self.kk_zoom_in)
        self.zoom_in_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 16px;
                background: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                font-family: '현대하모니L';
                font-weight: bold;
            }
            QPushButton:hover {
                background: #45a049;
            }
        """)
        
        self.zoom_out_btn = QPushButton("🔍- 축소")
        self.zoom_out_btn.clicked.connect(self.kk_zoom_out)
        self.zoom_out_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 16px;
                background: #FF9800;
                color: white;
                border: none;
                border-radius: 4px;
                font-family: '현대하모니L';
                font-weight: bold;
            }
            QPushButton:hover {
                background: #F57C00;
            }
        """)
        
        self.actual_size_btn = QPushButton("📏 원본크기")
        self.actual_size_btn.clicked.connect(self.kk_actual_size)
        self.actual_size_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 16px;
                background: #2196F3;
                color: white;
                border: none;
                border-radius: 4px;
                font-family: '현대하모니L';
                font-weight: bold;
            }
            QPushButton:hover {
                background: #1976D2;
            }
        """)
        
        
        self.close_btn = QPushButton("❌ 닫기")
        self.close_btn.clicked.connect(self.close)
        self.close_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 16px;
                background: #F44336;
                color: white;
                border: none;
                border-radius: 4px;
                font-family: '현대하모니L';
                font-weight: bold;
            }
            QPushButton:hover {
                background: #D32F2F;
            }
        """)
        
        button_layout.addWidget(self.zoom_in_btn)
        button_layout.addWidget(self.zoom_out_btn)
        button_layout.addWidget(self.actual_size_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.close_btn)
        
        layout.addLayout(button_layout)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setAlignment(Qt.AlignCenter)
        
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("background-color: white; border: 1px solid #ddd;")
        
        self.scroll_area.setWidget(self.image_label)
        layout.addWidget(self.scroll_area)

        self.kk_update_image()

        self.setFocusPolicy(Qt.StrongFocus)
        
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Plus or event.key() == Qt.Key_Equal:
            self.kk_zoom_in()
        elif event.key() == Qt.Key_Minus:
            self.kk_zoom_out()
        elif event.key() == Qt.Key_0:
            self.kk_actual_size()
        elif event.key() == Qt.Key_S and event.modifiers() & Qt.ControlModifier:
            self.kk_save_image()
        elif event.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)
        
    def kk_update_image(self):
        if self.original_pixmap and not self.original_pixmap.isNull():
            scaled_size = self.original_pixmap.size() * self.current_scale
            scaled_pixmap = self.original_pixmap.scaled(
                scaled_size, 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            self.image_label.setPixmap(scaled_pixmap)
            self.image_label.resize(scaled_pixmap.size())
            
    def kk_zoom_in(self):
        self.current_scale = min(self.current_scale * 1.25, 5.0)
        self.kk_update_image()
        
    def kk_zoom_out(self):
        self.current_scale = max(self.current_scale / 1.25, 0.1)
        self.kk_update_image()
        
    def kk_actual_size(self):
        self.current_scale = 1.0
        self.kk_update_image()
        
    def wheelEvent(self, event):
        if event.modifiers() & Qt.ControlModifier:
            if event.angleDelta().y() > 0:
                self.kk_zoom_in()
            else:
                self.kk_zoom_out()
            event.accept()
        else:
            super().wheelEvent(event)

class KKMessageBubble(QWidget):
    def __init__(self, sender, message, timestamp=None, is_mine=False, image_data=None, parent=None):
        super().__init__(parent)
        self.is_mine = is_mine
        self.image_data = image_data
        self.kk_setup_ui(sender, message, timestamp)
        
    def kk_setup_ui(self, sender, message, timestamp):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        bubble = QWidget()
        bubble.setObjectName("messageBubble")
        
        if self.is_mine:
            bg_color = "#DCF0FF" 
            bubble.setStyleSheet(f"#messageBubble {{ background-color: {bg_color}; border-radius: 15px; padding: 12px; margin: 2px; }}")
        else:
            bg_color = "#F5F5F5"  
            bubble.setStyleSheet(f"#messageBubble {{ background-color: {bg_color}; border-radius: 15px; padding: 12px; margin: 2px; }}")
            
        if "[분배" in message:
            bg_color = "#FFF3CD"  
            bubble.setStyleSheet(f"#messageBubble {{ background-color: {bg_color}; border-radius: 15px; padding: 12px; margin: 2px; border: 2px solid #FFC107; }}")
        elif "[LAS]" in message:
            bg_color = "#F8D7DA"  
            bubble.setStyleSheet(f"#messageBubble {{ background-color: {bg_color}; border-radius: 15px; padding: 12px; margin: 2px; border: 2px solid #DC3545; }}")
            
        bubble_layout = QVBoxLayout(bubble)
        bubble_layout.setSpacing(8)
        
        header_layout = QHBoxLayout()
        
        sender_label = QLabel(sender)
        font = QFont()
        font.setBold(True)
        font.setFamily("현대하모니L")
        font.setPointSize(10)
        sender_label.setFont(font)
        
        if timestamp:
            if isinstance(timestamp, float):
                time_str = datetime.fromtimestamp(timestamp).strftime("%H:%M")
            else:
                time_str = timestamp.strftime("%H:%M")
        else:
            time_str = datetime.now().strftime("%H:%M")
            
        time_label = QLabel(time_str)
        time_label.setStyleSheet("color: #757575; font-size: 9px; font-family: '현대하모니L';")
        time_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        
        if self.is_mine:
            header_layout.addStretch()
            header_layout.addWidget(time_label)
            header_layout.addWidget(sender_label)
        else:
            header_layout.addWidget(sender_label)
            header_layout.addWidget(time_label)
            header_layout.addStretch()
            
        bubble_layout.addLayout(header_layout)
        
        if self.image_data:
            try:
                image_bytes = base64.b64decode(self.image_data)
                pixmap = QPixmap()
                pixmap.loadFromData(image_bytes)
                
                if not pixmap.isNull():
                    scaled_pixmap = pixmap.scaled(200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    image_label = KKClickableImageLabel()
                    image_label.setPixmap(scaled_pixmap)
                    image_label.setAlignment(Qt.AlignCenter)
                    image_label.setStyleSheet("""
                        border: 2px solid #4CAF50;
                        border-radius: 8px;
                        padding: 2px;
                        background-color: white;
                    """)
                    
                    image_label.setToolTip("클릭하면 이미지를 확대할 수 있습니다\n\n확대 뷰어에서:\n- Ctrl + 마우스 휠: 확대/축소\n- +/-: 확대/축소\n- 0: 원본 크기\n- Ctrl+S: 저장\n- ESC: 닫기")
                    image_label.setCursor(QCursor(Qt.PointingHandCursor))
                    
                    image_label.clicked.connect(lambda: self.kk_show_image_viewer(pixmap))
                    bubble_layout.addWidget(image_label)
            except Exception as e:
                print(f"이미지 로드 오류: {e}")
        
        message_text = QTextEdit()
        message_text.setPlainText(message)
        message_text.setReadOnly(True)
        message_text.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        message_text.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        doc_height = message_text.document().size().height()
        message_text.setFixedHeight(max(int(doc_height) + 10, 30))
        
        font = QFont()
        font.setFamily("현대하모니L")
        font.setPointSize(9)
        
        if "[분배" in message or "[LAS]" in message:
            font.setBold(True)
            
        message_text.setFont(font)
        message_text.setStyleSheet("""
            QTextEdit {
                background-color: transparent;
                border: none;
                padding: 0;
                font-family: '현대하모니L';
            }
        """)
        
        if self.is_mine:
            message_text.setAlignment(Qt.AlignRight)
        else:
            message_text.setAlignment(Qt.AlignLeft)
            
        bubble_layout.addWidget(message_text)
        
        item_layout = QHBoxLayout()
        item_layout.setContentsMargins(10, 5, 10, 5)
        
        if self.is_mine:
            item_layout.addStretch()
            item_layout.addWidget(bubble)
        else:
            item_layout.addWidget(bubble)
            item_layout.addStretch()
            
        main_layout.addLayout(item_layout)
        
    def sizeHint(self):
        parent_width = self.parentWidget().width() if self.parentWidget() else 600
        hint = super().sizeHint()
        hint.setWidth(min(int(parent_width * 0.8), 500))
        return hint
        
    def kk_show_image_viewer(self, pixmap):
        try:
            viewer = KKImageViewerDialog(pixmap, self)
            viewer.exec_()
        except Exception as e:
            print(f"이미지 뷰어 오류: {e}")
        

class KKChatWidget(QListWidget):

    def __init__(self):
        super().__init__()
        self.setVerticalScrollMode(QListWidget.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setSelectionMode(QListWidget.NoSelection)
        self.setFrameShape(QListWidget.NoFrame)
        self.setSpacing(5)
        self.setStyleSheet("""
            QListWidget {
                background-color: #FAFAFA;
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 5px;
                font-family: '현대하모니L';
            }
            QListWidget::item {
                padding: 2px;
                border: none;
                background-color: transparent;
            }
        """)
        
        self.model().rowsInserted.connect(self.kk_update_item_sizes)
        self.model().layoutChanged.connect(self.kk_update_item_sizes)
        
    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.kk_update_item_sizes()
        
    def kk_update_item_sizes(self):
        for i in range(self.count()):
            item = self.item(i)
            widget = self.itemWidget(item)
            if widget:
                item.setSizeHint(widget.sizeHint())

    def kk_add_message(self, sender, content, timestamp, is_mine, image_data=None):
        item = QListWidgetItem()
        
        bubble = KKMessageBubble(sender, content, timestamp, is_mine, image_data, self)
        
        item.setSizeHint(bubble.sizeHint())

        self.addItem(item)
        self.setItemWidget(item, bubble)
        
        self.scrollToBottom()

    def kk_clear(self):
        self.clear()