from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QSplitter,
                            QListWidget, QListWidgetItem, QLineEdit, QPushButton,
                            QLabel, QTextEdit, QTabWidget, QWidget, QMessageBox,
                            QMenu, QInputDialog, QComboBox, QGroupBox, QApplication,
                            QCheckBox, QSystemTrayIcon, QShortcut)
from PyQt5.QtCore import Qt, pyqtSignal, QTimer, QByteArray, QBuffer, QIODevice
from PyQt5.QtGui import QColor, QFont, QIcon, QPixmap, QKeySequence
import base64
import io
import os
from datetime import datetime
from qgis.core import QgsProject, QgsVectorLayer

from .kk_distribution_dialog import KKDistributionDialog
from .kk_manual_dialog import KKManualDialog
from .kk_chat_widget import KKChatWidget

class KKMainDialog(QDialog):
    
    def __init__(self, plugin):
        super().__init__(plugin.iface.mainWindow())
        self.kk_plugin = plugin
        self.kk_current_peer = None
        self.kk_message_buffers = {}
        self.kk_unread_messages = {} 
        self.kk_notification_pending = set()
        self.kk_connection_test_timer = None
        self.kk_testing_peer_ip = None
        
        plugin.kk_network.kk_message_received.connect(self.kk_on_message_received)
        plugin.kk_network.kk_distribution_received.connect(self.kk_on_distribution_received)
        plugin.kk_network.kk_las_received.connect(self.kk_on_las_received)
        plugin.kk_network.kk_peer_online.connect(self.kk_on_peer_online)
        
        plugin.kk_indexer.kk_indexing_complete.connect(self.kk_on_indexing_complete)
        plugin.kk_indexer.kk_indexing_error.connect(self.kk_on_indexing_error)
        
        self.kk_init_ui()
        self.kk_init_notifications()
        self.kk_init_shortcuts()
        self.kk_load_contacts()
        
    def kk_init_ui(self):
        self.setWindowTitle(f"PIPI2 - {self.kk_plugin.kk_my_name}")
        self.resize(900, 600)
        
        default_font = QFont("현대하모니L", 10)
        self.setFont(default_font)
        
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        
        layout = QVBoxLayout(self)
        
        top_layout = QHBoxLayout()
        
        
        self.kk_test_btn = QPushButton("🔧 연결 테스트")
        self.kk_test_btn.clicked.connect(self.kk_test_connection)
        self.kk_test_btn.setStyleSheet("""
            QPushButton {
                padding: 5px 10px;
                background: #2196F3;
                color: white;
                border-radius: 3px;
                font-family: '현대하모니L';
            }
        """)
        top_layout.addWidget(self.kk_test_btn)
        
        self.kk_my_name_btn = QPushButton(f"👤 {self.kk_plugin.kk_my_name}")
        self.kk_my_name_btn.clicked.connect(self.kk_change_my_name)
        self.kk_my_name_btn.setStyleSheet("""
            QPushButton {
                padding: 5px 10px;
                background: #FF9800;
                color: white;
                border-radius: 3px;
                font-family: '현대하모니L';
            }
        """)
        top_layout.addWidget(self.kk_my_name_btn)
        
        self.kk_shortcut_btn = QPushButton("⌨️ 단축키")
        self.kk_shortcut_btn.clicked.connect(self.kk_configure_shortcut)
        self.kk_shortcut_btn.setStyleSheet("""
            QPushButton {
                padding: 5px 10px;
                background: #9C27B0;
                color: white;
                border-radius: 3px;
                font-family: '현대하모니L';
            }
        """)
        top_layout.addWidget(self.kk_shortcut_btn)
        
        top_layout.addStretch()
        layout.addLayout(top_layout)
        
        self.kk_tabs = QTabWidget()
        self.kk_tabs.setStyleSheet("QTabWidget { font-family: '현대하모니L'; }")
        self.kk_tabs.setTabPosition(QTabWidget.North)
        
        self.kk_messaging_tab = self._kk_create_messaging_tab()
        self.kk_tabs.addTab(self.kk_messaging_tab, "💬 메세지")
        
        self.kk_distribution_tab = self._kk_create_distribution_tab()
        self.kk_tabs.addTab(self.kk_distribution_tab, "📦 분배")
        
        self.kk_las_tab = self._kk_create_las_tab()
        self.kk_tabs.addTab(self.kk_las_tab, "⚠️ 작업불가")
        
        self.kk_manual_tab = KKManualDialog(self.kk_plugin)
        self.kk_tabs.addTab(self.kk_manual_tab, "🔧 수동")
        
        layout.addWidget(self.kk_tabs)
        
        self.kk_status_label = QLabel("Ready")
        self.kk_status_label.setStyleSheet("QLabel { padding: 5px; background: #f0f0f0; font-family: '현대하모니L'; }")
        layout.addWidget(self.kk_status_label)
        
    def _kk_create_messaging_tab(self):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        
        splitter = QSplitter(Qt.Horizontal)
        
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(5, 5, 5, 5)
        
        
        self.kk_contact_list = QListWidget()
        self.kk_contact_list.setStyleSheet("""
            QListWidget {
                font-family: '현대하모니L';
                font-size: 11px;
            }
            QListWidget::item {
                padding: 6px;
                font-size: 11px;
            }
        """)
        self.kk_contact_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.kk_contact_list.customContextMenuRequested.connect(self.kk_show_contact_menu)
        self.kk_contact_list.currentTextChanged.connect(self.kk_on_contact_selected)
        left_layout.addWidget(self.kk_contact_list)
        
        splitter.addWidget(left_widget)
        
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(5, 5, 5, 5)
        
        self.kk_chat_header = QLabel("대화 상대를 선택하세요")
        self.kk_chat_header.setStyleSheet("""
            QLabel {
                font-weight: bold;
                font-size: 14px;
                padding: 10px;
                background: #e3f2fd;
                border-radius: 5px;
                font-family: '현대하모니L';
            }
        """)
        right_layout.addWidget(self.kk_chat_header)
        
        self.kk_chat_widget = KKChatWidget()
        right_layout.addWidget(self.kk_chat_widget)
        
        input_layout = QHBoxLayout()
        
        self.kk_message_input = QLineEdit()
        self.kk_message_input.setPlaceholderText("메시지를 입력하세요...")
        self.kk_message_input.returnPressed.connect(self.kk_send_message)
        self.kk_message_input.setStyleSheet("""
            QLineEdit {
                padding: 8px;
                font-size: 13px;
                border: 1px solid #ccc;
                border-radius: 3px;
                font-family: '현대하모니L';
            }
        """)
        
        self.kk_paste_image_btn = QPushButton("📷")
        self.kk_paste_image_btn.clicked.connect(self.kk_paste_clipboard_image)
        self.kk_paste_image_btn.setToolTip("클립보드의 스크린샷 붙여넣기")
        self.kk_paste_image_btn.setFixedSize(35, 35)
        self.kk_paste_image_btn.setStyleSheet("""
            QPushButton {
                padding: 5px;
                background: #4CAF50;
                color: white;
                border-radius: 3px;
                font-size: 16px;
                font-family: '현대하모니L';
            }
            QPushButton:hover {
                background: #45a049;
            }
        """)
        
        
        self.kk_send_btn = QPushButton("전송")
        self.kk_send_btn.clicked.connect(self.kk_send_message)
        self.kk_send_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 15px;
                background: #2196F3;
                color: white;
                border: none;
                border-radius: 3px;
                font-weight: bold;
                font-family: '현대하모니L';
            }
            QPushButton:hover {
                background: #1976D2;
            }
        """)
        
        input_layout.addWidget(self.kk_message_input)
        input_layout.addWidget(self.kk_paste_image_btn)
        input_layout.addWidget(self.kk_send_btn)
        
        right_layout.addLayout(input_layout)
        
        splitter.addWidget(right_widget)
        splitter.setSizes([250, 650])
        
        layout.addWidget(splitter)
        
        return widget
        
    def _kk_create_distribution_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        is_authorized = self.kk_plugin.kk_my_ip == '10.206.111.16'
        
        if not is_authorized:
            no_permission_label = QLabel("""
            <h3>⛔ 권한 없음</h3>
            """.format(self.kk_plugin.kk_my_name))
            no_permission_label.setStyleSheet("""
                QLabel {
                    background-color: #ffebee;
                    padding: 20px;
                    border-radius: 5px;
                    color: #c62828;
                }
            """)
            layout.addWidget(no_permission_label)
            layout.addStretch()
        else:
            auth_label = QLabel("✅ 분배 권한이 있습니다")
            auth_label.setStyleSheet("""
                QLabel {
                    background-color: #e8f5e9;
                    padding: 10px;
                    border-radius: 5px;
                    color: #2e7d32;
                    font-weight: bold;
                }
            """)
            layout.addWidget(auth_label)
            
            dist_group = QGroupBox("분배")
            dist_layout = QVBoxLayout(dist_group)
            
            target_layout = QHBoxLayout()
            target_layout.addWidget(QLabel("받는 사람:"))
            
            self.kk_dist_target_combo = QComboBox()
            self.kk_dist_target_combo.setMinimumWidth(200)
            target_layout.addWidget(self.kk_dist_target_combo)
            
            target_layout.addStretch()
            dist_layout.addLayout(target_layout)
            
            dist_btn = QPushButton("📦 분배 설정")
            dist_btn.clicked.connect(self.kk_show_distribution_dialog)
            dist_btn.setStyleSheet("""
                QPushButton {
                    background: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    font-size: 14px;
                    font-weight: bold;
                    border-radius: 5px;
                    font-family: '현대하모니L';
                }
                QPushButton:hover {
                    background: #45a049;
                }
            """)
            dist_layout.addWidget(dist_btn)
            
            layout.addWidget(dist_group)
            layout.addStretch()
        
        return widget
        
    def _kk_create_las_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        las_group = QGroupBox("작업불가 지점 전송")
        las_layout = QVBoxLayout(las_group)
        
        info_label = QLabel(
            "선택한 피처를 작업불가(LAS) 지점으로 표시하여 전송합니다.\n"
            "받는 사람은 해당 피처가 자동으로 선택됩니다."
        )
        info_label.setStyleSheet("QLabel { color: #666; padding: 10px; font-family: '현대하모니L'; }")
        las_layout.addWidget(info_label)
        
        target_layout = QHBoxLayout()
        target_layout.addWidget(QLabel("받는 사람:"))
        
        self.kk_las_target_combo = QComboBox()
        self.kk_las_target_combo.setMinimumWidth(200)
        target_layout.addWidget(self.kk_las_target_combo)
        
        target_layout.addStretch()
        las_layout.addLayout(target_layout)
        
        las_btn = QPushButton("⚠️ 전송")
        las_btn.clicked.connect(self.kk_send_las)
        las_btn.setStyleSheet("""
            QPushButton {
                background: #f44336;
                color: white;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
                border-radius: 5px;
                font-family: '현대하모니L';
            }
            QPushButton:hover {
                background: #d32f2f;
            }
        """)
        las_layout.addWidget(las_btn)
        
        layout.addWidget(las_group)
        layout.addStretch()
        
        return widget
        
    def kk_load_contacts(self):
        self.kk_contact_list.clear()
        
        peers = self.kk_plugin.kk_peer_manager.get_peer_list(
            exclude_ip=self.kk_plugin.kk_my_ip
        )
        
        online_count = 0
        
        for peer in peers:
            display_text = peer['display_name']
            item = QListWidgetItem(display_text)
            item.setData(Qt.UserRole, peer)

            unread_count = self.kk_unread_messages.get(peer['ip'], 0)
            
            if unread_count > 0:
                item.setBackground(QColor(255, 255, 200))
                item.setToolTip(f"온라인 - {unread_count}개의 새 메시지")
                item.setText(f"{display_text} ({unread_count})")
                font = item.font()
                font.setBold(True)
                item.setFont(font)
            else:
                item.setBackground(QColor(220, 255, 220))
                item.setToolTip("온라인")
                font = item.font()
                font.setBold(False)
                item.setFont(font)
            
            online_count += 1
                
            self.kk_contact_list.addItem(item)
            
            if peer['ip'] not in self.kk_message_buffers:
                self.kk_message_buffers[peer['ip']] = []
                

        self.kk_update_combo_boxes()
        
    def kk_update_combo_boxes(self):
        if hasattr(self, 'kk_dist_target_combo'):
            self.kk_dist_target_combo.clear()
            
        self.kk_las_target_combo.clear()
        
        peers = self.kk_plugin.kk_peer_manager.get_peer_list(
            exclude_ip=self.kk_plugin.kk_my_ip
        )
        
        for peer in peers:
            display_text = peer['display_name']
            
            if hasattr(self, 'kk_dist_target_combo'):
                self.kk_dist_target_combo.addItem(display_text, peer)
            self.kk_las_target_combo.addItem(display_text, peer)
                
    def kk_show_contact_menu(self, pos):
        item = self.kk_contact_list.itemAt(pos)
        if not item:
            return
            
        peer = item.data(Qt.UserRole)
        menu = QMenu(self)
        
        nick_action = menu.addAction("📝 별명 설정")
        nick_action.triggered.connect(lambda: self.kk_set_nickname(peer))
        
        menu.exec_(self.kk_contact_list.mapToGlobal(pos))
        
    def kk_set_nickname(self, peer):
        current_name = self.kk_plugin.kk_peer_manager.get_display_name(peer['ip'])
        nickname, ok = QInputDialog.getText(
            self, 
            "별명 설정",
            f"{peer['name']} ({peer['ip']})의 별명:",
            text=current_name if current_name != peer['name'] else ""
        )
        
        if ok:
            self.kk_plugin.kk_peer_manager.set_nickname(peer['ip'], nickname)
            self.kk_load_contacts()
            
    def kk_on_contact_selected(self, text):
        if not text:
            return
            
        current_item = self.kk_contact_list.currentItem()
        if not current_item:
            return
            
        self.kk_current_peer = current_item.data(Qt.UserRole)
        
        self.kk_mark_messages_as_read(self.kk_current_peer['ip'])
        
        self.kk_chat_header.setText(
            f"🟢 {self.kk_current_peer['display_name']}나오라"
        )
        
        self.kk_update_chat_view()
        
    def kk_update_chat_view(self):
        if not self.kk_current_peer:
            return
            
        self.kk_chat_widget.kk_clear()
        
        messages = self.kk_message_buffers.get(self.kk_current_peer['ip'], [])
        for msg in messages[-100:]: 
            self.kk_chat_widget.kk_add_message(
                msg['sender'],
                msg['content'],
                msg['timestamp'],
                msg['is_mine'],
                msg.get('image_data')
            )
            
    def kk_send_message(self):
        if not self.kk_current_peer or not self.kk_message_input.text():
            return
            
        message = self.kk_message_input.text()
        
        success = self.kk_plugin.kk_network.kk_send_message(
            self.kk_current_peer['ip'],
            message,
            self.kk_plugin.kk_my_name
        )
        
        self.kk_message_buffers[self.kk_current_peer['ip']].append({
            'sender': self.kk_plugin.kk_my_name,
            'content': message,
            'timestamp': datetime.now(),
            'is_mine': True,
            'image_data': None
        })

        if len(self.kk_message_buffers[self.kk_current_peer['ip']]) > 200:
            self.kk_message_buffers[self.kk_current_peer['ip']] = self.kk_message_buffers[self.kk_current_peer['ip']][-200:]
        
        self.kk_message_input.clear()
        self.kk_update_chat_view()
        self.kk_status_label.setText(f"메시지 전송: {self.kk_current_peer['display_name']}")
            
    def kk_show_distribution_dialog(self):
        if self.kk_plugin.kk_my_ip != '10.206.111.16':
            QMessageBox.critical(self, "권한 없음")
            return
            
        target_peer = self.kk_dist_target_combo.currentData()
        if not target_peer:
            QMessageBox.warning(self, "경고", "받는 사람을 선택하세요")
            return
            
        dialog = KKDistributionDialog(self)
        if dialog.exec_():
            dist_data = dialog.kk_get_distribution_data()
            
            self.kk_plugin.kk_network.kk_send_distribution(
                target_peer['ip'],
                dist_data
            )
            
            doyeop_stats = self._calculate_doyeop_stats(dist_data)
            total_length = sum(stats['length'] for stats in doyeop_stats.values())
            
            if len(doyeop_stats) == 1:
                doyeop = list(doyeop_stats.keys())[0]
                status_text = f"분배 완료: {doyeop} 도엽 {total_length:.2f}km → {target_peer['display_name']}"
            else:
                status_text = f"분배 완료: {len(doyeop_stats)}개 도엽 {total_length:.2f}km → {target_peer['display_name']}"
                
            if hasattr(self, 'kk_status_label'):
                self.kk_status_label.setText(status_text)
            
    def kk_send_las(self):
        target_peer = self.kk_las_target_combo.currentData()
        if not target_peer:
            QMessageBox.warning(self, "경고", "받는 사람을 선택하세요")
            return
            
        layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount() > 0:
                layer = lyr
                break
                
        if not layer:
            QMessageBox.warning(self, "경고", "선택된 피처가 없습니다")
            return
            
        keys = []
        for feature in layer.selectedFeatures():
            keys.append(str(feature['key']))
            
        las_data = {
            'keys': keys,
            'layer_name': layer.name()
        }
        
        self.kk_plugin.kk_network.kk_send_las(
            target_peer['ip'],
            las_data
        )
        
        if hasattr(self, 'kk_status_label'):
            self.kk_status_label.setText(
                f"LAS 전송: {len(keys)}개 → {target_peer['display_name']}"
            )
        
    def kk_on_message_received(self, sender_ip, message, sender_name=None, image_data=None):
        if not sender_name:
            sender_name = self.kk_plugin.kk_peer_manager.get_display_name(sender_ip)
        
        if message.startswith("[연결테스트]"):
            response_message = f"[연결확인] {datetime.now().strftime('%H:%M:%S')}"
            self.kk_plugin.kk_network.kk_send_message(
                sender_ip,
                response_message,
                self.kk_plugin.kk_my_name,
                None
            )
            if hasattr(self, 'kk_status_label'):
                self.kk_status_label.setText(f"연결테스트 수신 및 응답: {sender_name}")
            return

        if message.startswith("[연결확인]"):
            if self.kk_testing_peer_ip == sender_ip:
                if self.kk_connection_test_timer and self.kk_connection_test_timer.isActive():
                    self.kk_connection_test_timer.stop()
                
                self.kk_testing_peer_ip = None
                
                if hasattr(self, 'kk_status_label'):
                    self.kk_status_label.setText(f"✅ 연결 성공: {sender_name}")
            return
        
        if sender_ip not in self.kk_message_buffers:
            self.kk_message_buffers[sender_ip] = []
            
        self.kk_message_buffers[sender_ip].append({
            'sender': sender_name,
            'content': message,
            'timestamp': datetime.now(),
            'is_mine': False,
            'image_data': image_data
        })
        
        if len(self.kk_message_buffers[sender_ip]) > 200:
            self.kk_message_buffers[sender_ip] = self.kk_message_buffers[sender_ip][-200:]
        
        if sender_ip not in self.kk_unread_messages:
            self.kk_unread_messages[sender_ip] = 0
        self.kk_unread_messages[sender_ip] += 1
        self.kk_check_unread_messages()
        
        print(f"DEBUG: 알림 조건 체크 - current_peer: {self.kk_current_peer is not None}, sender_ip: {sender_ip}, isHidden: {self.isHidden()}")
        
        if not self.kk_current_peer or self.kk_current_peer['ip'] != sender_ip or self.isHidden():
            self.kk_show_notification(sender_name, message, sender_ip)
        else:
            print("DEBUG: 알림 조건에 맞지 않아 알림 표시하지 않음")
        
        if self.kk_current_peer and self.kk_current_peer['ip'] == sender_ip:
            self.kk_mark_messages_as_read(sender_ip)
            self.kk_update_chat_view()
        else:
            self.kk_load_contacts()
            if hasattr(self, 'kk_status_label'):
                self.kk_status_label.setText(f"새 메시지: {sender_name}")
            
    def kk_on_distribution_received(self, sender_ip, dist_data):
        sender_name = self.kk_plugin.kk_peer_manager.get_display_name(sender_ip)
        
        doyeop_stats = self._calculate_doyeop_stats(dist_data)
        
        message_lines = ["새로운 구간이 분배되었습니다.", "업데이트 하시겠습니까?", ""]
        message_lines.append(f"보낸 사람: {sender_name}")
        message_lines.append("")
        message_lines.append("도엽별 작업량:")
        
        total_length = 0
        for doyeop, stats in sorted(doyeop_stats.items()):
            message_lines.append(f"  {doyeop} 도엽: {stats['length']:.2f} km ({stats['count']}개)")
            total_length += stats['length']
        
        message_lines.append("")
        message_lines.append(f"전체: {total_length:.2f} km")
        
        reply = QMessageBox.question(
            self,
            "분배 수신",
            "\n".join(message_lines),
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            try:
                if hasattr(self, 'kk_status_label'):
                    self.kk_status_label.setText("업데이트 진행 중...")
                QApplication.processEvents()

                self.kk_plugin.kk_indexer.kk_process_distribution(
                    dist_data,
                    self.kk_plugin.kk_my_name
                )
                
                doyeop_list = list(doyeop_stats.keys())
                if len(doyeop_list) == 1:
                    ack_message = f"[수신확인] {doyeop_list[0]} 도엽 {total_length:.2f}km 업데이트 완료"
                else:
                    ack_message = f"[수신확인] {len(doyeop_list)}개 도엽 {total_length:.2f}km 업데이트 완료"
                    
                self.kk_plugin.kk_network.kk_send_message(sender_ip, ack_message, self.kk_plugin.kk_my_name, None)
                
                if sender_ip not in self.kk_message_buffers:
                    self.kk_message_buffers[sender_ip] = []
                    
                if len(doyeop_list) == 1:
                    receive_message = f"[분배 수신] {doyeop_list[0]} 도엽 {total_length:.2f}km"
                else:
                    receive_message = f"[분배 수신] {len(doyeop_list)}개 도엽 {total_length:.2f}km"
                    
                self.kk_message_buffers[sender_ip].append({
                    'sender': sender_name,
                    'content': receive_message,
                    'timestamp': datetime.now(),
                    'is_mine': False,
                    'image_data': None
                })
                
                self.kk_message_buffers[sender_ip].append({
                    'sender': self.kk_plugin.kk_my_name,
                    'content': ack_message,
                    'timestamp': datetime.now(),
                    'is_mine': True,
                    'image_data': None
                })
                
                if len(self.kk_message_buffers[sender_ip]) > 200:
                    self.kk_message_buffers[sender_ip] = self.kk_message_buffers[sender_ip][-200:]
                
                if sender_ip not in self.kk_unread_messages:
                    self.kk_unread_messages[sender_ip] = 0
                self.kk_unread_messages[sender_ip] += 1
                
                if not self.kk_current_peer or self.kk_current_peer['ip'] != sender_ip or self.isHidden():
                    self.kk_show_notification(sender_name, f"분배 수신: {receive_message}", sender_ip)
                
                if self.kk_current_peer and self.kk_current_peer['ip'] == sender_ip:
                    self.kk_mark_messages_as_read(sender_ip)
                    self.kk_update_chat_view()
                else:
                    self.kk_load_contacts()
                    
                if hasattr(self, 'kk_status_label'):
                    self.kk_status_label.setText(f"업데이트 완료: {total_length:.2f}km")
                
            except Exception as e:
                error_message = f"[오류] 분배 처리 실패: {str(e)}"
                self.kk_plugin.kk_network.kk_send_message(sender_ip, error_message, self.kk_plugin.kk_my_name, None)
                if hasattr(self, 'kk_status_label'):
                    self.kk_status_label.setText(f"업데이트 오류: {str(e)}")
                QMessageBox.critical(self, "오류", f"업데이트 중 오류가 발생했습니다:\n{str(e)}")
        else:
            reject_message = "[거절] 분배를 거절했습니다"
            self.kk_plugin.kk_network.kk_send_message(sender_ip, reject_message, self.kk_plugin.kk_my_name, None)
            
            if sender_ip not in self.kk_message_buffers:
                self.kk_message_buffers[sender_ip] = []
                
            self.kk_message_buffers[sender_ip].append({
                'sender': sender_name,
                'content': f"[분배 수신] {len(dist_data['keys'])}개 작업 (거절됨)",
                'timestamp': datetime.now(),
                'is_mine': False,
                'image_data': None
            })
            
            if self.kk_current_peer and self.kk_current_peer['ip'] == sender_ip:
                self.kk_update_chat_view()
                
            if hasattr(self, 'kk_status_label'):
                self.kk_status_label.setText("분배 거절됨")
            
    def kk_on_las_received(self, sender_ip, las_data):
        sender_name = self.kk_plugin.kk_peer_manager.get_display_name(sender_ip)
        
        target_layer_name = las_data.get('layer_name', 'ING')
        layer = None
        
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and lyr.name() == target_layer_name:
                layer = lyr
                break
                
        if not layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsVectorLayer) and 'ING' in lyr.name():
                    layer = lyr
                    break
                    
        if not layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsVectorLayer):
                    layer = lyr
                    break
                    
        if not layer:
            QMessageBox.warning(
                self,
                "오류", 
                f"작업불가 지점을 표시할 레이어를 찾을 수 없습니다.\n대상 레이어: {target_layer_name}"
            )
            return
            
        feature_ids = []
        selected_features = []
        
        for feature in layer.getFeatures():
            feature_key = str(feature.attribute('key'))
            if feature_key in las_data['keys']:
                feature_ids.append(feature.id())
                selected_features.append(feature)
                print(f"DEBUG: LAS 피처 선택 - Key: {feature_key}, ID: {feature.id()}")
                
        if feature_ids:
            layer.selectByIds(feature_ids)
            
            if selected_features:
                from qgis.core import QgsGeometry
                geometries = [feature.geometry() for feature in selected_features]
                
                if geometries:
                    combined_geom = QgsGeometry.unaryUnion(geometries)
                    bbox = combined_geom.boundingBox()
                    
                    bbox_buffered = bbox.buffered(
                        max(bbox.width(), bbox.height()) * 0.1
                    )

                    canvas = self.kk_plugin.iface.mapCanvas()
                    canvas.setExtent(bbox_buffered)
                    canvas.refresh()
                    
            QMessageBox.information(
                self,
                "LAS 수신",
                f"{sender_name}님이 보낸 {len(feature_ids)}개 작업불가 지점을 선택하고 화면을 이동했습니다.\n"
                f"레이어: {layer.name()}"
            )
            
            if hasattr(self, 'kk_status_label'):
                self.kk_status_label.setText(
                    f"LAS 수신: {len(feature_ids)}개 지점 선택됨 - {sender_name}"
                )
        else:
            QMessageBox.warning(
                self,
                "경고",
                f"레이어 '{layer.name()}'에서 해당 키 값을 가진 피처를 찾을 수 없습니다.\n"
                f"전송된 키: {', '.join(las_data['keys'][:5])}{'...' if len(las_data['keys']) > 5 else ''}"
            )
            
    def kk_on_peer_online(self, ip):
        self.kk_load_contacts()
        name = self.kk_plugin.kk_peer_manager.get_display_name(ip)
        self.kk_status_label.setText(f"{name}님이 접속했습니다")
        
    def kk_on_indexing_complete(self, count):
        if hasattr(self, 'kk_status_label'):
            self.kk_status_label.setText(f"인덱싱 완료: {count}개 피처 업데이트")
        
    def kk_on_indexing_error(self, error):
        QMessageBox.critical(self, "인덱싱 오류", error)
        
    def _calculate_doyeop_stats(self, dist_data):
        doyeop_stats = {}
        has_length_field = 'length' in dist_data.get('fields', [])
        
        for i, key in enumerate(dist_data.get('keys', [])):
            if len(key) >= 8 and '_' in key:
                doyeop = key[:8]
            elif len(key) >= 8:
                doyeop = key[:8]
            else:
                doyeop = "알수없음"
                
            if doyeop not in doyeop_stats:
                doyeop_stats[doyeop] = {
                    'count': 0,
                    'length': 0.0,
                    'has_length': has_length_field
                }
                
            doyeop_stats[doyeop]['count'] += 1
            
            if has_length_field and i < len(dist_data.get('data', [])):
                feature_data = dist_data['data'][i]
                if 'length' in feature_data:
                    try:
                        length_str = str(feature_data['length']).strip()
                        if length_str and length_str != 'None':
                            length_value = float(length_str)
                            doyeop_stats[doyeop]['length'] += length_value
                    except (ValueError, TypeError):
                        pass
                        
        return doyeop_stats
        
    def closeEvent(self, event):
        if hasattr(self, 'kk_tray_icon') and self.kk_tray_icon:
            event.ignore()
            self.hide()
            
            if not hasattr(self, '_tray_hide_notified'):
                self.kk_tray_icon.showMessage(
                    "PIPI2",
                    "메시지창이 트레이로 이동했습니다.\n트레이 아이콘을 클릭하여 다시 열 수 있습니다.",
                    QSystemTrayIcon.Information,
                    3000
                )
                self._tray_hide_notified = True
        else:
            if hasattr(self, 'kk_global_shortcut'):
                self.kk_global_shortcut.setKey(QKeySequence())
                
            event.accept()
        
        
    def kk_test_connection(self):
        if not self.kk_current_peer:
            QMessageBox.warning(self, "경고", "테스트할 사용자를 선택하세요")
            return

        if self.kk_connection_test_timer and self.kk_connection_test_timer.isActive():
            QMessageBox.information(self, "안내", "이미 연결테스트가 진행 중입니다. 잠시 기다려 주세요.")
            return
            
        test_message = f"[연결테스트] {datetime.now().strftime('%H:%M:%S')}"

        self.kk_testing_peer_ip = self.kk_current_peer['ip']

        success = self.kk_plugin.kk_network.kk_send_message(
            self.kk_current_peer['ip'],
            test_message,
            self.kk_plugin.kk_my_name,
            None 
        )
        
        if success:
            self.kk_status_label.setText(f"⏳ 연결테스트 중... {self.kk_current_peer['display_name']}")

            if not self.kk_connection_test_timer:
                self.kk_connection_test_timer = QTimer()
                self.kk_connection_test_timer.setSingleShot(True)
                self.kk_connection_test_timer.timeout.connect(self.kk_on_connection_test_timeout)
            
            self.kk_connection_test_timer.start(5000)
        else:
            self.kk_status_label.setText(f"❌ 연결테스트 전송 실패: {self.kk_current_peer['display_name']}")
            self.kk_testing_peer_ip = None
        
    def kk_change_my_name(self):
        current_name = self.kk_plugin.kk_my_name
        
        new_name, ok = QInputDialog.getText(
            self,
            "내 별명 설정",
            f"새로운 별명을 입력하세요:\n(현재: {current_name})",
            text=current_name
        )
        
        if ok and new_name.strip() and new_name.strip() != current_name:
            self.kk_plugin.kk_my_name = new_name.strip()
            self.kk_plugin.settings.setValue('PIPI/my_name', new_name.strip())
            
            self.kk_my_name_btn.setText(f"👤 {self.kk_plugin.kk_my_name}")
            
            self.setWindowTitle(f"PIPI2 - {self.kk_plugin.kk_my_name}")
            
            QMessageBox.information(self, "완료", f"별명이 '{self.kk_plugin.kk_my_name}'로 변경되었습니다.")
            
    def kk_on_connection_test_timeout(self):
        if self.kk_testing_peer_ip:
            peer_name = self.kk_plugin.kk_peer_manager.get_display_name(self.kk_testing_peer_ip)
            self.kk_status_label.setText(f"❌ 연결 실패: {peer_name} (응답 없음)")
            
            QMessageBox.warning(
                self, 
                "연결 실패", 
                f"{peer_name}님으로부터 응답이 없습니다.\n\n"
                "다음을 확인해보세요:\n"
                "• 상대방 PIPI 실행 중인지\n"
                "• 네트워크 연결이 정상인지\n"
                "• 방화벽 설정이 차단하고 있지 않은지"
            )
            
            self.kk_testing_peer_ip = None
            
    def kk_init_shortcuts(self):
        default_shortcut = "Ctrl+Shift+M"
        saved_shortcut = self.kk_plugin.settings.value('PIPI/shortcut_key', default_shortcut)

        self.kk_global_shortcut = QShortcut(QKeySequence(saved_shortcut), self.kk_plugin.iface.mainWindow())
        self.kk_global_shortcut.activated.connect(self.kk_toggle_visibility)

        self.kk_current_shortcut = saved_shortcut
        
    def kk_configure_shortcut(self):
        current_shortcut = self.kk_current_shortcut
        
        new_shortcut, ok = QInputDialog.getText(
            self,
            "단축키 설정",
            f"메시지창 열기/닫기 단축키를 설정하세요:\n\n"
            f"현재 단축키: {current_shortcut}\n\n"
            f"• Alt+M\n"
            f"• F12\n"
            f"새 단축키:",
            text=current_shortcut
        )
        
        if ok and new_shortcut.strip():
            try:
                test_sequence = QKeySequence(new_shortcut.strip())
                if test_sequence.isEmpty():
                    QMessageBox.warning(self, "오류", "올바른 단축키 형식이 아닙니다.")
                    return
                
                if hasattr(self, 'kk_global_shortcut'):
                    self.kk_global_shortcut.setKey(QKeySequence())
                    
                self.kk_global_shortcut.setKey(test_sequence)
                self.kk_current_shortcut = new_shortcut.strip()
                
                self.kk_plugin.settings.setValue('PIPI/shortcut_key', self.kk_current_shortcut)
                
                QMessageBox.information(
                    self, 
                    "완료", 
                    f"단축키가 '{self.kk_current_shortcut}'로 설정되었습니다!\n"
                )
                
            except Exception as e:
                QMessageBox.warning(self, "오류", f"단축키 설정 중 오류가 발생했습니다:\n{str(e)}")
                
    def kk_toggle_visibility(self):
        if self.isVisible() and not self.isMinimized():
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()
            if hasattr(self, 'kk_has_unread_messages') and self.kk_has_unread_messages:
                self.kk_jump_to_unread_message()
                
    def kk_jump_to_unread_message(self):
        for i in range(self.kk_contact_list.count()):
            item = self.kk_contact_list.item(i)
            peer = item.data(Qt.UserRole)
            if peer and self.kk_unread_messages.get(peer['ip'], 0) > 0:
                self.kk_contact_list.setCurrentItem(item)
                self.kk_on_contact_selected(item.text())
                break
            
    def kk_init_notifications(self):
        if hasattr(self, 'kk_tray_icon') and self.kk_tray_icon:
            self.kk_tray_icon.hide()
            self.kk_tray_icon.deleteLater()
            self.kk_tray_icon = None
            
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.kk_tray_icon = QSystemTrayIcon(self)
            self.kk_has_unread_messages = False
            self.kk_update_tray_icon()
            self.kk_tray_icon.setToolTip("PIPI2 - 메시지 알림")
            self.kk_tray_icon.activated.connect(self.kk_on_tray_activated)
            tray_menu = QMenu()
            
            show_action = tray_menu.addAction("💬 메시지창 열기")
            show_action.triggered.connect(self.kk_show_from_tray)
            
            tray_menu.addSeparator()
            
            quit_action = tray_menu.addAction("❌ 완전 종료")
            quit_action.triggered.connect(self.kk_quit_application)
            
            self.kk_tray_icon.setContextMenu(tray_menu)
            self.kk_notification_timer = QTimer()
            self.kk_notification_timer.setSingleShot(True)
            self.kk_notification_timer.timeout.connect(self.kk_process_pending_notifications)
            self.kk_tray_icon.show()
        else:
            self.kk_tray_icon = None
            self.kk_notification_timer = None
            
    def kk_update_tray_icon(self):
        if not hasattr(self, 'kk_tray_icon') or not self.kk_tray_icon:
            return
            
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icon.png')
        
        if hasattr(self, 'kk_has_unread_messages') and self.kk_has_unread_messages:
            tooltip = "PIPI2 - 읽지 않은 메시지가 있습니다"
            try:
                base_pixmap = QPixmap(icon_path)
                if base_pixmap.isNull():
                    base_pixmap = QPixmap(16, 16)
                    base_pixmap.fill(QColor(220, 50, 50))
                else:
                    base_pixmap = base_pixmap.scaled(16, 16, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    painter = base_pixmap.createMaskFromColor(Qt.transparent)
                    
                    from PyQt5.QtGui import QPainter
                    painter = QPainter(base_pixmap)
                    painter.setBrush(QColor(255, 0, 0))
                    painter.setPen(Qt.NoPen)
                    painter.drawEllipse(10, 2, 6, 6)
                    painter.end()
            except:
                base_pixmap = QPixmap(16, 16)
                base_pixmap.fill(QColor(220, 50, 50))
        else:
            tooltip = "PIPI2 - 메시지 알림"
            try:
                base_pixmap = QPixmap(icon_path)
                if base_pixmap.isNull():
                    base_pixmap = QPixmap(16, 16)
                    base_pixmap.fill(QColor(0, 120, 215))
                else:
                    base_pixmap = base_pixmap.scaled(16, 16, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            except:
                base_pixmap = QPixmap(16, 16)
                base_pixmap.fill(QColor(0, 120, 215))
            
        self.kk_tray_icon.setIcon(QIcon(base_pixmap))
        self.kk_tray_icon.setToolTip(tooltip)
            
    def kk_on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.Trigger:
            if self.isHidden():
                self.show()
                self.activateWindow()
                self.raise_()
            else:
                self.hide()
                
    def kk_show_from_tray(self):
        self.show()
        self.raise_()
        self.activateWindow()
        if hasattr(self, 'kk_has_unread_messages') and self.kk_has_unread_messages:
            self.kk_jump_to_unread_message()
            
    def kk_quit_application(self):
        reply = QMessageBox.question(
            self,
            "PIPI2 종료",
            "PIPI2를 완전히 종료하시겠습니까?\n\n"
            "종료하면 메시지 수신이 중단됩니다.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if hasattr(self, 'kk_tray_icon') and self.kk_tray_icon:
                self.kk_tray_icon.hide()
                
            if hasattr(self.kk_plugin, 'unload'):
                self.kk_plugin.unload()
                
            self.close()
            QApplication.quit()
                
    def kk_show_notification(self, sender_name, message, sender_ip):
        print(f"DEBUG: kk_show_notification 호출 - {sender_name}, tray_icon: {self.kk_tray_icon is not None}")
        
        if not self.kk_tray_icon:
            print("DEBUG: 트레이 아이콘이 없어서 알림 불가")
            return
            
        if sender_ip not in self.kk_notification_pending:
            self.kk_notification_pending.add(sender_ip)
            print(f"DEBUG: 알림 대기 목록에 추가: {sender_ip}")

        if not self.kk_notification_timer.isActive():
            print("DEBUG: 알림 처리 시작")
            self.kk_process_pending_notifications()
        else:
            print("DEBUG: 알림 타이머가 이미 활성화됨")
            
    def kk_process_pending_notifications(self):
        print(f"DEBUG: kk_process_pending_notifications 호출 - pending: {len(self.kk_notification_pending)}, tray_icon: {self.kk_tray_icon is not None}")
        
        if not self.kk_notification_pending or not self.kk_tray_icon:
            print("DEBUG: 대기 중인 알림이 없거나 트레이 아이콘이 없음")
            return
            
        if len(self.kk_notification_pending) == 1:
            sender_ip = list(self.kk_notification_pending)[0]
            sender_name = self.kk_plugin.kk_peer_manager.get_display_name(sender_ip)
            unread_count = self.kk_unread_messages.get(sender_ip, 0)
            
            if unread_count == 1:
                title = f"새 메시지 - {sender_name}"
                message = "새로운 메시지가 도착했습니다."
            else:
                title = f"새 메시지 - {sender_name}"
                message = f"{unread_count}개의 새로운 메시지가 있습니다."
        else:
            total_senders = len(self.kk_notification_pending)
            total_unread = sum(self.kk_unread_messages.get(ip, 0) for ip in self.kk_notification_pending)
            
            title = "새 메시지"
            message = f"{total_senders}명에게서 {total_unread}개의 새로운 메시지가 있습니다."
            
        print(f"DEBUG: 트레이 알림 표시 - 제목: {title}, 메시지: {message}")
        
        self.kk_tray_icon.showMessage(
            title,
            message,
            QSystemTrayIcon.Information,
            2000  
        )
        
        self.kk_notification_pending.clear()
        
        self.kk_notification_timer.start(5000)
        
    def kk_mark_messages_as_read(self, sender_ip):
        if sender_ip in self.kk_unread_messages:
            self.kk_unread_messages[sender_ip] = 0
            QTimer.singleShot(100, self.kk_update_contact_display)
            self.kk_check_unread_messages()
            
    def kk_update_contact_display(self):
        for i in range(self.kk_contact_list.count()):
            item = self.kk_contact_list.item(i)
            peer = item.data(Qt.UserRole)
            if peer:
                unread_count = self.kk_unread_messages.get(peer['ip'], 0)
                display_text = peer['display_name']
                
                if unread_count > 0:
                    item.setBackground(QColor(255, 255, 200))
                    item.setToolTip(f"온라인 - {unread_count}개의 새 메시지")
                    item.setText(f"{display_text} ({unread_count})")
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                else:
                    item.setBackground(QColor(220, 255, 220))
                    item.setToolTip("온라인")
                    item.setText(display_text)
                    font = item.font()
                    font.setBold(False)
                    item.setFont(font)
                    
    def kk_check_unread_messages(self):
        total_unread = sum(self.kk_unread_messages.values())
        
        old_state = getattr(self, 'kk_has_unread_messages', False)
        self.kk_has_unread_messages = total_unread > 0

        if old_state != self.kk_has_unread_messages:
            self.kk_update_tray_icon()
            
    def kk_paste_clipboard_image(self):
        if not self.kk_current_peer:
            QMessageBox.warning(self, "경고", "대화상대를 선택하세요.")
            return
        
        try:
            print("DEBUG: 이미지 전송 시작")
            
            clipboard = QApplication.clipboard()
            pixmap = clipboard.pixmap()
            
            if pixmap.isNull():
                QMessageBox.information(self, "알림", "클립보드에 이미지가 없습니다.")
                return
            
            print(f"DEBUG: 원본 이미지 크기: {pixmap.width()}x{pixmap.height()}")
            
            # 최대 안정 크기로 이미지 처리 - UDP 64KB 한계 고려
            max_size = 600  # 최대 해상도 대폭 증가
            if pixmap.width() > max_size or pixmap.height() > max_size:
                pixmap = pixmap.scaled(max_size, max_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                print(f"DEBUG: 리사이즈된 이미지 크기: {pixmap.width()}x{pixmap.height()}")
            
            # 고품질부터 시작해서 UDP 한계 내에서 최적화
            quality_levels = [95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30]
            final_data = None
            target_size = 45000  # Base64 인코딩 후 UDP 패킷 크기 고려 (약 60KB JSON)
            
            for quality in quality_levels:
                byte_array = QByteArray()
                buffer = QBuffer(byte_array)
                buffer.open(QIODevice.WriteOnly)
                
                if not pixmap.save(buffer, "JPEG", quality):
                    buffer.close()
                    continue
                    
                buffer.close()
                image_size = len(byte_array.data())
                
                print(f"DEBUG: 품질 {quality}% - 크기: {image_size} bytes")
                
                # 목표 크기 이하면 채택
                if image_size <= target_size:
                    final_data = byte_array.data()
                    print(f"DEBUG: 최종 선택 - 품질: {quality}%, 크기: {image_size} bytes")
                    break
            
            # 최저 품질로도 안되면 크기를 더 줄여서 재시도
            if final_data is None:
                print("DEBUG: 기본 크기로 실패, 더 작은 크기로 재시도")
                smaller_size = 400
                pixmap = clipboard.pixmap()
                if pixmap.width() > smaller_size or pixmap.height() > smaller_size:
                    pixmap = pixmap.scaled(smaller_size, smaller_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                
                for quality in [40, 35, 30, 25, 20]:
                    byte_array = QByteArray()
                    buffer = QBuffer(byte_array)
                    buffer.open(QIODevice.WriteOnly)
                    
                    if pixmap.save(buffer, "JPEG", quality):
                        buffer.close()
                        image_size = len(byte_array.data())
                        print(f"DEBUG: 작은 크기 품질 {quality}% - 크기: {image_size} bytes")
                        
                        if image_size <= target_size:
                            final_data = byte_array.data()
                            print(f"DEBUG: 작은 크기로 최종 선택 - 품질: {quality}%, 크기: {image_size} bytes")
                            break
                    else:
                        buffer.close()
            
            if final_data is None:
                QMessageBox.warning(self, "경고", "이미지가 너무 복잡합니다. 더 단순한 이미지를 사용해주세요.")
                return
            
            image_size = len(final_data)
            
            image_data = base64.b64encode(final_data).decode('ascii')
            print(f"DEBUG: Base64 인코딩 완료, 크기: {len(image_data)} chars")
            
            self.kk_status_label.setText(f"이미지 전송 중... {self.kk_current_peer['display_name']}")
            QApplication.processEvents()
            
            try:
                success = self.kk_plugin.kk_network.kk_send_message(
                    self.kk_current_peer['ip'],
                    "[이미지]",
                    self.kk_plugin.kk_my_name,
                    image_data
                )
            except Exception as e:
                print(f"ERROR: Network send failed: {e}")
                success = False
            
            if self.kk_current_peer['ip'] not in self.kk_message_buffers:
                self.kk_message_buffers[self.kk_current_peer['ip']] = []
                
            self.kk_message_buffers[self.kk_current_peer['ip']].append({
                'sender': self.kk_plugin.kk_my_name,
                'content': "[이미지]",
                'timestamp': datetime.now(),
                'is_mine': True,
                'image_data': image_data
            })
            
            if len(self.kk_message_buffers[self.kk_current_peer['ip']]) > 200:
                self.kk_message_buffers[self.kk_current_peer['ip']] = self.kk_message_buffers[self.kk_current_peer['ip']][-200:]
            
            self.kk_update_chat_view()
            
            if success:
                self.kk_status_label.setText(f"이미지 전송 완료: {self.kk_current_peer['display_name']}")
            else:
                self.kk_status_label.setText(f"이미지 전송 실패: {self.kk_current_peer['display_name']}")
                
            print("DEBUG: 이미지 전송 처리 완료")
            
        except Exception as e:
            print(f"ERROR: 이미지 전송 중 오류: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "오류", f"이미지 전송 중 오류가 발생했습니다:\n{str(e)}")
            self.kk_status_label.setText("이미지 전송 실패")