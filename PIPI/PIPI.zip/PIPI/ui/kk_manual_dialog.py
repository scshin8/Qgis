# ui/kk_manual_dialog.py

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                            QPushButton, QTextEdit, QComboBox, QMessageBox,
                            QFileDialog, QGroupBox, QSplitter, QListWidget,
                            QTableWidget, QTableWidgetItem, QHeaderView,
                            QProgressDialog, QApplication)
from PyQt5.QtCore import Qt, QDateTime, QDate
from PyQt5.QtGui import QFont
from qgis.core import QgsProject, QgsVectorLayer
import json
from datetime import datetime

from ..core.kk_encoder import KKEncoder
from ..core.kk_field_mapping import KKFieldMapping

class KKManualDialog(QWidget):
    
    def __init__(self, plugin):
        super().__init__()
        self.kk_plugin = plugin
        self.kk_init_ui()
        
    def kk_init_ui(self):
        layout = QVBoxLayout(self)
        
        default_font = QFont("현대하모니L", 10)
        self.setFont(default_font)
        
        info_label = QLabel("""
        <h3>🔧 수동 </h3>
        <p>텍스트전송방식</p>
        <p>필드솔트</p>
        <p>300개정도??..</p>
        """)
        info_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                padding: 10px;
                border-radius: 5px;
                font-family: '현대하모니L';
            }
        """)
        layout.addWidget(info_label)
        
        splitter = QSplitter(Qt.Horizontal)
        
        encode_widget = self._create_encode_widget()
        splitter.addWidget(encode_widget)
        
        decode_widget = self._create_decode_widget()
        splitter.addWidget(decode_widget)
        
        splitter.setSizes([500, 500])
        layout.addWidget(splitter)
        
    def _create_encode_widget(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        group = QGroupBox("📤 인코딩")
        group_layout = QVBoxLayout(group)
        
        layer_layout = QHBoxLayout()
        layer_layout.addWidget(QLabel("레이어:"))
        
        self.kk_encode_layer_combo = QComboBox()
        layer_layout.addWidget(self.kk_encode_layer_combo)
        
        group_layout.addLayout(layer_layout)
        
        self.kk_encode_info = QLabel("피처를 선택하세요")
        self.kk_encode_info.setStyleSheet("QLabel { color: #666; padding: 5px; font-family: '현대하모니L'; }")
        group_layout.addWidget(self.kk_encode_info)
        
        field_group = QGroupBox("전송할 필드")
        field_layout = QVBoxLayout(field_group)
        
        self.kk_encode_field_table = QTableWidget()
        self.kk_encode_field_table.setColumnCount(2)
        self.kk_encode_field_table.setHorizontalHeaderLabels(['선택', '필드명'])
        self.kk_encode_field_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.kk_encode_field_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.kk_encode_field_table.setMaximumHeight(150)
        
        field_layout.addWidget(self.kk_encode_field_table)
        
        field_btn_layout = QHBoxLayout()
        
        essential_btn = QPushButton("필수만")
        essential_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        essential_btn.clicked.connect(self.kk_select_essential_encode_fields)
        
        all_btn = QPushButton("전체")
        all_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        all_btn.clicked.connect(self.kk_select_all_encode_fields)
        
        field_btn_layout.addWidget(essential_btn)
        field_btn_layout.addWidget(all_btn)
        field_btn_layout.addStretch()
        
        field_layout.addLayout(field_btn_layout)
        
        group_layout.addWidget(field_group)
        
        encode_btn = QPushButton("🔐 인코딩 실행")
        encode_btn.clicked.connect(self.kk_encode_features)
        encode_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-weight: bold;
                padding: 8px;
                font-family: '현대하모니L';
            }
        """)
        group_layout.addWidget(encode_btn)
        
        result_label = QLabel("<b>인코딩 결과:</b>")
        group_layout.addWidget(result_label)
        
        self.kk_encode_text = QTextEdit()
        self.kk_encode_text.setPlaceholderText("인코딩된 데이터...")
        self.kk_encode_text.setReadOnly(True)
        font = QFont("현대하모니L", 9)
        font.setStyleHint(QFont.Monospace)
        self.kk_encode_text.setFont(font)
        group_layout.addWidget(self.kk_encode_text)
        
        encode_btn_layout = QHBoxLayout()
        
        copy_btn = QPushButton("📋 복사")
        copy_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        copy_btn.clicked.connect(self.kk_copy_encoded)
        
        save_btn = QPushButton("💾 파일 저장")
        save_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        save_btn.clicked.connect(self.kk_save_encoded)
        
        encode_btn_layout.addWidget(copy_btn)
        encode_btn_layout.addWidget(save_btn)
        encode_btn_layout.addStretch()
        
        group_layout.addLayout(encode_btn_layout)
        
        layout.addWidget(group)
        
        self.kk_load_layers()
        
        return widget
        
    def _create_decode_widget(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        group = QGroupBox("📥 디코딩")
        group_layout = QVBoxLayout(group)
        

        input_label = QLabel("<b>인코딩된 데이터 입력:</b>")
        group_layout.addWidget(input_label)
        
        self.kk_decode_text = QTextEdit()
        self.kk_decode_text.setPlaceholderText(
            "인코딩된 데이터를 붙여넣으세요...\n"
            "파일에서 불러올 수 있습니다."
        )
        font = QFont("현대하모니L", 9)
        font.setStyleHint(QFont.Monospace)
        self.kk_decode_text.setFont(font)
        group_layout.addWidget(self.kk_decode_text)
        
        decode_btn_layout = QHBoxLayout()
        
        paste_btn = QPushButton("📋 붙여넣기")
        paste_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        paste_btn.clicked.connect(self.kk_paste_decode)
        
        load_btn = QPushButton("📁 파일 열기")
        load_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        load_btn.clicked.connect(self.kk_load_file)
        
        clear_btn = QPushButton("🗑️ 지우기")
        clear_btn.setStyleSheet("QPushButton { font-family: '현대하모니L'; }")
        clear_btn.clicked.connect(self.kk_decode_text.clear)
        
        decode_btn_layout.addWidget(paste_btn)
        decode_btn_layout.addWidget(load_btn)
        decode_btn_layout.addWidget(clear_btn)
        decode_btn_layout.addStretch()
        
        group_layout.addLayout(decode_btn_layout)
        
        decode_btn = QPushButton("🔓 디코딩&미리보기")
        decode_btn.clicked.connect(self.kk_decode_preview)
        decode_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 8px;
                font-family: '현대하모니L';
            }
        """)
        group_layout.addWidget(decode_btn)
        
        self.kk_decode_info = QLabel("디코딩 대기 중...")
        self.kk_decode_info.setStyleSheet("""
            QLabel {
                background-color: #FFF9C4;
                padding: 8px;
                border-radius: 4px;
                font-family: '현대하모니L';
            }
        """)
        group_layout.addWidget(self.kk_decode_info)
        
        preview_group = QGroupBox("미리보기")
        preview_layout = QVBoxLayout(preview_group)
        
        self.kk_preview_list = QListWidget()
        self.kk_preview_list.setMaximumHeight(150)
        preview_layout.addWidget(self.kk_preview_list)
        
        group_layout.addWidget(preview_group)
        
        index_btn = QPushButton("⚡ 레이어에 적용")
        index_btn.clicked.connect(self.kk_decode_and_index)
        index_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF5722;
                color: white;
                font-weight: bold;
                padding: 10px;
                font-size: 14px;
                font-family: '현대하모니L';
            }
        """)
        group_layout.addWidget(index_btn)
        
        layout.addWidget(group)
        return widget
        
    def kk_load_layers(self):
        self.kk_encode_layer_combo.clear()
        
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'ING' in layer.name():
                    self.kk_encode_layer_combo.addItem(f"⭐ {layer.name()}", layer)
                    
        if self.kk_encode_layer_combo.count() > 0:
            self.kk_encode_layer_combo.insertSeparator(self.kk_encode_layer_combo.count())
            
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and 'ING' not in layer.name():
                self.kk_encode_layer_combo.addItem(layer.name(), layer)
                
        self.kk_encode_layer_combo.currentIndexChanged.connect(self.kk_update_encode_fields)
        self.kk_update_encode_fields()
                
    def kk_update_encode_fields(self):
        layer = self.kk_encode_layer_combo.currentData()
        if not layer:
            return
            
        if not hasattr(self, 'kk_encode_info') or not hasattr(self, 'kk_encode_field_table'):
            return

        selected = layer.selectedFeatureCount()
        total = layer.featureCount()
        self.kk_encode_info.setText(f"선택: {selected:,}개 / 전체: {total:,}개")
        
        self.kk_encode_field_table.setRowCount(0)
        
        essential_fields = KKFieldMapping.ESSENTIAL_FIELDS
        
        for i, field in enumerate(layer.fields()):
            self.kk_encode_field_table.insertRow(i)
            
            check_item = QTableWidgetItem()
            check_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            
            if field.name() in essential_fields:
                check_item.setCheckState(Qt.Checked)
            else:
                check_item.setCheckState(Qt.Unchecked)
                
            self.kk_encode_field_table.setItem(i, 0, check_item)
            
            name_item = QTableWidgetItem(field.name())
            if field.name() in essential_fields:
                font = QFont("현대하모니L", -1, QFont.Bold)
                name_item.setFont(font)
            self.kk_encode_field_table.setItem(i, 1, name_item)
            
    def kk_select_essential_encode_fields(self):
        essential_fields = KKFieldMapping.ESSENTIAL_FIELDS
        
        for i in range(self.kk_encode_field_table.rowCount()):
            field_name = self.kk_encode_field_table.item(i, 1).text()
            if field_name in essential_fields:
                self.kk_encode_field_table.item(i, 0).setCheckState(Qt.Checked)
            else:
                self.kk_encode_field_table.item(i, 0).setCheckState(Qt.Unchecked)
                
    def kk_select_all_encode_fields(self):
        for i in range(self.kk_encode_field_table.rowCount()):
            self.kk_encode_field_table.item(i, 0).setCheckState(Qt.Checked)
            
    def kk_encode_features(self):
        layer = self.kk_encode_layer_combo.currentData()
        if not layer:
            QMessageBox.warning(self, "경고", "레이어를 선택하세요")
            return
            
        if layer.selectedFeatureCount() == 0:
            QMessageBox.warning(self, "경고", "선택된 피처가 없습니다")
            return
            
        selected_fields = []
        for i in range(self.kk_encode_field_table.rowCount()):
            if self.kk_encode_field_table.item(i, 0).checkState() == Qt.Checked:
                selected_fields.append(self.kk_encode_field_table.item(i, 1).text())
                
        if not selected_fields:
            QMessageBox.warning(self, "경고", "최소 하나의 필드를 선택하세요")
            return
            
        key_field = 'key'
        if 'key' not in selected_fields:
            if selected_fields:
                key_field = selected_fields[0]
                
        try:
            progress = QProgressDialog(
                "인코딩 중...", 
                "취소", 
                0, 
                layer.selectedFeatureCount(), 
                self
            )
            progress.setWindowModality(Qt.WindowModal)
            
            encoded = KKEncoder.kk_encode_features(
                list(layer.selectedFeatures()),
                selected_fields,
                key_field
            )
            
            progress.close()
            
            self.kk_encode_text.setText(encoded)
            
            QMessageBox.information(
                self,
                "인코딩 완료",
                f"✅ {layer.selectedFeatureCount()}개 피처가 인코딩되었습니다.\n"
                f"📦 데이터 크기: {len(encoded):,} 문자"
            )
            
        except Exception as e:
            QMessageBox.critical(self, "오류", f"인코딩 오류: {str(e)}")
            
    def kk_copy_encoded(self):
        text = self.kk_encode_text.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "복사 완료", "클립보드에 복사되었습니다.")
            
    def kk_save_encoded(self):
        text = self.kk_encode_text.toPlainText()
        if not text:
            QMessageBox.warning(self, "경고", "저장할 데이터가 없습니다.")
            return
            
        default_name = f"pipi_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "인코딩 데이터 저장",
            default_name,
            "텍스트 파일 (*.txt);;모든 파일 (*.*)"
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(text)
                QMessageBox.information(self, "저장 완료", "파일이 저장되었습니다.")
            except Exception as e:
                QMessageBox.critical(self, "오류", f"저장 오류: {str(e)}")
                
    def kk_paste_decode(self):
        text = QApplication.clipboard().text()
        if text:
            self.kk_decode_text.setText(text)
            
    def kk_load_file(self):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "인코딩 데이터 열기",
            "",
            "텍스트 파일 (*.txt);;모든 파일 (*.*)"
        )
        
        if filename:
            try:
                with open(filename, 'r', encoding='utf-8') as f:
                    text = f.read()
                self.kk_decode_text.setText(text)
            except Exception as e:
                QMessageBox.critical(self, "오류", f"파일 열기 오류: {str(e)}")
                
    def kk_decode_preview(self):
        encoded_text = self.kk_decode_text.toPlainText().strip()
        if not encoded_text:
            QMessageBox.warning(self, "경고", "디코딩할 데이터가 없습니다.")
            return
            
        try:
            self.decoded_data = KKEncoder.kk_decode_features(encoded_text)
            
            feature_count = len(self.decoded_data.get('features', []))
            field_count = len(self.decoded_data.get('fields', []))
            
            self.kk_decode_info.setText(
                f"✅ 디코딩 성공: {feature_count:,}개 피처, {field_count}개 필드\n"
                f"📋 필드: {', '.join(self.decoded_data.get('fields', []))}"
            )
            
            self.kk_preview_list.clear()
            for i, feature in enumerate(self.decoded_data.get('features', [])[:10]):
                key = feature.get(self.decoded_data.get('key_field', 'key'), 'N/A')
                progress = feature.get('Progress', 'N/A')
                operator = feature.get('operator', 'N/A')
                
                preview_text = f"[{i+1}] Key: {key} | Progress: {progress} | 작업자: {operator}"
                self.kk_preview_list.addItem(preview_text)
                
            if feature_count > 10:
                self.kk_preview_list.addItem(f"... 외 {feature_count - 10}개")
                
        except Exception as e:
            self.kk_decode_info.setText(f"❌ 디코딩 오류: {str(e)}")
            self.kk_preview_list.clear()
            QMessageBox.critical(self, "오류", f"디코딩 오류: {str(e)}")
            
    def kk_decode_and_index(self):
        if not hasattr(self, 'decoded_data'):
            QMessageBox.warning(self, "경고", "먼저 디코딩을 실행하세요.")
            return
            
        try:
            feature_count = len(self.decoded_data.get('features', []))
            field_list = ', '.join(self.decoded_data.get('fields', []))
            
            reply = QMessageBox.question(
                self,
                "인덱싱 확인",
                f"{feature_count:,}개 피처를 레이어에 적용하시겠습니까?\n\n"
                f"업데이트할 필드: {field_list}\n"
                f"작업자: {self.kk_plugin.kk_my_name}",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                progress = QProgressDialog(
                    "인덱싱 진행 중...", 
                    None,  
                    0, 
                    4, 
                    self
                )
                progress.setWindowModality(Qt.WindowModal)
                progress.show()
                
                progress.setLabelText("1/4 디코딩 확인...")
                progress.setValue(1)
                QApplication.processEvents()
                
                dist_data = {
                    'layer_name': self.decoded_data.get('layer_name', 'ING'),
                    'key_field': self.decoded_data.get('key_field', 'key'),
                    'fields': self.decoded_data.get('fields', []),
                    'keys': [],
                    'data': self.decoded_data.get('features', [])
                }
                
                progress.setLabelText("2/4 키 추출...")
                progress.setValue(2)

                QApplication.processEvents()
                for feature in self.decoded_data.get('features', []):
                    key = feature.get(dist_data['key_field'])
                    if key:
                        dist_data['keys'].append(str(key))
                
                progress.setLabelText("3/4 업데이트...")
                progress.setValue(3)
                QApplication.processEvents()
                
                self.kk_plugin.kk_indexer.kk_process_distribution(
                    dist_data,
                    self.kk_plugin.kk_my_name
                )
                
                progress.setLabelText("4/4 완료!")
                progress.setValue(4)
                QApplication.processEvents()
                
                progress.close()
                
                QMessageBox.information(
                    self, 
                    "완료", 
                    f"인덱싱이 완료되었습니다.\n\n"
                    f"처리된 피처: {feature_count:,}개\n"
                    f"업데이트된 필드: {field_list}"
                )
                
                self.kk_decode_text.clear()
                self.kk_decode_info.setText("디코딩 대기 중...")
                self.kk_preview_list.clear()
                delattr(self, 'decoded_data')
                
        except Exception as e:
            if 'progress' in locals():
                progress.close()
            QMessageBox.critical(self, "오류", f"인덱싱 오류: {str(e)}")