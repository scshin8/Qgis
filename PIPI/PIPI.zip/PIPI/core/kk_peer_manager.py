from PyQt5.QtCore import QSettings
import json

class KKPeerManager:
    
    DEFAULT_PEERS = {
        '10.206.111.12': '박상철',
        '10.206.111.13': '이담',
        '10.206.111.15': '신성철',
        '10.206.111.16': '김민구',
        '10.206.111.19': '주예진',
        '10.206.111.20': '남은지',
        '10.206.111.77': '이호평',
        '10.206.111.23': '박은비',
        '10.206.111.42': '김지의',
        '10.206.111.25': '성예은',
        '10.206.111.65': '김유림',
        '10.206.111.67': '김윤아',
        '10.206.111.28': '이정희',
        '10.206.111.29': '이나라',
        '10.206.111.31': '최선영',
        '10.206.111.33': '정다은',
        '10.206.111.35': '안유진',
        '10.206.111.32': '신현영',
    }
    
    def __init__(self):
        self.settings = QSettings()
        self._load_settings()
        
    def _load_settings(self):
        self.nicknames = {}
        saved_nicknames = self.settings.value('PIPI/peer_nicknames', '{}')
        if saved_nicknames:
            try:
                self.nicknames = json.loads(saved_nicknames)
            except:
                self.nicknames = {}
                
    def save_settings(self):
        self.settings.setValue('PIPI/peer_nicknames', json.dumps(self.nicknames))
        
    def get_peer_list(self, exclude_ip=None):
        peers = []
        for ip, default_name in self.DEFAULT_PEERS.items():
            if ip != exclude_ip:
                peer = {
                    'ip': ip,
                    'name': default_name,
                    'display_name': self.nicknames.get(ip, default_name)
                }
                peers.append(peer)
        return sorted(peers, key=lambda x: x['ip'])
        
    def set_nickname(self, ip, nickname):
        if nickname.strip():
            self.nicknames[ip] = nickname.strip()
        elif ip in self.nicknames:
            del self.nicknames[ip]
        self.save_settings()
        
    def get_display_name(self, ip):
        if ip in self.nicknames:
            return self.nicknames[ip]
        return self.DEFAULT_PEERS.get(ip, ip)
        
    def get_peer_by_ip(self, ip):
        if ip in self.DEFAULT_PEERS:
            return {
                'ip': ip,
                'name': self.DEFAULT_PEERS[ip],
                'display_name': self.get_display_name(ip)
            }
        return None