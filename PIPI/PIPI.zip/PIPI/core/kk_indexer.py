import sqlite3
from datetime import datetime
from PyQt5.QtCore import QObject, pyqtSignal, QDate, QDateTime
from qgis.core import QgsProject, QgsMessageLog, Qgis, QgsFeatureRequest, QgsExpression
from .kk_field_mapping import KKFieldMapping

class KKIndexingEngine(QObject):
    
    kk_indexing_progress = pyqtSignal(int, int)
    kk_indexing_complete = pyqtSignal(int)
    kk_indexing_error = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        
    def kk_process_distribution(self, dist_data, operator_name):
        """분배 데이터 처리 - 개선된 오류 처리 및 트랜잭션 관리"""
        try:
            # 1. 레이어 찾기
            layer = self._kk_find_layer(dist_data.get('layer_name', 'ING'))
            if not layer:
                raise ValueError("대상 레이어를 찾을 수 없습니다")
            
            # 2. 필드 검증
            field_indices = {}
            key_field = dist_data.get('key_field', 'key')
            key_idx = layer.fields().indexFromName(key_field)
            
            if key_idx == -1:
                raise ValueError(f"Key 필드를 찾을 수 없습니다: {key_field}")
            
            # 업데이트할 필드 확인
            fields_to_update = []
            missing_fields = []
            
            for field in dist_data.get('fields', []):
                if field != key_field:
                    idx = layer.fields().indexFromName(field)
                    if idx != -1:
                        fields_to_update.append(field)
                        field_indices[field] = idx
                    else:
                        missing_fields.append(field)
            
            if missing_fields:
                QgsMessageLog.logMessage(
                    f"누락된 필드: {', '.join(missing_fields)}", 
                    'PIPI', Qgis.Warning
                )
            
            if not fields_to_update:
                raise ValueError("업데이트할 필드가 없습니다")
            
            # 3. 데이터 준비
            keys_list = dist_data.get('keys', [])
            data_list = dist_data.get('data', [])
            
            if len(keys_list) != len(data_list):
                QgsMessageLog.logMessage(
                    f"키와 데이터 개수 불일치: keys={len(keys_list)}, data={len(data_list)}", 
                    'PIPI', Qgis.Warning
                )
            
            # key-data 매핑 생성
            key_data_map = {}
            for i in range(min(len(keys_list), len(data_list))):
                key_value = str(keys_list[i]).strip()
                if key_value:
                    key_data_map[key_value] = data_list[i]
            
            if not key_data_map:
                raise ValueError("처리할 데이터가 없습니다")
            
            # 4. 피처 매칭 및 업데이트 준비
            attr_updates = {}
            matched_count = 0
            not_found_keys = []
            
            # Expression 기반 검색으로 성능 개선
            key_values = list(key_data_map.keys())
            
            # 배치 처리를 위한 청크 생성 (100개씩)
            chunk_size = 100
            for i in range(0, len(key_values), chunk_size):
                chunk = key_values[i:i + chunk_size]
                
                # IN 절을 사용한 표현식 생성
                in_values = ','.join([f"'{k}'" for k in chunk])
                expression = QgsExpression(f'"{key_field}" IN ({in_values})')
                
                request = QgsFeatureRequest(expression)
                request.setFlags(QgsFeatureRequest.NoGeometry)
                
                for feature in layer.getFeatures(request):
                    feature_key = str(feature.attribute(key_field)).strip()
                    
                    if feature_key in key_data_map:
                        feature_data = key_data_map[feature_key]
                        change_map = {}
                        
                        for field in fields_to_update:
                            if field in field_indices:
                                idx = field_indices[field]
                                new_value = feature_data.get(field, '')
                                
                                # 필드 맵핑을 사용한 값 변환
                                try:
                                    if KKFieldMapping.is_date_field(field):
                                        formatted_value = self._format_date_value(new_value)
                                        change_map[idx] = formatted_value
                                    elif KKFieldMapping.is_real_field(field):
                                        if new_value is None or str(new_value).strip() == '':
                                            change_map[idx] = None
                                        else:
                                            change_map[idx] = float(str(new_value))
                                    else:
                                        # 문자열 필드
                                        if new_value is None:
                                            change_map[idx] = ''
                                        else:
                                            change_map[idx] = str(new_value)
                                except (ValueError, TypeError) as e:
                                    QgsMessageLog.logMessage(
                                        f"값 변환 오류 - Key: {feature_key}, Field: {field}, Value: {new_value}, Error: {str(e)}", 
                                        'PIPI', Qgis.Warning
                                    )
                                    # 변환 실패 시 원본 값 사용
                                    change_map[idx] = str(new_value) if new_value is not None else ''
                        
                        if change_map:
                            attr_updates[feature.id()] = change_map
                            matched_count += 1
                
                # 진행 상황 업데이트
                processed = min(i + chunk_size, len(key_values))
                self.kk_indexing_progress.emit(processed, len(key_values))
            
            # 찾지 못한 키 확인
            found_keys = set()
            for feature_id, changes in attr_updates.items():
                feature = layer.getFeature(feature_id)
                found_keys.add(str(feature.attribute(key_field)))
            
            not_found_keys = list(set(key_values) - found_keys)
            
            if not_found_keys:
                QgsMessageLog.logMessage(
                    f"찾을 수 없는 키: {', '.join(not_found_keys[:10])}{'...' if len(not_found_keys) > 10 else ''}", 
                    'PIPI', Qgis.Warning
                )
            
            if not attr_updates:
                QgsMessageLog.logMessage(
                    "업데이트할 항목이 없습니다", 
                    'PIPI', Qgis.Warning
                )
                self.kk_indexing_complete.emit(0)
                return
            
            # 5. 업데이트 실행
            QgsMessageLog.logMessage(
                f"DataProvider를 통해 {matched_count}개 항목 업데이트 시작", 
                'PIPI', Qgis.Info
            )

            # 편집 상태 관리
            was_editable = layer.isEditable()
            if was_editable:
                layer.commitChanges()

            # 배치 업데이트 실행
            success = True
            error_count = 0
            
            # 큰 업데이트는 청크로 나누어 처리
            update_chunk_size = 500
            update_items = list(attr_updates.items())
            
            for i in range(0, len(update_items), update_chunk_size):
                chunk_updates = dict(update_items[i:i + update_chunk_size])
                
                if not layer.dataProvider().changeAttributeValues(chunk_updates):
                    error_count += len(chunk_updates)
                    QgsMessageLog.logMessage(
                        f"청크 업데이트 실패: {i}-{i+update_chunk_size}", 
                        'PIPI', Qgis.Critical
                    )
                    success = False
            
            if success:
                layer.triggerRepaint()
                self.kk_indexing_complete.emit(matched_count)
                QgsMessageLog.logMessage(
                    f"{matched_count}개 항목 업데이트 완료 (찾을 수 없음: {len(not_found_keys)}개)", 
                    'PIPI', Qgis.Info
                )
            else:
                raise Exception(f"DataProvider 업데이트 부분 실패 (오류: {error_count}개)")

            # 편집 상태 복원
            if was_editable:
                layer.startEditing()
                
        except Exception as e:
            error_msg = f"인덱싱 오류: {str(e)}"
            self.kk_indexing_error.emit(error_msg)
            QgsMessageLog.logMessage(error_msg, 'PIPI', Qgis.Critical)
    
    def _format_date_value(self, value):
        """날짜 값 포맷팅 - KKFieldMapping 사용"""
        if value is None or str(value).strip() == '':
            return None
            
        # KKFieldMapping의 날짜 포맷팅 사용
        try:
            formatted = KKFieldMapping._format_date_value(value)
            return formatted if formatted else None
        except Exception as e:
            QgsMessageLog.logMessage(
                f"날짜 변환 실패: '{value}' - {str(e)}", 
                'PIPI', Qgis.Warning
            )
            return None
    
    def _kk_find_layer(self, layer_name):
        """레이어 찾기 - 개선된 매칭 로직"""
        layers = QgsProject.instance().mapLayers()
        
        # 1. 정확한 이름 매칭
        for layer_id, layer in layers.items():
            if layer.name() == layer_name:
                return layer
        
        # 2. 부분 이름 매칭 (ING 포함)
        if 'ING' in layer_name:
            for layer_id, layer in layers.items():
                if 'ING' in layer.name() and layer_name in layer.name():
                    return layer
        
        # 3. 기본 ING 레이어 찾기
        for layer_id, layer in layers.items():
            if 'ING' in layer.name():
                QgsMessageLog.logMessage(
                    f"요청된 레이어 '{layer_name}'를 찾을 수 없어 '{layer.name()}'를 사용합니다", 
                    'PIPI', Qgis.Warning
                )
                return layer
        
        return None
    
    def _kk_extract_gpkg_info(self, layer):
        """GeoPackage 정보 추출"""
        source = layer.source()
        
        if '|' in source:
            parts = source.split('|')
            gpkg_path = parts[0]
            table_name = None
            
            for part in parts[1:]:
                if part.startswith('layername='):
                    table_name = part[10:]
                    break
            
            if table_name:
                return gpkg_path, table_name
        
        # 기본값 반환
        if '|' in source:
            return source.split('|')[0], layer.name()
        else:
            return source, layer.name()
    
    def validate_distribution_data(self, dist_data):
        """분배 데이터 유효성 검사"""
        errors = []
        
        # 필수 키 확인
        required_keys = ['layer_name', 'key_field', 'fields', 'keys', 'data']
        for key in required_keys:
            if key not in dist_data:
                errors.append(f"필수 키 누락: {key}")
        
        # 데이터 일관성 확인
        if 'keys' in dist_data and 'data' in dist_data:
            if len(dist_data['keys']) != len(dist_data['data']):
                errors.append(f"키와 데이터 개수 불일치: keys={len(dist_data['keys'])}, data={len(dist_data['data'])}")
        
        # 필드 존재 확인
        if 'fields' in dist_data and 'data' in dist_data and dist_data['data']:
            sample_data = dist_data['data'][0]
            missing_fields = []
            for field in dist_data['fields']:
                if field not in sample_data:
                    missing_fields.append(field)
            if missing_fields:
                errors.append(f"데이터에 없는 필드: {', '.join(missing_fields)}")
        
        return errors