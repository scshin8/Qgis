import json
import time
import base64
import hashlib
import zstandard as zstd
from PyQt5.QtCore import QObject, pyqtSignal, QTimer, QThread, QSettings
from PyQt5.QtNetwork import QUdpSocket, QTcpServer, QTcpSocket, QHostAddress

class KKNetworkManager(QObject):
    
    kk_message_received = pyqtSignal(str, str, str, str)
    kk_distribution_received = pyqtSignal(str, dict)
    kk_las_received = pyqtSignal(str, dict) 
    kk_peer_online = pyqtSignal(str)
    kk_peer_offline = pyqtSignal(str)
    kk_ping_response_received = pyqtSignal(str)
    kk_offline_message_delivered = pyqtSignal(str, int) 
    
    KK_UDP_PORT = 45454
    KK_TCP_PORT = 45455
    KK_PING_TIMEOUT = 3000 
    
    def __init__(self):
        super().__init__()
        
        self.my_ip = None
        self.settings = QSettings()
        
        self.kk_udp_socket = QUdpSocket()
        self.kk_udp_socket.bind(QHostAddress.Any, self.KK_UDP_PORT)
        self.kk_udp_socket.readyRead.connect(self._kk_on_udp_ready)
        
        self.kk_tcp_server = QTcpServer()
        self.kk_tcp_server.listen(QHostAddress.Any, self.KK_TCP_PORT)
        self.kk_tcp_server.newConnection.connect(self._kk_on_tcp_connection)
        
        self.kk_online_peers = {}
        self.kk_known_peers = []
        self.kk_ping_timers = {}
        
        self.kk_offline_messages = {}
        self._load_offline_messages()
        
        self.kk_retry_timer = QTimer()
        self.kk_retry_timer.timeout.connect(self._retry_offline_messages)
        self.kk_retry_timer.start(30000) 
        
        # 온라인테러비활성화
        # self.kk_heartbeat_timer = QTimer()
        # self.kk_heartbeat_timer.timeout.connect(self.kk_check_online_status)
        # self.kk_heartbeat_timer.start(10000)  
        
    def set_my_ip(self, ip):
        self.my_ip = ip
        print(f"DEBUG: My IP set to {ip}")
        
    def start(self):
        # 온라인 알림 비활성화
        # self._kk_send_online_notification()
        # 시작 시 저장된 오프라인 메시지 확인
        QTimer.singleShot(5000, self._retry_offline_messages)
        # 시작 후 바로 온라인 상태 확인 비활성화
        # QTimer.singleShot(1000, self.kk_check_online_status)
        pass
        
    def stop(self):
        # 오프라인 알림 비활성화
        # self._kk_send_offline_notification()
        self._save_offline_messages()
        
        self.kk_udp_socket.close()
        self.kk_tcp_server.close()
        
    def set_known_peers(self, peer_ips):
        self.kk_known_peers = peer_ips
        
    def _load_offline_messages(self):
        try:
            saved_messages = self.settings.value('PIPI/offline_messages', '{}')
            self.kk_offline_messages = json.loads(saved_messages)
        except:
            self.kk_offline_messages = {}
            
    def _save_offline_messages(self):
        self.settings.setValue('PIPI/offline_messages', json.dumps(self.kk_offline_messages))
        
    def _retry_offline_messages(self):
        if not self.kk_offline_messages:
            return
            
        delivered_messages = []
        
        for target_ip, messages in self.kk_offline_messages.items():
            if target_ip in self.kk_online_peers:
                for msg_data in messages:
                    self._kk_send_udp_to(target_ip, msg_data['packet'])
                    
                delivered_messages.append(target_ip)
                self.kk_offline_message_delivered.emit(target_ip, len(messages))
                
        for ip in delivered_messages:
            del self.kk_offline_messages[ip]
            
        if delivered_messages:
            self._save_offline_messages()
        
    def kk_check_online_status(self):
        print("DEBUG: Checking online status manually")
        
        packet = {
            'type': 'PING',
            'timestamp': time.time()
        }
        
        for timer in self.kk_ping_timers.values():
            timer.stop()
        self.kk_ping_timers.clear()
        
        for peer_ip in self.kk_known_peers:
            if peer_ip != self.my_ip:
                self._kk_send_udp_to(peer_ip, packet)
                
                timer = QTimer()
                timer.setSingleShot(True)
                timer.timeout.connect(lambda ip=peer_ip: self._kk_on_ping_timeout(ip))
                timer.start(self.KK_PING_TIMEOUT)
                self.kk_ping_timers[peer_ip] = timer
        
    def _kk_on_ping_timeout(self, ip):
        if ip in self.kk_ping_timers:
            del self.kk_ping_timers[ip]
        if ip in self.kk_online_peers:
            del self.kk_online_peers[ip]
        self.kk_peer_offline.emit(ip)
        print(f"DEBUG: {ip} PING timeout - marked as offline")
        
    def kk_send_message(self, target_ip, message, sender_name=None, image_data=None):
        packet = {
            'type': 'MESSAGE',
            'content': message,
            'sender_name': sender_name,
            'timestamp': time.time()
        }
        
        if image_data:
            print(f"DEBUG: Sending image message via TCP to {target_ip}")
            return self._kk_send_image_via_tcp(target_ip, packet, image_data)
        else:
            print(f"DEBUG: Sending text message via UDP to {target_ip}: {message}")
            self._kk_send_udp_to(target_ip, packet)
            return True
        
    def kk_send_distribution(self, target_ip, dist_data):
        data_size = len(json.dumps(dist_data))
        
        if data_size < 50000: 
            self._kk_send_small_distribution(target_ip, dist_data)
        else:  
            self._kk_send_large_distribution(target_ip, dist_data)
            
    def _kk_send_small_distribution(self, target_ip, dist_data):
        json_bytes = json.dumps(dist_data).encode('utf-8')
        compressed = zstd.compress(json_bytes, 11)
        encoded = base64.b64encode(compressed).decode('ascii')
        
        packet = {
            'type': 'DISTRIBUTION',
            'data': encoded,
            'checksum': hashlib.sha256(compressed).hexdigest()[:16],
            'count': len(dist_data['keys']),
            'timestamp': time.time()
        }
        
        self._kk_send_udp_to(target_ip, packet)
        
    def _kk_send_large_distribution(self, target_ip, dist_data):
        thread = KKTcpSenderThread(target_ip, self.KK_TCP_PORT, dist_data)
        thread.finished.connect(thread.deleteLater)
        thread.start()
        
    def _kk_send_image_via_tcp(self, target_ip, message_packet, image_data):
        try:
            print(f"DEBUG: Image sending via UDP fallback to {target_ip}")
            
            image_size = len(image_data)
            if image_size > 60000:
                print(f"ERROR: Image too large for UDP: {image_size} bytes")
                return False
            
            try:
                base64.b64decode(image_data)
            except Exception as e:
                print(f"ERROR: Invalid base64 image data: {e}")
                return False
            
            image_packet = {
                'type': 'MESSAGE',
                'content': message_packet.get('content', '[이미지]'),
                'sender_name': message_packet.get('sender_name', ''),
                'image_data': image_data,
                'timestamp': time.time()
            }
            
            try:
                test_json = json.dumps(image_packet)
                if len(test_json) > 65000:
                    print(f"ERROR: JSON too large for UDP: {len(test_json)} bytes")
                    return False
            except Exception as e:
                print(f"ERROR: JSON serialization failed: {e}")
                return False
            
            self._kk_send_udp_to(target_ip, image_packet)
            print("DEBUG: Image sent via UDP")
            
            return True
            
        except Exception as e:
            print(f"ERROR: Image sending failed: {e}")
            import traceback
            traceback.print_exc()
            return False
        
    def kk_send_las(self, target_ip, las_data):
        packet = {
            'type': 'LAS',
            'keys': las_data['keys'],
            'layer': las_data['layer_name'],
            'count': len(las_data['keys']),
            'timestamp': time.time()
        }
        self._kk_send_udp_to(target_ip, packet)
        
    def _kk_send_udp_to(self, target_ip, packet):
        data = json.dumps(packet).encode('utf-8')
        self.kk_udp_socket.writeDatagram(data, QHostAddress(target_ip), self.KK_UDP_PORT)
        
    def _kk_send_udp_broadcast(self, packet):
        data = json.dumps(packet).encode('utf-8')
        
        self.kk_udp_socket.writeDatagram(data, QHostAddress("10.206.111.255"), self.KK_UDP_PORT)
        
        for peer_ip in self.kk_known_peers:
            if peer_ip != self.my_ip:
                self.kk_udp_socket.writeDatagram(data, QHostAddress(peer_ip), self.KK_UDP_PORT)
        
    def _normalize_ip(self, ip):
        if ip.startswith("::ffff:"):
            return ip[7:]
        return ip
        
    def _kk_on_udp_ready(self):
        while self.kk_udp_socket.hasPendingDatagrams():
            data, host, _ = self.kk_udp_socket.readDatagram(65535)
            sender_ip = self._normalize_ip(host.toString())
            
            if sender_ip == "127.0.0.1" or sender_ip == self.my_ip:
                continue
                
            try:
                packet = json.loads(data.decode('utf-8'))
                packet_type = packet.get('type')
                
                if packet_type == 'PING':
                    print(f"DEBUG: Received PING from {sender_ip}")
                    pong_packet = {
                        'type': 'PONG',
                        'timestamp': time.time()
                    }
                    self._kk_send_udp_to(sender_ip, pong_packet)
                    
                elif packet_type == 'PONG':
                    print(f"DEBUG: Received PONG from {sender_ip}")
                    if sender_ip in self.kk_ping_timers:
                        self.kk_ping_timers[sender_ip].stop()
                        del self.kk_ping_timers[sender_ip]
                    
                    was_offline = sender_ip not in self.kk_online_peers
                    self.kk_online_peers[sender_ip] = time.time()
                    
                    if was_offline:
                        self.kk_peer_online.emit(sender_ip)
                        QTimer.singleShot(2000, self._retry_offline_messages)
                    
                    self.kk_ping_response_received.emit(sender_ip)
                        
                elif packet_type == 'ONLINE':
                    print(f"DEBUG: Ignoring ONLINE notification from {sender_ip}")
                        
                elif packet_type == 'OFFLINE':
                    if sender_ip in self.kk_online_peers:
                        del self.kk_online_peers[sender_ip]
                        print(f"DEBUG: {sender_ip} went offline")
                        self.kk_peer_offline.emit(sender_ip)
                        
                elif packet_type == 'MESSAGE':
                    sender_name = packet.get('sender_name', sender_ip)
                    image_data = packet.get('image_data', '')
                    print(f"DEBUG: Message from {sender_name}: {packet['content']}")
                    self.kk_message_received.emit(sender_ip, packet['content'], sender_name, image_data)
                    
                elif packet_type == 'DISTRIBUTION':
                    compressed = base64.b64decode(packet['data'])
                    if hashlib.sha256(compressed).hexdigest()[:16] != packet['checksum']:
                        raise ValueError("체크섬 불일치")
                    decompressed = zstd.decompress(compressed)
                    dist_data = json.loads(decompressed.decode('utf-8'))
                    self.kk_distribution_received.emit(sender_ip, dist_data)
                    
                elif packet_type == 'LAS':
                    self.kk_las_received.emit(sender_ip, packet)
                    
            except Exception as e:
                print(f"UDP 패킷 처리 오류 from {sender_ip}: {e}")
                
    def _kk_on_tcp_connection(self):
        socket = self.kk_tcp_server.nextPendingConnection()
        if socket:
            thread = KKTcpReceiverThread(socket)
            thread.data_received.connect(self._kk_on_tcp_data_received)
            thread.finished.connect(thread.deleteLater)
            thread.start()
            
    def _kk_on_tcp_data_received(self, sender_ip, data):
        try:
            sender_ip = self._normalize_ip(sender_ip)
            
            if isinstance(data, dict) and data.get('type') == 'IMAGE_MESSAGE':
                print(f"DEBUG: Received image message via TCP from {sender_ip}")
                
                message_data = data.get('message_data', {})
                image_data = data.get('image_data', '')
                
                self.kk_message_received.emit(
                    sender_ip,
                    message_data.get('content', '[이미지]'),
                    message_data.get('sender_name', sender_ip),
                    image_data
                )
            else:
                self.kk_distribution_received.emit(sender_ip, data)
                
        except Exception as e:
            print(f"TCP 오류: {e}")
            
    def _kk_send_online_notification(self):
        packet = {
            'type': 'ONLINE',
            'timestamp': time.time()
        }
        self._kk_send_udp_broadcast(packet)
        
    def _kk_send_offline_notification(self):
        packet = {
            'type': 'OFFLINE',
            'timestamp': time.time()
        }
        self._kk_send_udp_broadcast(packet)
        
    def get_offline_message_count(self, target_ip):
        return len(self.kk_offline_messages.get(target_ip, []))


class KKTcpSenderThread(QThread):
    
    def __init__(self, target_ip, port, data):
        super().__init__()
        self.target_ip = target_ip
        self.port = port
        self.data = data
        
    def run(self):
        try:
            socket = QTcpSocket()
            socket.connectToHost(self.target_ip, self.port)
            
            if socket.waitForConnected(5000):
                json_bytes = json.dumps(self.data).encode('utf-8')
                compressed = zstd.compress(json_bytes, 11)
                
                size_bytes = len(compressed).to_bytes(8, 'big')
                socket.write(size_bytes)
                
                socket.write(compressed)
                socket.waitForBytesWritten()
                
                socket.close()
                
        except Exception as e:
            print(f"TCP 전송 오류: {e}")


class KKTcpReceiverThread(QThread):
    
    data_received = pyqtSignal(str, dict)
    
    def __init__(self, socket):
        super().__init__()
        self.socket = socket
        
    def run(self):
        try:
            sender_ip = self._normalize_ip(self.socket.peerAddress().toString())
            
            if self.socket.waitForReadyRead(5000):
                size_bytes = self.socket.read(8)
                data_size = int.from_bytes(size_bytes, 'big')
                
                received_data = b''
                while len(received_data) < data_size:
                    if self.socket.waitForReadyRead(5000):
                        chunk = self.socket.read(data_size - len(received_data))
                        received_data += chunk
                    else:
                        break
                
                print(f"DEBUG: Received {len(received_data)} bytes via TCP")
                
                try:
                    data = json.loads(received_data.decode('utf-8'))
                    print("DEBUG: Decoded as uncompressed JSON")
                except (json.JSONDecodeError, UnicodeDecodeError):

                    try:
                        decompressed = zstd.decompress(received_data)
                        data = json.loads(decompressed.decode('utf-8'))
                        print("DEBUG: Decoded as compressed JSON")
                    except Exception as e:
                        print(f"ERROR: Failed to decode TCP data: {e}")
                        return
                
                self.data_received.emit(sender_ip, data)
                
            self.socket.close()
            
        except Exception as e:
            print(f"TCP 수신 오류: {e}")
            
    def _normalize_ip(self, ip):
        if ip.startswith("::ffff:"):
            return ip[7:]
        return ip


class KKImageSenderThread(QThread):
    
    def __init__(self, target_ip, port, image_packet):
        super().__init__()
        self.target_ip = target_ip
        self.port = port
        self.image_packet = image_packet
        self.socket = None
        
    def run(self):
        try:
            print(f"DEBUG: Starting image TCP connection to {self.target_ip}:{self.port}")
            
            self.socket = QTcpSocket()
            self.socket.connectToHost(self.target_ip, self.port)
            
            if self.socket.waitForConnected(5000):
                print("DEBUG: TCP connection established for image")

                try:
                    json_data = json.dumps(self.image_packet).encode('utf-8')
                    data_size = len(json_data)

                    if data_size > 10 * 1024 * 1024:
                        print(f"ERROR: Data too large: {data_size} bytes")
                        return
                    
                    print(f"DEBUG: Sending image packet size: {data_size} bytes")

                    size_bytes = data_size.to_bytes(8, 'big')
                    if self.socket.write(size_bytes) == -1:
                        print("ERROR: Failed to write size bytes")
                        return
                        
                    if not self.socket.waitForBytesWritten(3000):
                        print("ERROR: Timeout writing size bytes")
                        return

                    chunk_size = 4096
                    bytes_sent = 0
                    
                    while bytes_sent < data_size:
                        if self.isInterruptionRequested():
                            print("DEBUG: Thread interruption requested")
                            break
                            
                        chunk_end = min(bytes_sent + chunk_size, data_size)
                        chunk = json_data[bytes_sent:chunk_end]
                        
                        bytes_written = self.socket.write(chunk)
                        if bytes_written == -1:
                            print("ERROR: Failed to write data to socket")
                            break
                            
                        if not self.socket.waitForBytesWritten(3000):
                            print("ERROR: Timeout writing data chunk")
                            break
                            
                        bytes_sent += len(chunk)
                        
                        if bytes_sent % (chunk_size * 10) == 0:
                            print(f"DEBUG: Sent {bytes_sent}/{data_size} bytes ({bytes_sent/data_size*100:.1f}%)")
                    
                    if bytes_sent == data_size:
                        print("DEBUG: Image transmission completed successfully")
                    else:
                        print(f"DEBUG: Image transmission incomplete: {bytes_sent}/{data_size} bytes")
                    
                except Exception as e:
                    print(f"ERROR: JSON serialization or transmission failed: {e}")
                    
            else:
                print(f"ERROR: Failed to connect to {self.target_ip}:{self.port} - {self.socket.errorString()}")
                
        except Exception as e:
            print(f"ERROR: Image TCP transmission failed: {e}")
            import traceback
            traceback.print_exc()
            
        finally:
            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None