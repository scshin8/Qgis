import json
import base64
import zstandard as zstd
from PyQt5.QtCore import QDate, QDateTime
from .kk_field_mapping import KKFieldMapping

class KKEncoder:
    
    @staticmethod
    def kk_encode_features(features, fields, key_field):
        data = {
            'version': '2.0',
            'key_field': key_field,
            'fields': fields,
            'features': []
        }
        
        for feature in features:
            feature_data = {}
            for field in fields:
                value = feature[field]
                
                formatted_value = KKFieldMapping.format_value(field, value)
                feature_data[field] = formatted_value
                
            data['features'].append(feature_data)
            
        json_str = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
        compressed = zstd.compress(json_str.encode('utf-8'), 11)
        encoded = base64.b64encode(compressed).decode('ascii')
        
        return encoded
        
    @staticmethod
    def kk_decode_features(encoded_data):
        try:
            compressed = base64.b64decode(encoded_data)
            decompressed = zstd.decompress(compressed)
            data = json.loads(decompressed.decode('utf-8'))
            
            return data
            
        except Exception as e:
            raise ValueError(f"디코딩 오류: {str(e)}")