from PyQt5.QtCore import QDate, QDateTime
from enum import Enum

class FieldType(Enum):
    STRING = "String"
    DATE = "Date"
    REAL = "Real"

class KKFieldMapping:
    
    FIELDS = {
        'operator': FieldType.STRING,
        'Progress': FieldType.STRING,
        'st_date': FieldType.DATE,
        'ed_date': FieldType.DATE,
        'Report': FieldType.STRING,
        'Group': FieldType.STRING,
        'key': FieldType.STRING,
        'length': FieldType.REAL,
        'work_history': FieldType.STRING
    }
    
    # 필드
    ESSENTIAL_FIELDS = ['key', 'operator', 'Progress', 'st_date', 'ed_date']
    
    # 날짜
    DATE_FORMAT = 'yyyy-MM-dd'
    
    @classmethod
    def get_field_type(cls, field_name):
        return cls.FIELDS.get(field_name, FieldType.STRING)
    
    @classmethod
    def is_date_field(cls, field_name):
        return cls.get_field_type(field_name) == FieldType.DATE
    
    @classmethod
    def is_real_field(cls, field_name):
        return cls.get_field_type(field_name) == FieldType.REAL
    
    @classmethod
    def is_string_field(cls, field_name):
        return cls.get_field_type(field_name) == FieldType.STRING
    
    @classmethod
    def is_essential_field(cls, field_name):
        return field_name in cls.ESSENTIAL_FIELDS
    
    @classmethod
    def format_value(cls, field_name, value):
        if value is None:
            return ''
            
        field_type = cls.get_field_type(field_name)
        
        if field_type == FieldType.DATE:
            return cls._format_date_value(value)
        elif field_type == FieldType.REAL:
            return cls._format_real_value(value)
        else: 
            return str(value)
    
    @classmethod
    def _format_date_value(cls, value):
        if value is None:
            return ''
            
        if isinstance(value, QDateTime):
            return value.date().toString(cls.DATE_FORMAT)
        elif isinstance(value, QDate):
            return value.toString(cls.DATE_FORMAT)
        
        if isinstance(value, str):
            value_str = value.strip()
            if not value_str:
                return ''
                
            if len(value_str) == 10 and value_str[4] == '-' and value_str[7] == '-':
                try:
                    year, month, day = value_str.split('-')
                    if 1900 <= int(year) <= 2100 and 1 <= int(month) <= 12 and 1 <= int(day) <= 31:
                        return value_str
                except:
                    pass
            
            date_formats = [
                "yyyy-MM-dd",
                "yyyyMMdd", 
                "yyyy/MM/dd",
                "dd/MM/yyyy",
                "dd-MM-yyyy",
                "yyyy.MM.dd",
                "dd.MM.yyyy",
                "yy-MM-dd",
                "MM/dd/yyyy"
            ]
            
            for fmt in date_formats:
                qdate = QDate.fromString(value_str, fmt)
                if qdate.isValid():
                    return qdate.toString(cls.DATE_FORMAT)
            
            if len(value_str) == 8 and value_str.isdigit():
                try:
                    year = int(value_str[:4])
                    month = int(value_str[4:6])
                    day = int(value_str[6:8])
                    if 1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31:
                        return f"{year:04d}-{month:02d}-{day:02d}"
                except:
                    pass
                    
            return value_str
        
        return str(value)
    
    @classmethod
    def _format_real_value(cls, value):
        try:
            if isinstance(value, str) and value.strip() == '':
                return ''
            return str(float(value))
        except (ValueError, TypeError):
            return '0.0'
    
    @classmethod
    def parse_value(cls, field_name, value_str):
        if not value_str or value_str.strip() == '':
            return None
            
        field_type = cls.get_field_type(field_name)
        
        if field_type == FieldType.DATE:
            return value_str 
        elif field_type == FieldType.REAL:
            try:
                return float(value_str)
            except (ValueError, TypeError):
                return 0.0
        else:
            return str(value_str)
    
    @classmethod
    def get_all_field_names(cls):
        return list(cls.FIELDS.keys())
    
    @classmethod
    def get_date_field_names(cls):
        return [name for name, field_type in cls.FIELDS.items() if field_type == FieldType.DATE]
    
    @classmethod
    def get_real_field_names(cls):
        return [name for name, field_type in cls.FIELDS.items() if field_type == FieldType.REAL]
    
    @classmethod
    def get_string_field_names(cls):
        return [name for name, field_type in cls.FIELDS.items() if field_type == FieldType.STRING]