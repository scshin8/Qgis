
def classFactory(iface):
    from .pipi import KKPlugin
    return KKPlugin(iface)