# -*- coding: utf-8 -*-

def classFactory(iface):
    from .custom_toolbar import CustomToolbar
    return CustomToolbar(iface)