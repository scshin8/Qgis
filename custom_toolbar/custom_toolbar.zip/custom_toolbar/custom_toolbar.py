# -*- coding: utf-8 -*-
# =============================================================================
#  custom_toolbar  —  QGIS 커스텀 툴바 구성 플러그인
# =============================================================================
#
#  [목적]
#   여러 플러그인/기본 기능의 툴바·메뉴 아이콘 중 실제로 쓰는 것만 골라,
#   사용자가 원하는 순서·구성으로 나만의 커스텀 툴바를 만든다.
#
#  [UI 구성] (open_dialog)
#   좌: 검색 + 카테고리 콤보 + 스냅(▲이전/▼다음) + 소스 트리(전체 기능 목록)
#   중앙: 조작 버튼들 (추가/제거/위/아래/그룹화/그룹해제/그룹에서 분리)
#         → 선택 상태에 따라 각 버튼이 조건부 활성화 (_update_buttons)
#   우: 커스텀 툴바 선택 콤보 + 추가/삭제 + 구성 트리(현재 담긴 항목)
#
#  [주요 기능]
#   - 커스텀 툴바 여러 개 생성/삭제/전환
#   - 툴바·메뉴 액션을 개별 또는 드롭다운(묶음) 단위로 추가/제거
#   - 그룹화(묶기) / 그룹 해제(펼치기) / 그룹에서 자식 분리
#   - 실시간 반영: 추가·제거·순서변경 즉시 실제 QGIS 툴바에 반영 (rebuild_bar)
#   - QSettings 저장/복원: QGIS 재시작 후에도 커스텀 툴바 유지
#   - 검색 + 카테고리 콤보(전체/안 담은 것만/기본·플러그인 툴바·메뉴)로 필터
#   - 스냅: 커스텀 툴바에 담은 기능 위치로 왼쪽 트리에서 빠르게 이동
#   - 중앙 버튼 다중 선택 지원: 여러 항목을 함께 위/아래 이동
#
#  [핵심 설계 원칙 — 개발 중 확정된 것들]
#   1) 드롭다운 재현은 "원본 QToolButton 이동" 금지 (원본 툴바에서 사라짐).
#      → 새 QToolButton을 만들어 원본 '액션'만 메뉴에 담는다(make_dropdown_button).
#        원본은 절대 훼손하지 않는다.
#   2) 드롭다운 팝업은 InstantPopup 사용.
#      → MenuButtonPopup + setDefaultAction 은 좌표도구 등 일부 플러그인의
#        내부 버튼 참조(self.copy)와 충돌하므로 쓰지 않는다.
#   3) 액션 식별 키(action_key): objectName 우선, 없으면 텍스트 기반.
#   4) 저장은 dict 리스트(type/child_keys 등)로 → 사용자 묶음/편집 드롭다운도
#      자식 키로 복원 가능.
#   5) 리로드 시 커스텀 툴바는 삭제하지 않고 남긴다(참조만 정리) →
#      죽은 QToolBar 참조는 sip.isdeleted 로 방어.
#   6) 다중 선택 이동(move_item): 이동 전에 아이템 객체를 미리 확보해야 함
#      (removeChild/insertChild 하면 인덱스가 바뀌므로). 선택 복원 시
#      setCurrentItem을 먼저 → setSelected를 나중에 (current가 선택을 리셋하므로).
#
#  [저장 구조 (QSettings)]
#   - CustomToolbar/bars           : 커스텀 툴바 이름 목록
#   - CustomToolbar/bar/<이름>     : 그 툴바 구성 (dict 리스트)
#       개별   → {'type':'action', 'key':...}
#       드롭다운 → {'type':'dropdown','rep':...,'objname':...,'child_keys':[...]}
#
#  [데이터 튜플 형식 — 트리 아이템의 UserRole에 저장]
#   ('action',  QAction)                                 : 개별 기능
#   ('dropdown', 대표텍스트, objectName, [자식액션,...])  : 드롭다운(묶음)
#
#  [아이콘 규칙]
#   - 툴바/메뉴 드롭다운: 원본 고유 아이콘(_dd_icons 매핑), 없으면 빈 아이콘
#   - 사용자 묶음 그룹(objname이 '묶음:'/'그룹:'): group.png 폴더 아이콘
#
#  [기본/플러그인 구분]
#   - 툴바: objectName 이 'm'으로 시작 + 'ToolBar'로 끝나면 QGIS 기본, 아니면 플러그인
#   - 메뉴: objectName 이 'm'으로 시작 + 'Menu'로 끝나면 기본, 아니면 플러그인
# =============================================================================
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QTreeWidget, QTreeWidgetItem, QToolBar, QLabel, QToolButton,
    QComboBox, QLineEdit, QMessageBox, QMenu, QAbstractItemView, QCheckBox
)
from qgis.PyQt.QtGui import QIcon, QColor, QPixmap, QPainter, QFont
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt import sip
import os, re

BAR_OBJNAME_PREFIX = 'CustomToolbar_Bar_'
BARS_KEY = 'CustomToolbar/bars'
BAR_ACTIONS_KEY = 'CustomToolbar/bar/'

class CustomToolbar:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None
        self.bars = {}
        self.plugin_dir = os.path.dirname(__file__)
        self.fallback_icon = QIcon(self.plugin_dir + '/icon-wizard.png')  # 플러그인 버튼용
        self._dd_icons = {}          # objectName → 드롭다운 대표 아이콘 (현실 아이콘 그대로)
        self.group_icon = QIcon(self.plugin_dir + '/group.png')  # 사용자 묶음 그룹 아이콘
        # 추가할 부분: 숫자 오버레이 아이콘 캐시
        self._numbered_group_icons = {}

    def initGui(self):
        # 플러그인 로드 시: 설정창 여는 툴바 버튼 등록 + 저장된 커스텀 툴바 복원
        self.action = QAction(self.fallback_icon, '커스텀 툴바 설정', self.iface.mainWindow())
        self.action.triggered.connect(self.open_dialog)
        self.iface.addToolBarIcon(self.action)
        self.restore_all()

    def unload(self):
        # 플러그인 언로드 시: 등록한 버튼/다이얼로그 정리 (커스텀 툴바 자체는 남김)
        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dlg is not None:
            self.dlg.close()
            self.dlg = None
        self.bars = {}

    # ── objectName 규칙 ────────────────────────────────────────────
    def objname_of(self, bar_name):
        # 커스텀 툴바 이름 → QToolBar objectName (접두어 부착)
        return BAR_OBJNAME_PREFIX + bar_name

    # ── 특정 이름의 커스텀 툴바 확보 ────────────────────────────────
    def ensure_bar(self, bar_name):
        # 이름에 해당하는 커스텀 툴바 확보 (없거나 죽었으면 새로 생성). sip로 죽은 참조 방어
        bar = self.bars.get(bar_name)
        if bar is not None and sip.isdeleted(bar):
            bar = None
        if bar is None:
            objn = self.objname_of(bar_name)
            bar = self.iface.mainWindow().findChild(QToolBar, objn)
            if bar is not None and sip.isdeleted(bar):
                bar = None
        if bar is None:
            bar = self.iface.addToolBar(bar_name)
            bar.setObjectName(self.objname_of(bar_name))
        self.bars[bar_name] = bar
        return bar

    # ── 액션 식별 키 ────────────────────────────────────────────────
    def action_key(self, act):
        # 액션 식별 키: objectName 있으면 obj:, 없으면 txt:텍스트
        name = act.objectName()
        if name:
            return 'obj:' + name
        return 'txt:' + act.text().replace('&', '').strip()

    # ── 드롭다운 식별 키 ───────────────────────────────────────────
    def dropdown_key(self, objname, subs):
        # 드롭다운 식별 키: objectName 우선(dd:obj:), 없으면 첫 자식 텍스트(dd:txt:)
        if objname:
            return 'dd:obj:' + objname
        if subs:
            return 'dd:txt:' + subs[0].text().replace('&', '').strip()
        return 'dd:unknown'
    
    # 숫자가 덧그려진 아이콘을 생성하는 로직입니다.
    def _get_numbered_group_icon(self, num_str):
        # 숫자가 없으면 기본 그룹 아이콘 반환
        if not num_str:
            return self.group_icon
            
        # 이미 생성된 아이콘이 있으면 캐시에서 반환
        if num_str in self._numbered_group_icons:
            return self._numbered_group_icons[num_str]
            
        # 원본 퍼즐 이미지 로드
        pixmap = QPixmap(self.plugin_dir + '/group.png')
        if pixmap.isNull():
            return self.group_icon
            
        # 이미지 위에 그리기
        painter = QPainter(pixmap)
        
        # 폰트 크기를 원본 이미지 해상도에 비례하도록 픽셀 단위로 크게 설정
        font = QFont("Arial")
        font.setPixelSize(int(pixmap.height() * 0.5))  # 픽스맵 높이의 50% 크기로 설정
        font.setBold(True)
        painter.setFont(font)
        
        rect = pixmap.rect()
        # --- 수정 및 추가할 부분 시작 ---
        # 1. 글자를 아래로 내릴 픽셀 값 계산 (이미지 높이의 약 15% 정도 아래로 이동)
        shift_y = int(pixmap.height() * 0.15) 
        
        # 2. 위쪽(top) 여백을 shift_y만큼 밀어낸 새로운 영역 생성
        shifted_rect = rect.adjusted(0, shift_y, 0, 0)

        # 글자 시인성을 위한 하얀색 그림자 오프셋도 이미지 크기에 비례하여 키움
        offset = max(1, int(pixmap.height() * 0.05))
        
        painter.setPen(QColor(Qt.white))
        painter.drawText(shifted_rect.adjusted(offset, offset, offset, offset), Qt.AlignCenter, num_str)
        
        # 실제 검은색 숫자 오버레이
        painter.setPen(QColor(Qt.black))
        painter.drawText(shifted_rect, Qt.AlignCenter, num_str)
        
        painter.end()
        
        # QIcon으로 변환 후 캐시에 저장
        icon = QIcon(pixmap)
        self._numbered_group_icons[num_str] = icon
        return icon

    def dropdown_icon(self, subs, objname=''):
        """드롭다운 대표 아이콘.
        - 사용자 묶음 그룹(묶음:/그룹:) → 번호가 들어간 퍼즐 아이콘
        - 원본 드롭다운 → 고유 아이콘(매핑), 없으면 빈 아이콘"""
        
        if objname.startswith('묶음:') or objname.startswith('그룹:'):
            # 정규표현식으로 숫자만 추출
            match = re.search(r'\d+', objname)
            num_str = match.group(0) if match else ''
            
            # 숫자 오버레이 아이콘 생성 함수 호출
            return self._get_numbered_group_icon(num_str)
            
        if objname and objname in self._dd_icons:
            ic = self._dd_icons[objname]
            if ic is not None and not ic.isNull():
                return ic
        return QIcon()

    # ── 드롭다운 버튼 생성 (InstantPopup, 원본 안전) ───────────────
    def make_dropdown_button(self, bar, subs, rep_icon=None, rep_text='', objname=''):
        # 커스텀 툴바에 새 QToolButton(InstantPopup) 생성 후 원본 액션들을 메뉴에 담음. 원본 위젯은 안 건드림
        btn = QToolButton(bar)
        btn.setPopupMode(QToolButton.InstantPopup)
        if objname:
            btn.setObjectName(objname)       # 원본과 같은 키가 되도록 objectName 부여
        menu = QMenu(btn)
        for s in subs:
            menu.addAction(s)                # 원본 액션 재사용
        btn.setMenu(menu)
        if rep_icon is not None and not rep_icon.isNull():
            btn.setIcon(rep_icon)
        else:
            btn.setIcon(self.dropdown_icon(subs, objname))    # 고유 아이콘 우선
        btn.setToolTip(rep_text or (subs[0].text().replace('&', '').strip() if subs else ''))
        bar.addWidget(btn)
        return btn

    # ── 전체 툴바 → {툴바이름: [항목,...]} ─────────────────────────
    #   항목: ('action', QAction) / ('dropdown', 대표텍스트, objectName, [자식...])
    def collect_toolbars(self):
        # QGIS 모든 툴바를 훑어 {툴바이름: [항목,...]} 반환. 드롭다운(자식2개+)은 통째로, 아이콘은 _dd_icons에 기억
        result = {}
        my_objnames = set(self.objname_of(n) for n in self.list_bar_names())
        for tb in self.iface.mainWindow().findChildren(QToolBar):
            if tb.objectName() in my_objnames:
                continue
            title = tb.windowTitle().strip()
            if not title:
                continue
            items = []
            seen = set()

            for a in tb.actions():
                if a.isSeparator():
                    continue
                w = tb.widgetForAction(a)
                if isinstance(w, QToolButton) and len(w.actions()) >= 2:
                    subs = []
                    for sub in w.actions():
                        if sub.isSeparator():
                            continue
                        t = sub.text().replace('&', '').strip()
                        if not t or id(sub) in seen:
                            continue
                        seen.add(id(sub))
                        subs.append(sub)
                    if len(subs) >= 2:
                        rep = w.text().replace('&', '').strip()
                        if not rep:
                            rep = subs[0].text().replace('&', '').strip()
                        if w.objectName():                # 버튼 고유 아이콘 기억
                            self._dd_icons[w.objectName()] = w.icon()
                        items.append(('dropdown', rep, w.objectName(), subs))
                    elif len(subs) == 1:
                        items.append(('action', subs[0]))
                else:
                    t = a.text().replace('&', '').strip()
                    if not t or id(a) in seen:
                        continue
                    seen.add(id(a))
                    items.append(('action', a))

            if items:
                result[title] = items
        return result

    # ── 메뉴바 → {'[메뉴] 이름': [('action',액션)/('dropdown',...)] } ─
    def collect_menus(self):
        # 메뉴바를 훑어 {[메뉴]이름: [항목,...]} 반환. 서브메뉴는 드롭다운으로, 툴바에 이미 있는 액션은 제외
        toolbar_ids = set()
        for items in self.collect_toolbars().values():
            for item in items:
                if item[0] == 'action':
                    toolbar_ids.add(id(item[1]))
                elif item[0] == 'dropdown':
                    for s in item[3]:
                        toolbar_ids.add(id(s))

        result = {}
        menubar = self.iface.mainWindow().menuBar()
        for top_act in menubar.actions():
            menu = top_act.menu()
            if menu is None:
                continue
            title = top_act.text().replace('&', '').strip()
            if not title:
                continue

            items = []
            seen = set()

            # 서브메뉴 안의 실제 실행 액션들을 평평하게 모은다 (툴바에 있는 건 제외)
            def collect_subactions(m):
                subs = []
                for a in m.actions():
                    if a.isSeparator():
                        continue
                    inner = a.menu()
                    if inner is not None:                 # 중첩 서브메뉴는 안으로
                        st = a.text().replace('&', '').strip()
                        if st.startswith('최근 열기'):
                            continue
                        subs.extend(collect_subactions(inner))
                        continue
                    t = a.text().replace('&', '').strip()
                    if not t:
                        continue
                    if id(a) in toolbar_ids:
                        continue
                    if id(a) in seen:
                        continue
                    seen.add(id(a))
                    subs.append(a)
                return subs

            for a in menu.actions():
                if a.isSeparator():
                    continue
                sub = a.menu()
                if sub is not None:
                    sub_title = a.text().replace('&', '').strip()
                    if sub_title.startswith('최근 열기'):
                        continue
                    subs = collect_subactions(sub)        # 이 서브메뉴 안 기능들
                    if len(subs) >= 2:
                        # 서브메뉴 제목을 objectName 자리에 넣어 드롭다운 키 안정화
                        objn = '메뉴:' + sub_title
                        self._dd_icons[objn] = a.icon()   # 서브메뉴 고유 아이콘 기억
                        items.append(('dropdown', sub_title, objn, subs))
                    elif len(subs) == 1:
                        items.append(('action', subs[0]))
                    # subs 0개면 스킵 (전부 툴바에 있음)
                else:
                    t = a.text().replace('&', '').strip()
                    if not t:
                        continue
                    if id(a) in toolbar_ids:
                        continue
                    if id(a) in seen:
                        continue
                    seen.add(id(a))
                    items.append(('action', a))

            if items:
                result['[메뉴] ' + title] = items
        return result

    # ── 툴바 이름 목록 (QSettings) ─────────────────────────────────
    def list_bar_names(self):
        # QSettings에서 커스텀 툴바 이름 목록 읽기
        names = QSettings().value(BARS_KEY, [])
        if isinstance(names, str):
            names = [names]
        return list(names) if names else []

    def set_bar_names(self, names):
        # QSettings에 커스텀 툴바 이름 목록 저장
        QSettings().setValue(BARS_KEY, names)

    # ── 액션 키 → 액션 매핑 (개별 + 드롭다운 자식) ─────────────────
    def build_action_map(self):
        # 복원용: 액션키 → 액션 객체 매핑 (툴바+메뉴, 드롭다운 자식 포함)
        all_acts = {}
        groups = self.collect_toolbars()
        groups.update(self.collect_menus())
        for title, items in groups.items():
            for item in items:
                if item[0] == 'action':
                    all_acts[self.action_key(item[1])] = item[1]
                elif item[0] == 'dropdown':
                    for s in item[3]:
                        all_acts[self.action_key(s)] = s
        return all_acts

    # ── 드롭다운 키 → (대표명, objectName, 자식들) 매핑 ─────────────
    def build_dropdown_map(self):
        # 복원용: 드롭다운키 → (대표명, objectName, 자식들) 매핑
        all_dd = {}
        groups = self.collect_toolbars()
        groups.update(self.collect_menus())        # 메뉴 서브메뉴 드롭다운도 포함
        for title, items in groups.items():
            for item in items:
                if item[0] == 'dropdown':
                    rep, objname, subs = item[1], item[2], item[3]
                    key = self.dropdown_key(objname, subs)
                    all_dd[key] = (rep, objname, subs)
        return all_dd

    # ── 다이얼로그 ──────────────────────────────────────────────────
    def open_dialog(self):
        # 설정 다이얼로그 구성: 좌(검색+카테고리콤보+소스트리) / 중앙(조작버튼) / 우(툴바콤보+구성트리)
        self.dlg = QDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle('커스텀 툴바 설정')
        self.dlg.resize(760, 640)
        outer = QVBoxLayout(self.dlg)

        split = QHBoxLayout()

        # 왼쪽: 검색 + 카테고리 콤보 + 기능 소스 트리
        left = QVBoxLayout()
        self.search = QLineEdit()                    # 검색칸을 왼쪽 위로 이동
        self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText('기능 검색...')
        self.search.textChanged.connect(lambda _: self.apply_filter())
        left.addWidget(self.search)

        # self.cat_combo = QComboBox()                 # 카테고리(그룹) 필터 콤보
        # self.cat_combo.currentIndexChanged.connect(lambda _: self.populate_tree())
        # left.addWidget(self.cat_combo)

        jump_row = QHBoxLayout()
        self.cat_combo = QComboBox()                 # 카테고리(그룹) 필터 콤보
        self.cat_combo.currentIndexChanged.connect(lambda _: self.populate_tree())
        btn_prev = QPushButton('▲ 이전')
        btn_next = QPushButton('▼ 다음')
        btn_prev.clicked.connect(lambda: self.jump_added(-1))
        btn_next.clicked.connect(lambda: self.jump_added(1))
        jump_row.addWidget(self.cat_combo)
        jump_row.addWidget(btn_prev)
        jump_row.addWidget(btn_next)
        left.addLayout(jump_row)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.itemSelectionChanged.connect(self.on_left_selection_changed) # 선택 변경 시 버튼 활성화 갱신

        left.addWidget(self.tree)
        split.addLayout(left, 3)

        # 가운데: 조작 버튼
        mid = QVBoxLayout()
        mid.addStretch(1)
        self.btn_to_right = QPushButton('추가 →')
        self.btn_to_left = QPushButton('← 제거')
        self.btn_to_right.clicked.connect(self.add_selected)
        self.btn_to_left.clicked.connect(self.remove_selected)
        mid.addWidget(self.btn_to_right)
        mid.addWidget(self.btn_to_left)
        mid.addSpacing(10)
        self.btn_up = QPushButton('▲ 위   로')
        self.btn_down = QPushButton('▼ 아래로')
        self.btn_up.clicked.connect(lambda: self.move_item(-1))
        self.btn_down.clicked.connect(lambda: self.move_item(1))
        mid.addWidget(self.btn_up)
        mid.addWidget(self.btn_down)
        mid.addSpacing(20)
        self.btn_group = QPushButton('그 룹 화')
        self.btn_group.clicked.connect(self.group_selected)
        mid.addWidget(self.btn_group)
        self.btn_explode = QPushButton('그룹 해제')
        self.btn_explode.clicked.connect(self.explode_dropdown)
        mid.addWidget(self.btn_explode)
        self.btn_detach = QPushButton('그룹에서 분리')
        self.btn_detach.clicked.connect(self.detach_children)
        mid.addWidget(self.btn_detach)
        mid.addStretch(1)
        split.addLayout(mid, 0)

        # 오른쪽: 툴바 선택 콤보 + 추가/삭제 + 커스텀 툴바 구성 (트리)
        right = QVBoxLayout()
        bar_row = QHBoxLayout()                       # 툴바 콤보를 오른쪽 위로 이동
        self.combo = QComboBox()
        self.combo.currentIndexChanged.connect(self.on_bar_changed)
        btn_add = QPushButton('추 가')
        btn_del = QPushButton('삭 제')
        btn_add.clicked.connect(self.add_bar)
        btn_del.clicked.connect(self.del_bar)
        bar_row.addWidget(self.combo, 1)
        bar_row.addWidget(btn_add)
        bar_row.addWidget(btn_del)
        right.addLayout(bar_row)

        label_layout = QHBoxLayout()
        label = QLabel('커스텀 툴바 구성')
        label.setFixedHeight(self.cat_combo.sizeHint().height())
        
        self.chk_show_title = QCheckBox('이름표 추가')
        self.chk_show_title.stateChanged.connect(self.on_show_title_changed)
        
        label_layout.addWidget(label)
        label_layout.addStretch(1) # 라벨과 체크박스 사이를 벌려줍니다
        label_layout.addWidget(self.chk_show_title)
        
        right.addLayout(label_layout)

        self.right_list = QTreeWidget()                 # 이름 유지, 타입만 트리
        self.right_list.setHeaderHidden(True)
        self.right_list.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.right_list.itemSelectionChanged.connect(self.on_right_selection_changed) # 선택 변경 시 버튼 갱신
        right.addWidget(self.right_list)
        split.addLayout(right, 3)

        outer.addLayout(split)

        btn_reload = QPushButton('목록 새로고침')
        btn_reload.clicked.connect(self.refresh_all)
        outer.addWidget(btn_reload)

        self.reload_combo()
        self.reload_cat_combo()
        
        # refresh_all() 대신 on_bar_changed를 직접 호출하여 
        # 체크박스 상태를 읽어온 뒤 화면을 새로고침하도록 유도합니다.
        self.on_bar_changed(self.combo.currentIndex()) 
        
        self.dlg.show()
        self.dlg.raise_()

    # ── 콤보 채우기 ────────────────────────────────────────────────
    def reload_combo(self):
        # 오른쪽 상단 커스텀 툴바 선택 콤보 채우기
        self.combo.blockSignals(True)
        self.combo.clear()
        names = self.list_bar_names()
        self.combo.addItems(names)
        self.combo.blockSignals(False)

    # ── 카테고리(그룹) 콤보 채우기 ─────────────────────────────────
    def reload_cat_combo(self):
        """특수항목 / 기본 툴바 / 플러그인 툴바 / 메뉴 (사이에 구분선)."""
        self.cat_combo.blockSignals(True)
        self.cat_combo.clear()

        # 1) 특수항목
        self.cat_combo.addItem('전체')
        self.cat_combo.addItem('안 담은 기능만')

        # 툴바 이름 → objectName 매핑 (기본/플러그인 판별용)
        name_to_obj = {}
        for tb in self.iface.mainWindow().findChildren(QToolBar):
            t = tb.windowTitle().strip()
            if t:
                name_to_obj[t] = tb.objectName()

        def is_builtin(title):
            objn = name_to_obj.get(title, '')
            return objn.startswith('m') and objn.endswith('ToolBar')

        # collect_toolbars 그룹을 기본/플러그인으로 분류
        tb_titles = list(self.collect_toolbars().keys())
        builtin = [t for t in tb_titles if is_builtin(t)]
        plugin = [t for t in tb_titles if not is_builtin(t)]

        # 2) 기본 툴바
        if builtin:
            self.cat_combo.insertSeparator(self.cat_combo.count())
            for t in builtin:
                self.cat_combo.addItem(t)

        # 3) 플러그인 툴바
        if plugin:
            self.cat_combo.insertSeparator(self.cat_combo.count())
            for t in plugin:
                self.cat_combo.addItem(t)

        # 4) 메뉴 그룹
        menu_titles = list(self.collect_menus().keys())
        if menu_titles:
            self.cat_combo.insertSeparator(self.cat_combo.count())
            for t in menu_titles:
                self.cat_combo.addItem(t)

        self.cat_combo.blockSignals(False)

    def current_bar_name(self):
        # 현재 선택된 커스텀 툴바 이름
        if self.combo.count() == 0:
            return None
        return self.combo.currentText()

    # ── 툴바 추가 ──────────────────────────────────────────────────
    def add_bar(self):
        # 새 커스텀 툴바 추가 (이름 자동 "커스텀 N")
        names = self.list_bar_names()
        n = 1
        while ('커스텀 %d' % n) in names:
            n += 1
        name = '커스텀 %d' % n
        names.append(name)
        self.set_bar_names(names)
        self.ensure_bar(name)
        self.reload_combo()
        self.combo.setCurrentText(name)
        self.refresh_all()

    # ── 툴바 삭제 ──────────────────────────────────────────────────
    def del_bar(self):
        # 현재 선택된 커스텀 툴바 삭제 (실제 툴바 위젯 + 저장값 제거)
        name = self.current_bar_name()
        if not name:
            return
        ans = QMessageBox.question(self.dlg, '툴바 삭제',
                                   "'%s' 툴바를 삭제할까요?" % name)
        if ans != QMessageBox.Yes:
            return
        bar = self.bars.get(name)
        if bar is None or sip.isdeleted(bar):
            bar = self.iface.mainWindow().findChild(QToolBar, self.objname_of(name))
        if bar is not None and not sip.isdeleted(bar):
            self.iface.mainWindow().removeToolBar(bar)
            bar.deleteLater()
        self.bars.pop(name, None)
        names = self.list_bar_names()
        if name in names:
            names.remove(name)
            self.set_bar_names(names)
        QSettings().remove(BAR_ACTIONS_KEY + name)
        self.reload_combo()
        self.refresh_all()

    # ── 콤보 전환 시 ───────────────────────────────────────────────
    def on_bar_changed(self, idx):
        # 커스텀 툴바 콤보 전환 시 좌우 갱신
        name = self.current_bar_name()
        if name:
            # 해당 툴바의 이름표 표시 설정 불러오기 (기본값: False)
            is_visible = QSettings().value('CustomToolbar/title_visible/' + name, False, type=bool)
            self.chk_show_title.blockSignals(True)  # 값을 변경할 때 이벤트가 무한 반복되는 것을 방지합니다
            self.chk_show_title.setChecked(is_visible)
            self.chk_show_title.blockSignals(False)
        self.refresh_all()

    def on_show_title_changed(self, state):
        name = self.current_bar_name()
        if not name:
            return
        is_visible = self.chk_show_title.isChecked()
        # 설정값 저장
        QSettings().setValue('CustomToolbar/title_visible/' + name, is_visible)
        # 툴바 즉시 재구성 (이름표 표시/숨김 실시간 반영)
        self.rebuild_bar()

    def refresh_all(self):
        # 왼쪽 소스 트리 + 오른쪽 구성 트리 다시 그림 + 버튼 상태 갱신
        self.populate_tree()
        self.populate_right()
        self._update_buttons()          # 트리 갱신 후 버튼 활성화 상태도 갱신

    def on_left_selection_changed(self):
        # 왼쪽 트리에 선택된 항목이 생기면 오른쪽 트리의 선택을 초기화
        if self.tree.selectedItems():
            self.right_list.blockSignals(True)
            self.right_list.clearSelection()
            self.right_list.blockSignals(False)
        self._update_buttons()

    def on_right_selection_changed(self):
        # 오른쪽 트리에 선택된 항목이 생기면 왼쪽 트리의 선택을 초기화
        if self.right_list.selectedItems():
            self.tree.blockSignals(True)
            self.tree.clearSelection()
            self.tree.blockSignals(False)
        self._update_buttons()

    # ── 조건에 따라 중앙 버튼 활성화/비활성화 ──────────────────────
    def _update_buttons(self):
        # 선택 상태에 따라 중앙 버튼 활성화/비활성화 (추가/제거/위·아래/그룹화/그룹해제/분리). 위·아래는 다중 선택 경계 기준
        has_bar = self.current_bar_name() is not None

        # 왼쪽 선택 중 '추가 가능'(개별/드롭다운) 항목이 있는가
        left_addable = False
        for it in self.tree.selectedItems():
            d = it.data(0, Qt.UserRole)
            if d is not None and d[0] in ('action', 'dropdown'):
                left_addable = True
                break

        # 오른쪽 선택 분석
        right_sel = self.right_list.selectedItems()
        right_top = [it for it in right_sel if it.parent() is None]          # 최상위
        right_top_dd = [it for it in right_top                                # 최상위 드롭다운
                        if (it.data(0, Qt.UserRole) or ('',))[0] == 'dropdown']
        right_child = [it for it in right_sel if it.parent() is not None]     # 드롭다운 자식
        # 드롭다운 자식 중 실제 action인 것 (분리 대상)
        detachable = False
        for it in right_child:
            pd = it.parent().data(0, Qt.UserRole)
            cd = it.data(0, Qt.UserRole)
            if pd is not None and pd[0] == 'dropdown' and cd is not None and cd[0] == 'action':
                detachable = True
                break

        # 위/아래 이동 가능 여부: 현재 항목과 같은 컨테이너의 선택들 기준 경계 검사
        can_up = can_down = False
        cur = self.right_list.currentItem()
        if cur is not None:
            parent = cur.parent()
            container = parent if parent is not None else self.right_list.invisibleRootItem()
            rows = []
            for it in right_sel:
                p = it.parent()
                c = p if p is not None else self.right_list.invisibleRootItem()
                if c is container:
                    rows.append(container.indexOfChild(it))
            if rows:
                can_up = min(rows) > 0
                can_down = max(rows) < container.childCount() - 1

        # 활성화 적용
        btn_to_right_Enabled = has_bar and left_addable
        self.btn_to_right.setEnabled(btn_to_right_Enabled)
        btn_to_left_Enabled = len(right_sel) > 0
        self.btn_to_left.setEnabled(btn_to_left_Enabled)
        self.btn_up.setEnabled(can_up)
        self.btn_down.setEnabled(can_down)
        self.btn_group.setEnabled(len(right_top) >= 2)                  # 최상위 2개 이상
        explode_ok = (len(right_sel) == 1 and len(right_top_dd) == 1)   # 그룹 해제: 그룹(드롭다운) 하나만 단독 선택일 때만
        self.btn_explode.setEnabled(explode_ok)
        self.btn_detach.setEnabled(detachable)                          # 드롭다운 자식 선택

    # ── 왼쪽 소스 트리 구성 (3단: 툴바 > 드롭다운 > 기능) ──────────
    def populate_tree(self):
        # 왼쪽 소스 트리 구성. 카테고리/안담은것 필터 반영, 이미 담긴 항목은 회색 배경
        self.tree.clear()
        current = self.current_keys()
        groups = self.collect_toolbars()
        groups.update(self.collect_menus())

        # 카테고리 콤보 필터
        cat = self.cat_combo.currentText() if self.cat_combo.count() > 0 else '전체'
        only_undone = (cat == '안 담은 기능만')

        for title, items in groups.items():
            # 특정 그룹만 보기 (전체/안담은것만이 아니면 그 그룹만)
            if cat not in ('전체', '안 담은 기능만') and title != cat:
                continue
            parent = QTreeWidgetItem(self.tree, [title])
            parent.setFlags(parent.flags() & ~Qt.ItemIsSelectable)
            for item in items:
                if item[0] == 'action':
                    a = item[1]
                    if only_undone and self.action_key(a) in current:
                        continue                       # 안 담은 것만: 담긴 개별 건너뜀
                    self._add_action_child(parent, a, current)
                elif item[0] == 'dropdown':
                    rep, objname, subs = item[1], item[2], item[3]
                    dkey = self.dropdown_key(objname, subs)
                    if only_undone and dkey in current:
                        continue                       # 안 담은 것만: 담긴 드롭다운 건너뜀
                    dnode = QTreeWidgetItem(parent, ['▾ ' + rep])
                    dnode.setIcon(0, self.dropdown_icon(subs, objname))
                    dnode.setData(0, Qt.UserRole, ('dropdown', rep, objname, subs))
                    dnode.setData(0, Qt.UserRole + 1, dkey)
                    if dkey in current:            # 이미 담긴 드롭다운
                        dnode.setBackground(0, QColor(210, 210, 210))
                        # 선택 가능 유지 (중복 추가는 add_selected에서 막힘)
                    for s in subs:
                        if only_undone and self.action_key(s) in current:
                            continue
                        self._add_action_child(dnode, s, current)
                    dnode.setExpanded(True)
            # 안 담은 것만인데 자식이 하나도 없으면 그룹 헤더 제거
            if only_undone and parent.childCount() == 0:
                idx = self.tree.indexOfTopLevelItem(parent)
                self.tree.takeTopLevelItem(idx)
                continue
            parent.setExpanded(True)
        self.apply_filter()

    def _add_action_child(self, parent, a, current):
        # 왼쪽 트리에 개별 액션 자식 노드 추가 (담긴 것은 회색 처리)
        t = a.text().replace('&', '').strip()
        child = QTreeWidgetItem(parent, [t])
        child.setIcon(0, a.icon())
        child.setData(0, Qt.UserRole, ('action', a))
        key = self.action_key(a)
        child.setData(0, Qt.UserRole + 1, key)
        if key in current:
            # child.setForeground(0, QColor('gray'))
            child.setBackground(0, QColor(210, 210, 210))
            # 선택은 가능하게 둔다 (스냅 시 하이라이트 보이도록).
            # 중복 추가는 add_selected에서 키로 막힘.

    # ── 오른쪽 구성 트리 채우기 ────────────────────────────────────
    def populate_right(self):
        # 오른쪽 구성 트리 채우기: 현재 커스텀 툴바의 액션/드롭다운을 트리로 표시
        self.right_list.clear()
        name = self.current_bar_name()
        if not name:
            return
        bar = self.ensure_bar(name)
        for a in bar.actions():
            w = bar.widgetForAction(a)
            if isinstance(w, QToolButton) and w.menu() is not None:
                subs = [s for s in w.menu().actions()
                        if not s.isSeparator() and s.text().replace('&', '').strip()]
                rep = w.toolTip() or (subs[0].text().replace('&', '').strip() if subs else '')
                icon = w.icon()
                if icon.isNull():
                    icon = self.dropdown_icon(subs, w.objectName())
                node = QTreeWidgetItem(self.right_list, ['▾ %s (%d)' % (rep, len(subs))])
                node.setIcon(0, icon)
                node.setData(0, Qt.UserRole, ('dropdown', rep, w.objectName(), subs))
                node.setData(0, Qt.UserRole + 1, self.dropdown_key(w.objectName(), subs))
                for s in subs:                       # 드롭다운 자식 표시 (트리로 펼침)
                    c = QTreeWidgetItem(node, [s.text().replace('&', '').strip()])
                    c.setIcon(0, s.icon())
                    c.setData(0, Qt.UserRole, ('action', s))
                    c.setData(0, Qt.UserRole + 1, self.action_key(s))
                node.setExpanded(True)
            else:
                t = a.text().replace('&', '').strip()
                if not t:
                    continue
                node = QTreeWidgetItem(self.right_list, [t])
                node.setIcon(0, a.icon())
                node.setData(0, Qt.UserRole, ('action', a))
                node.setData(0, Qt.UserRole + 1, self.action_key(a))

    # ── 현재 툴바에 담긴 키 집합 (개별 + 드롭다운 + 자식) ──────────
    def current_keys(self):
        # 현재 커스텀 툴바에 담긴 키 집합 (개별+드롭다운+그 자식). 왼쪽 회색 판정에 사용
        name = self.current_bar_name()
        if not name:
            return set()
        bar = self.ensure_bar(name)
        keys = set()
        for a in bar.actions():
            w = bar.widgetForAction(a)
            if isinstance(w, QToolButton) and w.menu() is not None:
                subs = [s for s in w.menu().actions()
                        if not s.isSeparator() and s.text().replace('&', '').strip()]
                keys.add(self.dropdown_key(w.objectName(), subs))
                for s in subs:                         # 드롭다운 안 자식도 '담김'으로 표시
                    keys.add(self.action_key(s))
            else:
                keys.add(self.action_key(a))
        return keys
    
    def _add_toolbar_title(self, bar, name):
        """툴바 맨 앞에 이름표를 부착하는 전용 함수"""
        # 저장된 표시 상태를 읽어옵니다
        is_visible = QSettings().value('CustomToolbar/title_visible/' + name, False, type=bool)
        
        # 체크되어 있을 때만 이름표를 부착합니다
        if is_visible:
            title_label = QLabel(f" ✨ {name}: ")
            title_label.setStyleSheet("font-weight: bold; color: #4169E1;")
            bar.addWidget(title_label)
            bar.addSeparator()

    # ── 오른쪽 트리 순서대로 툴바 재구성 + 저장 ────────────────────
    def rebuild_bar(self):
        # 오른쪽 트리 순서대로 실제 툴바 재구성 + QSettings 저장 (실시간 반영의 핵심)
        name = self.current_bar_name()
        if not name:
            return
        bar = self.ensure_bar(name)
        bar.clear()
        # 툴바 이름표 추가
        self._add_toolbar_title(bar, name)
        saved = []                                   # dict 리스트로 저장
        root = self.right_list.invisibleRootItem()
        for i in range(root.childCount()):
            node = root.child(i)
            data = node.data(0, Qt.UserRole)
            if data is None:
                continue
            if data[0] == 'action':
                a = data[1]
                if a is not None and not sip.isdeleted(a):
                    bar.addAction(a)
                    saved.append({'type': 'action', 'key': self.action_key(a)})
            elif data[0] == 'dropdown':
                rep, objname = data[1], data[2]
                # 자식 노드에서 현재 subs를 다시 읽는다 (편집/제거 반영)
                subs = []
                for j in range(node.childCount()):
                    cdata = node.child(j).data(0, Qt.UserRole)
                    if cdata is not None and cdata[0] == 'action':
                        s = cdata[1]
                        if s is not None and not sip.isdeleted(s):
                            subs.append(s)
                if subs:
                    self.make_dropdown_button(bar, subs, rep_text=rep, objname=objname)
                    saved.append({'type': 'dropdown', 'rep': rep, 'objname': objname,
                                  'child_keys': [self.action_key(s) for s in subs]})
        QSettings().setValue(BAR_ACTIONS_KEY + name, saved)

    # ── 오른쪽 최상위 항목들의 키 집합 (중복 방지용) ───────────────
    def _right_top_keys(self):
        # 오른쪽 최상위 항목들의 키 집합 (중복 추가 방지용)
        keys = set()
        root = self.right_list.invisibleRootItem()
        for i in range(root.childCount()):
            k = root.child(i).data(0, Qt.UserRole + 1)
            if k is not None:
                keys.add(k)
        return keys

    # ── 추가: 왼쪽 선택 → 오른쪽 (최상위에 추가) ───────────────────
    def add_selected(self):
        # 왼쪽에서 선택한 기능/드롭다운을 오른쪽(커스텀 툴바)에 추가
        name = self.current_bar_name()
        if not name:
            QMessageBox.information(self.dlg, '툴바 없음', '먼저 툴바를 추가하세요.')
            return
        sel = self.tree.selectedItems()
        if not sel:
            return
        existing = self._right_top_keys()
        added = False
        for it in sel:
            data = it.data(0, Qt.UserRole)
            key = it.data(0, Qt.UserRole + 1)
            if data is None or key in existing:
                continue
            if data[0] == 'action':
                a = data[1]
                node = QTreeWidgetItem(self.right_list, [a.text().replace('&', '').strip()])
                node.setIcon(0, a.icon())
                node.setData(0, Qt.UserRole, ('action', a))
                node.setData(0, Qt.UserRole + 1, key)
            elif data[0] == 'dropdown':
                rep, objname, subs = data[1], data[2], data[3]
                node = QTreeWidgetItem(self.right_list, ['▾ %s (%d)' % (rep, len(subs))])
                node.setIcon(0, self.dropdown_icon(subs, objname))
                node.setData(0, Qt.UserRole, data)
                node.setData(0, Qt.UserRole + 1, key)
                for s in subs:
                    c = QTreeWidgetItem(node, [s.text().replace('&', '').strip()])
                    c.setIcon(0, s.icon())
                    c.setData(0, Qt.UserRole, ('action', s))
                    c.setData(0, Qt.UserRole + 1, self.action_key(s))
                node.setExpanded(True)
            else:
                continue
            existing.add(key)
            added = True
        if added:
            self.rebuild_bar()
            self.populate_tree()

    # ── 제거: 오른쪽 선택 삭제 (최상위/드롭다운 자식 모두) ─────────
    def remove_selected(self):
        # 오른쪽에서 선택 항목 제거 (최상위 또는 드롭다운 자식). 이후 드롭다운 정리
        sel = self.right_list.selectedItems()
        if not sel:
            return
        root = self.right_list.invisibleRootItem()
        # 최상위 제거와 자식 제거를 구분해 처리
        for it in sel:
            parent = it.parent()
            if parent is None:
                root.removeChild(it)               # 최상위 항목 제거
            else:
                parent.removeChild(it)             # 드롭다운 자식 제거
        # 자식이 1개 이하로 줄어든 드롭다운 정리
        self._normalize_dropdowns()
        self.rebuild_bar()
        self.populate_tree()

    # ── 드롭다운 자식이 0/1개면 삭제/개별전환 ──────────────────────
    def _normalize_dropdowns(self):
        # 자식이 0개면 드롭다운 삭제, 1개면 개별 항목으로 전환
        root = self.right_list.invisibleRootItem()
        i = 0
        while i < root.childCount():
            node = root.child(i)
            data = node.data(0, Qt.UserRole)
            if data is not None and data[0] == 'dropdown':
                cc = node.childCount()
                if cc == 0:
                    root.removeChild(node)         # 자식 없음 → 삭제
                    continue                       # 인덱스 유지
                elif cc == 1:
                    # 자식 1개 → 개별 항목으로 전환
                    cdata = node.child(0).data(0, Qt.UserRole)
                    if cdata is not None and cdata[0] == 'action':
                        a = cdata[1]
                        new_node = QTreeWidgetItem([a.text().replace('&', '').strip()])
                        new_node.setIcon(0, a.icon())
                        new_node.setData(0, Qt.UserRole, ('action', a))
                        new_node.setData(0, Qt.UserRole + 1, self.action_key(a))
                        root.insertChild(i, new_node)
                        root.removeChild(node)
            i += 1

    # ── 순서 이동 (최상위끼리 / 같은 부모 자식끼리) ────────────────
    def move_item(self, direction):
        # 오른쪽 항목 순서 이동(▲▼). 같은 컨테이너의 선택 항목들을 함께 이동, 상대순서 유지, 경계에서 멈춤
        cur = self.right_list.currentItem()
        if cur is None:
            return
        parent = cur.parent()
        container = parent if parent is not None else self.right_list.invisibleRootItem()

        # 현재 항목과 '같은 컨테이너'에 속한 선택 항목들만 함께 이동
        rows = []
        for it in self.right_list.selectedItems():
            p = it.parent()
            c = p if p is not None else self.right_list.invisibleRootItem()
            if c is container:
                rows.append(container.indexOfChild(it))
        if not rows:
            return
        rows.sort()

        # 경계 검사 (위로면 맨위가 0, 아래로면 맨아래가 끝)
        if direction < 0 and rows[0] <= 0:
            return
        if direction > 0 and rows[-1] >= container.childCount() - 1:
            return

        # 이동 전에 아이템 객체를 미리 확보 (이동하면 인덱스가 바뀌므로)
        target_items = [container.child(r) for r in rows]
        order = list(zip(rows, target_items))
        if direction > 0:
            order = list(reversed(order))       # 아래로면 아래에서부터
        moved_items = []
        for r, item in order:
            expanded = item.isExpanded()
            container.removeChild(item)
            container.insertChild(r + direction, item)
            item.setExpanded(expanded)
            moved_items.append(item)

        # 이동한 항목들 다시 선택 유지 (시그널 차단으로 선택 꼬임 방지)
        self.right_list.blockSignals(True)
        self.right_list.clearSelection()
        self.right_list.setCurrentItem(cur)        # current 먼저 지정
        for it in moved_items:
            it.setSelected(True)                   # 그다음 다중 선택 복원 (current가 안 지움)
        self.right_list.blockSignals(False)
        self.rebuild_bar()
        self._update_buttons()

    # ── 개별/드롭다운 통합 묶기 ────────────────────────────────────
    def group_selected(self):
        # 오른쪽 선택 항목들을 하나의 드롭다운으로 묶음. 드롭다운 포함 시 첫 드롭다운 이름으로 통합
        sel = self.right_list.selectedItems()
        # 최상위 선택만 대상 (드롭다운 자식 개별 선택은 제외)
        top_sel = [it for it in sel if it.parent() is None]
        if len(top_sel) < 2:
            QMessageBox.information(self.dlg, '그룹화',
                                    '최상위 항목을 2개 이상 선택하세요. (개별/드롭다운 조합 가능)')
            return

        root = self.right_list.invisibleRootItem()
        # 트리 순서대로 정렬
        top_sel.sort(key=lambda it: root.indexOfChild(it))

        # 첫 드롭다운 이름/objectName 파악
        first_dd_rep = None
        first_dd_objname = None
        for it in top_sel:
            d = it.data(0, Qt.UserRole)
            if d is not None and d[0] == 'dropdown':
                first_dd_rep = d[1]
                first_dd_objname = d[2]
                break

        # 자식 액션 모으기 (순서 유지 + 중복 제거)
        subs = []
        seen = set()
        for it in top_sel:
            d = it.data(0, Qt.UserRole)
            if d is None:
                continue
            if d[0] == 'action':
                a = d[1]
                if a is not None and not sip.isdeleted(a) and id(a) not in seen:
                    seen.add(id(a))
                    subs.append(a)
            elif d[0] == 'dropdown':
                for a in d[3]:
                    if a is not None and not sip.isdeleted(a) and id(a) not in seen:
                        seen.add(id(a))
                        subs.append(a)
        if len(subs) < 2:
            return

        # 이름/objectName 결정
        if first_dd_rep is not None:
            rep = first_dd_rep
            objname = first_dd_objname
        else:
            existing_names = []
            for i in range(root.childCount()):
                d = root.child(i).data(0, Qt.UserRole)
                if d is not None and d[0] == 'dropdown':
                    existing_names.append(d[1])
            n = 1
            while ('그룹 %d' % n) in existing_names:
                n += 1
            rep = '그룹 %d' % n
            objname = '그룹:' + rep

        dd_data = ('dropdown', rep, objname, subs)
        dd_key = self.dropdown_key(objname, subs)

        # 새 드롭다운 노드 생성
        node = QTreeWidgetItem(['▾ %s (%d)' % (rep, len(subs))])
        node.setIcon(0, self.dropdown_icon(subs, objname))
        node.setData(0, Qt.UserRole, dd_data)
        node.setData(0, Qt.UserRole + 1, dd_key)
        for s in subs:
            c = QTreeWidgetItem(node, [s.text().replace('&', '').strip()])
            c.setIcon(0, s.icon())
            c.setData(0, Qt.UserRole, ('action', s))
            c.setData(0, Qt.UserRole + 1, self.action_key(s))

        # 첫 선택 위치 계산 후, 선택 항목 제거하고 삽입
        insert_at = root.indexOfChild(top_sel[0])
        for it in top_sel:
            root.removeChild(it)
        root.insertChild(insert_at, node)
        node.setExpanded(True)
        self.right_list.setCurrentItem(node)

        self.rebuild_bar()
        self.populate_tree()

    # ── 자식 분리 (드롭다운 자식을 개별 항목으로 밖으로 빼기) ──────
    def detach_children(self):
        # 드롭다운 자식을 개별 항목으로 밖으로 분리 (드롭다운 바로 아래에 삽입)
        sel = self.right_list.selectedItems()
        # 드롭다운의 자식 노드만 대상 (부모가 있고, 그 부모가 드롭다운)
        targets = []
        for it in sel:
            parent = it.parent()
            if parent is None:
                continue
            pdata = parent.data(0, Qt.UserRole)
            cdata = it.data(0, Qt.UserRole)
            if pdata is not None and pdata[0] == 'dropdown' and \
               cdata is not None and cdata[0] == 'action':
                targets.append(it)
        if not targets:
            QMessageBox.information(self.dlg, '자식 분리',
                                    '드롭다운 안의 자식 기능을 선택하세요.')
            return

        root = self.right_list.invisibleRootItem()
        existing = self._right_top_keys()

        for child in targets:
            parent = child.parent()
            if parent is None:
                continue
            cdata = child.data(0, Qt.UserRole)
            a = cdata[1]
            key = self.action_key(a)
            # 부모(드롭다운) 바로 아래 위치 계산
            parent_row = root.indexOfChild(parent)
            parent.removeChild(child)                  # 드롭다운에서 제거
            if key in existing:                        # 이미 최상위에 있으면 삽입 안 함
                continue
            new_node = QTreeWidgetItem([a.text().replace('&', '').strip()])
            new_node.setIcon(0, a.icon())
            new_node.setData(0, Qt.UserRole, ('action', a))
            new_node.setData(0, Qt.UserRole + 1, key)
            root.insertChild(parent_row + 1, new_node)  # 드롭다운 바로 아래
            existing.add(key)

        # 자식이 0/1개 남은 드롭다운 정리
        self._normalize_dropdowns()
        self.rebuild_bar()
        self.populate_tree()

    # ── 드롭다운 해제 (자식들을 개별 항목으로 풀기) ────────────────
    def explode_dropdown(self):
        # 드롭다운 해제: 자식 전부를 개별 항목으로 풀기
        sel = self.right_list.selectedItems()
        node = None
        for it in sel:
            if it.parent() is None:
                d = it.data(0, Qt.UserRole)
                if d is not None and d[0] == 'dropdown':
                    node = it
                    break
        if node is None:
            QMessageBox.information(self.dlg, '드롭다운 해제',
                                    '드롭다운 항목을 선택하세요.')
            return
        data = node.data(0, Qt.UserRole)
        subs = [s for s in data[3] if s is not None and not sip.isdeleted(s)]

        root = self.right_list.invisibleRootItem()
        row = root.indexOfChild(node)
        existing = self._right_top_keys()

        root.removeChild(node)                         # 드롭다운 제거
        insert_at = row
        for a in subs:                                 # 자식을 개별 최상위로 삽입
            key = self.action_key(a)
            if key in existing:
                continue
            new_node = QTreeWidgetItem([a.text().replace('&', '').strip()])
            new_node.setIcon(0, a.icon())
            new_node.setData(0, Qt.UserRole, ('action', a))
            new_node.setData(0, Qt.UserRole + 1, key)
            root.insertChild(insert_at, new_node)
            existing.add(key)
            insert_at += 1

        self.rebuild_bar()
        self.populate_tree()

    # ── 검색 필터 (왼쪽) ───────────────────────────────────────────
    def apply_filter(self):
        # 왼쪽 트리 검색 필터 적용
        text = self.search.text().strip().lower()
        root = self.tree.invisibleRootItem()
        for i in range(root.childCount()):
            parent = root.child(i)
            visible_child = self._filter_node(parent, text)
            parent.setHidden(not visible_child)

    def _filter_node(self, node, text):
        """노드(및 자식/손자) 필터. 보이는 자손이 있으면 True."""
        any_visible = False
        for j in range(node.childCount()):
            child = node.child(j)
            if child.childCount() > 0:                 # 드롭다운 노드
                self_match = (not text) or (text in child.text(0).lower())
                if self_match:
                    for k in range(child.childCount()):
                        child.child(k).setHidden(False)
                    child.setHidden(False)
                    any_visible = True
                else:
                    sub_visible = self._filter_node(child, text)
                    child.setHidden(not sub_visible)
                    if sub_visible:
                        any_visible = True
            else:
                show = (not text) or (text in child.text(0).lower())
                child.setHidden(not show)
                if show:
                    any_visible = True
        return any_visible

    # ── 담긴 항목 사이 점프 (개별 키 기준) ─────────────────────────
    def jump_added(self, direction):
        # 오른쪽에 담긴 '개별 액션 키'만 모은다 (드롭다운 키 제외, 그 자식 개별 키는 포함)
        added_keys = set()
        root_r = self.right_list.invisibleRootItem()
        for i in range(root_r.childCount()):
            node = root_r.child(i)
            data = node.data(0, Qt.UserRole)
            if data is None:
                continue
            if data[0] == 'action':
                added_keys.add(data[1] and self.action_key(data[1]))
            elif data[0] == 'dropdown':
                for j in range(node.childCount()):
                    cd = node.child(j).data(0, Qt.UserRole)
                    if cd is not None and cd[0] == 'action':
                        added_keys.add(self.action_key(cd[1]))
        added_keys.discard(None)
        if not added_keys:
            return

        # 왼쪽 트리에서 개별 키가 담김에 해당하는 노드들 수집
        items = []

        def collect(node):
            for j in range(node.childCount()):
                child = node.child(j)
                if child.isHidden():
                    continue
                cdata = child.data(0, Qt.UserRole)
                # 개별 액션 노드만 점프 대상 (드롭다운 노드 자체는 제외)
                if cdata is not None and cdata[0] == 'action':
                    if child.data(0, Qt.UserRole + 1) in added_keys:
                        items.append(child)
                if child.childCount() > 0:
                    collect(child)

        root = self.tree.invisibleRootItem()
        for i in range(root.childCount()):
            parent = root.child(i)
            if parent.isHidden():
                continue
            collect(parent)
        if not items:
            return
        cur = self.tree.currentItem()
        try:
            idx = items.index(cur)
        except ValueError:
            idx = -1 if direction > 0 else 0
        nxt = (idx + direction) % len(items)
        target = items[nxt]
        self.tree.setCurrentItem(target)
        self.tree.scrollToItem(target, QAbstractItemView.PositionAtCenter)

    # ── 시작 시 전체 복원 ──────────────────────────────────────────
    def restore_all(self):
        # 시작 시: QSettings 저장 구성으로 모든 커스텀 툴바 복원 (구/신 형식 호환)
        names = self.list_bar_names()
        if not names:
            return
        all_acts = self.build_action_map()
        for name in names:
            bar = self.ensure_bar(name)
            bar.clear()
            # 툴바 이름표 추가
            self._add_toolbar_title(bar, name)
            saved = QSettings().value(BAR_ACTIONS_KEY + name, [])
            if not saved:
                continue
            for entry in saved:
                # 구 형식 호환: 문자열 키
                if isinstance(entry, str):
                    if entry.startswith('dd:'):
                        continue
                    a = all_acts.get(entry)
                    if a is not None:
                        bar.addAction(a)
                    continue
                # 신 형식: dict
                etype = entry.get('type')
                if etype == 'action':
                    a = all_acts.get(entry.get('key'))
                    if a is not None:
                        bar.addAction(a)
                elif etype == 'dropdown':
                    child_keys = entry.get('child_keys', [])
                    subs = [all_acts.get(k) for k in child_keys]
                    subs = [s for s in subs if s is not None and not sip.isdeleted(s)]
                    if subs:
                        self.make_dropdown_button(
                            bar, subs,
                            rep_text=entry.get('rep', ''),
                            objname=entry.get('objname', ''))