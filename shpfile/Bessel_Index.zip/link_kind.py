from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def link_kind(number, feature, parent):
    
    link_kind = ['본선분리', '연결로JC','교차로통로','연결로IC','SA레이어',
                '복합교차점','로타리내링크','회전교차로내링크','','P턴링크',
                '', '진출입로', '단지내도로', '', '레이싱서킷', '본선비분리']
    
    Value = None
    try:

        for i in range(16):
            # Convert the input values to integers
            number = int(number)
            power = int(i)
            
            if (number & (1 << power)) != 0:
                if Value == None:
                    Value = link_kind[i]
                else:
                    Value = f'{Value},{link_kind[i]}'
            
        return Value
            
    except ValueError:
        return False
