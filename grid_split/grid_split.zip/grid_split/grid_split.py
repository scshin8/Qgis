from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsVectorLayer, QgsFeature, QgsRectangle, QgsGeometry, QgsProject, QgsField, QgsMapLayerType, QgsSpatialIndex, QgsExpression, QgsExpressionContext, QgsExpressionContextUtils

from .grid_split_dialog import grid_splitDialog
from .grid_split_dialog_2 import grid_splitDialog_2

import os.path

class grid_split:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u'&그리드분할')

        self.toolbar = self.iface.addToolBar('그리드분할')
        self.toolbar.setObjectName('grid_split')

    def tr(self, message):
        return QCoreApplication.translate('grid_split', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        # if add_to_toolbar:
        #     # Adds plugin icon to Plugins toolbar
        #     self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = self.plugin_dir + '/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'그리드분할'),
            callback=self.run,
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[0])

        icon_path = self.plugin_dir + '/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'키값생성'),
            callback=self.run2,
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[1])


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&그리드분할'),
                action)
            self.iface.removeToolBarIcon(action)

        try:
            del self.toolbar
        except:
            pass

    def run(self):
        self.dlg = grid_splitDialog(self.iface, self.iface.mainWindow())
        self.dlg.show()
        Layer = self.canvas.currentLayer()

        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.dlg.mMapLayerComboBox.setLayer(Layer)
            self.dlg.mFieldComboBox.setLayer(Layer)
        else:
            self.dlg.mMapLayerComboBox.setCurrentIndex(0)
            self.dlg.mFieldComboBox.setLayer(None)

        result = self.dlg.exec_()

    # 폴리곤 생성시작
        if result:
        # 작업할 레이어를 로드합니다
            layer =  self.dlg.mMapLayerComboBox.currentLayer()
            wkbtype  = layer.wkbType() #.wkbType() .geometryType()
        # 캠버스 좌표계
            map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            CRSid=map_crs.authid()

        # 그리드 크기 설정
            split_size = self.dlg.spinBox.value()

        # 각도 필드 설정
            angle_field = self.dlg.mFieldComboBox.currentText()

        # 새로운 레이어 생성
            grid_layer = QgsVectorLayer("Polygon"+'?crs='+CRSid, "grid_layer", "memory")
            # 새 레이어의 데이터 프로바이더 가져오기
            data_provider = grid_layer.dataProvider()
            data_provider.addAttributes([QgsField("FID", QVariant.Int),
                                        QgsField("GID", QVariant.String),
                                        QgsField("key", QVariant.String)])
            grid_layer.updateFields()
        # 레이어의 각 폴리곤을 그리드로 분할하여 새 레이어에 추가
            for feature in layer.getFeatures():
                print(feature)
                geom = feature.geometry()
                extent = geom.boundingBox()
                fid = feature.id()

            # 폴리곤의 회전 각도 가져오기
                angle = float(feature[angle_field]) if angle_field in feature.fields().names() else 0.0  # 기본값은 0.0입니다
                
            # 버퍼피처의 중심좌표 가져오기
                centroid = geom.centroid().asPoint()

                # 폴리곤 내에 그리드 생성
                x_min, x_max, y_min, y_max = extent.xMinimum(), extent.xMaximum(), extent.yMinimum(), extent.yMaximum()
                print(x_min, x_max, y_min, y_max)
                # 그리드 생성
                rows = float((y_max - y_min) / split_size)
                cols = float((x_max - x_min) / split_size)

                for i in range(split_size):
                    for j in range(split_size):
                    # 그리드를 만들어 새로운 feature로 추가
                        poly = QgsGeometry.fromRect(QgsRectangle(x_min + j * cols, y_max - i * rows, x_min + (j + 1) * cols, y_max - (i + 1) * rows))
                    # 버퍼피처 중심을 기준으로 폴리곤 회전
                        poly.rotate(angle, centroid)
                        new_feature = QgsFeature()
                        gid = f"{chr(65 + i)}{j+1:02d}"  # A01, A02, ... , C03 형식의 GID 생성
                        key = f"{fid}_{gid}"
                        new_feature.setAttributes([fid, gid, key]) # , Text, Kind, now, nameText])
                        new_feature.setGeometry(poly)
                        data_provider.addFeature(new_feature)

            # 맵에 그리드 레이어 추가
            QgsProject.instance().addMapLayer(grid_layer)
            
            print('end')
            self.canvas.refresh()

            # 결과를 저장할 파일 경로
            # output_path = "path_to_save/grid_layer.geojson"  # 파일 경로를 입력하세요

            pass
    def run2(self):
        self.dlg2 = grid_splitDialog_2(self.iface, self.iface.mainWindow())
        self.dlg2.show()

        Layer = self.canvas.currentLayer()

        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.dlg2.mMapLayerComboBox.setLayer(Layer)
            self.dlg2.mMapLayerComboBox_2.setLayer(Layer)
        else:
            self.dlg2.mMapLayerComboBox.setCurrentIndex(0)
            self.dlg2.mMapLayerComboBox_2.setCurrentIndex(0)

        result = self.dlg2.exec_()

    # 링크 레이어를 로드합니다
        grid_layer =  self.dlg2.mMapLayerComboBox_2.currentLayer()
        link_layer =  self.dlg2.mMapLayerComboBox.currentLayer()
        if result:

        # 공간 인덱스 생성
            index = QgsSpatialIndex()
            for feature in grid_layer.getFeatures():
                index.insertFeature(feature)


            # 새로운 레이어 생성 (결합된 속성을 담을 레이어)
            combined_layer = QgsVectorLayer("lineString?crs=" + grid_layer.crs().authid(), "결합된 레이어", "memory")
            provider = combined_layer.dataProvider()

            # 새로운 레이어의 필드 생성 (폴리곤 레이어와 링크 레이어의 필드 모두 포함)
            fields = link_layer.fields().toList() + grid_layer.fields().toList()
            provider.addAttributes(fields)
            combined_layer.updateFields()

            # 링크 레이어의 각 피처에 대해 폴리곤 레이어와의 위치 상호작용 확인 및 결합
            for link_feature in link_layer.getFeatures():
                link_geometry = link_feature.geometry()
                intersect_ids = index.intersects(link_geometry.boundingBox())

                for polygon_id in intersect_ids:
                    polygon_feature = grid_layer.getFeature(polygon_id)
                    if polygon_feature.geometry().intersects(link_geometry):
                        new_feature = QgsFeature()
                        new_feature.setGeometry(polygon_feature.geometry())
                        new_feature.setAttributes(link_feature.attributes() + polygon_feature.attributes())
                        provider.addFeature(new_feature)

            # 레이어에 추가하고 렌더링
            QgsProject.instance().addMapLayer(combined_layer)

            combined_layer.commitChanges()
            # 새로운 필드 생성 및 값 결합
            combined_layer.startEditing()

            # 새로운 필드 추가할 이름 설정
            new_field_name = '결합된_필드'

            # 새로운 필드 생성
            new_field = QgsField(new_field_name, QVariant.String)
            provider.addAttributes([new_field])
            combined_layer.updateFields()

            # 필드 계산기를 이용하여 값 결합
            expression = QgsExpression('concatenate( "GID" ,group_by:=array("LON","LAT"),concatenator:=\'\')') 
            print(expression)
            context = QgsExpressionContext()
            context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(combined_layer))

            for feature in combined_layer.getFeatures():
                context.setFeature(feature)
                value = expression.evaluate(context)
                feature[new_field_name] = value
                combined_layer.updateFeature(feature)

            # 필드 계산기 이용 후 종료
            combined_layer.commitChanges()

# 위치로 선택된 객체를 순환하며 KEY값을 조합함
    # def run2(self):
    #     self.dlg2 = grid_splitDialog_2(self.iface, self.iface.mainWindow())
    #     self.dlg2.show()

    #     Layer = self.canvas.currentLayer()

    #     if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
    #         self.chk = True
    #         self.dlg2.mMapLayerComboBox.setLayer(Layer)
    #         self.dlg2.mMapLayerComboBox_2.setLayer(Layer)
    #     else:
    #         self.dlg2.mMapLayerComboBox.setCurrentIndex(0)
    #         self.dlg2.mMapLayerComboBox_2.setCurrentIndex(0)

    #     result = self.dlg2.exec_()

    # # 링크 레이어를 로드합니다
    #     grid_layer =  self.dlg2.mMapLayerComboBox.currentLayer()
    #     link_layer =  self.dlg2.mMapLayerComboBox_2.currentLayer()
    #     if result:
    #         for feature in link_layer.getFeatures():
    #             fid=feature.id()

    #             # 공간 색인을 만듭니다.
    #             index = QgsSpatialIndex()
    #             index.addFeature(feature)

    #         # 선택을 초기화합니다.
    #             grid_layer.removeSelection()
    #             link_geometry = None

    #         # 링크 레이어의 각 피처에 대해 교차하는 폴리곤을 찾고 선택합니다.
    #             for grid_feature in grid_layer.getFeatures():
    #                 link_geometry = grid_feature.geometry()
    #                 intersecting_features = index.intersects(link_geometry.boundingBox())

    #                 for intersecting_feature_id in intersecting_features:
    #                     intersecting_feature = link_layer.getFeature(intersecting_feature_id)
    #                     intersecting_geometry = intersecting_feature.geometry()
                        
    #                     if link_geometry.intersects(intersecting_geometry):
    #                         grid_layer.select(grid_feature.id())

    #         # 선택된 피처를 확인합니다.
    #             selected_features = grid_layer.selectedFeatures()

    #         # 선택된 피처들의 속성 값을 저장할 리스트를 생성합니다.
    #             selected_features_attributes = []

    #         # 선택된 피처들의 속성 값을 가져와 리스트에 추가합니다.
    #             for feature in selected_features:
    #                 attributes = feature.attributes()
    #                 selected_features_attributes.append((feature, attributes))

    #         # 키 값을 기준으로 정렬합니다.
    #             sorted_features = sorted(selected_features_attributes, key=lambda x: x[1][2])

    #             keyValue = str(sorted_features[0][1][0])+'_'
    #             for feature, attributes in sorted_features:

    #             # 키값 가져오기
    #                 key = Qt.DisplayRole,feature.attributes()[1]
    #                 keyValue = keyValue + str(key[1])

    #             idx=link_layer.fields().indexFromName('cam_key')
    #             print(idx)
    #             if idx != -1:
    #                 link_layer.changeAttributeValue(fid, idx, keyValue, True)
    #             else:
    #                 # print(keyValue)
    #                 link_layer.dataProvider().addAttributes([QgsField('cam_key', QVariant.String,'',50)])
    #                 link_layer.updateFields()
    #                 link_layer.commitChanges()
    #                 link_layer.startEditing()
    #                 idx=link_layer.fields().indexFromName('cam_key')
    #                 link_layer.changeAttributeValue(fid, idx, keyValue, True)
                
    #         pass