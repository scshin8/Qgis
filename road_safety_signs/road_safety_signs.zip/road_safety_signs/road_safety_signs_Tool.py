from qgis.PyQt.QtCore import Qt, pyqtSignal, QVariant
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import *
from qgis.gui import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# import traceback
class roadsafetysignsTool(QgsMapToolEmitPoint):
    selectionDone = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb.setWidth(3)
        self.rb.setColor(QColor(60, 151, 255, 255))
    
    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            Point=self.toMapCoordinates(e.pos())
            self.rb.reset(QgsWkbTypes.PointGeometry)
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
            self.selectionDone.emit()

    def reset(self):
        # self.rb.reset(QgsWkbTypes.PointGeometry)
        self.rb.reset(True)

    def deactivate(self):
        # self.rb.reset(QgsWkbTypes.PointGeometry)
        self.rb.reset(True)
        QgsMapTool.deactivate(self)

class DrawLineComment(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, iface,idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.idx = idx
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        Color = QColor(50, 80, 255, 180) if self.idx == 29 else QColor(255, 80, 50, 180) if self.idx == 30 else QColor(80, 255, 80, 180)
        self.rb.setColor(Color) # 라인 색깔
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setWidth(2)  # 라인 너비
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None   

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            if self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
        return None

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.status = 1
            Point=self.toMapCoordinates(e.pos())

            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        else:
            if self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
            # else:
            #     self.reset()
        return None

    def canvasMoveEvent(self, e):
        if self.rb.numberOfVertices() > 0 and self.status == 1:
            self.rb.removeLastPoint(0)
            Point=self.toMapCoordinates(e.pos())
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        self.move.emit()
        return None

    def reset(self):
        self.status = 0
        # self.rb.reset(QgsWkbTypes.LineGeometry)
        self.rb.reset(True)

    def deactivate(self):
        # self.status = 0
        # self.rb.reset(QgsWkbTypes.LineGeometry)
        self.rb.reset(True)
        QgsMapTool.deactivate(self)

        
class DrawpolygonComment(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setColor(QColor(60, 151, 255, 70)) # 색깔
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setWidth(2)  # 라인 너비
        self.rb.setStrokeColor(QColor(60, 151, 255, 200)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        # # Fill symbol
        # fill_symbol = QgsFillSymbol.createSimple({'color': '60,151,255,150', 'style': 'dense7'}) # solid,  dense1 ~ dense7, horizontal, vertical, cross, bdiagonal, fdiagonal, crossdiag
        # # Apply fill symbol to the rubber band
        # self.rb.setSymbol(fill_symbol)

        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            if self.rb.numberOfVertices() > 3:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
        return
    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
            Point=self.toMapCoordinates(e.pos())

            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        else:
            if self.rb.numberOfVertices() > 3:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
            # else:
            #     self.reset()
        return None

    def canvasMoveEvent(self, e):
        if self.rb.numberOfVertices() > 0 and self.status == 1:
            self.rb.removeLastPoint(0)
            Point=self.toMapCoordinates(e.pos())
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        self.move.emit()
        return None

    def reset(self):
        self.status = 0
        self.rb.reset(True)

    def deactivate(self):
        self.status = 0
        self.rb.reset(True)
        QgsMapTool.deactivate(self)


class SelectDeleteTool(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, iface, Comment_crs):
        canvas = iface.mapCanvas()
        self.Comment_crs = Comment_crs
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        self.startPoint = None
        self.endPoint = None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.startPoint=self.toMapCoordinates(e.pos())
            self.endPoint = self.startPoint
        else:
            pass
        return None

    def canvasReleaseEvent(self, event):
        self.endPoint = self.toMapCoordinates(event.pos())
        self.rb.reset(True)

        if self.startPoint and self.endPoint:
            self.startPoint = self.CoordinateTransform(self.startPoint)
            self.endPoint = self.CoordinateTransform(self.endPoint)
            rect = QgsRectangle(self.startPoint, self.endPoint)
            layers = [layer for layer in QgsProject.instance().mapLayers().values() if layer.type() == QgsMapLayer.VectorLayer and "표지판" in layer.name()]
            for layer in layers:
                layer.removeSelection()
                layer.selectByRect(rect)
                layer.startEditing()
                for feature in layer.selectedFeatures():
                    layer.deleteFeature(feature.id())
                layer.commitChanges()
                layer.startEditing()
                
        self.canvas.refresh()
        self.startPoint = None
        self.endPoint = None
        self.selectionDone.emit()

    def canvasMoveEvent(self, event):
        if not self.startPoint:
            return
        self.endPoint=self.toMapCoordinates(event.pos())
        self.showRect(self.startPoint, self.endPoint)
        self.move.emit()

    def showRect(self, startPoint, endPoint):
        self.rb.reset(QgsWkbTypes.PolygonGeometry)  # true, it's a polygon
        point1 = QgsPointXY(startPoint.x(), startPoint.y())
        point2 = QgsPointXY(startPoint.x(), endPoint.y())
        point3 = QgsPointXY(endPoint.x(), endPoint.y())
        point4 = QgsPointXY(endPoint.x(), startPoint.y())

        self.rb.addPoint(point1, False)
        self.rb.addPoint(point2, False)
        self.rb.addPoint(point3, False)
        self.rb.addPoint(point4, True)  # true to update canvas
        self.rb.show()

    def CoordinateTransform(self, Point):
        map_crs = self.canvas.mapSettings().destinationCrs()
        Transform = QgsCoordinateTransform(map_crs,self.Comment_crs, QgsProject.instance())
        Point = Transform.transform(Point)
        return Point

    def reset(self):
        self.rb.reset(True)

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)