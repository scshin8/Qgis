from qgis.PyQt.QtCore import Qt, pyqtSignal, QVariant
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import *
from qgis.gui import *
from PyQt5.QtCore import QPoint, QSettings, Qt

import time, math
from math import sqrt, hypot, atan2, degrees, radians, cos, sin, pi
from .drawing_Tools_Circle import drawingToolsCircle
from .drawing_Tools_length import drawingToolslength

epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

# import traceback
class DrawPoint(QgsMapToolEmitPoint):
    selectionDone = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb.setWidth(3)
        self.rb.setColor(QColor(60, 151, 255, 255))
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.rb.reset(QgsWkbTypes.PointGeometry)
            Point=self.toMapCoordinates(e.pos())
            self.rb.addPoint(Point)
            self.selectionDone.emit()
        return None

    # def canvasMoveEvent(self, event):

    #     # 스냅된 지점을 가져오는 예시 코드입니다.
    #     snap_info = self.canvas.snappingUtils().snapToMap(event.pos())
    #     if snap_info.isValid():
    #         snap_point = snap_info.point()

    #         # 스냅된 지점을 화면에 표시합니다.
    #         marker = QgsVertexMarker(self.canvas)
    #         marker.setCenter(snap_point)
    #         marker.setColor(Qt.red)  # 원하는 색상으로 설정합니다.
    #         marker.setIconSize(5)  # 원하는 크기로 설정합니다.
    #         marker.setIconType(QgsVertexMarker.ICON_CIRCLE)  # 원 모양의 아이콘을 사용합니다.

    #         # snap_point를 사용하여 원하는 작업을 수행합니다.
    #         print("스냅된 지점:", snap_point)

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)

class DrawLine(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.rblist = []

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)

        self.rb = self.create_rubber_band(QColor(255, 0, 0, 255),w=2)
        self.rb1 = self.create_rubber_band(QColor(255, 0, 0, 255), Qt.DashLine, w=1) # Qt.DashLine, DotLine
        self.guide_rb = self.create_rubber_band( QColor(10, 10, 10, 150), Qt.DotLine) # Qt.DashLine

        self.startPoint=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)
        self.endPoint=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        self.distance1end = 0

    def activate(self):
        QgsMapTool.activate(self)
        # 필요하다면 여기서 위치를 다시 계산해도 됨(캔버스 크기 변경 대비)
        self.dlglength.show()

    def create_rubber_band(self, color, line_style=None, w=1):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        rb.setWidth(w)
        rb.setColor(color)
        if line_style:
            rb.setLineStyle(line_style)
        return rb

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            self.rblist.pop()
            self.update_rubber_band()
        elif event.matches(QKeySequence.Cancel):
            self.reset()
            self.dlglength.close()
            self.iface.actionPan().trigger()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.distance1end = 0
            self.reset()

    def canvasPressEvent(self, event):
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        if event.button() == Qt.LeftButton:
            self.handle_left_click(event)
        else:
            self.handle_right_click()

    def handle_left_click(self, event):
        self.startPoint = self.toMapCoordinates(event.pos())
        if self.status == 0:
            self.rblist.clear()
            self.rb.reset(QgsWkbTypes.LineGeometry)
            self.rb1.reset(QgsWkbTypes.LineGeometry)
            self.status = 1

        if self.rb.numberOfVertices() < 1:
            self.rb.addPoint(self.startPoint)
            self.rb1.addPoint(self.startPoint)
        else:
            self.rb.addPoint(self.endPoint)
            self.rb1.addPoint(self.endPoint)
            self.startPoint = self.endPoint
            self.distance1end = self.distance1end + self.distance1
            self.rb1.removePoint(0)

        self.rblist.append(self.startPoint)

    def handle_right_click(self):
        if len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.distance1end = 0
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint=self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self.showLine(self.startPoint, self.endPoint, event)
            self.move.emit()

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # 두 점이 같으면 종료
        dx = mousePoint.x() - lastPoint.x()
        dy = mousePoint.y() - lastPoint.y()
        length = math.hypot(dx, dy)
        if length == 0:
            self.guide_rb.hide()
            return

        # 방향 단위벡터
        ux = dx / length
        uy = dy / length

        # 캔버스의 대각선 길이(지도좌표 단위)
        extent = self.canvas.extent()
        diag_len = math.hypot(extent.width(), extent.height())

        # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        pA = QgsPointXY(
            lastPoint.x() - ux * diag_len,
            lastPoint.y() - uy * diag_len
        )
        pB = QgsPointXY(
            lastPoint.x() + ux * diag_len,
            lastPoint.y() + uy * diag_len
        )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(pA, False)
        self.guide_rb.addPoint(pB, True)
        self.guide_rb.show()

    def showLine(self, startPoint, endPoint, event):
        if startPoint.x() == endPoint.x() and startPoint.y() == endPoint.y():
            return

        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        transform_to_5179 = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        st5179 = transform_to_5179.transform(startPoint)
        en5179 = transform_to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()

        if dx == 0 and dy == 0:
            return
        
        # ─────────────────────────────
        # 2) EPSG:5179 기준 각도/거리 계산
        #    (각도: 0~360°, 거리: m)
        # ─────────────────────────────

        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
        distance = math.hypot(dx, dy)   # EPSG:5179 이므로 "미터" 단위

        # self.distance1 = math.sqrt((en5179.x() - st5179.x())**2 + (en5179.y() - st5179.y())**2)

        # ─────────────────────────────
        # 3) Shift 누르면 각도 + 거리 스냅
        #    각도: 15도 단위
        #    거리: 1 m 단위 (원하면 5, 10 등으로 변경 가능)
        # ─────────────────────────────
        if shift_pressed:
            # 각도 스냅
            SNAP_ANGLE = self.dlglength.spinBox_ang.value()
            if SNAP_ANGLE != 0:
                angle_deg =  int((angle_deg + (SNAP_ANGLE/2))/SNAP_ANGLE)*SNAP_ANGLE

            # 길이 스냅
            SNAP_DIST = self.dlglength.spinBox_dis.value()
            if SNAP_DIST != 0:
                distance = round(distance / SNAP_DIST) * SNAP_DIST

            # 스냅된 각도/길이로 EPSG:5179 상에서 endPoint 재계산
            angle_rad = math.radians(-(angle_deg) + 90)
            dx = distance * math.cos(angle_rad)
            dy = distance * math.sin(angle_rad)

            en5179 = QgsPointXY(st5179.x() + dx, st5179.y() + dy)

            # 다시 캔버스 CRS 로 변환해서 화면에 그릴 endPoint 갱신
            transform_to_canvas = QgsCoordinateTransform(
                self.epsg5179, self.canvasCRS, QgsProject.instance()
            )
            self.endPoint = transform_to_canvas.transform(en5179)
        else:
            # Shift 안누른 경우: 사용자가 움직인 endPoint 그대로 사용
            self.endPoint = endPoint

        # ─────────────────────────────
        # 4) 측정 결과(각도/거리) UI 표시
        #    distance1end 는 누적 거리 같은 곳에서 관리한다고 가정
        # ─────────────────────────────
        self.distance1 = distance   # 현재 세그먼트 길이 (m)

        # 거리 누적 + 각도 출력 (기존 로직 유지)
        # distance1end 가 없다면 그냥 distance 만 넣어도 됨
        total_dist = getattr(self, "distance1end", 0) + self.distance1
        
        self.dlglength.lineEdit_2.setText(f"{total_dist:.3f}")
        self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")
        self.dlglength.lineEdit_last.setText(f"{self.distance1:.3f}")

        # ─────────────────────────────
        # 5) rubber band 갱신
        # ─────────────────────────────
        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)
        self.updateGuideLine(self.startPoint, self.endPoint)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawDrawing(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.LeftButton = False
        self.status = 0

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) 
        self.rb.setColor(QColor(255, 0, 0, 255)) # 라인 색깔
        # self.rb.setWidth(5)  # 라인 너비

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
    
    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = True
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.status = 1
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
        else:
            self.handle_right_click()

    def handle_right_click(self):    
            if self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint()
                self.selectionDone.emit()
            self.reset()

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = False
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        time.sleep(0.01) 
        if self.LeftButton and self.status == 1:
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
            self.move.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)

class Drawpolygon(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.CTool = CTool
        self.idx = idx

        self.rblist = []
        self.startPoint = None
        self.endPoint = None

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)
        
        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

        self.rb = self.create_rubber_band(QColor(255, 0, 0, 30))
        self.rb1 = self.create_rubber_band(QColor(255, 0, 0, 30), Qt.DotLine, w=1) # DotLine DashLine

        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        # self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 150))
        self.guide_rb.setLineStyle(Qt.DotLine)


    def activate(self):
        QgsMapTool.activate(self)
        # 필요하다면 여기서 위치를 다시 계산해도 됨(캔버스 크기 변경 대비)
        self.dlglength.show()

    def create_rubber_band(self, fill_color, line_style=None, w=1):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(fill_color)
        rb.setStrokeColor(QColor(255, 0, 0, 255))
        if line_style:
            rb.setLineStyle(line_style)
            rb.setWidth(w)
        return rb

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            self.undo_last_point()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def undo_last_point(self):
        if self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            self.rblist.pop()
            self.update_rubber_band()
        elif self.rb.numberOfVertices() == 1:
            self.reset()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
            self.reset()

    def canvasPressEvent(self, e):
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        if e.button() == Qt.LeftButton:
            self.handle_left_click(e)
        else:
            self.handle_right_click()

    def handle_left_click(self, e):
        self.startPoint = self.toMapCoordinates(e.pos())
        if self.status == 0:
            self.reset_rubber_bands()
            self.status = 1

        if self.status == 1:
            self.rb.addPoint(self.endPoint)
            self.rblist.append(self.endPoint)
            self.rb1.addPoint(self.endPoint)
            self.startPoint = self.endPoint

        if self.rb1.numberOfVertices() == 4:
            self.rb1.removePoint(1)

    def handle_right_click(self):
        if self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint=self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self.showLine(self.startPoint, self.endPoint, event)
            self.move.emit()
        return None

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # 두 점이 같으면 종료
        dx = mousePoint.x() - lastPoint.x()
        dy = mousePoint.y() - lastPoint.y()
        length = math.hypot(dx, dy)
        if length == 0:
            self.guide_rb.hide()
            return

        # 방향 단위벡터
        ux = dx / length
        uy = dy / length

        # 캔버스의 대각선 길이(지도좌표 단위)
        extent = self.canvas.extent()
        diag_len = math.hypot(extent.width(), extent.height())

        # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        pA = QgsPointXY(
            lastPoint.x() - ux * diag_len,
            lastPoint.y() - uy * diag_len
        )
        pB = QgsPointXY(
            lastPoint.x() + ux * diag_len,
            lastPoint.y() + uy * diag_len
        )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(pA, False)
        self.guide_rb.addPoint(pB, True)
        self.guide_rb.show()

    def showLine(self, startPoint, endPoint, event):
        verNum = self.rb1.numberOfVertices()
        if startPoint.x() == endPoint.x() and startPoint.y() == endPoint.y():
            return
        
        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        transform_to_5179 = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        st5179 = transform_to_5179.transform(startPoint)
        en5179 = transform_to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()

        if dx == 0 and dy == 0:
            return
        
        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
        distance = math.hypot(dx, dy)   # EPSG:5179 이므로 "미터" 단위

        if shift_pressed:
            # 각도 스냅
            SNAP_ANGLE = self.dlglength.spinBox_ang.value()
            if SNAP_ANGLE != 0:
                angle_deg =  int((angle_deg + (SNAP_ANGLE/2))/SNAP_ANGLE)*SNAP_ANGLE
                
            # 길이 스냅
            SNAP_DIST = self.dlglength.spinBox_dis.value()
            if SNAP_DIST != 0:
                distance = round(distance / SNAP_DIST) * SNAP_DIST

            # 스냅된 각도/길이로 EPSG:5179 상에서 endPoint 재계산
            angle_rad = math.radians(-(angle_deg) + 90)
            dx = distance * math.cos(angle_rad)
            dy = distance * math.sin(angle_rad)

            en5179 = QgsPointXY(st5179.x() + dx, st5179.y() + dy)

            # 다시 캔버스 CRS 로 변환해서 화면에 그릴 endPoint 갱신
            transform_to_canvas = QgsCoordinateTransform(
                self.epsg5179, self.canvasCRS, QgsProject.instance()
            )
            self.endPoint = transform_to_canvas.transform(en5179)
        else:
            self.endPoint = endPoint

        # ── rubber band 갱신 ─────────────────────────
        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)

        # ── geometry 가져오기 ────────────────────────
        geom = self.rb1.asGeometry()
        if not geom or geom.isEmpty():
            return
        
        # ── 화면 CRS → EPSG:5179 로 변환 ──
        canvas_crs = self.canvas.mapSettings().destinationCrs()   # 현재 화면(프로젝트) 좌표계

        # transform context 는 항상 project 에서 가져오기
        transform = QgsCoordinateTransform(canvas_crs, epsg5179, QgsProject.instance())
        
        # 원본 지오메트리 보존용 복사
        geom_5179 = QgsGeometry(geom)
        geom_5179.transform(transform)   # <-- 여기서 5179 로 좌표 변환

        # 원본 지오메트리 보존용 복사
        da = QgsDistanceArea()
        da.setSourceCrs(epsg5179, QgsProject.instance().transformContext())

        geom_type = QgsWkbTypes.geometryType(geom_5179.wkbType())

        perimeter = 0.0
        area = 0.0

        if geom_type == QgsWkbTypes.LineGeometry:
            perimeter = da.measureLength(geom_5179)       # m 단위
        elif geom_type == QgsWkbTypes.PolygonGeometry:
            perimeter = da.measurePerimeter(geom_5179)    # m 단위
            area = da.measureArea(geom_5179)              # ㎡ 단위

        if verNum == 2:
            perimeter = perimeter / 2

        self.updateGuideLine(self.startPoint, self.endPoint)

        # ── 길이 / 넓이 UI 표시 ──────────────────────
        # 예: lineEdit_2 = 둘레, lineEdit = 넓이
        self.dlglength.lineEdit_2.setText(f"{perimeter:.3f}")
        self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")
        self.dlglength.lineEdit_last.setText(f"{distance:.3f}")

    def reset_rubber_bands(self):
        self.rblist = []
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        self.rb1.reset(QgsWkbTypes.PolygonGeometry)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawRectangle(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)

        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        self.startPoint = None
        self.endPoint = None

        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        # self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 200))
        self.guide_rb.setLineStyle(Qt.DotLine)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        # self.rb1 = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        # self.rb1.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        # self.rb1.setColor(QColor(255, 0, 0, 30))
        # self.rb1.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)

    def activate(self):
        QgsMapTool.activate(self)
        # 필요하다면 여기서 위치를 다시 계산해도 됨(캔버스 크기 변경 대비)
        self.dlglength.show()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
    
    def canvasPressEvent(self, e):
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        self.Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
                self.startPoint=self.toMapCoordinates(e.pos())
                self.endPoint = self.startPoint
            elif self.status == 1:
                self.status = 0
                self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint=self.toMapCoordinates(e.pos())
            self.move.emit()
            self.showRect(self.startPoint, self.endPoint, e)

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # # 두 점이 같으면 종료
        # dx = mousePoint.x() - lastPoint.x()
        # dy = mousePoint.y() - lastPoint.y()
        # length = math.hypot(dx, dy)
        # if length == 0:
        #     self.guide_rb.hide()
        #     return

        # # 방향 단위벡터
        # ux = dx / length
        # uy = dy / length

        # # 캔버스의 대각선 길이(지도좌표 단위)
        # extent = self.canvas.extent()
        # diag_len = math.hypot(extent.width(), extent.height())

        # # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        # pA = QgsPointXY(
        #     lastPoint.x() - ux * diag_len,
        #     lastPoint.y() - uy * diag_len
        # )
        # pB = QgsPointXY(
        #     lastPoint.x() + ux * diag_len,
        #     lastPoint.y() + uy * diag_len
        # )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(lastPoint, False)
        self.guide_rb.addPoint(mousePoint, True)
        self.guide_rb.show()


    def showRect(self, startPoint, endPoint, event):
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        if startPoint == endPoint:
            return
        
        Alt_pressed   = bool(event.modifiers() & Qt.AltModifier)
        Shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)
        Ctrl_pressed  = bool(event.modifiers() & Qt.ControlModifier)

        # 0) 변환 준비 (캔버스 CRS → 5179, 5179 → 캔버스)
        to_5179 = self.Transform  # 이미 canvasCRS → epsg5179 로 만든 변환
        back_tr = QgsCoordinateTransform(self.epsg5179, self.canvasCRS, QgsProject.instance())

        # 1) 시작/끝점을 5179로 변환
        start5179 = to_5179.transform(startPoint)
        end5179   = to_5179.transform(endPoint)

        dx = end5179.x() - start5179.x()
        dy = end5179.y() - start5179.y()
        if dx == 0 and dy == 0:
            return
        
        # 드래그 방향(사분면) 유지용 부호
        sx = 1 if dx >= 0 else -1
        sy = 1 if dy >= 0 else -1

        # 2) Alt 여부에 따라 기본 가로/세로(m) 계산
        if Alt_pressed:
            # 시작점을 중심으로 하는 모드
            width  = abs(dx) * 2.0
            height = abs(dy) * 2.0
        else:
            # 시작점을 모서리로 하는 모드
            width  = abs(dx)
            height = abs(dy)

        SNAP_DIST = self.dlglength.spinBox_dis.value()
        # 3) Ctrl: 정사각형 강제, Shift: 스냅
        if Ctrl_pressed:
            # 정사각형: 항상 한 변(side)으로 통일
            side = max(width, height)
            if Shift_pressed and SNAP_DIST > 0:
                side = round(side / SNAP_DIST) * SNAP_DIST
            width = height = side
        else:
            # 일반 직사각형: 가로/세로 각각 스냅
            if Shift_pressed and SNAP_DIST > 0:
                width  = round(width / SNAP_DIST) * SNAP_DIST
                height = round(height / SNAP_DIST) * SNAP_DIST

        # 4) 5179 상에서 네 꼭짓점 계산
        if Alt_pressed:
            # 시작점 = 중심
            cx = start5179.x()
            cy = start5179.y()
            half_w = width / 2.0
            half_h = height / 2.0

            x1 = cx - sx * half_w
            x2 = cx + sx * half_w
            y1 = cy - sy * half_h
            y2 = cy + sy * half_h
        else:
            # 시작점 = 한 모서리
            x1 = start5179.x()
            y1 = start5179.y()
            x2 = x1 + sx * width
            y2 = y1 + sy * height

        p1_5179 = QgsPointXY(x1, y1)
        p2_5179 = QgsPointXY(x1, y2)
        p3_5179 = QgsPointXY(x2, y2)
        p4_5179 = QgsPointXY(x2, y1)

        # 5) 캔버스 CRS로 다시 변환하여 RubberBand에 추가
        vertices = [
            back_tr.transform(p1_5179),
            back_tr.transform(p2_5179),
            back_tr.transform(p3_5179),
            back_tr.transform(p4_5179),
        ]

        for i, pt in enumerate(vertices):
            self.rb.addPoint(pt, i == len(vertices) - 1)
        self.rb.show()

        # 6) 가로/세로 길이 표시 (항상 5179 기준, 정사각형이면 완전히 동일)
        self.dlglength.lineEdit_2.setText(f"{width:.3f}")
        self.dlglength.lineEdit_last.setText(f"{height:.3f}")
    
    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawRectangle3P(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        
        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        # self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 150))
        self.guide_rb.setLineStyle(Qt.DotLine)

    def activate(self):
        QgsMapTool.activate(self)
        # 필요하다면 여기서 위치를 다시 계산해도 됨(캔버스 크기 변경 대비)

        # 위치만 미리 잡아둠
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)
        self.dlglength.show()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None
    
    def canvasPressEvent(self, e):
        Point=self.toMapCoordinates(e.pos())

        if e.button() == Qt.LeftButton and self.status == 0:
            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.status = 1
            self.startPoint=Point

        if e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 0:
            self.rb.addPoint(Point)
        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 2:
            self.secondPoint=self.endPoint
            self.rb.addPoint(self.endPoint)

        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 4:
            self.status = 0
            self.selectionDone.emit()
            self.reset()

        return None

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint=self.toMapCoordinates(e.pos())
            self.move.emit()
            self.showRect(self.startPoint, self.endPoint, e)

        return None
    
    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # 두 점이 같으면 종료
        dx = mousePoint.x() - lastPoint.x()
        dy = mousePoint.y() - lastPoint.y()
        length = math.hypot(dx, dy)
        if length == 0:
            self.guide_rb.hide()
            return

        # 방향 단위벡터
        ux = dx / length
        uy = dy / length

        # 캔버스의 대각선 길이(지도좌표 단위)
        extent = self.canvas.extent()
        diag_len = math.hypot(extent.width(), extent.height())

        # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        pA = QgsPointXY(
            lastPoint.x() - ux * diag_len,
            lastPoint.y() - uy * diag_len
        )
        pB = QgsPointXY(
            lastPoint.x() + ux * diag_len,
            lastPoint.y() + uy * diag_len
        )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(pA, False)
        self.guide_rb.addPoint(pB, True)
        self.guide_rb.show()

    def showRect(self, startPoint, endPoint, event):
        n = self.rb.numberOfVertices()
        SNAP_ANGLE = self.dlglength.spinBox_ang.value()
        SNAP_DIST = self.dlglength.spinBox_dis.value()

        Shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        transform_to_5179 = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        transform_to_canvas = QgsCoordinateTransform(self.epsg5179, self.canvasCRS, QgsProject.instance())

        st5179 = transform_to_5179.transform(startPoint)
        en5179 = transform_to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()

        if dx == 0 and dy == 0:
            return
        
        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
        distance = math.hypot(dx, dy)   # EPSG:5179 이므로 "미터" 단위
        # ─────────────────────────────
        # 1) 첫 번째 선분(2점만 있을 때) 처리
        #    (기존 Shift + 각도 스냅 유지)
        # ─────────────────────────────
        if n == 2:
            self.rb.removeLastPoint(0)

            if Shift_pressed:
                # 각도 스냅
                # angle_deg = round(angle_deg / SNAP_ANGLE) * SNAP_ANGLE
                angle_deg =  int((angle_deg + (SNAP_ANGLE/2))/SNAP_ANGLE)*SNAP_ANGLE

                # 길이 스냅
                distance = round(distance / SNAP_DIST) * SNAP_DIST
            
                # 스냅된 각도/길이로 EPSG:5179 상에서 endPoint 재계산
                angle_rad = math.radians(-(angle_deg) + 90)
                dx = distance * math.cos(angle_rad)
                dy = distance * math.sin(angle_rad)

                en5179 = QgsPointXY(st5179.x() + dx, st5179.y() + dy)

                # 다시 캔버스 CRS 로 변환해서 화면에 그릴 endPoint 갱신
                transform_to_canvas = QgsCoordinateTransform(
                    self.epsg5179, self.canvasCRS, QgsProject.instance()
                )
                self.endPoint = transform_to_canvas.transform(en5179)

            else:
                # 스냅 없이 그대로
                self.endPoint = endPoint

            self.rb.addPoint(self.endPoint)
            self.rb.show()

            self.updateGuideLine(self.startPoint, self.endPoint)

            self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")   # 세로는 n>2에서만 채움
            self.dlglength.lineEdit_2.setText(f"{distance:.3f}")
            self.dlglength.lineEdit_last.setText(f"{distance:.3f}")
        # ─────────────────────────────
        # 2) 세 번째 클릭 이후: 3점을 이용해 직사각형 완성
        #    (각도 if 대신 벡터/법선 사용)
        # ─────────────────────────────
        elif n > 2:
            # 첫 두 점(startPoint, secondPoint)만 남기고 나머지 삭제
            while self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint(0)

            # ① startPoint, secondPoint, endPoint 를 5179로 변환
            st1_5179 = transform_to_5179.transform(self.startPoint)
            st2_5179 = transform_to_5179.transform(self.secondPoint)
            en_5179  = transform_to_5179.transform(endPoint)

            # ② 기준변: start → second (5179 기준)
            vx_5179 = st2_5179.x() - st1_5179.x()
            vy_5179 = st2_5179.y() - st1_5179.y()
            base_len = math.hypot(vx_5179, vy_5179)    # 가로 길이 (m)

            if base_len  == 0:
                return

            # 단위 법선벡터 (v에 수직인 방향)
            nx = -vy_5179 / base_len
            ny =  vx_5179 / base_len

            # ③ endPoint 가 secondPoint에서 얼마나 떨어졌는지 (5179 기준)
            ox_5179 = en_5179.x() - st2_5179.x()
            oy_5179 = en_5179.y() - st2_5179.y()

            # 마우스 위치를 법선 방향으로 투영한 길이 (부호 포함)
            t = ox_5179 * nx + oy_5179 * ny

            # Shift 누르면 두께(세로)도 스냅
            if Shift_pressed:
                t = round(t / SNAP_DIST) * SNAP_DIST

            # 세로 길이(두께) = |t|
            height_len = abs(t)

            # ④ 5179 상에서 직사각형 나머지 두 꼭짓점 계산
            p3_5179 = QgsPointXY(st2_5179.x() + nx * t, st2_5179.y() + ny * t)
            p4_5179 = QgsPointXY(st1_5179.x() + nx * t, st1_5179.y() + ny * t)


            # ⑤ 다시 캔버스 좌표계로 변환해서 그리기
            p1_canvas = transform_to_canvas.transform(st1_5179)
            p2_canvas = transform_to_canvas.transform(st2_5179)
            p3_canvas = transform_to_canvas.transform(p3_5179)
            p4_canvas = transform_to_canvas.transform(p4_5179)

            # RubberBand 재구성
            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.rb.addPoint(p1_canvas, False)
            self.rb.addPoint(p2_canvas, False)
            self.rb.addPoint(p3_canvas, False)
            self.rb.addPoint(p4_canvas, True)
            self.rb.show()

            # 2번째 점(st2_5179)에서 3번째 점(p3_5179)으로 가는 벡터
            dx = p3_5179.x() - st2_5179.x()
            dy = p3_5179.y() - st2_5179.y()

            # 라디안 각도 (수학 좌표계 기준, +X축(동쪽) 기준 CCW)
            angle_rad = math.atan2(dx, dy)

            # 도(degree)로 변환 (-180 ~ 180)
            angle_deg = math.degrees(angle_rad)

            # 0 ~ 360도로 정규화하고 싶다면
            if angle_deg < 0:
                angle_deg += 360

            self.updateGuideLine(self.secondPoint, p3_canvas)

            self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")  
            self.dlglength.lineEdit_2.setText(f"{height_len:.3f}")
            self.dlglength.lineEdit_last.setText(f"{base_len:.3f}")
        return None

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.status = 0
        self.rb.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawCircleIn(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        
        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 200))
        self.guide_rb.setLineStyle(Qt.DashLine)
        
        self.locale = QSettings()
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))

        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        canvas_height = self.canvas.height()

        x_position = left_top_canvas.x() + canvas_width - self.dlgCircle.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표

        # QDialog를 지정한 위치로 이동합니다.
        self.dlgCircle.move(x_position, y_position)
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value('drawing_Tools/checkBox', Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value('drawing_Tools/lineEdit',0)))
        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value('drawing_Tools/spinBox_vert',5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.status = 0
            self.iface.actionPan().trigger()
            # self.dlgCircle.close()
            # self.reset()

    def wheelEvent(self, event):
        if event.type() == event.Wheel:
            delta = event.angleDelta().y() / 120  # 120은 기본 스크롤 단위입니다.
            if delta > 0:
                print("마우스 휠을 위로 스크롤했습니다.")
                # 위로 스크롤할 때 수행할 동작을 추가합니다.
            else:
                print("마우스 휠을 아래로 스크롤했습니다.")
                # 아래로 스크롤할 때 수행할 동작을 추
        return None

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center=self.toMapCoordinates(e.pos())
            self.canvasCRS = self.canvas.mapSettings().destinationCrs()
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            self.segments = int(self.dlgCircle.spinBox_vert.value())
            if self.dlgCircle.checkBox.isChecked():
                self.radius = self.dlgCircle.lineEdit.text()
                center = self.toMapCoordinates(e.pos())
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                Transform = QgsCoordinateTransform(canvasCRS,epsg5179, QgsProject.instance())
                Point5179 = Transform.transform(center.x(),center.y())
                Transform = QgsCoordinateTransform(epsg5179,canvasCRS, QgsProject.instance())
                cp = Transform.transform(Point5179[0],Point5179[1]+float(self.radius))
                self.rbcircle1(self.rb, center, cp, self.segments)
            else:
                cp = self.toMapCoordinates(e.pos())
                self.rbcircle2(self.rb, self.center, cp, self.segments)
            self.rb.show()
            self.move.emit()

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # # 두 점이 같으면 종료
        # dx = mousePoint.x() - lastPoint.x()
        # dy = mousePoint.y() - lastPoint.y()
        # length = math.hypot(dx, dy)
        # if length == 0:
        #     self.guide_rb.hide()
        #     return

        # # 방향 단위벡터
        # ux = dx / length
        # uy = dy / length

        # # 캔버스의 대각선 길이(지도좌표 단위)
        # extent = self.canvas.extent()
        # diag_len = math.hypot(extent.width(), extent.height())

        # # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        # pA = QgsPointXY(
        #     lastPoint.x() - ux * diag_len,
        #     lastPoint.y() - uy * diag_len
        # )
        # pB = QgsPointXY(
        #     lastPoint.x() + ux * diag_len,
        #     lastPoint.y() + uy * diag_len
        # )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(lastPoint, False)
        self.guide_rb.addPoint(mousePoint, True)
        self.guide_rb.show()


    def rbcircle1(self, rb, center, edgePoint, N):
        if center == edgePoint:
            return
        
        radius = sqrt(center.sqrDist(edgePoint))
        rb.reset(QgsWkbTypes.PolygonGeometry)
        angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
        angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
        for itheta in range(N):
            try:
                ang = 2.0 * pi / (360/angle)
                ang = ang - (2.0 * pi / 4)
            except:
                ang = -(2.0 * pi / 4)

            theta = (itheta * (2.0 * pi / N)) - ang
            rb.addPoint(QgsPointXY(center.x() + radius * cos(theta),
                                center.y() + radius * sin(theta)))

    def rbcircle2(self, rb, center, edgePoint, N):
        '''Fonction qui affiche une rubberband sous forme de cercle'''
        if center == edgePoint:
            return

        rb.reset(QgsWkbTypes.PolygonGeometry)

        # ─────────────────────────────
        # 1) 화면 CRS → EPSG:5179 변환
        # ─────────────────────────────
        to_5179 = QgsCoordinateTransform(self.canvasCRS, self.epsg5179, QgsProject.instance())
        to_canvas = QgsCoordinateTransform(self.epsg5179, self.canvasCRS, QgsProject.instance())

        center5179 = to_5179.transform(center)
        edge5179   = to_5179.transform(edgePoint)

        dx = edge5179.x() - center5179.x()
        dy = edge5179.y() - center5179.y()

        radius = hypot(dx, dy)  # EPSG:5179 이므로 m 단위
        if radius == 0:
            return
        
    # 중심 → 모서리 방향 각도 (0~360도)
        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
        angle_rad = math.radians(-(angle_deg) + 90)

        SNAP_ANGLE = self.dlgCircle.spinBox_ang.value()
        SNAP_DIST = self.dlgCircle.spinBox_dis.value()

        shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)

        if shift_pressed:

            # 각도 스냅
            if SNAP_ANGLE != 0:
                # angle_deg = round(angle_deg / SNAP_ANGLE) * SNAP_ANGLE
                # angle_rad = radians(angle_deg)
                angle_deg =  int((angle_deg + (SNAP_ANGLE/2))/SNAP_ANGLE)*SNAP_ANGLE
                angle_rad = math.radians(-(angle_deg) + 90)

            # 반경(거리) 스냅
            if SNAP_DIST != 0:
                radius = round(radius / SNAP_DIST) * SNAP_DIST

            # 스냅된 각도/길이로 EPSG:5179 상에서 endPoint 재계산
            angle_rad = math.radians(-(angle_deg) + 90)
            dx = radius * math.cos(angle_rad)
            dy = radius * math.sin(angle_rad)

            en5179 = QgsPointXY(center5179.x() + dx, center5179.y() + dy)

            # 다시 캔버스 CRS 로 변환해서 화면에 그릴 endPoint 갱신
            transform_to_canvas = QgsCoordinateTransform(
                self.epsg5179, self.canvasCRS, QgsProject.instance()
            )
            edgePoint = transform_to_canvas.transform(en5179)

            # 반경 표시 (스냅 반영된 값)
        self.dlgCircle.lineEdit.setText(f"{radius:.3f}")
        self.dlgCircle.lineEdit_2.setText(f"{angle_deg:.3f}")
        # ─────────────────────────────
        # 3) EPSG:5179 상에서 N각형 꼭짓점 계산
        #    첫 번째 꼭짓점이 center→edge 방향에 오도록
        # ─────────────────────────────
        points_canvas = []
        for i in range(N):
            theta = angle_rad + i * 2.0 * pi / N
            px_5179 = center5179.x() + radius * cos(theta)
            py_5179 = center5179.y() + radius * sin(theta)

            pt_canvas = to_canvas.transform(QgsPointXY(px_5179, py_5179))
            points_canvas.append(pt_canvas)

            # try:
            #     ang = 2.0 * pi / (360/angle)
            #     ang = ang - (2.0 * pi / 4)
            # except:
            #     ang = -(2.0 * pi / 4)

            # theta = (itheta * (2.0 * pi / N)) - ang
            # rb.addPoint(QgsPointXY(center.x() + radius * cos(theta),
            #                     center.y() + radius * sin(theta)))

        # ─────────────────────────────
        # 4) RubberBand에 꼭짓점 추가
        # ─────────────────────────────
        for i, pt in enumerate(points_canvas):
            # 마지막 점에서 True를 줘서 polygon 닫기
            rb.addPoint(pt, i == len(points_canvas) - 1)

        self.updateGuideLine(center, edgePoint)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        if not self.CTool.actions[6].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)

class DrawCircleOut(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.locale = QSettings()

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
            
        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 200))
        self.guide_rb.setLineStyle(Qt.DashLine)
        
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()

        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlgCircle.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlgCircle.move(x_position, y_position)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value('drawing_Tools/checkBox', Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value('drawing_Tools/lineEdit',0)))
        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value('drawing_Tools/spinBox_vert',5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.dlgCircle.close()
            self.CTool.close(7)
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center=self.toMapCoordinates(e.pos())
            self.canvasCRS = self.canvas.mapSettings().destinationCrs()
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            # construct a circle with N segments
            self.segments = int(self.dlgCircle.spinBox_vert.value())
            if self.dlgCircle.checkBox.isChecked():
                self.radius = self.dlgCircle.lineEdit.text()
                center = self.toMapCoordinates(e.pos())
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                Transform = QgsCoordinateTransform(canvasCRS,epsg5179, QgsProject.instance())
                Point5179 = Transform.transform(center.x(),center.y())
                Transform = QgsCoordinateTransform(epsg5179,canvasCRS, QgsProject.instance())
                cp = Transform.transform(Point5179[0],Point5179[1]+float(self.radius))
                self.rbcircle1(self.rb, center, cp, self.segments)
            else:
                cp = self.toMapCoordinates(e.pos())
                self.rbcircle2(self.rb, self.center, cp, self.segments)
            self.rb.show()
            self.move.emit()

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # # 두 점이 같으면 종료
        # dx = mousePoint.x() - lastPoint.x()
        # dy = mousePoint.y() - lastPoint.y()
        # length = math.hypot(dx, dy)
        # if length == 0:
        #     self.guide_rb.hide()
        #     return

        # # 방향 단위벡터
        # ux = dx / length
        # uy = dy / length

        # # 캔버스의 대각선 길이(지도좌표 단위)
        # extent = self.canvas.extent()
        # diag_len = math.hypot(extent.width(), extent.height())

        # # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        # pA = QgsPointXY(
        #     lastPoint.x() - ux * diag_len,
        #     lastPoint.y() - uy * diag_len
        # )
        # pB = QgsPointXY(
        #     lastPoint.x() + ux * diag_len,
        #     lastPoint.y() + uy * diag_len
        # )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(lastPoint, False)
        self.guide_rb.addPoint(mousePoint, True)
        self.guide_rb.show()

    def rbcircle1(self, rb, center, edgePoint, N):
        if center == edgePoint:
            return
        
        radius = sqrt(center.sqrDist(edgePoint))
        rb.reset(QgsWkbTypes.PolygonGeometry)
        angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
        angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)

        angle_radians = math.radians((360/N)/2)
        hypotenuse_length = radius / math.cos(angle_radians)

        for itheta in range(N):
            try:
                ang = 2.0 * pi / (360/angle)
                ang = ang - (2.0 * pi / 4) - angle_radians
            except:
                ang = -(2.0 * pi / 4)

            theta = (itheta * (2.0 * pi / N)) - ang
            rb.addPoint(QgsPointXY(center.x() + hypotenuse_length * cos(theta),
                                center.y() + hypotenuse_length * sin(theta)))

    def rbcircle2(self, rb, center, edgePoint, N):
        '''Fonction qui affiche une rubberband sous forme de cercle'''
        if center == edgePoint:
            return
        
        rb.reset(QgsWkbTypes.PolygonGeometry)

        # ─────────────────────────────
        # 1) 화면 CRS → EPSG:5179 변환
        # ─────────────────────────────
        to_5179 = QgsCoordinateTransform(self.canvasCRS, self.epsg5179, QgsProject.instance())
        to_canvas = QgsCoordinateTransform(self.epsg5179, self.canvasCRS, QgsProject.instance())

        center5179 = to_5179.transform(center)
        edge5179   = to_5179.transform(edgePoint)

        dx = edge5179.x() - center5179.x()
        dy = edge5179.y() - center5179.y()

        radius = hypot(dx, dy)  # EPSG:5179 이므로 m 단위
        if radius == 0:
            return
        
    # 중심 → 모서리 방향 각도 (0~360도)
        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
        angle_rad = math.radians(-(angle_deg) + 90)

        SNAP_ANGLE = self.dlgCircle.spinBox_ang.value()
        SNAP_DIST = self.dlgCircle.spinBox_dis.value()

        shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)

        if shift_pressed:
            # 각도 스냅
            if SNAP_ANGLE != 0:
                angle_deg =  int((angle_deg + (SNAP_ANGLE/2))/SNAP_ANGLE)*SNAP_ANGLE
                angle_rad = math.radians(-(angle_deg) + 90)

            # 반경(거리) 스냅
            if SNAP_DIST != 0:
                radius = round(radius / SNAP_DIST) * SNAP_DIST

            # 스냅된 각도/길이로 EPSG:5179 상에서 endPoint 재계산
            angle_rad = math.radians(-(angle_deg) + 90)
            dx = radius * math.cos(angle_rad)
            dy = radius * math.sin(angle_rad)

            en5179 = QgsPointXY(center5179.x() + dx, center5179.y() + dy)

            # 다시 캔버스 CRS 로 변환해서 화면에 그릴 endPoint 갱신
            transform_to_canvas = QgsCoordinateTransform(
                self.epsg5179, self.canvasCRS, QgsProject.instance()
            )
            edgePoint = transform_to_canvas.transform(en5179)

        # 반경 표시 (스냅 반영된 값)
        self.dlgCircle.lineEdit.setText(f"{radius:.3f}")
        self.dlgCircle.lineEdit_2.setText(f"{angle_deg:.3f}")

        # ─────────────────────────────
        # 3) 외접 N각형 꼭짓점 계산 (EPSG:5179 상에서)
        #    - center→edgePoint 는 "변의 중앙" 방향(접점)
        #    - 첫 번째 꼭짓점 방향 θ0 = 접점 각도 - π/N
        #    - 외접원 반지름 R = r / cos(π/N)
        # ─────────────────────────────

        half_central = pi / N          # π/N
        R = radius / cos(half_central)      # 외접원 반지름 (center→vertex 길이)

        theta0 = angle_rad - half_central   # 첫 번째 꼭짓점 방향

        pts_canvas = []
        for i in range(N):
            theta = theta0 + 2.0 * pi * i / N
            px = center5179.x() + R * cos(theta)
            py = center5179.y() + R * sin(theta)

            pt_canvas = to_canvas.transform(QgsPointXY(px, py))
            pts_canvas.append(pt_canvas)

        # ─────────────────────────────
        # 4) RubberBand에 추가
        # ─────────────────────────────
        for i, pt in enumerate(pts_canvas):
            rb.addPoint(pt, i == len(pts_canvas) - 1)

        self.updateGuideLine(center, edgePoint)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        if not self.CTool.actions[7].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)

class DrawCircle2P(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.locale = QSettings()

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
            
        self.guide_rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.guide_rb.setWidth(1)
        self.guide_rb.setColor(QColor(10, 10, 10, 200))
        self.guide_rb.setLineStyle(Qt.DashLine)
        
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()

        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlgCircle.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlgCircle.move(x_position, y_position)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value('drawing_Tools/checkBox', Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value('drawing_Tools/lineEdit',0)))
        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value('drawing_Tools/spinBox_vert',5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.dlgCircle.close()
            self.CTool.close(7)
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center=self.toMapCoordinates(e.pos())
            self.canvasCRS = self.canvas.mapSettings().destinationCrs()
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/spinBox_vert',self.segments)
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            # construct a circle with N segments
            self.segments = int(self.dlgCircle.spinBox_vert.value())
            if self.dlgCircle.checkBox.isChecked():
                self.radius = self.dlgCircle.lineEdit.text()
                center = self.toMapCoordinates(e.pos())
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                Transform = QgsCoordinateTransform(canvasCRS,epsg5179, QgsProject.instance())
                Point5179 = Transform.transform(center.x(),center.y())
                Transform = QgsCoordinateTransform(epsg5179,canvasCRS, QgsProject.instance())
                cp = Transform.transform(Point5179[0],Point5179[1]+float(self.radius))
                self.rbcircle1(self.rb, center, cp, self.segments)
            else:
                cp = self.toMapCoordinates(e.pos())
                self.rbcircle2(self.rb, self.center, cp, self.segments)
            self.rb.show()
            self.move.emit()

    def updateGuideLine(self, lastPoint: QgsPointXY, mousePoint: QgsPointXY):
        # 두 점이 같으면 종료
        dx = mousePoint.x() - lastPoint.x()
        dy = mousePoint.y() - lastPoint.y()
        length = math.hypot(dx, dy)
        if length == 0:
            self.guide_rb.hide()
            return

        # 방향 단위벡터
        ux = dx / length
        uy = dy / length

        # 캔버스의 대각선 길이(지도좌표 단위)
        extent = self.canvas.extent()
        diag_len = math.hypot(extent.width(), extent.height())

        # lastPoint 기준으로 양쪽으로 diag_len 만큼 늘리기
        pA = QgsPointXY(
            lastPoint.x() - ux * diag_len,
            lastPoint.y() - uy * diag_len
        )
        pB = QgsPointXY(
            lastPoint.x() + ux * diag_len,
            lastPoint.y() + uy * diag_len
        )

        # RubberBand 갱신
        self.guide_rb.reset(QgsWkbTypes.LineGeometry)
        self.guide_rb.addPoint(pA, False)
        self.guide_rb.addPoint(pB, True)
        self.guide_rb.show()

    def rbcircle1(self, rb, center, edgePoint, N):
        if center == edgePoint:
            return
        
        radius = sqrt(center.sqrDist(edgePoint))
        rb.reset(QgsWkbTypes.PolygonGeometry)
        angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
        angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
        for itheta in range(N):
            try:
                ang = 2.0 * pi / (360/angle)
                ang = ang - (2.0 * pi / 4)
            except:
                ang = -(2.0 * pi / 4)

            theta = (itheta * (2.0 * pi / N)) - ang
            rb.addPoint(QgsPointXY(center.x() + radius * cos(theta),
                                center.y() + radius * sin(theta)))

    def rbcircle2(self, rb, p1_canvas: QgsPointXY, p2_canvas: QgsPointXY, N: int):
        """
        시작점(p1)–종점(p2)을 한 변으로 갖는 정 N각형을 그립니다.
        p1_canvas, p2_canvas : 캔버스 CRS 좌표
        N                   : 꼭짓점 개수(3 이상)
        Shift 키를 누른 상태에서는 각/길이 스냅을 적용합니다.
        """
        if N < 3:
            return
        if p1_canvas == p2_canvas:
            return

        # ── 0) Shift 스냅 설정값 읽기 ──────────────────────────
        SNAP_ANGLE = self.dlgCircle.spinBox_ang.value()   # 도 단위
        SNAP_DIST  = self.dlgCircle.spinBox_dis.value()   # m 단위(5179 기준)
        shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)

        # ── 1) 캔버스 CRS → EPSG:5179 변환 ─────────────────────
        to_5179   = QgsCoordinateTransform(self.canvasCRS, self.epsg5179, QgsProject.instance())
        to_canvas = QgsCoordinateTransform(self.epsg5179, self.canvasCRS, QgsProject.instance())

        A = to_5179.transform(p1_canvas)
        B = to_5179.transform(p2_canvas)

        dx = B.x() - A.x()
        dy = B.y() - A.y()
        side_len = math.hypot(dx, dy)
        if side_len == 0:
            return
        
        # 방향 각도(0~360°, +X축 기준)
        angle_deg = math.degrees(math.atan2(dx, dy))
        if angle_deg < 0:
            angle_deg += 360.0
            
        # ── 2) Shift 누르면 변 방향/길이 스냅 ──────────────────
        if shift_pressed:

            # 각도 스냅 (예: 15°, 30° …)
            if SNAP_ANGLE != 0:
                angle_deg = int((angle_deg + SNAP_ANGLE / 2.0) / SNAP_ANGLE) * SNAP_ANGLE

            # 길이 스냅
            if SNAP_DIST != 0:
                side_len = round(side_len / SNAP_DIST) * SNAP_DIST

            angle_rad = math.radians(-(angle_deg) + 90)

            # 스냅된 각도/길이로 B 재계산
            B = QgsPointXY(
                A.x() + side_len * math.cos(angle_rad),
                A.y() + side_len * math.sin(angle_rad)
            )

            # 벡터/길이 다시 계산
            dx = B.x() - A.x()
            dy = B.y() - A.y()
            side_len = math.hypot(dx, dy)
            if side_len == 0:
                return
            p2_canvas = to_canvas.transform(B)
        # ── 3) 정N각형의 반지름 r, 중심까지 거리 h ─────────────
        s = side_len
        angle_unit = math.pi / float(N)
        r = s / (2.0 * math.sin(angle_unit))   # 외접원 반지름
        h = s / (2.0 * math.tan(angle_unit))   # 변중점→중심 거리

        # 변의 중점 M
        mx = (A.x() + B.x()) / 2.0
        my = (A.y() + B.y()) / 2.0

        # 변에 수직인 단위 법선 벡터
        nx = -dy / side_len
        ny =  dx / side_len
        # 필요하면 방향 반대로: nx, ny = -nx, -ny

        # 중심 C = M + n * h
        cx = mx + nx * h
        cy = my + ny * h
        center5179 = QgsPointXY(cx, cy)

        # 첫 꼭짓점을 A로 두기 위한 시작각
        start_angle = math.atan2(A.y() - center5179.y(), A.x() - center5179.x())

        # ── 4) 꼭짓점 계산 후 RubberBand 갱신 ────────────────
        rb.reset(QgsWkbTypes.PolygonGeometry)
        for i in range(N):
            theta = start_angle + 2.0 * math.pi * i / float(N)
            px = center5179.x() + r * math.cos(theta)
            py = center5179.y() + r * math.sin(theta)
            pt_canvas = to_canvas.transform(QgsPointXY(px, py))
            rb.addPoint(pt_canvas, i == N - 1)  # 마지막 점에서 polygon 닫기

        # 반경 표시 (스냅 반영된 값)
        self.dlgCircle.lineEdit.setText(f"{side_len:.3f}")
        self.dlgCircle.lineEdit_2.setText(f"{angle_deg:.3f}")

        self.updateGuideLine(p1_canvas, p2_canvas)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()
        
    def deactivate(self):
        if not self.CTool.actions[7].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)