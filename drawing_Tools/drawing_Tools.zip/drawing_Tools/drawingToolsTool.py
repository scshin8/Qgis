from qgis.PyQt.QtCore import Qt, pyqtSignal, QVariant
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import *
from qgis.gui import *
from PyQt5.QtCore import QPoint, QSettings, Qt

import time, math
from math import sqrt, pi, cos, sin
from .drawing_Tools_Circle import drawingToolsCircle
from .drawing_Tools_length import drawingToolslength

epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

# import traceback
class DrawPoint(QgsMapToolEmitPoint):
    selectionDone = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb.setWidth(3)
        self.rb.setColor(QColor(60, 151, 255, 255))
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None

    def canvasPressEvent(self, e):
        # # 스냅된 지점을 가져오는 예시 코드입니다.
        # snap_info = self.canvas.snappingUtils().snapToMap(e.pos())
        # if snap_info.isValid():
        #     snap_point = snap_info.point()
        #     # snap_point를 사용하여 원하는 작업을 수행합니다.
        #     print("스냅된 지점:", snap_point)

        if e.button() == Qt.LeftButton:
            self.rb.reset(QgsWkbTypes.PointGeometry)
            Point=self.toMapCoordinates(e.pos())
            self.rb.addPoint(Point)
            self.selectionDone.emit()
        return None
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)

    # def canvasMoveEvent(self, event):

    #     # 스냅된 지점을 가져오는 예시 코드입니다.
    #     snap_info = self.canvas.snappingUtils().snapToMap(event.pos())
    #     if snap_info.isValid():
    #         snap_point = snap_info.point()

    #         # 스냅된 지점을 화면에 표시합니다.
    #         marker = QgsVertexMarker(self.canvas)
    #         marker.setCenter(snap_point)
    #         marker.setColor(Qt.red)  # 원하는 색상으로 설정합니다.
    #         marker.setIconSize(5)  # 원하는 크기로 설정합니다.
    #         marker.setIconType(QgsVertexMarker.ICON_CIRCLE)  # 원 모양의 아이콘을 사용합니다.

    #         # snap_point를 사용하여 원하는 작업을 수행합니다.
    #         print("스냅된 지점:", snap_point)

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)

class DrawLine(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.rblist = []

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self.dlglength.show()
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)

        self.rb = self.create_rubber_band(QColor(255, 0, 0, 255))
        self.rb1 = self.create_rubber_band(QColor(255, 0, 0, 255), Qt.DotLine)

        self.startPoint=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)
        self.endPoint=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        self.distance1end = 0
    def create_rubber_band(self, color, line_style=None):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        rb.setColor(color)
        if line_style:
            rb.setLineStyle(line_style)
        return rb

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            self.rblist.pop()
            self.update_rubber_band()
        elif event.matches(QKeySequence.Cancel):
            self.reset()
            self.dlglength.close()
            self.iface.actionPan().trigger()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.dlglength.show()
            self.distance1end = 0
            self.reset()

    def canvasPressEvent(self, event):
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        if event.button() == Qt.LeftButton:
            self.handle_left_click(event)
        else:
            self.handle_right_click()

    def handle_left_click(self, event):
        self.startPoint = self.toMapCoordinates(event.pos())
        if self.status == 0:
            self.rblist.clear()
            self.rb.reset(QgsWkbTypes.LineGeometry)
            self.rb1.reset(QgsWkbTypes.LineGeometry)
            self.status = 1

        if self.rb.numberOfVertices() < 1:
            self.rb.addPoint(self.startPoint)
            self.rb1.addPoint(self.startPoint)
        else:
            self.rb.addPoint(self.endPoint)
            self.rb1.addPoint(self.endPoint)
            self.startPoint = self.endPoint
            self.distance1end = self.distance1end + self.distance1
            self.rb1.removePoint(0)

        self.rblist.append(self.startPoint)

    def handle_right_click(self):
        if len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.dlglength.show()
            self.distance1end = 0
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint=self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self.showLine(self.startPoint, self.endPoint, event)
            self.move.emit()

    def showLine(self, startPoint, endPoint, event):
        if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
            return

        Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        st5179 = Transform.transform(self.startPoint.x(),self.startPoint.y())
        en5179 = Transform.transform(self.endPoint.x(),self.endPoint.y())

        angle1 = math.atan2(en5179.x() - st5179.x(), en5179.y() - st5179.y())
        angle1 = int(math.degrees(angle1)if angle1 > 0 else (math.degrees(angle1) + 180)+180)
        self.distance1 = math.sqrt((en5179.x() - st5179.x())**2 + (en5179.y() - st5179.y())**2)


        if event.modifiers() & Qt.ShiftModifier:
            angle = math.atan2(self.endPoint.x() - self.startPoint.x(), self.endPoint.y() - self.startPoint.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
            distance = math.sqrt((endPoint.x() - startPoint.x())**2 + (endPoint.y() - startPoint.y())**2)

            angle_radians = math.radians(-(int((angle+7.5)/15)*15) + 90)
            
            x2 = startPoint.x() + distance * math.cos(angle_radians)
            y2 = startPoint.y() + distance * math.sin(angle_radians)
            self.endPoint = QgsPointXY(x2, y2)

            Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
            st5179 = Transform.transform(self.startPoint.x(),self.startPoint.y())
            en5179 = Transform.transform(self.endPoint.x(),self.endPoint.y())

            angle1 = math.atan2(en5179.x() - st5179.x(), en5179.y() - st5179.y())
            angle1 = int(math.degrees(angle1)if angle1 > 0 else (math.degrees(angle1) + 180)+180)
            angle1 = int((angle1+7.5)/15)*15

            self.distance1 = math.sqrt((en5179.x() - st5179.x())**2 + (en5179.y() - st5179.y())**2)

        self.dlglength.lineEdit_2.setText(str(round(self.distance1end + self.distance1,2)))
        self.dlglength.lineEdit.setText(str(round(angle1,2)))

            # val = startPoint.x() - endPoint.x()
            # self.endPoint = QgsPointXY(endPoint.x(), endPoint.y())
            # # # 각도 추출 경위도 좌표계에서는 정방향 TM좌표계에서는 역방향 
            # angle = math.atan2(self.endPoint.x() - self.startPoint.x(), self.endPoint.y() - self.startPoint.y())
            # angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
            # if (angle >= 338 or angle <= 23) or (angle >= 157 and angle <= 203):
            #     self.endPoint = QgsPointXY(startPoint.x(), endPoint.y())
            # elif (angle > 23 and angle < 67) or (angle > 203 and angle < 247):
            #     self.endPoint = QgsPointXY(startPoint.x() - val, startPoint.y() - val)
            # elif (angle >= 67 and angle <= 113) or (angle >= 247 and angle <= 293):
            #     self.endPoint = QgsPointXY(endPoint.x(), startPoint.y())
            # elif (angle > 113 and angle < 157) or (angle > 293 and angle < 338):
            #     self.endPoint = QgsPointXY(startPoint.x() - val, startPoint.y() + val)

        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawDrawing(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.LeftButton = False
        self.status = 0

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) 
        self.rb.setColor(QColor(255, 0, 0, 255)) # 라인 색깔
        # self.rb.setWidth(5)  # 라인 너비

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
    
    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = True
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.status = 1
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
        else:
            self.handle_right_click()

    def handle_right_click(self):    
            if self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint()
                self.selectionDone.emit()
            self.reset()

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = False
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        time.sleep(0.01) 
        if self.LeftButton and self.status == 1:
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
            self.move.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)

class Drawpolygon(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0

        self.rblist = []
        self.startPoint = None
        self.endPoint = None

        self.rb = self.create_rubber_band(QColor(255, 0, 0, 30))
        self.rb1 = self.create_rubber_band(QColor(255, 0, 0, 30), Qt.DotLine)

    def create_rubber_band(self, fill_color, line_style=None):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(fill_color)
        rb.setStrokeColor(QColor(255, 0, 0, 255))
        if line_style:
            rb.setLineStyle(line_style)
        return rb

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            self.undo_last_point()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def undo_last_point(self):
        if self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            self.rblist.pop()
            self.update_rubber_band()
        elif self.rb.numberOfVertices() == 1:
            self.reset()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
            self.reset()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.handle_left_click(e)
        else:
            self.handle_right_click()

    def handle_left_click(self, e):
        self.startPoint = self.toMapCoordinates(e.pos())
        if self.status == 0:
            self.reset_rubber_bands()
            self.status = 1

        if self.status == 1:
            self.rb.addPoint(self.endPoint)
            self.rblist.append(self.endPoint)
            self.rb1.addPoint(self.endPoint)
            self.startPoint = self.endPoint

        if self.rb1.numberOfVertices() == 4:
            self.rb1.removePoint(1)

    def handle_right_click(self):
        if self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint=self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self.showLine(self.startPoint, self.endPoint, event)
            self.move.emit()
        return None

    def showLine(self, startPoint, endPoint, event):
        if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
            return
        if event.modifiers() & Qt.ShiftModifier:
            angle = math.atan2(self.endPoint.x() - self.startPoint.x(), self.endPoint.y() - self.startPoint.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
            distance = math.sqrt((endPoint.x() - startPoint.x())**2 + (endPoint.y() - startPoint.y())**2)

            angle_radians = math.radians(-(int((angle+7.5)/15)*15) + 90)
            x2 = startPoint.x() + distance * math.cos(angle_radians)
            y2 = startPoint.y() + distance * math.sin(angle_radians)
            self.endPoint = QgsPointXY(x2, y2)

        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)

    def reset_rubber_bands(self):
        self.rblist = []
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        self.rb1.reset(QgsWkbTypes.PolygonGeometry)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)

class DrawRectangle(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self.dlglength.show()
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        # canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlglength.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlglength.move(x_position, y_position)

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        self.startPoint = None
        self.endPoint = None

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        # self.rb1 = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        # self.rb1.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        # self.rb1.setColor(QColor(255, 0, 0, 30))
        # self.rb1.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
    
    def canvasPressEvent(self, e):
        self.canvasCRS = self.canvas.mapSettings().destinationCrs()
        self.Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
                self.startPoint=self.toMapCoordinates(e.pos())
                self.endPoint = self.startPoint
            elif self.status == 1:
                self.status = 0
                self.selectionDone.emit()
                self.dlglength.show()

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint=self.toMapCoordinates(e.pos())
            self.move.emit()
            self.showRect(self.startPoint, self.endPoint, e)

    def showRect(self, startPoint, endPoint, event):
        self.rb.reset(QgsWkbTypes.PolygonGeometry)  # true, it's a polygon
        if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
            return
        if event.modifiers() & Qt.ShiftModifier:
            # X축과 Y축 차이를 비교하여 긴 축을 기준으로 정사각형을 생성하는 로직
            val1 = startPoint.x() - endPoint.x()
            val2 = startPoint.y() - endPoint.y()
            if abs(val1) > abs(val2):
                if (startPoint.x() < endPoint.x()) == (startPoint.y() < endPoint.y()):
                    endPointY = startPoint.y() - val1
                else:
                    endPointY = startPoint.y() + val1

                vertices = [QgsPointXY(startPoint.x(), startPoint.y()),
                            QgsPointXY(startPoint.x(), endPointY),
                            QgsPointXY(startPoint.x() - val1, endPointY),
                            QgsPointXY(startPoint.x() - val1, startPoint.y())]
            else:
                if (startPoint.x() < endPoint.x()) == (startPoint.y() < endPoint.y()):
                    endPointX = startPoint.x() - val2
                else:
                    endPointX = startPoint.x() + val2

                vertices = [QgsPointXY(startPoint.x(), startPoint.y()),
                            QgsPointXY(endPointX, startPoint.y()),
                            QgsPointXY(endPointX, startPoint.y() - val2),
                            QgsPointXY(startPoint.x(), startPoint.y() - val2)]

        elif event.modifiers() & Qt.AltModifier:
            val1 = startPoint.x() - endPoint.x()
            val2 = startPoint.y() - endPoint.y()
            vertices = [QgsPointXY(startPoint.x()+val1, startPoint.y()+val2),
                        QgsPointXY(startPoint.x()+val1, endPoint.y()),
                        QgsPointXY(endPoint.x(), endPoint.y()),
                        QgsPointXY(endPoint.x(), startPoint.y()+val2)]
        else:
            vertices = [QgsPointXY(startPoint.x(), startPoint.y()),
                        QgsPointXY(startPoint.x(), endPoint.y()),
                        QgsPointXY(endPoint.x(), endPoint.y()),
                        QgsPointXY(endPoint.x(), startPoint.y())]

        for point in vertices[:-1]:
            self.rb.addPoint(point, False)
        st5179 = self.Transform.transform(vertices[0].x(),vertices[0].y())
        en5179 = self.Transform.transform(vertices[2].x(),vertices[2].y())  
        self.rb.addPoint(vertices[-1], True)
        self.rb.show()

        w = abs(st5179.x() - en5179.x())
        h = abs(st5179.y() - en5179.y())

        self.dlglength.lineEdit_2.setText(str(round(w,2)))
        self.dlglength.lineEdit.setText(str(round(h,2)))

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawRectangle3P(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)

        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None
    
    def canvasPressEvent(self, e):
        Point=self.toMapCoordinates(e.pos())

        if e.button() == Qt.LeftButton and self.status == 0:
            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.status = 1
            self.startPoint=Point

        if e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 0:
            self.rb.addPoint(Point)
        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 2:
            self.secondPoint=self.endPoint
            self.rb.addPoint(self.endPoint)

        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 4:
            self.status = 0
            self.selectionDone.emit() 
        return None

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint=self.toMapCoordinates(e.pos())
            self.move.emit()
            self.showRect(self.startPoint, self.endPoint, e)

        return None

    def showRect(self, startPoint, endPoint, event):

        if self.rb.numberOfVertices() == 2:
            self.rb.removeLastPoint(0)
            if event.modifiers() & Qt.ShiftModifier:
                angle = math.atan2(self.endPoint.x() - self.startPoint.x(), self.endPoint.y() - self.startPoint.y())
                angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
                distance = math.sqrt((endPoint.x() - startPoint.x())**2 + (endPoint.y() - startPoint.y())**2)

                angle_radians = math.radians(-(int((angle+7.5)/15)*15) + 90)
                x2 = startPoint.x() + distance * math.cos(angle_radians)
                y2 = startPoint.y() + distance * math.sin(angle_radians)
                self.endPoint = QgsPointXY(x2, y2)

            self.rb.addPoint(self.endPoint)
            self.rb.show()

        elif self.rb.numberOfVertices() > 2:
            self.rb.removeLastPoint(0)
            if self.rb.numberOfVertices() == 3:
                self.rb.removeLastPoint(0)
            angle = math.atan2(self.secondPoint.x() - self.startPoint.x(), self.secondPoint.y() - self.startPoint.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
            distance = math.sqrt((endPoint.x() - self.secondPoint.x())**2 + (endPoint.y() - self.secondPoint.y())**2)
            angle_radians = math.radians(-angle)

            if angle >= 315 or angle <= 45:
                angle_radians = math.radians(-angle if endPoint.x() > self.secondPoint.x() else (-angle+180))
            elif angle >= 135 and angle <= 225:
                angle_radians = math.radians(-angle if endPoint.x() < self.secondPoint.x() else (-angle+180))
            elif angle > 45 and angle < 135:
                angle_radians = math.radians(-angle if endPoint.y() < self.secondPoint.y() else (-angle+180))
            elif angle > 225 and angle < 315:
                angle_radians = math.radians(-angle if endPoint.y() > self.secondPoint.y() else (-angle+180))

            x1 = self.secondPoint.x() + distance * math.cos(angle_radians)
            y1 = self.secondPoint.y() + distance * math.sin(angle_radians)
            endPoint = QgsPointXY(x1, y1)
            self.rb.addPoint(endPoint)

            x2 = self.startPoint.x() + distance * math.cos(angle_radians)
            y2 = self.startPoint.y() + distance * math.sin(angle_radians)
            endPoint = QgsPointXY(x2, y2)
            self.rb.addPoint(endPoint)
            self.rb.show()

        return None

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.status = 0
        self.rb.reset()
        QgsMapTool.deactivate(self)

class DrawCircleIn(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        self.locale = QSettings()
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))

        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        canvas_height = self.canvas.height()

        x_position = left_top_canvas.x() + canvas_width - self.dlgCircle.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표

        # QDialog를 지정한 위치로 이동합니다.
        self.dlgCircle.move(x_position, y_position)
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value('drawing_Tools/checkBox', Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value('drawing_Tools/lineEdit',0)))
        self.dlgCircle.lineEdit_2.setText(str(self.locale.value('drawing_Tools/lineEdit_2',5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.status = 0
            self.iface.actionPan().trigger()
            # self.dlgCircle.close()
            # self.reset()

    # def wheelEvent(self, event):
    #     if event.type() == event.Wheel:
    #         delta = event.angleDelta().y() / 120  # 120은 기본 스크롤 단위입니다.
    #         if delta > 0:
    #             print("마우스 휠을 위로 스크롤했습니다.")
    #             # 위로 스크롤할 때 수행할 동작을 추가합니다.
    #         else:
    #             print("마우스 휠을 아래로 스크롤했습니다.")
    #             # 아래로 스크롤할 때 수행할 동작을 추
    #     return None

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center=self.toMapCoordinates(e.pos())
            self.canvasCRS = self.canvas.mapSettings().destinationCrs()
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/lineEdit_2',self.segments)
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/lineEdit_2',self.segments)
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            self.segments = int(self.dlgCircle.lineEdit_2.text())
            if self.dlgCircle.checkBox.isChecked():
                self.radius = self.dlgCircle.lineEdit.text()
                center = self.toMapCoordinates(e.pos())
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                Transform = QgsCoordinateTransform(canvasCRS,epsg5179, QgsProject.instance())
                Point5179 = Transform.transform(center.x(),center.y())
                Transform = QgsCoordinateTransform(epsg5179,canvasCRS, QgsProject.instance())
                cp = Transform.transform(Point5179[0],Point5179[1]+float(self.radius))
                self.rbcircle1(self.rb, center, cp, self.segments)
            else:
                cp = self.toMapCoordinates(e.pos())
                self.rbcircle2(self.rb, self.center, cp, self.segments)
            self.rb.show()
            self.move.emit()

    def rbcircle1(self, rb, center, edgePoint, N):
        if center != edgePoint:
            radius = sqrt(center.sqrDist(edgePoint))
            rb.reset(QgsWkbTypes.PolygonGeometry)
            angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)
            for itheta in range(N):
                try:
                    ang = 2.0 * pi / (360/angle)
                    ang = ang - (2.0 * pi / 4)
                except:
                    ang = -(2.0 * pi / 4)

                theta = (itheta * (2.0 * pi / N)) - ang
                rb.addPoint(QgsPointXY(center.x() + radius * cos(theta),
                                    center.y() + radius * sin(theta)))

    def rbcircle2(self, rb, center, edgePoint, N):
        '''Fonction qui affiche une rubberband sous forme de cercle'''
        if center != edgePoint:
            radius = sqrt(center.sqrDist(edgePoint))
            rb.reset(QgsWkbTypes.PolygonGeometry)
            angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)

            Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
            center5179 = Transform.transform(center.x(),center.y())
            edge5179 = Transform.transform(edgePoint.x(),edgePoint.y())

            distance = math.sqrt((edge5179.x() - center5179.x())**2 + (edge5179.y() - center5179.y())**2)
            self.dlgCircle.lineEdit.setText(str(round(distance,2)))

            # angle_radians = math.radians(-(int((angle+22.5)/45)*45) + 90)
            # x2 = center.x() + distance * math.cos(angle_radians)
            # y2 = center.y() + distance * math.sin(angle_radians)
            # self.endPoint = QgsPointXY(x2, y2)
            for itheta in range(N):
                try:
                    ang = 2.0 * pi / (360/angle)
                    ang = ang - (2.0 * pi / 4)
                except:
                    ang = -(2.0 * pi / 4)

                theta = (itheta * (2.0 * pi / N)) - ang
                rb.addPoint(QgsPointXY(center.x() + radius * cos(theta),
                                    center.y() + radius * sin(theta)))

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        if not self.CTool.actions[6].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)

class DrawCircleOut(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx
        self.status = 0
        self.locale = QSettings()
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()
        # 화면 좌측 상단의 좌표를 스크린 좌표로 변환합니다.
        left_top_canvas = self.canvas.mapToGlobal(QPoint(0, 0))
        # 현재 맵 캔버스의 너비와 높이를 얻습니다.
        canvas_width = self.canvas.width()
        canvas_height = self.canvas.height()
        x_position = left_top_canvas.x() + canvas_width - self.dlgCircle.size().width() # x 좌표
        y_position = left_top_canvas.y()  # y 좌표
        # QDialog를 지정한 위치로 이동합니다.
        self.dlgCircle.move(x_position, y_position)

        self.epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value('drawing_Tools/checkBox', Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value('drawing_Tools/lineEdit',0)))
        self.dlgCircle.lineEdit_2.setText(str(self.locale.value('drawing_Tools/lineEdit_2',5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.dlgCircle.close()
            self.CTool.close(7)
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center=self.toMapCoordinates(e.pos())
            self.canvasCRS = self.canvas.mapSettings().destinationCrs()
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/lineEdit_2',self.segments)
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self.locale.setValue('drawing_Tools/checkBox',self.dlgCircle.checkBox.checkState())
            self.locale.setValue('drawing_Tools/lineEdit',self.dlgCircle.lineEdit.text())
            self.locale.setValue('drawing_Tools/lineEdit_2',self.segments)
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            # construct a circle with N segments
            self.segments = int(self.dlgCircle.lineEdit_2.text())
            if self.dlgCircle.checkBox.isChecked():
                self.radius = self.dlgCircle.lineEdit.text()
                center = self.toMapCoordinates(e.pos())
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                Transform = QgsCoordinateTransform(canvasCRS,epsg5179, QgsProject.instance())
                Point5179 = Transform.transform(center.x(),center.y())
                Transform = QgsCoordinateTransform(epsg5179,canvasCRS, QgsProject.instance())
                cp = Transform.transform(Point5179[0],Point5179[1]+float(self.radius))
                self.rbcircle1(self.rb, center, cp, self.segments)
            else:
                cp = self.toMapCoordinates(e.pos())
                self.rbcircle2(self.rb, self.center, cp, self.segments)
            self.rb.show()
            self.move.emit()

    def rbcircle1(self, rb, center, edgePoint, N):

        if center != edgePoint:
            radius = sqrt(center.sqrDist(edgePoint))
            rb.reset(QgsWkbTypes.PolygonGeometry)
            angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)

            angle_radians = math.radians((360/N)/2)
            hypotenuse_length = radius / math.cos(angle_radians)

            for itheta in range(N):
                try:
                    ang = 2.0 * pi / (360/angle)
                    ang = ang - (2.0 * pi / 4) - angle_radians
                except:
                    ang = -(2.0 * pi / 4)

                theta = (itheta * (2.0 * pi / N)) - ang
                rb.addPoint(QgsPointXY(center.x() + hypotenuse_length * cos(theta),
                                    center.y() + hypotenuse_length * sin(theta)))

    def rbcircle2(self, rb, center, edgePoint, N):
        '''Fonction qui affiche une rubberband sous forme de cercle'''
        if center != edgePoint:
            radius = sqrt(center.sqrDist(edgePoint))
            rb.reset(QgsWkbTypes.PolygonGeometry)
            angle = math.atan2(edgePoint.x() - center.x(), edgePoint.y() - center.y())
            angle = int(math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180)

            Transform = QgsCoordinateTransform(self.canvasCRS,self.epsg5179, QgsProject.instance())
            center5179 = Transform.transform(center.x(),center.y())
            edge5179 = Transform.transform(edgePoint.x(),edgePoint.y())

            distance = math.sqrt((edge5179.x() - center5179.x())**2 + (edge5179.y() - center5179.y())**2)
            self.dlgCircle.lineEdit.setText(str(round(distance,2)))

            angle_radians = math.radians((360/N)/2)
            hypotenuse_length = radius / math.cos(angle_radians)
            # angle_radians = math.radians(-(int((angle+22.5)/45)*45) + 90)
            # x2 = center.x() + hypotenuse_length * math.cos(angle_radians)
            # y2 = center.y() + hypotenuse_length * math.sin(angle_radians)
            # self.endPoint = QgsPointXY(x2, y2)
            for itheta in range(N):
                try:
                    ang = 2.0 * pi / (360/angle)
                    ang = ang - (2.0 * pi / 4) - angle_radians
                except:
                    ang = (2.0 * pi / 4)

                theta = (itheta * (2.0 * pi / N)) - ang
                rb.addPoint(QgsPointXY(center.x() + hypotenuse_length * cos(theta),
                                    center.y() + hypotenuse_length * sin(theta)))

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        if not self.CTool.actions[7].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)