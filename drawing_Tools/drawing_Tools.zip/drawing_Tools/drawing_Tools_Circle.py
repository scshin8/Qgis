
import os
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from PyQt5.QtCore import Qt
from qgis.PyQt.QtGui import QKeySequence

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui\drawing_Tools_Circle.ui'))

class drawingToolsCircle(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, iface, Tools, idx, parent=None):
        """Constructor."""
        super(drawingToolsCircle, self).__init__(parent, Qt.WindowStaysOnTopHint)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        self.idx = idx
        self.Tools = Tools
        self.iface = iface

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.Tools.actions[self.idx].setChecked(False)
            self.iface.actionPan().trigger()
            event.accept()  # 창을 닫습니다.

    def closeEvent(self, event):
        # self.Tools.close(self.idx)
        self.Tools.actions[self.idx].setChecked(False)
        self.iface.actionPan().trigger()
        event.accept()  # 창을 닫습니다.