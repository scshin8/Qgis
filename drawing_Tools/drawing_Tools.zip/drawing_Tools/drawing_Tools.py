# -*- coding: utf-8 -*-
""" 
2022-01-06 : 

2025-12-15 : 폴리곤2P 스냅기능 오차 수정

"""
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.gui import *
from PyQt5.QtGui import *

# Import the code for the dialog

from .drawingToolsTool_RE import DrawPoint, DrawLine, Drawpolygon, DrawDrawing, DrawRectangle, DrawRectangle3P, DrawCircleIn, DrawCircleOut, DrawCircle2P
import os.path
import random

epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

class drawingTools:

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.sb = self.iface.statusBarIface()
        self.Tool = None
        self.myaction = None
        self.idx = None
        self.toolbar = self.iface.addToolBar('그리기도구 툴바')
        self.toolbar.setObjectName('drawing_Tools_toolbar')

        self.plugin_dir = os.path.dirname(__file__)
        locale= QSettings()
        locale_path = os.path.join(self.plugin_dir,'i18n','drawingTools_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # self.Comment_crs = QgsCoordinateReferenceSystem(locale.value('locale/drawingTools/Project1','EPSG:4326'))

        self.actions = []
        self.menu = self.tr(u'&그리기도구')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('drawingTools', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.setCheckable(True)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        # if status_tip is not None:
        #     action.setStatusTip(status_tip)

        # if whats_this is not None:
        #     action.setWhatsThis(whats_this)

        # if add_to_toolbar:
        #     # Adds plugin icon to Plugins toolbar
        #     self.iface.addToolBarIcon(add_action)

        # if add_to_menu:
        #     self.iface.addPluginToMenu(
        #         self.menu,
        #         action)
            
        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        iconPoint_path = QIcon(os.path.dirname(__file__) + "/image/iconPoint.png")
        self.add_action(
            iconPoint_path,
            text=self.tr(u'포인트'),
            callback=(lambda : self.startdraw('Point', '그리기(포인트)', 0)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[0])
        self.iface.registerMainWindowAction(self.actions[0], "Shift+X")

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconLine.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'라인'),
            callback=(lambda : self.startdraw('lineString', '그리기(라인)', 1)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[1])
        self.iface.registerMainWindowAction(self.actions[1], "Shift+C")
        
        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconArrowline.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'화살표'),
            callback=(lambda : self.startdraw('lineString', '그리기(화살표)', 2)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[2])

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconspLine.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'펜'),
            callback=(lambda : self.startdraw('lineString', '그리기(펜)', 3)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[3])
        # self.iface.registerMainWindowAction(self.actions[3], "Shift+b")

        # 툴바에 드롭다운 목록 생성
        self.polygon = QToolButton(self.toolbar)
        self.polygon.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.polygon.setObjectName("폴리곤")

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconpolygon.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'폴리곤'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 4)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[4])
        self.polygon.setDefaultAction(self.actions[4])
        self.iface.registerMainWindowAction(self.actions[4], "Shift+v")

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconRectangle.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'사각형'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 5)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[5])

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconRectangle3P.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'사각형_3P'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 6)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[6])

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconcircleIn.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'다각형_in'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 7)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[7])

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconcircleOut.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'다각형_Out'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 8)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[8])

        iconLine_path = QIcon(os.path.dirname(__file__) + "/image/iconcircle2P.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'다각형_2P'),
            callback=(lambda : self.startdraw('Polygon', '그리기(폴리곤)', 9)),
            parent=self.iface.mainWindow())
        self.polygon.addAction(self.actions[9])


  # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.polygon)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.iface.actionPan().trigger()
   
        if self.Tool is not None:
            self.Tool.reset()
            self.Tool = None

        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&그리기도구'),
                action)
            self.iface.removeToolBarIcon(action)

        del self.toolbar

    def startdraw(self, draw_shape, cmt_name, idx):
        self.Tool = None
        self.drawShape = draw_shape
        self.cmtName = cmt_name
        self.idx = idx
        if self.idx > 3:
            self.polygon.setDefaultAction(self.actions[idx])

        if self.actions[self.idx].isChecked():
            self.actions[self.idx].setChecked(True)
            layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
            if layers:
                layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
                layer.commitChanges()
                layer.startEditing()

            draw_classes = [DrawPoint, 
                            DrawLine, 
                            DrawLine, 
                            DrawDrawing, 
                            Drawpolygon, 
                            DrawRectangle, 
                            DrawRectangle3P, 
                            DrawCircleIn, 
                            DrawCircleOut,
                            DrawCircle2P]

            if idx < len(draw_classes):
                draw_class = draw_classes[idx]

                self.Tool = draw_class(self, self.iface, self.idx) if self.idx == 1 or self.idx == 2 or self.idx == 4 or self.idx == 5 or self.idx >= 6 or self.idx >= 7 else draw_class(self.iface)

                self.Tool.setAction(self.actions[idx])
                self.Tool.selectionDone.connect(self.draw)
                self.Tool.reset()
                self.canvas.setMapTool(self.Tool)
        else:
            print('startdraw',self.idx)
            # self.actions[idx].setChecked(False)
            self.iface.actionPan().trigger() 

    def geomTransform(self, rb, canvasCRS):
        Geom = rb.asGeometry()
        Transform = QgsCoordinateTransform(canvasCRS, epsg5179, QgsCoordinateTransformContext())
        Geom.transform(Transform)
        rb.setToGeometry(Geom)
        Geom = rb.asGeometry()
        self.canvas.refresh()
        return Geom

    def draw(self):
        rb = self.Tool.rb
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        geometry = self.geomTransform(rb,canvasCRS)

        self.status = 0
        point = geometry.vertexAt(0)

        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            pr = layer.dataProvider() 
        else: # 코멘트 레이어가 없다면
            map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            CRSid=map_crs.authid()
            # CRSname=map_crs.description()
            # layer.setCrs(map_crs)

            layer = QgsVectorLayer(self.drawShape+'?crs=EPSG:5179', self.cmtName, "memory") # 코멘트 레이어 생성
            if self.idx == 2:
                layer.loadNamedStyle(os.path.join(self.plugin_dir, 'symbol_style', "Arrowline.qml"))
            pr = layer.dataProvider() 
            pr.addAttributes([QgsField("Lon", QVariant.Double),
                            QgsField("Lat",  QVariant.Double),
                            QgsField("PointSet", QVariant.String),
                            QgsField("text", QVariant.String)])
                            # QgsField("Update_User", QVariant.String),
                            # QgsField("Update_Date", QVariant.DateTime)])

            layer.updateFields()

            color = [random.randrange(50, 256), random.randrange(50, 256), random.randrange(50, 256)] # R / G / B 

            # 심볼 스타일 설정
            if self.drawShape == 'Point':
                # soldcol = QColor(0, 0, 0, 0) # 채우기색
                layer.renderer().symbol().setColor(QColor(*color, 255)) # 채우기색 (R / G / B / 투명도)
                # layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 (R , G , B , 투명도) QColor(255, 0, 255, 255)
                layer.renderer().symbol().setSize(3) # 포인트 크기
            if self.drawShape == 'lineString' and self.idx != 2:
                layer.renderer().symbol().setColor(QColor(*color, 255)) # 라인 색 R / G / B / 투명도
                layer.renderer().symbol().setWidth(1) # 라인 너비
            if self.drawShape == 'Polygon':
                layer.renderer().symbol().setColor(QColor(*color, 120)) # 채우기색 (R / G / B / 투명도)
                layer.renderer().symbol().symbolLayer(0).setStrokeColor(QColor(color[0]-30, color[1]-30, color[2]-30, 255)) # 테두리색 (R / G / B / 투명도) QColor(255, 0, 255, 255)
                layer.renderer().symbol().symbolLayer(0).setStrokeWidth(0.5) # 테두리 너비
                # layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
            
            pjt = QgsProject.instance()
            pjt.addMapLayer(layer, False)
            if pjt.layerTreeRoot().findGroup(self.tr('Drawings')) is None:
                pjt.layerTreeRoot().insertChildNode(0, QgsLayerTreeGroup(self.tr('Drawings')))
            group = pjt.layerTreeRoot().findGroup(self.tr('Drawings'))
            group.insertLayer(0, layer)
            self.iface.layerTreeView().refreshLayerSymbology(layer.id())
            self.iface.mapCanvas().refresh()

        # now = datetime.datetime.now() # 입력 날짜,시간 저장
        # now = now.strftime("%Y-%m-%d %H:%M:%S") 

        layer.triggerRepaint()
        # layer.beginEditCommand("Feature triangulation")

        if self.idx ==3:
            geometry = geometry.smooth(2) # smooth 평활화
            geometry = geometry.simplify(0.2) # simplify 단순화

        stringGeo = "" #'stringGeo' 빈 리스트 생성
        for i in range(0, rb.numberOfVertices()): # 도형의 보간점 개수 만큼 순환
            pp = geometry.vertexAt(i) # 보간점값을 pp 변수로 저장
            stringGeo += ("({:.6f}, {:.6f})".format( pp.x(), pp.y() )) # 보간점의 x,y 좌표값 저장
            if i != rb.numberOfVertices()-1: # 마지막 보간점이 아니라면 "," 값 추가
                stringGeo += ", "

        if self.drawShape == 'Point':
            # Point 지오메트리를 생성
            pointxy = QgsPointXY(point.x(),point.y())  # 여기서 (x, y)는 포인트의 좌표입니다.
            geometry = QgsGeometry.fromPointXY(pointxy)

        f = QgsFeature()
        f.setAttributes(["{:.6f}".format(point.x()), "{:.6f}".format(point.y()), stringGeo, None]) # , Text, Kind, now, nameText])
        f.setGeometry(geometry)
        pr.addFeature(f)

        # self.iface.messageBar().pushMessage("", "updateLayer()")
        self.iface.setActiveLayer(layer)
        layer.reload()
        layer.triggerRepaint()
        self.canvas.refresh()
        layer.startEditing()
        self.canvas.setMapTool(self.Tool)

        # self.canvas.refreshAllLayers()
        # layer.commitChanges()
        # layer.endEditCommand()
        # self.canvas.unsetMapTool(self.Tool)
        # self.iface.actionPan().trigger()
    
    def close(self, idx):
        self.actions[idx].setChecked(False)
        self.iface.actionPan().trigger()