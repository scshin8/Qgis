# -*- coding: utf-8 -*-
"""
drawing tools (refactored)

- 중복 제거: EPSG:5179 변환/스냅/가이드라인/다이얼로그 위치 계산을 공통화
- 불필요 코드 제거: wheelEvent 디버그 출력, time.sleep 등
- 동작 유지: 기존 클래스/시그널/메서드 인터페이스는 유지하되 내부 구현을 정리

원본(pasted.txt) 기반 리팩토링 파일입니다.
"""
import math

from qgis.PyQt.QtCore import Qt, pyqtSignal, QPoint, QSettings
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import QApplication

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsWkbTypes,
)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsRubberBand

from .drawing_Tools_Circle import drawingToolsCircle
from .drawing_Tools_length import drawingToolslength


EPSG_5179 = QgsCoordinateReferenceSystem("EPSG:5179")


class _ToolCommonMixin:
    """여러 MapTool 클래스에서 반복되는 유틸을 모은 mixin."""

    # ─────────────────────────────
    # UI helpers
    # ─────────────────────────────
    def _move_dialog_top_right(self, dlg):
        """맵 캔버스 우상단(스크린 좌표)에 다이얼로그 배치."""
        left_top = self.canvas.mapToGlobal(QPoint(0, 0))
        x = left_top.x() + self.canvas.width() - dlg.size().width()
        y = left_top.y()
        dlg.move(x, y)

    # ─────────────────────────────
    # CRS transforms
    # ─────────────────────────────
    def _ensure_transforms(self):
        """현재 캔버스 CRS ↔ EPSG:5179 변환을 캐시/갱신."""
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        if getattr(self, "_canvas_crs_cached", None) != canvas_crs:
            self._canvas_crs_cached = canvas_crs
            self._to_5179 = QgsCoordinateTransform(canvas_crs, EPSG_5179, QgsProject.instance())
            self._to_canvas = QgsCoordinateTransform(EPSG_5179, canvas_crs, QgsProject.instance())
        return self._to_5179, self._to_canvas

    # ─────────────────────────────
    # snapping & geometry helpers
    # ─────────────────────────────
    @staticmethod
    def _angle_deg_from_dxdy(dx, dy) -> float:
        """원본 코드와 동일하게 atan2(dx, dy) 사용(0~360 정규화)."""
        ang = math.degrees(math.atan2(dx, dy))
        return ang + 360.0 if ang < 0 else ang

    @staticmethod
    def _snap(value: float, step: float) -> float:
        if not step:
            return value
        return round(value / step) * step

    @staticmethod
    def _dxdy_from_angle_dist(angle_deg: float, dist: float):
        """원본 코드와 동일한 기준(각도 +90/- 부호)으로 dx/dy 산출."""
        angle_rad = math.radians(-angle_deg + 90.0)
        return dist * math.cos(angle_rad), dist * math.sin(angle_rad)

    def _apply_snap_angle_dist(self, angle_deg: float, dist: float, snap_angle: float, snap_dist: float):
        if snap_angle:
            angle_deg = int((angle_deg + (snap_angle / 2.0)) / snap_angle) * snap_angle
        if snap_dist:
            dist = self._snap(dist, snap_dist)
        return angle_deg, dist

    # ─────────────────────────────
    # RubberBand helpers
    # ─────────────────────────────
    def _make_line_rb(self, color: QColor, style=None, width: int = 1):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        rb.setWidth(width)
        rb.setColor(color)
        if style:
            rb.setLineStyle(style)
        return rb

    def _make_polygon_rb(self, fill_color: QColor, stroke_color: QColor, style=None, width: int = 1):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(fill_color)
        rb.setStrokeColor(stroke_color)
        if style:
            rb.setLineStyle(style)
            rb.setWidth(width)
        return rb

    def _update_guide_line(self, rb: QgsRubberBand, p1: QgsPointXY, p2: QgsPointXY, extend: bool):
        """가이드 라인(점 2개)을 segment 또는 화면 대각선 길이만큼 연장해서 표시."""
        if not p1 or not p2 or (p1.x() == p2.x() and p1.y() == p2.y()):
            rb.hide()
            return

        rb.reset(QgsWkbTypes.LineGeometry)

        if not extend:
            rb.addPoint(p1, False)
            rb.addPoint(p2, True)
            rb.show()
            return

        # extend 모드(원본 updateGuideLine 로직 공통화)
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        length = math.hypot(dx, dy)
        if length == 0:
            rb.hide()
            return

        ux = dx / length
        uy = dy / length

        extent = self.canvas.extent()
        diag_len = math.hypot(extent.width(), extent.height())

        pA = QgsPointXY(p1.x() - ux * diag_len, p1.y() - uy * diag_len)
        pB = QgsPointXY(p1.x() + ux * diag_len, p1.y() + uy * diag_len)

        rb.addPoint(pA, False)
        rb.addPoint(pB, True)
        rb.show()

    # ─────────────────────────────
    # circle/polygon helper (center-edge)
    # ─────────────────────────────
    def _edge_from_center_radius(self, center_canvas: QgsPointXY, radius_m: float, angle_deg: float = 0.0) -> QgsPointXY:
        """EPSG:5179 기준 반경/각도로 edge point를 만든 후, 캔버스 CRS로 환산."""
        to_5179, to_canvas = self._ensure_transforms()
        c5179 = to_5179.transform(center_canvas)
        dx, dy = self._dxdy_from_angle_dist(angle_deg, radius_m)
        e5179 = QgsPointXY(c5179.x() + dx, c5179.y() + dy)
        return to_canvas.transform(e5179)

    def _draw_ngon_center_edge(
        self,
        rb: QgsRubberBand,
        center_canvas: QgsPointXY,
        edge_canvas: QgsPointXY,
        n: int,
        snap_angle: float = 0.0,
        snap_dist: float = 0.0,
        shift_pressed: bool = False,
    ):
        """center-edge 기반으로 N각형(원 근사)을 그립니다. (EPSG:5179에서 거리/각도 계산)"""
        if not center_canvas or not edge_canvas or center_canvas == edge_canvas or n < 3:
            return None

        to_5179, to_canvas = self._ensure_transforms()
        c5179 = to_5179.transform(center_canvas)
        e5179 = to_5179.transform(edge_canvas)

        dx = e5179.x() - c5179.x()
        dy = e5179.y() - c5179.y()
        radius = math.hypot(dx, dy)
        if radius == 0:
            return None

        angle_deg = self._angle_deg_from_dxdy(dx, dy)

        if shift_pressed:
            angle_deg, radius = self._apply_snap_angle_dist(angle_deg, radius, snap_angle, snap_dist)
            sdx, sdy = self._dxdy_from_angle_dist(angle_deg, radius)
            e5179 = QgsPointXY(c5179.x() + sdx, c5179.y() + sdy)
            edge_canvas = to_canvas.transform(e5179)

        angle_rad = math.radians(-angle_deg + 90.0)

        rb.reset(QgsWkbTypes.PolygonGeometry)
        points = []
        for i in range(n):
            theta = angle_rad + i * 2.0 * math.pi / n
            px = c5179.x() + radius * math.cos(theta)
            py = c5179.y() + radius * math.sin(theta)
            points.append(to_canvas.transform(QgsPointXY(px, py)))

        for i, pt in enumerate(points):
            rb.addPoint(pt, i == len(points) - 1)

        return {
            "radius": radius,
            "angle_deg": angle_deg,
            "edge_canvas": edge_canvas,
        }



    def _draw_ngon_center_inradius(
        self,
        rb: QgsRubberBand,
        center_canvas: QgsPointXY,
        edge_canvas: QgsPointXY,
        n: int,
        snap_angle: float = 0.0,
        snap_dist: float = 0.0,
        shift_pressed: bool = False,
    ):
        """center-edge 기반 *외접* 정 N각형을 그립니다.

        - 사용자가 지정한 반경(center→edge)은 '내접원 반지름'(변까지의 거리, inradius)으로 해석합니다.
        - 실제 꼭짓점 반지름(외접원 반지름)은 R = r / cos(pi/N) 로 계산합니다.
        - edge 방향은 '변의 중앙(접점)' 방향으로 보고, 꼭짓점 시작각은 (edge각 - pi/N)로 둡니다.
        """
        if n < 3 or center_canvas == edge_canvas:
            return None

        rb.reset(QgsWkbTypes.PolygonGeometry)

        to_5179, to_canvas = self._ensure_transforms()
        c5179 = to_5179.transform(center_canvas)
        e5179 = to_5179.transform(edge_canvas)

        dx = e5179.x() - c5179.x()
        dy = e5179.y() - c5179.y()

        inradius = math.hypot(dx, dy)
        if inradius == 0:
            return None

        angle_deg = self._angle_deg_from_dxdy(dx, dy)

        # Shift 스냅(각도/반경)은 "내접원 반경" 기준으로 적용
        if shift_pressed:
            angle_deg, inradius = self._apply_snap_angle_dist(angle_deg, inradius, snap_angle, snap_dist)
            sdx, sdy = self._dxdy_from_angle_dist(angle_deg, inradius)
            e5179 = QgsPointXY(c5179.x() + sdx, c5179.y() + sdy)
            edge_canvas = to_canvas.transform(e5179)

        angle_rad = math.radians(-angle_deg + 90.0)

        half = math.pi / float(n)
        # 꼭짓점 반지름(외접원 반지름)
        R = inradius / math.cos(half)

        # edge 방향은 변 중앙이므로, 첫 꼭짓점은 ±pi/n 만큼 회전
        theta0 = angle_rad - half

        pts = []
        for i in range(n):
            theta = theta0 + i * (2.0 * math.pi / float(n))
            px = c5179.x() + R * math.cos(theta)
            py = c5179.y() + R * math.sin(theta)
            pts.append(to_canvas.transform(QgsPointXY(px, py)))

        for i, pt in enumerate(pts):
            rb.addPoint(pt, i == len(pts) - 1)

        return {
            "radius": inradius,          # 내접원 반경(표시용)
            "vertex_radius": R,          # 꼭짓점 반경(참고용)
            "angle_deg": angle_deg,
            "edge_canvas": edge_canvas,
        }

class DrawPoint(QgsMapToolEmitPoint):
    selectionDone = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb.setWidth(3)
        self.rb.setColor(QColor(60, 151, 255, 255))
        self.status = 0

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.rb.reset(QgsWkbTypes.PointGeometry)
            pt = self.toMapCoordinates(e.pos())
            self.rb.addPoint(pt)
            self.selectionDone.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)


class DrawLine(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0
        self.rblist = []

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self._move_dialog_top_right(self.dlglength)

        self.rb = self._make_line_rb(QColor(255, 0, 0, 255), width=2)
        self.rb1 = self._make_line_rb(QColor(255, 0, 0, 255), Qt.DashLine, width=1)
        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 150), Qt.DotLine, width=1)

        zero = iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)
        self.startPoint = zero
        self.endPoint = zero

        self.distance1 = 0.0
        self.distance1end = 0.0

    def activate(self):
        QgsMapTool.activate(self)
        self._move_dialog_top_right(self.dlglength)
        self.dlglength.show()

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            if self.rblist:
                self.rblist.pop()
            self.update_rubber_band()
        elif event.matches(QKeySequence.Cancel):
            self.reset()
            self.dlglength.close()
            self.iface.actionPan().trigger()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.distance1end = 0.0
            self.reset()

    def canvasPressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._handle_left_click(event)
        else:
            self._handle_right_click()

    def _handle_left_click(self, event):
        self.startPoint = self.toMapCoordinates(event.pos())

        if self.status == 0:
            self.rblist.clear()
            self.rb.reset(QgsWkbTypes.LineGeometry)
            self.rb1.reset(QgsWkbTypes.LineGeometry)
            self.status = 1

        if self.rb.numberOfVertices() < 1:
            self.rb.addPoint(self.startPoint)
            self.rb1.addPoint(self.startPoint)
        else:
            self.rb.addPoint(self.endPoint)
            self.rb1.addPoint(self.endPoint)
            self.startPoint = self.endPoint
            self.distance1end += getattr(self, "distance1", 0.0)
            self.rb1.removePoint(0)

        self.rblist.append(self.startPoint)

    def _handle_right_click(self):
        if len(self.rblist) > 1:
            self.status = 0
            self.selectionDone.emit()
            self.distance1end = 0.0
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint = self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self._show_line(self.startPoint, self.endPoint, event)
            self.move.emit()

    def _show_line(self, startPoint, endPoint, event):
        if startPoint == endPoint:
            return

        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        to_5179, to_canvas = self._ensure_transforms()
        st5179 = to_5179.transform(startPoint)
        en5179 = to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()
        if dx == 0 and dy == 0:
            return

        angle_deg = self._angle_deg_from_dxdy(dx, dy)
        dist = math.hypot(dx, dy)

        if shift_pressed:
            snap_angle = float(self.dlglength.spinBox_ang.value())
            snap_dist = float(self.dlglength.spinBox_dis.value())
            angle_deg, dist = self._apply_snap_angle_dist(angle_deg, dist, snap_angle, snap_dist)

            sdx, sdy = self._dxdy_from_angle_dist(angle_deg, dist)
            en5179 = QgsPointXY(st5179.x() + sdx, st5179.y() + sdy)
            self.endPoint = to_canvas.transform(en5179)
        else:
            self.endPoint = endPoint

        self.distance1 = dist
        total_dist = self.distance1end + self.distance1

        self.dlglength.lineEdit_2.setText(f"{total_dist:.3f}")
        self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")
        self.dlglength.lineEdit_last.setText(f"{self.distance1:.3f}")

        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)

        self._update_guide_line(self.guide_rb, self.startPoint, self.endPoint, extend=True)

    def update_rubber_band(self):
        """원본 코드의 후속 로직이 있을 수 있어 자리만 유지(필요 시 구현)."""
        # 기존 파일에는 정의가 있었던 것으로 보이며(Undo 시 호출),
        # 현재 pasted.txt 조각에는 구현이 없어서 안전하게 no-op 처리.
        pass

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)


class DrawDrawing(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface

        self.LeftButton = False
        self.status = 0

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 255))

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = True
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.status = 1
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
        else:
            self._handle_right_click()

    def _handle_right_click(self):
        if self.rb.numberOfVertices() > 2:
            self.rb.removeLastPoint()
            self.selectionDone.emit()
        self.reset()

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.LeftButton = False
            self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        # 원본의 time.sleep(0.01)은 UI를 끊기게 만들 수 있어 제거
        if self.LeftButton and self.status == 1:
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
            self.move.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        self.reset()
        QgsMapTool.deactivate(self)


class Drawpolygon(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0
        self.rblist = []

        self.startPoint = None
        self.endPoint = None

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self._move_dialog_top_right(self.dlglength)

        self.rb = self._make_polygon_rb(QColor(255, 0, 0, 30), QColor(255, 0, 0, 255))
        self.rb1 = self._make_polygon_rb(QColor(255, 0, 0, 30), QColor(255, 0, 0, 255), Qt.DashLine, width=1)

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 150), Qt.DotLine, width=1)

    def activate(self):
        QgsMapTool.activate(self)
        self._move_dialog_top_right(self.dlglength)
        self.dlglength.show()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            self._undo_last_point()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def _undo_last_point(self):
        if self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
            if self.rblist:
                self.rblist.pop()
            self.update_rubber_band()
        elif self.rb.numberOfVertices() == 1:
            self.reset()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
            self.reset()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._handle_left_click(e)
        else:
            self._handle_right_click()

    def _handle_left_click(self, e):
        self.startPoint = self.toMapCoordinates(e.pos())

        if self.status == 0:
            self._reset_rubber_bands()
            self.status = 1

        if self.status == 1:
            # 원본 로직: self.endPoint 기반이었으나 초기 None 방지를 위해 startPoint 사용
            pt = self.endPoint if self.endPoint else self.startPoint
            self.rb.addPoint(pt)
            self.rblist.append(pt)
            self.rb1.addPoint(pt)
            self.startPoint = pt

        if self.rb1.numberOfVertices() == 4:
            self.rb1.removePoint(1)

    def _handle_right_click(self):
        if self.rb.numberOfVertices() > 2:
            self.status = 0
            self.selectionDone.emit()
        self.reset()

    def canvasMoveEvent(self, event):
        self.endPoint = self.toMapCoordinates(event.pos())
        if self.rb1.numberOfVertices() > 0 and self.status == 1:
            self._show_line(self.startPoint, self.endPoint, event)
            self.move.emit()

    def _show_line(self, startPoint, endPoint, event):
        ver_num = self.rb1.numberOfVertices()
        if startPoint == endPoint:
            return

        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        to_5179, to_canvas = self._ensure_transforms()
        st5179 = to_5179.transform(startPoint)
        en5179 = to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()
        if dx == 0 and dy == 0:
            return

        angle_deg = self._angle_deg_from_dxdy(dx, dy)
        dist = math.hypot(dx, dy)

        if shift_pressed:
            snap_angle = float(self.dlglength.spinBox_ang.value())
            snap_dist = float(self.dlglength.spinBox_dis.value())
            angle_deg, dist = self._apply_snap_angle_dist(angle_deg, dist, snap_angle, snap_dist)

            sdx, sdy = self._dxdy_from_angle_dist(angle_deg, dist)
            en5179 = QgsPointXY(st5179.x() + sdx, st5179.y() + sdy)
            self.endPoint = to_canvas.transform(en5179)
        else:
            self.endPoint = endPoint

        self.rb1.removeLastPoint(0)
        self.rb1.addPoint(self.endPoint)

        # ── length/area 계산(5179 기준) ─────────────────────────
        geom = self.rb1.asGeometry()
        if not geom or geom.isEmpty():
            return

        geom_5179 = QgsGeometry(geom)
        geom_5179.transform(QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(), EPSG_5179, QgsProject.instance()))

        da = QgsDistanceArea()
        da.setSourceCrs(EPSG_5179, QgsProject.instance().transformContext())

        geom_type = QgsWkbTypes.geometryType(geom_5179.wkbType())
        perimeter = 0.0
        area = 0.0

        if geom_type == QgsWkbTypes.LineGeometry:
            perimeter = da.measureLength(geom_5179)
        elif geom_type == QgsWkbTypes.PolygonGeometry:
            perimeter = da.measurePerimeter(geom_5179)
            area = da.measureArea(geom_5179)

        if ver_num == 2:
            perimeter = perimeter / 2.0

        self._update_guide_line(self.guide_rb, self.startPoint, self.endPoint, extend=True)

        self.dlglength.lineEdit_2.setText(f"{perimeter:.3f}")
        self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")
        self.dlglength.lineEdit_last.setText(f"{dist:.3f}")

    def update_rubber_band(self):
        """원본 코드의 후속 로직이 있을 수 있어 자리만 유지."""
        # rb(실선): 확정된 포인트 재구성
        self.rb.reset(QgsWkbTypes.LineGeometry)
        for pt in self.rblist:
            self.rb.addPoint(pt)

        # rb1(점선): 마지막 확정 포인트부터 미리보기용
        self.rb1.reset(QgsWkbTypes.LineGeometry)
        if self.rblist:
            self.rb1.addPoint(self.rblist[-1])
            self.startPoint = self.rblist[-1]
            self.endPoint = self.startPoint

        # 누적 거리 재계산(5179 기준)
        self.distance1end = 0.0
        if len(self.rblist) > 1:
            to_5179, _ = self._ensure_transforms()
            for a, b in zip(self.rblist[:-1], self.rblist[1:]):
                A = to_5179.transform(a)
                B = to_5179.transform(b)
                self.distance1end += math.hypot(B.x() - A.x(), B.y() - A.y())

        self.dlglength.lineEdit_2.setText(f"{self.distance1end:.3f}")

    def _reset_rubber_bands(self):
        self.rblist = []
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        self.rb1.reset(QgsWkbTypes.PolygonGeometry)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.rb1.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)

class DrawRectangle(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)
        self._move_dialog_top_right(self.dlglength)

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255))

        self.startPoint = None
        self.endPoint = None

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 200), Qt.DotLine, width=1)

    def activate(self):
        QgsMapTool.activate(self)
        self._move_dialog_top_right(self.dlglength)
        self.dlglength.show()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo) and self.rb.numberOfVertices() > 1:
            self.rb.removeLastPoint()
        elif e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
                self.startPoint = self.toMapCoordinates(e.pos())
                self.endPoint = self.startPoint
            elif self.status == 1:
                self.status = 0
                self.selectionDone.emit()

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint = self.toMapCoordinates(e.pos())
            self.move.emit()
            self._show_rect(self.startPoint, self.endPoint, e)

    def _show_rect(self, startPoint, endPoint, event):
        self.rb.reset(QgsWkbTypes.PolygonGeometry)
        if startPoint == endPoint:
            return

        alt_pressed = bool(event.modifiers() & Qt.AltModifier)
        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)
        ctrl_pressed = bool(event.modifiers() & Qt.ControlModifier)

        to_5179, to_canvas = self._ensure_transforms()
        start5179 = to_5179.transform(startPoint)
        end5179 = to_5179.transform(endPoint)

        dx = end5179.x() - start5179.x()
        dy = end5179.y() - start5179.y()
        if dx == 0 and dy == 0:
            return

        sx = 1 if dx >= 0 else -1
        sy = 1 if dy >= 0 else -1

        if alt_pressed:
            width = abs(dx) * 2.0
            height = abs(dy) * 2.0
        else:
            width = abs(dx)
            height = abs(dy)

        snap_dist = float(self.dlglength.spinBox_dis.value())

        if ctrl_pressed:
            side = max(width, height)
            if shift_pressed and snap_dist > 0:
                side = self._snap(side, snap_dist)
            width = height = side
        else:
            if shift_pressed and snap_dist > 0:
                width = self._snap(width, snap_dist)
                height = self._snap(height, snap_dist)

        if alt_pressed:
            cx, cy = start5179.x(), start5179.y()
            half_w, half_h = width / 2.0, height / 2.0
            x1 = cx - sx * half_w
            x2 = cx + sx * half_w
            y1 = cy - sy * half_h
            y2 = cy + sy * half_h
        else:
            x1, y1 = start5179.x(), start5179.y()
            x2 = x1 + sx * width
            y2 = y1 + sy * height

        p1 = to_canvas.transform(QgsPointXY(x1, y1))
        p2 = to_canvas.transform(QgsPointXY(x1, y2))
        p3 = to_canvas.transform(QgsPointXY(x2, y2))
        p4 = to_canvas.transform(QgsPointXY(x2, y1))

        vertices = [p1, p2, p3, p4]
        for i, pt in enumerate(vertices):
            self.rb.addPoint(pt, i == len(vertices) - 1)
        self.rb.show()

        self.dlglength.lineEdit_2.setText(f"{width:.3f}")
        self.dlglength.lineEdit_last.setText(f"{height:.3f}")

        self._update_guide_line(self.guide_rb, p1, p3, extend=False)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)


class DrawRectangle3P(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.dlglength = drawingToolslength(self.iface, self.CTool, self.idx)

        self.status = 0

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255))

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 150), Qt.DotLine, width=1)

        self.startPoint = None
        self.secondPoint = None
        self.endPoint = None

    def activate(self):
        QgsMapTool.activate(self)
        self._move_dialog_top_right(self.dlglength)
        self.dlglength.show()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        pt = self.toMapCoordinates(e.pos())

        if e.button() == Qt.LeftButton and self.status == 0:
            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.status = 1
            self.startPoint = pt

        if e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 0:
            self.rb.addPoint(pt)
        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 2:
            self.secondPoint = self.endPoint
            self.rb.addPoint(self.endPoint)
        elif e.button() == Qt.LeftButton and self.status == 1 and self.rb.numberOfVertices() == 4:
            self.status = 0
            self.selectionDone.emit()
            self.reset()

    def canvasMoveEvent(self, e):
        if self.status == 1:
            self.endPoint = self.toMapCoordinates(e.pos())
            self.move.emit()
            self._show_rect(self.startPoint, self.endPoint, e)

    def _show_rect(self, startPoint, endPoint, event):
        n = self.rb.numberOfVertices()
        snap_angle = float(self.dlglength.spinBox_ang.value())
        snap_dist = float(self.dlglength.spinBox_dis.value())
        shift_pressed = bool(event.modifiers() & Qt.ShiftModifier)

        to_5179, to_canvas = self._ensure_transforms()
        st5179 = to_5179.transform(startPoint)
        en5179 = to_5179.transform(endPoint)

        dx = en5179.x() - st5179.x()
        dy = en5179.y() - st5179.y()
        if dx == 0 and dy == 0:
            return

        angle_deg = self._angle_deg_from_dxdy(dx, dy)
        dist = math.hypot(dx, dy)

        if n == 2:
            self.rb.removeLastPoint(0)

            if shift_pressed:
                angle_deg, dist = self._apply_snap_angle_dist(angle_deg, dist, snap_angle, snap_dist)
                sdx, sdy = self._dxdy_from_angle_dist(angle_deg, dist)
                en5179 = QgsPointXY(st5179.x() + sdx, st5179.y() + sdy)
                self.endPoint = to_canvas.transform(en5179)
            else:
                self.endPoint = endPoint

            self.rb.addPoint(self.endPoint)
            self.rb.show()

            self._update_guide_line(self.guide_rb, self.startPoint, self.endPoint, extend=True)

            self.dlglength.lineEdit.setText(f"{angle_deg:.3f}")
            # self.dlglength.lineEdit_2.setText(f"{dist:.3f}")
            self.dlglength.lineEdit_last.setText(f"{dist:.3f}")
            return

        if n > 2 and self.secondPoint:
            while self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint(0)

            st1_5179 = to_5179.transform(self.startPoint)
            st2_5179 = to_5179.transform(self.secondPoint)
            en_5179 = to_5179.transform(endPoint)

            vx = st2_5179.x() - st1_5179.x()
            vy = st2_5179.y() - st1_5179.y()
            base_len = math.hypot(vx, vy)
            if base_len == 0:
                return

            nx = -vy / base_len
            ny = vx / base_len

            ox = en_5179.x() - st2_5179.x()
            oy = en_5179.y() - st2_5179.y()
            t = ox * nx + oy * ny

            if shift_pressed and snap_dist:
                t = self._snap(t, snap_dist)

            height_len = abs(t)

            p3_5179 = QgsPointXY(st2_5179.x() + nx * t, st2_5179.y() + ny * t)
            p4_5179 = QgsPointXY(st1_5179.x() + nx * t, st1_5179.y() + ny * t)

            p1_canvas = to_canvas.transform(st1_5179)
            p2_canvas = to_canvas.transform(st2_5179)
            p3_canvas = to_canvas.transform(p3_5179)
            p4_canvas = to_canvas.transform(p4_5179)

            self.rb.reset(QgsWkbTypes.PolygonGeometry)
            self.rb.addPoint(p1_canvas, False)
            self.rb.addPoint(p2_canvas, False)
            self.rb.addPoint(p3_canvas, False)
            self.rb.addPoint(p4_canvas, True)
            self.rb.show()

            dx2 = p3_5179.x() - st2_5179.x()
            dy2 = p3_5179.y() - st2_5179.y()
            ang = self._angle_deg_from_dxdy(dx2, dy2)

            self._update_guide_line(self.guide_rb, self.secondPoint, p3_canvas, extend=True)

            self.dlglength.lineEdit.setText(f"{ang:.3f}")
            self.dlglength.lineEdit_2.setText(f"{height_len:.3f}")
            self.dlglength.lineEdit_last.setText(f"{base_len:.3f}")

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        self.status = 0
        self.rb.reset()
        self.dlglength.close()
        QgsMapTool.deactivate(self)


class DrawCircleIn(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0
        self.center = None

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255))

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 200), Qt.DotLine, width=1)

        self.locale = QSettings()
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()
        self._move_dialog_top_right(self.dlgCircle)

        self.dlgCircle.checkBox.setCheckState(int(self.locale.value("drawing_Tools/checkBox", Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value("drawing_Tools/lineEdit", 0)))
        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value("drawing_Tools/spinBox_vert", 5)))
        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

        self.segments = int(self.dlgCircle.spinBox_vert.value())

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.status = 0
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton and self.status == 0:
            self.center = self.toMapCoordinates(e.pos())
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self._save_dialog_state()
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self._save_dialog_state()
            self.selectionDone.emit()

    def _save_dialog_state(self):
        self.locale.setValue("drawing_Tools/checkBox", self.dlgCircle.checkBox.checkState())
        self.locale.setValue("drawing_Tools/lineEdit", self.dlgCircle.lineEdit.text())
        self.locale.setValue("drawing_Tools/spinBox_vert", int(self.dlgCircle.spinBox_vert.value()))

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            self.segments = int(self.dlgCircle.spinBox_vert.value())

            shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)
            snap_angle = float(self.dlgCircle.spinBox_ang.value())
            snap_dist = float(self.dlgCircle.spinBox_dis.value())

            if self.dlgCircle.checkBox.isChecked():
                # 고정 반경 모드: 마우스 위치가 중심, lineEdit 값이 반경(m)
                center = self.toMapCoordinates(e.pos())
                radius_m = float(self.dlgCircle.lineEdit.text() or 0)
                edge = self._edge_from_center_radius(center, radius_m, angle_deg=0.0)
                info = self._draw_ngon_center_edge(self.rb, center, edge, self.segments, snap_angle, snap_dist, shift_pressed)
                if info:
                    self.dlgCircle.lineEdit.setText(f"{info['radius']:.3f}")
                    self.dlgCircle.lineEdit_2.setText(f"{info['angle_deg']:.3f}")
                    self._update_guide_line(self.guide_rb, center, info["edge_canvas"], extend=False)
            else:
                # 2점 모드: 첫 클릭이 중심(self.center), 마우스가 edge
                cp = self.toMapCoordinates(e.pos())
                info = self._draw_ngon_center_edge(self.rb, self.center, cp, self.segments, snap_angle, snap_dist, shift_pressed)
                if info:
                    self.dlgCircle.lineEdit.setText(f"{info['radius']:.3f}")
                    self.dlgCircle.lineEdit_2.setText(f"{info['angle_deg']:.3f}")
                    self._update_guide_line(self.guide_rb, self.center, info["edge_canvas"], extend=False)

            self.rb.show()
            self.move.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        if not self.CTool.actions[6].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)


class DrawCircleOut(_ToolCommonMixin, QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0
        self.locale = QSettings()

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255))

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 200), Qt.DotLine, width=1)

        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()
        self._move_dialog_top_right(self.dlgCircle)

        # settings 로드
        self.dlgCircle.checkBox.setCheckState(int(self.locale.value("drawing_Tools/checkBox", Qt.Unchecked)))
        self.dlgCircle.lineEdit.setText(str(self.locale.value("drawing_Tools/lineEdit", 0)))
        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value("drawing_Tools/spinBox_vert", 5)))

        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

        self.segments = int(self.dlgCircle.spinBox_vert.value())
        self.p1 = None
        self.p2 = None

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.status = 0
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        pt = self.toMapCoordinates(e.pos())

        if e.button() == Qt.LeftButton and self.status == 0:
            self.p1 = pt
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.p2 = pt
            self._save_dialog_state()
            self.selectionDone.emit()
            self.dlgCircle.show()

    def canvasDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self.status == 1:
            self._save_dialog_state()
            self.selectionDone.emit()

    def _save_dialog_state(self):
        self.locale.setValue("drawing_Tools/checkBox", self.dlgCircle.checkBox.checkState())
        self.locale.setValue("drawing_Tools/lineEdit", self.dlgCircle.lineEdit.text())
        self.locale.setValue("drawing_Tools/spinBox_vert", int(self.dlgCircle.spinBox_vert.value()))

    def canvasMoveEvent(self, e):
        if self.status == 1 or self.dlgCircle.checkBox.isChecked():
            self.status = 1
            self.segments = int(self.dlgCircle.spinBox_vert.value())

            shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)
            snap_angle = float(self.dlgCircle.spinBox_ang.value())
            snap_dist = float(self.dlgCircle.spinBox_dis.value())

            if self.dlgCircle.checkBox.isChecked():
                # 고정 반경 모드: 마우스가 중심
                center = self.toMapCoordinates(e.pos())
                radius_m = float(self.dlgCircle.lineEdit.text() or 0)
                edge = self._edge_from_center_radius(center, radius_m, angle_deg=0.0)
                info = self._draw_ngon_center_inradius(self.rb, center, edge, self.segments, snap_angle, snap_dist, shift_pressed)
                if info:
                    self.dlgCircle.lineEdit.setText(f"{info['radius']:.3f}")
                    self.dlgCircle.lineEdit_2.setText(f"{info['angle_deg']:.3f}")
                    self._update_guide_line(self.guide_rb, center, info["edge_canvas"], extend=False)
            else:
                # 2점 모드: p1=중심, mouse=edge
                if not self.p1:
                    return
                cp = self.toMapCoordinates(e.pos())
                info = self._draw_ngon_center_inradius(self.rb, self.p1, cp, self.segments, snap_angle, snap_dist, shift_pressed)
                if info:
                    self.dlgCircle.lineEdit.setText(f"{info['radius']:.3f}")
                    self.dlgCircle.lineEdit_2.setText(f"{info['angle_deg']:.3f}")
                    self._update_guide_line(self.guide_rb, self.p1, info["edge_canvas"], extend=False)

            self.rb.show()
            self.move.emit()

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        if not self.CTool.actions[7].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)


class DrawCircle2P(_ToolCommonMixin, QgsMapTool):
    """
    시작점(p1)–종점(p2)을 한 변으로 갖는 정 N각형을 그리는 도구.
    pasted.txt의 말미 구현을 유지하되, 중복 유틸(변환/스냅/가이드)을 공통 함수로 정리.
    """
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, CTool, iface, idx):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)

        self.canvas = canvas
        self.iface = iface
        self.CTool = CTool
        self.idx = idx

        self.status = 0
        self.p1 = None
        self.p2 = None

        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setLineStyle(Qt.PenStyle(Qt.DashLine))
        self.rb.setColor(QColor(255, 0, 0, 30))
        self.rb.setStrokeColor(QColor(255, 0, 0, 255))

        self.guide_rb = self._make_line_rb(QColor(10, 10, 10, 200), Qt.DotLine, width=1)

        self.locale = QSettings()
        self.dlgCircle = drawingToolsCircle(self.iface, self.CTool, idx)
        self.dlgCircle.show()
        self._move_dialog_top_right(self.dlgCircle)

        self.dlgCircle.spinBox_vert.setValue(int(self.locale.value("drawing_Tools/spinBox_vert", 5)))
        self.dlgCircle.spinBox_ang.setValue(int(self.locale.value("drawing_Tools/spinBox_ang", 15)))
        self.dlgCircle.spinBox_dis.setValue(int(self.locale.value("drawing_Tools/spinBox_dis", 1)))

        self.dlgCircle.checkBox.hide()  # 2P 모드에서는 고정 반경 체크박스 의미가 없음(원본 유지)
        self.dlgCircle.lineEdit.setReadOnly(True)

        self.dlgCircle.checkBox.stateChanged.connect(self.reset)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.status = 0
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, e):
        pt = self.toMapCoordinates(e.pos())

        if e.button() == Qt.LeftButton and self.status == 0:
            self.p1 = pt
            self.status = 1
        elif e.button() == Qt.LeftButton and self.status == 1:
            self.p2 = pt
            self._save_dialog_state()
            self.selectionDone.emit()

    def _save_dialog_state(self):
        self.locale.setValue("drawing_Tools/spinBox_vert", int(self.dlgCircle.spinBox_vert.value()))
        self.locale.setValue("drawing_Tools/spinBox_ang", int(self.dlgCircle.spinBox_ang.value()))
        self.locale.setValue("drawing_Tools/spinBox_dis", int(self.dlgCircle.spinBox_dis.value()))

    def canvasMoveEvent(self, e):
        if self.status != 1 or not self.p1:
            return

        p2 = self.toMapCoordinates(e.pos())
        n = int(self.dlgCircle.spinBox_vert.value())
        snap_angle = float(self.dlgCircle.spinBox_ang.value())
        snap_dist = float(self.dlgCircle.spinBox_dis.value())
        shift_pressed = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)

        self._draw_regular_polygon_by_side(self.rb, self.p1, p2, n, snap_angle, snap_dist, shift_pressed)
        self.rb.show()
        self.move.emit()

    def _draw_regular_polygon_by_side(self, rb: QgsRubberBand, p1_canvas: QgsPointXY, p2_canvas: QgsPointXY, n: int,
                                      snap_angle: float, snap_dist: float, shift_pressed: bool):
        if n < 3 or not p1_canvas or not p2_canvas or p1_canvas == p2_canvas:
            return

        to_5179, to_canvas = self._ensure_transforms()
        p1_5179 = to_5179.transform(p1_canvas)
        p2_5179 = to_5179.transform(p2_canvas)

        dx = p2_5179.x() - p1_5179.x()
        dy = p2_5179.y() - p1_5179.y()

        side_len = math.hypot(dx, dy)
        EPS = 1e-9
        if side_len <= EPS:
            rb.reset(QgsWkbTypes.PolygonGeometry)
            return

        angle_deg = self._angle_deg_from_dxdy(dx, dy)

        # 정 N각형의 외접원 반지름(반경) R = s / (2 sin(pi/N))
        R = side_len / (2.0 * math.sin(math.pi / n))

        if shift_pressed:
            # 각도는 '변(p1→p2)' 방향 기준으로 스냅
            if snap_angle:
                angle_deg = int((angle_deg + (snap_angle / 2.0)) / snap_angle) * snap_angle

            # 거리 스냅은 '반경(R)' 기준으로 적용
            if snap_dist:
                R = self._snap(R, snap_dist)

            # 스냅된 반경 R에 맞는 변 길이를 재계산
            side_len = 2.0 * R * math.sin(math.pi / n)

            EPS = 1e-9
            if R <= EPS or side_len <= EPS:
                rb.reset(QgsWkbTypes.PolygonGeometry)
                return

            # 스냅된 각도/변길이로 p2 재계산
            sdx, sdy = self._dxdy_from_angle_dist(angle_deg, side_len)
            p2_5179 = QgsPointXY(p1_5179.x() + sdx, p1_5179.y() + sdy)
            p2_canvas = to_canvas.transform(p2_5179)
            dx = p2_5179.x() - p1_5179.x()
            dy = p2_5179.y() - p1_5179.y()
        # p1->p2 방향 벡터 단위화
        ux = (p2_5179.x() - p1_5179.x()) / side_len
        uy = (p2_5179.y() - p1_5179.y()) / side_len

        # 법선 방향(좌측) 단위 벡터
        nx = -uy
        ny = ux

        # 중심은 변의 중점에서 법선 방향으로 h 만큼 이동
        mx = (p1_5179.x() + p2_5179.x()) / 2.0
        my = (p1_5179.y() + p2_5179.y()) / 2.0
        h = math.sqrt(max(R * R - (side_len / 2.0) ** 2, 0.0))

        cx = mx + nx * h
        cy = my + ny * h
        center5179 = QgsPointXY(cx, cy)

        # 첫 꼭짓점 각도(중심->p1) 기준
        theta0 = math.atan2(p1_5179.y() - cy, p1_5179.x() - cx)

        rb.reset(QgsWkbTypes.PolygonGeometry)
        for i in range(n):
            theta = theta0 + i * (2.0 * math.pi / n)
            px = cx + R * math.cos(theta)
            py = cy + R * math.sin(theta)
            pt_canvas = to_canvas.transform(QgsPointXY(px, py))
            rb.addPoint(pt_canvas, i == n - 1)

        self.dlgCircle.lineEdit.setText(f"{R:.3f}")
        self.dlgCircle.lineEdit_2.setText(f"{angle_deg:.3f}")

        self._update_guide_line(self.guide_rb, p1_canvas, p2_canvas, extend=True)

    def reset(self):
        self.status = 0
        self.rb.reset()
        self.guide_rb.reset()

    def deactivate(self):
        if not self.CTool.actions[7].isChecked() or self.status == 0:
            self.dlgCircle.close()
        self.reset()
        QgsMapTool.deactivate(self)
