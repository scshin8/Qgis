
import os
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from PyQt5.QtCore import Qt
from qgis.PyQt.QtGui import QKeySequence

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui\drawing_Tools_length.ui'))

class drawingToolslength(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, iface, Tools, idx, parent=None):
        """Constructor."""
        super(drawingToolslength, self).__init__(parent, Qt.WindowStaysOnTopHint)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)

        self.idx = idx
        angSet = 15
        if self.idx == 4:
            self.label_1.setText('둘레 : ')
        if self.idx == 5 or self.idx == 6:
            self.label_1.setText('너비 : ')
            self.label_3.setText('높이 : ')

        self.Tools = Tools
        self.iface = iface

        self.setWindowModality(Qt.NonModal)    # 모달 방지
        self.setFocusPolicy(Qt.ClickFocus)     # 사용자가 클릭할 때만 포커스
        self.spinBox_ang.setValue(angSet)
        self.spinBox_dis.setValue(10)
        self.lineEdit_last.setText('')

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.Tools.actions[self.idx].setChecked(False)
            self.iface.actionPan().trigger()
            event.accept()  # 창을 닫습니다.

    def closeEvent(self, event):
        # self.Tools.close(self.idx)
        self.Tools.actions[self.idx].setChecked(False)
        self.iface.actionPan().trigger()
        event.accept()  # 창을 닫습니다.
