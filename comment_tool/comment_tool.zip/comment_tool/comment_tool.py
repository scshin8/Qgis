
from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsProject, 
                       QgsVectorLayer, 
                       QgsCoordinateTransform,
                       QgsCoordinateTransformContext,
                       QgsExpressionContextUtils,
                       QgsVectorFileWriter,
                       Qgis, QgsMessageLog,
                       QgsField, 
                       QgsFeature)

from PyQt5.QtCore import (QSettings,
                          QTranslator,
                          QCoreApplication,
                          QDateTime,
                          QVariant)

from PyQt5.QtGui import QIcon

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import (QDialogButtonBox,
                             QAction)
import datetime

# Import the code for the dialog
from .comment_tool_dialog import CommentToolDialog
from .comment_tool_setting import CommentToolSetting
from .comment_tool_function import DrawPointComment, DrawLineComment, DrawpolygonComment, SelectDeleteTool
import os.path

bessel_wkt = """
GEOGCRS["Bessel_MMS8",
    DATUM["Korean Datum 1985",
        ELLIPSOID["Bessel 1841",6377397.155,299.1528128,
            LENGTHUNIT["metre",1]]],
    PRIMEM["Greenwich",0,
        ANGLEUNIT["Degree",4.84813681109536E-08]],
    CS[ellipsoidal,2],
        AXIS["longitude",east,
            ORDER[1],
            ANGLEUNIT["Degree",4.84813681109536E-08]],
        AXIS["latitude",north,
            ORDER[2],
            ANGLEUNIT["Degree",4.84813681109536E-08]]]
"""

grs_wkt = """
GEOGCRS["GRS80_MMS8",
    DATUM["Geocentric datum of Korea",
        ELLIPSOID["GRS 1980",6378137,298.257222101,
            LENGTHUNIT["metre",1]]],
    PRIMEM["Greenwich",0,
        ANGLEUNIT["Degree",4.84813681109536E-08]],
    CS[ellipsoidal,2],
        AXIS["longitude",east,
            ORDER[1],
            ANGLEUNIT["Degree",4.84813681109536E-08]],
        AXIS["latitude",north,
            ORDER[2],
            ANGLEUNIT["Degree",4.84813681109536E-08]]]
"""

wgs_wkt = """
GEOGCRS["WGS84_MMS8",
    DATUM["World Geodetic System 1984",
        ELLIPSOID["WGS 84",6378137,298.257223563,
            LENGTHUNIT["metre",1]]],
    PRIMEM["Greenwich",0,
        ANGLEUNIT["Degree",4.84813681109536E-08]],
    CS[ellipsoidal,2],
        AXIS["longitude",east,
            ORDER[1],
            ANGLEUNIT["Degree",4.84813681109536E-08]],
        AXIS["latitude",north,
            ORDER[2],
            ANGLEUNIT["Degree",4.84813681109536E-08]]]
"""

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')

# WKT로부터 CRS 객체 생성
bessel_crs = QgsCoordinateReferenceSystem()
bessel_crs.createFromWkt(bessel_wkt)

grs_crs = QgsCoordinateReferenceSystem()
grs_crs.createFromWkt(grs_wkt)

wgs_crs = QgsCoordinateReferenceSystem()
wgs_crs.createFromWkt(wgs_wkt)

class CommentTool:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.sb = self.iface.statusBarIface()
        self.Tool = None
        self.myaction = None
        self.toolbar = self.iface.addToolBar('코멘트입력 툴바')
        self.toolbar.setObjectName('comment_manager_toolbar')
        self.dlg = CommentToolDialog()

        self.dlg.buttonBox.button(QDialogButtonBox.Reset).clicked.connect(self.Reset)

        self.dlgsetting = CommentToolSetting()
        self.dlgsetting.buttonBox.button(QDialogButtonBox.Save).clicked.connect(self.save)

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale= QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "CommentTool")

        locale_path = os.path.join(self.plugin_dir,'i18n','CommentManager_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr(u'&코멘트입력')

    def tr(self, message):
        return QCoreApplication.translate('CommentManager', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        Checkable=True,
        enabled_flag=True,
        parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.setCheckable(Checkable)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        self.actions.append(action)
        return action

    def initGui(self):
        iconPoint_path = QIcon(self.plugin_dir + "/image/iconPoint.png")
        self.add_action(
            iconPoint_path,
            text=self.tr(u'코멘트입력_point'),
            callback=(lambda : self.startComment('point', 1, 0)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[0])

        iconLine_path = QIcon(self.plugin_dir + "/image/iconLine.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트입력_line'),
            callback=(lambda : self.startComment('lineString', 2, 1)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[1])
        
        iconLine_path = QIcon(self.plugin_dir + "/image/icon1.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트입력_Arrowline'),
            callback=(lambda : self.startComment('lineString', 2, 2)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[2])

        iconLine_path = QIcon(self.plugin_dir + "/image/icon2.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트입력_Arrowline'),
            callback=(lambda : self.startComment('lineString', 2, 3)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[3])

        iconLine_path = QIcon(self.plugin_dir + "/image/iconpolygon.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트입력_polygon'),
            callback=(lambda : self.startComment('polygon', 3, 4)),
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[4])
        # self.iface.registerMainWindowAction(self.actions[16], "Shift+v")

        iconLine_path = QIcon(self.plugin_dir + "/image/dalete.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트삭제'),
            callback=self.DeleteTool,
            parent=self.iface.mainWindow())
        self.toolbar.addAction(self.actions[5])

        iconLine_path = QIcon(self.plugin_dir + "/image/setting.png")
        self.add_action(
            iconLine_path,
            text=self.tr(u'코멘트입력_설정'),
            callback=self.setting,
            parent=self.iface.mainWindow(),
            Checkable = False)
        self.toolbar.addAction(self.actions[6])

    def setting(self):
        self.dlgsetting.show()
        self.QSettings
        UserName = self.QSettings.value('UserName', '')
        SavePath = self.QSettings.value('SavePath', '')

        self.dlgsetting.lineEdit_userName.setText(UserName)
        self.dlgsetting.mQgsFileWidget.setFilePath(SavePath)

        # self.dlgsetting.mQgsProjectionSelectionWidget.setCrs(QgsCoordinateReferenceSystem(locale.value('locale/comment_manager/Project1','EPSG:4326')))
        # self.dlgsetting.lineEdit_userName.setText(locale.value('locale/comment_manager/user_name',''))

    def save(self):
        UserName = self.dlgsetting.lineEdit_userName.text()
        SavePath = self.dlgsetting.mQgsFileWidget.filePath()

        self.QSettings.setValue('UserName', UserName)
        self.QSettings.setValue('SavePath', SavePath)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&코멘트입력'),
                action)
            self.iface.removeToolBarIcon(action)

        del self.toolbar

    def DeleteTool(self):
        if self.actions[5].isChecked():
            self.tool = SelectDeleteTool(self.iface, wgs_crs)
            self.tool.setAction(self.actions[5])
            self.canvas.setMapTool(self.tool)
        else:
            self.actions[5].setChecked(False)
            self.iface.actionPan().trigger() 

    def startComment(self, drawShape, Vertices, idx):
        self.UserName = self.QSettings.value('UserName', '')
        self.SavePath = self.QSettings.value('SavePath', '')
        self.drawShape = drawShape
        self.Vertices = Vertices
        self.cmtName = f"코멘트_{drawShape}"
        self.Style = self.cmtName + '.qml'
        self.idx = idx
        self.Tool = None

        if not  self.UserName: # 사용자 이름이 없다면 실행 중단
            QMessageBox.critical(self.iface.mainWindow(), "Error", "사용자 이름 누락")
            self.actions[idx].setChecked(False)
            self.setting()
            return None
        
        if not  self.SavePath: # 사용자 이름이 없다면 실행 중단
            QMessageBox.critical(self.iface.mainWindow(), "Error", "저장 경로 누락")
            self.actions[idx].setChecked(False)
            self.setting()
            return None
        
        self.layer = self.layer_select(self.drawShape, self.cmtName, wgs_crs, self.Style)

        if self.actions[self.idx].isChecked():
            if self.idx in [0]:
                self.Tool = DrawPointComment(self.iface)
            elif self.idx in [1, 2, 3]:
                self.Tool = DrawLineComment(self.iface,idx)
            elif self.idx == 4:
                self.Tool = DrawpolygonComment(self.iface)

            self.Tool.setAction(self.actions[self.idx])
            self.Tool.selectionDone.connect(self.draw)
            self.Tool.reset()
            self.canvas.setMapTool(self.Tool)
        else:
            self.actions[self.idx].setChecked(False)
            self.iface.actionPan().trigger()

    def geomTransform(self, rb):
        Geom = rb.asGeometry()
        map_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        Transform = QgsCoordinateTransform(map_crs, wgs_crs, QgsCoordinateTransformContext())
        Geom.transform(Transform)
        rb.setToGeometry(Geom)
        self.canvas.refresh()
        return rb

    def draw(self):
        rb = self.Tool.rb
        rb = self.geomTransform(rb)

        if rb.numberOfVertices() >= self.Vertices:
            self.status = 0

            point = rb.asGeometry().vertexAt(rb.numberOfVertices()-1)

            self.dlg.lineEdit_Comment.clear(); # 입력란 삭제
            self.dlg.lineEdit_Comment.setFocus(); # 입력란 커서 이동

            # name = locale.value('locale/comment_manager/e','')
            self.dlg.label_name.setText(str('사용자:' + str(self.UserName)))

            result = self.dlg.exec_()
            if result:
                commentText = self.dlg.lineEdit_Comment.text()
                # Kind = sum(2 ** i for i, checkBox in enumerate([self.dlg.checkBox_1, self.dlg.checkBox_2, self.dlg.checkBox_3, self.dlg.checkBox_4, self.dlg.checkBox_5]) if checkBox.isChecked())
                self.addFeatureToLayer(rb, self.layer, point, self.idx+1, commentText, self.UserName)
            else:
                self.canvas.setMapTool(self.Tool)

            self.Tool.reset()

    def addFeatureToLayer(self, rb, layer, point, SubKind, commentText, name):
        geom = rb.asGeometry()
        geom.convertToSingleType()
        print(geom.asWkt())
        # stringGeo = ", ".join(["{:.6f} {:.6f}".format(p.x(), p.y()) for p in geom.vertices()])
        # stringGeo = f'({stringGeo})'

        # 2. 새로운 QgsFeature 생성 (레이어의 필드 정의를 그대로 복사)
        feat = QgsFeature(layer.fields())
        feat.setGeometry(geom)

        # 3. 각 필드에 맞는 원시 타입으로 setAttribute
        #    (필드 순서대로라도 되고, 필드 이름으로 해도 됩니다)
        dt = QDateTime.currentDateTime()
        feat.setAttribute("Lon",         point.x())     # float
        feat.setAttribute("Lat",         point.y())     # float
        # feat.setAttribute("wkt_geom",    geom.asWkt())     # str
        feat.setAttribute("Comment",     commentText)   # str
        feat.setAttribute("Sub_Kind",    SubKind)       # int
        feat.setAttribute("Update_Date", dt)            # QDateTime
        feat.setAttribute("Update_User", name)          # str

        # 4. 레이어에 추가
        layer.startEditing()
        layer.addFeature(feat)
        layer.commitChanges()

        # 5. 다시 편집 모드로 돌려 놓으면 다음 추가도 가능
        layer.startEditing()
        self.iface.mapCanvas().refresh()


    def layer_select(self, drawShape, cmtName, Comment_crs,Style):
        layers = QgsProject.instance().mapLayersByName(cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer.startEditing()
            return layer

        else: # 코멘트 레이어가 없다면
            # documents_path = os.path.join(os.path.expanduser("~"), "Documents")
            file_path = f"{self.SavePath}/{cmtName}.gpkg"  # 불러올 파일의 경로

            if os.path.isfile(file_path):

                # 벡터 레이어 생성 (두 번째 인자는 레이어 이름, 세 번째 인자는 데이터 소스 유형)
                layer = QgsVectorLayer(file_path, f'{cmtName}', "ogr")

                if not layer.isValid():
                    raise Exception(f"레이어 불러오기 실패: {file_path}")

                # 2) QML 스타일 다시 적용
                qml_path = os.path.join(self.plugin_dir, 'style', Style)
                ok, err = layer.loadNamedStyle(qml_path)
                if not ok:
                    QgsMessageLog.logMessage(f"스타일 로드 실패: {err}", 'CommentTool', Qgis.Warning)

                # 3) 스타일 적용을 반영
                layer.triggerRepaint()
                layer.reload()

                QgsProject.instance().addMapLayer(layer, True)
                self.iface.mapCanvas().refresh()
                self.iface.layerTreeView().refreshLayerSymbology(layer.id())
                layer.startEditing()
                return layer

            else:

                layer = QgsVectorLayer(drawShape, cmtName, "memory") # 코멘트 레이어 생성
                pr = layer.dataProvider() 
                pr.addAttributes([  QgsField("Lon", QVariant.Double),
                                    QgsField("Lat",  QVariant.Double),
                                    # QgsField("wkt_geom", QVariant.String),
                                    QgsField("Comment", QVariant.String),
                                    # QgsField("Kind", QVariant.Int),
                                    QgsField("Sub_Kind", QVariant.Int),
                                    QgsField("Update_Date", QVariant.DateTime),
                                    QgsField("Update_User", QVariant.String)])
                layer.updateFields()
                layer.setCrs(Comment_crs)
                # 스타일 적용
                # layer.loadNamedStyle(os.path.join(self.plugin_dir, 'style', Style))
      
                if not os.path.exists(self.SavePath):
                    os.makedirs(self.SavePath)  # 디ㄷ면 생성

                file_path = os.path.join(self.SavePath, f'{cmtName}.gpkg')
                transform_context = QgsProject.instance().transformContext()
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "GPKG"            # GeoPackage 드라이버
                options.fileEncoding = "windows-949"         # UTF-8 인코딩
                options.layerName = cmtName            

                # V2 호출
                result = QgsVectorFileWriter.writeAsVectorFormatV2(
                    layer,
                    file_path,
                    transform_context,
                    options
                )

                # result가 int일 수도, (int, str) 튜플일 수도 있으니 대응
                if isinstance(result, tuple):
                    err_code, err_msg = result
                else:
                    err_code = result
                    err_msg = ''

                if err_code != QgsVectorFileWriter.NoError:
                    raise Exception(f"GPKG 저장 실패 (error code: {err_code}, msg: {err_msg})")

                # 2) 저장된 gpkg 레이어를 다시 불러와 프로젝트에 추가
                layer = QgsVectorLayer(file_path, cmtName, "ogr")

                if not layer.isValid():
                    raise Exception(f"레이어 불러오기 실패: {file_path}")

                # 2) QML 스타일 다시 적용
                qml_path = os.path.join(self.plugin_dir, 'style', Style)
                ok, err = layer.loadNamedStyle(qml_path)
                if not ok:
                    QgsMessageLog.logMessage(f"스타일 로드 실패: {err}", 'CommentTool', Qgis.Warning)

                # 3) 스타일 적용을 반영
                layer.triggerRepaint()
                layer.reload()

                QgsProject.instance().addMapLayer(layer, True)
                self.iface.mapCanvas().refresh()
                self.iface.layerTreeView().refreshLayerSymbology(layer.id())
                layer.startEditing()
                return layer

    def Reset(self):
        self.dlg.lineEdit_Comment.clear(); # 입력란 삭제
        self.dlg.lineEdit_Comment.setFocus(); # 입력란 커서 이동

