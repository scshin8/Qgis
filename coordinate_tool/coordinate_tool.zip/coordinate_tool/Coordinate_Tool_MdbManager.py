import pyodbc



# 안전운행데이터 종류 및 분류
#포멧 형식 - 키값:'설명', '컬러, 'svg 파일 위치'
cam_kind = {
    1: '고정식 과속단속, #FFFF00, /images/Arrow_06.svg',
    2: '버스전용차로 단속, #00FF00, /images/Arrow_06.svg',
    3: '이동식과속단속, #00FF00, /images/Arrow_06.svg',
    4: '과적위반단속카메라, #00FF00, /images/Arrow_06.svg',
    5: '차랑번호인식장치, #00FF00, /images/Arrow_06.svg',
    6: '교통정보수집장치, #00FF00, /images/Arrow_06.svg',
    7: '신호위반단속, #0000FF, /images/Arrow_06.svg',
    8: '굽은도로, #00FF00, /images/Arrow_06.svg',
    9: '사고다발, #00FF00, /images/Arrow_06.svg',
    10:'고속도로 확장공사구간, #00FF00, /images/Arrow_06.svg',
    11:'경찰청, #00FF00, /images/Arrow_06.svg',
    13:'어린이보호구역, #00FF00, /images/Arrow_06.svg',
    14:'낙석 지역, #00FF00, /images/Arrow_06.svg',
    15:'안개 지역, #00FF00, /images/Arrow_06.svg',
    17:'좁아지는 도로, #00FF00, /images/Arrow_06.svg',
    18:'강풍 지역, #00FF00, /images/Arrow_06.svg',
    19:'철길건널목, #00FF00, /images/Arrow_06.svg',
    20:'?????, #00FF00, /images/Arrow_06.svg',
    22:'주정차단속카메라, #00FF00, /images/Arrow_06.svg',
    23:'안전띠단속, #00FF00, /images/Arrow_06.svg',
    27:'과속방지턱, #00FF00, /images/Arrow_06.svg',
    28:'내리막 도로, #00FF00, /images/Arrow_06.svg',
    60:'로드킬, #00FF00, /images/Arrow_06.svg',
    61:'끼어들기 단속 카메라, #00FF00, /images/Arrow_06.svg',
    62:'가변차로 단속 카메라, #00FF00, /images/Arrow_06.svg',
    63:'신호위반카메라, #00FF00, /images/Arrow_06.svg',
    65:'꼬리물기단속카메라, #00FF00, /images/Arrow_06.svg',
    66:'졸음쉼터, #00FF00, /images/Arrow_06.svg',
    67:'fuel-cut, #00FF00, /images/Arrow_06.svg',
    68:'역주행방지, #00FF00, /images/Arrow_06.svg',
    69:'횡단보도, #00FF00, /images/Arrow_06.svg',
    70:'터널내차선변경카메라, #00FF00, /images/Arrow_06.svg',
    71:'높이초과단속카메라, #00FF00, /images/Arrow_06.svg'
}

# mdb 파싱 관리 클래스
class AddMdbManager:
    def __init__(self):
        self.mdbFileName = None
        self.con_string = None
        self.connect = None
        self.cursor = None
        self.tableNames = None
        self.columns = None

        # ★ 데이터 컨테이너
        self.datas = []
        self.camKindSet = set()
        
    # [추가] 특정 필드의 고유값만 빠르게 가져오기 (DISTINCT)
    def GetDistinctValues(self, table, field):
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        string = "SELECT DISTINCT [{}] FROM [{}]".format(field, table)
        self.cursor.execute(string)
        rows = self.cursor.fetchall()
        self.connect.close()
        return [r[0] for r in rows if r[0] is not None]

    # [추가] 선택된 필드/값으로 필터링한 데이터 읽기 (없으면 전체)
    def ReadDatasFiltered(self, query, table, field=None, selected_values=None):
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()

        if field and selected_values:
            # 문자열로 들어온 체크값을 숫자 컬럼에도 매칭되도록 변환 시도
            def _conv(v):
                try:
                    return int(v)
                except (ValueError, TypeError):
                    try:
                        return float(v)
                    except (ValueError, TypeError):
                        return v
            values = [_conv(v) for v in selected_values]
            placeholders = ", ".join("?" for _ in values)
            string = "SELECT {} FROM [{}] WHERE [{}] IN ({})".format(query, table, field, placeholders)
            self.cursor.execute(string, values)
        else:
            string = "SELECT {} FROM [{}]".format(query, table)
            self.cursor.execute(string)

        rows = self.cursor.fetchall()
        self.datas = list(rows)
        self.connect.close()

    # odbc 파일 오픈
    def OpenFile(self, filePath):
        self.con_string = r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ='
        self.con_string += filePath + r';'
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        # 테이블명 얻기
        self.tableNames = [x[2] for x in self.cursor.tables().fetchall() if x[3] == 'TABLE']
        self.connect.close()

    # 해당 테이블에 컬럼명 읽기
    def ReadColumns(self, tableName):
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        
        string = ("SELECT * FROM {}").format(tableName)
        self.cursor.execute(string)
        self.columns = [column for column in self.cursor.description]        
        self.connect.close()

    # 해당 해당 테이블에 쿼리문으로 Data 읽기
    def ReadDatas(self, query, table):
        # self.connect = pyodbc.connect(self.con_string)
        # self.cursor = self.connect.cursor()
        # string = ("SELECT {} FROM {}").format(query, table)
        # self.cursor.execute(string)

        # self.datas.clear()
        # self.camKindSet.clear()
        # for row in self.cursor.fetchall():
        #     self.camKindSet.add(row[0])
        #     self.datas.append(row)

        # self.connect.close()

        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        string = ("SELECT {} FROM {}").format(query, table)
        self.cursor.execute(string)

        rows = self.cursor.fetchall()

        # ✅ 매번 “새 리스트 객체”를 만들어서 self.datas에 할당
        self.datas = list(rows)

        # camKindSet도 마찬가지로 새 set으로 만들기
        self.camKindSet = {row[0] for row in rows}

        self.connect.close()

    # Get Function
    def GetTables(self):
        return self.tableNames
    
    def GetColumns(self):
        return self.columns
    
    def GetDatas(self):
        # ★ 원본 리스트를 직접 주지 말고 복사본 반환
        return list(self.datas)

    def GetCamKindSet(self):
        return set(self.camKindSet)