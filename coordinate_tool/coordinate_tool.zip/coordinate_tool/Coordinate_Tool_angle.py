# -*- coding: utf-8 -*-
import math
import time
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsFeatureRequest,
    QgsMarkerSymbol,
    QgsTextAnnotation,
    Qgis
)
from qgis.gui import QgsMapCanvasAnnotationItem
from qgis.PyQt.QtCore import QSettings, QPointF, QSizeF
from qgis.PyQt.QtGui import QColor, QFont, QTextDocument

class CoordinateToolAngle:
    def __init__(self, main_tool, iface):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.AngleSymbol = []
        self.angle_run_chk = False
        self.time_start = 0

    def angle_run(self, *args):
        if self.main.angle.isChecked():
            self.canvas.selectionChanged.connect(self.angledisplay)
            self.angle_run_chk = True
            self.angledisplay()
        else:
            try:
                self.canvas.selectionChanged.disconnect(self.angledisplay)
            except Exception:
                pass
            self.remove_Angle()
            self.angle_run_chk = False

    def angledisplay(self, *args):
        if not self.angle_run_chk:
            self.remove_Angle()
            return

        self.time_start = time.perf_counter()
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            return

        featuresCount = layer.selectedFeatureCount()
        if featuresCount > 0:
            self.remove_Angle()
            selected_features = layer.selectedFeatures()

            if len(selected_features) != 1:
                return

            self.selected_feature = selected_features[0]
            geometry = self.selected_feature.geometry()
            if geometry is None or geometry.isEmpty():
                return

            parts = geometry.asGeometryCollection()
            if len(parts) != 1:
                self.iface.messageBar().pushMessage('멀티파츠 객체입니다.', level=Qgis.Info, duration=3)
                return

            wkbType = geometry.wkbType()
            if wkbType in (QgsWkbTypes.LineString, QgsWkbTypes.LineStringZM):
                geometry_points = geometry.asPolyline()
            elif wkbType in (QgsWkbTypes.MultiLineString, QgsWkbTypes.MultiLineStringZM):
                geometry_points = geometry.asMultiPolyline()[0]
            else:
                return

            self.start_point0 = geometry_points[0]
            self.start_point1 = geometry_points[1]
            self.end_point0 = geometry_points[-1]
            self.end_point1 = geometry_points[-2]

            map_crs = self.canvas.mapSettings().destinationCrs()
            layer_crs = layer.crs()
            transform = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())

            extent = self.canvas.extent()
            transformed_extent = transform.transformBoundingBox(extent)
            transformed_extent.scale(2)  # [추가] 화면 범위를 중심 기준 200% 확대
            request = QgsFeatureRequest().setFilterRect(transformed_extent)
            request.setSubsetOfAttributes([])

            visible_features = layer.getFeatures(request)

            sel_endpoints = (self.start_point0, self.end_point0)
            selected_id = self.selected_feature.id()
            adjacent_features = []
            for feature in visible_features:
                if feature.id() == selected_id:
                    continue
                fg = feature.geometry()
                if fg is None or fg.isEmpty():
                    continue
                if fg.isMultipart():
                    pl = fg.asMultiPolyline()
                    if not pl:
                        continue
                    pts = pl[0]
                else:
                    pts = fg.asPolyline()
                if len(pts) < 2:
                    continue
                if pts[0] in sel_endpoints or pts[-1] in sel_endpoints:
                    adjacent_features.append(feature)

            if len(adjacent_features) == 0:
                return

            transform_to_map = QgsCoordinateTransform(layer_crs, map_crs, QgsProject.instance())

            # ─────────────────────────────────────────────────────────────
            # [각도오류 수정 v2] 레이어 좌표계 종류와 무관하게
            #  '각도가 정확한 평면좌표계(EPSG:5179)'로 항상 변환 후 각도 계산.
            #  - 기존 isGeographic() 분기는 웹메르카토르(3857) 같은
            #    '투영좌표계지만 각도가 왜곡되는 경우'를 놓쳐서 오류가 남음.
            #  - 이미지2에서 5179 변환 시 정상 확인됨 → 5179를 기준으로 고정.
            #  ※ 인접 판정 == 비교는 여전히 원본좌표 사용(변환 안 함).
            # ─────────────────────────────────────────────────────────────

            angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
            if layer_crs == angle_crs:
                angle_transform = None
            else:
                angle_transform = QgsCoordinateTransform(layer_crs, angle_crs, QgsProject.instance())

            size = int(self.QSettings.value('spinBox_2', 10))
            txt_color = QColor(self.QSettings.value('markerColorButton_7', '#ff0000')).name()
            back_color = QColor(self.QSettings.value('markerColorButton_8', '#ff0000')).name()
            has_bg = int(self.QSettings.value('background_checkBox_2', 0)) != 0
            bg_style = f"background-color: {back_color};" if has_bg else ""

            marker_symbol = QgsMarkerSymbol.createSimple({
                "name": "rectangle",
                "color": "red",
                "outline_color": "0,0,0,255",
                "outline_style": "no",
                "size": "0"
            })

            fontDefault = QFont('맑은 고딕')
            fontDefault.setBold(True)

            adjacent_links = []
            for feature in adjacent_features:
                if feature.id() == self.selected_feature.id():
                    continue
                adjacent_geometry = feature.geometry()
                if adjacent_geometry is not None:
                    parts = adjacent_geometry.asGeometryCollection()

                    for adj_geom in parts:
                        wkbType = adj_geom.wkbType()
                        if wkbType in (QgsWkbTypes.LineString, QgsWkbTypes.LineStringZM):
                            adjacent_geometry_points = adj_geom.asPolyline()
                        elif wkbType in (QgsWkbTypes.MultiLineString, QgsWkbTypes.MultiLineStringZM):
                            adjacent_geometry_points = adj_geom.asMultiPolyline()[0]
                        else:
                            continue

                        adjacent_start_point0 = adjacent_geometry_points[0]
                        adjacent_start_point1 = adjacent_geometry_points[1]
                        adjacent_end_point0 = adjacent_geometry_points[-1]
                        adjacent_end_point1 = adjacent_geometry_points[-2]
                        length = adj_geom.length()

                        third_point = adj_geom.interpolate(length * 0.5).asPoint()

                        if self.start_point0 == adjacent_start_point0:
                            adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                        elif self.start_point0 == adjacent_end_point0:
                            adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                        elif self.end_point0 == adjacent_start_point0:
                            adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                        elif self.end_point0 == adjacent_end_point0:
                            adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])

            angles_result = []
            for adjacent_link, start_point0, start_point1, end_point0, end_point1, txtPoint in adjacent_links:
                if angle_transform:
                    sp0 = angle_transform.transform(start_point0)
                    sp1 = angle_transform.transform(start_point1)
                    ep0 = angle_transform.transform(end_point0)
                    ep1 = angle_transform.transform(end_point1)
                else:
                    sp0, sp1, ep0, ep1 = start_point0, start_point1, end_point0, end_point1

                angle = math.atan2(sp1.x() - sp0.x(), sp1.y() - sp0.y())
                selected_feature_angle = math.degrees(angle) if angle > 0 else (math.degrees(angle) + 180) + 180

                angle = math.atan2(ep1.x() - ep0.x(), ep1.y() - ep0.y())
                adjacent_feature_angle = math.degrees(angle) if angle > 0 else (math.degrees(angle) + 180) + 180

                abs_angle = round(abs((selected_feature_angle - adjacent_feature_angle) % 360), 1)
                angle_value = "%g" % round(abs_angle if abs_angle < 0 else 180 - abs_angle, 1)

                txtProjectPoint = transform_to_map.transform(txtPoint.x(), txtPoint.y())
                angles_result.append([txtProjectPoint, angle_value])

            text_annotations = []
            for point, angle in angles_result:
                html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{str(angle)}</span>'
                text_document = QTextDocument()
                text_document.setHtml(html_text)
                text_document.setDefaultFont(fontDefault)

                text_annotation = QgsTextAnnotation(self.canvas)
                text_annotation.setDocument(text_document)
                text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0, 0))
                text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0, 0))

                text_annotation.setMapPosition(point)
                text_annotation.setFrameOffsetFromReferencePoint(
                    QPointF(-(text_document.size().width()/2), -(text_document.size().height()/2))
                    )

                text_annotation.setMarkerSymbol(marker_symbol)
                text_annotation.setFrameSize(QSizeF(text_document.size().width() + 1, text_document.size().height()))

                text_annotations.append(text_annotation)

            annotation_items = [QgsMapCanvasAnnotationItem(ta, self.canvas) for ta in text_annotations]
            self.AngleSymbol.extend(annotation_items)
            self.canvas.refresh()
        else:
            self.remove_Angle()

    def remove_Angle(self, *args):
        if len(self.AngleSymbol) > 0:
            for mark in self.AngleSymbol:
                self.canvas.scene().removeItem(mark)
        self.AngleSymbol = []
        self.canvas.refresh()