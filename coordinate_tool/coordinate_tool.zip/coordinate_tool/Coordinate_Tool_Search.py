from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                        QgsCoordinateTransform, 
                        QgsProject, 
                        QgsMarkerSymbol, 
                        QgsTextAnnotation,
                        QgsVectorLayer,
                        QgsField,
                        QgsFeature,
                        QgsGeometry,
                        QgsPointXY
                    )

from PyQt5.QtCore import (QSizeF,
                          QPointF,
                          QSettings,
                          QVariant)

from qgis.gui import (QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from PyQt5.QtGui import (QKeySequence,
                         QTextDocument,
                         QColor,
                         QIcon)

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QTableWidgetItem

import os.path, requests

from .Coordinate_Tool_Function import capture,Coordinate_function
from .Coordinate_Tool_decryptKey import AESCipher
from . import Coordinate_Tool_data

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Search.ui'))

DEFAULT_LABEL_FRAME_SIZE = QSizeF(50.0, 20.0)
DEFAULT_POI_COLOR = QColor(255, 100, 200)
DEFAULT_ICON_SIZE = 12
DEFAULT_MARKER = QgsVertexMarker.ICON_CIRCLE

TABLE1_HEADERS = ["명칭","주소","전화","ID","카테고리","x","y"]
TABLE2_HEADERS = ["명칭","주소","전화","POI_ID","카테고리","x","y"]

class CoordinateToolSearch(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolSearch, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.VertexMarker_1=[]
        self.MarkerSymbol_1=[]
        self.VertexMarker_2=[]
        self.MarkerSymbol_2=[]
        self.clear_table(self.tableWidget, TABLE1_HEADERS)
        self.clear_table(self.tableWidget_2, TABLE2_HEADERS)
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.Function = Coordinate_function(self,iface)
        self.apikeys = Coordinate_Tool_data.API_KEYS
        self.AESCipher = AESCipher(self)
# 주변 POI 검색
        # 클릭 주변 검색
        self.toolButton_00.setIcon(QIcon(os.path.dirname(__file__) + "/icons/point.png"))
        self.toolButton_00.clicked.connect(lambda : self.capture())
        self.captureCoordinate = capture(self.canvas)
        self.captureCoordinate.capturePoint.connect(self.capturedPoint)
        self.captureCoordinate.captureStopped.connect(self.stopCapture)
        self.captureCoordinate.captureStopped1.connect(self.stopCapture1)
        # 입력 좌표 검색
        self.toolButton_9.setIcon(QIcon(os.path.dirname(__file__) + "/icons/move.png"))
        self.toolButton_9.clicked.connect(lambda : self.capture1())
        # 검색 결과 삭제
        self.toolButton_10.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_10.clicked.connect(lambda : self.Remove(2))

        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/duplicateALL.png"))
        self.toolButton_3.clicked.connect(lambda : self.copyTableToClipboard(self.tableWidget_2))

# 키워드 검색
        # 검색 시작
        self.toolButton_1.setIcon(QIcon(os.path.dirname(__file__) + "/icons/move.png"))
        self.toolButton_1.clicked.connect(self.listsetup)

        # 검색 결과 삭제
        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_2.clicked.connect(lambda : self.Remove(1))

        self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/duplicateALL.png"))
        self.toolButton.clicked.connect(lambda : self.copyTableToClipboard(self.tableWidget))

        self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/save1.png"))
        self.toolButton_4.clicked.connect(lambda : self.exportTableToPointLayer(self.tableWidget))

        self.toolButton_5.setIcon(QIcon(os.path.dirname(__file__) + "/icons/save1.png"))
        self.toolButton_5.clicked.connect(lambda : self.exportTableToPointLayer(self.tableWidget_2))

        # API 설정
        self.KeywordSearchComboBox_1.currentIndexChanged.connect(self.KeywordSearchAPIChange)
        idx = int(self.QSettings.value('KeywordSearchComboBox_1', 0))
        self.KeywordSearchComboBox_1.setCurrentIndex(idx)

        self.tableWidget.itemSelectionChanged.connect(lambda :self.btn_fun(1))
        self.tableWidget_2.itemSelectionChanged.connect(lambda :self.btn_fun(2))

        self.lineEdit.setFocus()

    def hideEvent(self, event):
        self.Remove(1)
        self.Remove(2)

    def clear_markers(self, vertex_list, symbol_list):
        for item in vertex_list + symbol_list:
            self.canvas.scene().removeItem(item)
        vertex_list.clear()
        symbol_list.clear()

    def clear_table(self, table, headers):
        self.chk = False
        table.clearContents()
        table.setRowCount(0)
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.resizeColumnsToContents()
        self.set_Enabled(1 if table == self.tableWidget else 2,True)
        self.chk = True

    def set_Enabled(self, idx, val=False):
        if idx == 1:
            self.toolButton.setEnabled(val)
            self.toolButton_2.setEnabled(val)
            self.toolButton_4.setEnabled(val)
        if idx == 2:
            self.toolButton_3.setEnabled(val)
            self.toolButton_5.setEnabled(val)
            self.toolButton_10.setEnabled(val)

    def Remove(self,idx):
        if idx == 1:
            self.lineEdit.clear()
            self.clear_markers(self.VertexMarker_1, self.MarkerSymbol_1)
            self.clear_table(self.tableWidget, TABLE1_HEADERS)
            self.set_Enabled(1)
            # self.lineEdit.setFocus()
        if idx == 2:
            # 주변 POI 삭제
            self.lineEdit_2.clear()
            # 마커, 테이블 삭제
            self.stopCapture1()
            self.clear_markers(self.VertexMarker_2, self.MarkerSymbol_2)
            self.clear_table(self.tableWidget_2, TABLE2_HEADERS)
            self.set_Enabled(2)
            # self.lineEdit_2.setFocus()
        self.lineEdit.setFocus()
        
    def copyTableToClipboard(self, table):
        row_count = table.rowCount()
        col_count = table.columnCount()

        # 헤더 라인
        headers = []
        for col in range(col_count):
            header_item = table.horizontalHeaderItem(col)
            if header_item:
                headers.append(header_item.text())
            else:
                headers.append(f"Column {col+1}")
        lines = ["\t".join(headers)]

        # 데이터 라인
        for row in range(row_count):
            line = []
            for col in range(col_count):
                item = table.item(row, col)
                if item:
                    line.append(item.text())
                else:
                    line.append("")
            lines.append("\t".join(line))

        # 전체 텍스트 결합
        table_text = "\n".join(lines)

        # 클립보드에 복사
        clipboard = QtWidgets.QApplication.clipboard()
        clipboard.setText(table_text)

    def exportTableToPointLayer(self, table):
        # 1) 메모리 레이어 생성 (Point geometry, CRS 지정)
        uri = "Point?crs=EPSG:4326"  # 좌표계에 맞춰 변경 가능
        mem_layer = QgsVectorLayer(uri, "Table_Points", "memory")
        prov = mem_layer.dataProvider()

        # 2) (선택) 속성 필드 정의: ID 필드 하나만 예시로 추가
        field_names = ["명칭", "주소", "전화번호", "ID", "카테고리", "Lon", "Lat"]
        fields = [QgsField(name, QVariant.String) for name in field_names]
        prov.addAttributes(fields)
        mem_layer.updateFields()

        # 3) 테이블행 순회하며 피처 생성
        feats = []
        for row in range(table.rowCount()):
            # 5,6번 컬럼: 인덱스 5 → X, 6 → Y
            item_x = table.item(row, 5)
            item_y = table.item(row, 6)
            if not item_x or not item_y:
                continue
            try:
                x = float(item_x.text())
                y = float(item_y.text())
            except ValueError:
                # 숫자가 아닌 경우 건너뜀
                continue

            feat = QgsFeature()
            # 필드 구조를 피처에 설정
            feat.setFields(mem_layer.fields())
            # 지오메트리 설정
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))

            for col, name in enumerate(field_names):
                item = table.item(row, col)
                val = item.text() if item else ""
                feat.setAttribute(name, val)
            feats.append(feat)

        # 4) 벡터 레이어에 피처 일괄 추가
        prov.addFeatures(feats)
        mem_layer.updateExtents()

        # 5) 프로젝트에 레이어 추가
        QgsProject.instance().addMapLayer(mem_layer)

    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            # self.remove_Marker()
            pass
        # 엔터 누를때 이벤트 발생
        elif e.matches(QKeySequence.InsertParagraphSeparator):
            self.clear_markers(self.VertexMarker_1, self.MarkerSymbol_1)
            self.clear_markers(self.VertexMarker_2, self.MarkerSymbol_2)
            self.CTool.Delete_Marker()
            if self.lineEdit.text()!='':
                self.lineEdit_2.clear()
                self.listsetup()
            elif self.lineEdit_2.text()!='':
                self.lineEdit.clear()
                self.capture1()  
            else:           
                pass

    def KeywordSearchAPIChange(self):
        idx = int(self.KeywordSearchComboBox_1.currentIndex())
        self.QSettings.setValue('KeywordSearchComboBox_1', idx)

    def closeEvent(self, event):
        self.clear_markers(self.VertexMarker_1, self.MarkerSymbol_1)
        self.clear_table(self.tableWidget, TABLE1_HEADERS)
        self.clear_markers(self.VertexMarker_2, self.MarkerSymbol_2)
        self.clear_table(self.tableWidget_2, TABLE2_HEADERS)

# 주변 POI 검색 =================================================================================================================
    def zoompoi(self):
        self.stopCapture1()
        point=self.lineEdit_2.text()
        if point != '':
            Lon,Lat = self.Function.fsconversion(point)
            lon=round(float(Lon)/360000,8)
            lat=round(float(Lat)/360000,8)
            self.Function.moveto(epsg4326, lon, lat, 0) 
        else:
            pass

# 아이콘 클릭으로 캡쳐 중단
    def stopCapture(self):
        self.CTool.Delete_Marker()
        self.toolButton_00.setChecked(False)
        
# ESC 눌러서 캡쳐 중단
    def stopCapture1(self):
        self.CTool.Delete_Marker()
        self.toolButton_00.setChecked(False)
        self.iface.actionPan().trigger()

# 검색지점(클릭지점) 좌표 캡쳐
    def capture(self):
        if self.toolButton_00.isChecked():
            self.Remove(1)
            self.capturechk=0
            self.savedMapTool = self.canvas.mapTool()
            self.canvas.setMapTool(self.captureCoordinate)
        else:
            if self.savedMapTool:
                self.canvas.setMapTool(self.savedMapTool)
                self.savedMapTool = None 
                    
# 입력란 좌표로 POI 검색
    def capture1(self):
        point=self.lineEdit_2.text()
        if point != '':
            self.Remove(1)
            self.clear_table(self.tableWidget_2, TABLE2_HEADERS)
            Lon,Lat = self.Function.fsconversion(point)
            poipoint=str(round(float(Lat)/360000,8))+','+str(round(float(Lon)/360000,8))
            self.zoompoi()
            self.capturedPOI(poipoint)
        else:
            pass
            
# 캡쳐된 좌표 WGS84,GRS좌표로 변환
    def capturedPoint(self, point):
        self.Remove(1)
        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
        GRSpoint = Trans.transform(point.x(), point.y())
        point=(str(round(float(GRSpoint[1]),8))+','+str(round(float(GRSpoint[0]),8))) # API용 WGS84 좌표
        
        if self.capturechk == 0:
            GRS = self.Function.fscoordinate(GRSpoint)
            self.lineEdit_2.setText(GRS) # GRS좌표 
            self.capturedPOI(point)
            self.set_Enabled(2,True)
# 주변POI 검색
    def capturedPOI(self, point):
        self.Buttons1=[]
        self.clear_markers(self.VertexMarker_2, self.MarkerSymbol_2)

        apikey = self.apikeys[str('routo')][0]
        key = self.AESCipher.decrypt(apikey)

        idx = int(self.kind_comboBox.currentIndex())
        if idx == 0:
            parameters = f'latlng={point}&key={key}'
        else:
            kinds = {1: 'oil', 2: 'lpg', 3: 'cng', 4: 'ev', 5: 'hd', 6: 'parking', 7:'building'}
            kind = kinds.get(idx)
            parameters = f'latlng={point}&kind={kind}&key={key}'

        url = 'https://api.routo.com/v1/reverselabel?'
        url += parameters

        request = requests.get(url)
        if request.status_code == 200:
            data = request.json()

            count=data['count']
            self.tableWidget_2.setRowCount(count)

            self.datas = {}

            if count > 0 :
                for i in range(count):
                    address='Null'
                    tel='Null'
                    for col in data['result'][i]:
                        if 'street_address' == col:
                            address=data['result'][i]['street_address']
                        elif 'jibun_address' == col:
                            address=data['result'][i]['jibun_address']
                        if 'telephone' == col:
                            tel=data['result'][i]['telephone']

                    self.datas[i] = {
                        'name'      : data['result'][i]['name'],
                        'address'   : address,
                        'phone'     : tel,
                        'id'        : data['result'][i]['poi_id'],
                        'class'     : data['result'][i]['class'],
                        'x'         : data['result'][i]['lng'],
                        'y'         : data['result'][i]['lat']
                        }

                self.setTableWidget(self.datas, self.tableWidget_2, self.VertexMarker_2, self.MarkerSymbol_2)

                self.chk = True
            else:
                print("Error Code:" + str(data))  
        else:
            QMessageBox.critical(self.iface.mainWindow(), "주변POI", "주변POI 검색 실패")
            print("Error Code : " , request.status_code)

    def setTableWidget(self, datas, TableWidget, VertexMarker, MarkerSymbol):
        TableWidget.setSortingEnabled(False)
        for i in range(len(datas)):
            TableWidget.setItem(i, 0, QTableWidgetItem(str(datas[i]['name'])))
            TableWidget.setItem(i, 1, QTableWidgetItem(str(datas[i]['address'])))
            TableWidget.setItem(i, 2, QTableWidgetItem(str(datas[i]['phone'])))
            TableWidget.setItem(i, 3, QTableWidgetItem(str(datas[i]['id'])))
            TableWidget.setItem(i, 4, QTableWidgetItem(str(datas[i]['class'])))
            TableWidget.setItem(i, 5, QTableWidgetItem(str(round(float(datas[i]['x']),7))))
            TableWidget.setItem(i, 6, QTableWidgetItem(str(round(float(datas[i]['y']),7))))

            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
            projpoint = Trans.transform(float(datas[i]['x']), float(datas[i]['y']))
            # VertexMarker
            m = QgsVertexMarker(self.canvas)
            m.setCenter(projpoint)
            m.setColor(DEFAULT_POI_COLOR)
            m.setPenWidth(3)
            m.setIconSize(DEFAULT_ICON_SIZE)
            m.setIconType(DEFAULT_MARKER) # ICON_BOX, ICON_CROSS, ICON_X
            VertexMarker.append(m)

            sym = QgsMarkerSymbol()
            sym.setSize(0)
            txt = QTextDocument(str(datas[i]['name']))
            lbl = QgsTextAnnotation(self.canvas)
            lbl.setDocument(txt)
            lbl.setFrameSize(DEFAULT_LABEL_FRAME_SIZE)
            lbl.setMapPosition(projpoint)
            lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
            lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
            lbl.setMarkerSymbol(sym)
            Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
            # QgsProject.instance().annotationManager().addAnnotation(lbl)
            MarkerSymbol.append(Symbol)
    
        TableWidget.setAlternatingRowColors(True)
        for i in range(0,6):
            TableWidget.resizeColumnToContents(i)
        TableWidget.resizeColumnsToContents()
        TableWidget.resizeRowsToContents()

        TableWidget.setSortingEnabled(True)

        lon=float(round(float(datas[0]['x']),7))
        lat=float(round(float(datas[0]['y']),7))
        self.Function.moveto(epsg4326, lon, lat, 0)

# 키워드 검색 ========================================================================================================================================
    def listsetup(self):
        idx = int(self.QSettings.value('KeywordSearchComboBox_1', 0))
        keyword = self.lineEdit.text()
        if keyword != '':
            self.Remove(1)
            self.Remove(2)
            self.stopCapture()
            self.Buttons=[]

            # 캔버스의 너비와 높이 가져오기
            canvas_width = self.canvas.width()
            canvas_height = self.canvas.height()
            # 캔버스의 중심 좌표 계산
            center_x = canvas_width / 2
            center_y = canvas_height / 2
            # 중심 좌표를 지도 좌표로 변환
            point = self.canvas.getCoordinateTransform().toMapCoordinates(center_x, center_y)
            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
            GRSpoint = Trans.transform(point.x(), point.y())
            point=(str(round(float(GRSpoint[1]),8))+','+str(round(float(GRSpoint[0]),8))) # API용 WGS84 좌표

            self.chk = True

            if idx == 0:
                self.listsetup_kakao(keyword, GRSpoint, point)
            elif idx == 1:
                self.listsetup_routo(keyword, GRSpoint, point)
            elif idx == 2:
                self.listsetup_google(keyword, GRSpoint, point)

            self.set_Enabled(1,True)

        else:
            pass # 검색어 없음

# 구글 검색 ===========================================================================================================================================
    def Search_google(self,keyword, GRSpoint, point):
        apikey = self.apikeys[str('google_APIkey')][0]
        google_apiKey = self.AESCipher.decrypt(apikey)

        if google_apiKey is None:
            return None
        
        if apikey != '':
            if self.checkBox.isChecked():
                url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?"
                url = url + f"location={point}&"
                url = url + "radius=1500&"
                url = url + f"keyword={keyword}&"
                url = url + f"key={google_apiKey}" 
            else:
                url = f"https://maps.googleapis.com/maps/api/place/textsearch/json?query={keyword}&key={google_apiKey}"

            payload={}
            headers = {}
            response = requests.request("GET", url, headers=headers, data=payload)
            if response.status_code == 200:
                places=response.json()
                return places, google_apiKey
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Google", "구글 검색 요청 오류")
            return None
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Google", "API key Null")
        return None

    def listsetup_google(self,keyword, GRSpoint, point):
        places, google_apiKey = self.Search_google(keyword, GRSpoint, point)
        if places is not None:
            results=places['results']
            if len(results) != 0:
                total = len(results) if len(results) <= 30 else 30
                self.tableWidget.setRowCount(total)
                self.datas = {}
                for i in range(total):
                    place_id=results[i]['place_id']
                    try:
                        url = "https://maps.googleapis.com/maps/api/place/details/json?"
                        url = url + f"place_id={place_id}&"
                        url = url + "fields=formatted_address%2Cname%2Cgeometry%2Cinternational_phone_number%2Curl%2Cplus_code&"
                        url = url + f"key={google_apiKey}"
                        payload={}
                        headers = {}
                        response = requests.request("GET", url, headers=headers, data=payload)
                        places=response.json()
                        formatted_phone_number = places['result'].get('formatted_phone_number')
                        formatted_address = places['result'].get('formatted_address')
                    except:
                        formatted_phone_number = 'None'
                        formatted_address = 'None'

                    name = results[i].get('name')
                    types = str(results[i]['types'])
                    x = results[i]['geometry']['location'].get('lng')
                    y = results[i]['geometry']['location'].get('lat')

                    self.datas[i] = {
                        'name'      : name,
                        'address'   : formatted_address,
                        'phone'     : formatted_phone_number,
                        'id'        : place_id,
                        'class'     : types,
                        'x'         : x,
                        'y'         : y
                        }

                self.setTableWidget(self.datas, self.tableWidget, self.VertexMarker_1, self.MarkerSymbol_1)

            else:
                print('검색결과 없음')
                
# 카카오 검색 ===========================================================================================================================================
    def Search_kakao(self,keyword,page, GRSpoint, point):
                # 결과 컬럼 설정
        # df = pd.DataFrame(columns = ['place_name','road_address_name','address_name','phone','id', 'category_name', 'x','y'])
        df  = {}

        apikey = self.apikeys[str('kakao_APIkey')][0]
        REST_API_KEY = self.AESCipher.decrypt(apikey)

        if REST_API_KEY is None:
            return None
        
        if apikey != '':
            url = 'https://dapi.kakao.com/v2/local/search/keyword.json'
            headers = {"Authorization": "KakaoAK {}".format(REST_API_KEY)}
            idx = 0
            while True:
                if self.checkBox.isChecked():
                    params = {'query': keyword ,'page': page , 'size' : 15,'y': float(GRSpoint[1]) , 'x' :float(GRSpoint[0])}
                else:
                    params = {'query': keyword ,'page': page , 'size' : 15}

                request=requests.get(url, params=params, headers=headers)
                if request.status_code == 200:
                    places=request.json()
                    # 검색결과 취합
                    for document in places['documents']:
                        df[idx] = document
                        idx += 1
                    if places['meta']['is_end']:
                        break
                    page += 1

                else:
                    QMessageBox.critical(self.iface.mainWindow(), "kakao", "카카오 검색 요청 오류")
                    break
        else:
            QMessageBox.critical(self.iface.mainWindow(), "kakao", "API key Null")
            return None
        return df
    
    def listsetup_kakao(self,keyword, GRSpoint, point):

        data = self.Search_kakao (keyword,1, GRSpoint, point)
        if data is None:
            return
        total = len(data)
        if data is not None:
            self.tableWidget.setRowCount(total)

            self.datas = {}
            for i in range(total):
                address = data[i]['road_address_name']
                if address == '':
                    address = data[i]['address_name']

                self.datas[i] = {
                    'name'      : data[i]['place_name'],
                    'address'   : address,
                    'phone'     : data[i]['phone'],
                    'id'        : data[i]['id'],
                    'class'     : data[i]['category_name'],
                    'x'         : data[i]['x'],
                    'y'         : data[i]['y']
                    }

            self.setTableWidget(self.datas, self.tableWidget, self.VertexMarker_1, self.MarkerSymbol_1)

        else:
            print('검색결과 없음')

# 루토 검색 ===========================================================================================================================================
    def Search_routo(self,keyword, GRSpoint, point):
        apikey = self.apikeys[str('routo')][0]
        key = self.AESCipher.decrypt(apikey)
        url=f"https://api.routo.com/v1/places/findplacefromtext?key={key}&rankby=1&size=30"
        url = url + f"&input={keyword}"

        if self.checkBox.isChecked():
            url = url + f"&location={point}"

        request = requests.get(url)
        if request.status_code == 200:
            data = request.json()
            return data
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "검색 결과 없음")
            print("Error Code:" + str(request.status_code))  
        return False
    def listsetup_routo(self,keyword, GRSpoint, point):
        data = self.Search_routo(keyword, GRSpoint, point)
        total = len(data['result'])

        self.datas = {}
        if total > 0:
            self.tableWidget.setRowCount(total)
            for i in range(total):
                address='Null'
                addresstype = 'addr' if data['result'][i]['addrRoad'] == ''else 'addrRoad'
                address = data['result'][i][addresstype]

                tele='Null'
                for col in data['result'][i]:
                    if 'tele' == col:
                        tele = data['result'][i]['tele']
                        break

                poi_id='Null'
                for col in data['result'][i]:
                    if 'poiId' == col:
                        poi_id=data['result'][i]['poiId']

                self.datas[i] = {
                    'name'      : data['result'][i]['title'],
                    'address'   : address,
                    'phone'     : tele,
                    'id'        : poi_id,
                    'class'     : 'Null',
                    'x'         : data['result'][i]['center']['lon'],
                    'y'         : data['result'][i]['center']['lat']
                    }

            self.setTableWidget(self.datas, self.tableWidget, self.VertexMarker_1, self.MarkerSymbol_1)

        else:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "검색 결과 없음")

    def btn_fun(self, index):
        if index == 1:
            table = self.tableWidget
            VertexMarker = self.VertexMarker_1
            MarkerSymbol = self.MarkerSymbol_1
        else:
            table = self.tableWidget_2
            VertexMarker = self.VertexMarker_2
            MarkerSymbol = self.MarkerSymbol_2

        if self.chk:
            # button = tableWidget.sender()
            # item = tableWidget.indexAt(button.pos())  
            selected_items = table.selectedItems()

            if not selected_items:
                self.iface.messageBar().pushWarning("알림", "선택된 테이블 행이 없습니다.")
                return
            
            item = table.indexFromItem(selected_items[-1])

            idx = int(item.row())
            rowCount=table.rowCount()
            
            lon=table.item( idx,5 ).text()
            lat=table.item( idx,6 ).text()
            self.Function.moveto(epsg4326, lon, lat, 0)
            
            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
            projpoint = Trans.transform(float(lon), float(lat))

            self.clear_markers(VertexMarker, MarkerSymbol)

            for i in range(table.rowCount()):
                if i == idx:
                    continue
                self.draw_markers(table, i, Trans, VertexMarker, MarkerSymbol, DEFAULT_POI_COLOR)

            self.draw_markers(table, idx, Trans, VertexMarker, MarkerSymbol, QColor(255,0,0), top=True)

            self.canvas.refresh()

            if index == 1:
                idx = int(self.QSettings.value('KeywordSearchComboBox_1', 0))
                if idx == 2:
                    m = QgsVertexMarker(self.canvas)
                    m.setCenter(projpoint)
                    m.setColor(QColor(255, 0, 0,255))
                    m.setPenWidth(2)
                    m.setIconSize(12)
                    m.setIconType(DEFAULT_MARKER)
                    VertexMarker.append(m)

    def draw_markers(self, table, i, Trans, VertexMarker, MarkerSymbol, color, top=False):

        lon = table.item( i,5 ).text()
        lat = table.item( i,6 ).text()
        projpoint1 = Trans.transform(float(lon), float(lat))
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(projpoint1)
        m.setColor(color)
        m.setPenWidth(3)
        m.setIconSize(DEFAULT_ICON_SIZE)
        m.setIconType(DEFAULT_MARKER) # ICON_BOX, ICON_CROSS, ICON_X, ICON_BOX
        # Z-order: top이면 높은 Z값
        m.setZValue(1 if top else 0)
        VertexMarker.append(m)

        sym = QgsMarkerSymbol()
        sym.setSize(0)
        txt = QTextDocument(str(table.item( i,0 ).text()))
        lbl = QgsTextAnnotation(self.canvas)
        lbl.setDocument(txt)
        lbl.setFrameSize(DEFAULT_LABEL_FRAME_SIZE)
        lbl.setMapPosition(projpoint1)
        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
        lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
        lbl.setMarkerSymbol(sym)
        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
        Symbol.setZValue(1 if top else 0)
        MarkerSymbol.append(Symbol)

