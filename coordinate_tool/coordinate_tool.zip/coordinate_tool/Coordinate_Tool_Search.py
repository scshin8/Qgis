from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject, 
                       QgsMarkerSymbol, 
                       QgsTextAnnotation)

from PyQt5.QtCore import (QSizeF,
                          QPointF,
                          QSettings)

from qgis.gui import (QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from PyQt5.QtGui import (QKeySequence,
                         QTextDocument,
                         QColor,
                         QIcon)

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import (QPushButton,
                             QTableWidgetItem)

import os.path, requests

from .Coordinate_Tool_Funtion import capture,Coordinate_funtion

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Search.ui'))

class CoordinateToolSearch(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolSearch, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.VertexMarker_1=[]
        self.MarkerSymbol_1=[]
        self.VertexMarker_2=[]
        self.MarkerSymbol_2=[]
        self.remove_tableWidget_1()
        self.remove_tableWidget_2()
        self.locale=QSettings()
        self.Funtion = Coordinate_funtion(self,iface)
        
# 주변 POI 검색
        # 클릭 주변 검색
        self.toolButton_00.setIcon(QIcon(os.path.dirname(__file__) + "/icons/point.png"))
        self.toolButton_00.clicked.connect(lambda : self.capture(0))
        self.captureCoordinate = capture(self.canvas)
        self.captureCoordinate.capturePoint.connect(self.capturedPoint)
        self.captureCoordinate.captureStopped.connect(self.stopCapture)
        self.captureCoordinate.captureStopped1.connect(self.stopCapture1)
        # 입력 좌표 검색
        self.toolButton_9.setIcon(QIcon(os.path.dirname(__file__) + "/icons/kakaosearch.png"))
        self.toolButton_9.clicked.connect(lambda : self.capture1(0))
        # 검색 결과 삭제
        self.toolButton_10.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_10.clicked.connect(lambda : self.Remove(2))
        
# 키워드 검색
        # 검색 시작
        self.toolButton_1.setIcon(QIcon(os.path.dirname(__file__) + "/icons/kakaosearch.png"))
        self.toolButton_1.clicked.connect(self.listsetup)
        # 검색 결과 삭제
        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_2.clicked.connect(lambda : self.Remove(1))
        # API 설정
        self.KeywordSearchComboBox_1.currentIndexChanged.connect(self.KeywordSearchAPIChange)
        idx = int(self.locale.value('locale/coordinate_tool/KeywordSearchComboBox_1', 0))
        self.KeywordSearchComboBox_1.setCurrentIndex(idx)
        # 좌표입력창 구글에서만 활성화
        self.lineEdit_3.setEnabled(True) if idx == 2 else self.lineEdit_3.setEnabled(False)
        self.toolButton_4.setEnabled(True) if idx == 2 else self.toolButton_4.setEnabled(False)
        self.toolButton_11.setEnabled(True) if idx == 2 else self.toolButton_11.setEnabled(False)
        # 클릭 좌표 가져오기
        self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/point.png"))
        self.toolButton_4.clicked.connect(lambda : self.capture(1))
        # 좌표 지점 이동
        self.toolButton_11.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_11.clicked.connect(lambda : self.capture1(1))


        
# 도엽이동
        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_3.clicked.connect(self.accept2)
# 주소이동
        self.toolButton_5.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_5.clicked.connect(self.accept3)
# 주소이동API설정
        # self.SearchSetting = SearchAddress(self,iface)
        # self.toolButton_03.setIcon(QIcon(os.path.dirname(__file__) + "/icons/setting.png"))
        # self.toolButton_03.clicked.connect(self.setting)
        # self.AddressSearchAPI.setText(self.Labelset(int(locale.value('locale/coordinate_tool/AddressSearchComboBox_2', 0))))
        
        idx = int(self.locale.value('locale/coordinate_tool/AddressSearchComboBox_3', 0))
        self.AddressSearchComboBox_3.setCurrentIndex(idx)
        self.AddressSearchComboBox_3.currentIndexChanged.connect(self.AddressSearchAPIChange)

# 경위도 이동
        self.toolButton_7.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_7.clicked.connect(self.accept1)

# 입력란 클릭시 이벤트 발생 _ 클릭한 입력란 제외삭제
        self.lineEdit_lon.mouseReleaseEvent = self.mouseRelease_1
        self.lineEdit_lat.mouseReleaseEvent = self.mouseRelease_1
        self.lineEdit_mapid.mouseReleaseEvent = self.mouseRelease_2
        self.lineEdit_address.mouseReleaseEvent = self.mouseRelease_3
        self.lineEdit.mouseReleaseEvent  = self.mouseRelease_4
        self.lineEdit_2.mouseReleaseEvent = self.mouseRelease_5
# 입력란 삭제
    def mouseRelease_1(self,Event):
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.lineEdit_2.clear()
        self.mouseRelease_end(0)
        
    def mouseRelease_2(self,Event):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_address.clear()
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.lineEdit_2.clear()
        self.mouseRelease_end(0)
        
    def mouseRelease_3(self,Event):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.lineEdit_2.clear()
        self.mouseRelease_end(0)
        
    def mouseRelease_4(self,Event):
        self.lineEdit.cursorPosition()
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        self.lineEdit_2.clear()
        self.mouseRelease_end(1)
        
    def mouseRelease_5(self,Event):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.mouseRelease_end(2)
        
    def mouseRelease_6(self):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.remove_tableWidget_1()
        self.remove_Marker_1()
        
    def mouseRelease_end(self,id):
        if id == 1:
            self.remove_tableWidget_2()
            self.remove_Marker_2()
        elif id == 2:
            self.remove_tableWidget_1()
            self.remove_Marker_1()
        else:
            self.remove_tableWidget_1()
            self.remove_tableWidget_2()
            self.remove_Marker_1()
            self.remove_Marker_2()
        self.stopCapture1()
    
    def Remove(self,idx):
        if idx == 1:
            self.lineEdit.clear()
            self.lineEdit_3.clear()
            self.remove_Marker_1()
            self.remove_tableWidget_1()
            # self.lineEdit.setFocus()
        elif idx == 2:
            # 주변 POI 삭제
            self.lineEdit_2.clear()
            # 마커, 테이블 삭제
            self.stopCapture1()
            self.remove_Marker_2()
            self.remove_tableWidget_2()
            self.lineEdit_2.setFocus()
            
    def RemoveAll(self):
        self.lineEdit.clear()
        self.lineEdit_3.clear()
        self.lineEdit_2.clear()
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        self.remove_Marker_1()
        self.remove_tableWidget_1()
        self.stopCapture1()
        self.remove_Marker_2()
        self.remove_tableWidget_2()

       
       
    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            # self.remove_Marker()
            pass
        # 엔터 누를때 이벤트 발생
        elif e.matches(QKeySequence.InsertParagraphSeparator):
            self.remove_Marker_1()
            self.remove_Marker_2()
            self.CTool.Delete_Marker()
            if self.lineEdit.text()!='':
                self.listsetup()
            elif self.lineEdit_address.text()!='':
                self.accept3()
            elif self.lineEdit_mapid.text()!='':
                self.accept2()
            elif self.lineEdit_2.text()!='':
                self.capture1(0)  
            elif self.lineEdit_lon.text()!='':
                self.accept1()
            else:           
                pass

    def remove_Marker_1(self):
        if len(self.VertexMarker_1) > 0:
            for mark in self.VertexMarker_1:
                self.canvas.scene().removeItem(mark)
        self.VertexMarker_1 = []
        if len(self.MarkerSymbol_1) > 0:  
            for mark in self.MarkerSymbol_1:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol_1 = []
        
    def remove_Marker_2(self):
        if len(self.VertexMarker_2) > 0:
            for mark in self.VertexMarker_2:
                self.canvas.scene().removeItem(mark)
        self.VertexMarker_2 = []
        if len(self.MarkerSymbol_2) > 0:  
            for mark in self.MarkerSymbol_2:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol_2 = []
        
    def remove_tableWidget_1(self):
        self.tableWidget.setColumnCount(8)
        table_column=["이동" , "명칭" , "주소" , "전화" , "ID" , "카테고리" , "x" , "y"]
        self.tableWidget.setHorizontalHeaderLabels(table_column)
        self.tableWidget.setRowCount(0)
        self.tableWidget.resizeColumnsToContents()
        
    def remove_tableWidget_2(self):
        self.tableWidget_2.setColumnCount(7)
        table_column1=["이동" , "명칭" , "주소" , "POI_ID" , "카테고리" , "x" , "y"]
        self.tableWidget_2.setHorizontalHeaderLabels(table_column1)
        self.tableWidget_2.setRowCount(0)
        self.tableWidget_2.resizeColumnsToContents()
        self.canvas.refresh()

    def AddressSearchAPIChange(self):
        idx = int(self.AddressSearchComboBox_3.currentIndex())
        self.locale.setValue('locale/coordinate_tool/AddressSearchComboBox_3', idx)

    def KeywordSearchAPIChange(self):
        idx = int(self.KeywordSearchComboBox_1.currentIndex())
        self.locale.setValue('locale/coordinate_tool/KeywordSearchComboBox_1', idx)
        self.lineEdit_3.setEnabled(True) if idx == 2 else self.lineEdit_3.setEnabled(False)
        self.toolButton_4.setEnabled(True) if idx == 2 else self.toolButton_4.setEnabled(False)
        self.toolButton_11.setEnabled(True) if idx == 2 else self.toolButton_11.setEnabled(False)

    def closeEvent(self, event):
        self.remove_Marker_1()
        self.remove_tableWidget_1()
        self.remove_Marker_2()
        self.remove_tableWidget_2()
          
# 주변 POI 검색 =================================================================================================================
    def zoompoi(self):
        self.stopCapture1()
        point=self.lineEdit_2.text()
        if point != '':
            Lon,Lat = self.Funtion.fsconversion(point)
            lon=round(float(Lon)/360000,8)
            lat=round(float(Lat)/360000,8)
            self.Funtion.moveto(epsg4326, lon, lat, 0) 
        else:
            pass

# 아이콘 클릭으로 캡쳐 중단
    def stopCapture(self):
        self.CTool.Delete_Marker()
        self.toolButton_00.setChecked(False)
        self.toolButton_4.setChecked(False)
        
# ESC 눌러서 캡쳐 중단
    def stopCapture1(self):
        self.CTool.Delete_Marker()
        self.toolButton_00.setChecked(False)
        self.toolButton_4.setChecked(False)
        self.iface.actionPan().trigger()
# 검색지점(클릭지점) 좌표 캡쳐
    def capture(self,idx):
        if idx == 0 :
            if self.toolButton_00.isChecked():
                self.mouseRelease_6()
                self.capturechk=0
                self.savedMapTool = self.canvas.mapTool()
                self.canvas.setMapTool(self.captureCoordinate)
            else:
                if self.savedMapTool:
                    self.canvas.setMapTool(self.savedMapTool)
                    self.savedMapTool = None
        elif idx == 1 :
            if self.toolButton_4.isChecked():
                self.capturechk=1
                self.savedMapTool = self.canvas.mapTool()
                self.canvas.setMapTool(self.captureCoordinate)
            else:
                if self.savedMapTool:
                    self.canvas.setMapTool(self.savedMapTool)
                    self.savedMapTool = None   
                    
# 입력란 좌표로 POI 검색
    def capture1(self,idx):
        if idx == 0 :
            point=self.lineEdit_2.text()
            if point != '':
                self.remove_tableWidget_1()
                Lon,Lat = self.Funtion.fsconversion(point)
                poipoint=str(round(float(Lat)/360000,8))+','+str(round(float(Lon)/360000,8))
                self.zoompoi()
                self.capturedPOI(poipoint)
            else:
                pass
        elif idx == 1 :
            point=self.lineEdit_3.text()
            lon=point.split(',')[1]
            lat=point.split(',')[0]
            self.Funtion.moveto(epsg4326, lon, lat, 0) 
            
# 캡쳐된 좌표 WGS84,GRS좌표로 변환
    def capturedPoint(self, point):
        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
        GRSpoint = Trans.transform(point.x(), point.y())
        point=(str(round(float(GRSpoint[1]),8))+','+str(round(float(GRSpoint[0]),8))) # API용 WGS84 좌표
        
        if self.capturechk == 0:
            GRS = self.Funtion.fscoordinate(GRSpoint)
            self.lineEdit_2.setText(GRS) # GRS좌표 
            self.capturedPOI(point)
            
        elif self.capturechk == 1:
            self.lineEdit_3.setText(point) # GRS좌표 

# 주변POI 검색
    def capturedPOI(self, point):
        self.Buttons1=[]
        self.remove_Marker_2()
        key='AB7B15940E89447C'
        parameters = '?' + 'latlng=' +  point  + '&key=' + key
        url = 'https://api.routo.com/v1/reverselabel'
        url += parameters
        request = requests.get(url)
        if request.status_code == 200:
            data = request.json()
            count=data['count']
            self.tableWidget_2.setRowCount(count)
            if count > 0 :
                for i in range(count):
                    btn=QPushButton("이동")
                    self.Buttons1.append(btn)
                    self.Buttons1[i].clicked.connect(self.btn_fun1)
                    self.tableWidget_2.setCellWidget(i,0,self.Buttons1[i]) # 이동 버튼 추가
                    self.tableWidget_2.setItem(i, 1, QTableWidgetItem(data['result'][i]['name']))
                    address='Null'
                    for col in data['result'][i]:
                        if 'street_address' == col:
                            address=data['result'][i]['street_address']
                        elif 'jibun_address' == col:
                            address=data['result'][i]['jibun_address']
                    self.tableWidget_2.setItem(i, 2, QTableWidgetItem(address))
                    self.tableWidget_2.setItem(i, 3, QTableWidgetItem(str(data['result'][i]['poi_id'])))
                    self.tableWidget_2.setItem(i, 4, QTableWidgetItem(data['result'][i]['class']))
                    self.tableWidget_2.setItem(i, 5, QTableWidgetItem(str(round(float(data['result'][i]['lng']),7))))
                    self.tableWidget_2.setItem(i, 6, QTableWidgetItem(str(round(float(data['result'][i]['lat']),7))))
                    
                    projCRS = self.canvas.mapSettings().destinationCrs()
                    Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                    projpoint = Trans.transform(float(data['result'][i]['lng']), float(data['result'][i]['lat']))
                    # VertexMarker
                    m = QgsVertexMarker(self.canvas)
                    m.setCenter(projpoint)
                    m.setColor(QColor(255, 100, 200))
                    m.setPenWidth(2)
                    m.setIconSize(12)
                    m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                    self.VertexMarker_2.append(m)

                    sym = QgsMarkerSymbol()
                    sym.setSize(0)
                    # sym.setColor(QColor(0, 0, 0, 0)) #setColor(QColor("#67000d"))
                    txt = QTextDocument(data['result'][i]['name'])
                    lbl = QgsTextAnnotation(self.canvas)
                    lbl.setDocument(txt)
                    lbl.setFrameSize(QSizeF(50.0, 20.0))
                    lbl.setMapPosition(projpoint)
                    lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                    lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
                    lbl.setMarkerSymbol(sym)
                    Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                    # QgsProject.instance().annotationManager().addAnnotation(lbl)
                    self.MarkerSymbol_2.append(Symbol)
                    
                self.tableWidget_2.setAlternatingRowColors(True)
                for i in range(1,7):
                    self.tableWidget_2.resizeColumnToContents(i)
                # self.tableWidget_2.resizeColumnsToContents()
                # self.tableWidget_2.resizeRowsToContents()
            else:
                print("Error Code:" + str(data))  
        else:
            QMessageBox.critical(self.iface.mainWindow(), "주변POI", "주변POI 검색 실패")
            print("Error Code : " , request.status_code)

    def btn_fun1(self):
        button = self.tableWidget_2.sender()
        item = self.tableWidget_2.indexAt(button.pos())
        idx = int(item.row())
        rowCount=self.tableWidget_2.rowCount()

        lon=self.tableWidget_2.item( idx,5 ).text()
        lat=self.tableWidget_2.item( idx,6 ).text()
        self.Funtion.moveto(epsg4326, lon, lat, 0)

        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
        projpoint = Trans.transform(float(lon), float(lat))

        self.remove_Marker_2()

        for i in range(rowCount):
            if idx != i :
                lon=self.tableWidget_2.item( i,5 ).text()
                lat=self.tableWidget_2.item( i,6 ).text()
                projpoint1 = Trans.transform(float(lon), float(lat))
                m = QgsVertexMarker(self.canvas)
                m.setCenter(projpoint1)
                m.setColor(QColor(255, 100, 200))
                m.setPenWidth(2)
                m.setIconSize(12)
                m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                self.VertexMarker_2.append(m)

                lon=self.tableWidget_2.item( i,5 ).text()
                lat=self.tableWidget_2.item( i,6 ).text()
                projpoint1 = Trans.transform(float(lon), float(lat))
                sym = QgsMarkerSymbol()
                sym.setSize(0)
                txt = QTextDocument(str(self.tableWidget_2.item( i,1 ).text()))
                lbl = QgsTextAnnotation(self.canvas)
                lbl.setDocument(txt)
                lbl.setFrameSize(QSizeF(50.0, 20.0))
                lbl.setMapPosition(projpoint1)
                lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
                lbl.setMarkerSymbol(sym)
                Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                self.MarkerSymbol_2.append(Symbol)
                
        m = QgsVertexMarker(self.canvas)
        m.setCenter(projpoint)
        m.setColor(QColor(255, 0, 0))
        m.setPenWidth(3)
        m.setIconSize(12)
        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
        self.VertexMarker_2.append(m)
        
        lbl = QgsTextAnnotation(self.canvas)
        txt = QTextDocument(str(self.tableWidget_2.item( idx,1 ).text()))
        sym = QgsMarkerSymbol()
        sym.setSize(0)
        lbl.setDocument(txt)
        lbl.setFrameSize(QSizeF(50.0, 20.0))
        lbl.setMapPosition(projpoint)
        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
        # lbl.setFrameBorderWidth(0)
        # lbl.setFrameColor(QColor(255, 0, 0))
        # lbl.setFrameBackgroundColor(QColor("#d7d7d7"))
        lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
        lbl.setMarkerSymbol(sym)
        # QgsProject.instance().annotationManager().addAnnotation(lbl)
        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
        self.MarkerSymbol_2.append(Symbol)
        self.canvas.refresh()

# 경위도 값이 존재==========================================================================================================================
    def accept1(self):
        if self.lineEdit_lon.text()!='':
            if self.lineEdit_lat.text()!='':
                lon=self.lineEdit_lon.text().strip()
                lat=self.lineEdit_lat.text().strip()
                lon=(int(float(lon)))/360000
                lat=(int(float(lat)))/360000
                checkBox=2
                self.Funtion.moveto(epsg4301, lon, lat, 0)
            else:
                print('경위도 입력 확인')
                pass
        
# MAPID 값이 존재==========================================================================================================================
    def accept2(self):
        if self.lineEdit_mapid.text()!='':
            MapID=self.lineEdit_mapid.text().strip()
            if len(MapID) >= 4:
                map1=int(MapID[0])
                map2=int(MapID[1])
                map3=int(MapID[2])
                map4=int(MapID[3])
                # 도엽중앙 좌표값 추출
                lon=(43897500+(map1*360000)+(45000*map3))
                lat=(11625000+(map2*240000)+(30000*map4))
                # 도엽 5자로 좌표값 추출
                if len(MapID) >= 5:
                    if (MapID[4])=='(':     #FS 좌표라면 패스
                        pass
                    else:
                        map5=int(MapID[4])
                        if map5==1:
                            lon = lon - (45000/4)
                            lat = lat + (30000/4)
                        elif map5==2:
                            lon = lon + (45000/4)
                            lat = lat + (30000/4)
                        elif map5==3:
                            lon = lon + (45000/4)
                            lat = lat - (30000/4)
                        elif map5==4:
                            lon = lon - (45000/4)
                            lat = lat - (30000/4)

                        # 도엽 6자로 좌표값 추출
                        if len(MapID) >= 6:
                            map6=int(MapID[5])
                            if map6==1:
                                lon = lon - (45000/8)
                                lat = lat + (30000/8)
                            elif map6==2:
                                lon = lon + (45000/8)
                                lat = lat + (30000/8)
                            elif map6==3:
                                lon = lon + (45000/8)
                                lat = lat - (30000/8)
                            elif map6==4:
                                lon = lon - (45000/8)
                                lat = lat - (30000/8)
                        # 도엽 7자로 좌표값 추출
                        if len(MapID) >= 7:
                            map7=int(MapID[6])
                            if map7==1:
                                lon = lon - (45000/16)
                                lat = lat + (30000/16)
                            elif map7==2:
                                lon = lon + (45000/16)
                                lat = lat + (30000/16)
                            elif map7==3:
                                lon = lon + (45000/16)
                                lat = lat - (30000/16)
                            elif map7==4:
                                lon = lon - (45000/16)
                                lat = lat - (30000/16)
                # 추출된 경위도 값에서 360000나누어서 베셀 좌표로 변환
                lon=lon/360000
                lat=lat/360000
                self.Funtion.moveto(epsg4301, lon, lat, 0)                  
            else: # 도엽 입력값이 3자리 이하라면 패스
                pass

# 주소가 입력 되었다면 다음 함수 진행==========================================================================================================================
    def accept3(self):
        if self.lineEdit_address.text()!='':
            address=self.lineEdit_address.text().strip()
            # 주소로 좌표 찾기 API 인덱스
            idx=int(self.locale.value('locale/coordinate_tool/AddressSearchComboBox_3', 0))
            if idx==0:
                self.kakaoaddress(address)  # kakao API
            elif idx==1:
                self.naveraddress(address) # naver API
            elif idx==2:
                self.vworldaddress(address,) # vworld API
            elif idx==3:
                self.jusoaddress(address) # juso API
            else:
                self.Routoaddress(address) # Routo API
        else:
            print('입력값 없음')
            
# kakao API
    def kakaoaddress(self,address):
        try:
            url = "https://dapi.kakao.com/v2/local/search/address.json"
            REST_API_KEY=str(self.locale.value('locale/coordinate_tool/REST_API_KEY',''))
            if REST_API_KEY != '':
                headers = {"Authorization": "KakaoAK {}".format(REST_API_KEY)}
                params = {"query": "{}".format(address)}
                request = requests.get(url, params=params, headers=headers)
                if request.status_code == 200:
                    data = request.json()
                    documents = data["documents"][0]
                    lon=documents["x"]
                    lat=documents["y"]
                    # 좌표값 취득후 화면이동 함수로 토스
                    self.Funtion.moveto(epsg4326, lon, lat, 0)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Kakao", "요청 오류 API KEY, 입력주소 재확인")
                    print("KA Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Kakao", "API key Null")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Kakao", "요청 오류 API KEY, 입력주소 재확인")
# naver API
    def naveraddress(self,address):
        try:
            client_id=str(self.locale.value('locale/coordinate_tool/client_id',''))
            client_secret=str(self.locale.value('locale/coordinate_tool/client_secret',''))
            if client_id != '' and  client_secret != '':
                url = f"https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode?query={address}"
                headers = {'X-NCP-APIGW-API-KEY-ID': client_id,
                            'X-NCP-APIGW-API-KEY': client_secret
                            }
                request = requests.get(url, headers=headers)
                if request.status_code == 200:
                    data = request.json()
                    if data['addresses'] != [] :
                        lat = data['addresses'][0]['y']  # 위도
                        lon = data['addresses'][0]['x']  # 경도
                        # 좌표값 취득후 화면이동 함수로 토스
                        self.Funtion.moveto(epsg4326, lon, lat, 0)
                    else:
                        print("'addresses' not exist!")
                        # 입력된 주소 검색 실패시 kakao 로 재검색
                        self.kakaoaddress(address)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Naver", "요청 오류 API KEY, 입력주소 재확인")
                    print("NA Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Naver", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Naver", "요청 오류 API KEY, 입력주소 재확인")
            
# vworld API
    def vworldaddress(self,address):
        try:
            Vworld_APIkey=str(self.locale.value('locale/coordinate_tool/Vworld_APIkey',''))
            if Vworld_APIkey != '':
                url = "http://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&crs=epsg:4326&address="
                url += address
                url += "&refine=true&simple=false&format=json&type=ROAD&key="
                url +=  Vworld_APIkey
                request = requests.get(url)
                if request.status_code == 200:
                    data = request.json()
                    # 도로명주소로 검색한 결과
                    if data['response']['status'] == "OK":
                        lon=data['response']['result']['point']['x']
                        lat=data['response']['result']['point']['y']
                        # 좌표값 취득후 화면이동 함수로 토스
                        self.Funtion.moveto(epsg4326, lon, lat, 0)
                    # 도로명 주소가 아니라면 지번 주소로 재검색
                    else:
                        url = "http://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&crs=epsg:4326&address="
                        url += address
                        url += "&refine=true&simple=false&format=json&type=PARCEL&key="
                        url +=  Vworld_APIkey
                        request = requests.get(url)
                        if request.status_code == 200:
                            data = request.json()
                            if data['response']['status'] == "OK":
                                lon=data['response']['result']['point']['x']
                                lat=data['response']['result']['point']['y']
                                # 좌표값 취득후 화면이동 함수로 토스
                                self.Funtion.moveto(epsg4326, lon, lat, 0)
                            else:
                                QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
                                print("Error Code:" + str(data['response']['status']))
                        else:
                            print("Error Code:" + str(request.status_code))
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
                    print("Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Vworld", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
# juso API
    def jusoaddress(self,address):
        try:
            Juso_APIkey=str(self.locale.value('locale/coordinate_tool/Juso_APIkey',''))
            Juso_APIkey_2=str(self.locale.value('locale/coordinate_tool/Juso_APIkey_2',''))
            if Juso_APIkey != '' and Juso_APIkey_2!= '':
                url = 'https://www.juso.go.kr/addrlink/addrLinkApi.do?currentPage=1&countPerPage=1&resultType=json&addInfoYn=Y&keyword='
                url += address
                url+='&confmKey='
                url+= Juso_APIkey
                request = requests.get(url)
                if request.status_code == 200:
                    data = request.json()
                    try:
                        juso=data['results']['juso'][0]
                        admCd=juso['admCd']
                        rnMgtSn=juso['rnMgtSn']
                        udrtYn=juso['udrtYn']
                        buldMnnm=juso['buldMnnm']
                        buldSlno=juso['buldSlno']
                        sURL = "https://www.juso.go.kr/addrlink/addrCoordApi.do?confmKey="
                        sURL += Juso_APIkey_2
                        sURL += "&admCd=" + admCd + "&rnMgtSn=" + rnMgtSn + "&udrtYn=" + udrtYn + "&buldMnnm=" + buldMnnm + "&buldSlno=" + buldSlno + "&resultType=json"
                        request = requests.get(sURL)
                        if request.status_code == 200:
                            data = request.json()
                            juso=data['results']['juso'][0]
                            lon=juso['entX']
                            lat=juso['entY']
                            setCRS = QgsCoordinateReferenceSystem('EPSG:5179')
                            self.Funtion.moveto(setCRS, lon, lat, 0)
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                            print("Error Code:" + str(request.status_code))
                    except:
                        QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                    print("Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "juso", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
 # Routo API
    def Routoaddress(self,address):
        try:
            url="https://api.routo.com/v1/geocode?key=AB7B15940E89447C&address="
            url += address
            request = requests.get(url)
            if request.status_code == 200:
                data = request.json()
                if data['count'] != 0:
                    if data['result'][0]['accuracy'] == 10:
                        lon=data['result'][0]['street']['lng']
                        lat=data['result'][0]['street']['lat']
                    elif data['result'][0]['accuracy'] == 20:
                        lon=data['result'][0]['jibun']['lng']
                        lat=data['result'][0]['jibun']['lat']
                    self.Funtion.moveto(epsg4326, lon, lat, 0)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")
                print("Error Code:" + str(request.status_code))
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")
# 키워드 검색 ========================================================================================================================================
    def listsetup(self):
        idx = int(self.locale.value('locale/coordinate_tool/KeywordSearchComboBox_1', 0))
        keyword = self.lineEdit.text()
        if keyword != '':
            self.remove_Marker_1()
            self.remove_tableWidget_2()
            self.stopCapture()
            self.Buttons=[]
            
            if idx == 0:
                self.listsetup_kakao(keyword)
            elif idx == 1:
                self.listsetup_routo(keyword)
            elif idx == 2:
                self.listsetup_google(keyword)
        else:
            pass # 검색어 없음



    def Search_google(self,keyword):
        google_apiKey=str(self.locale.value('locale/coordinate_tool/google_apiKey',''))
        if google_apiKey != '':
            display = self.lineEdit_3.text()
            if display == '':
                url = f"https://maps.googleapis.com/maps/api/place/textsearch/json?query={keyword}&key={google_apiKey}"
            else:
                url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?"
                url = url + f"location={display}&"
                url = url + "radius=1500&"
                url = url + f"keyword={keyword}&"
                url = url + f"key={google_apiKey}" 
            payload={}
            headers = {}
            response = requests.request("GET", url, headers=headers, data=payload)
            if response.status_code == 200:
                places=response.json()
                print(response.text)
                return places, google_apiKey
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Google", "구글 검색 요청 오류")
            return None
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Google", "API key Null")
        return None

    def listsetup_google(self,keyword):
        places, google_apiKey = self.Search_google(keyword)
        if places is not None:
            results=places['results']
            if len(results) != 0:
                total = len(results) if len(results) <= 30 else 30
                self.tableWidget.setRowCount(total)
                
                x = self.lineEdit_3.text().split(',')[1]
                y = self.lineEdit_3.text().split(',')[0]
                
                projCRS = self.canvas.mapSettings().destinationCrs()
                Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                projpoint = Trans.transform(float(x), float(y))
                
                m = QgsVertexMarker(self.canvas)
                m.setCenter(projpoint)
                m.setColor(QColor(255, 0, 0,255))
                m.setPenWidth(2)
                m.setIconSize(12)
                m.setIconType(QgsVertexMarker.ICON_X)
                self.VertexMarker_1.append(m)
                    
                for i in range(total):
                    btn=QPushButton("이동")
                    btn.resize(16, 16)
                    self.Buttons.append(btn)
                    self.Buttons[i].clicked.connect(self.btn_fun)
                    self.tableWidget.setCellWidget(i,0,self.Buttons[i])

                for i in range(total):
                    place_id=results[i]['place_id']
                    try:
                        url = "https://maps.googleapis.com/maps/api/place/details/json?"
                        url = url + f"place_id={place_id}&"
                        url = url + "fields=formatted_address%2Cname%2Cgeometry%2Cinternational_phone_number%2Curl%2Cplus_code&"
                        url = url + f"key={google_apiKey}"
                        payload={}
                        headers = {}
                        response = requests.request("GET", url, headers=headers, data=payload)
                        print(response.text)
                        places=response.json()
                        formatted_phone_number = places['result'].get('formatted_phone_number')
                        formatted_address = places['result'].get('formatted_address')
                    except:
                        formatted_phone_number = 'None'
                        formatted_address = 'None'

                    name = results[i].get('name')
                    types = str(results[i]['types'])
                    x = results[i]['geometry']['location'].get('lng')
                    y = results[i]['geometry']['location'].get('lat')

                    self.tableWidget.setItem(i, 1, QTableWidgetItem(name))
                    self.tableWidget.setItem(i, 2, QTableWidgetItem(formatted_address))
                    self.tableWidget.setItem(i, 3, QTableWidgetItem(formatted_phone_number))
                    self.tableWidget.setItem(i, 4, QTableWidgetItem(place_id))
                    self.tableWidget.setItem(i, 5, QTableWidgetItem(types))
                    self.tableWidget.setItem(i, 6, QTableWidgetItem(str(x)))
                    self.tableWidget.setItem(i, 7, QTableWidgetItem(str(y)))

                    projpoint = Trans.transform(float(x), float(y))
                    m = QgsVertexMarker(self.canvas)
                    m.setCenter(projpoint)
                    if i == 0:
                        m.setColor(QColor(255, 0, 0))
                        m.setPenWidth(3)
                    else:
                        m.setColor(QColor(255, 100, 200))
                        m.setPenWidth(2)
                    m.setIconSize(12)
                    m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                    self.VertexMarker_1.append(m)
                    sym = QgsMarkerSymbol()
                    sym.setSize(0)
                    txt = QTextDocument(name)
                    lbl = QgsTextAnnotation(self.canvas)
                    lbl.setDocument(txt)
                    lbl.setFrameSize(QSizeF(50.0, 25.0))
                    lbl.setMapPosition(projpoint)
                    lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                    lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                    lbl.setMarkerSymbol(sym)
                    Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                    self.MarkerSymbol_1.append(Symbol)
                    
                lon=float(results[0]['geometry']['location'].get('lng'))
                lat=float(results[0]['geometry']['location'].get('lat'))
                self.Funtion.moveto(epsg4326, lon, lat, 0)  
            else:
                print('검색결과 없음')
                
            self.tableWidget.setAlternatingRowColors(True)
            for i in range(1,8):
                self.tableWidget.resizeColumnToContents(i)

    # 카카오 검색
    def Search_kakao(self,keyword,page):
        REST_API_KEY = str(self.locale.value('locale/coordinate_tool/REST_API_KEY',''))
        if REST_API_KEY != '':
            url = 'https://dapi.kakao.com/v2/local/search/keyword.json'
            params = {'query': keyword ,'page': page , 'size' : 15}
            headers = {"Authorization": "KakaoAK {}".format(REST_API_KEY)}
            request=requests.get(url, params=params, headers=headers)
            if request.status_code == 200:
                places=request.json()
                return places
            else:
                QMessageBox.critical(self.iface.mainWindow(), "kakao", "카카오 검색 요청 오류")
            return None
        else:
            QMessageBox.critical(self.iface.mainWindow(), "kakao", "API key Null")
        return None
    
    def listsetup_kakao(self,keyword):
        Q1=None
        Q2=None
        places = self.Search_kakao (keyword,1)
        if places is not None:
            totals = places['meta']['pageable_count']
            if totals > 0 :
                if totals > 30:
                    total=30
                    Q1=15
                    Q2=15
                else:
                    total=totals
                    if total > 15:
                        Q1=15
                        Q2=total-15
                    else:
                        Q1=total
                self.tableWidget.setRowCount(total)

                for i in range(total):
                    btn=QPushButton("이동")
                    btn.resize(16, 16)
                    self.Buttons.append(btn)
                    self.Buttons[i].clicked.connect(self.btn_fun)
                    self.tableWidget.setCellWidget(i,0,self.Buttons[i])

                if Q1 is not None:
                    for i in range(Q1):
                        self.tableWidget.setItem(i, 1, QTableWidgetItem(places['documents'][i]['place_name']))
                        if places['documents'][i]['road_address_name'] == '':
                            address=places['documents'][i]['address_name']
                        else:
                            address=places['documents'][i]['road_address_name']
                        self.tableWidget.setItem(i, 2, QTableWidgetItem(address))
                        self.tableWidget.setItem(i, 3, QTableWidgetItem(places['documents'][i]['phone']))
                        self.tableWidget.setItem(i, 4, QTableWidgetItem(places['documents'][i]['id']))
                        self.tableWidget.setItem(i, 5, QTableWidgetItem(places['documents'][i]['category_name']))
                        self.tableWidget.setItem(i, 6, QTableWidgetItem(places['documents'][i]['x']))
                        self.tableWidget.setItem(i, 7, QTableWidgetItem(places['documents'][i]['y']))
                        
                        projCRS = self.canvas.mapSettings().destinationCrs()
                        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                        projpoint = Trans.transform(float(places['documents'][i]['x']), float(places['documents'][i]['y']))
                        m = QgsVertexMarker(self.canvas)
                        m.setCenter(projpoint)
                        if i == 0:
                            m.setColor(QColor(255, 0, 0))
                            m.setPenWidth(3)
                        else:
                            m.setColor(QColor(255, 100, 200))
                            m.setPenWidth(2)
                        m.setIconSize(12)
                        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                        self.VertexMarker_1.append(m)
                        
                        sym = QgsMarkerSymbol()
                        sym.setSize(0)
                        txt = QTextDocument(places['documents'][i]['place_name'])
                        lbl = QgsTextAnnotation(self.canvas)
                        lbl.setDocument(txt)
                        lbl.setFrameSize(QSizeF(50.0, 25.0))
                        lbl.setMapPosition(projpoint)
                        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                        lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                        lbl.setMarkerSymbol(sym)
                        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                        self.MarkerSymbol_1.append(Symbol)
                        
                    lon=float(places['documents'][0]['x'])
                    lat=float(places['documents'][0]['y'])
                    self.Funtion.moveto(epsg4326, lon, lat, 0)  
                        
                if Q2 is not None:
                    places = self.Search_kakao(keyword,2)
                    total2 = places['meta']['pageable_count']
                    if total2 < total:
                        self.tableWidget.setRowCount(total2)
                        Q2= total2 - 15

                    for i in range(Q2):
                        self.tableWidget.setItem(i+15, 1, QTableWidgetItem(places['documents'][i]['place_name']))
                        if places['documents'][i]['road_address_name'] == '':
                            address=places['documents'][i]['address_name']
                        else:
                            address=places['documents'][i]['road_address_name']
                        self.tableWidget.setItem(i+15, 2, QTableWidgetItem(address))
                        self.tableWidget.setItem(i+15, 3, QTableWidgetItem(places['documents'][i]['phone']))
                        self.tableWidget.setItem(i+15, 4, QTableWidgetItem(places['documents'][i]['id']))
                        self.tableWidget.setItem(i+15, 5, QTableWidgetItem(places['documents'][i]['category_name']))
                        self.tableWidget.setItem(i+15, 6, QTableWidgetItem(places['documents'][i]['x']))
                        self.tableWidget.setItem(i+15, 7, QTableWidgetItem(places['documents'][i]['y']))
                
                        projCRS = self.canvas.mapSettings().destinationCrs()
                        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                        projpoint = Trans.transform(float(places['documents'][i]['x']), float(places['documents'][i]['y']))
                        m = QgsVertexMarker(self.canvas)
                        m.setCenter(projpoint)
                        m.setColor(QColor(255, 100, 200))
                        m.setPenWidth(2)
                        m.setIconSize(12)
                        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                        self.VertexMarker_1.append(m)
                        
                        sym = QgsMarkerSymbol()
                        sym.setSize(0)
                        txt = QTextDocument(places['documents'][i]['place_name'])
                        lbl = QgsTextAnnotation(self.canvas)
                        lbl.setDocument(txt)
                        lbl.setFrameSize(QSizeF(50.0, 25.0))
                        lbl.setMapPosition(projpoint)
                        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                        lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                        lbl.setMarkerSymbol(sym)
                        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                        self.MarkerSymbol_1.append(Symbol)
            else:
                print('검색결과 없음')
                
            self.tableWidget.setAlternatingRowColors(True)
            for i in range(1,8):
                self.tableWidget.resizeColumnToContents(i)

    # 루토 검색
    def Search_routo(self,keyword):
        url="https://api.routo.com/v1/places/findplacefromtext?key=AB7B15940E89447C&rankby=1&size=30&input="
        url += keyword
        request = requests.get(url)
        if request.status_code == 200:
            data = request.json()
            return data
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "검색 결과 없음")
            print("Error Code:" + str(request.status_code))  
        return False
    def listsetup_routo(self,keyword):
        data = self.Search_routo(keyword)
        if data['total']>0:
            if data['total']>30:
                total = 30
            else:
                total = data['total']
            self.tableWidget.setRowCount(total)
            
            for i in range(total):
                btn=QPushButton("이동")
                btn.resize(16, 16)
                self.Buttons.append(btn)
                self.Buttons[i].clicked.connect(self.btn_fun)
                self.tableWidget.setCellWidget(i,0,self.Buttons[i])
                self.tableWidget.setItem(i, 1, QTableWidgetItem(data['result'][i]['title']))
                address='Null'
                if data['result'][i]['addrRoad'] == '':
                    address=data['result'][i]['addr']
                else:
                    address=data['result'][i]['addrRoad']
                self.tableWidget.setItem(i, 2, QTableWidgetItem(address))
                
                tele='Null'
                for col in data['result'][i]:
                    if 'tele' == col:
                        tele=data['result'][i]['tele']
                        break
                self.tableWidget.setItem(i, 3, QTableWidgetItem(tele))

                poi_id='Null'
                for col in data['result'][i]:
                    if 'poi_id' == col:
                        poi_id=data['result'][i]['poi_id']
                self.tableWidget.setItem(i, 4, QTableWidgetItem(str(poi_id)))

                self.tableWidget.setItem(i, 5, QTableWidgetItem('Null'))
                self.tableWidget.setItem(i, 6, QTableWidgetItem(str(data['result'][i]['center']['lon'])))
                self.tableWidget.setItem(i, 7, QTableWidgetItem(str(data['result'][i]['center']['lat'])))
                
                projCRS = self.canvas.mapSettings().destinationCrs()
                Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                projpoint = Trans.transform(float(data['result'][i]['center']['lon']), float(data['result'][i]['center']['lat']))
                m = QgsVertexMarker(self.canvas)
                m.setCenter(projpoint)
                if i == 0:
                    m.setColor(QColor(255, 0, 0))
                    m.setPenWidth(3)
                else:
                    m.setColor(QColor(255, 100, 200))
                    m.setPenWidth(2)
                m.setIconSize(12)
                m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                self.VertexMarker_1.append(m)
                
                sym = QgsMarkerSymbol()
                sym.setSize(0)
                txt = QTextDocument(data['result'][i]['title'])
                lbl = QgsTextAnnotation(self.canvas)
                lbl.setDocument(txt)
                lbl.setFrameSize(QSizeF(50.0, 25.0))
                lbl.setMapPosition(projpoint)
                lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                lbl.setMarkerSymbol(sym)
                Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                self.MarkerSymbol_1.append(Symbol)
                
            lon=float(data['result'][0]['center']['lon'])
            lat=float(data['result'][0]['center']['lat'])
            self.Funtion.moveto(epsg4326, lon, lat, 0)
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "검색 결과 없음")
            
        self.tableWidget.setAlternatingRowColors(True)
        for i in range(1,8):
            self.tableWidget.resizeColumnToContents(i) 

    def btn_fun(self):
        button = self.tableWidget.sender()
        item = self.tableWidget.indexAt(button.pos())   
        idx = int(item.row())
        rowCount=self.tableWidget.rowCount()
        
        lon=self.tableWidget.item( idx,6 ).text()
        lat=self.tableWidget.item( idx,7 ).text()
        self.Funtion.moveto(epsg4326, lon, lat, 0)
        
        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
        projpoint = Trans.transform(float(lon), float(lat))
        
        self.remove_Marker_1()

        for i in range(rowCount):
            if idx != i :
                lon=self.tableWidget.item( i,6 ).text()
                lat=self.tableWidget.item( i,7 ).text()
                projpoint1 = Trans.transform(float(lon), float(lat))
                
                m = QgsVertexMarker(self.canvas)
                m.setCenter(projpoint1)
                m.setColor(QColor(255, 100, 200))
                m.setPenWidth(2)
                m.setIconSize(12)
                m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                self.VertexMarker_1.append(m)

                sym = QgsMarkerSymbol()
                sym.setSize(0)
                txt = QTextDocument(str(self.tableWidget.item( i,1 ).text()))
                lbl = QgsTextAnnotation(self.canvas)
                lbl.setDocument(txt)
                lbl.setFrameSize(QSizeF(50.0, 20.0))
                lbl.setMapPosition(projpoint1)
                lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
                lbl.setMarkerSymbol(sym)
                Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                self.MarkerSymbol_1.append(Symbol)
                
        m = QgsVertexMarker(self.canvas)
        m.setCenter(projpoint)
        m.setColor(QColor(255, 0, 0))
        m.setPenWidth(3)
        m.setIconSize(12)
        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
        self.VertexMarker_1.append(m)
        
        lbl = QgsTextAnnotation(self.canvas)
        txt = QTextDocument(str(self.tableWidget.item( idx,1 ).text()))
        sym = QgsMarkerSymbol()
        sym.setSize(0)
        lbl.setDocument(txt)
        lbl.setFrameSize(QSizeF(50.0, 20.0))
        lbl.setMapPosition(projpoint)
        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
        lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
        lbl.setMarkerSymbol(sym)
        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
        self.MarkerSymbol_1.append(Symbol)
        self.canvas.refresh() 
        
        
        x = self.lineEdit_3.text().split(',')[1]
        y = self.lineEdit_3.text().split(',')[0]
        
        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
        projpoint = Trans.transform(float(x), float(y))
        
        idx = int(self.locale.value('locale/coordinate_tool/KeywordSearchComboBox_1', 0))
        if idx == 2:
            m = QgsVertexMarker(self.canvas)
            m.setCenter(projpoint)
            m.setColor(QColor(255, 0, 0,255))
            m.setPenWidth(2)
            m.setIconSize(12)
            m.setIconType(QgsVertexMarker.ICON_X)
            self.VertexMarker_1.append(m)