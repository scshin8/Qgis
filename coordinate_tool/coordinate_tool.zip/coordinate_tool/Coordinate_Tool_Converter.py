'''
좌표변환코드
'''

from qgis.PyQt.uic import loadUiType

from qgis.core import   (Qgis,
                         QgsFields,
                         QgsExpression,
                         QgsExpressionContextUtils,
                         QgsExpressionContext,
                         QgsMapLayerType,
                         QgsCoordinateReferenceSystem,
                         QgsField)

from PyQt5.QtCore import (Qt, QCoreApplication, QTimer, QThread,
                          QSettings, pyqtSignal, QObject,
                          QVariant)

from qgis.PyQt.QtWidgets import QMessageBox, QDialog, QProgressBar, QLabel

from PyQt5.QtGui import QKeySequence

from PyQt5.QtWidgets import (QCompleter,
                             QComboBox,
                             QCheckBox,
                             QDialogButtonBox)

import os
import time

crsNone = QgsCoordinateReferenceSystem()
epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg4004 = QgsCoordinateReferenceSystem('EPSG:4004')
epsg3857 = QgsCoordinateReferenceSystem('EPSG:3857')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Converter.ui'))

class Worker(QObject):
    finished = pyqtSignal()
    cancel = pyqtSignal()
    progress = pyqtSignal(int, str)
    stopped = pyqtSignal()

    def __init__(self, layer, expression, addfields, use_checkBox):
        super().__init__()
        self.layer = layer
        self.expression = expression
        self.addfields = addfields
        self.use_checkBox = use_checkBox
        self._is_stopped = False

    def run(self):
        try:
            count = 0

            for expre, name in zip(self.expression, self.addfields):
                if self._is_stopped:
                    self.stopped.emit()
                    return
                
                expression = QgsExpression(expre)
                context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(self.layer))
                
                # 객체 확인
                objects = (self.layer.selectedFeatures()
                            if self.use_checkBox
                            else self.layer.getFeatures())
                objectCount = (self.layer.selectedFeatureCount()
                            if self.use_checkBox
                            else self.layer.featureCount())

                # 만들 필드명이 기존에 있는지 판별 있다면. 필드 번호 반환 없다면 -1 값 반환
                idx = self.layer.fields().indexOf(name)
                
                # 입력 필드가 가상 필드 일때 True
                if self.layer.fields().fieldOrigin(idx) == QgsFields.OriginExpression:
                    # 표현식으로 새로운값 업데이트
                    self.layer.updateExpressionField(idx, expre)
                    percent = 100
                    count = objectCount
                    
                # 입력 필드가 일반 필드 일때 True
                elif self.layer.fields().fieldOrigin(idx) in (
                        QgsFields.OriginProvider, QgsFields.OriginEdit):
                    
                    changes = {}
                    # 객체순환
                    for object in objects:

                        if self._is_stopped:
                            self.stopped.emit()
                            return

                        context.setFeature(object)
                        new_value = expression.evaluate(context)
                        changes[object.id()] = {idx: new_value}

                        count += 1
                        percent = ((count/len(self.addfields))/float(objectCount)) * 100
                        self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfields),0))}]")

                    self.layer.startEditing()
                    self.layer.dataProvider().changeAttributeValues(changes)
                    # self.layer.commitChanges()
                    self.layer.triggerRepaint()

            if self._is_stopped:
                self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfields),0))}] 변환 중단")
                self.cancel.emit()
            else:
                self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfields),0))}] 변환 완료")
                self.finished.emit()

        except Exception as e:
            self.iface.messageBar().pushMessage(f"Error : {e}, '{name}' 필드 처리 불가", level=Qgis.Warning, duration=4)

    def stop(self):
        self._is_stopped = True

class CoordinateToolConverter(QDialog, FORM_CLASS): # QtWidgets
    def __init__(self, iface, parent):

        super(CoordinateToolConverter, self).__init__(parent) # Qt.WindowStaysOnTopHint
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.chkBox = 0
        # self.setWindowFlags(Qt.WindowStaysOnTopHint) # self.windowFlags()  # Qt.FramelessWindowHint

        self.mMapLayerComboBox.layerChanged.connect(self.LayerChange)
        self.mMapLayerComboBox.setAllowEmptyLayer(True)
        self.mMapLayerComboBox.setCurrentIndex(0)
        
        self.mFieldComboBox.fieldChanged.connect(self.FieldChange2)
        self.mFieldComboBox_1.fieldChanged.connect(self.FieldChange1)
        self.mFieldComboBox_2.fieldChanged.connect(self.FieldChange1)
        self.comboBox.currentIndexChanged.connect(self.SepChange)
        
        self.checkBox_21.stateChanged.connect(self.checkBox_21_Cha)
        self.checkBox_22.stateChanged.connect(self.checkBox_22_Cha)
        self.checkBox_23.stateChanged.connect(self.checkBox_23_Cha)
        self.checkBox_24.stateChanged.connect(self.checkBox_24_Cha)
        
        self.toolButton_1.clicked.connect(lambda : self.chkset(1))
        self.toolButton_2.clicked.connect(lambda : self.chkset(2))
        self.toolButton_3.clicked.connect(lambda : self.chkset(3))

        # self.buttonBox.button(QDialogButtonBox.Ok).clicked.connect(self.run)
        self.pushButton.clicked.connect(self.run)
        self.pushButton.setEnabled(True)

        self.pushButton_2.clicked.connect(self.close)
        # self.buttonBox.button(QDialogButtonBox.Cancel).clicked.connect(self.cancelRun) #.hide() .close

        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.toggle)

        self.checkBox_0.stateChanged.connect(lambda : self.checkBox_Cha(0))
        self.checkBox_1.stateChanged.connect(lambda : self.checkBox_Cha(1))
        self.checkBox_2.stateChanged.connect(lambda : self.checkBox_Cha(2))
        self.checkBox_3.stateChanged.connect(lambda : self.checkBox_Cha(3))
        self.checkBox_4.stateChanged.connect(lambda : self.checkBox_Cha(4))
        self.checkBox_5.stateChanged.connect(lambda : self.checkBox_Cha(5))
        self.checkBox_6.stateChanged.connect(lambda : self.checkBox_Cha(6))
        self.checkBox_7.stateChanged.connect(lambda : self.checkBox_Cha(7))
        self.checkBox_8.stateChanged.connect(lambda : self.checkBox_Cha(8))
        self.checkBox_9.stateChanged.connect(lambda : self.checkBox_Cha(9))
        self.checkBox_10.stateChanged.connect(lambda : self.checkBox_Cha(10))
        self.checkBox_11.stateChanged.connect(lambda : self.checkBox_Cha(11))
        self.checkBox_12.stateChanged.connect(lambda : self.checkBox_Cha(12))
        self.checkBox_13.stateChanged.connect(lambda : self.checkBox_Cha(13))
        self.checkBox_14.stateChanged.connect(lambda : self.checkBox_Cha(14))
        self.checkBox_15.stateChanged.connect(lambda : self.checkBox_Cha(15))
        self.checkBox_16.stateChanged.connect(lambda : self.checkBox_Cha(16))
        self.checkBox_17.stateChanged.connect(lambda : self.checkBox_Cha(17))

    def checkBox_Cha(self,idx):
        if self.chkBox==0:
            fields=[]
            layer = self.mMapLayerComboBox.currentLayer()
            for x in layer.fields():
                fields.append(x.name())
            if self.findChild(QCheckBox,'checkBox_'+str(idx)).isChecked():
                ComboBox=self.findChild(QComboBox,'FieldComboBox_'+str(idx))
                ComboBox.setEnabled(True)
                text = ComboBox.currentText()
                ComboBox.clear()
                ComboBox.addItems(fields)
                ComboBox.setCompleter(QCompleter(fields))
                ComboBox.setEditText(text)            
            else:
                ComboBox=self.findChild(QComboBox,'FieldComboBox_'+str(idx))
                ComboBox.setEnabled(False)
            self.chkBox=0
            
    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.close()
        # enter 누를때 이벤트 발생  
        if e.matches(QKeySequence.InsertParagraphSeparator):
            self.run()
            
    def toggle(self):
        # 현재 레이어층 가져오기
        # layer = self.canvas.currentLayer()
        layer = self.mMapLayerComboBox.currentLayer()
        
        if layer and layer.type() == layer.VectorLayer:
            try:
                layer.editingStarted.disconnect(self.toggle)
            except:
                pass
            try:
                layer.editingStopped.disconnect(self.toggle)
            except:
                pass
            
            # 현재 도면층이 편집 가능하고 선택한 피쳐가 있는지 확인
            # 그리고 플러그인 버튼을 활성화할지 비활성화할지 결정합니다.
            # 도면층 편집 활성화
            # if layer.isEditable():
            if layer.selectedFeatureCount() > 0:
                self.checkBox.setEnabled(True)
                self.checkBox.setChecked(True)
            else:
                self.checkBox.setChecked(False)
                self.checkBox.setEnabled(False)
            layer.editingStopped.connect(self.toggle)
            # 도면층을 편집 비활성화
            # else:
            #     for i in range(len(self.actions)-1):
            #         self.actions[i].setEnabled(False)
            #     layer.editingStarted.connect(self.toggle)
        else:
            self.checkBox.setChecked(False)
            self.checkBox.setEnabled(False)
            
    # def closeEvent(self,e):
    #     self.CTool.coordinateConverter.setChecked(False)
        
    def showEvent(self,e):
        # self.CTool.coordinateConverter.setChecked(True)
        # self.progressBar.setValue(0)
        layer = self.mMapLayerComboBox.currentLayer()
        self.mFieldComboBox.setAllowEmptyFieldName(True)
        self.mFieldComboBox_1.setAllowEmptyFieldName(True)
        self.mFieldComboBox_2.setAllowEmptyFieldName(True)
        self.mFieldComboBox.setLayer(None)
        self.mFieldComboBox_1.setLayer(None)
        self.mFieldComboBox_2.setLayer(None)
        for checkstate in self.findChildren(QCheckBox):
            checkstate.setChecked(False)
        for i in range(0,18):
            self.findChild(QCheckBox,'checkBox_'+str(i)).setEnabled(False)
        self.mMapLayerComboBox.setCurrentIndex(0)
        self.mFieldComboBox_1.setCurrentIndex(0)
        self.mFieldComboBox_2.setCurrentIndex(0)
        self.mFieldComboBox.setCurrentIndex(0)
        self.comboBox_2.setCurrentIndex(-1)
        self.comboBox_2.setEnabled(False)
        self.comboBox.setCurrentIndex(-1)
        self.comboBox.setEnabled(False)
        self.lineEdit.setText('')
        self.lineEdit.setEnabled(False)
        self.label.setText('')
        self.checkBox.setChecked(False)
        self.checkBox.setEnabled(False)
        self.checkBox_21.setChecked(False)
        self.checkBox_21.setEnabled(False)
        self.checkBox_22.setChecked(False)
        self.checkBox_22.setEnabled(False)
        self.checkBox_23.setChecked(False)
        self.checkBox_23.setEnabled(False)
        self.toolButton_1.setEnabled(False)
        self.toolButton_2.setEnabled(False)
        self.toolButton_3.setEnabled(False)
        self.checkBox_24.setEnabled(False)
        
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(False)

    def chkset(self,idx):
        self.chkBox=1
        for i in range(0,18):
            if idx == 1:
                self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(True)
                self.findChild(QComboBox,'FieldComboBox_'+str(i)).setEnabled(True)
                
            elif idx == 2:
                self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(False)
                self.findChild(QComboBox,'FieldComboBox_'+str(i)).setEnabled(False)
            elif idx == 3:
                if self.findChild(QCheckBox,'checkBox_'+str(i)).isChecked():
                    self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(False)
                    self.findChild(QComboBox,'FieldComboBox_'+str(i)).setEnabled(False)
                else:
                    self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(True)
                    self.findChild(QComboBox,'FieldComboBox_'+str(i)).setEnabled(True)
                    
        self.chkBox=0
        
    def checkBox_21_Cha(self):
        if self.checkBox_21.isChecked():
            self.checkBox_22.setChecked(False)
            self.checkBox_23.setChecked(False)
            self.comboBox_2.setCurrentIndex(-1)
            self.comboBox_2.setEnabled(False)
            self.comboBox.setCurrentIndex(-1)
            self.comboBox.setEnabled(False)
            self.label.setText('')
        else:
            self.comboBox_2.setCurrentIndex(0)
            self.comboBox_2.setEnabled(True)
            self.comboBox.setCurrentIndex(0)
            self.comboBox.setEnabled(True)

    def checkBox_22_Cha(self):
        if self.checkBox_22.isChecked():
            self.checkBox_21.setChecked(False)
            self.checkBox_23.setChecked(False)
            self.comboBox_2.setCurrentIndex(-1)
            self.comboBox_2.setEnabled(False)
            self.comboBox.setCurrentIndex(-1)
            self.comboBox.setEnabled(False)
            self.label.setText('')
        else:
            self.comboBox_2.setCurrentIndex(0)
            self.comboBox_2.setEnabled(True)
            self.comboBox.setCurrentIndex(0)
            self.comboBox.setEnabled(True)
        
    def checkBox_23_Cha(self):
        if self.checkBox_23.isChecked():
            self.checkBox_21.setChecked(False)
            self.checkBox_22.setChecked(False)
            self.comboBox_2.setCurrentIndex(-1)
            self.comboBox_2.setEnabled(False)
            self.comboBox.setCurrentIndex(-1)
            self.comboBox.setEnabled(False)
            self.label.setText('')
            self.mQgsProjectionSelectionWidget.setCrs(crsNone)
            self.mQgsProjectionSelectionWidget.setEnabled(False)
        else:
            self.comboBox_2.setCurrentIndex(0)
            self.comboBox_2.setEnabled(True)
            self.comboBox.setCurrentIndex(0)
            self.comboBox.setEnabled(True)
            self.mQgsProjectionSelectionWidget.setEnabled(True)
            layer = self.mMapLayerComboBox.currentLayer()
            if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                self.mQgsProjectionSelectionWidget.setCrs(layer.crs())
        
    def checkBox_24_Cha(self):
        if self.checkBox_24.isChecked():
            self.checkBox_21.setChecked(False)
            self.checkBox_21.setEnabled(False) 
            self.checkBox_22.setChecked(False)
            self.checkBox_22.setEnabled(False)
            self.checkBox_23.setChecked(False)
            self.checkBox_23.setEnabled(False)
            self.mFieldComboBox_1.setCurrentIndex(0)
            self.mFieldComboBox_2.setCurrentIndex(0)
            self.mFieldComboBox.setCurrentIndex(0)
            self.mFieldComboBox_1.setEnabled(False)
            self.mFieldComboBox_2.setEnabled(False)  
            self.mFieldComboBox.setEnabled(False)
            self.comboBox_2.setCurrentIndex(-1)
            self.comboBox_2.setEnabled(False)
            self.comboBox.setCurrentIndex(-1)
            self.comboBox.setEnabled(False)
            self.lineEdit.setText('')
            self.lineEdit.setEnabled(False)
            self.mQgsProjectionSelectionWidget.setCrs(crsNone)
            self.mQgsProjectionSelectionWidget.setEnabled(False)
        else:
            self.label.setText('')
            self.mFieldComboBox_1.setEnabled(True)
            self.mFieldComboBox_2.setEnabled(True)  
            self.mFieldComboBox.setEnabled(True)
            self.mQgsProjectionSelectionWidget.setEnabled(True)
            layer = self.mMapLayerComboBox.currentLayer()
            if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                self.mQgsProjectionSelectionWidget.setCrs(layer.crs())
            
    def LayerChange(self):
        layer = self.mMapLayerComboBox.currentLayer()
        # print(layer.type())
        # print(layer.geometryType())
        # print(layer .wkbType())
        # print(QgsWkbTypes.displayString(layer .wkbType()))
        if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
            
            if layer.selectedFeatureCount() > 0:
                self.checkBox.setEnabled(True)
                self.checkBox.setChecked(True)
            else:
                self.checkBox.setChecked(False)
                self.checkBox.setEnabled(False)
            for i in range(0,18):
                self.findChild(QCheckBox,'checkBox_'+str(i)).setEnabled(True)
                self.chkBox=1
                self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(False)
                self.chkBox=0
            self.mQgsProjectionSelectionWidget.setCrs(layer.crs())
            self.mFieldComboBox.setLayer(layer)
            self.mFieldComboBox.setAllowEmptyFieldName(True)
            self.mFieldComboBox_1.setLayer(layer)
            self.mFieldComboBox_1.setAllowEmptyFieldName(True)
            self.mFieldComboBox_2.setLayer(layer)
            self.mFieldComboBox_2.setAllowEmptyFieldName(True)
            self.mFieldComboBox_1.setCurrentIndex(0)
            self.mFieldComboBox_2.setCurrentIndex(0)
            self.mFieldComboBox.setCurrentIndex(0)
            self.toolButton_1.setEnabled(True)
            self.toolButton_2.setEnabled(True)
            self.toolButton_3.setEnabled(True)
            self.checkBox_24.setEnabled(True)
        else:
            for i in range(0,18):
                self.findChild(QCheckBox,'checkBox_'+str(i)).setEnabled(False)
                self.chkBox=1
                self.findChild(QCheckBox,'checkBox_'+str(i)).setChecked(False)
                self.chkBox=0
                self.findChild(QComboBox,'FieldComboBox_'+str(i)).setEnabled(False)
            self.checkBox.setEnabled(False)
            self.checkBox.setChecked(False)
            self.checkBox_24.setChecked(False)
            self.checkBox_24.setEnabled(False)
            self.mQgsProjectionSelectionWidget.setCrs(crsNone)
            self.mFieldComboBox.setLayer(None)
            self.mFieldComboBox_1.setLayer(None)
            self.mFieldComboBox_2.setLayer(None)
            self.toolButton_1.setEnabled(False)
            self.toolButton_2.setEnabled(False)
            self.toolButton_3.setEnabled(False)
        self.label.setText('')

    def FieldChange2(self):
        if self.mFieldComboBox.currentIndex()==0:
            self.FieldChange1()
        else:
            self.mFieldComboBox_1.setCurrentIndex(0)
            self.mFieldComboBox_2.setCurrentIndex(0)
            self.checkBox_21.setEnabled(True)
            self.checkBox_22.setEnabled(True)
            self.checkBox_23.setEnabled(True)
            if self.checkBox_22.isChecked() or  self.checkBox_23.isChecked():
                pass
            else:
                self.comboBox_2.setCurrentIndex(0)
                self.comboBox_2.setEnabled(True)
                self.comboBox.setCurrentIndex(0)
                self.comboBox.setEnabled(True)
                self.lineEdit.setText('')
                self.label.setText('')
        
    def FieldChange1(self):
        self.checkBox_21.setChecked(False)
        self.checkBox_21.setEnabled(False)
        self.checkBox_22.setChecked(False)
        self.checkBox_22.setEnabled(False)
        self.checkBox_23.setChecked(False)
        self.checkBox_23.setEnabled(False)
        self.mFieldComboBox.setCurrentIndex(0)
        self.comboBox_2.setCurrentIndex(-1)
        self.comboBox_2.setEnabled(False)
        self.comboBox.setCurrentIndex(-1)
        self.comboBox.setEnabled(False)
        self.lineEdit.setText('')
        self.lineEdit.setEnabled(False)
        self.label.setText('')
        
    def SepChange(self):
        if self.comboBox.currentIndex() == 6:
            self.lineEdit.setEnabled(True)
            self.lineEdit.setText('')
            self.lineEdit.setFocus()
        else:
            self.lineEdit.setText('')
            self.lineEdit.setEnabled(False)
        self.label.setText('')
    
    def getExpression(self, op):
        try:
            # 표현식 리스트 초기화
            expression=[]
            # 입력값이 Mapid라면 필드명을 표현식에 입력
            if self.chk==1:
                
                xy = self.mFieldComboBox.currentText()
                # 표현식 작성
                expr = f'"{xy}"'
            
            # 입력값이 xy가 합쳐진 값이라면 X, Y 값을 분리하는 표현식으로 적용 ( string_to_array("필드명",',')[0]  /  string_to_array("필드명",',')[1] )
            # bessel(make_point(string_to_array("LONLAT",',')[0] , string_to_array("LONLAT",',')[1] ),'USER:100000')   
            elif self.chk == 3:
                # 필드명 xy 값으로 입력
                xy = self.mFieldComboBox.currentText()
                # 입력된 좌표계 addCrs 값으로 입력
                addCrs = self.mQgsProjectionSelectionWidget.crs().authid()
                
                # 입력값이 MMS 좌표값이라면
                if self.checkBox_21.isChecked():
                    # 표현식 작성
                    expr = f'make_point( replace( string_to_array( "{xy}" )[0],'
                    expr =  expr + "'(',''),"
                    expr =  expr + f'replace( string_to_array( "{xy}")[1],'
                    expr =  expr + "')','')),"
                    expr =  expr + f"'{addCrs}'" 
    
                # 입력값이 FS 좌표값이라면
                elif self.checkBox_22.isChecked():
                    # 표현식 작성
                    expr = f'make_point( string_to_array(Fs2LonLat("{xy}"))[0],'
                    expr =  expr + f'string_to_array(Fs2LonLat("{xy}"))[1]),'
                    expr =  expr + f"'{addCrs}'"
                    
                # 아니라면
                else:
                    # 입력된 좌표값의 정역 확인
                    v = [0,1] if self.comboBox_2.currentIndex() == 0 else [1,0]
                    # 입력된 좌표값의 구분자 확인
                    spltxt=str(self.comboBox.currentText()[:1]) if self.comboBox.currentIndex() != 6 else str(self.lineEdit.text())
                    # 표현식 작성
                    expr = f'make_point( string_to_array("{xy}",'
                    expr =  expr + f"'{spltxt}')[{v[0]}],"
                    expr =  expr + f'string_to_array("{xy}",'
                    expr =  expr + f"'{spltxt}')[{v[1]}]),"
                    expr =  expr + f"'{addCrs}'" 
                    
            # 좌표가 X Y 필드 각각 존재한다면
            # bessel(make_point( "LON" , "LAT" ),'USER:100000')
            elif self.chk == 4:
                # 필드명 x y 값으로 각각입력
                x = self.mFieldComboBox_1.currentText()
                y = self.mFieldComboBox_2.currentText()
                
                addCrs = self.mQgsProjectionSelectionWidget.crs().authid()
                
                expr = f'make_point( "{x}",'
                expr =  expr + f'"{y}" ),'
                expr =  expr + f"'{addCrs}'"
                
            if self.chk == 2:
                if 0 in op :
                    expression.append(' Bessel ( $geometry ) ')
                if 1 in op :
                    expression.append(" '(' + BesLonLat ( $geometry ) + ')' ")
                if 2 in op :
                    expression.append(" BesLon ( $geometry ) ")
                if 3 in op :
                    expression.append(" BesLat ( $geometry ) ")
                if 4 in op :
                    expression.append(" Wgs ( $geometry ) ")
                if 5 in op :
                    expression.append(" '(' + WgsLonLat ( $geometry ) + ')' ")
                if 6 in op :
                    expression.append(" WgsLon ( $geometry ) ")
                if 7 in op :
                    expression.append(" WgsLat ( $geometry ) ")
                if 8 in op :
                    expression.append(" MapID ( $geometry ) ")
                if 9 in op :
                    expression.append(" MapID8Lv ( $geometry ) ")
                if 10 in op :
                    expression.append(" 협력사 ( $geometry ) ")
                if 11 in op :
                    expression.append(" 담당 ( $geometry ) ")
                if 12 in op :
                    expression.append(" 대권역 ( $geometry ) ")
                if 13 in op :
                    expression.append(" 소권역 ( $geometry ) ")
                if 14 in op:
                    expression.append(" 'http://map.naver.com/v5/?c=' + to_string(Wgs84Lon ( $geometry )) + ',' + to_string(Wgs84Lat ( $geometry )) + ',17,0,0,0,dh' ")
                if 15 in op:
                    expression.append(" 'https://map.kakao.com/link/map/' + to_string(Wgs84Lat ( $geometry )) + ',' + to_string(Wgs84Lon ( $geometry )) ")
                if 16 in op:
                    expression.append(" 'https://map.kakao.com/link/ROADVIEW/' + to_string(Wgs84Lat ( $geometry )) + ',' + to_string(Wgs84Lon ( $geometry )) ")
                if 17 in op:
                    expression.append(" Wgs84Lat ( $geometry )  ||  ','  ||  Wgs84Lon ( $geometry ) ")
            else:
                if 0 in op :
                    expression.append(f' Bessel ( {expr} ) ')
                if 1 in op :
                    expression.append(f" '(' + BesLonLat ( {expr} ) + ')' ")
                if 2 in op :
                    expression.append(f" BesLon ( {expr} ) ")
                if 3 in op :
                    expression.append(f" BesLat ( {expr} ) ")
                if 4 in op :
                    expression.append(f" Wgs ( {expr} ) ")
                if 5 in op :
                    expression.append(f" '(' + WgsLonLat ( {expr} ) + ')' " )
                if 6 in op :
                    expression.append(f" WgsLon ( {expr} ) ")
                if 7 in op :
                    expression.append(f" WgsLat ( {expr} ) " )
                if 8 in op :
                    expression.append(f" MapID ( {expr} ) " )
                if 9 in op :
                    expression.append(f" MapID8Lv ( {expr} ) " )
                if 10 in op :
                    expression.append(f" 협력사 ( {expr} ) ")
                if 11 in op :
                    expression.append(f" 담당 ( {expr} ) ")
                if 12 in op :
                    expression.append(f" 대권역 ( {expr} ) ")
                if 13 in op :
                    expression.append(f" 소권역 ( {expr} ) ")
                if 14 in op:
                    expression.append(f" 'http://map.naver.com/v5/?c=' + to_string(Wgs84Lon ( {expr} )) + ',' + to_string(Wgs84Lat ( {expr} )) + ',17,0,0,0,dh' ")
                if 15 in op:
                    expression.append(f" 'https://map.kakao.com/link/map/' + to_string(Wgs84Lat ( {expr} )) + ',' + to_string(Wgs84Lon ( {expr} )) " )
                if 16 in op:
                    expression.append(f" 'https://map.kakao.com/link/ROADVIEW/' + to_string(Wgs84Lat ( {expr} )) + ',' + to_string(Wgs84Lon ( {expr} )) " )
                if 17 in op:
                    expression.append(f" Wgs84Lat ( {expr} )  ||  ','  ||  Wgs84Lon ( {expr} ) " )

            return expression
    
        except Exception as e:
            print("getExpression Error : ", e)
            return None

    def startset(self):
        self.time_start = time.perf_counter()
        self.label.setText('')
        self.worker_stopped = False

    def reportProgress(self, value, txt):
        self.progressBar.setValue(value)
        self.label.setText(txt)

    def run(self):
        self.canvas.refresh()
        layer = self.mMapLayerComboBox.currentLayer()
        try:
            self.pushButton_2.setText('취소')
            self.pushButton_2.clicked.disconnect()
            self.pushButton_2.clicked.connect(self.cancelRun)

            self.startset()
            self.progressBar.setValue(0)
            self.progressBar.setTextVisible(True)

            if layer.type() != QgsMapLayerType.VectorLayer or not layer.isValid():
                self.cancelRun()
                return

            layer.beginEditCommand("Feature Start Editing")
            layer.undoStack().beginMacro('좌표변환기')

            addfields=[]
            addfieldsNum=[]
            # 변환 옵션 순환문
            if self.checkBox_23.isChecked():
                self.chk=1
                for i in range(10,14):
                    if self.findChild(QCheckBox,'checkBox_'+str(i)).isChecked():
                        na = self.findChild(QComboBox,'FieldComboBox_'+str(i)).currentText()
                        addfields.append(na)
                        addfieldsNum.append(i)
            else:
                
                if self.checkBox_24.isChecked():
                    # 객체 속성으로 변환
                    self.chk=2
                elif self.mFieldComboBox.currentIndex() != 0:
                    self.chk=3
                elif self.mFieldComboBox_1.currentIndex() != 0 or self.mFieldComboBox_2.currentIndex() != 0:
                    self.chk=4
                else:
                    self.cancelRun()
                    return
                
                for i in range(0,18):
                    if self.findChild(QCheckBox,'checkBox_'+str(i)).isChecked():
                        na = self.findChild(QComboBox,'FieldComboBox_'+str(i)).currentText()
                        addfields.append(na)
                        addfieldsNum.append(i)

            if not addfields:
                QMessageBox.warning(self.iface.mainWindow(), "Error", '변환옵션 확인')
                self.cancelRun()
                return
            
            layer.startEditing()
            for vf in addfields:
                if layer.fields().indexOf(vf) < 0:
                    if layer.providerType() == "postgres":
                        field = QgsField(vf, QVariant.String, "varchar", 255)
                    else:
                        field = QgsField(vf, QVariant.String)

                    layer.addAttribute(field)
                    layer.updateFields()

            layer.commitChanges()
            layer.startEditing()

            # 변환옵션에 맞춰 표현식 작성
            expression = self.getExpression(addfieldsNum)
            use_checkBox = self.checkBox.isChecked()

            self.thread = QThread()
            self.worker = Worker(layer, expression, addfields, use_checkBox)
            self.worker.moveToThread(self.thread)

            self.thread.started.connect(self.worker.run)
            self.worker.finished.connect(self.thread.quit)
            self.worker.finished.connect(self.worker.deleteLater)
            self.thread.finished.connect(self.thread.deleteLater)
            self.worker.progress.connect(self.reportProgress)
            self.worker.stopped.connect(self.onThreadStopped)
            self.thread.start()
            self.thread.finished.connect(self.onThreadFinished)
            self.pushButton.setEnabled(False)
            self.thread.finished.connect(lambda: self.pushButton.setEnabled(True))

        except Exception as e:
            print(f"Error: {e}")
            self.cancelRun()
            layer.rollBack()

    def onThreadFinished(self):
        if not self.worker_stopped:
            QMessageBox.information(self, "작업 완료", "작업이 완료되었습니다.")
        self.worker_stopped = False
        self.mMapLayerComboBox.currentLayer().triggerRepaint()

        # 툴바 '새로고침' 버튼 강제 클릭
        try:
            self.iface.actionRefresh().trigger()
        except Exception:
            pass

        # 캔버스 전 레이어 재렌더링
        self.iface.mapCanvas().refreshAllLayers()
        self.iface.mapCanvas().refresh()    
        self.colse_set()

    def cancelRun(self):
        self.worker_stopped = True
        self.colse_set()
        try:
            if hasattr(self, 'worker') and hasattr(self, 'thread') and self.thread.isRunning():
                self.worker.stop()
                self.thread.quit()
                self.thread.wait()
                QMessageBox.information(self, "작업 취소", "작업이 취소되었습니다.")
                self.onThreadStopped()
                if self.mMapLayerComboBox.currentLayer().isEditable():
                    self.mMapLayerComboBox.currentLayer().rollBack()
        except:
            pass

    def onThreadStopped(self):
        self.progressBar.setValue(0)
        self.label.setText('작업이 취소되었습니다')
        self.pushButton.setEnabled(True)
        self.colse_set()

    def colse_set(self):
        self.pushButton_2.setText('닫기')
        self.pushButton_2.clicked.disconnect()
        self.pushButton_2.clicked.connect(self.close)