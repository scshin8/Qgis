# -*- coding: utf-8 -*-
import time
from qgis.core import (
    QgsCoordinateTransform,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsMarkerSymbol,
    QgsTextAnnotation
)
from qgis.gui import QgsMapCanvasAnnotationItem
from qgis.PyQt.QtCore import QSettings, QPointF, QSizeF
from qgis.PyQt.QtGui import QColor, QFont, QTextDocument


class CoordinateToolVertex:
    def __init__(self, main_tool, iface):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.MarkerSymbol = []
        self.vertex_run_chk = False
        self.time_start = 0

    def vertex_run(self, *args):
        if self.main.vertex.isChecked():
            self.canvas.selectionChanged.connect(self.vertexdisplay)
            self.vertex_run_chk = True
            self.vertexdisplay()
        else:
            try:
                self.canvas.selectionChanged.disconnect(self.vertexdisplay)
            except Exception:
                pass
            self.remove_Marker()
            self.vertex_run_chk = False

    def vertexdisplay(self, *args):
        self.time_start = time.perf_counter()
        if not self.vertex_run_chk:
            self.remove_Marker()
            return

        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            return

        featuresCount = layer.selectedFeatureCount()
        # 선택 객체가 1개 이상 20개 이하일 때만 보간점 표시
        if 1 <= featuresCount <= 20:
            selected_features = layer.selectedFeatures()
            self.remove_Marker()
            selected_objects = []

            canvasCRS = self.canvas.mapSettings().destinationCrs()
            layer_crs = layer.crs()
            transform = QgsCoordinateTransform(layer_crs, canvasCRS, QgsProject.instance())

            size = int(self.QSettings.value('spinBox', 10))
            txt_color = QColor(self.QSettings.value('markerColorButton_5', '#ff0000')).name()
            back_color = QColor(self.QSettings.value('markerColorButton_6', '#ff0000')).name()
            has_bg = int(self.QSettings.value('background_checkBox', 0)) != 0
            bg_style = f"background-color: {back_color};" if has_bg else ""

            marker_size = "0" if layer.isEditable() else "0.6"
            marker_symbol = QgsMarkerSymbol.createSimple({
                "name": "rectangle",
                "color": "red",
                "outline_style": "no",
                "size": marker_size
            })

            fontDefault = QFont('맑은 고딕')
            fontDefault.setBold(True)

            for feature in selected_features:
                geometry = feature.geometry()
                if not geometry or geometry.isEmpty():
                    continue

                wkbType = geometry.wkbType()
                if wkbType in (QgsWkbTypes.Point, QgsWkbTypes.PointZM,
                               QgsWkbTypes.MultiPoint, QgsWkbTypes.MultiPointZM):
                    continue

                if wkbType in (QgsWkbTypes.LineString, QgsWkbTypes.LineStringZM):
                    vertexs = geometry.asPolyline()
                elif wkbType in (QgsWkbTypes.MultiLineString, QgsWkbTypes.MultiLineStringZM):
                    multi_lines = geometry.asMultiPolyline()
                    vertexs = [vertex for lines in multi_lines for vertex in lines]
                elif wkbType in (QgsWkbTypes.Polygon, QgsWkbTypes.PolygonZM):
                    rings = geometry.asPolygon()
                    vertexs = [vertex for ring in rings for vertex in ring[:-1]]
                elif wkbType in (QgsWkbTypes.MultiPolygon, QgsWkbTypes.MultiPolygonZM):
                    multi_Polygons = geometry.asMultiPolygon()
                    vertexs = [vertex for Polygons in multi_Polygons for Polygon in Polygons for vertex in Polygon[:-1]]
                else:
                    vertexs = []

                for i, vertex in enumerate(vertexs):
                    txtProjectPoint = transform.transform(vertex.x(), vertex.y())
                    selected_objects.append([txtProjectPoint, i])

            text_annotations = []
            for Vertex, idx in selected_objects:
                html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{idx}</span>'
                text_document = QTextDocument()
                text_document.setHtml(html_text)
                text_document.setDefaultFont(fontDefault)

                text_annotation = QgsTextAnnotation(self.canvas)
                text_annotation.setDocument(text_document)

                text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0, 0))
                text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0, 0))

                text_annotation.setMapPosition(Vertex)

                # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                if layer.isEditable():
                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                else:
                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(-(text_document.size().width()), - (text_document.size().height())))

                text_annotation.setMarkerSymbol(marker_symbol)
                text_annotation.setFrameSize(QSizeF(text_document.size().width()+1, text_document.size().height()))  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                text_annotations.append(text_annotation)

            annotation_items = [QgsMapCanvasAnnotationItem(ta, self.canvas) for ta in text_annotations]
            self.MarkerSymbol.extend(annotation_items)
            self.canvas.refresh()
        else:
            self.remove_Marker()

    def remove_Marker(self, *args):
        if len(self.MarkerSymbol) > 0:
            for mark in self.MarkerSymbol:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol = []
        self.canvas.refresh()