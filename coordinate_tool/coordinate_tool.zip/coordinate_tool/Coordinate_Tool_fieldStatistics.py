# -*- coding: utf-8 -*-
from qgis.PyQt import QtWidgets
from qgis.PyQt.uic import loadUiType
from qgis.core import ( QgsProject,
                        QgsProcessingFeatureSourceDefinition,
                        QgsMapLayerType, 
                        Qgis, 
                        QgsWkbTypes, 
                        QgsExpression, 
                        QgsAggregateCalculator, 
                        QgsCategorizedSymbolRenderer,
                        QgsCoordinateTransform,
                        QgsRendererCategory,
                        QgsSymbol,
                        QgsFeatureRequest,
                        QgsRectangle,
                        QgsSingleSymbolRenderer,
                        QgsExpressionContext,
                        QgsRuleBasedRenderer,
                        QgsPointXY,
                        QgsVectorLayer,
                        QgsField,
                        QgsFeature,
                        QgsGeometry,
                        QgsExpressionContextUtils)
from PyQt5.QtCore import (QSettings,
                          Qt)
from PyQt5 import QtCore

from qgis.PyQt.QtCore import QVariant

from PyQt5.QtWidgets import (QApplication,
                             QPushButton, 
                             QComboBox,
                             QTableWidgetItem, 
                             QLineEdit)

from PyQt5.QtGui import (QKeySequence, 
                         QTextDocument, 
                         QColor, 
                         QIcon)

import os, shutil, processing, glob, random

# 코드 → 함수명 매핑
# agg_map = {
#     0: "Count", 1: "CountDistinct", 2: "CountNulls",
#     3: "Min", 4: "Max", 5: "Sum", 6: "Mean", 7: "Median",
#     8: "StDev", 9: "StDevSample", 10: "Range",
#     11: "Minority", 12: "Majority", 13: "FirstQuartile",
#     14: "ThirdQuartile", 15: "InterQuartileRange",
#     16: "StringMinLength", 17: "StringMaxLength",
#     18: "StringConcatenate", 19: "GeometryCollect",
#     20: "ArrayAggregate", 21: "StringConcatUnique",
#     22: "StringAvgLength"
# }

VERSION = Qgis.QGIS_VERSION_INT

# 코드 → 함수명 매핑
agg_map = {
    0: "Count", 5: "Sum"
}

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_fieldStatistics.ui'))

class fieldStatisticsDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(fieldStatisticsDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chk = False

        self.layerListComboBox.layerChanged.connect(self.LayerChange)
        self.layerListComboBox.setAllowEmptyLayer(True)
        self.layerListComboBox.setCurrentIndex(0)

        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.toggle)

        self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/copy.png"))
        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/selection.png"))
        self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/palette.png"))

        self.model = self.mComboBox.model()

        self.remove()
        
        self.chk = True

    def toggle(self):
        if self.chk:
            # 현재 레이어층 가져오기
            layer = self.layerListComboBox.currentLayer()
            
            if layer and layer.type() == layer.VectorLayer:
                try:
                    layer.editingStarted.disconnect(self.toggle)
                except TypeError:
                    # 이미 해제됨
                    pass
                try:
                    layer.editingStopped.disconnect(self.toggle)
                except TypeError:
                    # 이미 해제됨
                    pass
                
                if layer.selectedFeatureCount() > 0:
                    self.checkBox.setEnabled(True)
                    self.checkBox.setChecked(True)
                else:
                    self.checkBox.setChecked(False)
                    self.checkBox.setEnabled(False)
                layer.editingStopped.connect(self.toggle)

            else:
                self.checkBox.setChecked(False)
                self.checkBox.setEnabled(False)
        else:
            self.chk = True

    def remove_tableWidget(self):
        self.tableWidget.setColumnCount(3)
        table_column=["" , "count" , "sum"]
        self.tableWidget.setHorizontalHeaderLabels(table_column)
        self.tableWidget.setRowCount(0)
        self.tableWidget.resizeColumnsToContents()
        self.toolButton_2.setEnabled(False)
        self.toolButton_3.setEnabled(False)
        self.toolButton_4.setEnabled(False)

    def remove(self):
        self.chk = False
        self.remove_tableWidget()
        self.layerListComboBox.setCurrentIndex(0)
        self.mComboBox.clear()
        self.mFieldComboBox_2.setLayer(None)
        self.chk = True

    def format_number(self, num):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)
    
    def detect_rounding_place(self, num):
        if num:
            str_num = f"{num:.16f}"  # 충분한 자리수 확보
            decimals = str_num.split(".")[1]
            if '99999' in decimals:
                idx = decimals.find('99999')
                # 연속되는 9 앞자리까지가 정확한 자리
                return round( num, idx)
            elif '00000' in decimals:
                idx = decimals.find('00000')
                if idx == 0:
                    return int(num)
                else:  
                    return round( num, idx)
        return num
    
    def hideEvent(self, event):
        # try:
        #     self.layerListComboBox.layerChanged.disconnect(self.LayerChange)
        #     print('selectionChanged 시그널이 정상적으로 해제되었습니다.')
        # except TypeError:
        #     # 이미 disconnect되었거나 연결되지 않았을 때 예외 처리
        #     print('selectionChanged 시그널이 이미 해제되었습니다.')
        super().hideEvent(event)

    # 위젯이 다시 표시될 때 연결을 재설정하려면 showEvent도 정의할 수 있습니다.
    def showEvent(self, event):
        # try:
        #     self.layerListComboBox.layerChanged.connect(self.LayerChange)
        #     self.layerListComboBox.setCurrentIndex(0)
        #     print('selectionChanged 시그널이 정상적으로 연결되었습니다.')
        # except TypeError:
        #     print('selectionChanged 시그널이 이미 연결되었습니다.')

        # self.tableWidget.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        # self.tableWidget.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)

        # self.tableWidget.setDragEnabled(True)
        # self.tableWidget.setAcceptDrops(True)
        # self.tableWidget.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        super().showEvent(event)

    def LayerChange(self):
        if self.chk:
            try:
                self.model.itemChanged.disconnect(self.onItemChanged)
                self.pushButton.clicked.disconnect(self.run)
                self.toolButton.clicked.disconnect(self.remove)
                self.toolButton_2.clicked.disconnect(self.copyTableToClipboard)
                self.toolButton_3.clicked.disconnect(self.selectFeaturesFromTable)
                self.toolButton_4.clicked.disconnect(self.applyCombinedCategorizedSymbology)
                self.tableWidget.itemSelectionChanged.disconnect(self.onSelectionChanged)
                self.tableWidget.itemDoubleClicked.disconnect(self.selectFeaturesFromTable)
            except:
                pass

            self.checked_fields = []
            self.layer = self.layerListComboBox.currentLayer()
            if self.layerListComboBox.currentIndex() > 0:
                self.mComboBox.clear()
                for fld in self.layer.fields():
                    self.mComboBox.addItem(fld.name())

                self.model.itemChanged.connect(self.onItemChanged)
                self.pushButton.clicked.connect(self.run)
                self.toolButton.clicked.connect(self.remove)
                self.toolButton_2.clicked.connect(self.copyTableToClipboard)
                self.toolButton_3.clicked.connect(self.selectFeaturesFromTable)
                self.toolButton_4.clicked.connect(self.applyCombinedCategorizedSymbology)
                self.tableWidget.itemSelectionChanged.connect(self.onSelectionChanged)
                self.tableWidget.itemDoubleClicked.connect(self.selectFeaturesFromTable)

                self.mFieldComboBox_2.setLayer(self.layer)
                self.mFieldComboBox_2.setAllowEmptyFieldName(True)
                self.mFieldComboBox_2.setCurrentIndex(0)
            else:
                self.mFieldComboBox_2.setLayer(None)
                self.mComboBox.clear()   
            self.column_count = 0
            self.remove_tableWidget()
            self.toggle()

    def onSelectionChanged(self):
        selected_items = self.tableWidget.selectedItems()
        total = 0
        count = 0

        for item in selected_items:
            text = item.text()
            try:
                value = float(text)
                total += value
                count += 1
            except ValueError:
                count += 1
                continue
        total = self.format_number(round(total,4))
        if count > 0:
            self.iface.statusBarIface().showMessage(f"선택한 {count}개의 숫자 합계: {total}")
            self.lineEdit.setText(f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}")
            self.toolButton_3.setEnabled(True)
        else:
            self.lineEdit.setText(f"")
            self.toolButton_3.setEnabled(False)


    def onItemChanged(self, item):
        field = item.text()
        if item.checkState() == Qt.Checked:
            # 새로 체크된 필드는 리스트 뒤에 추가
            if field not in self.checked_fields:
                self.checked_fields.append(field)
        else:
            # 해제된 필드는 리스트에서 제거
            if field in self.checked_fields:
                self.checked_fields.remove(field)

        # if len(self.checked_fields)==1:
        #     self.fields = f"'{self.checked_fields[0]}'"
        # else:
        #     self.fields = self.checked_fields

        self.checked_fields  = [f for f in self.checked_fields]

        self.table_column    = self.checked_fields + ["count" , "sum"]
        self.column_count = len(self.table_column)
        # self.tableWidget.setColumnCount(self.column_count)
        # self.tableWidget.setHorizontalHeaderLabels(self.table_column)

        # parts = [f'"{f}"' for f in self.checked_fields]
        # expr = " || '_' || ".join(parts) if parts else ""

        # self.unique_values = sorted(list(self.layer.uniqueValues(self.layer.fields().indexFromName(expr))))
        # print(self.unique_values)

        # for i, value in enumerate(self.unique_values):
        #     self.tableWidget.setItem(i, 0, QTableWidgetItem(str(value))) 

        # self.tableWidget.setRowCount(len(self.unique_values))

        # self.tableWidget.setAlternatingRowColors(True)
        # for i in range(0,self.column_count):
        #     self.tableWidget.resizeColumnToContents(i)

    def run(self):
        self.tableWidget.setSortingEnabled(False)
        self.chk = False
        features = None
        stats_layer = None
        self.remove_tableWidget()
        self.tableWidget.clear()               # 셀 내용 + 헤더 모두 지움
        # self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)        # 행 0개
        if self.column_count == 0:
            return
        self.tableWidget.setColumnCount(self.column_count)
        self.tableWidget.setHorizontalHeaderLabels(self.table_column)

        if self.checkBox.isChecked():
            # 선택된 객체만 처리하기 위한 입력 정의
            input_layer = QgsProcessingFeatureSourceDefinition(
                self.layer.source(),
                selectedFeaturesOnly=True
            )
        else:
            input_layer = self.layer

        is_numeric = False
        self.Field_txt2 = ''
        if self.mFieldComboBox_2.currentIndex() > 0:
            # 클리어 추가 필요
            self.Field_txt2 = self.mFieldComboBox_2.currentText()
            field_type = self.layer.fields().field(self.Field_txt2).type()
            is_numeric = field_type in (QVariant.Int, QVariant.LongLong, QVariant.Double)
            # is_string  = field_type == QVariant.String

        alg_params = {
            'CATEGORIES_FIELD_NAME': self.checked_fields,
            'INPUT': input_layer,
            'VALUES_FIELD_NAME': self.Field_txt2,
            'OUTPUT': 'memory:'
        }
        outputs = processing.run('qgis:statisticsbycategories', alg_params)
        stats_layer = outputs['OUTPUT']
        stats_layer.setName(f"범주 별 통계")
        if self.checkBox_2.isChecked():
            QgsProject.instance().addMapLayer(stats_layer)

        # 결과 피처에서 값 추출
        features = stats_layer.getFeatures()

        for i, f in enumerate(features):

            count = f['COUNT']
            if is_numeric:
                sum_val = f['SUM']
                # sum_val = self.detect_rounding_place(sum_val)
                # sum_val = self.format_number(sum_val)
            else:
                sum_val = ''

            self.tableWidget.insertRow(i)

            for idx, name in enumerate(self.checked_fields):
                value = f[name]

                if isinstance(value, (int, float)):
                    item = QTableWidgetItem()
                    item.setData(QtCore.Qt.UserRole, value)          # 내부에 float/int 데이터 보관
                    item.setData(QtCore.Qt.DisplayRole, value)
                else:
                    item = QTableWidgetItem(str(value))

                self.tableWidget.setItem(i, idx, item)

            item = QTableWidgetItem()
            item.setData(QtCore.Qt.DisplayRole, count)
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.tableWidget.setItem(i, idx + 1, item)

            item = QTableWidgetItem()
            item.setData(QtCore.Qt.DisplayRole, sum_val)
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.tableWidget.setItem(i, idx + 2, item)

        self.tableWidget.setAlternatingRowColors(True)
        for i in range(0,self.column_count):
            self.tableWidget.resizeColumnToContents(i)

        self.chk = True

        self.toolButton_2.setEnabled(True)
        self.toolButton_4.setEnabled(True)

        self.lineEdit.setText(f"범주 별 통계 완료")
        self.tableWidget.setSortingEnabled(True)
            # results = {}
            # for value in self.unique_values:
            #     if value == 'Null' or value == None or value == '':
            #         continue

            #     fids = [f.id() for f in self.layer.getFeatures() if f[self.Field_txt1 ] == value]
            #     calc = QgsAggregateCalculator(self.layer)
            #     calc.setFidsFilter(fids)

            #     for code, name in agg_map.items():
            #         if VERSION >= 34000:
            #             agg_enum = getattr(Qgis.Aggregate, name)
            #         else:
            #             agg_enum = code

            #         # 타입 체크: 숫자형 전용 연산인 경우
            #         if code in (5,6,7,8,9,13,14,15) and not is_numeric:
            #             continue

            #         # 문자열 전용 연산인 경우
            #         if code in (16,17,18,21,22) and not is_string:
            #             continue

            #         # 지오메트리 전용 연산(예: code==19) 등 필요시 추가 체크…

            #         # 실제 계산
            #         results.setdefault(value, {})
            #         results[value][name] = calc.calculate(agg_enum, Field_txt2)[0]
            #    # 예시 출력
            # for i, (value, stats) in enumerate(results.items()):
            #     print(f"'{value}' : Count = {int(stats.get('Count'))}, Sum = {stats.get('Sum')}")
        
            #     self.tableWidget.setItem(i, 1, QTableWidgetItem(str(int(stats.get('Count'))))) 
            #     self.tableWidget.setItem(i, 2, QTableWidgetItem(str(stats.get('Sum')))) 

    def zoom(self):
        if self.chk:

            selected_features = self.layer.selectedFeatures()
            if selected_features==[]:
                return
            # 선택객체 박스 영역 가져오기
            selection_bbox_project_crs = self.selection_box()
            # bounding box 크기를 10% 확장
            width = selection_bbox_project_crs.width()
            height = selection_bbox_project_crs.height()
            delta_x = width * 0.025  # 5%의 0.025
            delta_y = height * 0.025  # 5%의 0.025
            
            # 새로운 확장된 QgsRectangle 생성
            expanded_bbox = QgsRectangle( selection_bbox_project_crs.xMinimum() - delta_x,
                                        selection_bbox_project_crs.yMinimum() - delta_y,
                                        selection_bbox_project_crs.xMaximum() + delta_x,
                                        selection_bbox_project_crs.yMaximum() + delta_y )

            # 화면을 선택된 객체들의 영역으로 이동 및 확대
            self.canvas.setExtent(expanded_bbox)
            self.canvas.refresh()

    def selection_box(self):
        project_crs = QgsProject.instance().crs()
        # 선택된 객체들의 영역 결정
        selection_bbox = self.layer.boundingBoxOfSelected()
        # 좌표 변환 - 레이어 좌표계에서 현재 프로젝트 좌표계로
        xform = QgsCoordinateTransform(self.layer.crs(), project_crs, QgsProject.instance())
        selection_bbox_project_crs = xform.transformBoundingBox(selection_bbox)
        return selection_bbox_project_crs

    def selectFeaturesFromTable(self):
        # 현재 선택된 행 번호 가져오기
        selected_items = self.tableWidget.selectedItems()
        if not selected_items:
            self.iface.messageBar().pushWarning("알림", "선택된 테이블 행이 없습니다.")
            return

        # 선택된 행 번호 집합 구하기
        selected_rows = set()
        for item in selected_items:
            selected_rows.add(item.row())

        all_fids = set()

        for row in selected_rows:
            conditions = []
            for col, field_name in enumerate(self.checked_fields):
                item = self.tableWidget.item(row, col)
                if not item:
                    continue


                raw = item.data(Qt.UserRole)
                if raw is None:
                    # 문자열 혹은 NULL
                    text = item.text()
                    if text.upper()=="NULL" or text=="":
                        conditions.append(f"\"{field_name}\" IS NULL")
                    else:
                        escaped = text.replace("'", "''")
                        conditions.append(f"\"{field_name}\" = '{escaped}'")
                else:
                    # 숫자 분기
                    conditions.append(f"\"{field_name}\" = {raw}")

                # value = item.text()

                # # NULL 처리
                # if value.upper() == "NULL" or value == "":
                #     print('null',value)
                #     conditions.append(f"\"{field_name}\" IS NULL")
                # # 문자열 처리
                # elif isinstance(value, str):
                #     print('str',value)
                #     value_escaped = value.replace("'", "''")
                #     conditions.append(f"\"{field_name}\" = '{value_escaped}'")
                # else:
                #     print('int',value)
                #     conditions.append(f"\"{field_name}\" = {value}")

            if not conditions:
                continue

            expr_str = " AND ".join(conditions)
            expr = QgsExpression(expr_str)
            request = QgsFeatureRequest(expr)
            # 각 행 조건에 맞는 피처 id 수집
            fids = [f.id() for f in self.layer.getFeatures(request)]
            all_fids.update(fids)

        # 최종 선택
        if all_fids:
            self.layer.selectByIds(list(all_fids))
            self.iface.messageBar().pushInfo("선택 완료", f"{len(all_fids)}개의 피처를 선택했습니다.")
            self.zoom()
        else:
            self.iface.messageBar().pushWarning("선택 결과 없음", "조건에 맞는 피처가 없습니다.")

    def applyCombinedCategorizedSymbology(self):
        # 1) 기본 심볼 생성
        default_sym = QgsSymbol.defaultSymbol(self.layer.geometryType())
        # 2) 싱글 심볼 렌더러 생성
        default_renderer = QgsSingleSymbolRenderer(default_sym)
        self.layer.setRenderer(default_renderer)
        self.layer.triggerRepaint()

        # 1) Expression 조합 문자열
        expr = " || '_' || ".join(f'"{f}"' for f in self.checked_fields)
        
        # 2) 테이블에서 이미 계산해 놓은 조합값(문자열) 리스트 생성
        combos = []
        for row in range(self.tableWidget.rowCount()):
            vals = [ self.tableWidget.item(row, c).text() for c in range(len(self.checked_fields)) ]
            
            # NULL 또는 빈 문자열인 값만 걸러냅니다.
            clean_vals = [v for v in vals if v and v.upper() != 'NULL']

            if len(self.checked_fields) != len(clean_vals) :
                continue
            
            # 남은 값들만 "_" 로 연결
            key = "_".join(clean_vals)
            combos.append(key)
        
        # 3) 카테고리 객체 리스트 만들기
        categories = []

        for key in combos:
            sym = QgsSymbol.defaultSymbol(self.layer.geometryType())
            sym.setColor(QColor(random.randrange(70,220),
                                random.randrange(70,220),
                                random.randrange(70,220)))
            categories.append(QgsRendererCategory(key, sym, key))
        

        # 3) “NULL” (expression 결과가 NULL) 전용 카테고리 추가
        other_sym = QgsSymbol.defaultSymbol(self.layer.geometryType())
        other_sym.setColor(QColor(random.randrange(160,250),
                                random.randrange(160,250),
                                random.randrange(160,250)))
        categories.append(QgsRendererCategory(
            None,            # None 값이면 expression이 NULL인 피처만 매칭
            other_sym,
            'ELSE' # 레전드에 표시될 레이블
        ))

        # 4) Renderer 생성 & 적용
        renderer = QgsCategorizedSymbolRenderer(expr, categories)
        self.layer.setRenderer(renderer)
        self.layer.triggerRepaint()
        self.iface.messageBar().pushInfo("완료", f"{len(categories)}개 조합으로 심볼 적용됨")
        
    def copyTableToClipboard(self):
        row_count = self.tableWidget.rowCount()
        col_count = self.tableWidget.columnCount()

        # 헤더 라인
        headers = []
        for col in range(col_count):
            header_item = self.tableWidget.horizontalHeaderItem(col)
            if header_item:
                headers.append(header_item.text())
            else:
                headers.append(f"Column {col+1}")
        lines = ["\t".join(headers)]

        # 데이터 라인
        for row in range(row_count):
            line = []
            for col in range(col_count):
                item = self.tableWidget.item(row, col)
                if item:
                    line.append(item.text())
                else:
                    line.append("")
            lines.append("\t".join(line))

        # 전체 텍스트 결합
        table_text = "\n".join(lines)

        # 클립보드에 복사
        clipboard = QtWidgets.QApplication.clipboard()
        clipboard.setText(table_text)

        self.lineEdit.setText(f"통계값 복사 완료")