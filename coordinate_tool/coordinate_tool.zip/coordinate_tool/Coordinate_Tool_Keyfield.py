# -*- coding: utf-8 -*-
import os.path
from .Coordinate_Tool_Function import capture,Coordinate_function
from .Coordinate_Tool_decryptKey import AESCipher
from . import Coordinate_Tool_data

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from PyQt5.QtCore import QSettings

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Keyfield.ui'))

class CoordinateToolKeyfield(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolKeyfield, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
