from qgis.PyQt import uic, QtWidgets
from qgis.core import (QgsProject,
                       Qgis,
                       QgsVectorLayer)
from qgis.PyQt.QtCore import (Qt,
                          QSettings,
                          QFileInfo)
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QLineEdit, 
                             QFileDialog, 
                             QToolButton, 
                             QDialogButtonBox)
import os
# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Bookmark.ui'))

class CoordinateToolBookmark(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        
        super(CoordinateToolBookmark, self).__init__(parent,Qt.WindowStaysOnTopHint)
        
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        # self.QSettings = QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        
        self.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.Close)
        
        icon = QIcon(os.path.dirname(__file__) + "/icons/delete.png")
        for i in range(1,9):
            self.findChild(QToolButton,'toolButton_'+str(i)).setIcon(icon)
            
            text=str(self.QSettings.value('Bookmark/lineEdit_'+str(i),''))
            self.findChild(QLineEdit,'lineEdit_'+str(i)).setText(text)
            
            text=str(self.QSettings.value('Bookmark/lineEdit_'+str(i+8),''))
            self.findChild(QLineEdit,'lineEdit_'+str(i+8)).setText(text)
            
        self.pushButton_1.clicked.connect(lambda : self.fileopen1(self.lineEdit_1))
        self.pushButton_2.clicked.connect(lambda : self.fileopen1(self.lineEdit_2))
        self.pushButton_3.clicked.connect(lambda : self.fileopen1(self.lineEdit_3))
        self.pushButton_4.clicked.connect(lambda : self.fileopen1(self.lineEdit_4))
        self.pushButton_5.clicked.connect(lambda : self.fileopen1(self.lineEdit_5))
        self.pushButton_6.clicked.connect(lambda : self.fileopen1(self.lineEdit_6))
        self.pushButton_7.clicked.connect(lambda : self.fileopen1(self.lineEdit_7))
        self.pushButton_8.clicked.connect(lambda : self.fileopen1(self.lineEdit_8))

        self.pushButton_9.clicked.connect(lambda : self.fileset(self.lineEdit_1,self.lineEdit_9))
        self.pushButton_10.clicked.connect(lambda : self.fileset(self.lineEdit_2,self.lineEdit_10))
        self.pushButton_11.clicked.connect(lambda : self.fileset(self.lineEdit_3,self.lineEdit_11))
        self.pushButton_12.clicked.connect(lambda : self.fileset(self.lineEdit_4,self.lineEdit_12))
        self.pushButton_13.clicked.connect(lambda : self.fileset(self.lineEdit_5,self.lineEdit_13))
        self.pushButton_14.clicked.connect(lambda : self.fileset(self.lineEdit_6,self.lineEdit_14))
        self.pushButton_15.clicked.connect(lambda : self.fileset(self.lineEdit_7,self.lineEdit_15))
        self.pushButton_16.clicked.connect(lambda : self.fileset(self.lineEdit_8,self.lineEdit_16))

        self.toolButton_1.clicked.connect(lambda : self.delete(self.lineEdit_1,self.lineEdit_9))
        self.toolButton_2.clicked.connect(lambda : self.delete(self.lineEdit_2,self.lineEdit_10))
        self.toolButton_3.clicked.connect(lambda : self.delete(self.lineEdit_3,self.lineEdit_11))
        self.toolButton_4.clicked.connect(lambda : self.delete(self.lineEdit_4,self.lineEdit_12))
        self.toolButton_5.clicked.connect(lambda : self.delete(self.lineEdit_5,self.lineEdit_13))
        self.toolButton_6.clicked.connect(lambda : self.delete(self.lineEdit_6,self.lineEdit_14))
        self.toolButton_7.clicked.connect(lambda : self.delete(self.lineEdit_7,self.lineEdit_15))
        self.toolButton_8.clicked.connect(lambda : self.delete(self.lineEdit_8,self.lineEdit_16))

    def fileset(self,lineEdit1,lineEdit2):
        file = QFileDialog.getOpenFileName(None, 'Open file','', 'GeoPackage files (*.gpkg);;Shape files (*.shp);;Excel files (*.xls *.xlsx);;All File(*)')[0]
        if file:
            filename = QFileInfo(str(file)).fileName()
            lineEdit1.setText(file)
            lineEdit1.setFocus()
            lineEdit2.setText(filename)
            
            self.QSettings.setValue('Bookmark/'+str(lineEdit1.objectName()), file)
            self.QSettings.setValue('Bookmark/'+str(lineEdit2.objectName()), filename)
        
    def delete(self,lineEdit1,lineEdit2):
        lineEdit1.clear()
        lineEdit2.clear()
        lineEdit1.setFocus()

        self.QSettings.setValue('Bookmark/'+str(lineEdit1.objectName()),'')
        self.QSettings.setValue('Bookmark/'+str(lineEdit2.objectName()),'')
        
    def fileopen1(self,lineEdit1):
        filepath = lineEdit1.text()
        if QFileInfo(filepath).isFile()==True:
           self.fileopen(filepath)
        else:
            self.iface.messageBar().pushMessage("", "파일이 없습니다.", level=Qgis.Warning, duration=4)

    def fileopen(self,filepath):
        # filename = QFileInfo(filepath).fileName()
        filename = QFileInfo(filepath).baseName()
        layer = QgsVectorLayer(filepath, filename, "ogr")

        if not layer.isValid():
            return
        else:
            QgsProject.instance().addMapLayer(layer)

        self.canvas.refresh()

    def getOpenFile(self):
        filepath=self.QSettings.value('filepath', '')
        files = QFileDialog.getOpenFileNames(None, 'Open file',filepath, 'Shapefiles (*.shp);;Excelfiles (*.xls *.xlsx);;All File(*)')[0]
        for file in files:
            filename = QFileInfo(str(file)).fileName()
            filepath = QFileInfo(str(file)).path()
            self.QSettings.setValue('filepath', filepath)
            self.fileopen(file)

    def closeEvent(self, e):
        self.Close()
        
    def Close(self):
        for i in range(1,9):

            file = self.findChild(QLineEdit,'lineEdit_'+str(i)).text()
            self.QSettings.setValue('Bookmark/'+str('lineEdit_'+str(i)), file)
            
            filename = self.findChild(QLineEdit,'lineEdit_'+str(i+8)).text()
            self.QSettings.setValue('Bookmark/'+str('lineEdit_'+str(i+8)), filename)