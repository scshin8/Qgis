from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsProject,
                       Qgis,
                       QgsVectorLayer)

from PyQt5.QtCore import (Qt,
                          QSettings,
                          QFileInfo)

from PyQt5.QtGui import QIcon

from PyQt5.QtWidgets import (QLineEdit, 
                             QFileDialog, 
                             QToolButton, 
                             QDialogButtonBox)

import os

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Bookmark.ui'))

class CoordinateToolBookmark(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        
        super(CoordinateToolBookmark, self).__init__(parent,Qt.WindowStaysOnTopHint)
        
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        # self.QSettings = QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        
        self.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.Close)
        
        icon = QIcon(os.path.dirname(__file__) + "/icons/delete.png")
        for i in range(1,9):
            self.findChild(QToolButton,'toolButton_'+str(i)).setIcon(icon)
            
            text=str(self.QSettings.value('Bookmark/lineEdit_'+str(i),''))
            self.findChild(QLineEdit,'lineEdit_'+str(i)).setText(text)
            
            text=str(self.QSettings.value('Bookmark/lineEdit_'+str(i+8),''))
            self.findChild(QLineEdit,'lineEdit_'+str(i+8)).setText(text)
            
        self.pushButton_1.clicked.connect(lambda : self.fileopen1(self.lineEdit_1))
        self.pushButton_2.clicked.connect(lambda : self.fileopen1(self.lineEdit_2))
        self.pushButton_3.clicked.connect(lambda : self.fileopen1(self.lineEdit_3))
        self.pushButton_4.clicked.connect(lambda : self.fileopen1(self.lineEdit_4))
        self.pushButton_5.clicked.connect(lambda : self.fileopen1(self.lineEdit_5))
        self.pushButton_6.clicked.connect(lambda : self.fileopen1(self.lineEdit_6))
        self.pushButton_7.clicked.connect(lambda : self.fileopen1(self.lineEdit_7))
        self.pushButton_8.clicked.connect(lambda : self.fileopen1(self.lineEdit_8))

        self.pushButton_9.clicked.connect(lambda : self.fileset(self.lineEdit_1,self.lineEdit_9))
        self.pushButton_10.clicked.connect(lambda : self.fileset(self.lineEdit_2,self.lineEdit_10))
        self.pushButton_11.clicked.connect(lambda : self.fileset(self.lineEdit_3,self.lineEdit_11))
        self.pushButton_12.clicked.connect(lambda : self.fileset(self.lineEdit_4,self.lineEdit_12))
        self.pushButton_13.clicked.connect(lambda : self.fileset(self.lineEdit_5,self.lineEdit_13))
        self.pushButton_14.clicked.connect(lambda : self.fileset(self.lineEdit_6,self.lineEdit_14))
        self.pushButton_15.clicked.connect(lambda : self.fileset(self.lineEdit_7,self.lineEdit_15))
        self.pushButton_16.clicked.connect(lambda : self.fileset(self.lineEdit_8,self.lineEdit_16))

        self.toolButton_1.clicked.connect(lambda : self.delete(self.lineEdit_1,self.lineEdit_9))
        self.toolButton_2.clicked.connect(lambda : self.delete(self.lineEdit_2,self.lineEdit_10))
        self.toolButton_3.clicked.connect(lambda : self.delete(self.lineEdit_3,self.lineEdit_11))
        self.toolButton_4.clicked.connect(lambda : self.delete(self.lineEdit_4,self.lineEdit_12))
        self.toolButton_5.clicked.connect(lambda : self.delete(self.lineEdit_5,self.lineEdit_13))
        self.toolButton_6.clicked.connect(lambda : self.delete(self.lineEdit_6,self.lineEdit_14))
        self.toolButton_7.clicked.connect(lambda : self.delete(self.lineEdit_7,self.lineEdit_15))
        self.toolButton_8.clicked.connect(lambda : self.delete(self.lineEdit_8,self.lineEdit_16))

    def fileset(self,lineEdit1,lineEdit2):
        file = QFileDialog.getOpenFileName(None, 'Open file','', 'Shapefiles (*.shp);;Excelfiles (*.xls *.xlsx);;All File(*)')[0]
        filename = QFileInfo(str(file)).fileName()
        lineEdit1.setText(file)
        lineEdit1.setFocus()
        lineEdit2.setText(filename)
        
        self.QSettings.setValue('Bookmark/'+str(lineEdit1.objectName()), file)
        self.QSettings.setValue('Bookmark/'+str(lineEdit2.objectName()), filename)
        
    def delete(self,lineEdit1,lineEdit2):
        lineEdit1.clear()
        lineEdit2.clear()
        lineEdit1.setFocus()

        self.QSettings.setValue('Bookmark/'+str(lineEdit1.objectName()),'')
        self.QSettings.setValue('Bookmark/'+str(lineEdit2.objectName()),'')
        
    def fileopen1(self,lineEdit1):
        filepath = lineEdit1.text()
        if QFileInfo(filepath).isFile()==True:
           self.fileopen(filepath)
        else:
            self.iface.messageBar().pushMessage("", "파일이 없습니다.", level=Qgis.Warning, duration=4)

    def fileopen(self,filepath):
        # filename = QFileInfo(filepath).fileName()
        filename = QFileInfo(filepath).baseName()
        layer = QgsVectorLayer(filepath, filename, "ogr")

        if not layer.isValid():
            return
        else:
            QgsProject.instance().addMapLayer(layer)

        self.canvas.refresh()

    def getOpenFile(self):
        filepath=self.QSettings.value('filepath', '')
        files = QFileDialog.getOpenFileNames(None, 'Open file',filepath, 'Shapefiles (*.shp);;Excelfiles (*.xls *.xlsx);;All File(*)')[0]
        for file in files:
            filename = QFileInfo(str(file)).fileName()
            filepath = QFileInfo(str(file)).path()
            self.QSettings.setValue('filepath', filepath)
            self.fileopen(file)

    def closeEvent(self, e):
        self.Close()
        
    def Close(self):
        for i in range(1,9):

            file = self.findChild(QLineEdit,'lineEdit_'+str(i)).text()
            self.QSettings.setValue('Bookmark/'+str('lineEdit_'+str(i)), file)
            
            filename = self.findChild(QLineEdit,'lineEdit_'+str(i+8)).text()
            self.QSettings.setValue('Bookmark/'+str('lineEdit_'+str(i+8)), filename)
            
    # self.pushButton_9.clicked.connect(self.fileopen2)
    # def fileopen2(self,objectName):
        
    #     filename = QFileDialog.getOpenFileName(self.iface.mainWindow(), 'Open file','', 'Shapefiles (*.shp)')[0]
        # self.fileopen(filename)
        
    # if not self.isLoaded(filename):
    #     print('Layer is not loaded')
    # else:
    #      print('Layer is loaded') 
         
    # def isLoaded(self,filename):
    #     for layer in QgsProject.instance().mapLayers().values():
    #         if layer.source() == filename:
    #             return True
    #     return False
    
    #  QFileDialog 매서드
    #  QFileDialog.getOpenFileName : 파일을 여는 함수
    #  QFileDialog.getSaveFileName : 파일을 Save 하는 함수
    #  QFileDialog.getExistingDirectory : 폴더 주소를 가져오는 함수
    
    # QFileInfo 매서드
    # QFileInfo(file).absolutePath()    파일의 경로 절대 경로를 반환합니다. 여기에는 파일 이름이 포함되지 않습니다.
    # QFileInfo(file).baseName()        경로 없이 파일의 기본 이름을 반환합니다.
    # QFileInfo(file).fileName()        경로 없이 파일의 확장자 포함 이름을 반환합니다.
    # QFileInfo(file).birthTime()       파일이 생성/생성된 날짜와 시간을 반환합니다.
    # QFileInfo(file).isFile()          파일이 있다면 True 없다면 False