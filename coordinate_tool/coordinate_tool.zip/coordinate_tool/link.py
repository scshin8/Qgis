import json
import math
import random
import time
from typing import NamedTuple

from qgis.PyQt.QtCore import (
    QByteArray, QObject, QSettings, QTimer, QUrl, QUrlQuery, pyqtSignal,
)
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsCsException,
    QgsPointXY, QgsProject,
)

PUSH_PATH = "/api/coordinate"
PULL_PATH = "/api/v1/map-center"
SERVER_TOKEN = "MapCompare"
SETTINGS_KEY = "coordinate_tool/mapcompare_sync"
UNIT = 360000
PUSH_TIMEOUT_MS = 800
PULL_TIMEOUT_MS = 28000
DEBOUNCE_MS = 90
RETRY_MAX = 3
RETRY_MS = 250
PULL_MS = 30
PULL_RETRY_MS = 200
PULL_CAP_MS = 4000
MISS_MAX = 6
JITTER_MS = 150
LONGPOLL_S = 20
DEDUPE_S = 0.35
ECHO_S = 0.9
THROTTLE_S = 3.0

# 서버 -> QGIS 수신 시 부드러운 이동(보간) 설정
SMOOTH_ENABLED = True     # False 로 두면 기존처럼 즉시 점프
SMOOTH_FRAME_MS = 15      # 애니메이션 프레임 간격(약 60fps)
SMOOTH_ALPHA = 0.25      # 매 프레임 목표로 다가가는 비율(0~1, 클수록 빠르고 덜 부드러움)
SMOOTH_SNAP_PX = 0.5     # 목표와의 거리가 이 픽셀 이하이면 스냅하고 멈춤


class _Job(NamedTuple):
    seq: int
    payload: bytes
    attempt: int
    forced: bool


class _Cursor(NamedTuple):
    instance: str
    sequence: int


class MapCompareCoordinateLink(QObject):
    failed = pyqtSignal(str)

    def __init__(self, iface, host="127.0.0.1", port=18765):
        super().__init__(iface.mainWindow())
        self._iface = iface
        self._base = "http://%s:%d" % (str(host), int(port))
        self._manager = QNetworkAccessManager(self)
        self._wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        self._pending = None
        self._active = None
        self._stream = None
        self._cursor = _Cursor("", 0)
        self._seq = 0
        self._misses = 0
        self._last = None
        self._last_at = 0.0
        self._echo_until = 0.0
        self._failure_at = 0.0
        self._closed = False
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._drain)
        # 서버 -> QGIS 부드러운 이동용 애니메이션 타이머
        self._anim = QTimer(self)
        self._anim.setInterval(SMOOTH_FRAME_MS)
        self._anim.timeout.connect(self._anim_step)
        self._target = None   # 목표 중심 (QgsPointXY, 캔버스 CRS)
        self.failed.connect(lambda t: self._iface.messageBar().pushWarning("", t))
        QTimer.singleShot(0, self._poll)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._debounce.stop()
        self._anim.stop()
        self._target = None
        self._pending = None
        active, self._active = self._active, None
        stream, self._stream = self._stream, None
        if active is not None:
            active[1].abort()
        if stream is not None:
            stream.abort()

    def submit(self, point, source_crs, *args):
        return self._offer(point, source_crs, False)

    def submit_force(self, point, source_crs, *args):
        return self._offer(point, source_crs, True)

    def _offer(self, point, source_crs, forced):
        if self._closed:
            return False
        if not forced and (not self._send_enabled() or time.monotonic() < self._echo_until):
            return False
        fix = self._fix(point, source_crs)
        if fix is None:
            return False
        now = time.monotonic()
        if not forced and fix == self._last and now - self._last_at <= DEDUPE_S:
            return False
        self._last, self._last_at = fix, now
        self._seq += 1
        payload = json.dumps({"coordinate": "%d %d" % fix},
                             separators=(",", ":")).encode("utf-8")
        self._pending = _Job(self._seq, payload, 0, forced)
        self._debounce.start(0 if forced else DEBOUNCE_MS)
        return True

    def _fix(self, point, source_crs):
        try:
            source = QgsCoordinateReferenceSystem(source_crs)
        except Exception:
            source = QgsCoordinateReferenceSystem()
        if not source.isValid():
            self._fail("좌표계 에러")
            return None
        try:
            value = QgsPointXY(point)
            if source != self._wgs84:
                value = QgsCoordinateTransform(source, self._wgs84,
                                               QgsProject.instance()).transform(value)
            lon, lat = float(value.x()), float(value.y())
        except Exception:
            self._fail("좌표변환 에러")
            return None
        if not (-180.0 <= lon <= 180.0 and -90.0 <= lat <= 90.0):
            self._fail("범위밖")
            return None
        return round(lon * UNIT), round(lat * UNIT)

    def _mode(self):
        """동기화 모드 문자열 반환: off / both / push(QGIS->서버) / pull(서버->QGIS).
        하위호환: 값이 참(true/on/1)이면 both, 거짓이면 off 로 본다."""
        v = QSettings().value(SETTINGS_KEY, "off")
        s = str(v).strip().lower() if v is not None else "off"
        if s in {"both", "push", "pull", "off"}:
            return s
        if s in {"1", "true", "yes", "on"}:
            return "both"
        return "off"

    def _enabled(self):
        # 이전 코드 호환용(양방향 전체 on/off 판단): off 가 아니면 활성
        return self._mode() != "off"

    def _send_enabled(self):
        # QGIS -> 서버 송신 허용 (양방향 또는 push)
        return self._mode() in ("both", "push")

    def _recv_enabled(self):
        # 서버 -> QGIS 수신 허용 (양방향 또는 pull)
        return self._mode() in ("both", "pull")

    def _request(self, path, query=None):
        url = QUrl(self._base + path)
        if query is not None:
            url.setQuery(query)
        request = QNetworkRequest(url)
        request.setRawHeader(b"Accept", b"application/json")
        try:
            request.setAttribute(QNetworkRequest.RedirectPolicyAttribute,
                                 QNetworkRequest.ManualRedirectPolicy)
        except AttributeError:
            pass
        return request

    @staticmethod
    def _armed(reply, timeout):
        timer = QTimer(reply)
        timer.setSingleShot(True)
        timer.timeout.connect(reply.abort)
        timer.start(timeout)
        return reply

    def _drain(self):
        if self._closed or self._active is not None or self._pending is None:
            return
        if not self._pending.forced and not self._send_enabled():
            self._pending = None
            return
        job, self._pending = self._pending, None
        request = self._request(PUSH_PATH)
        request.setHeader(QNetworkRequest.ContentTypeHeader, "application/json")
        reply = self._armed(self._manager.post(request, QByteArray(job.payload)),
                            PUSH_TIMEOUT_MS)
        self._active = (job, reply)
        reply.finished.connect(lambda j=job, r=reply: self._finish(j, r))

    def _finish(self, job, reply):
        active = self._active
        if active is None or active[0].seq != job.seq or active[1] is not reply:
            reply.deleteLater()
            return
        self._active = None
        ok = self._valid(reply) and self._acked(bytes(reply.readAll()))
        status = int(reply.attribute(QNetworkRequest.HttpStatusCodeAttribute) or 0)
        message = reply.errorString()
        reply.deleteLater()
        if self._closed:
            return
        if ok:
            self._debounce.start(0)
            return
        if self._pending is None and job.attempt < RETRY_MAX:
            self._pending = job._replace(attempt=job.attempt + 1)
            self._debounce.start(RETRY_MS * 2 ** job.attempt + random.randint(0, JITTER_MS))
            return
        if self._pending is None:
            self._fail("지도비교 좌표 전송 실패: HTTP %s · %s" % (status or "-", message))
        self._debounce.start(0)

    @staticmethod
    def _acked(body):
        try:
            return int(json.loads(body.decode("utf-8")).get("sequence", 0)) > 0
        except Exception:
            return False

    def _poll(self):
        if self._closed or self._stream is not None:
            return
        query = QUrlQuery()
        query.addQueryItem("after", str(self._cursor.sequence))
        query.addQueryItem("wait", str(LONGPOLL_S))
        reply = self._armed(self._manager.get(self._request(PULL_PATH, query)),
                            PULL_TIMEOUT_MS)
        self._stream = reply
        reply.finished.connect(lambda r=reply: self._track(r))

    def _track(self, reply):
        if reply is not self._stream:
            reply.deleteLater()
            return
        self._stream = None
        delay = PULL_MS
        try:
            if not self._valid(reply):
                raise ValueError
            data = json.loads(bytes(reply.readAll()).decode("utf-8"))
            instance = str(data.get("instance") or "")
            sequence = int(data.get("sequence") or 0)
            cursor = self._cursor
            if (instance and instance != cursor.instance) or sequence < cursor.sequence:
                cursor = _Cursor(instance or cursor.instance, 0)
            if data.get("found") and sequence > cursor.sequence and self._recv_enabled():
                self._recenter(float(data["lat"]), float(data["lng"]))
            self._cursor = _Cursor(cursor.instance, max(cursor.sequence, sequence))
            self._misses = 0
        except Exception:
            self._misses = min(self._misses + 1, MISS_MAX)
            delay = (min(PULL_CAP_MS, PULL_RETRY_MS * 2 ** self._misses)
                     + random.randint(0, JITTER_MS))
        finally:
            reply.deleteLater()
            if not self._closed:
                QTimer.singleShot(delay, self._poll)

    def _recenter(self, lat, lng):
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lng <= 180.0):
            return
        canvas = self._iface.mapCanvas()
        destination = canvas.mapSettings().destinationCrs()
        if not destination.isValid():
            return
        point = QgsPointXY(lng, lat)
        if destination != self._wgs84:
            try:
                point = QgsCoordinateTransform(self._wgs84, destination,
                                               QgsProject.instance()).transform(point)
            except QgsCsException:
                return
        center = canvas.center()
        tolerance = max(float(canvas.mapSettings().mapUnitsPerPixel()) * 0.5,
                        abs(canvas.extent().width()) * 1e-9, 1e-9)
        if math.hypot(point.x() - center.x(), point.y() - center.y()) <= tolerance:
            return

        if not SMOOTH_ENABLED:
            # 기존 방식: 즉시 점프
            self._echo_until = time.monotonic() + ECHO_S
            canvas.setCenter(point)
            canvas.refresh()
            return

        # 부드러운 이동: 목표만 갱신하고 애니메이션 타이머가 따라가게 한다.
        self._target = point
        self._echo_until = time.monotonic() + ECHO_S
        if not self._anim.isActive():
            self._anim.start()

    def _anim_step(self):
        if self._closed or self._target is None:
            self._anim.stop()
            return
        canvas = self._iface.mapCanvas()
        center = canvas.center()
        target = self._target
        mupp = float(canvas.mapSettings().mapUnitsPerPixel()) or 1e-9
        dist_px = math.hypot(target.x() - center.x(),
                             target.y() - center.y()) / mupp

        # 목표에 충분히 가까우면 정확히 맞추고 정지
        if dist_px <= SMOOTH_SNAP_PX:
            self._echo_until = time.monotonic() + ECHO_S
            canvas.setCenter(QgsPointXY(target))
            canvas.refresh()
            self._anim.stop()
            self._target = None
            return

        # 현재 -> 목표 로 일정 비율만큼 접근
        nx = center.x() + (target.x() - center.x()) * SMOOTH_ALPHA
        ny = center.y() + (target.y() - center.y()) * SMOOTH_ALPHA
        # 애니메이션 이동도 서버로 되돌아가지 않도록 에코 차단 시간 갱신
        self._echo_until = time.monotonic() + ECHO_S
        canvas.setCenter(QgsPointXY(nx, ny))
        canvas.refresh()

    @staticmethod
    def _valid(reply):
        if reply.error() != QNetworkReply.NoError:
            return False
        status = int(reply.attribute(QNetworkRequest.HttpStatusCodeAttribute) or 0)
        server = bytes(reply.rawHeader(b"Server")).decode("ascii", "ignore").strip()
        return status == 200 and server.startswith(SERVER_TOKEN)

    def _fail(self, text):
        now = time.monotonic()
        if now - self._failure_at < THROTTLE_S:
            return
        self._failure_at = now
        self.failed.emit(str(text))
