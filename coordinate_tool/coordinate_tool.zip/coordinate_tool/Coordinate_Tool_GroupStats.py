# -*- coding: utf-8 -*-

import csv
import os
import pickle
import sys
import traceback
import math
import webbrowser
from math import *

from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox, QTableView, QWidget, QMenu, QAction, QLabel, QVBoxLayout

from qgis.core import *
from qgis.gui import *

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/Coordinate_Tool_groupstats.ui'))

class CoordinateToolGroupStats(QMainWindow):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.ui = FORM_CLASS()
        self.ui.setupUi(self)

        # --- 새로 추가할 부분: 창을 항상 최상단에 고정 ---
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.ui.result = WindowResults(self.ui.centralwidget)
        self.ui.horizontalLayout.addWidget(self.ui.result)
        
        self.calculations = Calculations(self)

        # 레이어별 캐싱 데이터를 보관할 딕셔너리 생성
        self.all_layers_cache = {}

        self.ui.listHalf.setAcceptDrops(True)
        self.ui.listHalf.setModelColumn(2)

        self.ui.rows.setAcceptDrops(True)
        self.ui.columns.setAcceptDrops(True)
        self.ui.values.setAcceptDrops(True)

        self.ui.calculate.clicked.connect(self.showScore)
        self.ui.refresh.clicked.connect(self.refreshLayerData)
        self.ui.copy.clicked.connect(self.duplication)
        self.ui.clear.clicked.connect(self.clearChoice)
        self.ui.filterButton.clicked.connect(self.setFilter)
        self.ui.layer.currentIndexChanged.connect(self.layerSelection)   

        dictionary =  {'attributeTxt':[('Rejon',1), ('Posterunek',2)],
                    'countAttributes':[('Moc stacji', 3)],
                    # 'geometry':[('Length', 1), ('Area', 2)],
                    'calculations':[('Count', 1), ('Sum', 2), ('Average', 3), ('Standard deviation', 4)]}

        self.tm1 = ModelListaPol(self)
        self.ui.listHalf.setModel(self.tm1)

        self.tm2 = ModelRowsColumns(self)
        #tm2.ustawInneModele(tm1)
        self.ui.rows.setModel(self.tm2)

        self.tm3 = ModelRowsColumns(self)
        #tm3.ustawInneModele(tm1)
        self.ui.columns.setModel(self.tm3)

        self.tm4 = ValueModel(self)
        self.ui.values.setModel(self.tm4)

        self.tm2.setOtherModels(self.tm3, self.tm4)
        self.tm3.setOtherModels(self.tm2, self.tm4)
        self.tm4.setOtherModels(self.tm2, self.tm3)

        self.tm2.rowsInserted.connect(self.blockCalculations)   # Layer selection signal
        self.tm3.rowsInserted.connect(self.blockCalculations)   
        self.tm4.rowsInserted.connect(self.blockCalculations)   
        self.tm2.rowsRemoved.connect(self.blockCalculations)   
        self.tm3.rowsRemoved.connect(self.blockCalculations)   
        self.tm4.rowsRemoved.connect(self.blockCalculations)   
        self.ui.actionCopy.triggered.connect(self.duplication)   
        self.ui.actionCopySelected.triggered.connect(self.copyMarked)   
        self.ui.actionSaveCSV.triggered.connect(self.exportToCSV)   
        self.ui.actionSaveCSVSelected.triggered.connect(self.exportMarkedToCSV)
        self.ui.actionExport.triggered.connect(self.exportToLayer)
        self.ui.actionShowPanel.triggered.connect(self.showControlPanel)   
        self.ui.actionShowOnMap.triggered.connect(self.showOnMap)   


        self.ui.result.verticalHeader().sortIndicatorChanged.connect(self.sortRows)   

    def closeEvent(self, event):
        """
        창이 닫힐 때 자동으로 실행되는 이벤트 함수입니다. 
        여기서 기존 정보를 모두 초기화합니다.
        """
        # 1. 다중 캐싱을 위해 만든 딕셔너리 및 변수 완전 초기화
        self.all_layers_cache = {}
        self.cached_features = []
        
        # 2. 결과 모델 및 테이블 초기화 (기존에 만드신 함수 재사용)
        self.clearChoice()
        
        # 3. 레이어 선택 콤보박스 초기화 (첫 번째 항목으로 돌리거나 선택 해제)
        self.ui.layer.setCurrentIndex(-1)
        
        # 4. 기타 UI 설정값 초기화 (필요한 것만 선택적으로 적용하세요)
        self.ui._filter.setPlainText('')
        
        if hasattr(self.ui, 'onlySelected'):
            self.ui.onlySelected.setChecked(False)
            
        if hasattr(self.ui, 'useNULL'):
            self.ui.useNULL.setChecked(False)
            
        # 상태 표시줄 초기화
        self.statusBar().showMessage("")
        
        # 정상적으로 창 닫기(숨기기) 이벤트 진행
        event.accept()

    def sortRows(self, row, mode):
            self.ui.result.model().sortRows(row, mode)

    def blockCalculations(self, x, y, z):
        """값 영역에 필드가 들어오면 계산 버튼을 활성화합니다."""
        values = self.tm4._data
        
        # 값 영역에 데이터가 1개 이상 있으면 버튼 활성화
        if len(values) > 0:
            self.ui.calculate.setEnabled(True)
        else:
            self.ui.calculate.setEnabled(False)

    def showScore(self):
        "Performs calculations and sends them for display"
        chosenRows = tuple(self.tm2._data)
        chosenColumns = tuple(self.tm3._data)
        chosenValues = tuple(self.tm4._data)

        # 1. 값 영역의 속성 필드 추출
        value_fields = [x for x in chosenValues if x[0] != 'calculations']
        if not value_fields:
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', '계산할 값 필드를 먼저 추가해 주세요.'), 5000)
            return

        # 2. 행/열/값 영역에서 계산식(Function) 모두 추출
        calc_items = [x for x in chosenColumns + chosenRows + chosenValues if x[0] == 'calculations']
        if not calc_items:
            calc_items = [('calculations', 'sum', 0)] # 기본값: sum

        chosenRows_no_calc = [x for x in chosenRows if x[0] != 'calculations']
        chosenCols_no_calc = [x for x in chosenColumns if x[0] != 'calculations']

        # 3. 특수 NULL 값 판별 헬퍼 함수
        def is_null_val(val):
            if val is None: return True
            if isinstance(val, QVariant) and val.isNull(): return True
            s = str(val).strip()
            return s == '' or s.upper() == 'NULL' or 'QPyNullVariant' in s

        # 4. 값 추출 람다 함수 생성
        valueFunctions = []
        for val in value_fields:
            if val[0] == 'attributeTxt':
                valueFunctions.append(lambda _obj, idx=val[2]: _obj['attributes'][idx])
            elif val[0] == 'countAttributes':
                valueFunctions.append(
                    lambda _obj, idx=val[2]: None if is_null_val(_obj['attributes'][idx]) else (
                        float(_obj['attributes'][idx].value()) if isinstance(_obj['attributes'][idx], QVariant) else float(_obj['attributes'][idx])
                    )
                )

        index = self.ui.layer.currentIndex()
        layerId = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(layerId)

        _filter = self.ui._filter.toPlainText()
        valid_ids = None
        if _filter:
            request = QgsFeatureRequest().setFilterExpression(_filter).setFlags(QgsFeatureRequest.NoGeometry)
            valid_ids = set([f.id() for f in layer.getFeatures(request)])

        onlySelected = self.ui.onlySelected.isChecked()
        selectedObjects = layer.selectedFeatureIds() if onlySelected else []

        result = {}
        numberOfObjects = len(self.cached_features)
        counter = 0
        NULLcounter = 0
        use_null = self.ui.useNULL.isChecked()

        # 5. 1차 데이터 집계 (NULL 값 완전 필터링)
        for f_dict in self.cached_features:
            f_id = f_dict['id']

            if onlySelected and f_id not in selectedObjects:
                continue
            if valid_ids is not None and f_id not in valid_ids:
                continue

            has_null_key = False
            key_column = []
            for k in chosenCols_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_column.append('' if is_null_val(attr_val) else attr_val)

            key_row = []
            for k in chosenRows_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_row.append('' if is_null_val(attr_val) else attr_val)

            vals_to_calc = [vf(f_dict) for vf in valueFunctions]
            all_null_values = all(is_null_val(v) for v in vals_to_calc)

            if not use_null and (has_null_key or all_null_values):
                NULLcounter += 1
                continue

            key = (tuple(key_row), tuple(key_column))
            
            if key in result:
                result[key][0].append(vals_to_calc)
                result[key][1].append(f_id)
            else:
                result[key] = [[vals_to_calc], [f_id]]

            counter += 1
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats','데이터 분류 중... ') + '%.0f%%' % ((float(counter)/float(numberOfObjects))*100))

        self.statusBar().showMessage('총합계 및 테이블 생성 중...')

        # 6. UI 옵션 변수 연동
        enable_bottom_total = self.ui.showTotalBottom_checkBox.isChecked() if hasattr(self.ui, 'showTotalBottom_checkBox') else True
        enable_right_total = self.ui.showTotalRight_checkBox.isChecked() if hasattr(self.ui, 'showTotalRight_checkBox') else True
        enable_subtotal = self.ui.showSubtotal_checkBox.isChecked() if hasattr(self.ui, 'showSubtotal_checkBox') else True

        num_val_fields = len(value_fields)
        num_calcs = len(calc_items)
        has_rows = len(chosenRows_no_calc) > 0
        has_cols = len(chosenCols_no_calc) > 0

        # 무의미한 열(가로) 합계 방지 방어 로직
        add_col_total_key = enable_right_total and has_cols
        add_extra_total_cols = enable_right_total and (num_val_fields >= 2)

        # 행/열 구조 생성 및 부분합계/총합계 키 추가
        keys = result.keys()
        base_rows = list(set([z[0] for z in keys]))
        kolu = list(set([z[1] for z in keys]))

        subtotal_rows = set()
        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for i in range(1, len(chosenRows_no_calc)):
                    sub_key = list(r)
                    sub_key[i] = f"[{r[i-1]} 부분합]"
                    for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                    subtotal_rows.add(tuple(sub_key))
        subtotal_rows = list(subtotal_rows)

        ROW_TOTAL_KEY = tuple(['총합계'] + [''] * (len(chosenRows_no_calc) - 1)) if has_rows else ()
        COL_TOTAL_KEY = tuple(['총합계'] + [''] * (len(chosenCols_no_calc) - 1)) if has_cols else ()

        rows = base_rows[:]
        if enable_subtotal: rows.extend(subtotal_rows)
        if enable_bottom_total and has_rows: rows.append(ROW_TOTAL_KEY)

        columns = kolu[:]
        if add_col_total_key: columns.append(COL_TOTAL_KEY)

        raw_matrix = {r: {c: [] for c in columns} for r in rows}
        id_matrix = {r: {c: [] for c in columns} for r in rows}

        # 7. 데이터 2차 재배치 (부분합계, 총합계 긁어모으기)
        # 7-1. 원본 데이터
        for x in keys:
            r_key, c_key = x[0], x[1]
            raw_matrix[r_key][c_key].extend(result[x][0])
            id_matrix[r_key][c_key].extend(result[x][1])

        # 7-2. 행 부분합계 데이터
        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for c in kolu:
                    for i in range(1, len(chosenRows_no_calc)):
                        sub_key = list(r)
                        sub_key[i] = f"[{r[i-1]} 부분합]"
                        for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                        sub_key = tuple(sub_key)
                        raw_matrix[sub_key][c].extend(raw_matrix[r][c])
                        id_matrix[sub_key][c].extend(id_matrix[r][c])

        # 7-3. 가로 방향(열 범주 전체) 합계 데이터
        if add_col_total_key:
            for r in base_rows + (subtotal_rows if enable_subtotal else []):
                for c in kolu:
                    raw_matrix[r][COL_TOTAL_KEY].extend(raw_matrix[r][c])
                    id_matrix[r][COL_TOTAL_KEY].extend(id_matrix[r][c])

        # 7-4. 세로 방향(밑바닥 전체) 합계 데이터
        if enable_bottom_total and has_rows:
            cols_to_sum = kolu[:]
            if add_col_total_key: cols_to_sum.append(COL_TOTAL_KEY)
            for c in cols_to_sum:
                for r in base_rows: # 중복 방지를 위해 원본(base_rows)만 합산
                    raw_matrix[ROW_TOTAL_KEY][c].extend(raw_matrix[r][c])
                    id_matrix[ROW_TOTAL_KEY][c].extend(id_matrix[r][c])

        # 8. 데이터 행렬(Matrix) 생성 및 계산식 적용
        rowDictionary = {row: nr for nr, row in enumerate(rows)}
        columnDictionary = {col: nr for nr, col in enumerate(columns)}

        cols_count = len(columns) if len(columns) > 0 else 1
        extra_cols = num_calcs if add_extra_total_cols else 0
        total_normal_cols = cols_count * num_val_fields * num_calcs

        data = []
        for x in range(len(rows)):
            data.append([['', []] for _ in range(total_normal_cols + extra_cols)])

        for r in rows:
            for c in (columns if len(columns) > 0 else [()]):
                nrw = rowDictionary[r]
                nrk = columnDictionary[c] if len(columns) > 0 else 0

                cell_raw_data = raw_matrix[r][c] if len(columns) > 0 else raw_matrix[r][()]
                cell_ids = id_matrix[r][c] if len(columns) > 0 else id_matrix[r][()]

                for v_idx in range(num_val_fields):
                    raw_values = [row[v_idx] for row in cell_raw_data]
                    valid_values = []

                    for v in raw_values:
                        if is_null_val(v):
                            if use_null: valid_values.append(0.0)
                        else:
                            try:
                                valid_values.append(float(v))
                            except (ValueError, TypeError):
                                valid_values.append(str(v))

                    for c_idx, calc in enumerate(calc_items):
                        calc_id = calc[2]
                        calc_name = calc[1]

                        calc_vals = valid_values
                        if calc_name not in ('count', 'unique'):
                            calc_vals = [v for v in valid_values if isinstance(v, (int, float))]

                        if not calc_vals and calc_name not in ('count', 'unique'):
                            s = ''
                        else:
                            try:
                                s = self.calculations.list[calc_id][1](calc_vals)
                            except Exception:
                                s = ''

                        col_idx = nrk * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
                        data[nrw][col_idx] = [s, cell_ids]

        # 값 필드가 2개 이상일 때 나타나는 우측 끝 궁극의 크로스 합계
        if add_extra_total_cols:
            for r_idx, r in enumerate(rows):
                for c_idx, calc in enumerate(calc_items):
                    row_val = 0.0
                    has_num = False
                    
                    if add_col_total_key:
                        col_key_idx = columnDictionary[COL_TOTAL_KEY]
                        start_col = col_key_idx * (num_val_fields * num_calcs)
                        indices_to_sum = [start_col + v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    else:
                        indices_to_sum = [v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    
                    for i in indices_to_sum:
                        val = data[r_idx][i][0]
                        if isinstance(val, (int, float)):
                            row_val += val
                            has_num = True
                            
                    target_col_idx = total_normal_cols + c_idx
                    if has_num:
                        data[r_idx][target_col_idx] = [round(row_val, 4), []]
                    else:
                        data[r_idx][target_col_idx] = ['', []]

        # 9. 헤더(이름표) 동적 생성
        atr = {i: layer.fields().at(i) for i in range(layer.fields().count())}

        rowNames = [atr[x[2]].name() for x in chosenRows_no_calc]
        colNames = [atr[x[2]].name() for x in chosenCols_no_calc]
        valNames = [f"{atr[val[2]].name()} {calc[1]}" for val in value_fields for calc in calc_items]

        columns1 = []
        if len(columns) > 0 and len(columns[0]) > 0:
            for c in columns:
                if c == COL_TOTAL_KEY:
                    for vname in valNames:
                        columns1.append(tuple(['총합계'] + [''] * (len(chosenCols_no_calc) - 1) + [vname]))
                else:
                    for vname in valNames:
                        columns1.append(c + (vname,))
        else:
            columns1 = [(vname,) for vname in valNames]

        if add_extra_total_cols:
            for calc in calc_items:
                calc_name = calc[1]
                header_len = len(columns1[0]) if len(columns1) > 0 else 1
                if header_len > 1:
                    extra_header = tuple(['총합계'] + [''] * (header_len - 2) + [f"전체 {calc_name}"])
                else:
                    extra_header = (f"총합계 {calc_name}",)
                columns1.append(extra_header)

        rows1 = rows

        self.rows = len(rows1[0]) if len(rows1) > 0 else 0
        self.columns = len(columns1[0]) if len(columns1) > 0 else 0

        if len(rows1) > 0 and len(rows1[0]) > 0:
            rows1.insert(0, tuple(rowNames))
        if len(columns1) > 0 and len(columns1[0]) > 0:
            columns1.insert(0, tuple(colNames) + ("값(Value)",))

        if len(rows1) > 0 and len(columns1) > 0:
            self.ui.result.setUpdatesEnabled(False)
            self.tm5 = ResultModel(data, rows1, columns1, layer)
            self.ui.result.setModel(self.tm5)

            for i in range(len(columns1[0]), 0, -1):
                self.ui.result.verticalHeader().setSortIndicator(i-1, Qt.AscendingOrder)
            for i in range(len(rows1[0]), 0, -1):
                self.ui.result.horizontalHeader().setSortIndicator(i-1, Qt.AscendingOrder)

            statement = self.statusBar().currentMessage()
            percent = 100.00 / self.tm5.columnCount()
            counter = 0
            for i in range(self.tm5.columnCount()):
                self.ui.result.resizeColumnToContents(i)
                counter += percent
                self.statusBar().showMessage(statement + '%.0f%%' % (counter))

            self.ui.result.setUpdatesEnabled(True)
            self.ui.result.doubleClicked.connect(lambda index: self.showOnMap())
            self.ui.result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged())

            msg = "계산 완료."
            if NULLcounter > 0 and not use_null:
                msg += f" (NULL 객체 {NULLcounter}개 제외됨)"
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', msg), 20000)

        else:
            try:
                del(self.tm5)
            except AttributeError:
                pass
            self.ui.result.setModel(None)
            self.statusBar().showMessage(CoreApplication.translate('GroupStats','조건에 맞는 데이터를 찾을 수 없습니다.'), 10000)

    def setLayers (self, layer):   #finished
        "Adds available layers to the selection list in the window"

        index = self.ui.layer.currentIndex()
        if index !=-1:
            layerId = self.ui.layer.itemData(index)                        # id of the previously selected layer

        self.ui.layer.blockSignals(True)
        self.ui.layer.clear()                                            # fill the comboBox with a new list of layers
        # layer.sort(key=lambda x: x[0].lower())
        for i in layer:
            self.ui.layer.addItem(i[0], i[1])

        if index !=-1:
            index2 = self.ui.layer.findData(layerId)                       # if the previously selected layer is a list then select it
            if index2 !=-1:
                self.ui.layer.setCurrentIndex(index2)
            else:
                self.layerSelection(0)                                            # if it doesn't have the first one
        else:
            self.layerSelection(0)
        self.ui.layer.blockSignals(False)

    def exportToLayer(self):
        """
        계산된 피벗 테이블 결과를 도형이 없는 QGIS 메모리 테이블 레이어로 생성합니다.
        """
        if not hasattr(self, 'tm5') or self.tm5 is None:
            QMessageBox.information(self, QCoreApplication.translate('GroupStats','알림'), "출력할 계산 결과가 없습니다.")
            return

        # 1. 빈 메모리 레이어 생성 (도형 없는 속성 테이블 전용)
        layer_name = "피벗테이블_결과"
        mem_layer = QgsVectorLayer("None", layer_name, "memory")
        pr = mem_layer.dataProvider()

        offsetX = self.tm5.offsetX
        offsetY = self.tm5.offsetY
        numberOfRows = self.tm5.rowCount()
        numberOfColumns = self.tm5.columnCount()

        field_names = []
        fields = []

        # 2. 필드(컬럼) 구성하기
        for j in range(numberOfColumns):
            if j < offsetX:
                # [좌측] 행 속성 이름 (예: 일정분배, 담당 등)
                name = str(self.tm5.createIndex(offsetY - 1, j).data() or "").strip()
                if not name: name = f"Field_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.String))
            else:
                # [우측] 열(피벗) 속성 이름 조합 (예: 광주_count, 광주_sum)
                name_parts = []
                for i in range(offsetY):
                    part = str(self.tm5.createIndex(i, j).data() or "").strip()
                    if part: name_parts.append(part)
                name = "_".join(name_parts)
                if not name: name = f"Value_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.Double)) # 계산을 위해 실수형(Double)으로 지정

        pr.addAttributes(fields)
        mem_layer.updateFields()

        # 3. 데이터(행) 채워 넣기
        features = []
        for i in range(offsetY, numberOfRows):
            feat = QgsFeature()
            attrs = []
            for j in range(numberOfColumns):
                val = self.tm5.createIndex(i, j).data()
                if val is None or str(val).strip() == "":
                    attrs.append(None) # 빈 칸은 NULL 처리
                else:
                    if j < offsetX:
                        attrs.append(str(val)) # 이름은 문자로
                    else:
                        try:
                            attrs.append(float(val)) # 값은 숫자로 변환
                        except ValueError:
                            attrs.append(str(val)) # 변환 실패 시 문자로 안전하게 삽입
            feat.setAttributes(attrs)
            features.append(feat)

        # 4. 레이어를 QGIS 화면에 추가
        pr.addFeatures(features)
        mem_layer.updateExtents()
        QgsProject.instance().addMapLayer(mem_layer)
        
        self.statusBar().showMessage("결과가 레이어 패널에 '피벗테이블_결과'로 추가되었습니다.", 10000)


    def refreshLayerData(self):
        """
        현재 선택된 레이어의 캐시를 삭제하고 데이터를 새로 불러옵니다.
        """
        index = self.ui.layer.currentIndex()
        if index == -1:
            return
            
        idW = self.ui.layer.itemData(index)
        
        # 1. 딕셔너리에 현재 레이어의 캐시 정보가 남아있다면 삭제
        if idW in self.all_layers_cache:
            del self.all_layers_cache[idW]
            
        # 2. 결과 테이블 비우기
        self.clearChoice()
        
        # 3. 레이어 선택 함수를 강제로 다시 호출하여 새 데이터 수집
        self.layerSelection(index)
        
        self.statusBar().showMessage("해당 레이어의 정보가 새로고침 되었습니다.", 5000)

    def layerSelection(self, index):     #finished
        "Runs after selecting layer from the list. Sets a new list of fields to choose from and deletes windows with already selected fields"
        # --- 새로 추가할 안전장치 ---
        if index == -1:
            return
        
        idW = self.ui.layer.itemData(index)                          # Get the ID of the selected layer
        layer = QgsProject.instance().mapLayer(idW)#.toString())
        
        # --- 레이어를 정상적으로 찾지 못한 경우 방어 ---
        if not layer:
            return
        
        fields = layer.fields()

        dictionary = {}
        # if layer.geometryType() in (QgsWkbTypes.PointGeometry, QgsWkbTypes.NullGeometry):
        #     dictionary['geometry'] =  []
        # elif layer.geometryType() == QgsWkbTypes.LineGeometry:                             # line
        #     dictionary['geometry'] = [(QCoreApplication.translate('GroupStats','Length'), 1)]
        # elif layer.geometryType() == QgsWkbTypes.PolygonGeometry:                             # polygon
        #     dictionary['geometry'] = [(QCoreApplication.translate('GroupStats','Perimeter'), 1), (QCoreApplication.translate('GroupStats','Area'), 2)]

        dictionary['countAttributes'] = []
        dictionary['attributeTxt'] = []

        for i in range(fields.count()):
            field = fields.at(i)
            if field.isNumeric():
                dictionary['countAttributes'].append((field.name(), i))
            else:
                dictionary['attributeTxt'].append((field.name(), i))

        dictionary['calculations']=[]
        obl = self.calculations.list
        for c,b in obl.items():
            dictionary['calculations'].append((b[0],c))

        del(self.tm1)
        self.tm1 = ModelListaPol()
        self.ui.listHalf.setModel(self.tm1)
        keys = ['calculations']  # geometry
        for i in keys:
            j = dictionary[i]
            j.sort(key=lambda x: x[0].lower())
            rows=[]
            for k, l in j:
                rows.append((i,k,l))
            rows.sort(key=lambda x: x[2])
            self.tm1.insertRows( 0, len(rows), QModelIndex(), rows)
        keys = ['countAttributes', 'attributeTxt']
        rows=[]
        for i in keys:
            j = dictionary[i]
            for k, l in j:
                rows.append((i,k,l))
        # rows.sort(key=lambda x: x[1].lower()) # 필드명 오름차순
        rows.sort(key=lambda x: x[2]) # 필드명 순서대로 나열
        self.tm1.insertRows( 0, len(rows), QModelIndex(), rows)

        self.clearChoice()
        # 딕셔너리에 현재 선택한 레이어 ID(idW)가 이미 저장되어 있는지 확인
        if idW in self.all_layers_cache:
            # 이미 저장된 정보가 있으면 새로 불러오지 않고 즉시 적용
            self.cached_features = self.all_layers_cache[idW]
            self.statusBar().showMessage("레이어 정보 불러오기 완료", 5000)
        else:
            # --- NoGeometry 플래그를 사용한 초고속 캐싱 로직 ---
            self.statusBar().showMessage("레이어 정보를 메모리에 불러오는 중입니다. 잠시만 기다려주세요...")
            QCoreApplication.processEvents() # UI 멈춤 방지
        
            request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
            self.cached_features = [
                {
                    'id': f.id(),
                    'attributes': f.attributes()
                }
                for f in layer.getFeatures(request)
            ]
            # 다음 번에 빠르게 불러오기 위해 딕셔너리에 레이어 ID와 함께 저장
            self.all_layers_cache[idW] = self.cached_features

            self.statusBar().showMessage("레이어 속성 정보 불러오기 및 캐시 저장 완료.", 5000)

    def clearChoice(self):             # finished
        " Clears windows with selected rows, columns and values"
        self.tm2.removeRows(0, self.tm2.rowCount() ,QModelIndex())
        self.tm3.removeRows(0, self.tm3.rowCount() ,QModelIndex())
        self.tm4.removeRows(0, self.tm4.rowCount() ,QModelIndex())
        # 수정된 부분: ResultModel 인스턴스를 삭제하고 테이블 뷰의 모델을 해제하여 비움
        try:
            del(self.tm5)
        except AttributeError:
            pass
        self.ui.result.setModel(None)
        
        self.ui._filter.setPlainText('')

    def showControlPanel(self):     # finished
        ""
        self.ui.controlPanel.setVisible(True)


    def setFilter(self):               # finished 2
        index = self.ui.layer.currentIndex()                                             # Download selected layer
        layerId = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(str(layerId))

        text = self.ui._filter.toPlainText()                                                 # Retrieve the text from the window and display the query window
        q = QgsSearchQueryBuilder(layer)
        q.setSearchString(text)
        q.exec_()

        self.ui._filter.setPlainText(q.searchString ())                                       # Insert a query into the window


    # ------------------------ COPYING DATA TO THE CLIPBOARD AND CSV SAVE ----------------------------START

    def duplication (self):
        "Copy all data to the clipboard"
        text, test = self.downloadDataFromTheTable(True, True)
        if test==True:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('모든 데이터를 클립보드에 복사합니다.', 5000)

    def copyMarked (self):
        "Copy selected data to the clipboard"
        text, test = self.downloadDataFromTheTable(False, True)
        if test==True:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('선택한 데이터를 클립보드에 복사합니다.', 5000)

    def exportToCSV (self):
        "Saves all data to CSV file"
        data, test = self.downloadDataFromTheTable(True, False)
        if test==True:
            self.saveFileData(data)

    def exportMarkedToCSV (self):
        "Saves selected data to a CSV file"
        data, test = self.downloadDataFromTheTable(False, False)
        if test==True:
            self.saveFileData(data)

    def saveFileData (self, data):
        "Support for writing data to a file"
        fileWindow = QFileDialog()                                              # Select file to write
        fileWindow.setAcceptMode(1)
        fileWindow.setDefaultSuffix("csv")
        fileWindow.setNameFilters(["CSV files (*.csv)", "All files (*)"])
        if fileWindow.exec_() == 0:                                             # No file selected - output
            return
        fileName = fileWindow.selectedFiles()[0]
        _file = open(fileName, 'w')                                            # Open file for writing
        csvfile = csv.writer( _file, delimiter=';' )
        for i in data:                                                          # Copying data from the table
            #csvfile.writerow([bytes(x, 'utf-8') for x in i])
            csvfile.writerow(i)
        _file.close()

    def downloadDataFromTheTable(self, allData=True, controlCharacters=False):
        if self.ui.result.model()==None:
            QMessageBox.information(None,QCoreApplication.translate('GroupStats','Information'), \
                QCoreApplication.translate('GroupStats','No data to save/copy'))
            return None, False

        text=''
        data = []
        numberOfColumns = self.tm5.columnCount()
        numberOfRows = self.tm5.rowCount()
        rows = []
        columns = []

        if allData == False:                                                               # If the option 'only checked' get indexes of selected fields
            indexList = self.ui.result.selectedIndexes()
            if len(indexList)==0:
                QMessageBox.information(None,QCoreApplication.translate('GroupStats','Information'), \
                    QCoreApplication.translate('GroupStatsD','No data selected'))
                return None, False
            for i in indexList:
                rows.append(i.row())
                columns.append(i.column())

        for i in range(numberOfRows):                                                          # Copying data from the table
            if allData or (i in rows) or (i < self.tm5.offsetY):
                row = []
                for j in range(numberOfColumns):
                    if allData or (j in columns) or (j < self.tm5.offsetX):
                        row.append(str(self.tm5.createIndex(i,j).data()))
                data.append(row)

        if controlCharacters == True:
            for m, i in enumerate(data):                                                # Copying data from the table
                if m>0:
                    text = text + chr(13)
                for n, j in enumerate(i):
                    if n>0:
                        text = text + chr(9)
                    text = text + j
            return text, True
        else:
            return data, True

    def copyCellContent(self, selectedCell):
        "Copy cell value to clipboard"
        clipboard = QApplication.clipboard()
        clipboard.setText(selectedCell)

    # ------------------------ COPYING DATA TO THE CLIPBOARD AND SAVING CSV ------------------ ---------- END

    def showOnMap(self):             # change not to duplicate indexes from cells
        indexList = self.ui.result.selectedIndexes()                                    # Retrieve the indexes of the selected fields
        idList = []
        for i in indexList:                                                             # Get object indexes to show
            lista = i.data(Qt.UserRole)#.toList()
            if lista == None:                                                           # Reject lines with headers
                lista = ()
            for j in lista:
                idList.append(j)    # w 1 było idList.append(j.toInt()[0])

        try:
            self.tm5.layer.selectByIds(idList)                                          #   selecting them on the map
        except AttributeError:
            QMessageBox.information(None,QCoreApplication.translate('GroupStats','Information'),QCoreApplication.translate('GroupStats','No data selected'))
        else:                                                  
            self.iface.mapCanvas().zoomToSelected(self.tm5.layer)                        #   zoom to selected objects
            if len(idList)==1 and self.tm5.layer.geometryType()==0:                      #   if the layer is point and there is only one object in the group ..
                self.iface.mapCanvas().zoomScale(1000)                                   #   set the scale to 1: 1000

    def onSelectionChanged(self):
        indexList = self.ui.result.selectedIndexes()                                  
        total = 0
        count = 0

        for item in indexList:
            row = item.row()        # 행 번호 (0부터 시작)
            col = item.column()     # 열 번호 (0부터 시작)
            if self.columns <= row and self.rows <= col:
                text = item.data(Qt.DisplayRole)#.toList()
                try:
                    value = float(text)
                    total += value
                    count += 1
                except ValueError:
                    count += 1
                    continue

        total = self.format_number(round(total,4))
        if count > 0:
            # self.iface.statusBarIface().showMessage(f"선택한 {count}개의 숫자 합계: {total}")
            # self.bottom_label.setText(f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}")
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats',f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}"),30000)
        else:
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats',''), 30000)

    def format_number(self, num):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)

class ModelList(QAbstractListModel):
    """
    Model for windows with amodeut lists.
    Data stored on the list: [(amodeutu type, name, id), ...]
    """

    def __init__(self, mainWindow, parent=None):

        super(ModelList, self).__init__(parent)
        self._data = []
        self.mainWindow = mainWindow
        self.calculations = Calculations(self)


    def rowCount(self, parent=QModelIndex):
        return len(self._data)


    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < self.rowCount():
            return None#QVariant()

        row = index.row()
        if role == Qt.DisplayRole:
            return self._data[row][1]

        #elif rola == Qt.ForegroundRole:
        #    if self.data[row][0] == 'geometry':
        #        kolor = QColor(0,255,0)
        #    elif self.data[row][0] == 'calculations':
        #        kolor = QColor(255,0,0)
        #    elif self.data[row][0] == 'attributeTxt':
        #        kolor = QColor(150,150,150)
        #    else:
        #        kolor = QColor(0,0,0)   # 'countAttributes'
        #
        #    pedzel = QBrush(kolor)
        #    return pedzel

        elif role == Qt.DecorationRole:
            if self._data[row][0] == 'geometry':
                icon = QIcon(":/plugins/groupstats/icons/geom.png")
            elif self._data[row][0] == 'calculations':
                icon = QIcon(":/plugins/groupstats/icons/calc.png")
            elif self._data[row][0] == 'attributeTxt':
                icon = QIcon(":/plugins/groupstats/icons/alpha.png")
            else:
                icon = QIcon(":/plugins/groupstats/icons/digits.png")

            return icon

        return None#QVariant()


    def mimeTypes(self):
        return ['application/x-groupstats-polaL', 'application/x-groupstats-polaWK', 'application/x-groupstats-polaW']


    def supportedDragActions(self):
        return Qt.MoveAction


    def supportedDropActions(self):
        return Qt.MoveAction


    def insertRows(self, row, number, index, data):
        self.beginInsertRows(index, row, row + number - 1)
        for n in range(number):
            self._data.insert(row + n, data[n])
        self.endInsertRows()
        return True


    def removeRows(self, row, number, index):
        self.beginRemoveRows(index, row, row + number - 1)
        del self._data[row:row + number]
        self.endRemoveRows()
        return True


    def mimeData(self, indexy, typMime='application/x-groupstats-polaL'):
        dataMime = QMimeData()
        data = QByteArray()
        stream = QDataStream(data, QIODevice.WriteOnly)
        for index in indexy:
            row = index.row()
            stringg = pickle.dumps(self._data[row][2])
            #stream << self.data[rows][0][0] << self.data[row][1][0]    #----------------------------- ???????[0]correct
            # Datatypes below happen to be strings or already bytes! (b'geometry', b'calculations' or b'attributeTxt' - maybe reused?)

            stream.writeBytes(bytes(self._data[row][0], 'utf-8') if isinstance(self._data[row][0], str) else bytes(self._data[row][0]))
            stream.writeBytes(bytes(self._data[row][1], 'utf-8') if isinstance(self._data[row][1], str) else bytes(self._data[row][1]))
            stream.writeInt16(self._data[row][2])

        dataMime.setData(typMime, data)

        return dataMime


    def flags(self, index):
        flag = super(ModelList, self).flags(index)

        if index.isValid():
            return flag | Qt.ItemIsDragEnabled | Qt.ItemIsEnabled | Qt.ItemIsSelectable
        else:
            return Qt.ItemIsDropEnabled


class ModelRowsColumns(ModelList):
    """
    Model for windows with field lists for rows and columns
    """

    def __init__(self, parent):

        super(ModelRowsColumns, self).__init__(parent)
        self._data = []


    def setData(self, index, value):
        self._data.insert(index, value)
        return True


    def setOtherModels(self, modelWiK, valueModel):
        self.modelWiK = modelWiK._data
        self.valueModel = valueModel._data


    def mimeData(self, indexy):
        return super(ModelRowsColumns, self).mimeData(indexy, 'application/x-groupstats-polaWK')

    def dropMimeData(self, dataMime, share, row, column, index):
        if dataMime.hasFormat('application/x-groupstats-polaL'):
            dataType = 'application/x-groupstats-polaL'
        elif dataMime.hasFormat('application/x-groupstats-polaWK'):
            dataType = 'application/x-groupstats-polaWK'
        elif dataMime.hasFormat('application/x-groupstats-polaW'):
            dataType = 'application/x-groupstats-polaW'
        else:
            return False

        data = dataMime.data(dataType)

        stream = QDataStream(data, QIODevice.ReadOnly)
        outData = []
        while not stream.atEnd():
            #typ = ''#QString() --------------------------------???????????????????????????????????????
            #name = ''#QString()   -------------------------------------??????????????????????????????????????????????
            #stream >> typ >> name
            typ = stream.readBytes().decode('utf-8')
            name = stream.readBytes().decode('utf-8')
            id = stream.readInt16()
            field = (typ, name, id)
            dataWKiW = self.modelWiK+self.valueModel

            if typ=='calculations' and typ in [x[0] for x in dataWKiW] and dataType == 'application/x-groupstats-polaL':
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','함수는 한 영역에서만 사용할 수 있습니다'),5000)
                return False
            elif (field in self.modelWiK or field in self._data) and dataType in ['application/x-groupstats-polaL', 'application/x-groupstats-polaW']:
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','이 필드는 이미 있습니다.'),5000)
                return False
            #elif (typ != 'calculations' and 'calculations' in [x[0] for x in self.data]) or (typ=='calculations' and len([x for x in self.data if (x[0] != 'calculations')])>0):
            #    print 'calculated fields cannot be together with other fields'
            #    return False
            elif typ=='calculations' and id not in self.calculations.textList and 'attributeTxt' in [x[0] for x in self.valueModel]:  #name != self.calculations.lista[0][0]
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','텍스트 값 함수는 다음 중 하나만 사용할 수 있습니다 (%s)' % self.calculations.textNames), 5000)
                return False

            outData.append(field)

        self.insertRows(row, len(outData), index, outData)

        return True


class ValueModel(ModelList):
    """
    Model for a window with values ​​for calculations
    """

    def __init__(self, parent=None):

        super(ValueModel, self).__init__(parent)
        self._data = []

    def mimeData(self, indexy):
        return super(ValueModel, self).mimeData(indexy, 'application/x-groupstats-polaW')

    def dropMimeData(self, dataMime, share, row, column, index):
        if dataMime.hasFormat('application/x-groupstats-polaL'):
            dataType = 'application/x-groupstats-polaL'
        elif dataMime.hasFormat('application/x-groupstats-polaWK'):
            dataType = 'application/x-groupstats-polaWK'
        elif dataMime.hasFormat('application/x-groupstats-polaW'):
            dataType = 'application/x-groupstats-polaW'
        else:
            return False

        data = dataMime.data(dataType)
        stream = QDataStream(data, QIODevice.ReadOnly)
        outData = []
        
        while not stream.atEnd():
            typ = stream.readBytes().decode('utf-8')
            name = stream.readBytes().decode('utf-8')
            id = stream.readInt16()
            field = (typ, name, id)

            # 1. 계산식(sum, count 등) 드롭 방지
            # --- 아래 부분을 수정합니다 (내부 순서 변경은 중복 검사에서 제외) ---
            if field in self._data and dataType != 'application/x-groupstats-polaW':
                self.mainWindow.statusBar().showMessage("이미 추가된 필드입니다.", 5000)
                return False

            outData.append(field)

        self.insertRows(row, len(outData), index, outData)
        return True

    def setOtherModels(self, modelRows, modelColumns):
        self.modelRows = modelRows._data
        self.modelColumns = modelColumns._data
        
class ModelListaPol(ModelList):
    """
    Model for the window with a list of available fields
    """

    def __init__(self, parent=None):

        super(ModelListaPol, self).__init__(parent)
        #self.ustawDane(slownikPol)
        self._data = []

    def dropMimeData(self, dataMime, share, row, column, index):
        return True


    def removeRows(self, row, number, index):

        return True


class ResultModel(QAbstractTableModel):     # finished
    """
    Model for the window with calculation results
    """

    def __init__(self, data, rows, columns, layer, parent=None):
        super(ResultModel, self).__init__(parent)
        self._data = data
        self.rows = rows
        self.columns = columns
        self.layer = layer

        self.offsetX = max(1,len(rows[0]))                                           # Coordinate shift so that the data starts with 0.0
        self.offsetY = max(1, len(columns[0]))
        
        # --- 아래 두 줄을 주석 처리(#) 하거나 삭제하세요 ---
        # if len(rows[0]) != 0 and len(columns[0]) != 0:                               # One line offset (empty) to make room for the names of the lines
        #         self.offsetY += 1

    def columnCount(self,parent=QModelIndex()):
        if len(self.rows[0])>0 and len(self.columns[0])>0:
            l = len(self.columns) + len(self.rows[0]) - 1
        elif len(self.rows[0])>0 and len(self.columns[0])==0:
            l = len(self.rows[0])+1
        elif len(self.rows[0])==0 and len(self.columns[0])>0:
            l = len(self.columns)
        else:
            l = 2

        return l #max(len(self.rows[0])+1,len(self.column)+len(self.rows[0]))

    def rowCount(self, parent=QModelIndex()):
        # --- 수정 전 ---
        # return max(2, len(self.rows) + len(self.columns[0]))
        
        # --- 수정 후 ---
        if len(self.rows[0]) > 0 and len(self.columns[0]) > 0:
            return max(2, len(self.rows) + len(self.columns[0]) - 1)
        return max(2, len(self.rows) + len(self.columns[0]))

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < self.rowCount():
            return None

        row = index.row() - self.offsetY
        column = index.column() - self.offsetX

        if role == Qt.DisplayRole:
            if row >= 0 and column >= 0:                                      # [우측 하단] 데이터 영역
                return self._data[row][column][0]
            elif column < 0 and row >= 0 and len(self.rows[0]) > 0:           # [좌측 하단] 행 값 영역 (예: 본사, 대구)
                return self.rows[row+1][column]
            elif row < 0 and column < 0 and len(self.rows[0]) > 0:            # [좌측 상단] 헤더 이름 영역
                if row == -1:                                                 
                    return self.rows[0][column]                               # 제일 아랫줄은 행 이름 (예: '일정분배')
                else:                                                         
                    return self.columns[column + 1][row]                      # 윗줄은 열 이름 (예: '담당')
            elif column >= 0 and row < 0 and len(self.columns[0]) > 0:        # [우측 상단] 열 값 영역 (예: count, sum)
                return self.columns[column + 1][row]

        elif role == Qt.UserRole:
            if row >=0 and column >=0:                                      # Data
                return self._data[row][column][1]

        elif role == Qt.UserRole+1:
            #print "user role+1"
            if row <0 and column >=0:                                      # column, row or data
                return "column"
            elif row >=0 and column <0:
                return "row"
            elif row >=0 and column >=0:
                return "data"

        elif role == Qt.BackgroundRole:                                         # Cell filling
            if row<0 or column<0:                                           # gray for cells with descriptions and namesi
                colour = QColor(245,235,235)
                brush = QBrush(colour)
                return brush

        elif role == Qt.TextAlignmentRole:
            if column < 0 and row < -1 and len(self.rows[0]) != 0:
                return Qt.AlignRight | Qt.AlignVCenter
            elif column >= 0 and row < 0:
                return Qt.AlignHCenter | Qt.AlignVCenter
            elif column >= 0 and row >= 0:
                return Qt.AlignRight | Qt.AlignVCenter

        elif role == Qt.FontRole:
            if row<0 and column<0:
                font = QFont()
                font.setBold(True)
                #font.setItalic(True)
                return font

        return None#QVariant()

    def sort(self, column, mode):
        """
        Sorts the results table by the selected column
        column - column number
        mode - 1-descending, other-ascending
        """

        if len(self.rows) == 1:                                              # If there is only one line, there is nothing to sort
            return

        tmp = []                                                                # A temporary list for a sorted column

        if column >= self.offsetX:                                             # Selecting data to sort
            # n-line number before storting, d-data in line
            try:
                tmp.extend([(n, (float('nan') if not str(d[column - self.offsetX][0]).strip()
                                 else float(d[column - self.offsetX][0]))) for n, d in enumerate(self._data)])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[column - self.offsetX][0])) for n, d in enumerate(self._data)])
        else:                                                                   # or line names
            # Either convert all values or none to float for sorting
            # n-row number before storting, d-row description
            try:
                tmp.extend([(n, (float('nan') if not str(d[column]).strip()
                                 else float(d[column]))) for n, d in enumerate(self.rows[1:])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[column])) for n, d in enumerate(self.rows[1:])])

        tmp = sort_values_nulls_last(tmp, mode)

        data2 = tuple(self._data)                                                # A temporary tuple with all the data
        self._data=[]
        rows2=tuple(self.rows)                                            # A temporary tuple with descriptions of the rows
        self.rows=[]
        self.rows.append(rows2[0])                                        # Adding row names (only names, no row descriptions)

        for i in tmp:                                                           # Arrange all data and row descriptions according to a temporary sort list
            self._data.append(data2[i[0]])
            self.rows.append(rows2[i[0]+1])

        topLeft = self.createIndex(0,0)                                         # Signal change data
        bottomRight = self.createIndex(self.rowCount(), self.columnCount())
        self.dataChanged.emit(topLeft, bottomRight)


    def sortRows(self, row, mode):
        """
        Sorts the results table according to the chosen rows
        rows - rows number
        mode - 1-descending, other-ascending
        """
        if len(self.columns) - self.offsetX <=1:                                              # If there is only one column, there is nothing to sort
            return                                                              # (self.columns are then the following list [(),])
        tmp = []                                                                # A temporary list for a sorted row

        if row >= self.offsetY:                                              # Selecting data to sort
            # Either convert all values or none to float for sorting
            try:
                tmp.extend([(n, (float('nan') if not str(d[0]).strip() else float(d[0]))) for n, d in enumerate(self._data[row - self.offsetY])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[0])) for n, d in enumerate(self._data[row - self.offsetY])])    # n-column number before storting, d-data in the column
        else:                                                                   # or column names
            # Either convert all values or none to float for sorting
            try:
                tmp.extend([(n, (float('nan') if not str(d[row]).strip() else float(d[row]))) for n, d in enumerate(self.columns[1:])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[row])) for n, d in enumerate(self.columns[1:])])
            except IndexError:
                # The table can't be sorted using this column. It's probably the row header columnn
                return

        tmp = sort_values_nulls_last(tmp, mode)

        data2 = tuple(self._data)                                                # A temporary tuple with all the data
        self._data=[]
        columns2=tuple(self.columns)                                            # A temporary tuple with column descriptions
        self.columns=[]
        self.columns.append(columns2[0])                                        # Adding column names (only names, no column descriptions)
        for j in data2:                                                         # Arranging all data according to a temporary sort list
            row = []
            for i in tmp:
                row.append(j[i[0]])
            self._data.append(tuple(row))

        for i in tmp:                                                           # Arrangement of column descriptions according to a temporary sort list
            self.columns.append(columns2[i[0] + 1])

        topLeft = self.createIndex(0,0)                                         # Signal change data
        bottomRight = self.createIndex(self.rowCount(), self.columnCount())
        self.dataChanged.emit(topLeft, bottomRight)


def sort_values_nulls_last(alist, rev):
    # 유효한 값만 1차로 필터링
    contains_values = [x for x in alist
                       if str(x[1]).strip()
                       and x[1] is not None
                       and (not isinstance(x[1], float) or not math.isnan(x[1]))]
                       
    # 일반 데이터, 부분합계, 총합계를 담을 빈 리스트 생성
    normals = []
    subtotals = []
    totals = []
    
    # 텍스트를 검사하여 데이터 분류
    for x in contains_values:
        val_str = str(x[1])
        if val_str == '총합계':
            totals.append(x)
        elif '부분합]' in val_str or '부분합' in val_str:
            subtotals.append(x)
        else:
            normals.append(x)
            
    # 각각 지정된 모드(오름차순/내림차순)에 맞춰 개별 정렬 수행
    normals = list(sorted(normals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    subtotals = list(sorted(subtotals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    totals = list(sorted(totals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    
    # 순서 강제 조립: 일반 데이터 -> 부분합계 -> 총합계 순으로 무조건 고정
    result = normals + subtotals + totals
    
    # NULL 값들(빈칸)은 표의 맨 마지막으로 보냄
    values_idx = [x[0] for x in result]
    result.extend([x for x in alist if x[0] not in values_idx])
    
    return result


class WindowResults(QTableView, QMenu):
    """
    Window with calculation results
    """

    def __init__(self, parent=None):
        super(WindowResults, self).__init__(parent)
        self.setSortingEnabled(True)
        self.setObjectName("result")
        self.verticalHeader().setSortIndicatorShown(True)
        self.clicked.connect(self._selectAll)

    def contextMenuEvent(self, event):
        """
        Right click in the results table
        """
        self.menu = QMenu(self)
        copyCellContentAction = QAction('Copy cell content', self)
        selectionIndex = self.indexAt(event.pos())                                       # Get the index at the position of the right click event
        if selectionIndex.row() in [0, -1] or selectionIndex.column() in [0, -1]:             # Don't do anyting if row or column header is clicked
            return
        selectedCell = str(self.indexAt(event.pos()).data())                        # Get the content of the cell on right click
        copyCellContentAction.triggered.connect(lambda: CoordinateToolGroupStats().copyCellContent(selectedCell))
        self.menu.addAction(copyCellContentAction)
        self.selectionModel().select(selectionIndex, QItemSelectionModel.ClearAndSelect)        # Clear any selection in the table and select the single cell that has been clicked
        self.menu.popup(QCursor.pos())

    def selectionCommand(self, index, event=None):
        """
        Implementation of the original method - adds selection of entire rows and columns when the table header is selected
        """
        flag = super(WindowResults, self).selectionCommand(index, event)        # calling the original method
        test = None        
        if self.model():
            test = self.model().data(index, Qt.UserRole+1)                         # checking the selected cell type
        if test == "row":
            return flag | QItemSelectionModel.Rows
        elif test == "column":
            return flag | QItemSelectionModel.Columns
        else:
            return flag


    def _selectAll(self, index):
        """
        Select or deselect all data when clicked in the corner of the table
        """
        test = self.model().data(index, Qt.UserRole+1)                      # checking the selected cell type
        if test not in ("data", "row", "column"):                           # checking if the corner
            if self.selectionModel().isSelected(index):                        # if the corner is selected, it also marks all dataa
                self.selectAll()
            else:
                self.clearSelection()                                          # deselects all data


class Calculations(QObject):                   # finished
    """
    A class that suppresses functions that perform statistical calculations
    """

    def __init__(self, parent):                                                                     # List with ID, name and calculating function
        super(Calculations, self).__init__(parent)

                                                                                                    # Do not change the function ID! (used for conditions)
        self.list = {0:(QCoreApplication.translate('Calculations','sum'), self.sum),
                     1:(QCoreApplication.translate('Calculations','count'), self.count),
                     2:(QCoreApplication.translate('Calculations','average'), self.average),
                     3:(QCoreApplication.translate('Calculations','variance'), self.variance),
                     4:(QCoreApplication.translate('Calculations','stand.dev.'), self.stand_dev),
                     5:(QCoreApplication.translate('Calculations','median'), self.median),
                     6:(QCoreApplication.translate('Calculations','min'), self.minimum),
                     7:(QCoreApplication.translate('Calculations','max'), self.maximum),
                     8:(QCoreApplication.translate('Calculations','unique'), self.unique)}

        self.textList = (0, 6, 7, 8)                                                                        # Calculations also working on text

        self.textNames = ''
        for i in self.textList:
            self.textNames = self.textNames + self.list[i][0] + ', '

        self.textNames = self.textNames[:-2]

    def count(self, result):
        return len(result)

    def sum(self, result):
        return sum(result)

    def average(self, result):
        return self.sum(result)/self.count(result)

    def variance(self, result):
        _variance = 0
        for x in result:
            _variance = _variance + (x-self.average(result))**2
        return _variance/self.count(result)

    def stand_dev(self, result):
        return sqrt(self.variance(result))

    def median(self, result):
        result.sort()
        count = self.count(result)
        if count == 1:
            median = result[0]
        else:
            position = int(count / 2)
            if count%2 == 0:
                median = (result[position]+result[position-1])/2
            else:
                median = result[position]
        return median

    def minimum(self, result):
        return min(result)

    def maximum(self, result):
        return max(result)

    def unique(self, result):
        return len(set(result))

