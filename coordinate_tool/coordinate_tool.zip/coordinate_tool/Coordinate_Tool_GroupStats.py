# -*- coding: utf-8 -*-
"""
QGIS Pivot Table / GroupStats Plugin
====================================
이 모듈은 QGIS 환경에서 레이어의 속성 데이터를 불러와
엑셀 형태의 피벗 테이블(행, 열, 값, 계산식)을 동적으로 생성하고,
결과를 화면에 출력하거나 외부 엑셀(XLSX) 및 메모리 레이어로 내보내는 기능을 수행합니다.
"""

from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import (QGroupBox, QRadioButton, QApplication, QFileDialog, QMainWindow, 
                             QMessageBox, QTableView, QWidget, QMenu, QAction, QLabel, QVBoxLayout, 
                             QDialog, QListWidget, QListWidgetItem, QLineEdit, QComboBox, QPushButton, 
                             QHBoxLayout, QTabWidget, QInputDialog, QCompleter)
from qgis.core import *
from qgis.gui import *

import os, sys, pickle, math, platform, subprocess

VERSION = Qgis.QGIS_VERSION_INT
full_version = Qgis.QGIS_VERSION
QGIS_VERSION = f"QGIS {full_version.split('-')[0]}"  # '3.40.6'
# python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
python_path = f"C:/Program Files/{QGIS_VERSION}/bin/python.exe"

try:
    from openpyxl import Workbook
except:

    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'openpyxl'])
    else:
        try:
            subprocess.check_call(['python', '-m', 'pip', 'install', 'openpyxl', '--no-cache-dir'])
        except subprocess.CalledProcessError as e:
            print("pip 설치 실패. 코드:", e.returncode)
    from openpyxl import Workbook

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/Coordinate_Tool_groupstats.ui'))

class CoordinateToolGroupStats(QMainWindow):
    """
    피벗 테이블 플러그인의 메인 GUI 창을 제어하는 클래스입니다.
    
    [주요 구성 요소]
    - self.tm1: 사용 가능한 원본 필드 목록 모델
    - self.tm2: 행(Rows) 영역 모델
    - self.tm3: 열(Columns) 영역 모델
    - self.tm4: 값(Values) 영역 모델
    - self.tm5: 최종 계산 결과가 담기는 행렬(Result) 모델
    """
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.ui = FORM_CLASS()
        self.ui.setupUi(self)

        # --- 새로 추가할 부분: 창을 항상 최상단에 고정 ---
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.ui.result = WindowResults(self.ui.centralwidget)
        self.ui.horizontalLayout.addWidget(self.ui.result)
        
        self.calculations = Calculations(self)

        # 레이어별 캐싱 데이터를 보관할 딕셔너리 생성
        self.all_layers_cache = {}

        self.ui.listHalf.setAcceptDrops(True)
        self.ui.listHalf.setModelColumn(2)

        self.ui.rows.setAcceptDrops(True)
        self.ui.columns.setAcceptDrops(True)
        self.ui.values.setAcceptDrops(True)

        self.ui.calculate.clicked.connect(self.showScore)
        self.ui.refresh.clicked.connect(self.refreshLayerData)
        self.ui.clear.clicked.connect(self.clearChoice)
        self.ui.filterButton.clicked.connect(self.setFilter)
        self.ui.filter_del.clicked.connect(self.delFilter)
        self.ui.layer.currentIndexChanged.connect(self.layerSelection)   

        dictionary =  {'attributeTxt':[('Rejon',1), ('Posterunek',2)],
                    'countAttributes':[('Moc stacji', 3)],
                    # 'geometry':[('Length', 1), ('Area', 2)],
                    'calculations':[('Count', 1), ('Sum', 2), ('Average', 3), ('Standard deviation', 4)]}

        self.tm1 = ModelListaPol(self)
        self.ui.listHalf.setModel(self.tm1)

        self.tm2 = ModelRowsColumns(self)
        #tm2.ustawInneModele(tm1)
        self.ui.rows.setModel(self.tm2)

        self.tm3 = ModelRowsColumns(self)
        #tm3.ustawInneModele(tm1)
        self.ui.columns.setModel(self.tm3)

        self.tm4 = ValueModel(self)
        self.ui.values.setModel(self.tm4)

        self.tm2.setOtherModels(self.tm3, self.tm4)
        self.tm3.setOtherModels(self.tm2, self.tm4)
        self.tm4.setOtherModels(self.tm2, self.tm3)

        self.tm2.rowsInserted.connect(self.blockCalculations)
        self.tm3.rowsInserted.connect(self.blockCalculations)   
        self.tm4.rowsInserted.connect(self.blockCalculations)   
        self.tm2.rowsRemoved.connect(self.blockCalculations)   
        self.tm3.rowsRemoved.connect(self.blockCalculations)   
        self.tm4.rowsRemoved.connect(self.blockCalculations)   
        self.ui.actionCopy.triggered.connect(self.duplication)   
        self.ui.actionCopySelected.triggered.connect(self.copyMarked)   
        self.ui.actionSaveExcel.triggered.connect(self.exportToExcel)   
        self.ui.actionSaveExcelSelected.triggered.connect(self.exportMarkedToExcel)
        self.ui.actionExport.triggered.connect(self.exportToLayer)
        self.ui.actionShowPanel.triggered.connect(self.showControlPanel)   
        self.ui.actionShowOnMap.triggered.connect(self.showOnMap)   

        self.ui.duplication.clicked.connect(self.duplication)

        # --- 더블클릭 이벤트 ---
        self.ui.listHalf.doubleClicked.connect(self.addFieldFromList)
        self.ui.rows.doubleClicked.connect(self.removeItemFromList)
        self.ui.columns.doubleClicked.connect(self.removeItemFromList)
        self.ui.values.doubleClicked.connect(self.removeItemFromList)
        
        self.ui.result.verticalHeader().sortIndicatorChanged.connect(self.sortRows)   

    #     # --- 새로 추가: 합계 체크박스 상태 변경 시 실시간 테이블 업데이트 ---
    #     if hasattr(self.ui, 'showTotalBottom_checkBox'):
    #         self.ui.showTotalBottom_checkBox.stateChanged.connect(self.update_totals_if_calculated)
    #     if hasattr(self.ui, 'showTotalRight_checkBox'):
    #         self.ui.showTotalRight_checkBox.stateChanged.connect(self.update_totals_if_calculated)
    #     if hasattr(self.ui, 'showSubtotal_checkBox'):
    #         self.ui.showSubtotal_checkBox.stateChanged.connect(self.update_totals_if_calculated)

    # def update_totals_if_calculated(self, *args, **kwargs):
    #         """
    #         체크박스 상태가 변경될 때, 결과 테이블이 화면에 띄워져 있다면 즉시 표를 다시 그립니다.
    #         """
    #         if self.ui.result.model() is not None:
    #             self.showScore()

    def closeEvent(self, event):
        """
        창이 닫힐 때 자동으로 실행되는 이벤트 함수입니다. 
        여기서 기존 정보를 모두 초기화합니다.
        """
        # 1. 다중 캐싱을 위해 만든 딕셔너리 및 변수 완전 초기화
        self.all_layers_cache = {}
        self.cached_features = []
        
        # 2. 결과 모델 및 테이블 초기화 (기존에 만드신 함수 재사용)
        self.clearChoice()
        
        # 3. 레이어 선택 콤보박스 초기화 (첫 번째 항목으로 돌리거나 선택 해제)
        self.ui.layer.setCurrentIndex(-1)
        
        # 4. 기타 UI 설정값 초기화 (필요한 것만 선택적으로 적용하세요)
        self.ui._filter.setPlainText('')
        
        if hasattr(self.ui, 'onlySelected'):
            self.ui.onlySelected.setChecked(False)
            
        if hasattr(self.ui, 'useNULL'):
            self.ui.useNULL.setChecked(False)
            
        # 상태 표시줄 초기화
        self.statusBar().showMessage("")
        
        # 정상적으로 창 닫기(숨기기) 이벤트 진행
        event.accept()

    def sortRows(self, row, mode):
            self.ui.result.model().sortRows(row, mode)

    def addFieldFromList(self, index):
        """
        필드 목록에서 항목을 더블클릭하면 
        일반 속성은 '행(Rows)'으로, 함수는 '열(Columns)'로 자동 삽입합니다.
        """
        if not index.isValid():
            return
            
        # 1. 클릭한 항목의 데이터 가져오기 (타입, 이름, ID 추출)
        field_data = self.tm1._data[index.row()]
        field_type = field_data[0]
        field_name = field_data[1]
        
        # 2. 이동할 대상 지정 (함수면 열, 그 외 일반 필드면 행)
        if field_type == 'calculations':
            target_model = self.tm3  # 열(Columns) 모델
            target_name_str = "열(Columns)"
        else:
            # --- 필드 타입(문자/숫자) 판별 로직 예시 ---
            if field_type == 'attributeTxt':
                target_model = self.tm2  # 행(Rows) 모델
                target_name_str = "행(Rows)"
            else:
                target_model = self.tm4  # 값(Value) 모델
                target_name_str = "값(Value)"

        # 3. 중복 추가 방지 방어 로직
        if field_data in target_model._data:
            self.statusBar().showMessage(f"'{field_name}' 항목은 이미 {target_name_str}에 있습니다.", 3000)
            return
            
        # (선택) 함수가 여러 번 중복 사용되는 것을 막는 방어 로직
        if field_type == 'calculations':
            # 타겟이 열(tm3)이므로, 행(tm2)과 값(tm4) 영역에 다른 함수가 있는지 검사
            other_areas_types = [x[0] for x in self.tm2._data + self.tm4._data]
            if 'calculations' in other_areas_types:
                self.statusBar().showMessage("함수는 한 영역에서만 사용할 수 있습니다.", 3000)
                return
                
        # 4. 대상 모델의 맨 마지막 줄에 데이터 삽입
        target_model.insertRows(target_model.rowCount(), 1, QModelIndex(), [field_data])
        self.statusBar().showMessage(f"'{field_name}' 항목이 {target_name_str}에 추가되었습니다.", 3000)

    def removeItemFromList(self, index):
        """
        행, 열, 값 리스트에서 더블 클릭한 항목을 즉시 삭제합니다.
        """
        sender_view = self.sender() # 더블클릭 이벤트가 발생한 창(리스트 뷰)을 찾음
        if sender_view and index.isValid():
            model = sender_view.model()
            if model:
                model.removeRow(index.row()) # 모델에서 해당 항목 삭제
                self.statusBar().showMessage("항목이 삭제되었습니다.", 3000)

    def blockCalculations(self, x, y, z):
        """값 영역에 필드가 들어오면 계산 버튼을 활성화합니다."""
        values = self.tm4._data
        
        # 값 영역에 데이터가 1개 이상 있으면 버튼 활성화
        if len(values) > 0:
            self.ui.calculate.setEnabled(True)
        else:
            self.ui.calculate.setEnabled(False)

    def showScore(self):
        "계산을 수행하고 결과를 화면에 표시합니다."
        # =====================================================================
        # [PHASE 1] 사용자 설정값 읽기 및 기본 연산식 세팅
        # =====================================================================
        chosenRows = tuple(self.tm2._data)
        chosenColumns = tuple(self.tm3._data)
        chosenValues = tuple(self.tm4._data)

        # 1. 값 영역의 속성 필드 추출
        value_fields = [x for x in chosenValues if x[0] != 'calculations']
        if not value_fields:
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', '계산할 값 필드를 먼저 추가해 주세요.'), 5000)
            return

        # 2. 행/열/값 영역에서 계산식(Function) 모두 추출
        calc_items = [x for x in chosenColumns + chosenRows + chosenValues if x[0] == 'calculations']
        if not calc_items:
            calc_items = [('calculations', 'sum', 0)] # 기본값: sum

        chosenRows_no_calc = [x for x in chosenRows if x[0] != 'calculations']
        chosenCols_no_calc = [x for x in chosenColumns if x[0] != 'calculations']

        # 3. 특수 NULL 값 판별 헬퍼 함수
        def is_null_val(val):
            if val is None: return True
            if isinstance(val, QVariant) and val.isNull(): return True
            s = str(val).strip()
            return s == '' or s.upper() == 'NULL' or 'QPyNullVariant' in s

        # 4. 값 추출 람다 함수 생성
        valueFunctions = []
        for val in value_fields:
            if val[0] == 'attributeTxt':
                valueFunctions.append(lambda _obj, idx=val[2]: _obj['attributes'][idx])
            elif val[0] == 'countAttributes':
                valueFunctions.append(
                    lambda _obj, idx=val[2]: None if is_null_val(_obj['attributes'][idx]) else (
                        float(_obj['attributes'][idx].value()) if isinstance(_obj['attributes'][idx], QVariant) else float(_obj['attributes'][idx])
                    )
                )
        # =====================================================================
        # [PHASE 2] QGIS 원본 데이터 필터링 및 1차 캐싱 수집
        # =====================================================================
        index = self.ui.layer.currentIndex()
        layerId = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(layerId)

        _filter = self.ui._filter.toPlainText()
        valid_ids = None

        if _filter:
            # 속성(Attributes)과 도형(Geometry)을 모두 제외하고 오직 ID만 가장 빠르게 찾도록 세팅
            request = QgsFeatureRequest().setFilterExpression(_filter).setFlags(QgsFeatureRequest.NoGeometry).setNoAttributes()
            
            # 레이어를 거치지 않고 provider를 통해 다이렉트로 ID만 수집
            valid_ids = set([f.id() for f in layer.dataProvider().getFeatures(request)])

        onlySelected = self.ui.onlySelected.isChecked()
        selectedObjects = layer.selectedFeatureIds() if onlySelected else []

        result = {}
        numberOfObjects = len(self.cached_features)
        counter = 0
        NULLcounter = 0
        use_null = self.ui.useNULL.isChecked()

        # 5. 1차 데이터 집계 (NULL 값 완전 필터링)
        for f_dict in self.cached_features:
            f_id = f_dict['id']

            if onlySelected and f_id not in selectedObjects:
                continue
            if valid_ids is not None and f_id not in valid_ids:
                continue

            has_null_key = False
            key_column = []
            for k in chosenCols_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_column.append('' if is_null_val(attr_val) else attr_val)

            key_row = []
            for k in chosenRows_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_row.append('' if is_null_val(attr_val) else attr_val)

            vals_to_calc = [vf(f_dict) for vf in valueFunctions]
            all_null_values = all(is_null_val(v) for v in vals_to_calc)

            if not use_null and (has_null_key or all_null_values):
                NULLcounter += 1
                continue

            key = (tuple(key_row), tuple(key_column))
            
            if key in result:
                result[key][0].append(vals_to_calc)
                result[key][1].append(f_id)
            else:
                result[key] = [[vals_to_calc], [f_id]]

            counter += 1
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats','데이터 분류 중... ') + '%.0f%%' % ((float(counter)/float(numberOfObjects))*100))

        self.statusBar().showMessage('총합계 및 테이블 생성 중...')

        # 6. UI 옵션 변수 연동
        enable_bottom_total = self.ui.showTotalBottom_checkBox.isChecked() if hasattr(self.ui, 'showTotalBottom_checkBox') else True
        enable_right_total = self.ui.showTotalRight_checkBox.isChecked() if hasattr(self.ui, 'showTotalRight_checkBox') else True
        enable_subtotal = self.ui.showSubtotal_checkBox.isChecked() if hasattr(self.ui, 'showSubtotal_checkBox') else True

        num_val_fields = len(value_fields)
        num_calcs = len(calc_items)
        has_rows = len(chosenRows_no_calc) > 0
        has_cols = len(chosenCols_no_calc) > 0

        # 무의미한 열(가로) 합계 방지 방어 로직
        add_col_total_key = enable_right_total and has_cols
        add_extra_total_cols = enable_right_total and (num_val_fields >= 2)

        # 행/열 구조 생성 및 부분합계/총합계 키 추가
        keys = result.keys()
        # --- 새로 추가된 부분: 문자와 숫자가 섞여 있어도 에러 없이 정렬하는 헬퍼 함수 ---
        def sorting_key(tup):
            key_list = []
            for val in tup:
                if val is None or str(val).strip() == '':
                    key_list.append((2, str(val))) # 빈칸은 맨 뒤로 배치
                else:
                    try:
                        key_list.append((0, float(val))) # 숫자는 맨 앞으로, 크기순 정렬
                    except (ValueError, TypeError):
                        key_list.append((1, str(val))) # 문자는 그 다음, 가나다순 정렬
            return tuple(key_list)

        # 헬퍼 함수를 적용하여 깔끔하게 오름차순 정렬된 상태로 리스트 생성
        base_rows = sorted(list(set([z[0] for z in keys])), key=sorting_key)
        kolu = sorted(list(set([z[1] for z in keys])), key=sorting_key)

        subtotal_rows = set()
        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for i in range(1, len(chosenRows_no_calc)):
                    sub_key = list(r)
                    sub_key[i] = f"[{r[i-1]} 부분합]"
                    for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                    subtotal_rows.add(tuple(sub_key))
        subtotal_rows = list(subtotal_rows)

        # ROW_TOTAL_KEY = tuple(['총합계'] + [''] * (len(chosenRows_no_calc) - 1)) if has_rows else ()
        # COL_TOTAL_KEY = tuple(['행합계'] + [''] * (len(chosenCols_no_calc) - 1)) if has_cols else ()

        # --- 새로 추가: 선택된 함수에 따라 총합계 텍스트를 다르게 표시 ---
        if len(calc_items) == 1:
            f_name = calc_items[0][1]
            if f_name == 'sum': dynamic_total = '총합계'
            elif f_name == 'count': dynamic_total = '총 개수'
            elif f_name == 'unique': dynamic_total = '총 고유값'
            elif f_name == 'average': dynamic_total = '전체 평균'
            else: dynamic_total = f"전체 {f_name}"
        else:
            dynamic_total = '전체 요약' # 함수를 2개 이상 섞어 쓸 경우

        # 기존의 하드코딩된 '총합계' 대신 dynamic_total 변수를 사용합니다.
        ROW_TOTAL_KEY = tuple([dynamic_total] + [''] * (len(chosenRows_no_calc) - 1)) if has_rows else ()
        COL_TOTAL_KEY = tuple(['행합계'] + [''] * (len(chosenCols_no_calc) - 1)) if has_cols else ()

        rows = base_rows[:]
        if enable_subtotal: rows.extend(subtotal_rows)
        if enable_bottom_total and has_rows: rows.append(ROW_TOTAL_KEY)

        columns = kolu[:]
        if add_col_total_key: columns.append(COL_TOTAL_KEY)

        raw_matrix = {r: {c: [] for c in columns} for r in rows}
        id_matrix = {r: {c: [] for c in columns} for r in rows}

        # 7. 데이터 2차 재배치 (부분합계, 총합계 긁어모으기)
        # 7-1. 원본 데이터
        for x in keys:
            r_key, c_key = x[0], x[1]
            raw_matrix[r_key][c_key].extend(result[x][0])
            id_matrix[r_key][c_key].extend(result[x][1])

        # 7-2. 행 부분합계 데이터
        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for c in kolu:
                    for i in range(1, len(chosenRows_no_calc)):
                        sub_key = list(r)
                        sub_key[i] = f"[{r[i-1]} 부분합]"
                        for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                        sub_key = tuple(sub_key)
                        raw_matrix[sub_key][c].extend(raw_matrix[r][c])
                        id_matrix[sub_key][c].extend(id_matrix[r][c])

        # 7-3. 가로 방향(열 범주 전체) 합계 데이터
        if add_col_total_key:
            for r in base_rows + (subtotal_rows if enable_subtotal else []):
                for c in kolu:
                    raw_matrix[r][COL_TOTAL_KEY].extend(raw_matrix[r][c])
                    id_matrix[r][COL_TOTAL_KEY].extend(id_matrix[r][c])

        # 7-4. 세로 방향(밑바닥 전체) 합계 데이터
        if enable_bottom_total and has_rows:
            cols_to_sum = kolu[:]
            if add_col_total_key: cols_to_sum.append(COL_TOTAL_KEY)
            for c in cols_to_sum:
                for r in base_rows: # 중복 방지를 위해 원본(base_rows)만 합산
                    raw_matrix[ROW_TOTAL_KEY][c].extend(raw_matrix[r][c])
                    id_matrix[ROW_TOTAL_KEY][c].extend(id_matrix[r][c])

        # 8. 데이터 행렬(Matrix) 생성 및 계산식 적용
        rowDictionary = {row: nr for nr, row in enumerate(rows)}
        columnDictionary = {col: nr for nr, col in enumerate(columns)}

        cols_count = len(columns) if len(columns) > 0 else 1
        extra_cols = num_calcs if add_extra_total_cols else 0
        total_normal_cols = cols_count * num_val_fields * num_calcs

        data = []
        for x in range(len(rows)):
            data.append([['', []] for _ in range(total_normal_cols + extra_cols)])

        for r in rows:
            for c in (columns if len(columns) > 0 else [()]):
                nrw = rowDictionary[r]
                nrk = columnDictionary[c] if len(columns) > 0 else 0

                cell_raw_data = raw_matrix[r][c] if len(columns) > 0 else raw_matrix[r][()]
                cell_ids = id_matrix[r][c] if len(columns) > 0 else id_matrix[r][()]

                for v_idx in range(num_val_fields):
                    raw_values = [row[v_idx] for row in cell_raw_data]
                    valid_values = []

                    for v in raw_values:
                        if is_null_val(v):
                            if use_null: valid_values.append(0.0)
                        else:
                            try:
                                valid_values.append(float(v))
                            except (ValueError, TypeError):
                                valid_values.append(str(v))

                    for c_idx, calc in enumerate(calc_items):
                        calc_id = calc[2]
                        calc_name = calc[1]

                        calc_vals = valid_values
                        if calc_name not in ('count', 'unique'):
                            calc_vals = [v for v in valid_values if isinstance(v, (int, float))]

                        if not calc_vals and calc_name not in ('count', 'unique'):
                            s = ''
                        else:
                            try:
                                s = self.calculations.list[calc_id][1](calc_vals)
                            except Exception:
                                s = ''

                        col_idx = nrk * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
                        data[nrw][col_idx] = [s, cell_ids]

        # # ==============================================================================
        # # [새로 추가할 부분] 8.5. 총합계 및 부분합계 시각적 단순 합산(강제 덮어쓰기)
        # # 통계적/수학적 의미(unique, avg 등)를 무시하고 눈에 보이는 숫자를 그대로 더합니다.
        # # ==============================================================================
        
        # # A. 세로 방향(부분합계) 덮어쓰기 (일반 데이터 행만 더함)
        # if enable_subtotal and subtotal_rows:
        #     for sub_r in subtotal_rows:
        #         r_idx = rowDictionary[sub_r]
        #         level = -1
        #         for i, val in enumerate(sub_r):
        #             if isinstance(val, str) and ' 부분합]' in val:
        #                 level = i
        #                 break
                
        #         # 현재 부분합에 속하는 하위 일반 데이터(base_rows) 찾기
        #         matching_base_rows = [b_r for b_r in base_rows if b_r[:level] == sub_r[:level]]
                
        #         for c in kolu:
        #             c_i = columnDictionary[c]
        #             for v_idx in range(num_val_fields):
        #                 for c_idx, calc in enumerate(calc_items):
        #                     target_idx = c_i * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
        #                     sum_val = 0.0
        #                     has_num = False
        #                     for b_r in matching_base_rows:
        #                         val = data[rowDictionary[b_r]][target_idx][0]
        #                         if isinstance(val, (int, float)):
        #                             sum_val += val
        #                             has_num = True
        #                     data[r_idx][target_idx][0] = round(sum_val, 4) if has_num else ''

        # # B. 세로 방향(맨 밑바닥 총합계) 덮어쓰기 (일반 데이터 행 전체를 더함)
        # if enable_bottom_total and has_rows:
        #     r_idx = rowDictionary[ROW_TOTAL_KEY]
        #     for c in kolu:
        #         c_i = columnDictionary[c]
        #         for v_idx in range(num_val_fields):
        #             for c_idx, calc in enumerate(calc_items):
        #                 target_idx = c_i * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
        #                 sum_val = 0.0
        #                 has_num = False
        #                 for b_r in base_rows:
        #                     val = data[rowDictionary[b_r]][target_idx][0]
        #                     if isinstance(val, (int, float)):
        #                         sum_val += val
        #                         has_num = True
        #                 data[r_idx][target_idx][0] = round(sum_val, 4) if has_num else ''

        # # C. 가로 방향(우측 끝 행합계) 덮어쓰기 (위에서 덮어쓴 행을 포함하여 모든 행에 대해 가로로 더함)
        # if add_col_total_key:
        #     col_total_idx = columnDictionary[COL_TOTAL_KEY]
        #     for r in rows:
        #         r_idx = rowDictionary[r]
        #         for v_idx in range(num_val_fields):
        #             for c_idx, calc in enumerate(calc_items):
        #                 target_idx = col_total_idx * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
        #                 sum_val = 0.0
        #                 has_num = False
        #                 for normal_c in kolu:
        #                     c_i = columnDictionary[normal_c]
        #                     source_idx = c_i * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
        #                     val = data[r_idx][source_idx][0]
        #                     if isinstance(val, (int, float)):
        #                         sum_val += val
        #                         has_num = True
        #                 data[r_idx][target_idx][0] = round(sum_val, 4) if has_num else ''
        # # ==============================================================================


        # 값 필드가 2개 이상일 때 나타나는 우측 끝 궁극의 크로스 합계
        if add_extra_total_cols:
            for r_idx, r in enumerate(rows):
                for c_idx, calc in enumerate(calc_items):
                    row_val = 0.0
                    has_num = False
                    
                    if add_col_total_key:
                        col_key_idx = columnDictionary[COL_TOTAL_KEY]
                        start_col = col_key_idx * (num_val_fields * num_calcs)
                        indices_to_sum = [start_col + v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    else:
                        indices_to_sum = [v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    
                    for i in indices_to_sum:
                        val = data[r_idx][i][0]
                        if isinstance(val, (int, float)):
                            row_val += val
                            has_num = True
                            
                    target_col_idx = total_normal_cols + c_idx
                    if has_num:
                        data[r_idx][target_col_idx] = [round(row_val, 4), []]
                    else:
                        data[r_idx][target_col_idx] = ['', []]

        # 9. 헤더(이름표) 동적 생성
        atr = {i: layer.fields().at(i) for i in range(layer.fields().count())}

        rowNames = [atr[x[2]].name() for x in chosenRows_no_calc]
        colNames = [atr[x[2]].name() for x in chosenCols_no_calc]
        valNames = [f"{atr[val[2]].name()} {calc[1]}" for val in value_fields for calc in calc_items]

        columns1 = []
        if len(columns) > 0 and len(columns[0]) > 0:
            for c in columns:
                if c == COL_TOTAL_KEY:
                    for vname in valNames:
                        columns1.append(tuple(['행합계'] + [''] * (len(chosenCols_no_calc) - 1) + [vname]))
                else:
                    for vname in valNames:
                        columns1.append(c + (vname,))
        else:
            columns1 = [(vname,) for vname in valNames]

        if add_extra_total_cols:
            for calc in calc_items:
                calc_name = calc[1]
                header_len = len(columns1[0]) if len(columns1) > 0 else 1
                if header_len > 1:
                    extra_header = tuple(['행합계'] + [''] * (header_len - 2) + [f"전체 {calc_name}"])
                else:
                    extra_header = (f"총합계 {calc_name}",)
                columns1.append(extra_header)

        rows1 = rows

        self.rows = len(rows1[0]) if len(rows1) > 0 else 0
        self.columns = len(columns1[0]) if len(columns1) > 0 else 0

        if len(rows1) > 0 and len(rows1[0]) > 0:
            rows1.insert(0, tuple(rowNames))
        if len(columns1) > 0 and len(columns1[0]) > 0:
            columns1.insert(0, tuple(colNames) + ("값(Value)",))

        if len(rows1) > 0 and len(columns1) > 0:
            self.ui.result.setUpdatesEnabled(False)
            self.tm5 = ResultModel(data, rows1, columns1, layer)
            self.ui.result.setModel(self.tm5)

            for i in range(len(columns1[0]), 0, -1):
                self.ui.result.verticalHeader().setSortIndicator(i-1, Qt.AscendingOrder)
            for i in range(len(rows1[0]), 0, -1):
                self.ui.result.horizontalHeader().setSortIndicator(i-1, Qt.AscendingOrder)

            statement = self.statusBar().currentMessage()
            percent = 100.00 / self.tm5.columnCount()
            counter = 0
            for i in range(self.tm5.columnCount()):
                self.ui.result.resizeColumnToContents(i)
                counter += percent
                self.statusBar().showMessage(statement + '%.0f%%' % (counter))

            self.ui.result.setUpdatesEnabled(True)
            self.ui.result.doubleClicked.connect(lambda index: self.showOnMap())
            self.ui.result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged())

            msg = "계산 완료."
            if NULLcounter > 0 and not use_null:
                msg += f" (NULL 객체 {NULLcounter}개 제외됨)"
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', msg), 20000)

        else:
            try:
                del(self.tm5)
            except AttributeError:
                pass
            self.ui.result.setModel(None)
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats','조건에 맞는 데이터를 찾을 수 없습니다.'), 10000)

    def setLayers (self, layer):   #finished
        "레이어 콤보박스에 사용 가능한 레이어를 추가합니다."

        index = self.ui.layer.currentIndex()
        if index !=-1:
            layerId = self.ui.layer.itemData(index)     # 이전에 선택했던 레이어의 ID 보관

        self.ui.layer.blockSignals(True)
        self.ui.layer.clear()                           # 콤보박스를 새로운 레이어 목록으로 채움
        # layer.sort(key=lambda x: x[0].lower())

        # --- 새로 추가된 부분: 맨 위에 빈 항목(기본값) 추가 ---
        self.ui.layer.addItem("레이어를 선택하세요...", None)

        for i in layer:
            self.ui.layer.addItem(i[0], i[1])

        if index !=-1:
            index2 = self.ui.layer.findData(layerId)
            if index2 !=-1:
                self.ui.layer.setCurrentIndex(index2)
            else:
                self.ui.layer.setCurrentIndex(0) # 첫 번째 빈 항목 선택
                self.layerSelection(0)
        else:
            self.ui.layer.setCurrentIndex(0) # 첫 번째 빈 항목 선택
            self.layerSelection(0)
        self.ui.layer.blockSignals(False)

    def exportToLayer(self):
        """
        계산된 피벗 테이블 결과를 도형이 없는 QGIS 메모리 테이블 레이어로 생성합니다.
        """
        if not hasattr(self, 'tm5') or self.tm5 is None:
            QMessageBox.information(self, QCoreApplication.translate('GroupStats','알림'), "출력할 데이터가 없습니다.")
            return

        # 1. 빈 메모리 레이어 생성 (도형 없는 속성 테이블 전용)
        layer_name = "피벗테이블_결과"
        mem_layer = QgsVectorLayer("None", layer_name, "memory")
        pr = mem_layer.dataProvider()

        offsetX = self.tm5.offsetX
        offsetY = self.tm5.offsetY
        numberOfRows = self.tm5.rowCount()
        numberOfColumns = self.tm5.columnCount()

        field_names = []
        fields = []

        # 2. 필드(컬럼) 구성하기
        for j in range(numberOfColumns):
            if j < offsetX:
                # [좌측] 행 속성 이름 (예: 일정분배, 담당 등)
                name = str(self.tm5.createIndex(offsetY - 1, j).data() or "").strip()
                if not name: name = f"Field_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.String))
            else:
                # [우측] 열(피벗) 속성 이름 조합 (예: 광주_count, 광주_sum)
                name_parts = []
                for i in range(offsetY):
                    part = str(self.tm5.createIndex(i, j).data() or "").strip()
                    if part: name_parts.append(part)
                name = "_".join(name_parts)
                if not name: name = f"Value_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.Double)) # 계산을 위해 실수형(Double)으로 지정

        pr.addAttributes(fields)
        mem_layer.updateFields()

        # 3. 데이터(행) 채워 넣기
        features = []
        for i in range(offsetY, numberOfRows):
            feat = QgsFeature()
            attrs = []
            for j in range(numberOfColumns):
                val = self.tm5.createIndex(i, j).data()
                if val is None or str(val).strip() == "":
                    attrs.append(None) # 빈 칸은 NULL 처리
                else:
                    if j < offsetX:
                        attrs.append(str(val)) # 이름은 문자로
                    else:
                        try:
                            attrs.append(float(val)) # 값은 숫자로 변환
                        except ValueError:
                            attrs.append(str(val)) # 변환 실패 시 문자로 안전하게 삽입
            feat.setAttributes(attrs)
            features.append(feat)

        # 4. 레이어를 QGIS 화면에 추가
        pr.addFeatures(features)
        mem_layer.updateExtents()
        QgsProject.instance().addMapLayer(mem_layer)
        
        self.statusBar().showMessage("결과가 레이어 패널에 '피벗테이블_결과'로 추가되었습니다.", 10000)


    def refreshLayerData(self):
        """
        설정된 행/열/값 선택을 유지한 채 레이어의 데이터만 새로 불러와 결과를 갱신합니다.
        """
        index = self.ui.layer.currentIndex()
        if index == -1:
            return
            
        idW = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(idW)
        if not layer:
            return
            
        self.statusBar().showMessage("레이어 데이터를 새로고침 하는 중입니다. 잠시만 기다려주세요...")
        QCoreApplication.processEvents() # UI 멈춤 방지
        
        # 1. 기존 선택을 비우지 않고, 데이터(캐시)만 QGIS에서 다시 읽어와 덮어쓰기
        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        provider = layer.dataProvider()
        self.cached_features = [
            {
                'id': f.id(),
                'attributes': f.attributes()
            }
            for f in provider.getFeatures(request)
        ]
        self.all_layers_cache[idW] = self.cached_features
        
        # 2. 값(Value) 영역에 설정된 필드가 있다면 즉시 재계산(showScore) 실행
        if len(self.tm4._data) > 0:
            self.showScore()
            self.statusBar().showMessage("레이어 정보가 새로고침되고 결과 테이블이 업데이트되었습니다.", 5000)
        else:
            self.statusBar().showMessage("레이어 데이터가 새로고침 되었습니다.", 5000)


    def layerSelection(self, index):     #finished
        # --- 새로 추가할 안전장치 ---
        if index == -1:
            return
        
        idW = self.ui.layer.itemData(index)
        # itemData가 None이면 예외를 방지하기 위해 layer를 None으로 처리
        if idW is None:
            layer = None
        else:
            layer = QgsProject.instance().mapLayer(idW)
        
        # --- 수정된 부분: 레이어가 없는 경우(0번 빈 항목 선택 시) 화면 완전 초기화 ---
        if not layer:
            self.clearChoice() # 1. 행, 열, 값, 결과 테이블 완전 비우기
            try:
                del(self.tm1)
            except AttributeError:
                pass
            self.tm1 = ModelListaPol() # 2. 좌측 필드 목록 및 함수 빈 모델로 덮어쓰기
            self.ui.listHalf.setModel(self.tm1)
            self.statusBar().showMessage("레이어를 선택해 주세요.", 5000)
            return
        
        fields = layer.fields()

        dictionary = {}
        # if layer.geometryType() in (QgsWkbTypes.PointGeometry, QgsWkbTypes.NullGeometry):
        #     dictionary['geometry'] =  []
        # elif layer.geometryType() == QgsWkbTypes.LineGeometry:                             # line
        #     dictionary['geometry'] = [(QCoreApplication.translate('GroupStats','Length'), 1)]
        # elif layer.geometryType() == QgsWkbTypes.PolygonGeometry:                             # polygon
        #     dictionary['geometry'] = [(QCoreApplication.translate('GroupStats','Perimeter'), 1), (QCoreApplication.translate('GroupStats','Area'), 2)]

        dictionary['countAttributes'] = []
        dictionary['attributeTxt'] = []

        for i in range(fields.count()):
            field = fields.at(i)
            if field.isNumeric():
                dictionary['countAttributes'].append((field.name(), i))
            else:
                dictionary['attributeTxt'].append((field.name(), i))

        dictionary['calculations']=[]
        obl = self.calculations.list
        for c,b in obl.items():
            dictionary['calculations'].append((b[0],c))

        del(self.tm1)
        self.tm1 = ModelListaPol()
        self.ui.listHalf.setModel(self.tm1)
        keys = ['calculations']  # geometry
        for i in keys:
            j = dictionary[i]
            j.sort(key=lambda x: x[0].lower())
            rows=[]
            for k, l in j:
                rows.append((i,k,l))
            rows.sort(key=lambda x: x[2])
            self.tm1.insertRows( 0, len(rows), QModelIndex(), rows)
        keys = ['countAttributes', 'attributeTxt']
        rows=[]
        for i in keys:
            j = dictionary[i]
            for k, l in j:
                rows.append((i,k,l))
        # rows.sort(key=lambda x: x[1].lower()) # 필드명 오름차순
        rows.sort(key=lambda x: x[2]) # 필드명 순서대로 나열
        self.tm1.insertRows( 0, len(rows), QModelIndex(), rows)

        self.clearChoice()
        # 딕셔너리에 현재 선택한 레이어 ID(idW)가 이미 저장되어 있는지 확인
        if idW in self.all_layers_cache:
            # 이미 저장된 정보가 있으면 새로 불러오지 않고 즉시 적용
            self.cached_features = self.all_layers_cache[idW]
            self.statusBar().showMessage("레이어 정보 불러오기 완료", 5000)
        else:
            # 1. 데이터를 무식하게 긁어오기 전에, 밀려있는 UI 그리기 작업(창 열기)부터 강제로 실행
            self.statusBar().showMessage("레이어 정보를 가져오는 중입니다. 잠시만 기다려주세요...")
            QCoreApplication.processEvents()

            request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
            provider = layer.dataProvider()

            # 2. 진행률 표시를 위해 레이어의 전체 객체(Feature) 개수 파악
            total_features = provider.featureCount()
            if total_features < 0:
                total_features = layer.featureCount()

            self.cached_features = []
            counter = 0

            # 3. 리스트 컴프리헨션 대신 일반 for문으로 변경하여 중간중간 화면을 갱신
            for f in provider.getFeatures(request):
                self.cached_features.append({
                    'id': f.id(),
                    'attributes': f.attributes()
                })
                counter += 1

                # 4. 너무 잦은 업데이트는 오히려 연산 속도를 떨어뜨리므로 1000개 단위로 갱신
                if counter % 1000 == 0:
                    if total_features > 0:
                        percent = (counter / total_features) * 100
                        self.statusBar().showMessage(f"데이터 불러오는 중... {percent:.1f}% ({counter:,} / {total_features:,})")
                    else:
                        self.statusBar().showMessage(f"데이터 불러오는 중... {counter:,}개 완료")
                    QCoreApplication.processEvents() # 화면이 멈추지(프리징) 않도록 주기적으로 숨통 틔우기

            # 다음 번에 빠르게 불러오기 위해 딕셔너리에 레이어 ID와 함께 저장
            self.all_layers_cache[idW] = self.cached_features
            self.statusBar().showMessage("레이어 속성 정보 불러오기 및 캐시 저장 완료.", 5000)


    def clearChoice(self):             # finished
        "행, 열, 값 창을 지웁니다."
        self.tm2.removeRows(0, self.tm2.rowCount() ,QModelIndex())
        self.tm3.removeRows(0, self.tm3.rowCount() ,QModelIndex())
        self.tm4.removeRows(0, self.tm4.rowCount() ,QModelIndex())
        # 수정된 부분: ResultModel 인스턴스를 삭제하고 테이블 뷰의 모델을 해제하여 비움
        try:
            del(self.tm5)
        except AttributeError:
            pass
        self.ui.result.setModel(None)
        
        self.ui._filter.setPlainText('')


    def showControlPanel(self):     # finished
        self.ui.controlPanel.setVisible(True)

    def delFilter(self):
        self.ui._filter.setPlainText('')

    def setFilter(self):
        """팝업창에서 넘어온 여러 개의 조건을 하나로 묶어 SQL 텍스트로 변환합니다."""
        index = self.ui.layer.currentIndex()
        if index == -1: return
        layerId = self.ui.layer.itemData(index)
        if layerId is None: return
        layer = QgsProject.instance().mapLayer(str(layerId))
        if not layer or layer.fields().count() == 0: return

        dialog = ExcelFilterDialog(layer, self.cached_features, self)
        if dialog.exec_() == QDialog.Accepted:
            conditions_list = dialog.final_conditions
            global_logic = dialog.global_logic  # "AND" 또는 "OR"
            
            sql_parts = []
            
            for filter_data in conditions_list:
                field_name = filter_data['field']
                is_numeric = filter_data['is_numeric']
                expr = ""
                
                if filter_data['null_status'] == 'null':
                    expr = f'"{field_name}" IS NULL'
                elif filter_data['null_status'] == 'not_null':
                    expr = f'"{field_name}" IS NOT NULL'
                
                elif filter_data['null_status'] == 'all':
                    if filter_data['type'] == 'value':
                        vals = [f"{str(v)}" if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'" for v in filter_data['values']]
                        if vals: expr = f'"{field_name}" IN ({", ".join(vals)})'
                    elif filter_data['type'] == 'condition':
                        op, v1_raw, v2_raw = filter_data['op'], filter_data.get('val1',''), filter_data.get('val2','')
                        def fmt(v): return str(v) if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'"
                        v1, v2 = fmt(v1_raw), fmt(v2_raw)
                        
                        if op == "같음 (=)": expr = f'"{field_name}" = {v1}'
                        elif op == "같지 않음 (≠)": expr = f'"{field_name}" != {v1}'
                        elif op == "포함": expr = f'"{field_name}" LIKE \'%{v1_raw}%\''
                        elif op == "포함하지 않음": expr = f'"{field_name}" NOT LIKE \'%{v1_raw}%\''
                        elif op == "시작 문자": expr = f'"{field_name}" LIKE \'{v1_raw}%\''
                        elif op == "종료 문자": expr = f'"{field_name}" LIKE \'%{v1_raw}\''
                        elif op == "초과 (>)": expr = f'"{field_name}" > {v1}'
                        elif op == "미만 (<)": expr = f'"{field_name}" < {v1}'
                        elif op == "이상 (≥)": expr = f'"{field_name}" >= {v1}'
                        elif op == "이하 (≤)": expr = f'"{field_name}" <= {v1}'
                        elif op == "사이 (포함)": expr = f'"{field_name}" >= {v1} AND "{field_name}" <= {v2}'
                        elif op == "사이에 없음 (포함)": expr = f'"{field_name}" < {v1} OR "{field_name}" > {v2}'

                if expr:
                    sql_parts.append(f"({expr})")

            # 생성된 여러 조건의 SQL을 AND 또는 OR로 묶기
            if sql_parts:
                new_full_expr = f" {global_logic} ".join(sql_parts)
                
                # 기존에 텍스트박스에 적혀있던 내용이 있다면, 그 내용과 새로운 묶음을 다시 AND로 결합
                current_text = self.ui._filter.toPlainText().strip()
                if current_text:
                    self.ui._filter.setPlainText(f"({current_text}) AND ({new_full_expr})")
                else:
                    self.ui._filter.setPlainText(new_full_expr)

    # def setFilter(self):
    #     """단일 팝업창에서 필드 선택과 다중 조건을 설정하고 SQL로 변환합니다."""
    #     index = self.ui.layer.currentIndex()
    #     if index == -1: return
    #     layerId = self.ui.layer.itemData(index)
    #     if layerId is None: return
    #     layer = QgsProject.instance().mapLayer(str(layerId))
    #     if not layer or layer.fields().count() == 0: return

    #     # 1. 1차 팝업 없이 레이어를 통째로 넘겨 통합 엑셀 필터 창 바로 띄우기
    #     dialog = ExcelFilterDialog(layer, self.cached_features, self)
    #     if dialog.exec_() == QDialog.Accepted:
    #         filter_data = dialog.filter_data
    #         field_name = filter_data['field']
    #         is_numeric = filter_data['is_numeric']
    #         expr = ""
            
    #         # [단계 1] 상단 NULL 버튼 조건 우선 처리
    #         if filter_data['null_status'] == 'null':
    #             expr = f'"{field_name}" IS NULL'
    #         elif filter_data['null_status'] == 'not_null':
    #             expr = f'"{field_name}" IS NOT NULL'
            
    #         # [단계 2] '전체 데이터' 모드일 때만 상세 탭 조건 처리
    #         if filter_data['null_status'] == 'all':
    #             if filter_data['type'] == 'value':
    #                 vals = [f"{str(v)}" if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'" for v in filter_data['values']]
    #                 if vals: expr = f'"{field_name}" IN ({", ".join(vals)})'
    #             elif filter_data['type'] == 'condition':
    #                 op, v1_raw, v2_raw = filter_data['op'], filter_data['val1'], filter_data['val2']
    #                 def fmt(v): return str(v) if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'"
    #                 v1, v2 = fmt(v1_raw), fmt(v2_raw)
                    
    #                 if op == "같음 (=)": expr = f'"{field_name}" = {v1}'
    #                 elif op == "같지 않음 (≠)": expr = f'"{field_name}" != {v1}'
    #                 elif op == "포함": expr = f'"{field_name}" LIKE \'%{v1_raw}%\''
    #                 elif op == "포함하지 않음": expr = f'"{field_name}" NOT LIKE \'%{v1_raw}%\''
    #                 elif op == "시작 문자": expr = f'"{field_name}" LIKE \'{v1_raw}%\''
    #                 elif op == "종료 문자": expr = f'"{field_name}" LIKE \'%{v1_raw}\''
    #                 elif op == "초과 (>)": expr = f'"{field_name}" > {v1}'
    #                 elif op == "미만 (<)": expr = f'"{field_name}" < {v1}'
    #                 elif op == "이상 (≥)": expr = f'"{field_name}" >= {v1}'
    #                 elif op == "이하 (≤)": expr = f'"{field_name}" <= {v1}'
    #                 elif op == "사이 (포함)": expr = f'"{field_name}" >= {v1} AND "{field_name}" <= {v2}'
    #                 elif op == "사이에 없음 (포함)": expr = f'"{field_name}" < {v1} OR "{field_name}" > {v2}'

    #         # 최종 텍스트 박스 반영
    #         if expr:
    #             current_text = self.ui._filter.toPlainText().strip()
    #             if current_text: self.ui._filter.setPlainText(f"({current_text}) AND ({expr})")
    #             else: self.ui._filter.setPlainText(expr)


    def duplication (self):
        "결과 테이블 모든 값을 클립보드에 저장합니다."
        text, test = self.downloadDataFromTheTable(True, True)
        if test==True:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('모든 데이터를 클립보드에 복사합니다.', 5000)


    def copyMarked (self):
        "결과 테이블 선택한 값을 클립보드에 저장합니다."
        text, test = self.downloadDataFromTheTable(False, True)
        if test==True:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('선택한 데이터를 클립보드에 복사합니다.', 5000)


    def exportToExcel (self):
        "결과 테이블 모든 값을 엑셀파일로 저장합니다."
        data, test = self.downloadDataFromTheTable(True, False)
        if test==True:
            self.saveFileData(data)


    def exportMarkedToExcel (self):
        "결과 테이블 선택한 값을 엑셀파일로 저장합니다."
        data, test = self.downloadDataFromTheTable(False, False)
        if test==True:
            self.saveFileData(data)


    def saveFileData (self, data):
        "엑셀파일 저장"
        fileWindow = QFileDialog()
        fileWindow.setAcceptMode(1)
        # 확장자와 필터를 엑셀(xlsx) 형식으로 변경
        fileWindow.setDefaultSuffix("xlsx")
        fileWindow.setNameFilters(["Excel files (*.xlsx)", "All files (*)"])
        if fileWindow.exec_() == 0:
            return
        fileName = fileWindow.selectedFiles()[0]
        # 1. 새로운 가상의 엑셀 워크북(문서) 생성 및 현재 시트 선택
        wb = Workbook()
        ws = wb.active
        ws.title = "Pivot Data" # 엑셀 하단 시트 탭의 이름 설정

        # 2. 피벗 테이블의 데이터를 엑셀 시트에 한 줄씩 쏟아넣기
        for i in data:
            ws.append(i)

        # 3. 엑셀 파일로 디스크에 최종 저장
        wb.save(fileName)

        # (선택사항) 저장이 완료되었음을 알리는 메시지
        if hasattr(self, 'statusBar'):
            self.statusBar().showMessage(f"엑셀 파일로 저장이 완료되었습니다: {fileName}", 5000)


    def downloadDataFromTheTable(self, allData=True, controlCharacters=False):
        if self.ui.result.model()==None:
            QMessageBox.information(self,QCoreApplication.translate('GroupStats','Information'), \
                QCoreApplication.translate('GroupStats','저장/복사할 데이터가 없습니다.'))
            return None, False

        text=''
        data = []
        numberOfColumns = self.tm5.columnCount()
        numberOfRows = self.tm5.rowCount()
        rows = []
        columns = []

        if allData == False:            # '선택한 데이터 복사' 옵션일 경우, 선택된 셀의 인덱스만 가져옴
            indexList = self.ui.result.selectedIndexes()
            if len(indexList)==0:
                QMessageBox.information(self,QCoreApplication.translate('GroupStats','Information'), \
                    QCoreApplication.translate('GroupStatsD','선택한 데이터가 없습니다.'))
                return None, False
            for i in indexList:
                rows.append(i.row())
                columns.append(i.column())

        for i in range(numberOfRows):  # 테이블에서 실제 데이터를 추출하여 복사
            if allData or (i in rows) or (i < self.tm5.offsetY):
                row = []
                for j in range(numberOfColumns):
                    if allData or (j in columns) or (j < self.tm5.offsetX):
                        row.append(str(self.tm5.createIndex(i,j).data()))
                data.append(row)

        if controlCharacters == True:
            for m, i in enumerate(data):  # 테이블에서 실제 데이터를 추출하여 복사
                if m>0:
                    text = text + chr(13)
                for n, j in enumerate(i):
                    if n>0:
                        text = text + chr(9)
                    text = text + j
            return text, True
        else:
            return data, True


    def copyCellContent(self, selectedCell):
        "셀 값을 클립보드에 복사합니다."
        clipboard = QApplication.clipboard()
        clipboard.setText(selectedCell)


    def showOnMap(self):
        indexList = self.ui.result.selectedIndexes()
        idList = []
        for i in indexList:
            lista = i.data(Qt.UserRole)#.toList()
            if lista == None:
                lista = ()
            for j in lista:
                idList.append(j)

        try:
            self.tm5.layer.selectByIds(idList)
        except AttributeError:
            QMessageBox.information(self,QCoreApplication.translate('GroupStats','Information'),QCoreApplication.translate('GroupStats','선택한 데이터가 없습니다.'))
        else:
            self.iface.mapCanvas().zoomToSelected(self.tm5.layer)
            if len(idList)==1 and self.tm5.layer.geometryType()==0:
                self.iface.mapCanvas().zoomScale(1000)


    def onSelectionChanged(self):
        indexList = self.ui.result.selectedIndexes()
        total = 0
        count = 0

        for item in indexList:
            row = item.row()        # 행 번호 (0부터 시작)
            col = item.column()     # 열 번호 (0부터 시작)
            if self.columns <= row and self.rows <= col:
                text = item.data(Qt.DisplayRole)#.toList()
                try:
                    value = float(text)
                    total += value
                    count += 1
                except ValueError:
                    count += 1
                    continue

        total = self.format_number(round(total,4))
        if count > 0:
            # self.iface.statusBarIface().showMessage(f"선택한 {count}개의 숫자 합계: {total}")
            # self.bottom_label.setText(f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}")
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats',f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}"),30000)
        else:
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats',''), 30000)

    def format_number(self, num):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)



class ModelList(QAbstractListModel):
    """
    필드(항목) 목록을 관리하는 기본 리스트 모델입니다.
    목록에 저장된 데이터 형식: [(속성 타입, 필드명, ID), ...]
    """

    def __init__(self, mainWindow, parent=None):

        super(ModelList, self).__init__(parent)
        self._data = []
        self.mainWindow = mainWindow
        self.calculations = Calculations(self)


    def rowCount(self, parent=QModelIndex):
        return len(self._data)


    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < self.rowCount():
            return None#QVariant()

        row = index.row()
        if role == Qt.DisplayRole:
            return self._data[row][1]

        #elif rola == Qt.ForegroundRole:
        #    if self.data[row][0] == 'geometry':
        #        kolor = QColor(0,255,0)
        #    elif self.data[row][0] == 'calculations':
        #        kolor = QColor(255,0,0)
        #    elif self.data[row][0] == 'attributeTxt':
        #        kolor = QColor(150,150,150)
        #    else:
        #        kolor = QColor(0,0,0)   # 'countAttributes'
        #
        #    pedzel = QBrush(kolor)
        #    return pedzel

        elif role == Qt.DecorationRole:
            if self._data[row][0] == 'geometry':
                icon = QIcon(":/plugins/groupstats/icons/geom.png")
            elif self._data[row][0] == 'calculations':
                icon = QIcon(":/plugins/groupstats/icons/calc.png")
            elif self._data[row][0] == 'attributeTxt':
                icon = QIcon(":/plugins/groupstats/icons/alpha.png")
            else:
                icon = QIcon(":/plugins/groupstats/icons/digits.png")

            return icon

        return None#QVariant()


    def mimeTypes(self):
        return ['application/x-groupstats-polaL', 'application/x-groupstats-polaWK', 'application/x-groupstats-polaW']


    def supportedDragActions(self):
        return Qt.MoveAction


    def supportedDropActions(self):
        return Qt.MoveAction


    def insertRows(self, row, number, index, data):
        self.beginInsertRows(index, row, row + number - 1)
        for n in range(number):
            self._data.insert(row + n, data[n])
        self.endInsertRows()
        return True


    def removeRows(self, row, number, index):
        self.beginRemoveRows(index, row, row + number - 1)
        del self._data[row:row + number]
        self.endRemoveRows()
        return True


    def mimeData(self, indexy, typMime='application/x-groupstats-polaL'):
        dataMime = QMimeData()
        data = QByteArray()
        stream = QDataStream(data, QIODevice.WriteOnly)
        for index in indexy:
            row = index.row()
            stringg = pickle.dumps(self._data[row][2])
            stream.writeBytes(bytes(self._data[row][0], 'utf-8') if isinstance(self._data[row][0], str) else bytes(self._data[row][0]))
            stream.writeBytes(bytes(self._data[row][1], 'utf-8') if isinstance(self._data[row][1], str) else bytes(self._data[row][1]))
            stream.writeInt16(self._data[row][2])

        dataMime.setData(typMime, data)

        return dataMime


    def flags(self, index):
        flag = super(ModelList, self).flags(index)

        if index.isValid():
            return flag | Qt.ItemIsDragEnabled | Qt.ItemIsEnabled | Qt.ItemIsSelectable
        else:
            return Qt.ItemIsDropEnabled



class ModelRowsColumns(ModelList):
    """
    행과 열에 대한 필드 목록이 있는 모델
    """
    def __init__(self, parent):

        super(ModelRowsColumns, self).__init__(parent)
        self._data = []


    def setData(self, index, value):
        self._data.insert(index, value)
        return True


    def setOtherModels(self, modelWiK, valueModel):
        self.modelWiK = modelWiK._data
        self.valueModel = valueModel._data


    def mimeData(self, indexy):
        return super(ModelRowsColumns, self).mimeData(indexy, 'application/x-groupstats-polaWK')

    def dropMimeData(self, dataMime, share, row, column, index):
        if dataMime.hasFormat('application/x-groupstats-polaL'):
            dataType = 'application/x-groupstats-polaL'
        elif dataMime.hasFormat('application/x-groupstats-polaWK'):
            dataType = 'application/x-groupstats-polaWK'
        elif dataMime.hasFormat('application/x-groupstats-polaW'):
            dataType = 'application/x-groupstats-polaW'
        else:
            return False

        data = dataMime.data(dataType)

        stream = QDataStream(data, QIODevice.ReadOnly)
        outData = []
        while not stream.atEnd():
            typ = stream.readBytes().decode('utf-8')
            name = stream.readBytes().decode('utf-8')
            id = stream.readInt16()
            field = (typ, name, id)
            dataWKiW = self.modelWiK+self.valueModel

            if typ=='calculations' and typ in [x[0] for x in dataWKiW] and dataType == 'application/x-groupstats-polaL':
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','함수는 한 영역에서만 사용할 수 있습니다'),5000)
                return False
            elif (field in self.modelWiK or field in self._data) and dataType in ['application/x-groupstats-polaL', 'application/x-groupstats-polaW']:
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','이 필드는 이미 있습니다.'),5000)
                return False
            #elif (typ != 'calculations' and 'calculations' in [x[0] for x in self.data]) or (typ=='calculations' and len([x for x in self.data if (x[0] != 'calculations')])>0):
            #    print 'calculated fields cannot be together with other fields'
            #    return False
            elif typ=='calculations' and id not in self.calculations.textList and 'attributeTxt' in [x[0] for x in self.valueModel]:  #name != self.calculations.lista[0][0]
                self.mainWindow.statusBar().showMessage(QCoreApplication.translate('GroupStats','텍스트 값 함수는 다음 중 하나만 사용할 수 있습니다 (%s)' % self.calculations.textNames), 5000)
                return False

            outData.append(field)

        self.insertRows(row, len(outData), index, outData)

        return True



class ValueModel(ModelList):
    """
    계산을 위한 값이 있는 모델
    """

    def __init__(self, parent=None):

        super(ValueModel, self).__init__(parent)
        self._data = []

    def mimeData(self, indexy):
        return super(ValueModel, self).mimeData(indexy, 'application/x-groupstats-polaW')

    def dropMimeData(self, dataMime, share, row, column, index):
        if dataMime.hasFormat('application/x-groupstats-polaL'):
            dataType = 'application/x-groupstats-polaL'
        elif dataMime.hasFormat('application/x-groupstats-polaWK'):
            dataType = 'application/x-groupstats-polaWK'
        elif dataMime.hasFormat('application/x-groupstats-polaW'):
            dataType = 'application/x-groupstats-polaW'
        else:
            return False

        data = dataMime.data(dataType)
        stream = QDataStream(data, QIODevice.ReadOnly)
        outData = []
        
        while not stream.atEnd():
            typ = stream.readBytes().decode('utf-8')
            name = stream.readBytes().decode('utf-8')
            id = stream.readInt16()
            field = (typ, name, id)

            # 1. 계산식(sum, count 등) 드롭 방지
            # --- 아래 부분을 수정합니다 (내부 순서 변경은 중복 검사에서 제외) ---
            if field in self._data and dataType != 'application/x-groupstats-polaW':
                self.mainWindow.statusBar().showMessage("이미 추가된 필드입니다.", 5000)
                return False

            outData.append(field)

        self.insertRows(row, len(outData), index, outData)
        return True

    def setOtherModels(self, modelRows, modelColumns):
        self.modelRows = modelRows._data
        self.modelColumns = modelColumns._data



class ModelListaPol(ModelList):
    """
    사용 가능한 필드 목록이 있는 모델
    """

    def __init__(self, parent=None):

        super(ModelListaPol, self).__init__(parent)
        #self.ustawDane(slownikPol)
        self._data = []

    def dropMimeData(self, dataMime, share, row, column, index):
        return True


    def removeRows(self, row, number, index):

        return True



class ResultModel(QAbstractTableModel):
    """
    계산 결과가 있는 모델
    """

    def __init__(self, data, rows, columns, layer, parent=None):
        super(ResultModel, self).__init__(parent)
        self._data = data
        self.rows = rows
        self.columns = columns
        self.layer = layer

        self.offsetX = max(1,len(rows[0]))
        self.offsetY = max(1, len(columns[0]))
        
        # --- 아래 두 줄을 주석 처리(#) 하거나 삭제하세요 --- 결과 테이블 빈줄 삭제
        # if len(rows[0]) != 0 and len(columns[0]) != 0:
        #         self.offsetY += 1

    def columnCount(self,parent=QModelIndex()):
        if len(self.rows[0])>0 and len(self.columns[0])>0:
            l = len(self.columns) + len(self.rows[0]) - 1
        elif len(self.rows[0])>0 and len(self.columns[0])==0:
            l = len(self.rows[0])+1
        elif len(self.rows[0])==0 and len(self.columns[0])>0:
            l = len(self.columns)
        else:
            l = 2

        return l #max(len(self.rows[0])+1,len(self.column)+len(self.rows[0]))

    def rowCount(self, parent=QModelIndex()):
        # --- 수정 전 ---
        # return max(2, len(self.rows) + len(self.columns[0]))
        
        # --- 수정 후 ---
        if len(self.rows[0]) > 0 and len(self.columns[0]) > 0:
            return max(2, len(self.rows) + len(self.columns[0]) - 1)
        return max(2, len(self.rows) + len(self.columns[0]))

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < self.rowCount():
            return None

        row = index.row() - self.offsetY
        column = index.column() - self.offsetX

        if role == Qt.DisplayRole:
            if row >= 0 and column >= 0:                                      # [우측 하단] 데이터 영역
                return self._data[row][column][0]
            elif column < 0 and row >= 0 and len(self.rows[0]) > 0:           # [좌측 하단] 행 값 영역 (예: 본사, 대구)
                return self.rows[row+1][column]
            elif row < 0 and column < 0 and len(self.rows[0]) > 0:            # [좌측 상단] 헤더 이름 영역
                if row == -1:                                                 
                    return self.rows[0][column]                               # 제일 아랫줄은 행 이름 (예: '일정분배')
                else:                                                         
                    return self.columns[column + 1][row]                      # 윗줄은 열 이름 (예: '담당')
            elif column >= 0 and row < 0 and len(self.columns[0]) > 0:        # [우측 상단] 열 값 영역 (예: count, sum)
                return self.columns[column + 1][row]

        elif role == Qt.UserRole:
            if row >=0 and column >=0:
                return self._data[row][column][1]

        elif role == Qt.UserRole+1:
            #print "user role+1"
            if row <0 and column >=0:
                return "column"
            elif row >=0 and column <0:
                return "row"
            elif row >=0 and column >=0:
                return "data"

        elif role == Qt.BackgroundRole:
            if row<0 or column<0:
                colour = QColor(245,235,235)
                brush = QBrush(colour)
                return brush

        elif role == Qt.TextAlignmentRole:
            if column < 0 and row < -1 and len(self.rows[0]) != 0:
                return Qt.AlignRight | Qt.AlignVCenter
            elif column >= 0 and row < 0:
                return Qt.AlignHCenter | Qt.AlignVCenter
            elif column >= 0 and row >= 0:
                return Qt.AlignRight | Qt.AlignVCenter

        elif role == Qt.FontRole:
            if row<0 and column<0:
                font = QFont()
                font.setBold(True)
                #font.setItalic(True)
                return font

        return None#QVariant()



    def sort(self, column, mode):
        """
        선택한 열을 기준으로 결과 테이블을 정렬합니다
        column: 열 번호
        mmode: 1이면 내림차순, 그 외는 오름차
        """

        if len(self.rows) == 1:
            return

        tmp = [] 

        if column >= self.offsetX:
            # n-line number before storting, d-data in line
            try:
                tmp.extend([(n, (float('nan') if not str(d[column - self.offsetX][0]).strip()
                                 else float(d[column - self.offsetX][0]))) for n, d in enumerate(self._data)])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[column - self.offsetX][0])) for n, d in enumerate(self._data)])
        else:                                                                   # or line names
            # Either convert all values or none to float for sorting
            # n-row number before storting, d-row description
            try:
                tmp.extend([(n, (float('nan') if not str(d[column]).strip()
                                 else float(d[column]))) for n, d in enumerate(self.rows[1:])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[column])) for n, d in enumerate(self.rows[1:])])

        tmp = sort_values_nulls_last(tmp, mode)

        data2 = tuple(self._data)
        self._data=[]
        rows2=tuple(self.rows)
        self.rows=[]
        self.rows.append(rows2[0])

        for i in tmp:
            self._data.append(data2[i[0]])
            self.rows.append(rows2[i[0]+1])

        topLeft = self.createIndex(0,0)
        bottomRight = self.createIndex(self.rowCount(), self.columnCount())
        self.dataChanged.emit(topLeft, bottomRight)



    def sortRows(self, row, mode):
        """
        선택한 행에 따라 결과 표를 정렬합니다
        rows - rows number
        mode - 1-descending, other-ascending
        """
        if len(self.columns) - self.offsetX <=1:
            return
        tmp = []

        if row >= self.offsetY:
            try:
                tmp.extend([(n, (float('nan') if not str(d[0]).strip() else float(d[0]))) for n, d in enumerate(self._data[row - self.offsetY])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[0])) for n, d in enumerate(self._data[row - self.offsetY])])
        else:
            try:
                tmp.extend([(n, (float('nan') if not str(d[row]).strip() else float(d[row]))) for n, d in enumerate(self.columns[1:])])
            except (ValueError, TypeError):
                tmp.extend([(n, str(d[row])) for n, d in enumerate(self.columns[1:])])
            except IndexError:
                return

        tmp = sort_values_nulls_last(tmp, mode)

        data2 = tuple(self._data)
        self._data=[]
        columns2=tuple(self.columns)
        self.columns=[]
        self.columns.append(columns2[0])
        for j in data2:
            row = []
            for i in tmp:
                row.append(j[i[0]])
            self._data.append(tuple(row))

        for i in tmp:
            self.columns.append(columns2[i[0] + 1])

        topLeft = self.createIndex(0,0)
        bottomRight = self.createIndex(self.rowCount(), self.columnCount())
        self.dataChanged.emit(topLeft, bottomRight)


def sort_values_nulls_last(alist, rev):
    """
    데이터 리스트를 정렬하되, 특수 텍스트(부분합, 총합계)와 NULL 값의 우선순위를 강제로 조정합니다.

    Args:
        alist (list): 정렬할 대상 데이터 리스트. 형식은 [(index, value), ...] 형태.
        rev (int): 정렬 모드. 1이면 내림차순(Descending), 그 외는 오름차순(Ascending).

    Returns:
        list: 1. 일반 데이터 -> 2. 부분합계 -> 3. 행/열합계 -> 4. 크로스합계 -> 5. 빈칸(NULL) 
              순서로 재배치된 새로운 리스트.
    """
    contains_values = [x for x in alist
                       if str(x[1]).strip()
                       and x[1] is not None
                       and (not isinstance(x[1], float) or not math.isnan(x[1]))]
                       
    # 우선순위에 따라 4개의 바구니 생성
    normals = []
    subtotals = []
    totals = []
    grand_totals = []
    
    # 텍스트를 검사하여 데이터를 각 바구니에 분류
    for x in contains_values:
        val_str = str(x[1]).strip()
        
        if '부분합' in val_str:
            subtotals.append(x)
        elif val_str.startswith('전체 '): # '전체 sum', '전체 count' 등 크로스 합계
            grand_totals.append(x)
        elif val_str in ('총합계', '행합계', '열합계'):
            totals.append(x)
        else:
            normals.append(x)
            
    # 각각 지정된 모드(오름차순/내림차순)에 맞춰 개별 정렬 수행
    normals = list(sorted(normals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    subtotals = list(sorted(subtotals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    totals = list(sorted(totals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    grand_totals = list(sorted(grand_totals, key=lambda x: x[1], reverse=True if rev == 1 else False))
    
    # 순서 강제 조립: 일반 -> 부분합계 -> 행/열합계 -> 전체(크로스) 합계 순으로 고정
    result = normals + subtotals + totals + grand_totals
    
    # NULL 값들(빈칸)은 표의 맨 마지막으로 보냄
    values_idx = [x[0] for x in result]
    result.extend([x for x in alist if x[0] not in values_idx])
    
    return result



class WindowResults(QTableView, QMenu):
    """
    계산 결과 창
    """

    def __init__(self, parent=None):
        super(WindowResults, self).__init__(parent)
        self.setSortingEnabled(True)
        self.setObjectName("result")
        self.verticalHeader().setSortIndicatorShown(True)
        self.clicked.connect(self._selectAll)

    def contextMenuEvent(self, event):
        """
        결과 테이블 우클릭 메뉴 생성
        """
        selectionIndex = self.indexAt(event.pos())
        
        # 유효하지 않은 빈 공간이나 헤더(-1)를 클릭한 경우 메뉴를 띄우지 않음
        if not selectionIndex.isValid() or selectionIndex.row() < 0 or selectionIndex.column() < 0:
            return
            
        # 1. 팝업 메뉴 객체 생성
        self.menu = QMenu(self)



        # 2. '셀 내용 복사' 액션 생성 및 연결
        copyCellAction = QAction('셀 내용 복사', self)
        selectedCell = str(selectionIndex.data(Qt.DisplayRole) or "")
        # def copy_to_clipboard():
        #     clipboard = QApplication.clipboard()
        #     clipboard.setText(selectedCell)


        def copyMarked():
            "선택한 셀을 클립보드에 복사합니다"
            indexList = self.window().ui.result.selectedIndexes()
            if not indexList:
                QMessageBox.information(self, QCoreApplication.translate('GroupStats','Information'),
                    QCoreApplication.translate('GroupStats','선택한 데이터가 없습니다.'))
                return

            # 1. 행(Row)별로 선택된 셀들을 그룹화하여 딕셔너리에 저장
            row_data = {}
            for idx in indexList:
                r = idx.row()
                c = idx.column()
                val = str(idx.data(Qt.DisplayRole) or "")
                
                if r not in row_data:
                    row_data[r] = {}
                row_data[r][c] = val

            # 2. 행과 열의 시각적 순서대로 정렬하여 텍스트 결합 (탭과 줄바꿈)
            text_lines = []
            for r in sorted(row_data.keys()):
                cols = sorted(row_data[r].keys())
                line = "\t".join([row_data[r][c] for c in cols])
                text_lines.append(line)

            text = "\n".join(text_lines)
            
            # 3. 클립보드에 삽입
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.window().statusBar().showMessage('선택한 셀의 내용을 클립보드에 복사했습니다.', 5000)

        copyCellAction.triggered.connect(copyMarked)
        self.menu.addAction(copyCellAction)

        self.menu.addSeparator() # 메뉴 사이에 구분선 추가

        # 3. '전체 데이터 복사' 액션 추가 (원하시는 메뉴를 이런 식으로 계속 추가 가능합니다)
        selectAllAction = QAction('전체 데이터 복사', self)
        selectAllAction.triggered.connect(self.duplication)
        self.menu.addAction(selectAllAction)

        # 2. '선택한 데이터 복사' 액션 생성 및 연결
        copyCellAction = QAction('선택 데이터 복사', self)
        selectedCell = str(selectionIndex.data(Qt.DisplayRole) or "")
        copyCellAction.triggered.connect(self.window().copyMarked)
        self.menu.addAction(copyCellAction)

        self.menu.addSeparator() # 메뉴 사이에 구분선 추가

        # 4. '선택한 객체 맵에서 보기' 액션 추가
        showMapAction = QAction('객체 이동', self)
        # self.window()를 통해 메인 창의 showOnMap 함수를 안전하게 호출
        showMapAction.triggered.connect(self.window().showOnMap)
        self.menu.addAction(showMapAction)

        # 메뉴를 띄우기 전에 우클릭한 셀을 선택된 상태(파란색 배경)로 만듦
        # self.selectionModel().select(selectionIndex, QItemSelectionModel.ClearAndSelect)
        
        # 마우스 커서가 있는 현재 위치에 메뉴 팝업 띄우기
        self.menu.popup(QCursor.pos())

    def duplication(self):
        self.selectAll()
        self.window().duplication()

    def selectionCommand(self, index, event=None):
        """
        기본 선택 동작 구현 - 테이블의 헤더(이름표)를 클릭할 때 해당 행이나 열 전체를 선택합니다.
        """
        flag = super(WindowResults, self).selectionCommand(index, event)
        test = None        
        if self.model():
            test = self.model().data(index, Qt.UserRole+1)
        if test == "row":
            return flag | QItemSelectionModel.Rows
        elif test == "column":
            return flag | QItemSelectionModel.Columns
        else:
            return flag


    def _selectAll(self, index):
        """
        테이블 모서리를 클릭하면 모든 데이터를 선택하거나 선택 취소합니다
        """
        test = self.model().data(index, Qt.UserRole+1)
        if test not in ("data", "row", "column"):
            if self.selectionModel().isSelected(index):
                self.selectAll()
            else:
                self.clearSelection()



class Calculations(QObject):                   # finished
    """
    통계 계산을 수행하는 함수 클래스
    """

    def __init__(self, parent):
        super(Calculations, self).__init__(parent)

        self.list = {0:(QCoreApplication.translate('Calculations','sum'), self.sum),                # 합계
                     1:(QCoreApplication.translate('Calculations','count'), self.count),            # 개수
                     2:(QCoreApplication.translate('Calculations','average'), self.average),        # 평균
                     3:(QCoreApplication.translate('Calculations','variance'), self.variance),      # 분산
                     4:(QCoreApplication.translate('Calculations','stand.dev.'), self.stand_dev),   # 표준편차
                     5:(QCoreApplication.translate('Calculations','median'), self.median),          # 중앙값
                     6:(QCoreApplication.translate('Calculations','min'), self.minimum),            # 최소
                     7:(QCoreApplication.translate('Calculations','max'), self.maximum),            # 최대
                     8:(QCoreApplication.translate('Calculations','unique'), self.unique)}          # 고유값

        self.textList = (0, 6, 7, 8)

        self.textNames = ''
        for i in self.textList:
            self.textNames = self.textNames + self.list[i][0] + ', '

        self.textNames = self.textNames[:-2]


    def count(self, result):
        return len(result)


    def sum(self, result):
        return sum(result)


    def average(self, result):
        return self.sum(result)/self.count(result)


    def variance(self, result):
        count = self.count(result)
        if count <= 1:
            return 0.0 # 데이터가 1개 이하면 분산을 0으로 처리하여 에러 방지
            
        avg = self.average(result) # 루프 바깥에서 평균을 딱 한 번만 미리 계산
        
        # 제너레이터 표현식(Generator expression)을 사용하여 C언어 수준의 속도로 빠르게 계산
        _variance = sum((x - avg) ** 2 for x in result)
        
        return _variance / count


    def stand_dev(self, result):
        return sqrt(self.variance(result))


    def median(self, result):
        result.sort()
        count = self.count(result)
        if count == 1:
            median = result[0]
        else:
            position = int(count / 2)
            if count%2 == 0:
                median = (result[position]+result[position-1])/2
            else:
                median = result[position]
        return median


    def minimum(self, result):
        return min(result)


    def maximum(self, result):
        return max(result)


    def unique(self, result):
        return len(set(result))



class ExcelFilterDialog(QDialog):
    """여러 필드의 조건을 누적하여 AND/OR로 조합할 수 있는 통합 필터 창"""
    def __init__(self, layer, cached_data, parent=None):
        super(ExcelFilterDialog, self).__init__(parent)
        self.layer = layer
        self.cached_data = cached_data
        self.setWindowTitle("다중 통합 필터 설정")
        self.resize(450, 700) # 창 크기를 조금 더 키움
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.is_numeric = False
        layout = QVBoxLayout(self)

        # [0] 최상단: 다중 조건 논리 연산자 선택 (AND / OR)
        logic_group = QGroupBox("다중 조건 결합 방식")
        logic_layout = QHBoxLayout()
        self.radio_and = QRadioButton("모든 조건 만족 (AND)")
        self.radio_or = QRadioButton("하나라도 만족 (OR)")
        self.radio_and.setChecked(True) # 기본값 AND
        logic_layout.addWidget(self.radio_and)
        logic_layout.addWidget(self.radio_or)
        logic_group.setLayout(logic_layout)
        layout.addWidget(logic_group)

        # [1] 필드 선택
        field_layout = QHBoxLayout()
        field_layout.addWidget(QLabel("필터링할 필드:"))
        self.field_combo = QComboBox()
        self.fields = [f.name() for f in layer.fields()]
        self.field_combo.addItems(self.fields)
        field_layout.addWidget(self.field_combo)
        layout.addLayout(field_layout)

        # [2] 결측치(NULL) 옵션
        null_group = QGroupBox("결측치(NULL) 필터")
        null_layout = QHBoxLayout()
        self.radio_all = QRadioButton("전체 데이터 (기본)")
        self.radio_null = QRadioButton("누락 (NULL)")
        self.radio_not_null = QRadioButton("누락되지 않음 (NOT NULL)")
        self.radio_all.setChecked(True)
        null_layout.addWidget(self.radio_all)
        null_layout.addWidget(self.radio_null)
        null_layout.addWidget(self.radio_not_null)
        null_group.setLayout(null_layout)
        layout.addWidget(null_group)

        # [3] 상세 필터 탭
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        self.setup_value_tab()
        self.setup_condition_tab()

        # [4] 조건 추가 버튼 (핵심)
        self.btn_add_condition = QPushButton("👇 현재 설정을 조건 목록에 추가")
        self.btn_add_condition.setStyleSheet("background-color: #e0f7fa; font-weight: bold; padding: 5px;")
        self.btn_add_condition.clicked.connect(self.add_condition_to_list)
        layout.addWidget(self.btn_add_condition)

        # [5] 누적된 조건 목록 위젯
        list_group = QGroupBox("적용할 필터 조건 목록")
        list_layout = QVBoxLayout()
        self.condition_list_widget = QListWidget()
        list_layout.addWidget(self.condition_list_widget)
        
        self.btn_remove_condition = QPushButton("선택한 조건 삭제")
        self.btn_remove_condition.clicked.connect(self.remove_selected_condition)
        list_layout.addWidget(self.btn_remove_condition)
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)

        # [6] 하단 확인/취소 버튼
        btn_box = QHBoxLayout()
        btn_ok = QPushButton("최종 확인")
        btn_cancel = QPushButton("취소")
        btn_ok.clicked.connect(self.apply_filter)
        btn_cancel.clicked.connect(self.reject)
        btn_box.addStretch()
        btn_box.addWidget(btn_ok)
        btn_box.addWidget(btn_cancel)
        layout.addLayout(btn_box)

        # 이벤트 연결
        self.field_combo.currentIndexChanged.connect(self.on_field_changed)
        self.radio_all.toggled.connect(self.toggle_tabs)
        self.radio_null.toggled.connect(self.toggle_tabs)
        self.radio_not_null.toggled.connect(self.toggle_tabs)
        
        if self.fields: self.on_field_changed()
        self.search_box.setFocus()

    def toggle_tabs(self):
        is_all = self.radio_all.isChecked()
        self.tabs.setEnabled(is_all)

    def setup_value_tab(self):
        self.tab_values = QWidget()
        v_layout = QVBoxLayout(self.tab_values)
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("값 검색...")
        self.search_box.textChanged.connect(self.filter_list)
        v_layout.addWidget(self.search_box)
        
        h_btn = QHBoxLayout()
        self.btn_all = QPushButton("모두 선택")
        self.btn_clear = QPushButton("모두 해제")
        h_btn.addWidget(self.btn_all)
        h_btn.addWidget(self.btn_clear)
        v_layout.addLayout(h_btn)

        self.val_list_widget = QListWidget() # 이름 변경 방지용
        v_layout.addWidget(self.val_list_widget)
        self.tabs.addTab(self.tab_values, "값 선택")
        
        self.btn_all.clicked.connect(lambda: self.set_check_all(Qt.Checked))
        self.btn_clear.clicked.connect(lambda: self.set_check_all(Qt.Unchecked))

    def setup_condition_tab(self):
        self.tab_condition = QWidget()
        c_layout = QVBoxLayout(self.tab_condition)
        self.cond_combo = QComboBox()
        self.cond_combo.currentIndexChanged.connect(self.update_condition_ui)
        c_layout.addWidget(self.cond_combo)
        self.cond_input1 = QLineEdit()
        self.cond_input2 = QLineEdit()
        self.cond_input2.setVisible(False)
        c_layout.addWidget(self.cond_input1)
        c_layout.addWidget(self.cond_input2)
        c_layout.addStretch()
        self.tabs.addTab(self.tab_condition, "조건 필터")

    def on_field_changed(self):
        field_name = self.field_combo.currentText()
        field_idx = self.layer.fields().indexOf(field_name)
        self.is_numeric = self.layer.fields().at(field_idx).isNumeric()
        
        QApplication.setOverrideCursor(Qt.WaitCursor)
        if hasattr(self, 'cached_data') and self.cached_data:
            unique_values = {f['attributes'][field_idx] for f in self.cached_data if f['attributes'][field_idx] is not None and str(f['attributes'][field_idx]).strip() != ''}
        else:
            unique_values = self.layer.dataProvider().uniqueValues(field_idx)

        def safe_float(val):
            if hasattr(val, 'value'): val = val.value()
            return float(val)
        def safe_str(val):
            if hasattr(val, 'value'): val = val.value()
            return str(val)

        if self.is_numeric:
            try: sorted_vals = sorted(list(unique_values), key=safe_float)
            except (ValueError, TypeError): sorted_vals = sorted(list(unique_values), key=safe_str)
        else:
            sorted_vals = sorted(list(unique_values), key=safe_str)
            
        valid_values_str = [str(v.value()) if hasattr(v, 'value') else str(v) for v in sorted_vals]

        self.val_list_widget.setUpdatesEnabled(False)
        self.val_list_widget.clear()
        self.val_list_widget.addItems(valid_values_str)
        for i in range(self.val_list_widget.count()):
            item = self.val_list_widget.item(i)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
        self.val_list_widget.setUpdatesEnabled(True)

        completer = QCompleter(valid_values_str, self)
        completer.setFilterMode(Qt.MatchContains)
        self.cond_input1.setCompleter(completer)
        self.cond_input2.setCompleter(completer)

        self.cond_combo.blockSignals(True)
        self.cond_combo.clear()
        if self.is_numeric:
            self.cond_combo.addItems(["같음 (=)", "같지 않음 (≠)", "초과 (>)", "미만 (<)", "이상 (≥)", "이하 (≤)", "사이 (포함)", "사이에 없음 (포함)"])
        else:
            self.cond_combo.addItems(["같음 (=)", "같지 않음 (≠)", "포함", "포함하지 않음", "시작 문자", "종료 문자"])
        self.cond_combo.blockSignals(False)
        self.update_condition_ui()
        QApplication.restoreOverrideCursor()

    def update_condition_ui(self):
        op = self.cond_combo.currentText()
        self.cond_input1.setVisible(True)
        self.cond_input2.setVisible("사이" in op)

    def filter_list(self, text):
        for i in range(self.val_list_widget.count()):
            item = self.val_list_widget.item(i)
            item.setHidden(text.lower() not in item.text().lower())

    def set_check_all(self, state):
        for i in range(self.val_list_widget.count()):
            item = self.val_list_widget.item(i)
            if not item.isHidden(): item.setCheckState(state)

    def remove_selected_condition(self):
        for item in self.condition_list_widget.selectedItems():
            self.condition_list_widget.takeItem(self.condition_list_widget.row(item))

    def add_condition_to_list(self):
        """현재 UI 설정을 읽어 조건 목록 위젯에 담습니다."""
        field_name = self.field_combo.currentText()
        cond_data = {
            'field': field_name,
            'is_numeric': self.is_numeric,
            'null_status': 'all',
            'type': 'none'
        }

        display_text = f"[{field_name}] "

        if self.radio_null.isChecked():
            cond_data['null_status'] = 'null'
            display_text += "IS NULL"
        elif self.radio_not_null.isChecked():
            cond_data['null_status'] = 'not_null'
            display_text += "IS NOT NULL"
        else:
            if self.tabs.currentIndex() == 0:
                checked_vals = [self.val_list_widget.item(i).text() for i in range(self.val_list_widget.count()) if self.val_list_widget.item(i).checkState() == Qt.Checked]
                if len(checked_vals) == 0:
                    QMessageBox.warning(self, "경고", "선택된 값이 없습니다.")
                    return
                if len(checked_vals) == self.val_list_widget.count():
                    QMessageBox.information(self, "알림", "모든 값이 선택되었습니다. (필터 효과 없음)")
                    return
                cond_data.update({'type': 'value', 'values': checked_vals})
                display_text += f"IN ({', '.join(checked_vals[:3])}{' 등...' if len(checked_vals)>3 else ''})"
            else:
                op = self.cond_combo.currentText()
                val1 = self.cond_input1.text().strip()
                val2 = self.cond_input2.text().strip()
                if not val1:
                    QMessageBox.warning(self, "경고", "조건 값을 입력해 주세요.")
                    return
                cond_data.update({'type': 'condition', 'op': op, 'val1': val1, 'val2': val2})
                if "사이" in op: display_text += f"{op} {val1} ~ {val2}"
                else: display_text += f"{op} {val1}"

        # 리스트에 추가
        item = QListWidgetItem(display_text)
        item.setData(Qt.UserRole, cond_data) # 실제 데이터 숨김 저장
        self.condition_list_widget.addItem(item)
        
        self.statusBar_msg = "조건이 추가되었습니다. 계속 추가하거나 최종 확인을 누르세요."

    def apply_filter(self):
        """최종적으로 다이얼로그를 닫으며 메인 창으로 리스트 데이터를 전달합니다."""
        if self.condition_list_widget.count() == 0:
            # 목록이 비어있으면 현재 상태를 자동으로 한번 추가 시도
            self.add_condition_to_list()
            if self.condition_list_widget.count() == 0:
                return # 그래도 없으면 값 미입력 등의 오류가 뜬 상태이므로 무시
        
        # 목록에 쌓인 모든 조건을 리스트로 추출
        self.final_conditions = []
        for i in range(self.condition_list_widget.count()):
            item = self.condition_list_widget.item(i)
            self.final_conditions.append(item.data(Qt.UserRole))
            
        self.global_logic = "AND" if self.radio_and.isChecked() else "OR"
        self.accept()

# class ExcelFilterDialog(QDialog):
#     """상단에 NULL 필터 버튼이 통합된 통합 필터 창"""
#     def __init__(self, layer, cached_data, parent=None):
#         super(ExcelFilterDialog, self).__init__(parent)
#         self.layer = layer
#         self.cached_data = cached_data  # 캐시 데이터 저장
#         self.setWindowTitle("통합 필터 설정")
#         self.resize(400, 550)
#         self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

#         self.filter_data = {'type': 'none', 'null_status': 'all', 'values': [], 'condition': None, 'field': None, 'is_numeric': False}
#         self.is_numeric = False
        
#         layout = QVBoxLayout(self)

#         # [1] 상단: 필드 선택
#         field_layout = QHBoxLayout()
#         field_layout.addWidget(QLabel("필터링할 필드:"))
#         self.field_combo = QComboBox()
#         self.fields = [f.name() for f in layer.fields()]
#         self.field_combo.addItems(self.fields)
#         field_layout.addWidget(self.field_combo)
#         layout.addLayout(field_layout)

#         # [2] 중단: NULL 필터 옵션 (새로 추가된 핵심 구역)
#         null_group = QGroupBox("결측치(NULL) 필터")
#         null_layout = QHBoxLayout()
#         self.radio_all = QRadioButton("전체 데이터 (기본)")
#         self.radio_null = QRadioButton("누락 (NULL)")
#         self.radio_not_null = QRadioButton("누락되지 않음 (NOT NULL)")
#         self.radio_all.setChecked(True)
        
#         null_layout.addWidget(self.radio_all)
#         null_layout.addWidget(self.radio_null)
#         null_layout.addWidget(self.radio_not_null)
#         null_group.setLayout(null_layout)
#         layout.addWidget(null_group)

#         # [3] 하단: 상세 필터 탭
#         self.tabs = QTabWidget()
#         layout.addWidget(self.tabs)
        
#         self.setup_value_tab()
#         self.setup_condition_tab()

#         # 버튼 레이아웃
#         btn_box = QHBoxLayout()
#         btn_ok = QPushButton("확인"); btn_cancel = QPushButton("취소")
#         btn_ok.clicked.connect(self.apply_filter); btn_cancel.clicked.connect(self.reject)
#         btn_box.addStretch(); btn_box.addWidget(btn_ok); btn_box.addWidget(btn_cancel)
#         layout.addLayout(btn_box)

#         # 이벤트 연결
#         self.field_combo.currentIndexChanged.connect(self.on_field_changed)
#         self.radio_all.toggled.connect(self.toggle_tabs)
#         self.radio_null.toggled.connect(self.toggle_tabs)
#         self.radio_not_null.toggled.connect(self.toggle_tabs)
        
#         if self.fields: self.on_field_changed()
#         self.search_box.setFocus()
        
#     def toggle_tabs(self):
#         """'전체 데이터'일 때만 하단 탭을 사용할 수 있게 제한합니다."""
#         is_all = self.radio_all.isChecked()
#         self.tabs.setEnabled(is_all)
#         if not is_all:
#             self.statusBar_msg = "NULL 조건 선택 시 상세 필터는 비활성화됩니다."
#         else:
#             self.statusBar_msg = ""

#     def setup_value_tab(self):
#         self.tab_values = QWidget()
#         v_layout = QVBoxLayout(self.tab_values)
#         self.search_box = QLineEdit(); self.search_box.setPlaceholderText("값 검색...")
#         self.search_box.textChanged.connect(self.filter_list)
#         v_layout.addWidget(self.search_box)
        
#         h_btn = QHBoxLayout()
#         self.btn_all = QPushButton("모두 선택")
#         self.btn_clear = QPushButton("모두 해제")
#         self.btn_asc = QPushButton("오름차순")
#         self.btn_desc = QPushButton("내림차순")
#         h_btn.addWidget(self.btn_all)
#         h_btn.addWidget(self.btn_clear)
#         h_btn.addWidget(self.btn_asc)
#         h_btn.addWidget(self.btn_desc)
#         v_layout.addLayout(h_btn)

#         self.list_widget = QListWidget()
#         v_layout.addWidget(self.list_widget)
#         self.tabs.addTab(self.tab_values, "값 선택")
#         # 이벤트 연결
#         self.btn_all.clicked.connect(lambda: self.set_check_all(Qt.Checked))
#         self.btn_clear.clicked.connect(lambda: self.set_check_all(Qt.Unchecked))
#         self.btn_asc.clicked.connect(lambda: self.list_widget.sortItems(Qt.AscendingOrder))
#         self.btn_desc.clicked.connect(lambda: self.list_widget.sortItems(Qt.DescendingOrder))

#     def setup_condition_tab(self):
#         self.tab_condition = QWidget()
#         c_layout = QVBoxLayout(self.tab_condition)
#         self.cond_combo = QComboBox()
#         self.cond_combo.currentIndexChanged.connect(self.update_condition_ui)
#         c_layout.addWidget(self.cond_combo)
#         self.cond_input1 = QLineEdit(); self.cond_input2 = QLineEdit()
#         self.cond_input2.setVisible(False)
#         c_layout.addWidget(self.cond_input1); c_layout.addWidget(self.cond_input2)
#         c_layout.addStretch()
#         self.tabs.addTab(self.tab_condition, "조건 필터")
#         self.cond_input1.setFocus()

#     def on_field_changed(self):
#         field_name = self.field_combo.currentText()
#         field_idx = self.layer.fields().indexOf(field_name)
#         self.is_numeric = self.layer.fields().at(field_idx).isNumeric()
        
#         QApplication.setOverrideCursor(Qt.WaitCursor)
#         # --- 수정된 부분: QGIS 프로바이더를 직접 쿼리하지 않고 메인 창의 캐시를 사용 ---
#         # 1. 고유값 빠른 추출 (Set 컴프리헨션)
#         if hasattr(self, 'cached_data') and self.cached_data:
#             unique_values = {f['attributes'][field_idx] for f in self.cached_data if f['attributes'][field_idx] is not None and str(f['attributes'][field_idx]).strip() != ''}
#         else:
#             unique_values = self.layer.dataProvider().uniqueValues(field_idx)

#         # 2. 정렬 로직 최적화 (QVariant 안전 처리)
#         def safe_float(val):
#             if hasattr(val, 'value'): # QVariant 객체인지 확인
#                 val = val.value()
#             return float(val)

#         def safe_str(val):
#             if hasattr(val, 'value'): # QVariant 객체인지 확인
#                 val = val.value()
#             return str(val)

#         if self.is_numeric:
#             try:
#                 sorted_vals = sorted(list(unique_values), key=safe_float)
#             except (ValueError, TypeError):
#                 sorted_vals = sorted(list(unique_values), key=safe_str)
#         else:
#             sorted_vals = sorted(list(unique_values), key=safe_str)
            
#         # 리스트 위젯에 넣을 때도 <QVariant object> 문자열이 들어가지 않도록 실제 값으로 변환
#         valid_values_str = [str(v.value()) if hasattr(v, 'value') else str(v) for v in sorted_vals]

#         # 3. [핵심] 리스트 위젯 UI 렌더링 최적화
#         self.list_widget.setUpdatesEnabled(False) # UI 다시 그리기 일시 정지
#         self.list_widget.clear()
        
#         # 반복문으로 하나씩 넣지 않고 한 번에 통째로 삽입
#         self.list_widget.addItems(valid_values_str)
        
#         # 삽입된 아이템들에 체크박스 속성 일괄 부여
#         for i in range(self.list_widget.count()):
#             item = self.list_widget.item(i)
#             item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
#             item.setCheckState(Qt.Checked)
            
#         self.list_widget.setUpdatesEnabled(True) # UI 다시 그리기 재개      

#         # 4. 자동완성 기능 설정
#         completer = QCompleter(valid_values_str, self)
#         completer.setFilterMode(Qt.MatchContains)
#         self.cond_input1.setCompleter(completer); self.cond_input2.setCompleter(completer)

#         self.cond_combo.blockSignals(True); self.cond_combo.clear()
#         # NULL 옵션은 이제 여기서 제거되었습니다 (상단 버튼으로 이동)
#         if self.is_numeric:
#             self.cond_combo.addItems(["같음 (=)", "같지 않음 (≠)", "초과 (>)", "미만 (<)", "이상 (≥)", "이하 (≤)", "사이 (포함)", "사이에 없음 (포함)"])
#         else:
#             self.cond_combo.addItems(["같음 (=)", "같지 않음 (≠)", "포함", "포함하지 않음", "시작 문자", "종료 문자"])
#         self.cond_combo.blockSignals(False)

#         self.update_condition_ui()
#         QApplication.restoreOverrideCursor()


#     def update_condition_ui(self):
#         op = self.cond_combo.currentText()
#         is_between = "사이" in op
#         self.cond_input1.setVisible(True); self.cond_input2.setVisible(is_between)

#     def filter_list(self, text):
#         for i in range(self.list_widget.count()):
#             item = self.list_widget.item(i)
#             item.setHidden(text.lower() not in item.text().lower())

#     def set_check_all(self, state):
#         for i in range(self.list_widget.count()):
#             item = self.list_widget.item(i)
#             if not item.isHidden(): item.setCheckState(state)

#     def apply_filter(self):
#         self.filter_data['field'] = self.field_combo.currentText()
#         self.filter_data['is_numeric'] = self.is_numeric
        
#         # NULL 버튼 상태 저장
#         if self.radio_null.isChecked(): self.filter_data['null_status'] = 'null'
#         elif self.radio_not_null.isChecked(): self.filter_data['null_status'] = 'not_null'
#         else: self.filter_data['null_status'] = 'all'

#         # 상세 탭 데이터 수집
#         if self.radio_all.isChecked():
#             if self.tabs.currentIndex() == 0:
#                 checked_vals = [self.list_widget.item(i).text() for i in range(self.list_widget.count()) if self.list_widget.item(i).checkState() == Qt.Checked]
#                 # --- 수정할 부분: 0개 선택 시 경고 띄우고 창이 안 닫히게 방어 ---
#                 if len(checked_vals) == 0:
#                     QMessageBox.warning(self, "경고", "선택된 값이 없습니다. 최소 하나 이상의 값을 체크해 주세요.")
#                     return # 여기서 함수를 멈추어 창이 닫히지 않게 함
                
#                 if len(checked_vals) == self.list_widget.count(): self.filter_data['type'] = 'none'
#                 else: self.filter_data.update({'type': 'value', 'values': checked_vals})
#             else:
#                 op = self.cond_combo.currentText()
#                 val1, val2 = self.cond_input1.text().strip(), self.cond_input2.text().strip()
#                 if val1: self.filter_data.update({'type': 'condition', 'op': op, 'val1': val1, 'val2': val2})
#                 else: self.filter_data['type'] = 'none'
#         else:
#             self.filter_data['type'] = 'none' # NULL 모드일 땐 탭 조건 무시
            
#         self.accept()