from qgis.PyQt.QtCore import QSettings
from qgis.gui import QgsMapToolEmitPoint
from qgis.core import Qgis

import datetime
import base64
import hashlib
import subprocess
import sys
import platform

VERSION = Qgis.QGIS_VERSION_INT

try:
    from Crypto.Cipher import AES

except:
    if platform.system() == "Darwin":
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in sys.executable:
            sys.path.append(qgis_python_path)
            subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'pycryptodome'])
    else:
        python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
        subprocess.check_call(['python', '-m', 'pip', 'install', 'pycryptodome', '--no-cache-dir'])

    from Crypto.Cipher import AES

BS = 16 # blocksize를 16바이트로 고정시켜야 함(AES의 특징)

# AES에서는 블럭사이즈가 128bit 즉 16byte로 고정되어 있어야 하므로 문자열을 encrypt()함수 인자로 전달시
# 입력 받은 데이터의 길이가 블럭사이즈의 배수가 아닐때 아래와 같이 패딩을 해주어야 한다.
# 패딩: 데이터의 길이가 블럭사이즈의 배수가 아닐때 마지막 블록값을 추가해 블록사이즈의 배수로 맞추어 주는 행위
pad = (lambda s: s+ (BS - len(s) % BS) * chr(BS - len(s) % BS).encode())
unpad = (lambda s: s[:-ord(s[len(s)-1:])])

class AESCipher(QgsMapToolEmitPoint):
    def __init__(self, iface):
        self.iface = iface
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        today = datetime.date.today()
        y = today.year
        key = self.QSettings.value('lineEdit_pluginKey', None)
        if key is None:
            self.key = None
        else:
            self.key = f'{key}' # _{y}'

    def decrypt(self, enc): # 복호화 함수 -> 암호화의 역순으로 진행
        if self.key is None:
            decText = None
        else:
            dec = hashlib.sha256(self.key.encode()).digest() # 키가 쉽게 노출되는 것을 막기 위해 키를 어렵게 처리하는 과정으로 보통 해시를 적용
            enctext = base64.b64decode(enc) # 암호화된 문자열을 base64 디코딩 후
            cipher = AES.new(dec, AES.MODE_CBC, self.__iv().encode('utf8')) # AES암호화 알고리즘 처리(한글처리를 위해 encode('utf8') 적용)
            decval = cipher.decrypt(enctext) # base64 디코딩된 암호화 문자열을 복호화
            decText = unpad(decval).decode('utf-8') # 복호화된 문자열에서 패딩처리를 풀고(unpading) 리턴
        
        return decText

    def encrypt(self, message): # 암호화 함수
        if self.key is None:
            encText = None
        else:
            dec = hashlib.sha256(self.key.encode()).digest() # 키가 쉽게 노출되는 것을 막기 위해 키를 어렵게 처리하는 과정으로 보통 해시를 적용
            message = message.encode() # 문자열 인코딩
            raw = pad(message) # 인코딩된 문자열을 패딩처리
            cipher = AES.new(dec, AES.MODE_CBC, self.__iv().encode('utf8')) # AES 암호화 알고리즘 처리(한글처리를 위해 encode('utf8') 적용)
            encval = cipher.encrypt(raw) # 패딩된 문자열을 AES 알고리즘으로 암호화
            encText = base64.b64encode(encval).decode('utf-8')
        
        return encText # 암호화된 문자열을 base64 인코딩 후 리턴

    def __iv(self):
        return chr(0) * 16