# -*- coding: utf-8 -*-
import os
import time
import random
import zipfile
import requests
from datetime import datetime
from io import BytesIO

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsSymbol,
    QgsSimpleFillSymbolLayer,
    QgsRendererCategory,
    QgsCategorizedSymbolRenderer,
    QgsPalLayerSettings,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon, QFont
from qgis.PyQt.QtWidgets import QMenu, QAction, QToolButton


class CoordinateToolShpLoader:
    def __init__(self, main_tool, iface, plugin_dir):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = plugin_dir

        self.init_ui()

    def init_ui(self):
        """툴바 드롭다운 및 메뉴 액션 생성"""
        # 툴바 드롭다운 버튼 생성
        self.indexshp = QToolButton(self.main.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")

        # 메뉴 드롭다운 목록 생성
        self.Menu = QMenu()
        self.Menu.setObjectName('쉐입파일')

        # 1. BES 인덱스
        icon = QIcon(self.plugin_dir + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(lambda *args: self.shpIndex(1, self.besindex, "Bessel_Index", "Bessel_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.besindex)
        self.indexshp.setDefaultAction(self.besindex)
        self.Menu.addAction(self.besindex)

        # 2. GRS 인덱스
        icon = QIcon(self.plugin_dir + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "GRS인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('GRS인덱스')
        self.grsindex.triggered.connect(lambda *args: self.shpIndex(2, self.grsindex, "GRS_Index", "GRS_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex)
        self.Menu.addAction(self.grsindex)

        # 3. WGS84 인덱스
        icon = QIcon(self.plugin_dir + '/icons/wgsindex.png')
        self.wgsindex = QAction(icon, "WGS인덱스", self.iface.mainWindow())
        self.wgsindex.setObjectName('WGS인덱스')
        self.wgsindex.triggered.connect(lambda *args: self.shpIndex(3, self.wgsindex, "WGS84_Index", "WGS84_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex)
        self.Menu.addAction(self.wgsindex)

        # 4. 협력사 인덱스
        icon = QIcon(self.plugin_dir + '/icons/partnerindex.png')
        self.parindex = QAction(icon, "협력사인덱스", self.iface.mainWindow())
        self.parindex.setObjectName('협력사인덱스')
        self.parindex.triggered.connect(lambda *args: self.shpIndex(4, self.parindex, "협력사_Index", "Partner_Index.shp", "협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex)
        self.Menu.addAction(self.parindex)

        # 5. 시도행정계
        icon = QIcon(self.plugin_dir + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(lambda *args: self.shpIndex(5, self.ctpshp, "시도행정계", "ctp.shp", "CTP_KOR_NM", "CTP_KOR_NM", 0.6))
        self.indexshp.addAction(self.ctpshp)
        self.Menu.addAction(self.ctpshp)

        # 6. 시군구행정계
        icon = QIcon(self.plugin_dir + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(lambda *args: self.shpIndex(6, self.sigshp, "시군구행정계", "sig.shp", "SIG_KOR_NM", "CTP_KOR_NM", 0.3))
        self.indexshp.addAction(self.sigshp)
        self.Menu.addAction(self.sigshp)

        # 상단 메뉴바에 쉐입파일 액션 등록
        icon_main = QIcon(self.plugin_dir + '/icons/shp.png')
        self.shp_action = QAction(icon_main, '쉐입파일', self.iface.mainWindow())
        self.shp_action.setMenu(self.Menu)

    def shpIndex(self, idx, Action, cmtName, fileName, leLabefield, symbolfield, lineWidth, *args):
        """SHP 파일 로드 및 최신 여부 검사 후 다운로드/스타일 적용"""
        self.main.Delete()
        self.indexshp.setDefaultAction(Action)
        layers = QgsProject.instance().mapLayersByName(cmtName)
        if layers:
            layer = layers[0]
            layer.triggerRepaint()
        else:
            filepath = os.path.join(self.plugin_dir, 'shp', fileName)
            zipinfo_time = datetime.min

            if os.path.isfile(filepath):
                modification_time = os.path.getmtime(filepath)
                getctime_time = datetime.fromtimestamp(int(modification_time))

                file_zip = fileName.split('.')[0] + '.zip'
                raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip

                try:
                    response = requests.get(raw_url, verify=False, timeout=5)
                    if response.status_code == 200:
                        with zipfile.ZipFile(BytesIO(response.content)) as shp_zip:
                            try:
                                zipinfo = shp_zip.getinfo(fileName)
                                zipinfo_time = datetime(*zipinfo.date_time)
                            except KeyError:
                                pass
                except Exception:
                    pass

                if zipinfo_time > getctime_time:
                    self.indexdownload(fileName)

                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)
            else:
                self.indexdownload(fileName)
                time.sleep(1)
                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

    def shpimport(self, idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth, *args):
        """SHP 파일을 메모리 레이어로 프로젝트에 적재"""
        existing_layer = QgsVectorLayer(filepath, cmtName, "ogr")
        if not existing_layer.isValid():
            return

        crs = existing_layer.crs().authid()
        memory_layer = QgsVectorLayer(f"Polygon?crs={crs}", cmtName, "memory")

        memory_layer_data_provider = memory_layer.dataProvider()
        memory_layer.startEditing()
        memory_layer_data_provider.addAttributes(existing_layer.fields().toList())
        memory_layer.updateFields()

        features = list(existing_layer.getFeatures())
        memory_layer_data_provider.addFeatures(features)
        memory_layer.commitChanges()

        QgsProject.instance().addMapLayer(memory_layer)

        if idx in (1, 2, 3):
            memory_layer.loadNamedStyle(os.path.join(self.plugin_dir, 'style', "index.qml"))
        else:
            self.setsymbol(memory_layer, leLabefield, symbolfield, lineWidth)

        memory_layer.triggerRepaint()

    def indexdownload(self, fileName):
        """깃허브에서 최신 압축 파일 다운로드 및 해제"""
        file_zip = fileName.split('.')[0] + '.zip'
        destination_path = os.path.join(self.plugin_dir, file_zip)
        extracted_folder = os.path.join(self.plugin_dir, 'shp')
        if not os.path.exists(extracted_folder):
            os.makedirs(extracted_folder)

        raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip
        try:
            response = requests.get(raw_url, verify=False, timeout=10)
            if response.status_code == 200:
                with open(destination_path, 'wb') as file:
                    file.write(response.content)

                with zipfile.ZipFile(destination_path, 'r') as zip_ref:
                    zip_ref.extractall(extracted_folder)

                if os.path.exists(destination_path):
                    os.remove(destination_path)
        except Exception as e:
            print(f"다운로드 실패: {e}")

    def setsymbol(self, layer, leLabefield, symbolfield, lineWidth, *args):
        """레이어 카테고리 심볼 및 라벨 설정"""
        fni = layer.dataProvider().fields().indexFromName(symbolfield)
        unique_values = layer.uniqueValues(fni)

        categories = []
        for unique_value in unique_values:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            layer_style = {
                'style': 'no',
                'color': '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256)),
                'outline_color': '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256)),
                'outline_width': lineWidth
            }
            symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)
            if symbol_layer is not None:
                symbol.changeSymbolLayer(0, symbol_layer)

            category = QgsRendererCategory(unique_value, symbol, str(unique_value))
            categories.append(category)

        renderer = QgsCategorizedSymbolRenderer(symbolfield, categories)
        if renderer is not None:
            layer.setRenderer(renderer)

        layer.triggerRepaint()

        # 라벨 설정
        layer_settings = QgsPalLayerSettings()
        text_format = QgsTextFormat()
        text_format.setFont(QFont("맑은 고딕"))
        text_format.setSize(9)

        layer_settings.setFormat(text_format)
        layer_settings.fieldName = leLabefield
        layer_settings.enabled = True

        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)

        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

    def unload(self):
        """리소스 정리"""
        if hasattr(self, 'indexshp') and self.indexshp:
            try:
                self.indexshp.deleteLater()
            except Exception:
                pass