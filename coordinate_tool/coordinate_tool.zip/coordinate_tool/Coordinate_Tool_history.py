# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProject,
    QgsCoordinateTransform
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QFrame


class CoordinateToolHistory:
    def __init__(self, main_tool, iface, plugin_dir):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = plugin_dir

        # ─────────────────────────────────────────────────────────────
        # 1. 화면 영역(Extent) 히스토리 변수
        # ─────────────────────────────────────────────────────────────
        self.history = []
        self.current_index = -1
        self._block = False

        # 초기 영역 상태 저장
        initial_extent = self.canvas.extent()
        initial_crs = self.canvas.mapSettings().destinationCrs()
        self.history.append((initial_extent, initial_crs))

        # ─────────────────────────────────────────────────────────────
        # 2. 객체 선택(Selection) 히스토리 변수
        # ─────────────────────────────────────────────────────────────
        self.select_history = []    # (layer_id, fids) 튜플 리스트
        self.select_index = -1
        self._block1 = False

        # ─────────────────────────────────────────────────────────────
        # 3. 툴바 및 액션 초기화
        # ─────────────────────────────────────────────────────────────
        self.init_toolbar()

        # ─────────────────────────────────────────────────────────────
        # 4. 시그널 연결
        # ─────────────────────────────────────────────────────────────
        self.canvas.extentsChanged.connect(self.on_extent_changed)
        self.canvas.selectionChanged.connect(self.select_toggle)

    def init_toolbar(self):
        """영역이동 툴바 및 액션 생성"""
        self.zoom_toolbar = self.iface.addToolBar('영역이동 툴바')
        self.zoom_toolbar.setObjectName('Coordinate_Tool_zoom_toolbar')
        self.zoom_toolbar.setToolTip('영역이동 툴바')

        # 화면 뒤로 가기
        icon = QIcon(self.plugin_dir + '/icons/go_back.png')
        self.action_back = QAction(icon, "뒤로 가기", self.iface.mainWindow())
        self.action_back.setObjectName('뒤로 가기')
        self.action_back.setEnabled(False)
        self.action_back.triggered.connect(self.go_back)
        self.zoom_toolbar.addAction(self.action_back)

        # 화면 앞으로 가기
        icon = QIcon(self.plugin_dir + '/icons/go_forward.png')
        self.action_forward = QAction(icon, "앞으로 가기", self.iface.mainWindow())
        self.action_forward.setObjectName('앞으로 가기')
        self.action_forward.setEnabled(False)
        self.action_forward.triggered.connect(self.go_forward)
        self.zoom_toolbar.addAction(self.action_forward)

        # 구분 세로선
        self.zoom_toolbar.addSeparator()
        # vertical_line = QFrame(self.iface.mainWindow())
        # vertical_line.setFixedWidth(5)
        # vertical_line.setFrameShape(QFrame.VLine)
        # vertical_line.setFrameShadow(QFrame.Sunken)
        # self.zoom_toolbar.addWidget(vertical_line)

        # 선택 되돌리기
        icon = QIcon(self.plugin_dir + '/icons/select_back.png')
        self.select_back = QAction(icon, "선택 되돌리기", self.iface.mainWindow())
        self.select_back.setObjectName('선택 되돌리기')
        self.select_back.setEnabled(False)
        self.select_back.triggered.connect(self.go_select_back)
        self.zoom_toolbar.addAction(self.select_back)

        # 선택 다시하기
        icon = QIcon(self.plugin_dir + '/icons/select_forward.png')
        self.select_forward = QAction(icon, "선택 다시하기", self.iface.mainWindow())
        self.select_forward.setObjectName('선택 다시하기')
        self.select_forward.setEnabled(False)
        self.select_forward.triggered.connect(self.go_select_forward)
        self.zoom_toolbar.addAction(self.select_forward)

    # ═══════════════════════════════════════════════════════════════
    # 화면 영역(Extent) 히스토리 로직
    # ═══════════════════════════════════════════════════════════════
    def on_extent_changed(self, *args):
        if self._block:
            return
        extent = self.canvas.extent()
        crs = self.canvas.mapSettings().destinationCrs()
        # 현재 인덱스 이후 기록 삭제 (Redo 불가능 상태로 갱신)
        self.history = self.history[:self.current_index + 1]
        self.history.append((extent, crs))
        self.current_index = len(self.history) - 1
        self.update_buttons()

    def go_back(self, *args):
        if self.current_index > 0:
            self._block = True
            self.current_index -= 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()

    def go_forward(self, *args):
        if self.current_index < len(self.history) - 1:
            self._block = True
            self.current_index += 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()

    def restore_extent(self, extent_crs_tuple, *args):
        extent, saved_crs = extent_crs_tuple
        current_crs = self.canvas.mapSettings().destinationCrs()
        if saved_crs != current_crs:
            transform = QgsCoordinateTransform(
                saved_crs,
                current_crs,
                QgsProject.instance().transformContext()
            )
            extent = transform.transformBoundingBox(extent)

        self.canvas.setExtent(extent)
        self.canvas.refresh()

    def update_buttons(self, *args):
        if hasattr(self, 'action_back'):
            self.action_back.setEnabled(self.current_index > 0)
        if hasattr(self, 'action_forward'):
            self.action_forward.setEnabled(self.current_index < len(self.history) - 1)

    # ═══════════════════════════════════════════════════════════════
    # 객체 선택(Selection) 히스토리 로직
    # ═══════════════════════════════════════════════════════════════
    def select_toggle(self, layer, *args):
        if self._block1:
            return

        if not layer or layer.selectedFeatureCount() == 0:
            self.select_index = len(self.select_history)
            return

        layer_id = layer.id()
        fids = layer.selectedFeatureIds()
        self.select_history = self.select_history[:self.select_index + 1]
        self.select_history.append((layer_id, fids))
        self.select_index = len(self.select_history) - 1
        self.update_buttons1()

    def clean_select_history(self, *args):
        """삭제된 레이어 기록 제거"""
        project = QgsProject.instance()
        new_hist = [
            (lid, fids)
            for (lid, fids) in self.select_history
            if project.mapLayer(lid)
        ]
        self.select_history = new_hist

        if not new_hist:
            self.select_index = -1
        else:
            self.select_index = min(self.select_index, len(new_hist) - 1)

        self.update_buttons1()

    def re_select(self, select_tuple, *args):
        layer_id, fids = select_tuple
        project = QgsProject.instance()

        layer = project.mapLayer(layer_id)
        if not layer:
            self.clean_select_history()
            return

        layer.removeSelection()
        layer.selectByIds(fids)
        self.canvas.zoomToSelected(layer)
        self.canvas.refresh()

    def go_select_back(self, *args):
        if self.select_index > 0:
            active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
            if not active_layer:
                return
            target_layer_id = active_layer.id()

            found_index = -1
            for i in range(self.select_index - 1, -1, -1):
                if self.select_history[i][0] == target_layer_id:
                    found_index = i
                    break

            if found_index != -1:
                self._block1 = True
                self.select_index = found_index
                self.re_select(self.select_history[self.select_index])
                self._block1 = False
                self.update_buttons1()

    def go_select_forward(self, *args):
        if self.select_index < len(self.select_history) - 1:
            active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
            if not active_layer:
                return
            target_layer_id = active_layer.id()

            found_index = -1
            for i in range(self.select_index + 1, len(self.select_history)):
                if self.select_history[i][0] == target_layer_id:
                    found_index = i
                    break

            if found_index != -1:
                self._block1 = True
                self.select_index = found_index
                self.re_select(self.select_history[self.select_index])
                self._block1 = False
                self.update_buttons1()

    def update_buttons1(self, *args):
        active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
        if not active_layer:
            if hasattr(self, 'select_back'):
                self.select_back.setEnabled(False)
            if hasattr(self, 'select_forward'):
                self.select_forward.setEnabled(False)
            return

        target_layer_id = active_layer.id()

        has_back = any(h[0] == target_layer_id for h in self.select_history[:self.select_index])
        has_forward = any(h[0] == target_layer_id for h in self.select_history[self.select_index + 1:])

        if hasattr(self, 'select_back'):
            self.select_back.setEnabled(has_back)
        if hasattr(self, 'select_forward'):
            self.select_forward.setEnabled(has_forward)

    # ═══════════════════════════════════════════════════════════════
    # 해제 로직
    # ═══════════════════════════════════════════════════════════════
    def unload(self):
        """시그널 연결 해제 및 툴바 제거"""
        try:
            self.canvas.extentsChanged.disconnect(self.on_extent_changed)
        except Exception:
            pass

        try:
            self.canvas.selectionChanged.disconnect(self.select_toggle)
        except Exception:
            pass

        if hasattr(self, 'zoom_toolbar') and self.zoom_toolbar:
            try:
                del self.zoom_toolbar
            except Exception:
                pass

        self.history = []
        self.select_history = []
        self.current_index = -1
        self.select_index = -1