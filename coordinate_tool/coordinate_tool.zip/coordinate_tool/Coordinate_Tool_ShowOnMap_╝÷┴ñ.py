from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsWkbTypes,
    Qgis
)
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand
from PyQt5.QtCore import QSettings, QTimer, Qt
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtGui import QKeySequence
import webbrowser, requests, json, math
from . import Coordinate_Tool_data

class CoordinateToolShowOnMap(QgsMapToolEmitPoint):
    # Predefined CRS instances
    CRS = {
        'wgs84': QgsCoordinateReferenceSystem('EPSG:4326'),
        '5181': QgsCoordinateReferenceSystem('EPSG:5181'),
        '3857': QgsCoordinateReferenceSystem('EPSG:3857')
    }

    def __init__(self, parent_tool, iface):
        super().__init__(iface.mapCanvas())
        self.iface = iface
        self.parent = parent_tool
        self.canvas = iface.mapCanvas()
        self.settings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.external_count = len(Coordinate_Tool_data.MAP_PROVIDERS)

        # Rubber bands for drawing
        self.point_band = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.line_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)

        # Interaction state
        self.click_started = False
        self.line_drawn = False
        self.start_pt = None
        self.end_pt = None

    def activate(self):
        self.canvas.setCursor(Qt.CrossCursor)

    def deactivate(self):
        self.clear_rubber()
        self.iface.actionPan().trigger()

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.clear_rubber()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, event):
        self.clear_rubber()
        x, y = event.pos().x(), event.pos().y()
        self.start_pt = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.point_band.reset()
        self.point_band.setColor(Qt.red)
        self.point_band.addPoint(self.start_pt)
        self.click_started = True

    def canvasMoveEvent(self, event):
        if not self.click_started:
            return
        x, y = event.pos().x(), event.pos().y()
        self.end_pt = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        # Draw or update line
        self.line_band.reset()
        self.line_band.setColor(Qt.red)
        self.line_band.addPoint(self.start_pt)
        self.line_band.addPoint(self.end_pt)
        self.line_drawn = True

    def canvasReleaseEvent(self, event):
        if not self.click_started or not self.line_drawn:
            self.clear_rubber()
            return

        # Prepare coordinates
        map_crs = self.canvas.mapSettings().destinationCrs()
        lon, lat = self._to_wgs84(self.end_pt, map_crs)
        angle = self._compute_angle(self.start_pt, self.end_pt)

        # Determine provider and zoom
        button = event.button()
        provider_index = int(self.settings.value(
            'MapProviderRight' if button == Qt.RightButton else 'MapProvider',
            0
        ))
        place_key = 'zoomSpinBox_2' if button == Qt.RightButton else 'zoomSpinBox_1'
        zoom = int(self.settings.value(place_key, 15))
        placemark_flag = int(self.settings.value(
            'checkBox_placemark_2' if button == Qt.RightButton else 'checkBox_placemark_1',
            Qt.Checked
        ))

        # Draw marker and open external URL
        self.parent.Draw_Marker(self.end_pt, 3 if button == Qt.RightButton else 2)
        url = self._build_map_url(provider_index, lon, lat, angle, zoom, placemark_flag, map_crs)
        if url:
            webbrowser.open(url)
            self.iface.messageBar().pushMessage(
                '', f"Viewing coordinate {lat:.6f}, {lon:.6f}", level=Qgis.Info, duration=5
            )
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "지도를 불러오는 데 실패했습니다.")

        # Cleanup
        QTimer.singleShot(1000, self.clear_rubber)

    def clear_rubber(self):
        self.point_band.reset()
        self.line_band.reset()
        self.click_started = False
        self.line_drawn = False

    def _to_wgs84(self, point, src_crs):
        transformer = QgsCoordinateTransform(src_crs, self.CRS['wgs84'], QgsProject.instance())
        p = transformer.transform(point)
        return p.x(), p.y()

    def _compute_angle(self, p0, p1):
        rad = math.atan2(p1.x() - p0.x(), p1.y() - p0.y())
        deg = math.degrees(rad)
        return (int(deg) + 360) % 360

    def _build_map_url(self, idx, lon, lat, angle, zoom, placemark, canvas_crs):
        providers = Coordinate_Tool_data.MAP_PROVIDERS
        count = self.external_count
        # Determine template and name
        if idx >= count:
            name, template = self.settings.value('UserMapProviders')[idx - count]
        else:
            name, url_with_point, url_without_point = providers[idx]
            # Use placemark flag (Qt.Checked == 2) to choose URL with or without marker
            template = url_with_point if placemark == Qt.Checked else url_without_point

        # Handle special cases
        if '카카오' in name:
            return self._kakao_url(pt=self.end_pt, canvas_crs=canvas_crs, template=template, full=True, angle=angle)
        if '네이버' in name:
            return self._naver_url(pt=self.end_pt, template=template, angle=angle)

        return template.format(lon=lon, lat=lat, zoom=zoom, angle=angle)

    def _kakao_url(self, pt, canvas_crs, template, full, angle):
        # Transform to EPSG:5181 for Kakao
        x, y = QgsCoordinateTransform(canvas_crs, self.CRS['5181'], QgsProject.instance()).transform(pt)
        resp = requests.get(
            f'https://rv.map.kakao.com/roadview-search/v2/nodes?PX={x}&PY={y}&RAD=35&PAGE_SIZE=50',
            verify=False
        )
        data = resp.json()['street_view']['streetList'][0]
        return template.format(id=data['id'], lon=data['wcongx'], lat=data['wcongy'], angle=angle)

    def _naver_url(self, pt, template, angle):
        # Transform to WGS84 then EPSG:3857 for Naver
        lon, lat = self._to_wgs84(pt, self.canvas.mapSettings().destinationCrs())
        resp = requests.post(f'https://m.map.naver.com/viewer/panorama.naver?lng={lon}&lat={lat}', verify=False)
        if resp.status_code != 200:
            return None
        text = resp.text
        idx = text.find('"panorama"') + 11
        json_str = text[idx:text.find('}', idx)+1]
        pano = json.loads(json_str)
        x, y = QgsCoordinateTransform(self.CRS['wgs84'], self.CRS['3857'], QgsProject.instance()).transform(lon, lat)
        return template.format(id=pano['id'], lon=x, lat=y, angle=angle, tilt=pano.get('tilt', 0))
