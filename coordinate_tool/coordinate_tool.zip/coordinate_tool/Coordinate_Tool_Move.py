from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject, 
                       QgsMarkerSymbol, 
                       QgsTextAnnotation)

from PyQt5.QtCore import (QSizeF,
                          QPointF,
                          QSettings)

from qgis.gui import (QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from PyQt5.QtGui import (QKeySequence,
                         QTextDocument,
                         QColor,
                         QIcon)

from qgis.PyQt.QtWidgets import QMessageBox, QDialog

from PyQt5.QtWidgets import (QPushButton,
                             QTableWidgetItem)

import os.path, requests

from .Coordinate_Tool_Funtion import capture,Coordinate_funtion
from .Coordinate_Tool_decryptKey import AESCipher
from . import Coordinate_Tool_data

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Move.ui'))

class CoordinateToolMove(QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolMove, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.QSettings=QSettings()
        self.Funtion = Coordinate_funtion(self,iface)
        self.apikeys = Coordinate_Tool_data.API_KEYS
        self.AESCipher = AESCipher(self)
        
# 도엽이동
        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_3.clicked.connect(self.accept2)
# 주소이동
        self.toolButton_5.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_5.clicked.connect(self.accept3)
# 주소이동API설정
        # self.SearchSetting = SearchAddress(self,iface)
        # self.toolButton_03.setIcon(QIcon(os.path.dirname(__file__) + "/icons/setting.png"))
        # self.toolButton_03.clicked.connect(self.setting)
        # self.AddressSearchAPI.setText(self.Labelset(int(locale.value('coordinate_tool/AddressSearchComboBox_2', 0))))
        
        idx = int(self.QSettings.value('coordinate_tool/AddressSearchComboBox_3', 0))
        self.AddressSearchComboBox_3.setCurrentIndex(idx)
        self.AddressSearchComboBox_3.currentIndexChanged.connect(self.AddressSearchAPIChange)

# 경위도 이동
        self.toolButton_7.setIcon(QIcon(os.path.dirname(__file__) + "/icons/zoom.png"))
        self.toolButton_7.clicked.connect(self.accept1)

# 입력란 클릭시 이벤트 발생 _ 클릭한 입력란 제외삭제
        self.lineEdit_lon.mouseReleaseEvent = self.mouseRelease_1
        self.lineEdit_lat.mouseReleaseEvent = self.mouseRelease_1
        self.lineEdit_mapid.mouseReleaseEvent = self.mouseRelease_2
        self.lineEdit_address.mouseReleaseEvent = self.mouseRelease_3

# 입력란 삭제
    def mouseRelease_1(self,Event):
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()
        
    def mouseRelease_2(self,Event):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_address.clear()
        
    def mouseRelease_3(self,Event):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()

    def RemoveAll(self):
        self.lineEdit_lon.clear()
        self.lineEdit_lat.clear()
        self.lineEdit_mapid.clear()
        self.lineEdit_address.clear()

    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            # self.remove_Marker()
            pass
        # 엔터 누를때 이벤트 발생
        elif e.matches(QKeySequence.InsertParagraphSeparator):
            self.CTool.Delete_Marker()
            if self.lineEdit_address.text()!='':
                self.accept3()
            elif self.lineEdit_mapid.text()!='':
                self.accept2()
            elif self.lineEdit_lon.text()!='':
                self.accept1()
            else:           
                pass

    def AddressSearchAPIChange(self):
        idx = int(self.AddressSearchComboBox_3.currentIndex())
        self.QSettings.setValue('coordinate_tool/AddressSearchComboBox_3', idx)

# 경위도 값이 존재==========================================================================================================================
    def accept1(self):
        if self.lineEdit_lon.text()!='':
            if self.lineEdit_lat.text()!='':
                lon=self.lineEdit_lon.text().strip()
                lat=self.lineEdit_lat.text().strip()
                lon=(int(float(lon)))/360000
                lat=(int(float(lat)))/360000
                checkBox=2
                self.Funtion.moveto(epsg4301, lon, lat, 0)
            else:
                print('경위도 입력 확인')
                pass
        self.canvas.refresh()
# MAPID 값이 존재==========================================================================================================================
    def accept2(self):
        if self.lineEdit_mapid.text()!='':
            MapID=self.lineEdit_mapid.text().strip()
            if len(MapID) >= 4:
                map1=int(MapID[0])
                map2=int(MapID[1])
                map3=int(MapID[2])
                map4=int(MapID[3])
                # 도엽중앙 좌표값 추출
                lon=(43897500+(map1*360000)+(45000*map3))
                lat=(11625000+(map2*240000)+(30000*map4))
                # 도엽 5자로 좌표값 추출
                if len(MapID) >= 5:
                    if (MapID[4])=='(':     #FS 좌표라면 패스
                        pass
                    else:
                        map5=int(MapID[4])
                        if map5==1:
                            lon = lon - (45000/4)
                            lat = lat + (30000/4)
                        elif map5==2:
                            lon = lon + (45000/4)
                            lat = lat + (30000/4)
                        elif map5==3:
                            lon = lon + (45000/4)
                            lat = lat - (30000/4)
                        elif map5==4:
                            lon = lon - (45000/4)
                            lat = lat - (30000/4)

                        # 도엽 6자로 좌표값 추출
                        if len(MapID) >= 6:
                            map6=int(MapID[5])
                            if map6==1:
                                lon = lon - (45000/8)
                                lat = lat + (30000/8)
                            elif map6==2:
                                lon = lon + (45000/8)
                                lat = lat + (30000/8)
                            elif map6==3:
                                lon = lon + (45000/8)
                                lat = lat - (30000/8)
                            elif map6==4:
                                lon = lon - (45000/8)
                                lat = lat - (30000/8)
                        # 도엽 7자로 좌표값 추출
                        if len(MapID) >= 7:
                            map7=int(MapID[6])
                            if map7==1:
                                lon = lon - (45000/16)
                                lat = lat + (30000/16)
                            elif map7==2:
                                lon = lon + (45000/16)
                                lat = lat + (30000/16)
                            elif map7==3:
                                lon = lon + (45000/16)
                                lat = lat - (30000/16)
                            elif map7==4:
                                lon = lon - (45000/16)
                                lat = lat - (30000/16)
                # 추출된 경위도 값에서 360000나누어서 베셀 좌표로 변환
                lon=lon/360000
                lat=lat/360000
                self.Funtion.moveto(epsg4301, lon, lat, 0)                  
            else: # 도엽 입력값이 3자리 이하라면 패스
                pass
            self.canvas.refresh()
# 주소가 입력 되었다면 다음 함수 진행==========================================================================================================================
    def accept3(self):
        if self.lineEdit_address.text()!='':
            address=self.lineEdit_address.text().strip()
            # 주소로 좌표 찾기 API 인덱스
            idx=int(self.QSettings.value('coordinate_tool/AddressSearchComboBox_3', 0))
            if idx==0:
                self.kakaoaddress(address)  # kakao API
            elif idx==1:
                self.naveraddress(address) # naver API
            elif idx==2:
                self.vworldaddress(address,) # vworld API
            elif idx==3:
                self.jusoaddress(address) # juso API
            else:
                self.Routoaddress(address) # Routo API
        else:
            print('입력값 없음')
        self.canvas.refresh()
# kakao API
    def kakaoaddress(self,address):
        try:
            apikey = self.apikeys[str('kakao_APIkey')][0]
            REST_API_KEY = self.AESCipher.decrypt(apikey)
            if apikey != '':
                headers = {"Authorization": "KakaoAK {}".format(REST_API_KEY)}
                params = {"query": "{}".format(address)}
                url = "https://dapi.kakao.com/v2/local/search/address.json"
                request = requests.get(url, params=params, headers=headers)
                if request.status_code == 200:
                    data = request.json()
                    documents = data["documents"][0]
                    lon=documents["x"]
                    lat=documents["y"]
                    # 좌표값 취득후 화면이동 함수로 토스
                    self.Funtion.moveto(epsg4326, lon, lat, 0)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Kakao", "요청 오류 API KEY, 입력주소 재확인")
                    print("KA Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Kakao", "API key Null")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Kakao", "요청 오류 API KEY, 입력주소 재확인")
# naver API
    def naveraddress(self,address):
        try:
            apikey1 = self.apikeys[str('naver_client_id')][0]
            client_id = self.AESCipher.decrypt(apikey1)
            apikey2 = self.apikeys[str('naver_client_secret')][0]
            client_secret = self.AESCipher.decrypt(apikey2)
            if apikey1 != '' and  apikey2 != '':
                url = f"https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode?query={address}"
                headers = {'X-NCP-APIGW-API-KEY-ID': client_id,
                            'X-NCP-APIGW-API-KEY': client_secret
                            }
                request = requests.get(url, headers=headers)
                if request.status_code == 200:
                    data = request.json()
                    if data['addresses'] != [] :
                        lat = data['addresses'][0]['y']  # 위도
                        lon = data['addresses'][0]['x']  # 경도
                        # 좌표값 취득후 화면이동 함수로 토스
                        self.Funtion.moveto(epsg4326, lon, lat, 0)
                    else:
                        print("'addresses' not exist!")
                        # 입력된 주소 검색 실패시 kakao 로 재검색
                        self.kakaoaddress(address)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Naver", "요청 오류 API KEY, 입력주소 재확인")
                    print("NA Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Naver", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Naver", "요청 오류 API KEY, 입력주소 재확인")
            
# vworld API
    def vworldaddress(self,address):
        try:
            apikey = self.apikeys[str('Vworld_APIkey')][0]
            Vworld_APIkey = self.AESCipher.decrypt(apikey)
            if apikey != '':
                url = "http://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&crs=epsg:4326&address="
                url += address
                url += "&refine=true&simple=false&format=json&type=ROAD&key="
                url +=  Vworld_APIkey
                request = requests.get(url)
                if request.status_code == 200:
                    data = request.json()
                    # 도로명주소로 검색한 결과
                    if data['response']['status'] == "OK":
                        lon=data['response']['result']['point']['x']
                        lat=data['response']['result']['point']['y']
                        # 좌표값 취득후 화면이동 함수로 토스
                        self.Funtion.moveto(epsg4326, lon, lat, 0)
                    # 도로명 주소가 아니라면 지번 주소로 재검색
                    else:
                        url = "http://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&crs=epsg:4326&address="
                        url += address
                        url += "&refine=true&simple=false&format=json&type=PARCEL&key="
                        url +=  Vworld_APIkey
                        request = requests.get(url)
                        if request.status_code == 200:
                            data = request.json()
                            if data['response']['status'] == "OK":
                                lon=data['response']['result']['point']['x']
                                lat=data['response']['result']['point']['y']
                                # 좌표값 취득후 화면이동 함수로 토스
                                self.Funtion.moveto(epsg4326, lon, lat, 0)
                            else:
                                QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
                                print("Error Code:" + str(data['response']['status']))
                        else:
                            print("Error Code:" + str(request.status_code))
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
                    print("Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Vworld", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Vworld", "요청 오류 API KEY, 입력주소 재확인")
# juso API
    def jusoaddress(self,address):
        try:
            apikey1 = self.apikeys[str('Juso_road_APIkey')][0]
            Juso_APIkey = self.AESCipher.decrypt(apikey1)
            apikey2 = self.apikeys[str('Juso_coor_APIkey')][0]
            Juso_APIkey_2 = self.AESCipher.decrypt(apikey2)
            if apikey1 != '' and apikey2!= '':
                url = 'https://www.juso.go.kr/addrlink/addrLinkApi.do?currentPage=1&countPerPage=1&resultType=json&addInfoYn=Y&keyword='
                url += address
                url+='&confmKey='
                url+= Juso_APIkey
                request = requests.get(url)
                if request.status_code == 200:
                    data = request.json()
                    try:
                        juso=data['results']['juso'][0]
                        admCd=juso['admCd']
                        rnMgtSn=juso['rnMgtSn']
                        udrtYn=juso['udrtYn']
                        buldMnnm=juso['buldMnnm']
                        buldSlno=juso['buldSlno']
                        sURL = "https://www.juso.go.kr/addrlink/addrCoordApi.do?confmKey="
                        sURL += Juso_APIkey_2
                        sURL += "&admCd=" + admCd + "&rnMgtSn=" + rnMgtSn + "&udrtYn=" + udrtYn + "&buldMnnm=" + buldMnnm + "&buldSlno=" + buldSlno + "&resultType=json"
                        request = requests.get(sURL)
                        if request.status_code == 200:
                            data = request.json()
                            juso=data['results']['juso'][0]
                            lon=juso['entX']
                            lat=juso['entY']
                            setCRS = QgsCoordinateReferenceSystem('EPSG:5179')
                            self.Funtion.moveto(setCRS, lon, lat, 0)
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                            print("Error Code:" + str(request.status_code))
                    except:
                        QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
                    print("Error Code:" + str(request.status_code))
            else:
                QMessageBox.critical(self.iface.mainWindow(), "juso", "주소 이동 실패 API KEY 미입력")
        except:
            QMessageBox.critical(self.iface.mainWindow(), "juso", "요청 오류 API KEY, 입력주소 재확인")
 # Routo API
    def Routoaddress(self,address):
        try:
            url="https://api.routo.com/v1/geocode?key=AB7B15940E89447C&address="
            url += address
            request = requests.get(url)
            if request.status_code == 200:
                data = request.json()
                if data['count'] != 0:
                    if data['result'][0]['accuracy'] == 10:
                        lon=data['result'][0]['street']['lng']
                        lat=data['result'][0]['street']['lat']
                    elif data['result'][0]['accuracy'] == 20:
                        lon=data['result'][0]['jibun']['lng']
                        lat=data['result'][0]['jibun']['lat']
                    self.Funtion.moveto(epsg4326, lon, lat, 0)
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")
                print("Error Code:" + str(request.status_code))
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Routo", "요청 오류 입력주소 재확인")