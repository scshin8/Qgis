import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .Algorithm.Create_Qfield_GPSlog_Algorithm import Create_Qfield_GPSlog_Algorithm  # Qfield 로그 생성
from .Algorithm.Export_Qfield_SurveyLink_Algorithm import Export_Qfield_SurveyLink_Algorithm # Qfield 조사링크 추출
from .Algorithm.Create_Qfield_EVList_Algorithm import Create_Qfield_EVList_Algorithm # Qfield  수시 전기차
from .Algorithm.Create_Folder_Lise_Algorithm import ListAllFoldersAlgorithm # 하위 전체 폴더 리스트
from .Algorithm.Processes_Import_shp_files_Algorithm import Processes_merge_Algorithm # 폴더내 파일 순환 병합
from .Algorithm.Processes_Import_shp_files_Algorithm import Processes_autoIncremental_Algorithm # 폴더내 파일 순환 자동증가필드
from .Algorithm.Processes_Import_shp_files_Algorithm import Processes_Calculator_Algorithm # 폴더내 파일 순환 필드계산기
from .Algorithm.GuidedLine_Extraction_Algorithm import GuidedLine_Extraction_Algorithm # 영상인식 유도선 추출
from .Algorithm.Sign_Extraction_Algorithm import Sign_Extraction_Algorithm # 영상인식 유도선 추출
from .Algorithm.Create_Excel_to_Shp_Algorithm import Create_Excel_to_Shp_Algorithm # Excel_To_Shp
from .Algorithm.Processes_vlookup_Algorithm import Processes_vlookup_Algorithm # 로그 궤적 보정

class Coordinate_Tool_Algorithm(QgsProcessingProvider):

    def unload(self):
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        self.addAlgorithm(Create_Excel_to_Shp_Algorithm())
        self.addAlgorithm(Create_Qfield_EVList_Algorithm())
        self.addAlgorithm(Create_Qfield_GPSlog_Algorithm())
        self.addAlgorithm(Export_Qfield_SurveyLink_Algorithm())
        self.addAlgorithm(GuidedLine_Extraction_Algorithm())
        self.addAlgorithm(Sign_Extraction_Algorithm())
        self.addAlgorithm(Processes_merge_Algorithm())
        self.addAlgorithm(Processes_autoIncremental_Algorithm())
        self.addAlgorithm(Processes_Calculator_Algorithm())
        self.addAlgorithm(ListAllFoldersAlgorithm())
        self.addAlgorithm(Processes_vlookup_Algorithm())

    def icon(self):
        return QIcon(os.path.dirname(__file__) + '/icons/MyToolBox.png')

    def id(self):
        return 'MyToolBox'

    def name(self):
        return '좌표도구_툴박스'

    def longName(self):
        return self.name()
