import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .Algorithm.Create_Qfield_GPSlog_Algorithm import Create_Qfield_GPSlog_Algorithm  # Qfield 로그 생성
from .Algorithm.Export_Qfield_SurveyLink_Algorithm import Export_Qfield_SurveyLink_Algorithm # Qfield 조사링크 추출
from .Algorithm.Create_Qfield_EVList_Algorithm import Create_Qfield_EVList_Algorithm # Qfield  수시 전기차

# from .toolBox_Algorithm import CopyAttributesByLocationAlgorithm
# from .Algorithm.Create_Folder_Lise_Algorithm import ListSubfoldersAlgorithm # 하위 폴더 리스트
from .Algorithm.Create_Folder_Lise_Algorithm import ListAllFoldersAlgorithm # 하위 전체 폴더 리스트

from .Algorithm.GuidedLine_Extraction_Algorithm import GuidedLine_Extraction_Algorithm # 영상인식 유도선 추출
from .Algorithm.Create_Excel_to_Shp_Algorithm import Create_Excel_to_Shp_Algorithm # Excel_To_Shp
from .Algorithm.Create_Daily_shp_Merge_Algorithm import Create_Daily_shp_Merge_Algorithm # 조사등록 shp 병합

from .Algorithm.Processes_SHP_files_Algorithm import Processes_SHP_files_Algorithm # 주단위 SHP 파일 처리
from .Algorithm.Processes_Log_vertex_Algorithm import Processes_Log_vertex_Algorithm # 로그 궤적 보정
from .Algorithm.Processes_vlookup_Algorithm import Processes_vlookup_Algorithm # 로그 궤적 보정

class Coordinate_Tool_Algorithm(QgsProcessingProvider):

    def unload(self):
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        self.addAlgorithm(Create_Excel_to_Shp_Algorithm())
        self.addAlgorithm(Create_Daily_shp_Merge_Algorithm())
        self.addAlgorithm(Create_Qfield_EVList_Algorithm())
        self.addAlgorithm(Create_Qfield_GPSlog_Algorithm())
        self.addAlgorithm(Export_Qfield_SurveyLink_Algorithm())
        self.addAlgorithm(GuidedLine_Extraction_Algorithm())
        self.addAlgorithm(Processes_SHP_files_Algorithm())
        self.addAlgorithm(Processes_Log_vertex_Algorithm())
        # self.addAlgorithm(ListSubfoldersAlgorithm())
        self.addAlgorithm(ListAllFoldersAlgorithm())
        self.addAlgorithm(Processes_vlookup_Algorithm())

    def icon(self):
        return QIcon(os.path.dirname(__file__) + '/icons/MyToolBox.png')

    def id(self):
        return 'MyToolBox'

    def name(self):
        return '좌표도구_툴박스'

    def longName(self):
        return self.name()
