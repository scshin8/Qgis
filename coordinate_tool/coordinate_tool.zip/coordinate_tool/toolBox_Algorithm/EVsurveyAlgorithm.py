from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

class EVsurveyAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")


    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        excel_file = self.Qsettings.value('실사건', '')

        self.addParameter(QgsProcessingParameterFile('1', '실사건 리스트', behavior=QgsProcessingParameterFile.File, fileFilter='XLSX files (*.xlsx);;CSV files (*.csv);;XLTM files (*.xltm)', defaultValue=excel_file))
        # self.addParameter(QgsProcessingParameterFeatureSink('Result', '전기차실사건', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))


    def processAlgorithm(self, parameters, context, model_feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 1) '1_수시_전기차_리스트' 레이어 객체 가져오기
        project = QgsProject.instance()
        target_list = project.mapLayersByName('1_수시_전기차_리스트')
        if not target_list:
            raise QgsProcessingException("레이어 '1_수시_전기차_리스트'를 찾을 수 없습니다.")
        target_layer = target_list[0]

        # 입력된 값 가져오기기
        excel_file = self.parameterAsFile(parameters, '1', context)
        
        self.Qsettings.setValue('실사건', excel_file)

        # parameters['Result'].destinationName = '전기차실사건'

        feedback = QgsProcessingMultiStepFeedback(7, model_feedback)
        results = {}
        outputs = {}


        # 1���ڿ� ���� 01_NODE_STATS.csv
        alg_params = {
            'INPUT_1': excel_file,
            'INPUT_2': '|layername=전기차'
        }
        outputs['01_node_statscsv'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 2ǥ�������� ����
        alg_params = {
            'EXPRESSION': '"담당" = \'대구\' and "LOG" is Null',
            'INPUT': outputs['01_node_statscsv']['CONCATENATION'],
            'OUTPUT': 'memory:'
        }
        outputs['2'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 3�ʵ� ����
        alg_params = {
            'FIELD_LENGTH': 8,
            'FIELD_NAME': 'LON',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': ' Fs2Lon( "BESSEL좌표")',
            'INPUT': outputs['2']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # 4�ʵ� ����
        alg_params = {
            'FIELD_LENGTH': 8,
            'FIELD_NAME': 'LAT',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': ' Fs2Lat( "BESSEL좌표")',
            'INPUT': outputs['3']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['4'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}
        
        # # 5�ʵ� ����
        # alg_params = {
        #     'FIELD_LENGTH': 10,
        #     'FIELD_NAME': '조사완료',
        #     'FIELD_PRECISION': 0,
        #     'FIELD_TYPE': 2,  # Integer (32 bit)
        #     'FORMULA': 'NULL',
        #     'INPUT': outputs['4']['OUTPUT'],
        #     'OUTPUT': 'memory:'
        # }
        # outputs['5'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # feedback.setCurrentStep(5)
        # if feedback.isCanceled():
        #     return {}

        # 6�ʵ� ����
        alg_params = {
            'COLUMN': ['LOG','층수','실사내역','특이사항','실사완료','입력완료','실사주차(현황용)','보류대상','현황용_1'],
            'INPUT': outputs['4']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['6'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 7���̺����� ����Ʈ ����
        alg_params = {
            'INPUT': outputs['6']['OUTPUT'],
            'MFIELD': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('USER:100000'),
            'XFIELD': 'LON',
            'YFIELD': 'LAT',
            'ZFIELD': '',
            'OUTPUT': 'memory:'
        }
        outputs['_Result'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        # results['Result'] = outputs['_Result']['OUTPUT']

        # ▶ 반환된 레이어 ID 로부터 실제 QgsVectorLayer 객체 가져오기
        layer_id = outputs['_Result']['OUTPUT']
        result_layer = QgsProcessingUtils.mapLayerFromString(layer_id, context)
        if not result_layer or not result_layer.isValid():
            raise QgsProcessingException(f"생성된 레이어({layer_id})를 가져오지 못했습니다.")
        
        # 편집 모드 시작
        if not target_layer.isEditable():
            target_layer.startEditing()

        # ③ 필드 목록 미리 구하기
        target_fields = target_layer.fields()
        target_field_names = [f.name() for f in target_fields]
        result_field_names = [f.name() for f in result_layer.fields()]

        new_feats = []
        for feat in result_layer.getFeatures():
            new_feat = QgsFeature(target_fields)
            # geometry 복사
            new_feat.setGeometry(feat.geometry())

            # 속성값 하나씩 복사하며 타입에 맞게 캐스팅
            attrs = []
            for fld in target_fields:
                name = fld.name()
                match_name = None
                if name == 'KEY':
                    match_name = 'KEY'
                elif name == '명칭':
                    match_name = '명칭'
                else:
                    # prefix 일치 검사
                    match_name = None
                    for res_name in result_field_names:
                        if res_name.startswith(name) or name.startswith(res_name):
                            match_name = res_name
                            break
                # 필드 타입에 따라 변환
                if match_name:
                    val = feat[match_name]
                    # ② 타입에 맞춰 캐스팅
                    if fld.type() == QVariant.Int:
                        try:    attrs.append(int(val))
                        except: attrs.append(None)
                    elif fld.type() == QVariant.Double:
                        try:    attrs.append(float(val))
                        except: attrs.append(None)
                    elif fld.type() == QVariant.String:
                        attrs.append(str(val) if val is not None else '')
                    else:
                        attrs.append(val)
                else:
                    # 매칭 필드 없으면 None
                    attrs.append(None)

            new_feat.setAttributes(attrs)
            new_feats.append(new_feat)

        # ⑤ 피처 추가 및 저장
        if new_feats:
            target_layer.dataProvider().addFeatures(new_feats)
            target_layer.updateExtents()
            target_layer.commitChanges()

        return {}

    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "EV_survey"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield 전기차 실사건"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return EVsurveyAlgorithm()