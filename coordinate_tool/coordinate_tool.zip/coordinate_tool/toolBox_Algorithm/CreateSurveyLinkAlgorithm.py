from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

class CreateSurveyLinkAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        Daily_GpsLog = self.Qsettings.value('Daily_GpsLog', '')
        Surver_link = self.Qsettings.value('Surver_link', '')

        self.addParameter(QgsProcessingParameterVectorLayer('Gps_log', 'Gps_log', types=[QgsProcessing.TypeVectorPoint], defaultValue=Daily_GpsLog))
        self.addParameter(QgsProcessingParameterVectorLayer('Link_shp', 'Link_shp', types=[QgsProcessing.TypeVectorLine], defaultValue=Surver_link))
        self.addParameter(QgsProcessingParameterFeatureSink('Result', '조사', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Ng', '미조사', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # ——— 출력 레이어 이름 고정 ———
        parameters['Result'].destinationName = '조사'
        parameters['Ng'].destinationName  = '미조사'

        Daily_GpsLog = self.parameterAsVectorLayer(parameters, 'Gps_log', context)
        Surver_link = self.parameterAsVectorLayer(parameters, 'Link_shp', context)

        self.Qsettings.setValue('Daily_GpsLog', Daily_GpsLog)
        self.Qsettings.setValue('Surver_link', Surver_link)

        feedback = QgsProcessingMultiStepFeedback(20, model_feedback)
        results = {}
        outputs = {}

        # 1_�ڵ� ���� �ʵ� �߰�_gps
        alg_params = {
            'FIELD_NAME': 'g_key',
            'GROUP_FIELDS': [''],
            'INPUT': Daily_GpsLog,
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['1'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 2_���̾� ������
        alg_params = {
            'INPUT': outputs['1']['OUTPUT'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'OUTPUT': 'memory:'
        }
        outputs['2'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 3_ǥ�������� ����_���� �α� ����
        alg_params = {
            # 'EXPRESSION': '"flag" = 1\r\nand\r\n"number_of" >= 5\r\nand\r\n"h_acc" < 20\r\nand\r\n"v_acc" < 20',
            'EXPRESSION': '"flag" = 1\r\nand\r\n"h_acc" < 20\r\nand\r\n"v_acc" < 20',
            'INPUT': outputs['2']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['3'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}


        # 4_�ڵ� ���� �ʵ� �߰�
        alg_params = {
            'FIELD_NAME': 'l_key',
            'GROUP_FIELDS': [''],
            'INPUT': Surver_link,
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['4'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # 5_���̾� ������
        alg_params = {
            'INPUT': outputs['4']['OUTPUT'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'OUTPUT': 'memory:'
        }
        outputs['5'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # 6_Ư�� ������ ����
        alg_params = {
            'INPUT': outputs['5']['OUTPUT'],
            'VERTICES': '0',
            'OUTPUT': 'memory:'
        }
        outputs['6'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 7_Ư�� ������ ����
        alg_params = {
            'INPUT': outputs['5']['OUTPUT'],
            'VERTICES': '-1',
            'OUTPUT': 'memory:'
        }
        outputs['7'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}
        
        # 8_���� ���̾� ����
        alg_params = {
            'CRS': None,
            'LAYERS': [outputs['6']['OUTPUT'],outputs['7']['OUTPUT']],
            'OUTPUT': 'memory:'
        }
        outputs['8'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}
        
        # 9_����
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 0.01,
            'END_CAP_STYLE': 0,  # �ձ۰�
            'INPUT': outputs['8']['OUTPUT'],
            'JOIN_STYLE': 0,  # �ձ۰�
            'MITER_LIMIT': 2,
            'SEGMENTS': 5,
            'OUTPUT': 'memory:'
        }
        outputs['9'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # 10_�ֱ��� �Ÿ��� �̿��Ͽ� �Ӽ��� ����
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELDS_TO_COPY': ['l_key'],
            'INPUT': outputs['3']['OUTPUT'],
            'INPUT_2': outputs['5']['OUTPUT'],
            'MAX_DISTANCE': 25,
            'NEIGHBORS': 1,
            'PREFIX': '',
            'OUTPUT': 'memory:'
        }
        outputs['10'] = processing.run('native:joinbynearest', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # 11_�ڵ� ���� �ʵ� �߰�_join
        alg_params = {
            'FIELD_NAME': 'j_key',
            'GROUP_FIELDS': [''],
            'INPUT': outputs['10']['OUTPUT'],
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['11'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # 12_�ʵ� ����_llnk_angle
        alg_params = {
            'FIELD_LENGTH': 3,
            'FIELD_NAME': 'llnk_angle',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': 'with_variable( \'angle_value\',with_variable(\r\n\t\'angle_deg\',(90-to_int(degrees(atan2( "nearest_y"-"feature_y", "nearest_x"-"feature_x" )))) % 360,if(@angle_deg < 0, @angle_deg + 360 , @angle_deg)),if(@angle_value + 90>360, (@angle_value + 90)-360,(@angle_value + 90)))',
            'INPUT': outputs['11']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['12'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # 13_�ʵ� ����_����
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': '조사',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # �ؽ�Ʈ (string)
            'FORMULA': ' if(abs("angle" - "llnk_angle" ) <= 15 ,\r\n \'조사\',\r\n if(abs("angle" - to_int(("llnk_angle" + 180) % 360))<= 15,\r\n \'조사\',\r\n \'미조사\'))',
            'INPUT': outputs['12']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['13'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # 14_ǥ�������� ����
        alg_params = {
            'EXPRESSION': '"조사" = \'조사\'',
            'INPUT': outputs['13']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['14'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # 15_���̺����� ����Ʈ ����
        alg_params = {
            'INPUT': outputs['14']['OUTPUT'],
            'MFIELD': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'XFIELD': 'nearest_x',
            'YFIELD': 'nearest_y',
            'ZFIELD': '',
            'OUTPUT':'memory:'
        }
        outputs['15'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}


        # ���� �ε��� ����_15
        alg_params = {
            'INPUT': outputs['15']['OUTPUT']
        }
        outputs['_15'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # ���� �ε��� ����_9
        alg_params = {
            'INPUT': outputs['9']['OUTPUT']
        }
        outputs['_9'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # 16_��ġ�� ����
        alg_params = {
            'INPUT': outputs['_15']['OUTPUT'],
            'INTERSECT': outputs['_9']['OUTPUT'],
            'PREDICATE': [6],  # ����(are within)
            'OUTPUT':'memory:'
        }
        outputs['16'] = processing.run('native:extractbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # 17_�ʵ� ������ �Ӽ� ����
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'j_key',
            'FIELDS_TO_COPY': ['1'],
            'FIELD_2': 'j_key',
            'INPUT': outputs['14']['OUTPUT'],
            'INPUT_2': outputs['16']['OUTPUT'],
            'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
            'PREFIX': '',
            'NON_MATCHING': 'memory:'
        }
        outputs['17'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            return {}

        # 18_�ʵ� ������ �Ӽ� ����
        alg_params = {
            'DISCARD_NONMATCHING': True,
            'FIELD': 'l_key',
            'FIELDS_TO_COPY': ['조사'],
            'FIELD_2': 'l_key',
            'INPUT': outputs['4']['OUTPUT'],
            'INPUT_2': outputs['17']['NON_MATCHING'],
            'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
            'PREFIX': '',
            'NON_MATCHING': 'memory:',
            'OUTPUT': 'memory:'
        }
        outputs['18'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            return {}

        # 19_�ʵ� ����
        alg_params = {
            'COLUMN': ['l_key'],
            'INPUT': outputs['18']['NON_MATCHING'],
            'OUTPUT': parameters['Ng']
        }
        outputs['_ng'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Ng'] = outputs['_ng']['OUTPUT']

        feedback.setCurrentStep(19)
        if feedback.isCanceled():
            return {}

        # 20_�ʵ� ����
        alg_params = {
            'COLUMN': ['l_key'],
            'INPUT': outputs['18']['OUTPUT'],
            'OUTPUT': parameters['Result']
        }
        outputs['_result'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Result'] = outputs['_result']['OUTPUT']

        # 결과로 넘어온 레이어의 ID
        result_id = results['Result']
        ng_id     = results['Ng']

        # context에서 레이어 객체 꺼내오기
        result_layer = context.getMapLayer(result_id)
        ng_layer     = context.getMapLayer(ng_id)

        # 심벌 정의 (예: 빨간색, 선 두께 0.8)
        sym_result = QgsLineSymbol.createSimple({
            'color': '255,0,0',
            'width': '0.6'
        })
        sym_ng = QgsLineSymbol.createSimple({
            'color': '120,120,120',
            'width': '0.4'
            # 'line_style': 'dash'  # 대시선 스타일 예시 "solid", "dash", "dot", "dashdot", "dashdotdot", "custom" 
            # 'capstyle': 'round',  선 끝 모양. "flat", "square", "round"
            # 'joinstyle': 'bevel',  선이 만나는 모서리 모양. "miter", "bevel", "round"
            # 'offset': '1.0', 선을 원래 위치에서 평행 이동할 거리 (문자열, 기본 단위는 mm)
            # 'offset_unit': 'MM', offset 단위. "MM" 또는 "MapUnit"
            # 'use_custom_dash': '1', customdash 사용 여부. "1" or "0"
            # 'customdash': '4;2;1;2' penstyle이 "custom" 일 때 사용. 대시패턴을 세미콜론으로 구분된 숫자 문자열로 지정 (예: "4;2;1;2")
        })

        # 렌더러 교체
        result_layer.setRenderer(QgsSingleSymbolRenderer(sym_result))
        ng_layer.setRenderer    (QgsSingleSymbolRenderer(sym_ng))

        # 맵 캔버스 갱신
        result_layer.triggerRepaint()
        ng_layer.triggerRepaint()

        return results
    
    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "Daily_Surver_link"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield 조사링크 추출"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return CreateSurveyLinkAlgorithm()