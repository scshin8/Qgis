from pathlib import Path

from qgis.PyQt import uic, QtWidgets
from qgis.PyQt.QtWidgets import (
                                QMessageBox, QWidget, QTextEdit, QGridLayout,
                                QInputDialog)
from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.core import Qgis

import json

from .Coordinate_Tool_decryptKey import AESCipher
from .Coordinate_Tool_data import API_KEYS

# UI 로드
UI_PATH = Path(__file__).parent / 'ui' / 'Coordinate_Tool_Memo.ui'
FORM_CLASS, _ = uic.loadUiType(str(UI_PATH))

# 아이콘 디렉토리
ICON_DIR = Path(__file__).parent / 'icons'

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):
    """
    QGIS 플러그인 메모 탭 관리 다이얼로그
    """
    AUTO_SAVE_DELAY_MS = 500
    def __init__(self, ctool, iface, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.ctool = ctool

        # 설정 및 API 키
        self.settings = QSettings(
            QSettings.NativeFormat, QSettings.UserScope,
            "masco", "coordinateTool"
        )
        self.token_enc = API_KEYS.get('token', [''])[0]
        self.aes_cipher = AESCipher(self)

        # 메모 탭 로드 및 초기화
        self.tabs = self._load_tabs()
        self._ensure_default_tab()

        # UI 초기화
        self._setup_tab_widget()
        self._setup_buttons()
        self._setup_dialogs()

        # 탭 추가 및 내용 복원
        self._populate_tabs()

    def _load_tabs(self, *args):
        raw_json = self.settings.value('MemoTabs', '[]')
        try:
            return json.loads(raw_json)
        except json.JSONDecodeError:
            return []

    def _ensure_default_tab(self, *args):
        if not self.tabs:
            self.tabs = [{'id': '0', 'name': '메모', 'text': ''}]
            self._save_tabs()

    def _save_tabs(self, *args):
        self.settings.setValue(
            'MemoTabs', json.dumps(self.tabs, ensure_ascii=False)
        )

    def _setup_tab_widget(self, *args):
        self.tabWidget.tabBar().setMovable(True)
        self.tabWidget.tabBar().tabMoved.connect(self._on_tab_moved)

        self.auto_save_timer = QTimer(self)
        self.auto_save_timer.setSingleShot(True)
        self.auto_save_timer.timeout.connect(self._save_current_text)

    def _setup_buttons(self, *args):
        buttons = {
            self.toolButton:    ("memo_add.png",    self._add_tab),
            self.toolButton_2:  ("memo_remove.png", self._remove_tab),
            self.toolButton_3:  ("memo_edit.png",   self._rename_tab),
        }
        for btn, (icon_file, handler) in buttons.items():
            btn.setIcon(QIcon(str(ICON_DIR / icon_file)))
            btn.clicked.connect(handler)

    def _setup_dialogs(self, *args):
        def _create_input_dialog(title, label, width=300, height=150):
            dlg = QInputDialog(self)
            dlg.setWindowTitle(title)
            dlg.setLabelText(label)
            dlg.resize(width, height)
            return dlg

        self.ad_input_dialog = _create_input_dialog(
            "AD계정 입력",
            "AD계정 변수가 설정되어 있지 않습니다.\n직접 입력해주세요. (사번)"
        )
        self.rename_input_dialog = _create_input_dialog(
            "메모탭 수정", "메모탭 이름을 입력하세요"
        )

    def _on_tab_moved(self, old_index, new_index, *args):
        entry = self.tabs.pop(old_index)
        self.tabs.insert(new_index, entry)
        self._save_tabs()

    def _populate_tabs(self, *args):
        for entry in self.tabs:
            tab_id = entry['id']
            name = entry['name']
            text = entry.get('text', '')

            container = QWidget()
            container.setObjectName(f"tab_{tab_id}")

            text_edit = QTextEdit()
            text_edit.setObjectName(f"textEdit_{tab_id}")
            text_edit.setPlainText(text)
            text_edit.textChanged.connect(self._on_text_changed)

            layout = QGridLayout(container)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.addWidget(text_edit)

            self.tabWidget.addTab(container, name)

    def _on_text_changed(self, *args):
        self.auto_save_timer.start(self.AUTO_SAVE_DELAY_MS)

    def _save_current_text(self, *args):
        current_id = self._get_current_tab_id()
        text_edit = self.findChild(QTextEdit, f"textEdit_{current_id}")
        if not text_edit:
            return
        content = text_edit.toPlainText()
        for entry in self.tabs:
            if entry['id'] == current_id:
                entry['text'] = content
                break
        self._save_tabs()

    def _get_current_tab_id(self, *args):
        widget = self.tabWidget.currentWidget()
        return widget.objectName().split('_', 1)[1]

    def _show_message(self, msg, level=Qgis.Info, duration=5, *args):
        self.iface.messageBar().clearWidgets()
        self.iface.messageBar().pushMessage(msg, level=level, duration=duration)

    # === 탭 관리 메서드 ===
    def _add_tab(self, *args):
        used_ids = {int(e['id']) for e in self.tabs}
        new_id = str(next(i for i in range(100) if i not in used_ids))
        self.tabs.append({'id': new_id, 'name': '메모', 'text': ''})
        self._save_tabs()
        self._populate_single_tab(new_id)

    def _populate_single_tab(self, tab_id, *args):
        # 단일 탭 추가 로직
        container = QWidget()
        container.setObjectName(f"tab_{tab_id}")

        text_edit = QTextEdit()
        text_edit.setObjectName(f"textEdit_{tab_id}")
        text_edit.textChanged.connect(self._on_text_changed)

        layout = QGridLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addWidget(text_edit)

        index = self.tabWidget.addTab(container, '메모')
        self.tabWidget.setCurrentIndex(index)

    def _remove_tab(self, *args):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        tab_id = self._get_current_tab_id()
        name = self.tabWidget.tabText(index)
        answer = QMessageBox.question(
            self, '메모탭 삭제', f"'{name}' 탭을 삭제하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer == QMessageBox.Yes:
            self.tabs = [e for e in self.tabs if e['id'] != tab_id]
            self._save_tabs()
            self.tabWidget.removeTab(index)

    def _rename_tab(self, *args):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        old_name = self.tabWidget.tabText(index)

        text_edit = self.tabWidget.currentWidget().findChild(QTextEdit)
        if not text_edit:
            return
        text = text_edit.toPlainText()

        self.rename_input_dialog.setTextValue(old_name)
        if self.rename_input_dialog.exec_() != QInputDialog.Accepted:
            return
        new_name = self.rename_input_dialog.textValue().strip()
        if not new_name:
            return
        self.tabWidget.setTabText(index, new_name)
        current_id = self._get_current_tab_id()
        for entry in self.tabs:
            if entry['id'] == current_id:
                entry['name'] = new_name
                entry['text'] = text
                break
        self._save_tabs()