from qgis.PyQt import uic, QtWidgets

from qgis.core import Qgis, QgsCoordinateReferenceSystem, QgsExpressionContextUtils

from PyQt5.QtCore import QSettings, Qt, QTimer

from qgis.PyQt.QtWidgets import (QMessageBox, 
                                 QWidget, 
                                 QTextEdit, 
                                 QGridLayout)

from PyQt5.QtWidgets import QDialogButtonBox, QTabWidget, QInputDialog

from PyQt5.QtGui import QIcon
from .Coordinate_Tool_decryptKey import AESCipher
# from cryptography.fernet import Fernet

import os.path, datetime

import requests
import base64
import winreg

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

token = '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'
repo = 'scshin8/Qgis'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Memo.ui'))

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolMemo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        self.chk = False
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.tabList = self.QSettings.value('MemotabList',[])
        if self.tabList == None:
            self.tabList = []

        self.tabNames = self.QSettings.value('MemotabNames',[])
        if self.tabNames == None:
            self.tabNames = []

        self.tabWidget.currentChanged.connect(self.tabCha)

        self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/memo_add.png"))
        self.toolButton.clicked.connect(self.addtab)

        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/memo_remove.png"))
        self.toolButton_2.clicked.connect(self.remove_tab)

        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/memo_edit.png"))
        self.toolButton_3.clicked.connect(self.tabNameEdit)       

        self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/save.png"))
        self.toolButton_4.clicked.connect(self.githubSave)

        self.toolButton_5.setIcon(QIcon(os.path.dirname(__file__) + "/icons/import.png"))
        self.toolButton_5.clicked.connect(self.githubLoad)

        self.setMemoTab()

        self.AESCipher = AESCipher(self)

        # 메모 백업 암호화
        # key_file = os.path.join(os.path.dirname(__file__), 'secret.key')
        
        # if not os.path.exists(key_file):
        #     key = Fernet.generate_key()              # 32바이트 url-safe base64 키 생성
        #     with open(key_file, 'wb') as f:
        #         f.write(key)   

        # with open(key_file , 'rb') as f:
        #     key = f.read()
        #     self.fernet = Fernet(key)


        # QInputDialog 객체 직접 생성
        self.dialog = QInputDialog()
        self.dialog.setWindowTitle("AD계정")
        self.dialog.setLabelText("AD계정 변수가 설정되어 있지 않습니다.\n직접 입력해주세요. (9사번 입력)")
        self.dialog.resize(300, 150)  # 다이얼로그 창 사이즈 조절 (너비, 높이)

        # QInputDialog 객체 직접 생성
        self.reName = QInputDialog()
        self.reName.setWindowTitle("메모텝 수정")
        self.reName.setLabelText("메모탭 이름 수정")
        self.reName.resize(300, 150)  # 다이얼로그 창 사이즈 조절 (너비, 높이)

        self.chk = True
        self.QSettings.setValue('MemocurrentIndex', 0)
        self.tabWidget.setCurrentIndex(0)
        self.tabidx = 0
        tabName = str(self.tabWidget.currentWidget().objectName())
        self.changeidx = tabName.replace('tab_', '')

        # 시스템 변수 목록을 가져오기
        system_variables = QgsExpressionContextUtils.globalScope().variableNames()

        self.path = None

        try:
            # 시스템 변수와 그 값 출력하기
            for var in system_variables:
                if var == 'id':
                    id = QgsExpressionContextUtils.globalScope().variable(var)
                    self.path = f'{id}.txt'
                    break
        except:
            self.path = None

    def getId(self):
        # 시스템 변수 목록을 가져오기
        system_variables = QgsExpressionContextUtils.globalScope().variableNames()
        # 시스템 변수와 그 값 출력하기
        for var in system_variables:
            if var == 'AD계정':
                self.id = QgsExpressionContextUtils.globalScope().variable(var)
                self.path = f'{self.id}.txt'
                break

        if self.path is None:
            # 입력을 기다림
            if self.dialog.exec_() == QInputDialog.Accepted:
                self.id = self.dialog.textValue()
                if self.id:
                    QgsExpressionContextUtils.setGlobalVariable('AD계정', self.id)
                    self.path = f'{self.id}.txt'
                    self.iface.messageBar().clearWidgets()
                    self.iface.messageBar().pushMessage(f'변수 설정 [AD계정 : {self.id}]', level=Qgis.Info, duration=5)
                else:
                    self.path = None
                    self.iface.messageBar().clearWidgets()
                    # self.iface.messageBar().pushMessage('사번 입력이 필요합니다.', level=Qgis.Warning, duration=10)

    def githubLoad(self):
        if self.path is None:
            self.getId()
            if self.path is None:
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'AD계정 변수가 없습니다.', level=Qgis.Warning, duration=5)
                return

        # 1. 현재 탭과 대응하는 QTextEdit 찾기
        current_tab = self.tabWidget.currentWidget()
        if current_tab is None:
            return
        changetabName = str(current_tab.objectName())
        changeidx = changetabName.replace('tab_', '')
        text_edit = self.findChild(QTextEdit, f'textEdit_{changeidx}')
        if text_edit is None:
            return

        # 2. GitHub API 호출 준비
        url = f'https://api.github.com/repos/{repo}/contents/Memo/{self.path}'
        headers = {
            'Authorization': f'token {token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # 3. 파일 정보 조회
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            print(f'Failed to fetch file: {response.status_code}, {response.text}')
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushMessage(f'가져오기 실패했습니다.', level=Qgis.Question, duration=5)
            return

        # 4. base64 로 인코딩된 content 디코딩
        data = response.json()
        b64content = data.get('content', '')
        text = base64.b64decode(b64content).decode('utf-8')
        
        # 내용 복호화
        dectext = self.AESCipher.decrypt(text) 

        # GitHub에서 받아온 base64 → 암호문 → 복호화
        # token_bytes = base64.b64decode(data['content'])
        if dectext is not None:
            try:
                # decrypted = self.fernet.decrypt(token_bytes)
                # text = decrypted.decode('utf-8')

                # 5. QTextEdit 에 내용 반영
                text_edit.setPlainText(dectext)

                # 6. 다음 업데이트를 위해 최신 sha 저장(선택)
                self.latest_sha = data.get('sha', '')
                print('File loaded into widget!')
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'메모가 로드 되었습니다.', level=Qgis.Info, duration=5)
                self.text_changeRun()
            except:
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'메모 가져오기 실패!', level=Qgis.Warning, duration=5)
                print('복호화 키 오류 또는 AD사번 오류')
        else:
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushMessage(f'메모 가져오기 실패! 인증키 오류', level=Qgis.Warning, duration=5)

    def githubSave(self):
        if self.path is None:
            self.getId()
            if self.path is None:
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'AD계정 변수가 없습니다.', level=Qgis.Warning, duration=5)
                return

        # 현재 탭과 텍스트를 찾아 저장
        current_tab = self.tabWidget.currentWidget()
        if current_tab is None:
            return
        changetabName = str(current_tab.objectName())
        changeidx = changetabName.replace('tab_', '') 
        text_edit = self.findChild(QTextEdit, f'textEdit_{changeidx}')
        if text_edit is None:
            return
        text = text_edit.toPlainText()
        # 내용 암호화
        encrypt = self.AESCipher.encrypt(text)

        if encrypt is not None:
            url = f'https://api.github.com/repos/{repo}/contents/Memo/{self.path}'
            headers = {
                'Authorization': f'token {token}',
                'Accept': 'application/vnd.github.v3+json'
            }

            # # 저장할 텍스트 암호화
            # plain = text.encode('utf-8')
            # token_bytes = self.fernet.encrypt(plain)  # 암호문 bytes
            # content = base64.b64encode(token_bytes).decode('utf-8')

            content = base64.b64encode(encrypt.encode('utf-8')).decode('utf-8')
            data = {
                'message': 'Updating file via QGIS plugin',
                'content': content,
                'sha': self.get_file_sha(url, headers)
            }

            response = requests.put(url, headers=headers, json=data)
            if response.status_code == 200:
                print('업데이트 되었습니다.!')
                # QMessageBox 정보(Infromation) 아이콘의 팝업창
                QMessageBox.information(
                    self.iface.mainWindow(),
                    '메모 저장 완료',
                    f"{text}\n\n{'-' * 60}\n메모가 성공적으로 업데이트되었습니다."
                )
            else:
                print(f'Failed to update file: {response.status_code}, {response.text}')
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'업데이트 실패했습니다.', level=Qgis.Question, duration=5)
        else:
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushMessage(f'메모 가져오기 실패! 인증키 오류', level=Qgis.Warning, duration=5)

    def get_file_sha(self, url, headers):
        import requests
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json()['sha']
        else:
            print('error')
            return ''

    def tabCha(self):
        if not self.chk:
            return

        tabidx = self.tabWidget.currentIndex()
        if tabidx < 0:
            return

        changetabName = str(self.tabWidget.currentWidget().objectName())
        changeidx = changetabName.replace('tab_', '')

        if tabidx != self.tabidx and  changeidx == self.changeidx:

            # 두 리스트의 순서를 동시에 변경
            for lst in [self.tabList, self.tabNames]:
                lst[self.tabidx], lst[tabidx] = lst[tabidx], lst[self.tabidx]

            # 변경된 리스트 저장
            self.QSettings.setValue('MemotabList', self.tabList)
            self.QSettings.setValue('MemoTabNames', self.tabNames)

        self.QSettings.setValue('MemocurrentIndex', tabidx)
        self.tabidx = tabidx
        self.changeidx = changeidx

    def text_change(self):
        # 타이머 초기화 및 설정
        if not hasattr(self, 'text_change_timer'):
            self.text_change_timer = QTimer()
            self.text_change_timer.setSingleShot(True)  # 단일 실행으로 설정
            self.text_change_timer.timeout.connect(self.text_changeRun)

        # 텍스트 변경 시마다 타이머 재시작
        self.text_change_timer.start(3000)  # 5초(5000ms)

    def text_changeRun(self):
        # 현재 탭과 텍스트를 찾아 저장
        current_tab = self.tabWidget.currentWidget()
        if current_tab is None:
            return

        changetabName = str(current_tab.objectName())
        changeidx = changetabName.replace('tab_', '')

        text_edit = self.findChild(QTextEdit, f'textEdit_{changeidx}')
        if text_edit is None:
            return

        text = text_edit.toPlainText()
        self.QSettings.setValue(f'Memo{changeidx}', text)

    # 깃허브 메모장 수정 코드 속도가 너무 느려 폐기함
    #     import requests
    #     import base64
    #     token = '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'
    #     repo = 'scshin8/Qgis'
    #     path = 'Memo.txt'
    #     url = f'https://api.github.com/repos/{repo}/contents/{path}'
    #     headers = {
    #         'Authorization': f'token {token}',
    #         'Accept': 'application/vnd.github.v3+json'
    #     }

    #     content = base64.b64encode(text.encode('utf-8')).decode('utf-8')
    #     data = {
    #         'message': 'Updating file via QGIS plugin',
    #         'content': content,
    #         'sha': self.get_file_sha(url, headers)
    #     }

    #     response = requests.put(url, headers=headers, json=data)
    #     if response.status_code == 200:
    #         print('File updated successfully!')
    #     else:
    #         print(f'Failed to update file: {response.status_code}, {response.text}')

    # def get_file_sha(self, url, headers):
    #     import requests
    #     response = requests.get(url, headers=headers)
    #     if response.status_code == 200:
    #         return response.json()['sha']
    #     else:
    #         print('error')
    #         return ''

    def tabNameEdit(self):
        tabname = self.tabWidget.tabText(self.tabidx)
        self.reName.setTextValue(tabname)
        if self.reName.exec_() == QInputDialog.Accepted:
            newname = self.reName.textValue()

            edittabName = str(self.tabWidget.currentWidget().objectName())
            editidx = edittabName.replace('tab_', '')
            self.tabWidget.setTabText(self.tabidx, newname)

            self.tabList = self.QSettings.value('MemotabList',[])
            self.tabNames = self.QSettings.value('MemotabNames',[])
            for idx, i in enumerate(self.tabList):
                if i == editidx:
                    self.tabNames[idx] = newname
                    break
            print(self.tabNames)
            self.QSettings.setValue('MemotabNames',self.tabNames)

    def setMemoTab(self):
        tabListCount = len(self.tabList)
        if tabListCount > 0:
            for i,n   in zip(self.tabList, self.tabNames):
                # 새로운 탭을 만듭니다.
                new_tab = QWidget()
                new_tab.setObjectName('tab_'+str(i))
                # 탭에 추가할 내용을 만듭니다.
                content = QTextEdit()
                content.setObjectName('textEdit_'+str(i))

                # 탭의 레이아웃을 설정합니다.
                tab_layout = QGridLayout()
                tab_layout.setContentsMargins(6, 6, 6, 6)
                tab_layout.addWidget(content)
                new_tab.setLayout(tab_layout)

                # 탭을 QTabWidget에 추가합니다.
                self.tabWidget.addTab(new_tab,n)
                self.findChild(QTextEdit,'textEdit_'+ str(i)).setPlainText(str(self.QSettings.value('Memo'+str(i), '')))
                self.findChild(QTextEdit,'textEdit_'+ str(i)).textChanged.connect(self.text_change)
        else:
            # 새로운 탭을 만듭니다.
            new_tab = QWidget()
            new_tab.setObjectName('tab_0')
            # 탭에 추가할 내용을 만듭니다.
            content = QTextEdit()
            content.setObjectName('textEdit_0')

            # 탭의 레이아웃을 설정합니다.
            tab_layout = QGridLayout()
            tab_layout.setContentsMargins(6, 6, 6, 6)
            tab_layout.addWidget(content)
            new_tab.setLayout(tab_layout)

            new_tab_name = '메모'

            # 탭을 QTabWidget에 추가합니다.
            self.tabWidget.addTab(new_tab,new_tab_name)
            self.findChild(QTextEdit,'textEdit_0').textChanged.connect(self.text_change)

            self.tabidx = 0
            self.QSettings.setValue('MemocurrentIndex', self.tabidx)
            # self.QSettings.setValue('Memo_tabcount',1)
            self.tabList = ['0']
            self.QSettings.setValue('MemotabList',self.tabList)
            self.tabNames = [new_tab_name]
            self.QSettings.setValue('MemotabNames',self.tabNames)

    def remove_tab(self):
        if self.tabWidget.count() > 0:
            self.tabList = self.QSettings.value('MemotabList',[])
            self.tabNames = self.QSettings.value('MemotabNames',[])

            tabname = self.tabWidget.tabText(self.tabidx)
            deltabName = str(self.tabWidget.currentWidget().objectName())
            delidx = deltabName.replace('tab_', '')
            reply = QMessageBox.question(None,
                                    self.tr('메모탭 삭제'),
                                    self.tr(str(tabname) +  " 를 삭제 합니다.  \n계속 하시겠습니까?  \n"),
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                self.findChild(QTextEdit,'textEdit_'+ str(delidx)).deleteLater()
                self.tabWidget.removeTab(self.tabidx)

                # 탭 리스트 삭제
                try:
                    self.tabList.remove(int(delidx))
                except:
                    self.tabList.remove(str(delidx))
                    
                self.QSettings.setValue('MemotabList',self.tabList)

                # 네임 리스트 삭제
                print(self.tabNames)
                self.tabNames.remove(str(tabname))
                print(self.tabNames)
                self.QSettings.setValue('MemotabNames',self.tabNames)
                # 저장값 삭제
                self.QSettings.remove('Memo'+str(delidx))

    def addtab(self):
        self.tabList = self.QSettings.value('MemotabList',[])
        print(self.tabList)
        for i in range(100):
            if str(i) not in self.tabList:
                self.addidx = str(i)
                break
        print(self.addidx)
        # 새 메모탭 이름
        tabName = "메모_"
        tabName += datetime.datetime.now().strftime("%Y%m%d_%H%M%S")[2:]
        

        # 현재 메모탭 카운터
        tabcount = self.tabWidget.count()
        # 탭 리스트
        self.tabList = self.QSettings.value('MemotabList',[])
        # 탭 리스트 추가
        self.tabList.append(self.addidx)
        print(self.tabList)
        # 탭 네임
        self.tabNames = self.QSettings.value('MemotabNames',[])
        # 탭 네임 추가
        self.tabNames.append(tabName)

        # 새로운 탭을 만듭니다.
        new_tab = QWidget()
        new_tab.setObjectName('tab_' + self.addidx)
        # 탭에 추가할 내용을 만듭니다.s
        content = QTextEdit()
        content.setObjectName('textEdit_'+ self.addidx)

        # 탭의 레이아웃을 설정합니다.
        tab_layout = QGridLayout()
        tab_layout.setContentsMargins(6, 6, 6, 6)
        tab_layout.addWidget(content)
        new_tab.setLayout(tab_layout)

        # 탭을 QTabWidget에 추가합니다.
        self.tabWidget.addTab(new_tab,tabName)
        self.tabWidget.setCurrentIndex(tabcount)
        self.findChild(QTextEdit,'textEdit_'+ str(self.addidx)).textChanged.connect(self.text_change)

        self.QSettings.setValue('MemotabList', self.tabList)
        self.QSettings.setValue('MemotabNames', self.tabNames)