from pathlib import Path

from qgis.PyQt import uic, QtWidgets
from qgis.PyQt.QtWidgets import (
    QMessageBox, QWidget, QTextEdit, QGridLayout,
    QInputDialog)
from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.core import Qgis

import json

from .Coordinate_Tool_decryptKey import AESCipher
from .Coordinate_Tool_data import API_KEYS

# UI 로드
UI_PATH = Path(__file__).parent / 'ui' / 'Coordinate_Tool_Memo.ui'
FORM_CLASS, _ = uic.loadUiType(str(UI_PATH))

# 아이콘 디렉토리
ICON_DIR = Path(__file__).parent / 'icons'

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):
    """
    QGIS 플러그인 메모 탭 관리 다이얼로그
    """
    AUTO_SAVE_DELAY_MS = 500
    def __init__(self, ctool, iface, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.ctool = ctool

        # 설정 및 API 키
        self.settings = QSettings(
            QSettings.NativeFormat, QSettings.UserScope,
            "masco", "coordinateTool"
        )
        self.token_enc = API_KEYS.get('token', [''])[0]
        self.aes_cipher = AESCipher(self)

        # 메모 탭 로드 및 초기화
        self.tabs = self._load_tabs()
        self._ensure_default_tab()

        # UI 초기화
        self._setup_tab_widget()
        self._setup_buttons()
        self._setup_dialogs()

        # AD 계정 확인
        # self.user_path = None
        # self._init_ad_account()

        # 탭 추가 및 내용 복원
        self._populate_tabs()

    def _load_tabs(self):
        raw_json = self.settings.value('MemoTabs', '[]')
        try:
            return json.loads(raw_json)
        except json.JSONDecodeError:
            return []

    def _ensure_default_tab(self):
        if not self.tabs:
            self.tabs = [{'id': '0', 'name': '메모', 'text': ''}]
            self._save_tabs()

    def _save_tabs(self):
        self.settings.setValue(
            'MemoTabs', json.dumps(self.tabs, ensure_ascii=False)
        )

    def _setup_tab_widget(self):
        self.tabWidget.tabBar().setMovable(True)
        self.tabWidget.tabBar().tabMoved.connect(self._on_tab_moved)

        self.auto_save_timer = QTimer(self)
        self.auto_save_timer.setSingleShot(True)
        self.auto_save_timer.timeout.connect(self._save_current_text)

    def _setup_buttons(self):
        buttons = {
            self.toolButton:    ("memo_add.png",    self._add_tab),
            self.toolButton_2:  ("memo_remove.png", self._remove_tab),
            self.toolButton_3:  ("memo_edit.png",   self._rename_tab),
            # self.toolButton_4:  ("save1.png",        self._github_save),
            # self.toolButton_5:  ("folder.png",      self._github_load),
        }
        for btn, (icon_file, handler) in buttons.items():
            btn.setIcon(QIcon(str(ICON_DIR / icon_file)))
            btn.clicked.connect(handler)

    def _setup_dialogs(self):
        def _create_input_dialog(title, label, width=300, height=150):
            dlg = QInputDialog(self)
            dlg.setWindowTitle(title)
            dlg.setLabelText(label)
            dlg.resize(width, height)
            return dlg

        self.ad_input_dialog = _create_input_dialog(
            "AD계정 입력",
            "AD계정 변수가 설정되어 있지 않습니다.\n직접 입력해주세요. (사번)"
        )
        self.rename_input_dialog = _create_input_dialog(
            "메모탭 수정", "메모탭 이름을 입력하세요"
        )

    def _on_tab_moved(self, old_index, new_index):
        entry = self.tabs.pop(old_index)
        self.tabs.insert(new_index, entry)
        self._save_tabs()

    def _populate_tabs(self):
        for entry in self.tabs:
            tab_id = entry['id']
            name = entry['name']
            text = entry.get('text', '')

            container = QWidget()
            container.setObjectName(f"tab_{tab_id}")

            text_edit = QTextEdit()
            text_edit.setObjectName(f"textEdit_{tab_id}")
            text_edit.setPlainText(text)
            text_edit.textChanged.connect(self._on_text_changed)

            layout = QGridLayout(container)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.addWidget(text_edit)

            self.tabWidget.addTab(container, name)

    def _on_text_changed(self):
        self.auto_save_timer.start(self.AUTO_SAVE_DELAY_MS)

    def _save_current_text(self):
        current_id = self._get_current_tab_id()
        text_edit = self.findChild(QTextEdit, f"textEdit_{current_id}")
        if not text_edit:
            return
        content = text_edit.toPlainText()
        for entry in self.tabs:
            if entry['id'] == current_id:
                entry['text'] = content
                break
        self._save_tabs()

    def _get_current_tab_id(self):
        widget = self.tabWidget.currentWidget()
        return widget.objectName().split('_', 1)[1]

    def _show_message(self, msg, level=Qgis.Info, duration=5):
        self.iface.messageBar().clearWidgets()
        self.iface.messageBar().pushMessage(msg, level=level, duration=duration)

    # === 탭 관리 메서드 ===
    def _add_tab(self):
        used_ids = {int(e['id']) for e in self.tabs}
        new_id = str(next(i for i in range(100) if i not in used_ids))
        self.tabs.append({'id': new_id, 'name': '메모', 'text': ''})
        self._save_tabs()
        self._populate_single_tab(new_id)

    def _populate_single_tab(self, tab_id):
        # 단일 탭 추가 로직
        container = QWidget()
        container.setObjectName(f"tab_{tab_id}")

        text_edit = QTextEdit()
        text_edit.setObjectName(f"textEdit_{tab_id}")
        text_edit.textChanged.connect(self._on_text_changed)

        layout = QGridLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addWidget(text_edit)

        index = self.tabWidget.addTab(container, '메모')
        self.tabWidget.setCurrentIndex(index)

    def _remove_tab(self):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        tab_id = self._get_current_tab_id()
        name = self.tabWidget.tabText(index)
        answer = QMessageBox.question(
            self, '메모탭 삭제', f"'{name}' 탭을 삭제하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer == QMessageBox.Yes:
            self.tabs = [e for e in self.tabs if e['id'] != tab_id]
            self._save_tabs()
            self.tabWidget.removeTab(index)

    def _rename_tab(self):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        old_name = self.tabWidget.tabText(index)

        text_edit = self.tabWidget.currentWidget().findChild(QTextEdit)
        if not text_edit:
            return
        text = text_edit.toPlainText()

        self.rename_input_dialog.setTextValue(old_name)
        if self.rename_input_dialog.exec_() != QInputDialog.Accepted:
            return
        new_name = self.rename_input_dialog.textValue().strip()
        if not new_name:
            return
        self.tabWidget.setTabText(index, new_name)
        current_id = self._get_current_tab_id()
        for entry in self.tabs:
            if entry['id'] == current_id:
                entry['name'] = new_name
                entry['text'] = text
                break
        self._save_tabs()

    # # === AD 계정 및 GitHub 연동 ===
    # def _init_ad_account(self):
    #     var_names = QgsExpressionContextUtils.globalScope().variableNames()
    #     if 'AD계정' in var_names:
    #         uid = QgsExpressionContextUtils.globalScope().variable('AD계정')
    #         # if str(uid).isdigit() and int(uid) in self.ad_list:
    #             self.toolButton_4.setEnabled(True)
    #             self.toolButton_5.setEnabled(True)
    #         self.user_path = f"{uid}.txt"

    # def _ensure_ad_account(self):
    #     if not self.user_path:
    #         stored = QgsExpressionContextUtils.globalScope().variable('AD계정')
    #         if stored:
    #             self.user_path = f"{stored}.txt"
    #         else:
    #             if self.ad_input_dialog.exec_() == QInputDialog.Accepted:
    #                 val = self.ad_input_dialog.textValue()
    #                 QgsExpressionContextUtils.setGlobalVariable('AD계정', val)
    #                 self.user_path = f"{val}.txt"
    #                 self._show_message(f"AD계정 설정: {val}")

    # def _github_load(self):
    #     self._ensure_ad_account()
    #     if not self.user_path:
    #         return self._show_message('AD계정 변수가 없습니다.', level=Qgis.Warning)

    #     url = (
    #         f"https://api.github.com/repos/scshin8/Qgis/contents/Memo/"
    #         f"{self.user_path}"
    #     )
    #     token = self.aes_cipher.decrypt(self.token_enc)
    #     headers = {
    #         'Authorization': f'token {token}',
    #         'Accept': 'application/vnd.github.v3+json'
    #     }
    #     resp = requests.get(url, headers=headers)
    #     if not resp.ok:
    #         return self._show_message('메모 불러오기 실패', level=Qgis.Warning)

    #     data = resp.json()
    #     try:
    #         decoded = base64.b64decode(data['content']).decode('utf-8')
    #         text = self.aes_cipher.decrypt(decoded)
    #     except Exception:
    #         return self._show_message('복호화 오류', level=Qgis.Warning)

    #     text_edit = self.tabWidget.currentWidget().findChild(QTextEdit)
    #     if text_edit:
    #         text_edit.setPlainText(text)
    #         self.latest_sha = data.get('sha')
    #         self._show_message('메모가 로드되었습니다.', level=Qgis.Success)
    #         self._save_current_text()

    # def _github_save(self):
    #     self._ensure_ad_account()
    #     if not self.user_path:
    #         return self._show_message('AD계정 변수가 없습니다.', level=Qgis.Warning)

    #     text_edit = self.tabWidget.currentWidget().findChild(QTextEdit)
    #     if not text_edit:
    #         return
    #     plain_text = text_edit.toPlainText()

    #     encrypted = self.aes_cipher.encrypt(plain_text)
    #     if not encrypted:
    #         return self._show_message('암호화 실패', level=Qgis.Warning)

    #     b64_content = base64.b64encode(
    #         encrypted.encode('utf-8')
    #     ).decode()

    #     url = (
    #         f"https://api.github.com/repos/scshin8/Qgis/contents/Memo/"
    #         f"{self.user_path}"
    #     )
    #     token = self.aes_cipher.decrypt(self.token_enc)
    #     headers = {
    #         'Authorization': f'token {token}',
    #         'Accept': 'application/vnd.github.v3+json'
    #     }
    #     sha = self._get_file_sha(url, headers)

    #     payload = {
    #         'message': 'Updating via QGIS plugin',
    #         'content': b64_content,
    #         'sha': sha or None
    #     }
    #     resp = requests.put(url, headers=headers, json=payload)
    #     if resp.ok:
    #         QMessageBox.information(
    #             self.iface.mainWindow(),
    #             '메모 저장 완료', '메모가 업데이트되었습니다.'
    #         )
    #     else:
    #         self._show_message('메모 저장 실패', level=Qgis.Warning)

    # def _get_file_sha(self, url, headers):
    #     resp = requests.get(url, headers=headers)
    #     return resp.json().get('sha') if resp.ok else None