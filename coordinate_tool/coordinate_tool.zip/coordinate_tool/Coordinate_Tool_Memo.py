from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject, 
                       QgsMarkerSymbol, 
                       QgsTextAnnotation)

from PyQt5.QtCore import (QSizeF,
                          QPointF,
                          QSettings)

from qgis.gui import (QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from PyQt5.QtGui import (QKeySequence,
                         QTextDocument,
                         QColor,
                         QIcon)

from qgis.PyQt.QtWidgets import QMessageBox, QTabWidget, QWidget, QPushButton, QVBoxLayout, QTextEdit, QGridLayout

from PyQt5.QtWidgets import (QPushButton,
                             QTableWidgetItem,
                             QDialogButtonBox)

import os.path

from .Coordinate_Tool_Memo_add import CoordinateToolMemoadd

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Memo.ui'))

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolMemo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        self.chk = False
        self.QSettings=QSettings()
        self.memoadd = CoordinateToolMemoadd()
        self.memoadd.buttonBox.button(QDialogButtonBox.Save).clicked.connect(self.addmemosave)

        self.tabWidget.currentChanged.connect(self.tabCha)

        # self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/add.png"))
        self.pushButton.clicked.connect(self.addtab)

        # self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/remove.png"))
        self.pushButton_2.clicked.connect(self.remove_tab)

        self.setMemoTab()

        self.chk = True
        index = int(self.QSettings.value('coordinate_tool/MemocurrentIndex', 0))
        self.tabWidget.setCurrentIndex(index)

    def tabCha(self):
        if self.chk:
            tabidx = self.tabWidget.currentIndex()
            self.QSettings.setValue('coordinate_tool/MemocurrentIndex', tabidx)

    def text_change(self):
        tabidx = self.tabWidget.currentIndex()
        text = str(self.findChild(QTextEdit,'textEdit_'+ str(tabidx)).toPlainText())
        print(tabidx, text)
        self.QSettings.setValue('coordinate_tool/Memo'+str(tabidx), text)

    def setMemoTab(self):
        count = int(self.QSettings.value('coordinate_tool/Memo_tabcount',0))
        if count > 0:
            for i in range(0, count):
                # 새로운 탭을 만듭니다.
                new_tab = QWidget()
                # 탭에 추가할 내용을 만듭니다.
                content = QTextEdit()
                content.setObjectName('textEdit_'+str(i))

                # 탭의 레이아웃을 설정합니다.
                tab_layout = QGridLayout()
                tab_layout.setContentsMargins(6, 6, 6, 6)
                tab_layout.addWidget(content)
                new_tab.setLayout(tab_layout)

                # 탭을 QTabWidget에 추가합니다.
                tabName = self.QSettings.value('coordinate_tool/MemotabName'+str(i),"메모"+str(i+1))
                self.tabWidget.addTab(new_tab,tabName)
                self.findChild(QTextEdit,'textEdit_'+ str(i)).setPlainText(str(self.QSettings.value('coordinate_tool/Memo'+str(i), '')))
                self.findChild(QTextEdit,'textEdit_'+ str(i)).textChanged.connect(self.text_change)
        else:
            # 새로운 탭을 만듭니다.
            new_tab = QWidget()
            # 탭에 추가할 내용을 만듭니다.
            content = QTextEdit()
            content.setObjectName('textEdit_0')

            # 탭의 레이아웃을 설정합니다.
            tab_layout = QGridLayout()
            tab_layout.setContentsMargins(6, 6, 6, 6)
            tab_layout.addWidget(content)
            new_tab.setLayout(tab_layout)

            # 탭을 QTabWidget에 추가합니다.
            tabName = ('메모1')
            self.tabWidget.addTab(new_tab,tabName)
            self.findChild(QTextEdit,'textEdit_0').textChanged.connect(self.text_change)

            self.QSettings.setValue('coordinate_tool/MemotabName0',tabName)
            self.QSettings.setValue('coordinate_tool/MemocurrentIndex', 0)
            self.QSettings.setValue('coordinate_tool/Memo_tabcount',1)

    def remove_tab(self):
        if self.tabWidget.count() > 1:

            tabidx = self.tabWidget.currentIndex()
            text = self.tabWidget.tabText(tabidx)
            reply = QMessageBox.question(None,
                                    self.tr('메모 삭제'),
                                    self.tr(str(text) +  " 를 삭제 합니다.  \n계속 하시겠습니까?  \n"),
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                count = self.tabWidget.count()

                for i in range(0, count):
                    if i >= tabidx:
                        self.findChild(QTextEdit,'textEdit_'+ str(i)).deleteLater()
                        self.tabWidget.removeTab(tabidx)

                for i in range(0, count):
                    if i > tabidx:
                        idx = i-1
                        # 새로운 탭을 만듭니다.
                        new_tab = QWidget()
                        # 탭에 추가할 내용을 만듭니다.
                        content = QTextEdit()
                        content.setObjectName('textEdit_'+str(idx))
                        
                        # # 탭의 레이아웃을 설정합니다.
                        tab_layout = QGridLayout()
                        tab_layout.setContentsMargins(6, 6, 6, 6)
                        tab_layout.addWidget(content)
                        new_tab.setLayout(tab_layout)

                        # 탭을 QTabWidget에 추가합니다.
                        tabName = self.QSettings.value('coordinate_tool/MemotabName'+str(i),"메모"+str(i))
                        self.tabWidget.addTab(new_tab,tabName)
                        text = str(self.QSettings.value('coordinate_tool/Memo'+str(i), ''))
                        self.findChild(QTextEdit,'textEdit_'+ str(idx)).setPlainText(text)
                        self.QSettings.setValue('coordinate_tool/Memo'+str(idx),text)
                        self.QSettings.setValue('coordinate_tool/MemotabName'+str(idx),tabName)
                        self.QSettings.remove('coordinate_tool/Memo'+str(i))
                        self.QSettings.remove('coordinate_tool/MemotabName'+str(i))

                        # self.QSettings.remove('coordinate_tool/MemotabName'+str(i))
                        self.findChild(QTextEdit,content.objectName()).textChanged.connect(self.text_change)

        self.tabcount()

    def addtab(self):
        tabcount = self.tabWidget.count()
        self.memoadd.show()
        self.memoadd.lineEdit.clear()
        self.memoadd.lineEdit.setText("메모"+str(tabcount+1))
        self.memoadd.lineEdit.setFocus()

    def addmemosave(self):
        tabName = self.memoadd.lineEdit.text()
        # 새로운 탭을 만듭니다.
        new_tab = QWidget()
        # 현재 메모탭 카운터
        tabcount = self.tabWidget.count()
        self.QSettings.setValue('coordinate_tool/MemotabName'+str(tabcount),tabName)
        # 탭에 추가할 내용을 만듭니다.s
        content = QTextEdit()
        content.setObjectName('textEdit_'+str(tabcount))

        # 탭의 레이아웃을 설정합니다.
        tab_layout = QGridLayout()
        tab_layout.setContentsMargins(6, 6, 6, 6)
        tab_layout.addWidget(content)
        new_tab.setLayout(tab_layout)

        # 탭을 QTabWidget에 추가합니다.
        self.tabWidget.addTab(new_tab,tabName)
        self.tabWidget.setCurrentIndex(tabcount)
        self.findChild(QTextEdit,'textEdit_'+ str(tabcount)).textChanged.connect(self.text_change)
        self.tabcount()

    def tabcount(self):
        count = self.tabWidget.count()
        self.QSettings.setValue('coordinate_tool/Memo_tabcount',count)
