from pathlib import Path
import os
import json
from qgis.core import Qgis, QgsApplication
from qgis.PyQt import uic, QtWidgets
from qgis.PyQt.QtWidgets import (QMessageBox, QWidget, QTextEdit, QGridLayout,
                                 QInputDialog, QLineEdit, QPushButton) # QLineEdit, QPushButton 추가
from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.Qsci import (QsciScintilla, QsciLexerPython, 
                            QsciLexerHTML, QsciLexerSQL)
from qgis.PyQt.QtGui import QIcon, QColor

UI_PATH = Path(__file__).parent / 'ui' / 'Coordinate_Tool_Memo.ui'
FORM_CLASS, _ = uic.loadUiType(str(UI_PATH))

# 아이콘 디렉토리
ICON_DIR = Path(__file__).parent / 'icons'

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):
    """
    QGIS 플러그인 메모 탭 관리 다이얼로그
    """
    AUTO_SAVE_DELAY_MS = 500
    def __init__(self, ctool, iface, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.ctool = ctool

        # 설정 및 API 키
        self.settings = QSettings(
            QSettings.NativeFormat, QSettings.UserScope,
            "masco", "coordinateTool"
        )

        # 메모 탭 로드 및 초기화
        self.tabs = self._load_tabs()
        self._ensure_default_tab()

        # UI 초기화
        self._setup_tab_widget()
        self._setup_buttons()
        self._setup_dialogs()

        # 탭 추가 및 내용 복원
        self._populate_tabs()

    def _get_memo_file_path(self):
        """메모 데이터를 저장할 JSON 파일의 절대 경로를 반환합니다."""
        profile_dir = QgsApplication.qgisSettingsDirPath()
        return os.path.join(profile_dir, "masco_memo_data.json")

    def _ensure_default_tab(self, *args):
        # UI 생성 전 초기 탭을 파일에서 로드
        self.tabs = self._load_tabs()
        if not self.tabs:
            self.tabs = [{'name': '메모', 'text': ''}]
            self._save_tabs()

    def _load_tabs(self, *args):
        file_path = self._get_memo_file_path()
        if not os.path.exists(file_path):
            return []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _save_tabs(self, *args):
        # UI(QTabWidget)의 현재 상태를 읽어서 즉시 파일로 저장
        tabs_data = []
        for i in range(self.tabWidget.count()):
            name = self.tabWidget.tabText(i)
            container = self.tabWidget.widget(i)
            
            # [버그 수정] QTextEdit 대신 QsciScintilla를 찾아야 합니다.
            editor = container.findChild(QsciScintilla)
            # toPlainText() 대신 Scintilla 전용 메서드인 text()를 사용합니다.
            text = editor.text() if editor else ""
            
            tabs_data.append({'name': name, 'text': text})
        
        file_path = self._get_memo_file_path()
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(tabs_data, f, ensure_ascii=False, indent=4)
        except IOError:
            self._show_message("메모 저장에 실패했습니다.", level=Qgis.Critical)

    def _setup_tab_widget(self, *args):
        self.tabWidget.tabBar().setMovable(True)
        # 탭을 드래그해서 옮기면 바로 UI 순서대로 재저장
        self.tabWidget.tabBar().tabMoved.connect(self._save_tabs)

        self.auto_save_timer = QTimer(self)
        self.auto_save_timer.setSingleShot(True)
        # 타이머 만료 시 즉시 UI 상태 저장
        self.auto_save_timer.timeout.connect(self._save_tabs)

    def _setup_buttons(self, *args):
        # 연속 검색(다음 찾기)을 위한 이전 검색어 저장 변수
        self.last_search_text = ""
        
        buttons = {
            self.toolButton:    ("memo_add.png",    self._add_tab),
            self.toolButton_2:  ("memo_remove.png", self._remove_tab),
            self.toolButton_3:  ("memo_edit.png",   self._rename_tab),
        }
        for btn, (icon_file, handler) in buttons.items():
            btn.setIcon(QIcon(str(ICON_DIR / icon_file)))
            btn.clicked.connect(handler)

        # [추가] 상단 레이아웃 우측 빈 공간에 검색 입력창과 버튼 부착
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("검색어 입력 후 엔터")
        self.search_input.setMaximumWidth(150)
        self.search_input.returnPressed.connect(self._find_text)

        self.btn_find = QPushButton("찾기")
        self.btn_find.clicked.connect(self._find_text)

        self.horizontalLayout.addWidget(self.search_input)
        self.horizontalLayout.addWidget(self.btn_find)

    def _find_text(self, *args):
        """현재 활성화된 탭에서 텍스트를 검색합니다."""
        text = self.search_input.text()
        if not text:
            return

        container = self.tabWidget.currentWidget()
        if not container:
            return
            
        editor = container.findChild(QsciScintilla)
        if not editor:
            return

        if getattr(editor, 'last_search_text', '') != text:
            editor.last_search_text = text
            editor.findFirst(text, False, False, False, True)
        else:
            editor.findNext()

    def _setup_dialogs(self, *args):
        def _create_input_dialog(title, label, width=300, height=150):
            dlg = QInputDialog(self)
            dlg.setWindowTitle(title)
            dlg.setLabelText(label)
            dlg.resize(width, height)
            return dlg

        self.rename_input_dialog = _create_input_dialog(
            "메모탭 수정", "메모탭 이름을 입력하세요"
        )

    def _populate_tabs(self, *args):
        self.tabWidget.clear()
        for entry in self.tabs:
            # 과거 데이터 호환을 위해 get 사용, id는 더 이상 사용하지 않음
            name = entry.get('name', '메모')
            text = entry.get('text', '')
            self._create_ui_tab(name, text)

    def _create_ui_tab(self, name, text):
        container = QWidget()
        editor = QsciScintilla()
        editor.setUtf8(True)

        editor.setMarginType(0, QsciScintilla.NumberMargin)
        editor.setMarginWidth(0, "00000")        # 0번 마진(줄 번호): 최대 3자리 폭 확보
        editor.setMarginWidth(1, 5)              # [핵심] 숫자 우측의 불필요한 마커 영역(1번 마진)을 완전히 제거
        
        # Scintilla 내부 메시지로 숫자 앞뒤 미세 패딩을 1~2px로 최소화 밀착
        editor.SendScintilla(QsciScintilla.SCI_SETMARGINLEFT, 0, 10)
        editor.SendScintilla(QsciScintilla.SCI_SETMARGINRIGHT, 0, 2)

        editor.setBraceMatching(QsciScintilla.SloppyBraceMatch)
        editor.setText(text)
        self._apply_lexer(editor, name)
        
        editor.textChanged.connect(self._on_text_changed)

        layout = QGridLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addWidget(editor)

        index = self.tabWidget.addTab(container, name)
        return index

    def _on_text_changed(self, *args):
        self.auto_save_timer.start(self.AUTO_SAVE_DELAY_MS)

    def _show_message(self, msg, level=Qgis.Info, duration=5, *args):
        self.iface.messageBar().clearWidgets()
        self.iface.messageBar().pushMessage(msg, level=level, duration=duration)

    def _apply_lexer(self, editor, tab_name):
        """탭 이름의 확장자를 인식하여 코드 하이라이팅 적용"""
        name_lower = tab_name.lower()
        lexer = None
        if name_lower.endswith('.py'):
            lexer = QsciLexerPython()
        elif name_lower.endswith('.html') or name_lower.endswith('.htm'):
            lexer = QsciLexerHTML()
        elif name_lower.endswith('.sql'):
            lexer = QsciLexerSQL()
            
        if lexer:
            lexer.setDefaultFont(editor.font())
            editor.setLexer(lexer)
        else:
            editor.setLexer(None)
            # [추가 1] 일반 탭으로 돌아올 때 기존 텍스트의 문법 색상을 완전히 초기화
            text = editor.text()
            editor.blockSignals(True)
            editor.setText(text)
            editor.blockSignals(False)
            
        # [추가 2] Lexer가 세팅/해제된 직후에 선택 영역 색상을 다시 강제로 먹여줌
        editor.setSelectionBackgroundColor(QColor("#3399FF"))
        editor.setSelectionForegroundColor(QColor("white"))
        editor.SendScintilla(QsciScintilla.SCI_HIDESELECTION, False)

    # === 탭 관리 메서드 ===
    def _add_tab(self, *args):
        index = self._create_ui_tab('메모', '')
        self.tabWidget.setCurrentIndex(index)
        self._save_tabs()

    def _remove_tab(self, *args):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        name = self.tabWidget.tabText(index)
        answer = QMessageBox.question(
            self, '메모탭 삭제', f"'{name}' 탭을 삭제하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer == QMessageBox.Yes:
            self.tabWidget.removeTab(index)
            self._save_tabs()

    def _rename_tab(self, *args):
        index = self.tabWidget.currentIndex()
        if index < 0:
            return
        old_name = self.tabWidget.tabText(index)

        self.rename_input_dialog.setTextValue(old_name)
        if self.rename_input_dialog.exec_() != QInputDialog.Accepted:
            return
        new_name = self.rename_input_dialog.textValue().strip()
        if not new_name:
            return
        
        self.tabWidget.setTabText(index, new_name)
        
        # 이름이 변경되면 확장자를 재검사하여 실시간으로 코드 스타일 갱신
        editor = self.tabWidget.currentWidget().findChild(QsciScintilla)
        if editor:
            self._apply_lexer(editor, new_name)
        
        # UI 순서대로 즉시 JSON 파일 저장
        self._save_tabs()