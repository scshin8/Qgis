from qgis.PyQt import uic, QtWidgets

from qgis.core import QgsCoordinateReferenceSystem

from PyQt5.QtCore import QSettings

from qgis.PyQt.QtWidgets import (QMessageBox, 
                                 QWidget, 
                                 QTextEdit, 
                                 QGridLayout)

from PyQt5.QtWidgets import QDialogButtonBox

from PyQt5.QtGui import QIcon

import os.path

from .Coordinate_Tool_Memo_add import CoordinateToolMemoadd

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Memo.ui'))

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolMemo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        self.chk = False
        self.QSettings=QSettings()

        self.tabList = self.QSettings.value('coordinate_tool/MemotabList',[])
        if self.tabList == None:
            self.tabList = []

        self.tabNames = self.QSettings.value('coordinate_tool/MemotabNames',[])
        if self.tabNames == None:
            self.tabNames = []

        self.memoadd = CoordinateToolMemoadd()
        self.memoadd.buttonBox.button(QDialogButtonBox.Save).clicked.connect(self.save)

        self.tabWidget.currentChanged.connect(self.tabCha)

        self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/add.png"))
        self.toolButton.clicked.connect(self.addtab)

        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/remove.png"))
        self.toolButton_2.clicked.connect(self.remove_tab)

        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/edit.png"))
        self.toolButton_3.clicked.connect(self.tabNameEdit)        

        self.setMemoTab()

        self.chk = True
        index = int(self.QSettings.value('coordinate_tool/MemocurrentIndex', 0))
        self.tabWidget.setCurrentIndex(index)

    def tabCha(self):
        if self.chk:
            tabidx = self.tabWidget.currentIndex()
            self.QSettings.setValue('coordinate_tool/MemocurrentIndex', tabidx)

    def text_change(self):
        changetabName = str(self.tabWidget.currentWidget().objectName())
        changeidx = changetabName.replace('tab_', '')
        text = str(self.findChild(QTextEdit,'textEdit_'+ str(changeidx)).toPlainText())
        self.QSettings.setValue('coordinate_tool/Memo'+str(changeidx), text)

    def tabNameEdit(self):
        tabidx = self.tabWidget.currentIndex()
        tabname = self.tabWidget.tabText(tabidx)
        if tabidx > -1:
            self.memoadd.show()
            self.memoadd.label.setText('메모탭 이름 수정')
            self.memoadd.lineEdit.clear()
            self.memoadd.lineEdit.setPlaceholderText(tabname)
            self.memoadd.lineEdit.setFocus()

    def edifmemo(self):
        tabidx = self.tabWidget.currentIndex()
        tabname = self.tabWidget.tabText(tabidx)
        edittabName = str(self.tabWidget.currentWidget().objectName())
        editidx = edittabName.replace('tab_', '')
        newname = self.memoadd.lineEdit.text()
        self.tabWidget.setTabText(tabidx, newname)

        self.tabList = self.QSettings.value('coordinate_tool/MemotabList',[])
        self.tabNames = self.QSettings.value('coordinate_tool/MemotabNames',[])

        for idx, i in enumerate(self.tabList):
            if i == int(editidx):
                print(self.tabNames, newname)
                self.tabNames[idx] = newname
                break

        self.QSettings.setValue('coordinate_tool/MemotabNames',self.tabNames)

    def setMemoTab(self):
        tabListCount = len(self.tabList)
        if tabListCount > 0:
            for i, n  in zip(self.tabList, self.tabNames):
                # 새로운 탭을 만듭니다.
                new_tab = QWidget()
                new_tab.setObjectName('tab_'+str(i))
                # 탭에 추가할 내용을 만듭니다.
                content = QTextEdit()
                content.setObjectName('textEdit_'+str(i))

                # 탭의 레이아웃을 설정합니다.
                tab_layout = QGridLayout()
                tab_layout.setContentsMargins(6, 6, 6, 6)
                tab_layout.addWidget(content)
                new_tab.setLayout(tab_layout)

                # 탭을 QTabWidget에 추가합니다.
                self.tabWidget.addTab(new_tab,n)
                self.findChild(QTextEdit,'textEdit_'+ str(i)).setPlainText(str(self.QSettings.value('coordinate_tool/Memo'+str(i), '')))
                self.findChild(QTextEdit,'textEdit_'+ str(i)).textChanged.connect(self.text_change)
        else:
            # 새로운 탭을 만듭니다.
            new_tab = QWidget()
            new_tab.setObjectName('tab_0')
            # 탭에 추가할 내용을 만듭니다.
            content = QTextEdit()
            content.setObjectName('textEdit_0')

            # 탭의 레이아웃을 설정합니다.
            tab_layout = QGridLayout()
            tab_layout.setContentsMargins(6, 6, 6, 6)
            tab_layout.addWidget(content)
            new_tab.setLayout(tab_layout)

            # 탭을 QTabWidget에 추가합니다.
            self.tabWidget.addTab(new_tab,'메모1')
            self.findChild(QTextEdit,'textEdit_0').textChanged.connect(self.text_change)

            self.QSettings.setValue('coordinate_tool/MemocurrentIndex', 0)
            # self.QSettings.setValue('coordinate_tool/Memo_tabcount',1)
            self.tabList = [0]
            self.QSettings.setValue('coordinate_tool/MemotabList',self.tabList)
            self.tabNames = ['메모1']
            self.QSettings.setValue('coordinate_tool/MemotabNames',self.tabNames)

    def remove_tab(self):
        if self.tabWidget.count() > 0:
            self.tabList = self.QSettings.value('coordinate_tool/MemotabList',[])
            self.tabNames = self.QSettings.value('coordinate_tool/MemotabNames',[])

            tabidx = self.tabWidget.currentIndex()
            tabname = self.tabWidget.tabText(tabidx)
            deltabName = str(self.tabWidget.currentWidget().objectName())
            delidx = deltabName.replace('tab_', '')
            reply = QMessageBox.question(None,
                                    self.tr('메모 삭제'),
                                    self.tr(str(tabname) +  " 를 삭제 합니다.  \n계속 하시겠습니까?  \n"),
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                self.findChild(QTextEdit,'textEdit_'+ str(delidx)).deleteLater()
                self.tabWidget.removeTab(tabidx)
                # 탭 리스트 삭제
                self.tabList.remove(int(delidx))
                self.tabNames.remove(str(tabname))

                self.QSettings.setValue('coordinate_tool/MemotabList',self.tabList)
                self.QSettings.setValue('coordinate_tool/MemotabNames',self.tabNames)

                # count = self.tabWidget.count()
                # for i in range(0, count):
                #     print(self.tabWidget.widget(i).objectName())
                #     if i >= tabidx:
                #         self.findChild(QTextEdit,'textEdit_'+ str(i)).deleteLater()
                #         self.tabWidget.removeTab(tabidx)

                # for i in range(0, count):
                #     if i > tabidx:
                #         idx = i-1
                #         # 새로운 탭을 만듭니다.
                #         new_tab = QWidget()
                #         new_tab.setObjectName('tab_' + str(idx))
                #         # 탭에 추가할 내용을 만듭니다.
                #         content = QTextEdit()
                #         content.setObjectName('textEdit_'+str(idx))
                        
                #         # # 탭의 레이아웃을 설정합니다.
                #         tab_layout = QGridLayout()
                #         tab_layout.setContentsMargins(6, 6, 6, 6)
                #         tab_layout.addWidget(content)
                #         new_tab.setLayout(tab_layout)

                #         # 탭을 QTabWidget에 추가합니다.
                #         tabName = self.QSettings.value('coordinate_tool/MemotabName'+str(i),"메모"+str(i))
                #         self.tabWidget.addTab(new_tab,tabName)
                #         text = str(self.QSettings.value('coordinate_tool/Memo'+str(i), ''))
                #         self.findChild(QTextEdit,'textEdit_'+ str(idx)).setPlainText(text)
                #         self.QSettings.setValue('coordinate_tool/Memo'+str(idx),text)
                #         self.QSettings.setValue('coordinate_tool/MemotabName'+str(idx),tabName)
                #         self.QSettings.remove('coordinate_tool/Memo'+str(i))
                #         self.QSettings.remove('coordinate_tool/MemotabName'+str(i))

                #         # self.QSettings.remove('coordinate_tool/MemotabName'+str(i))
                #         self.findChild(QTextEdit,content.objectName()).textChanged.connect(self.text_change)

    def addtab(self):
        self.tabList = self.QSettings.value('coordinate_tool/MemotabList',[])
        for i in range(100):
            if i not in self.tabList:
                self.addidx = i
                self.memoadd.show()
                self.memoadd.label.setText('메모탭 추가')
                self.memoadd.lineEdit.clear()
                self.memoadd.lineEdit.setPlaceholderText("")
                self.memoadd.lineEdit.setText("메모"+str(i+1))
                self.memoadd.lineEdit.setFocus()
                break

    def save(self):
        if self.memoadd.label.text() == '메모탭 추가':
            self.addmemo()
        else:
            self.edifmemo()

    def addmemo(self):
        # 새 메모탭 이름
        tabName = self.memoadd.lineEdit.text()
        # 현재 메모탭 카운터
        tabcount = self.tabWidget.count()
        # 탭 리스트
        self.tabList = self.QSettings.value('coordinate_tool/MemotabList',[])
        # 탭 리스트 추가
        self.tabList.append(self.addidx)
        # 탭 네임
        self.tabNames = self.QSettings.value('coordinate_tool/MemotabNames',[])
        # 탭 네임 추가
        self.tabNames.append(tabName)

        # 새로운 탭을 만듭니다.
        new_tab = QWidget()
        new_tab.setObjectName('tab_' + str(self.addidx))
        # 탭에 추가할 내용을 만듭니다.s
        content = QTextEdit()
        content.setObjectName('textEdit_'+str(self.addidx))

        # 탭의 레이아웃을 설정합니다.
        tab_layout = QGridLayout()
        tab_layout.setContentsMargins(6, 6, 6, 6)
        tab_layout.addWidget(content)
        new_tab.setLayout(tab_layout)

        # 탭을 QTabWidget에 추가합니다.
        self.tabWidget.addTab(new_tab,tabName)
        self.tabWidget.setCurrentIndex(tabcount)
        self.findChild(QTextEdit,'textEdit_'+ str(self.addidx)).textChanged.connect(self.text_change)

        self.QSettings.setValue('coordinate_tool/MemotabList',self.tabList)
        self.QSettings.setValue('coordinate_tool/MemotabNames',self.tabNames)