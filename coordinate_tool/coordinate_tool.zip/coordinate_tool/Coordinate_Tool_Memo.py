from qgis.PyQt import uic, QtWidgets

from qgis.core import QgsCoordinateReferenceSystem

from PyQt5.QtCore import QSettings, Qt

from qgis.PyQt.QtWidgets import (QMessageBox, 
                                 QWidget, 
                                 QTextEdit, 
                                 QGridLayout)

from PyQt5.QtWidgets import QDialogButtonBox, QTabWidget

from PyQt5.QtGui import QIcon

import os.path, datetime

from .Coordinate_Tool_Memo_add import CoordinateToolMemoadd

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Memo.ui'))

class CoordinateToolMemo(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self,CTool,iface, parent=None):
        super(CoordinateToolMemo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        self.chk = False
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.tabList = self.QSettings.value('MemotabList',[])
        if self.tabList == None:
            self.tabList = []

        self.tabNames = self.QSettings.value('MemotabNames',[])
        if self.tabNames == None:
            self.tabNames = []

        self.memoadd = CoordinateToolMemoadd()
        self.memoadd.buttonBox.button(QDialogButtonBox.Save).clicked.connect(self.editmemo)

        self.tabWidget.currentChanged.connect(self.tabCha)

        self.toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/add.png"))
        self.toolButton.clicked.connect(self.addtab)

        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/remove.png"))
        self.toolButton_2.clicked.connect(self.remove_tab)

        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/edit.png"))
        self.toolButton_3.clicked.connect(self.tabNameEdit)        

        self.setMemoTab()

        self.chk = True
        self.QSettings.setValue('MemocurrentIndex', 0)
        self.tabWidget.setCurrentIndex(0)
        self.tabidx = 0
        tabName = str(self.tabWidget.currentWidget().objectName())
        self.changeidx = tabName.replace('tab_', '')

    def tabCha(self):
        if self.chk:
            tabidx = self.tabWidget.currentIndex()

            if tabidx > -1:
                changetabName = str(self.tabWidget.currentWidget().objectName())
                changeidx = changetabName.replace('tab_', '')

                if tabidx != self.tabidx and  changeidx == self.changeidx:
                    self.tabList[self.tabidx],  self.tabList[tabidx] = self.tabList[tabidx] , self.tabList[self.tabidx]
                    self.QSettings.setValue('MemotabList',self.tabList)

                self.QSettings.setValue('MemocurrentIndex', tabidx)
                self.tabidx = tabidx
                self.changeidx = changeidx

    def text_change(self):
        import requests
        import base64
        changetabName = str(self.tabWidget.currentWidget().objectName())
        changeidx = changetabName.replace('tab_', '')
        text = str(self.findChild(QTextEdit,'textEdit_'+ str(changeidx)).toPlainText())
        self.QSettings.setValue('Memo'+str(changeidx), text)

    # 깃허브 메모장 수정 코드
    #     token = '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'
    #     repo = 'scshin8/Qgis'
    #     path = 'Memo.txt'
    #     url = f'https://api.github.com/repos/{repo}/contents/{path}'
    #     headers = {
    #         'Authorization': f'token {token}',
    #         'Accept': 'application/vnd.github.v3+json'
    #     }

    #     content = base64.b64encode(text.encode('utf-8')).decode('utf-8')
    #     data = {
    #         'message': 'Updating file via QGIS plugin',
    #         'content': content,
    #         'sha': self.get_file_sha(url, headers)
    #     }

    #     response = requests.put(url, headers=headers, json=data)
    #     if response.status_code == 200:
    #         print('File updated successfully!')
    #     else:
    #         print(f'Failed to update file: {response.status_code}, {response.text}')

    # def get_file_sha(self, url, headers):
    #     import requests
    #     response = requests.get(url, headers=headers)
    #     if response.status_code == 200:
    #         return response.json()['sha']
    #     else:
    #         print('error')
    #         return ''

    def tabNameEdit(self):
        tabname = self.tabWidget.tabText(self.tabidx)
        if self.tabidx > -1:
            self.memoadd.show()
            self.memoadd.label.setText('메모탭 이름 수정')
            self.memoadd.lineEdit.clear()
            self.memoadd.lineEdit.setPlaceholderText(tabname)
            self.memoadd.lineEdit.setFocus()

    def editmemo(self):
        edittabName = str(self.tabWidget.currentWidget().objectName())
        editidx = edittabName.replace('tab_', '')
        newname = self.memoadd.lineEdit.text()
        self.tabWidget.setTabText(self.tabidx, newname)

        self.tabList = self.QSettings.value('MemotabList',[])
        self.tabNames = self.QSettings.value('MemotabNames',[])
        for idx, i in enumerate(self.tabList):
            if i == editidx:
                self.tabNames[idx] = newname
                break
        print(self.tabNames)
        self.QSettings.setValue('MemotabNames',self.tabNames)

    def setMemoTab(self):
        tabListCount = len(self.tabList)
        if tabListCount > 0:
            for i,n   in zip(self.tabList, self.tabNames):
                # 새로운 탭을 만듭니다.
                new_tab = QWidget()
                new_tab.setObjectName('tab_'+str(i))
                # 탭에 추가할 내용을 만듭니다.
                content = QTextEdit()
                content.setObjectName('textEdit_'+str(i))

                # 탭의 레이아웃을 설정합니다.
                tab_layout = QGridLayout()
                tab_layout.setContentsMargins(6, 6, 6, 6)
                tab_layout.addWidget(content)
                new_tab.setLayout(tab_layout)

                # 탭을 QTabWidget에 추가합니다.
                self.tabWidget.addTab(new_tab,n)
                self.findChild(QTextEdit,'textEdit_'+ str(i)).setPlainText(str(self.QSettings.value('Memo'+str(i), '')))
                self.findChild(QTextEdit,'textEdit_'+ str(i)).textChanged.connect(self.text_change)
        else:
            # 새로운 탭을 만듭니다.
            new_tab = QWidget()
            new_tab.setObjectName('tab_0')
            # 탭에 추가할 내용을 만듭니다.
            content = QTextEdit()
            content.setObjectName('textEdit_0')

            # 탭의 레이아웃을 설정합니다.
            tab_layout = QGridLayout()
            tab_layout.setContentsMargins(6, 6, 6, 6)
            tab_layout.addWidget(content)
            new_tab.setLayout(tab_layout)

            new_tab_name = '메모'

            # 탭을 QTabWidget에 추가합니다.
            self.tabWidget.addTab(new_tab,new_tab_name)
            self.findChild(QTextEdit,'textEdit_0').textChanged.connect(self.text_change)

            self.tabidx = 0
            self.QSettings.setValue('MemocurrentIndex', self.tabidx)
            # self.QSettings.setValue('Memo_tabcount',1)
            self.tabList = ['0']
            self.QSettings.setValue('MemotabList',self.tabList)
            self.tabNames = [new_tab_name]
            self.QSettings.setValue('MemotabNames',self.tabNames)

    def remove_tab(self):
        if self.tabWidget.count() > 0:
            self.tabList = self.QSettings.value('MemotabList',[])
            self.tabNames = self.QSettings.value('MemotabNames',[])

            tabname = self.tabWidget.tabText(self.tabidx)
            deltabName = str(self.tabWidget.currentWidget().objectName())
            delidx = deltabName.replace('tab_', '')
            reply = QMessageBox.question(None,
                                    self.tr('메모탭 삭제'),
                                    self.tr(str(tabname) +  " 를 삭제 합니다.  \n계속 하시겠습니까?  \n"),
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if reply == QMessageBox.Yes:
                self.findChild(QTextEdit,'textEdit_'+ str(delidx)).deleteLater()
                self.tabWidget.removeTab(self.tabidx)

                # 탭 리스트 삭제
                try:
                    self.tabList.remove(int(delidx))
                except:
                    self.tabList.remove(str(delidx))
                    
                self.QSettings.setValue('MemotabList',self.tabList)

                # 네임 리스트 삭제
                print(self.tabNames)
                self.tabNames.remove(str(tabname))
                print(self.tabNames)
                self.QSettings.setValue('MemotabNames',self.tabNames)
                # 저장값 삭제
                self.QSettings.remove('Memo'+str(delidx))

    def addtab(self):
        self.tabList = self.QSettings.value('MemotabList',[])
        print(self.tabList)
        for i in range(100):
            if str(i) not in self.tabList:
                self.addidx = str(i)
                break
        print(self.addidx)
        # 새 메모탭 이름
        tabName = "메모_"
        tabName += datetime.datetime.now().strftime("%Y%m%d_%H%M%S")[2:]
        

        # 현재 메모탭 카운터
        tabcount = self.tabWidget.count()
        # 탭 리스트
        self.tabList = self.QSettings.value('MemotabList',[])
        # 탭 리스트 추가
        self.tabList.append(self.addidx)
        print(self.tabList)
        # 탭 네임
        self.tabNames = self.QSettings.value('MemotabNames',[])
        # 탭 네임 추가
        self.tabNames.append(tabName)

        # 새로운 탭을 만듭니다.
        new_tab = QWidget()
        new_tab.setObjectName('tab_' + self.addidx)
        # 탭에 추가할 내용을 만듭니다.s
        content = QTextEdit()
        content.setObjectName('textEdit_'+ self.addidx)

        # 탭의 레이아웃을 설정합니다.
        tab_layout = QGridLayout()
        tab_layout.setContentsMargins(6, 6, 6, 6)
        tab_layout.addWidget(content)
        new_tab.setLayout(tab_layout)

        # 탭을 QTabWidget에 추가합니다.
        self.tabWidget.addTab(new_tab,tabName)
        self.tabWidget.setCurrentIndex(tabcount)
        self.findChild(QTextEdit,'textEdit_'+ str(self.addidx)).textChanged.connect(self.text_change)

        self.QSettings.setValue('MemotabList', self.tabList)
        self.QSettings.setValue('MemotabNames', self.tabNames)