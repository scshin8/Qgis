from PyQt5 import QtCore
from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsWkbTypes,
                       QgsCoordinateTransform,
                       QgsProject, 
                       Qgis,
                       QgsPointXY, 
                       QgsRectangle, 
                       QgsPoint, 
                       QgsGeometry)

from PyQt5.QtCore import (QSettings,
                          QTimer,
                          Qt,
                          pyqtSignal)

from qgis.gui import (QgsRubberBand,
                      QgsMapToolEmitPoint)

from PyQt5.QtGui import (QKeySequence, 
                         QColor)

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_decryptKey import AESCipher
from . import Coordinate_Tool_data
import requests, json, math

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')

class Coordinate_funtion(QgsMapToolEmitPoint):
    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool = CTool
        self.marker = None
        self.crossRb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.QSettings=QSettings()
        self.clipboard = QApplication.clipboard()
        self.mapid = Coordinate_Tool_data.MAP_ID
        self.AESCipher = AESCipher(self)

        # self.dlg = CoordinateToolSetting(self,iface)
        
    def setval(self,setCRS,text):
        try:
            # 이동 좌표가 사용자정의 좌표계 인지 확인 
            if 100000 <= int(setCRS.authid().split(':')[1]):  # description()_좌표계이름  authid()_좌표계 식별코드
                # 사용자정의 좌표가 맞다면
                lon, lat = self.fsconversion(text)
                return lon, lat
                #사용자 정의 좌표계가 아니라면
            else:
                # 좌표값 X,Y 구분  
                if text.find(',')>0:
                    lon=text.split(',')[0]
                    lat=text.split(',')[1]
                elif text.find(' ')>0:
                    lon=text.split(' ')[0]
                    lat=text.split(' ')[1]
                elif text.find('	')>0:
                    lon=text.split('	')[0]
                    lat=text.split('	')[1]
                elif text.find('/')>0:
                    lon=text.split('/')[0]
                    lat=text.split('/')[1]
                elif text.find('_')>0:
                    lon=text.split('_')[0]
                    lat=text.split('_')[1]
                elif text.find('|')>0:
                    lon=text.split('|')[0]
                    lat=text.split('|')[1]
                # X,Y 구분후 다른 진행
                return lon, lat
        except Exception as e:
            print("setval Error : ", e)
                
    # 사용자정의 좌표계라면 FS 좌표 인지. MMS 좌표인지 구분이 필요
    def fsconversion(self, text):
        try:
            if text[0]=='(' and text[-1]==')':      # MMS 좌표 괄호 포함
                text=text.strip('()')
                text=text.split(',')
                lon=text[0].strip()
                lat=text[1].strip()
                return lon, lat

            elif text[4]=='(' and text[11]==')':    # FS 좌표
                text=text[12:].strip('()') # .replace('/', ',')
                text=text.split('/')
                lon=text[0].strip()
                lat=text[1].strip()
                lon=lon.split('.')
                lat=lat.split('.')

                lon2=lon[2]+'.'+lon[3]
                lon2=float(lon2)/60
                lon1=round((int(lon[1])+lon2)/60,8)
                lon=(int(lon[0])+lon1)*360000

                lat2=lat[2]+'.'+lat[3]
                lat2=float(lat2)/60
                lat1=round((int(lat[1])+lat2)/60,8)
                lat=(int(lat[0])+lat1)*360000 
                return lon, lat

            elif text[0]=='4' or text[0]=='1':      # MMS 좌표 괄호 미포함
                if text.find(',')>0:
                    lon=text.split(',')[0]
                    lat=text.split(',')[1]
                elif text.find(' ')>0:
                    lon=text.split(' ')[0]
                    lat=text.split(' ')[1]
                elif text.find('	')>0:
                    lon=text.split('	')[0]
                    lat=text.split('	')[1]
                elif text.find('/')>0:
                    lon=text.split('/')[0]
                    lat=text.split('/')[1]
                return lon, lat

            # 해당 조건에 맞지 않는 좌표값은 프로그램 중단
            else:
                pass

        except Exception as e:
            print("fsconversion Error : ", e)

    def moveto(self, setCRS, lon, lat, Order):
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(setCRS, canvas_crs, QgsProject.instance())
        transform1 = QgsCoordinateTransform(setCRS, epsg4326, QgsProject.instance())
        
        Lon = lat if Order == 1 else lon
        Lat = lon if Order == 1 else lat  
            
        try:
            x, y = transform.transform(float(Lon), float(Lat))
            point = transform1.transform(float(Lon), float(Lat))
        except:
            pass

        # 위치정보 표출
        grs = self.fscoordinate(point)
        map, company, team, ctp, sig = self.mapidinfo(grs)
        self.iface.statusBarIface().showMessage(f"{company} / {team} / {ctp} / {sig} / {map} / {grs}", 4000)
        
        rect = QgsRectangle(x, y, x, y)
        self.canvas.setExtent(rect)
        point = QgsPointXY(x, y)
        self.highlight(point)
        
# 화면에 이동지점 표시
    def highlight(self, point):
        self.resetRubberbands
        currExt = self.canvas.extent()

        leftPt = QgsPoint(currExt.xMinimum(), point.y())
        rightPt = QgsPoint(currExt.xMaximum(), point.y())

        topPt = QgsPoint(point.x(), currExt.yMaximum())
        bottomPt = QgsPoint(point.x(), currExt.yMinimum())

        horizLine = QgsGeometry.fromPolyline([leftPt, rightPt])
        vertLine = QgsGeometry.fromPolyline([topPt, bottomPt])

        self.crossRb.reset(QgsWkbTypes.LineGeometry)
        
        color = QColor(self.QSettings.value('coordinate_tool/GridColorButton_1', '#ff00ff'))
        color.setAlpha(int(self.QSettings.value('coordinate_tool/GridColorButtonOpacity_1', 255)))
        
        self.crossRb.setColor(color)
        self.crossRb.setWidth(1)
        self.crossRb.addGeometry(horizLine, None)
        self.crossRb.addGeometry(vertLine, None)

        QTimer.singleShot(6000, self.resetRubberbands)
# 화면 이동지점 표시 삭제
    def resetRubberbands(self):
        self.crossRb.reset()

# MMS좌표로 변환       
    def mmscoordinate(self,point):
        if int(point[0]) > 40000000:
            Lon = float(point[0])
            Lat = float(point[1])
        else:
            Lon = float(point[0]*360000)
            Lat = float(point[1]*360000)
        return Lon , Lat 
    
# mapid_8Lv      
    def mapid_8Lv(self,point):
        if int(point[0]) > 40000000:
            Lon = float(point[0])
            Lat = float(point[1])
        else:
            Lon = float(point[0]*360000)
            Lat = float(point[1]*360000)
            
        map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
        map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
        map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
        map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
        mapid = map1 + map2 + map3 + map4
        
        row = int((abs((Lat-11880000)-(int((Lat-11880000)/30000)*30000))+30000)/3750)-7
        cou = int((abs((Lon-44640000)-(int((Lon-44640000)/45000)*45000))+45000)/5625)-7

        mapid_Info=self.mapid.get(str(row))
        
        if mapid_Info != None:
            idx = mapid_Info[cou]
            mapid = mapid + idx
            return mapid
        else:
            return mapid

# FS좌표로 변환
    def fscoordinate(self,point):
        try:
            if int(point[0]) > 40000000:
                Lon = int(point[0])
                Lat = int(point[1])
                x = float(Lon/360000)
                y = float(Lat/360000)
            else:
                x = float(point[0])
                y = float(point[1])
                Lon = int(x*360000)
                Lat = int(y*360000)
            
            map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
            map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
            map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
            map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
            mapid = map1 + map2 + map3 + map4

            LonD=int(x)
            LonM=int(((x)-LonD)*60)
            LonS=round(((((x)-LonD)*60)-LonM)*60,2)
            LonS=format(LonS, ".2f")
            LatD=int(y)
            LatM=int(((y)-LatD)*60)
            LatS=round(((((y)-LatD)*60)-LatM)*60,2)
            LatS=f'{LatS:.2f}'
            fs = mapid + '(000000)(' + str(LonD) +'.'+ str(LonM) +'.'+ str(LonS) +'/'+ str(LatD) +'.'+ str(LatM) +'.'+ str(LatS) + ')' 

            return fs
        except:
            pass

# 카카오 주소값 변환
    def kakaojoso(self,point):
        try:
            x = point[0]
            y = point[1]
            apikey = self.QSettings.value('coordinate_tool/REST_API_KEY', '')
            REST_API_KEY = self.AESCipher.decrypt(apikey)
            if apikey != '':
                url="https://dapi.kakao.com/v2/local/geo/coord2address.json"
                headers = {"Authorization": f"KakaoAK {REST_API_KEY}"}
                params = {"x": f"{x}","y": f"{y}"}
                request = requests.get(url, headers=headers, params=params)
                if request.status_code==200:
                    data=request.json()
                    road_address = data["documents"][0].get("road_address")
                    address = data["documents"][0].get("address")
                    if road_address != None:
                        ctp = road_address["region_1depth_name"]
                        sig = road_address["region_2depth_name"]
                        finalAddress=road_address["address_name"]
                        roadaddress = finalAddress.replace('  ',' ')
                        finalAddress=address["address_name"]
                        jibunaddress = finalAddress.replace('  ',' ')
                        return ctp, sig, roadaddress, jibunaddress
                    else:
                        ctp = address["region_1depth_name"]
                        sig = address["region_2depth_name"]
                        finalAddress=address["address_name"]
                        jibunaddress = finalAddress.replace('  ',' ')
                        return ctp, sig, jibunaddress, jibunaddress
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "kakao" , "카카오 주소 요청 오류")
                    return None, None, None, None
            else:
                QMessageBox.critical(self.iface.mainWindow(), "kakao " , "API key Null")
                return None, None, None, None
        except:
                QMessageBox.critical(self.iface.mainWindow(), "kakao " , "카카오 주소 요청 오류")
                return None, None, None, None
# 네이버 주소값 변환
    def naverjoso(self,point):
        apikey1 = self.QSettings.value('coordinate_tool/client_id', '')
        client_id = self.AESCipher.decrypt(apikey1)
        apikey2 = self.QSettings.value('coordinate_tool/client_secret', '')
        client_secret = self.AESCipher.decrypt(apikey2)
        if apikey1!='' and apikey2 != '':
            coords= str(point[0]) +','+ str(point[1])
            output = "json"
            orders = 'addr,roadaddr' #orders=admcode,legalcode,addr,roadaddr
            naver_url = "https://naveropenapi.apigw.ntruss.com/map-reversegeocode/v2/gc"
            url = f"{naver_url}?request=coordsToaddr&coords={coords}&output={output}&orders={orders}"
            headers  = {"X-NCP-APIGW-API-KEY-ID": str(client_id), "X-NCP-APIGW-API-KEY": str(client_secret)}
            request = requests.get(url, headers=headers)
            # 가져온 JSON 텍스트를 dictionary으로 변환한다.
            naver_url_text = json.loads(request.text)
            try:    
                if str(request) == '<Response [200]>':
                    
                    if int(len(naver_url_text['results'])) == 2:
                        Address=naver_url_text['results'][1]
                        # 국가 코드 최상위 도메인 두 자리.
                        # finalAddress = Address['region']['area0']['name']+" "
                        # 시/도
                        ctp = Address['region']['area1']['name']
                        finalAddress = Address['region']['area1']['name']+" "
                        # 시/군/구
                        sig = Address['region']['area2']['name']
                        finalAddress += Address['region']['area2']['name']+" "
                        # 읍/면/동
                        # finalAddress += Address['region']['area3']['name']+" "
                        # 리
                        # finalAddress += Address['region']['area4']['name']+" "
                        # 도로명
                        finalAddress += Address['land']['name']+" "
                        # 토지 본번호
                        finalAddress += Address['land']['number1']
                        if Address['land']['number2'] != '':
                            # 토지 부번호
                            finalAddress += "-" +Address['land']['number2']
                        roadaddress = finalAddress.replace('  ',' ')
                        
                        Address=naver_url_text['results'][0]
                        finalAddress = Address['region']['area1']['name']+" "
                        finalAddress += Address['region']['area2']['name']+" "
                        finalAddress += Address['region']['area3']['name']+" "
                        finalAddress += Address['region']['area4']['name']+" "
                        finalAddress += Address['land']['number1']
                        if Address['land']['number2'] != '':
                            finalAddress += "-" +Address['land']['number2']
                        jibunaddress = finalAddress.replace('  ',' ')
                        return ctp, sig, roadaddress, jibunaddress
                    else:
                        Address=naver_url_text['results'][0]
                        ctp = Address['region']['area1']['name']
                        finalAddress = Address['region']['area1']['name']+" "
                        sig = Address['region']['area2']['name']
                        finalAddress += Address['region']['area2']['name']+" "
                        finalAddress += Address['region']['area3']['name']+" "
                        finalAddress += Address['region']['area4']['name']+" "
                        finalAddress += Address['land']['number1']
                        if Address['land']['number2'] != '':
                            finalAddress += "-" +Address['land']['number2']
                        jibunaddress = finalAddress.replace('  ',' ')
                        return ctp, sig, jibunaddress, jibunaddress
                else:
                    QMessageBox.critical(self.iface.mainWindow(), "Naver", "주소 요청 오류")
                    return None, None, None, None
            except requests.exceptions.RequestException as erra :
                QMessageBox.critical(self.iface.mainWindow(), "Naver", "Error Code:" + str(erra))
                return None, None, None, None
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Naver", "API key Null")
            return None, None, None, None

# 브이월드 주소값 변환
    def vworldjoso(self,point):
        x = point[0]
        y = point[1]
        apikey = self.QSettings.value('coordinate_tool/Vworld_APIkey', '')
        Vworld_APIkey = self.AESCipher.decrypt(apikey)
        if apikey != '':
            coords= str(x) +','+ str(y)
            url = "http://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&crs=epsg:4326&point="
            url += coords
            url += "&format=json&type=ROAD&zipcode=true&simple=false&key="
            url +=  Vworld_APIkey
            request = requests.get(url)
            request.status_code
            if request.status_code == 200:
                data = request.json()
                if data['response']['status'] == "OK":
                    ctp = data['response']['result'][0]['structure']['level1']
                    sig = data['response']['result'][0]['structure']['level2']
                    finalAddress=data['response']['result'][0]['text']
                    roadaddress = finalAddress.replace('  ',' ')

                    url = "http://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&crs=epsg:4326&point="
                    url += coords
                    url += "&format=json&type=PARCEL&zipcode=true&simple=false&key="
                    url +=  Vworld_APIkey
                    request = requests.get(url)
                    request.status_code
                    if request.status_code == 200:
                        data = request.json()
                        if data['response']['status'] == "OK":
                            finalAddress=data['response']['result'][0]['text']
                            jibunaddress = finalAddress.replace('  ',' ')
                            return ctp, sig, roadaddress, jibunaddress
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "Error", "Error Code:" + str(data['response']['status']))
                            return None, None, None, None
                    else:
                        QMessageBox.critical(self.iface.mainWindow(), "Error", "Error Code:" + str(request.status_code))
                        return None, None, None, None
                else:
                    url = "http://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&crs=epsg:4326&point="
                    url += coords
                    url += "&format=json&type=PARCEL&zipcode=true&simple=false&key="
                    url +=  Vworld_APIkey
                    request = requests.get(url)
                    request.status_code
                    if request.status_code == 200:
                        data = request.json()
                        if data['response']['status'] == "OK":
                            ctp = data['response']['result'][0]['structure']['level1']
                            sig = data['response']['result'][0]['structure']['level2']
                            finalAddress=data['response']['result'][0]['text']
                            jibunaddress = finalAddress.replace('  ',' ')
                            return ctp, sig, jibunaddress, jibunaddress
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "Vworld", "주소 요청 오류")
                            return None, None, None, None
                    else:
                        QMessageBox.critical(self.iface.mainWindow(), "Vworld", "주소 요청 오류")
                        return None, None, None, None
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Vworld", "주소 요청 오류")
                return None, None, None, None
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Vworld", "API key Null")
            return None, None, None, None

# 플레이맵 주소값 변환
    def Routojoso(self,point):
        x = point[0]
        y = point[1]
        coords= str(y) +','+ str(x)
        url="https://api.routo.com/v1/rgeocode?key=AB7B15940E89447C&latlng="
        url = url + coords
        request = requests.get(url)
        request.status_code
        if request.status_code == 200:
            data = request.json()
            if data['count'] > 0 :
                ctp = data['result'][0]['administrative']['state']
                sig = data['result'][0]['administrative']['city']
                roadaddress=data['result'][0]['street']['formatted_address']
                jibunaddress=data['result'][0]['jibun']['formatted_address']
                return ctp, sig, roadaddress, jibunaddress
            else:
                return None, None, None, None
        else:
            return None, None, None, None
        
    def mapidinfo(self,point):
        mapid=point[:4]
        mapid_Info=self.mapid.get(str(mapid))
        if mapid_Info != None:
            map=mapid+'0000'
            partner = self.mapid[str(mapid)][0]
            team = self.mapid[str(mapid)][1]
            ctp = self.mapid[str(mapid)][2]
            sig = self.mapid[str(mapid)][3]
            return map, partner, team, ctp, sig
        else:
            return None, None, None, None, None

class capture(QgsMapToolEmitPoint):
    '''Class to interact with the map canvas to capture the coordinate
    when the mouse button is pressed.'''
    capturePoint = pyqtSignal(QgsPointXY)
    captureStopped = pyqtSignal()
    captureStopped1 = pyqtSignal()
    
    def __init__(self, canvas,):
        QgsMapToolEmitPoint.__init__(self, canvas)
        self.canvas = canvas
        self.vertex = None

    def activate(self):
        '''When activated set the cursor to a crosshair.'''
        self.canvas.setCursor(Qt.CrossCursor)

    # 아이콘 눌러 좌표캡쳐중단
    def deactivate(self):
        self.captureStopped.emit()

    # ESC 눌러 좌표캡쳐중단
    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.captureStopped1.emit()
 
    # 좌표캡쳐 이벤트 함수
    def canvasReleaseEvent(self, event):
        button = event.button()
        if button == Qt.LeftButton: # 좌클릭하면 좌표캡쳐 실행
            pt =self.toMapCoordinates(self.canvas.mouseLastXY())
            self.capturePoint.emit(pt)
        else:
            pass
                
class Pathcapture(QgsMapToolEmitPoint):
    '''Class to interact with the map canvas to capture the coordinate
    when the mouse button is pressed.'''
    capturePoint = pyqtSignal(QgsPointXY,str)
    captureStopped = pyqtSignal()
    captureStopped1 = pyqtSignal()
    
    def __init__(self, canvas,):
        QgsMapToolEmitPoint.__init__(self, canvas)
        self.canvas = canvas
        self.vertex = None

    def activate(self):
        '''When activated set the cursor to a crosshair.'''
        self.canvas.setCursor(Qt.CrossCursor)
        # self.snapcolor = QgsSettings().value( "/qgis/digitizing/snap_color" , QColor( Qt.magenta ) )

    # 아이콘 눌러 좌표캡쳐중단
    def deactivate(self):
        self.captureStopped.emit()

    # ESC 눌러 좌표캡쳐중단
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Cancel):
            self.captureStopped1.emit()
            
    def canvasReleaseEvent(self, event):
        pt =self.toMapCoordinates(self.canvas.mouseLastXY())
        button = event.button()
        event.modifiers()
        if button == Qt.LeftButton: # 좌클릭하면 좌표캡쳐 실행
            if (event.modifiers() & QtCore.Qt.ControlModifier):  # Qt::AltModifier , Qt::ShiftModifier
                self.capturePoint.emit(pt,'pass')
            else:
                self.capturePoint.emit(pt,'str')
        if button == Qt.RightButton: # 좌클릭하면 좌표캡쳐 실행
            self.capturePoint.emit(pt,'end')
        else:
            pass