from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd
    
class Create_Excel_to_Shp_Algorithm(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        excel_file = self.Qsettings.value('엑셀문서', '')
        crs = self.Qsettings.value('CRS', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    "변환 문서",
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'XLSX files (*.xlsx);;CSV files (*.csv);;XLTM files (*.xltm)',
                    defaultValue = excel_file
                )
            )
            
        self.addParameter(
            QgsProcessingParameterCrs(
                'CRS',
                '좌표계 지정',
                defaultValue=crs  # 기본값 설정 가능
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model

        """전체 하위 폴더 목록을 가져오는 로직"""
        excel_file = self.parameterAsFile(parameters, '1', context)
        crs = self.parameterAsCrs(parameters, 'CRS', context)

        self.Qsettings.setValue('엑셀문서', excel_file)
        self.Qsettings.setValue('CRS', crs.authid())

        feedback = QgsProcessingMultiStepFeedback(1, model_feedback)

        def detect_geometry_type(wkt_string: str) -> str:
            """
            주어진 WKT 문자열을 기반으로 QGIS에서 사용할 geometry 타입을 반환합니다.
            예: 'POINT', 'LINESTRING', 'MULTIPOLYGON' 등

            QGIS의 QgsVectorLayer에 사용할 수 있는 문자열 형식으로 반환됩니다.
            """
            if not wkt_string:
                return None

            wkt_upper = wkt_string.strip().upper()

            if wkt_upper.startswith("POINT"):
                return "Point"
            elif wkt_upper.startswith("LINESTRING"):
                return "LineString"
            elif wkt_upper.startswith("POLYGON"):
                return "Polygon"
            elif wkt_upper.startswith("MULTIPOINT"):
                return "MultiPoint"
            elif wkt_upper.startswith("MULTILINESTRING"):
                return "MultiLineString"
            elif wkt_upper.startswith("MULTIPOLYGON"):
                return "MultiPolygon"
            else:
                return None  # 알 수 없는 형식

        def create_shp(excel_path, save_path):

            # 엑셀 읽기
            df = pd.read_excel(excel_path)

            if 'wkt_geom' not in df.columns:
                raise ValueError("wkt_geom 필드가 없습니다.")

            geometry_type = detect_geometry_type(df['wkt_geom'].iloc[0])  # 첫 번째 행으로 판별

            # 필드 정의
            fields = QgsFields()
            fields.append(QgsField("id", QVariant.String))
            for col in df.columns:
                if col != 'wkt_geom':
                    fields.append(QgsField(col, QVariant.String))

            # LineString 레이어 생성
            layer = QgsVectorLayer(f"{geometry_type}?crs={crs.authid()}", "auto_layer", "memory")
            layer_data = layer.dataProvider()
            layer_data.addAttributes(fields)
            layer.updateFields()

            # 피처 생성
            for i, row in df.iterrows():
                geom = QgsGeometry.fromWkt(row['wkt_geom'])
                if not geom or geom.isEmpty():
                    continue

                feat = QgsFeature()
                feat.setGeometry(geom)


                # attr = [str(i)] + [str(row[col]) for col in df.columns if col != 'wkt_geom']

                # NaN 값을 None으로 변환
                attr = [str(i)]
                for col in df.columns:
                    if col == 'wkt_geom':
                        continue
                    val = row[col]
                    if pd.isna(val):
                        attr.append(None)
                    else:
                        attr.append(str(val))

                feat.setAttributes(attr)
                layer_data.addFeature(feat)

            layer.updateExtents()
            # QgsProject.instance().addMapLayer(layer)
            # SHP 저장
            result = QgsVectorFileWriter.writeAsVectorFormat(
                layer, save_path, "System", crs, "ESRI Shapefile"
            )
            # QGIS 버전에 따라 튜플 또는 정수 처리
            if isinstance(result, tuple):
                error_code = result[0]
            else:
                error_code = result

            print(error_code)
            if error_code == QgsVectorFileWriter.NoError:
                print("저장 성공:", save_path)
                return True
            else:
                print("저장 실패")
                return False

        excel_file.split('.')[0]
        output_shp = f"{excel_file.split('.')[0]}.shp"



        excel_file.split('.')[0]
        output_shp = f"{excel_file.split('.')[0]}.shp"

        create_shp(excel_file, output_shp)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}
        
        return {}
    
    def name(self):
        return 'WKT to Geometry'

    def displayName(self):
        return 'WKT 변환기'

    def group(self):
        return '포맷 변환 & 속성 결합'

    def groupId(self):
        return '포맷 변환 & 속성 결합'
    
    def shortHelpString(self):
        return "QGIS 테이블에서 복사된 'wkt_geom' 필드 값으로 객체를 재생성 합니다."
    
    def createInstance(self):
        return Create_Excel_to_Shp_Algorithm()