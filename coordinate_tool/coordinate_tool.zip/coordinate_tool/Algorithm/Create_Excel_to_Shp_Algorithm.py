from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterCrs,
    QgsProcessingParameterField,
    QgsProcessingParameterFeatureSink,
    QgsProcessing,
    QgsFeature,
    QgsGeometry,
    QgsWkbTypes,
    QgsFeatureSink
)
from PyQt5.QtCore import QSettings

class Create_Excel_to_Shp_Algorithm(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        crs = self.Qsettings.value('CRS', 'EPSG:4326')
        
        # 1. 파일 직접 지정 및 레이어 선택을 모두 지원하는 FeatureSource로 변경
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                '입력 변환 문서 또는 레이어',
                types=[QgsProcessing.TypeVector]
            )
        )
        
        self.addParameter(
            QgsProcessingParameterCrs(
                'CRS',
                '좌표계 지정',
                defaultValue=crs
            )
        )

        # 2. 불러온 파일/레이어의 필드를 동적으로 선택할 수 있도록 추가
        self.addParameter(
            QgsProcessingParameterField(
                'WKT_FIELD',
                'WKT 지오메트리 필드 선택',
                parentLayerParameterName='INPUT',
                type=QgsProcessingParameterField.Any
            )
        )

        # 3. 폴더 저장 대신 레이어 추가를 위한 FeatureSink 추가 (기본값: 임시 메모리 레이어)
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                '변환된 결과 레이어'
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)
        crs = self.parameterAsCrs(parameters, 'CRS', context)
        wkt_field_name = self.parameterAsString(parameters, 'WKT_FIELD', context)

        if source is None:
            return {}

        self.Qsettings.setValue('CRS', crs.authid())

        # WKT 필드의 인덱스 확인
        wkt_field_idx = source.fields().lookupField(wkt_field_name)
        if wkt_field_idx == -1:
            raise ValueError(f"'{wkt_field_name}' 필드를 찾을 수 없습니다.")

        # 첫 번째 유효한 WKT를 검사하여 출력 레이어의 지오메트리 타입 결정
        geom_type = QgsWkbTypes.Unknown
        for feat in source.getFeatures():
            wkt_val = feat.attribute(wkt_field_idx)
            if wkt_val:
                temp_geom = QgsGeometry.fromWkt(str(wkt_val))
                if not temp_geom.isEmpty():
                    geom_type = temp_geom.wkbType()
                    break

        # Sink(출력 목적지) 생성 (임시 레이어 처리)
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            source.fields(),
            geom_type,
            crs
        )

        if sink is None:
            return {}

        total_features = source.featureCount()
        step = 100.0 / total_features if total_features else 0

        # 데이터 변환 및 피처 추가 루프 (Pandas 없이 QGIS API로 처리)
        for current, feat in enumerate(source.getFeatures()):
            if model_feedback.isCanceled():
                break
            
            # 새 피처 생성 및 원본 속성 복사
            new_feat = QgsFeature(source.fields())
            new_feat.setAttributes(feat.attributes())
            
            # WKT 파싱 및 지오메트리 셋팅
            wkt_val = feat.attribute(wkt_field_idx)
            if wkt_val:
                geom = QgsGeometry.fromWkt(str(wkt_val))
                if geom and not geom.isEmpty():
                    new_feat.setGeometry(geom)
            
            # Sink에 피처 추가
            sink.addFeature(new_feat, QgsFeatureSink.FastInsert)
            model_feedback.setProgress(int(current * step))

        # 결과 레이어 ID 반환 (QGIS가 자동으로 맵에 로드함)
        return {'OUTPUT': dest_id}

    def name(self):
        return 'WKT to Geometry'

    def displayName(self):
        return 'WKT 변환기'

    def group(self):
        return '포맷 변환 & 속성 결합'

    def groupId(self):
        return '포맷 변환 & 속성 결합'
    
    def shortHelpString(self):
        return "선택된 레이어나 파일에서 지정한 WKT 필드 값으로 객체를 재생성하고 레이어에 추가합니다."
    
    def createInstance(self):
        return Create_Excel_to_Shp_Algorithm()