from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterField,
    QgsFields,
    QgsField,
    QgsProject,
    QgsFeature,
    QgsFeatureSink,
    QgsWkbTypes,
    QgsVectorLayer,
    QgsProcessingUtils,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSource,
    QgsProcessingException,
    QgsCoordinateReferenceSystem,
    QgsProcessingFeedback,
    QgsFeatureRequest,
    QgsSingleSymbolRenderer,
    QgsLineSymbol
)
from qgis.PyQt.QtCore import QVariant
import os, processing, math

from pyproj import Proj, transform

class Processes_vlookup_Algorithm(QgsProcessingAlgorithm):

    INPUT_TARGET = 'INPUT_TARGET'
    INPUT_KEY_FIELD = 'INPUT_KEY_FIELD'
    JOIN_TARGET = 'JOIN_TARGET'
    JOIN_KEY_FIELD = 'JOIN_KEY_FIELD'
    VALUE_FIELDS = 'VALUE_FIELDS'
    # RANGE = 'RANGE'
    UNIT = 'UNIT'
    OUTPUT = 'End'

    def initAlgorithm(self, config=None):
        # 백터 레이어 가져오기
        # self.addParameter(
        #     QgsProcessingParameterFeatureSource(
        #         self.INPUT_TARGET,
        #         '📄원본 파일',
        #         types=[QgsProcessing.TypeVector]
        #     )
        # )
        # 백터 레이어 가져오기
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_TARGET,
                '📄원본 파일',
                [QgsProcessing.TypeVector]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.INPUT_KEY_FIELD, 
                '원본 Key 필드',
                type=QgsProcessingParameterField.Any, 
                parentLayerParameterName=self.INPUT_TARGET, 
                allowMultiple=False, 
            )
        )

        # 백터 객체 가져오기
        # self.addParameter(
        #     QgsProcessingParameterFeatureSource(
        #         self.JOIN_TARGET,
        #         '📄결합 파일',
        #         types=[QgsProcessing.TypeVector]
        #     )
        # )

        # 백터 레이어 가져오기
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.JOIN_TARGET,
                '📄결합 파일',
                [QgsProcessing.TypeVector]
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.JOIN_KEY_FIELD, 
                '결합 Key 필드',
                type=QgsProcessingParameterField.Any, 
                parentLayerParameterName=self.JOIN_TARGET, 
                allowMultiple=False, 
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.VALUE_FIELDS, 
                '복사할 필드',
                type=QgsProcessingParameterField.Any, 
                parentLayerParameterName=self.JOIN_TARGET, 
                allowMultiple=True, 
            )
        )

        # 2) 단위 콤보박스 (m 또는 km)
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                '⚙️기존값이 있다면?',
                options=['덮어쓰기', '건너뛰기'],
                defaultValue=0
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        # 1) 파라미터 읽기
        feedback.pushInfo('1/8: 파라미터 읽기 시작')
        # in_src          = self.parameterAsSource(parameters, self.INPUT_TARGET, context)
        in_layer          = self.parameterAsVectorLayer(parameters, self.INPUT_TARGET, context)
        # join_src          = self.parameterAsSource(parameters, self.JOIN_TARGET, context)
        join_layer        = self.parameterAsVectorLayer(parameters, self.JOIN_TARGET, context)
        input_key_field   = self.parameterAsFields(parameters, self.INPUT_KEY_FIELD, context)[0]
        join_key_field    = self.parameterAsFields(parameters, self.JOIN_KEY_FIELD, context)[0]
        val_fields        = self.parameterAsFields(parameters, self.VALUE_FIELDS, context)
        mode              = self.parameterAsEnum(parameters, self.UNIT, context)

        feedback.pushInfo(f'입력 키: {input_key_field}, 결합 키: {join_key_field}, 값 필드: {val_fields}, 모드: ' + ('건너뛰기' if mode==1 else '덮어쓰기'))
        feedback.setProgress(5)
        if feedback.isCanceled():
            return {}
        # in_layer = QgsProcessingUtils.mapLayerFromString(in_src.sourceName(), context)
        if not in_layer:
            raise QgsProcessingException("입력 레이어를 찾을 수 없습니다.")
        
        # join_layer = QgsProcessingUtils.mapLayerFromString(join_src.sourceName(), context)
        if not join_layer:
            raise QgsProcessingException("결합 레이어를 찾을 수 없습니다.")

        in_layer_fields = len(in_layer.fields())
        features = list(in_layer.getFeatures())

        if feedback.isCanceled():
            return {}
        
        feedback.pushInfo('2/8: 원본 레이어 복사')

        feedback.setProgress(10)
        if feedback.isCanceled():
            return {}
        
        new_name = F"{in_layer.name()}_결합레이어"
        wkb_type = in_layer.wkbType()
        layer_crs = in_layer.sourceCrs()
        fields = QgsFields(in_layer.fields())
        new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
        dp_copy = new_layer.dataProvider()
        dp_copy.addAttributes(fields)
        new_layer.updateFields()

        plugin_dir = os.path.dirname(os.path.dirname(__file__))
        # 스타일을 임시 XML 파일에 저장
        temp_style_file = os.path.join(plugin_dir, 'style', 'temp_style.qml')
        in_layer.saveNamedStyle(temp_style_file)
        # 새 레이어에 스타일 XML 적용
        new_layer.loadNamedStyle(temp_style_file)

        new_layer.startEditing()
        dp = new_layer.dataProvider()
        dp.addFeatures(features)
        new_layer.updateExtents()
        if feedback.isCanceled():
            return {}
        # 2) 조인 매핑 생성
        feedback.pushInfo('3/8: 조인 매핑 생성')
        j_fields    = join_layer.fields()
        j_key_idx   = j_fields.indexOf(join_key_field)
        val_idxs_on_join = {vf: j_fields.indexOf(vf) for vf in val_fields}
        total       = len(list(join_layer.getFeatures()))
        join_feats  = join_layer.getFeatures()

        mapping = {}
        all_keys    = []
        for i, feat in enumerate(join_feats):
            key_val = feat.attribute(j_key_idx)
            if key_val is None:
                continue
            mapping[key_val] = {vf: feat.attribute(val_idxs_on_join[vf]) for vf in val_fields}
            all_keys.append(key_val)
            feedback.setProgress(10 + int(20*(i+1)/total))
            if feedback.isCanceled():
                return {}
        feedback.pushInfo(f'매핑 건수: {len(mapping)}')
        if feedback.isCanceled():
            return {}
        # 중복 키 검증
        feedback.pushInfo('4/8: 결합 레이어 중복 키 검증')
        from collections import Counter
        dup_keys = [k for k, c in Counter(all_keys).items() if c > 1]
        if dup_keys:
            raise QgsProcessingException(f'결합 레이어에 중복된 키 값이 있습니다: {dup_keys}')
        feedback.pushInfo('4/8: 결합 레이어 중복 키값이 없습니다.')
        feedback.setProgress(32)
        if feedback.isCanceled():
            return {}
        # 원본 레이어 중복 키 검증
        feedback.pushInfo('5/8: 원본 레이어 중복 키 검증')
        in_key_idx_temp = new_layer.fields().indexOf(input_key_field)
        in_feats_list   = new_layer.getFeatures()
        in_keys = []
        for f in in_feats_list:
            kv = f.attribute(in_key_idx_temp)
            if kv is not None:
                in_keys.append(kv)

            if feedback.isCanceled():
                return {}
        dup_in_keys = [k for k, c in Counter(in_keys).items() if c > 1]
        if dup_in_keys:
            raise QgsProcessingException(f'원본 레이어에 중복된 키 값이 있습니다: {dup_in_keys}')
        feedback.pushInfo('5/8: 원본 레이어 중복 키값이 없습니다.')
        feedback.setProgress(34)
        if feedback.isCanceled():
            return {}
        # 3) 입력 레이어 필드 준비
        feedback.pushInfo('6/8: 입력 필드 준비')
        in_fields = new_layer.fields()
        in_key_idx = in_fields.indexOf(input_key_field)
        if in_key_idx < 0:
            raise QgsProcessingException(f"입력 레이어에 키 필드 '{input_key_field}'가 없습니다.")
        # 누락된 값 필드 추가
        for vf in val_fields:
            if in_fields.indexOf(vf) < 0:
                fld = j_fields.field(val_idxs_on_join[vf])
                dp.addAttributes([fld])
        new_layer.updateFields()
        in_fields = new_layer.fields()
        val_idxs = {vf: in_fields.indexOf(vf) for vf in val_fields}
        feedback.setProgress(36)

        # 4) 변경사항 수집
        feedback.pushInfo('7/8: 변경사항 수집')
        if feedback.isCanceled():
            return {}
        
        changes = {}
        in_feats_temp  = list(new_layer.getFeatures())
        total_in       = len(in_feats_temp)

        for i, feat in enumerate(new_layer.getFeatures()):
            key_val = feat.attribute(in_key_idx)
            if key_val not in mapping:
                continue
            upd = {}

            for vf, new_val in mapping[key_val].items():
                idx = val_idxs[vf]
                if in_layer_fields > idx:
                    old = feat.attribute(idx)
                    if mode==1 and old not in (None,'',QVariant()):
                        continue
                upd[idx] = new_val
            if upd:
                changes[feat.id()] = upd
            feedback.setProgress(40+int(50*(i+1)/max(1,total_in)))
            if feedback.isCanceled():
                return {}
        feedback.pushInfo(f'적용 대상 개수: {len(changes)}')

        # 5) 속성 적용
        feedback.pushInfo('8/8: 속성 적용')
        if changes:
            dp.changeAttributeValues(changes)
            # Undo/redo가 가능한 편집 커맨드 사용
            # in_layer.beginEditCommand('shp to Vlookup update')
            # for fid, attrs in changes.items():
            #     for idx, val in attrs.items():
            #         in_layer.changeAttributeValue(fid, idx, val)
            # in_layer.endEditCommand()
            new_layer.triggerRepaint()
            QgsProject.instance().addMapLayer(new_layer)

        feedback.setProgress(95)

        outputs = {}
        results = {}
        silent_feedback = QgsProcessingFeedback()

        # 필드 값으로 속성 결합  
        alg_params = {
            'INPUT': join_layer,
            'FIELD': join_key_field,
            'INPUT_2': new_layer,
            'FIELD_2': input_key_field,
            'FIELDS_TO_COPY': ['__'], # 복사할 레이어
            'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
            'DISCARD_NONMATCHING': True, # 결합할 수 없는 레코드 버리기
            'PREFIX': '',
            'OUTPUT': 'memory:',
            'NON_MATCHING': 'memory:'
        }
        outputs['join'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

        non_matching = QgsProcessingUtils.mapLayerFromString(
        outputs['join']['NON_MATCHING'],
        context
        )
        matching = QgsProcessingUtils.mapLayerFromString(
        outputs['join']['OUTPUT'],
        context
        )

        if len(list(non_matching.getFeatures())) > 0:
            # 비매칭
            non_matching_name = F"비매칭"
            wkb_type = join_layer.wkbType()

            layer_crs = join_layer.sourceCrs()
            fields = QgsFields(join_layer.fields())
            non_matching_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), non_matching_name, "memory")
            # non_matching_layer.setRenderer(join_layer.renderer().clone())
            non_matching_layer.startEditing()
            non_matching_dp = non_matching_layer.dataProvider()
            non_matching_dp.addAttributes(fields)
            non_matching_layer.updateFields()

            non_matching_dp.addFeatures(non_matching.getFeatures())
            non_matching_layer.updateExtents()
            non_matching_layer.triggerRepaint()

            # results['NON_MATCHING'] = outputs['join']['NON_MATCHING'] 
            NG_result = QgsLineSymbol.createSimple({
                'color': '255,0,0',
                'width': '3'
            })
            # NG_layer = context.getMapLayer(results['NON_MATCHING'])
            non_matching_layer.setRenderer(QgsSingleSymbolRenderer(NG_result))
            # 맵 캔버스 갱신
            non_matching_layer.triggerRepaint()

            QgsProject.instance().addMapLayer(non_matching_layer)

            # 매칭
            matching_name = F"매칭"
            wkb_type = join_layer.wkbType()
            layer_crs = join_layer.sourceCrs()
            fields = QgsFields(join_layer.fields())
            matching_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), matching_name, "memory")
            # matching_layer.setRenderer(join_layer.renderer().clone())
            matching_layer.startEditing()
            matching_dp = matching_layer.dataProvider()
            matching_dp.addAttributes(fields)
            matching_layer.updateFields()

            matching_dp.addFeatures(matching.getFeatures())
            matching_layer.updateExtents()
            matching_layer.triggerRepaint()

            # results['OUTPUT'] = outputs['join']['OUTPUT']
            OK_result = QgsLineSymbol.createSimple({
                'color': '50,180,60',
                'width': '1'
            })
            # OK_layer = context.getMapLayer(results['OUTPUT'])
            matching_layer.setRenderer(QgsSingleSymbolRenderer(OK_result))
            # 맵 캔버스 갱신
            matching_layer.triggerRepaint()
            QgsProject.instance().addMapLayer(matching_layer)

        feedback.setProgress(100)
        feedback.pushInfo('완료!')

        return {}

    def name(self):
        return "Key Join"

    def displayName(self):
        return "키로 속성 붙이기"

    def group(self):
        return '포맷 변환 & 속성 결합'

    def groupId(self):
        return '포맷 변환 & 속성 결합'
    
    def shortHelpString(self):
        return "엑셀에서 vlookup과 같은 기능으로 지정된 키값으로 매칭하여 가져올 필드의 값을 원본레이어에"
    
    def createInstance(self):
        return Processes_vlookup_Algorithm()
