from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

# class ListSubfoldersAlgorithm(QgsProcessingAlgorithm):
#     INPUT_FOLDER = "INPUT_FOLDER"
#     OUTPUT = "OUTPUT"

#     def initAlgorithm(self, config=None):
#         """파라미터 설정"""
#         self.addParameter(
#             QgsProcessingParameterFile(
#                 self.INPUT_FOLDER,
#                 "폴더 선택",
#                 behavior=QgsProcessingParameterFile.Folder
#             )
#         )

#         self.addParameter(
#             QgsProcessingParameterFeatureSink(
#                 self.OUTPUT,
#                 "출력 테이블"
#             )
#         )

#     def processAlgorithm(self, parameters, context, feedback):
#         """폴더의 하위 디렉터리 목록을 가져오는 로직"""
#         input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
#         if not os.path.isdir(input_folder):
#             raise QgsProcessingException("올바른 폴더를 선택하세요.")

#         subfolders = [f for f in os.listdir(input_folder) if os.path.isdir(os.path.join(input_folder, f))]

#         feedback.pushInfo(f"총 {len(subfolders)}개의 하위 폴더를 찾았습니다.")

#         # 🔹 QGIS 출력 테이블 생성 (필드 정의)
#         fields = QgsFields()
#         fields.append(QgsField("Folder_Name", QVariant.String))

#         # 🔹 기본 CRS 설정 (EPSG:4326 사용)
#         crs = QgsCoordinateReferenceSystem("EPSG:4326")

#         # 🔹 QGIS 처리 결과를 테이블로 출력
#         sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

#         for subfolder in subfolders:
#             feature = QgsFeature()
#             feature.setAttributes([subfolder])
#             sink.addFeature(feature, QgsFeatureSink.FastInsert)

#         return {self.OUTPUT: dest_id}

#     def name(self):
#         return "list_subfolders"

#     def displayName(self):
#         return "하위 폴더 목록 가져오기"

#     def group(self):
#         return "파일 관리"

#     def groupId(self):
#         return "파일 관리"
    
#     def shortHelpString(self):
#         return "지정된 경로의 하위 모든 폴더 목록을 가져옵니다."

#     def createInstance(self):
#         return ListSubfoldersAlgorithm()

class ListAllFoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ALL',
                    '하위 모든 폴더 가져오기',
                    defaultValue = False
                )
            )
        
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """전체 하위 폴더 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        # 사용자의 체크박스 선택값 읽기
        all = self.parameterAsBool(parameters, 'ALL', context)

        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")
        
        if all:
            # 🔹 전체 폴더 목록 가져오기
            all_folders = []
            for root, dirs, _ in os.walk(input_folder):
                for directory in dirs:
                    full_path = os.path.join(root, directory)
                    all_folders.append(full_path)

            feedback.pushInfo(f"총 {len(all_folders)}개의 폴더를 찾았습니다.")

            # 🔹 QGIS 출력 테이블 생성 (필드 정의)
            fields = QgsFields()
            fields.append(QgsField("Folder_Name", QVariant.String))
            fields.append(QgsField("Folder_Path", QVariant.String))

            # 🔹 기본 CRS 설정 (EPSG:4326 사용)
            crs = QgsCoordinateReferenceSystem("EPSG:4326")

            # 🔹 QGIS 처리 결과를 테이블로 출력
            sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

            for folder in all_folders:
                feature = QgsFeature()
                feature.setAttributes([os.path.basename(folder), folder])
                sink.addFeature(feature, QgsFeatureSink.FastInsert)

        else:
            subfolders = [f for f in os.listdir(input_folder) if os.path.isdir(os.path.join(input_folder, f))]

            feedback.pushInfo(f"총 {len(subfolders)}개의 하위 폴더를 찾았습니다.")

            # 🔹 QGIS 출력 테이블 생성 (필드 정의)
            fields = QgsFields()
            fields.append(QgsField("Folder_Name", QVariant.String))
            fields.append(QgsField("Folder_Path", QVariant.String)) 

            # 🔹 기본 CRS 설정 (EPSG:4326 사용)
            crs = QgsCoordinateReferenceSystem("EPSG:4326")

            # 🔹 QGIS 처리 결과를 테이블로 출력
            sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

            for subfolder in subfolders:
                folder_path = os.path.join(input_folder, subfolder)
                feature = QgsFeature()
                feature.setAttributes([subfolder, folder_path])
                sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_all_folders"

    def displayName(self):
        return "폴더 목록 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "파일 관리"
    
    def shortHelpString(self):
        return "지정된 경로의 폴더 목록을 가져옵니다."
    
    def createInstance(self):
        return ListAllFoldersAlgorithm()
