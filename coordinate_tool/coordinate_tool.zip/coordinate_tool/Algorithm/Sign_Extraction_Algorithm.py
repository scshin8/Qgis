from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsPointXY,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd
import pyodbc
import datetime

class Sign_Extraction_Algorithm(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def initAlgorithm(self, config=None):

        def_input_Folder = self.Qsettings.value('로그폴더', '')
        def_camera_mdb = self.Qsettings.value('안전DB', '')
        def_partner_shp = self.Qsettings.value('협력사shp', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '로그 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = def_input_Folder
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    'CAMERA_MDB',
                    'CAMERA_MDB',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'mdbFile (*.mdb)',
                    defaultValue = def_camera_mdb
                )
            )

        # 좌표계 입력 항목 추가
        self.addParameter(
            QgsProcessingParameterCrs(
                'TARGET_CRS',          # 알고리즘 내부에서 값을 호출할 때 쓸 파라미터 이름
                'CAMERA_MDB 좌표계 설정',         # UI에 표시될 라벨
                defaultValue='' # 기본으로 세팅될 좌표계
            )
        )

        self.addParameter(
                QgsProcessingParameterFile(
                    '3',
                    '협력사_shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = def_partner_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ADD_TO_CANVAS',
                    '결과 레이어를 화면에 추가',
                    defaultValue = False
                )
            )
        
    def processAlgorithm(self, parameters, context, model_feedback):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model

        """전체 하위 폴더 목록을 가져오는 로직"""
        input_Folder = self.parameterAsFile(parameters, '1', context)
        camera_mdb = self.parameterAsFile(parameters, 'CAMERA_MDB', context)
        camera_crs = self.parameterAsCrs(parameters, 'TARGET_CRS', context)
        partner_shp = self.parameterAsFile(parameters, '3', context)

        if not os.path.isdir(input_Folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")
        
        """하위 폴더 목록을 가져오는 로직"""
        subfolders = [f for f in os.listdir(input_Folder) if os.path.isdir(os.path.join(input_Folder, f))]
        feedback = QgsProcessingMultiStepFeedback(10 * len(subfolders) + 13, model_feedback)

        weekNum = input_Folder.split('\\')[-1]

        feedback.pushInfo(f"안전MDB SHP파일 변환중...")
        feedback.setCurrentStep(1)

        camera_shp = self.clickedOkBTN(camera_mdb, camera_crs)
        
        feedback.pushInfo(f"안전MDB SHP파일 변환 완료")

        # for root, dirs, _ in os.walk(input_folder):
        #     for directory in dirs:
        #         full_path = os.path.join(root, directory)
        #         all_folders.append(full_path)

        feedback.pushInfo(f"총 {len(subfolders)}개의 폴더를 찾았습니다.")
        feedback.pushInfo(f"{subfolders}")

        detectResult_sign=[]
        idx = 0
        for logFolder in subfolders:
            Stepnum = 10 * idx
            results = {}
            outputs = {}

            feedback.pushInfo("-" * 80)
            feedback.pushInfo(f"로그명: {logFolder}")

            # 1_문자열 연결_로그
            # E:\Survey_Log\   로그명 앞 경로 설정 필요
            alg_params = {
                'INPUT_1': input_Folder,
                'INPUT_2': f'/{logFolder}'
            }
            outputs['1'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 3_문자열 연결_RESULT
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/RESULT'
            }
            outputs['2'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 4_디렉터리 생성
            path_to_create = outputs['2']['CONCATENATION']
            if not os.path.exists(path_to_create):
                os.makedirs(path_to_create)


            # 표지판 결과 SHP 변환============================================================================================
            # 문자열 연결_result_sign_unique.csv
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/result_sign_unique.csv'
            }
            outputs['sign'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 문자열 연결_00_Sign_Results_END.shp
            alg_params = {
                'INPUT_1': outputs['2']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}_sign.shp'
            }
            outputs['sign_shp'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 문자열 연결_00_Sign_Results_END.qml
            alg_params = {
                'INPUT_1': outputs['2']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}_sign.qml'
            }
            outputs['sign_qml'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 파일 다운로드
            alg_params = {
                'DATA': '',
                'METHOD': 0,  # GET
                'OUTPUT': outputs['sign_qml']['CONCATENATION'],
                'URL': 'https://scshin8.github.io/Qgis/style/sign/00_Sign_Results_END.qml'
            }
            outputs['Sign_down'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 테이블에서 포인트 생성
            csv_path = outputs['sign']['CONCATENATION']
            csv_uri = f'file:///{csv_path}?encoding=CP949&type=csv&detectTypes=yes&xField=x&yField=y&crs=EPSG:5179'
            csv_layer = QgsVectorLayer(csv_uri, 'csv_src', 'delimitedtext')

            alg_params = {
                'INPUT': csv_layer,
                'MFIELD': '',
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                'XFIELD': 'x',
                'YFIELD': 'y',
                'ZFIELD': '',
                'OUTPUT': 'memory:'
            }
            outputs['sign_point'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 공간 인덱스 생성_버퍼
            alg_params = {
                'INPUT': outputs['sign_point']['OUTPUT']
            }
            outputs['index'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 30_위치에 따라 속성 결합 _ 인덱스 결합
            # 협력사 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['index']['OUTPUT'],
                # 'JOIN': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/협력사_22년.shp',
                'JOIN': partner_shp,
                'JOIN_FIELDS': ['Area'],
                'METHOD': 2,  # 최대 중첩 영역을 가진 피처의 속성만 가져오기 (1대1)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['sign_point_Area'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(8 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 63_속성으로 추출 other
            alg_params = {
                'FIELD': 'Area',
                'INPUT': outputs['sign_point_Area']['OUTPUT'],
                'OPERATOR': 0,
                'VALUE': '매스코',
                'FAIL_OUTPUT': 'memory:',
                'OUTPUT': 'memory:'
            }
            outputs['sign_point_masco'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(9 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 93_필드 재작성
            alg_params = {
                'FIELDS_MAPPING': [{'expression': '"filepath"','length': 254,'name': 'filepath','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"lon"','length': 10,'name': 'lon','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"lat"','length': 10,'name': 'lat','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"index"','length': 10,'name': 'index','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"angle"','length': 10,'name': 'angle','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"distance"','length': 10,'name': 'distance','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"velocity"','length': 10,'name': 'velocity','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"class_num"','length': 10,'name': 'class_num','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"class_name"','length': 254,'name': 'class_name','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"score"','length': 10,'name': 'score','precision': 5,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"bbox_x1"','length': 10,'name': 'bbox_x1','precision': 5,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"bbox_y1"','length': 10,'name': 'bbox_y1','precision': 5,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"bbox_x2"','length': 10,'name': 'bbox_x2','precision': 5,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"bbox_y2"','length': 10,'name': 'bbox_y2','precision': 5,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"x"','length': 20,'name': 'x','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"y"','length': 20,'name': 'y','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"box_area"','length': 10,'name': 'box_area','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"box_ratio"','length': 10,'name': 'box_ratio','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"brightness"','length': 10,'name': 'brightness','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                    {'expression': '"ocr"','length': 254,'name': 'ocr','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"cluster_id"','length': 254,'name': 'cluster_id','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"Area"','length': 10,'name': 'Area','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],

                'INPUT': outputs['sign_point_masco']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['fields'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10 + Stepnum)
            if feedback.isCanceled():
                return {}

            layer_sign = None
            # ----------------- 수정된 부분 시작 -----------------
            # 1. 출력된 메모리 레이어의 ID(경로)를 가져옵니다.
            layer_sign_id = outputs['fields']['OUTPUT']

            # 2. ID를 통해 실제 QgsVectorLayer 객체로 변환합니다.
            layer_sign = QgsProcessingUtils.mapLayerFromString(layer_sign_id, context)

            # 3. 객체에 원하는 레이어 이름을 지정합니다. (예: 반복문의 idx 활용)
            # 신선비님이 원하시는 이름 규칙으로 변경하시면 됩니다.
            layer_sign.setName(f'{logFolder}')

            detectResult_sign.append(layer_sign)

            # 벡터 피처를 파일로 저장
            alg_params = {
                'DATASOURCE_OPTIONS': '',
                'INPUT': outputs['fields']['OUTPUT'],
                'LAYER_NAME': '',
                'LAYER_OPTIONS': '',
                'OUTPUT': outputs['sign_shp']['CONCATENATION'],
            }
            outputs['Sign_END1'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10 + Stepnum)
            if feedback.isCanceled():
                return {}

            feedback.pushInfo("완료")
            idx += 1

        feedback.pushInfo("-" * 80)
        feedback.pushInfo(f"파일 병합 및 제외 대상 삭제")

        # 결과 병합 후 레이어 경로
        result_path = f'{input_Folder}/{weekNum}'

        # 표지판 스타일 다운로드
        alg_params = {
            'DATA': '',
            'METHOD': 0,  # GET
            'OUTPUT': f'{result_path}_sign.qml',
            'URL': 'https://scshin8.github.io/Qgis/style/sign/00_Sign_Results_END.qml'
        }
        outputs['sign_end_qml'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 표지판 스타일 다운로드
        alg_params = {
            'DATA': '',
            'METHOD': 0,  # GET
            'OUTPUT': f'{result_path}_sign_END.qml',
            'URL': 'https://scshin8.github.io/Qgis/style/sign/00_Sign_Results_END.qml'
        }
        outputs['sign_end_qml'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 표지판 레이어 병합
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'LAYERS': detectResult_sign,
            'OUTPUT': 'memory:',
        }
        outputs['sign_merge'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 표현식으로 추출 추월금지에서 속도표지판 삭제
        alg_params = {
            'EXPRESSION': '"class_num" = \'4\' and (to_int("ocr") * 1 = to_int("ocr"))',
            'INPUT': outputs['sign_merge']['OUTPUT'],
            'OUTPUT': 'memory:',
            'FAIL_OUTPUT': 'memory:',
        }
        outputs['sign_merge_del1'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 표현식으로 추출 정지에서 속도표지판, 진입금지, 주정차금지 삭제
        alg_params = {
            'EXPRESSION': '"class_num" = \'10\' and not regexp_match(lower("ocr"), \'[stop]{3}|[정지]{2}\')',
            'INPUT': outputs['sign_merge_del1']['FAIL_OUTPUT'],
            'OUTPUT': 'memory:',
            'FAIL_OUTPUT': 'memory:',
        }
        outputs['sign_merge_del2'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 표현식으로 추출 양보에서 천천히 삭제
        alg_params = {
            'EXPRESSION': '"class_num" = \'5\' and (regexp_match(lower("ocr"), \'[천전정중친진선신건히]{2}|주정|금지|공사|구간|slo|low\') and not regexp_match(lower("ocr"), \'yielo|yield|ielo|ield|양보|양 보\') or to_int("ocr") * 1 = to_int("ocr"))',
            'INPUT': outputs['sign_merge_del2']['FAIL_OUTPUT'],
            'OUTPUT': 'memory:',
            'FAIL_OUTPUT': 'memory:',
        }
        outputs['sign_merge_del3'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 표현식으로 추출 우선도로에서 위험 삭제
        alg_params = {
            'EXPRESSION': '"class_num" = \'48\' and "ocr" <> \'\'',
            'INPUT': outputs['sign_merge_del3']['FAIL_OUTPUT'],
            'OUTPUT': 'memory:',
            'FAIL_OUTPUT': 'memory:'
        }
        outputs['sign_merge_del4'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16 + Stepnum) 
        if feedback.isCanceled():
            return {}
        
        # 벡터 피처를 파일로 저장
        alg_params = {
            'DATASOURCE_OPTIONS': '',
            'INPUT': outputs['sign_merge_del4']['FAIL_OUTPUT'],
            'LAYER_NAME': '',
            'LAYER_OPTIONS': '',
            'OUTPUT': f'{result_path}_sign.shp',
        }
        outputs['Sign_END2'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17 + Stepnum)
        if feedback.isCanceled():
            return {}

        feedback.pushInfo("파일 병합 및 제외 대상 삭제 완료")
        feedback.pushInfo("-" * 80)
        feedback.pushInfo("안전DB 비매칭 추출")

        # 자동 증가 필드 키값 생성
        alg_params = {
            'FIELD_NAME': 'AUTO',
            'GROUP_FIELDS': [''],
            'INPUT': outputs['Sign_END2']['OUTPUT'],
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT':  'memory:'
        }
        outputs['addauto'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 최근접 거리를 이용하여 속성을 결합
        # 카메라DB 결합
        alg_params = {
            'DISCARD_NONMATCHING': False,                           # 결합할 수 없는 레코드 버리기  True False
            'FIELDS_TO_COPY': ['Cam_ID','Cam_Kind','Angle_Tune'],   # 복사할 레이어2 필드 (모든 필드를 복사하려면 비워두기)
            'INPUT': outputs['addauto']['OUTPUT'],                  # 입력레이어1 (원본 레이어)
            'INPUT_2': camera_shp,                                  # 입력레이어2 (가져올 레이어)
            'MAX_DISTANCE': 30,                                     # 최장 인접 거리 None
            'NEIGHBORS': 5,                                         # 최대 인접 수 (최소1)
            'PREFIX': '',                                           # 결합된 필드 접두사
            'OUTPUT': 'memory:',                                    # 결합 레이어
            'NON_MATCHING': 'memory:'                               # 첫 번째 레이어에서 결합할 수 없는 객체
        }
        outputs['join'] = processing.run('native:joinbynearest', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(19 + Stepnum)
        if feedback.isCanceled():
            return {}

        #필드계산기 Cam_Kind 수정
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'Cam_Kind',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': 'if("Cam_Kind" = 50, 5, if("Cam_Kind" = 51, 10, if("Cam_Kind" = 52, 48, if("Cam_Kind" = 53, 4, 0))))',
            'INPUT': outputs['join']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['fieldcalculator1'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(20 + Stepnum)
        if feedback.isCanceled():
            return {}

        #필드계산기 인접 각도 추출
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'agl',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': 'with_variable(\'angle_deg\', ("angle" - "Angle_Tune" ) % 360, if(@angle_deg < 0, @angle_deg + 360 , @angle_deg))',
            'INPUT': outputs['fieldcalculator1']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['fieldcalculator2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(20 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 표현식으로 추출
        alg_params = {
            'EXPRESSION': ' "agl" >= 165 and "agl" <= 195 and  "class_num" = "Cam_Kind" ',
            'INPUT': outputs['fieldcalculator2']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['extract'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(21 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 필드 값으로 속성 결합
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'AUTO',
            'FIELDS_TO_COPY': ['1'],
            'FIELD_2': 'AUTO',
            'INPUT': outputs['addauto']['OUTPUT'],
            'INPUT_2': outputs['extract']['OUTPUT'],
            'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
            'PREFIX': '',
            'OUTPUT': 'memory:',
            'NON_MATCHING': 'memory:'
        }
        outputs['jointable'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(22 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 필드 삭제
        alg_params = {
            'COLUMN': ['AUTO'],
            'INPUT': outputs['jointable']['NON_MATCHING'],
            'OUTPUT': f'{result_path}_sign_END.shp'
        }
        outputs['delete'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(23 + Stepnum)
        if feedback.isCanceled():
            return {}

        # 사용자의 체크박스 선택값 읽기
        add_to_canvas = self.parameterAsBool(parameters, 'ADD_TO_CANVAS', context)
        # 조건에 따라 레이어 로드
        if add_to_canvas and os.path.exists(f'{result_path}_sign_END.shp'):
            result_layer = QgsVectorLayer(f'{result_path}_sign_END.shp', weekNum, 'ogr')
            if result_layer.isValid():
                # 스타일 적용 (선택)
                qml_path = f'{input_Folder}/{weekNum}_sign_END.qml'
                if os.path.exists(qml_path):
                    result_layer.loadNamedStyle(qml_path)
                QgsProject.instance().addMapLayer(result_layer)
                self._setValue(input_Folder, partner_shp, camera_mdb)
                return {}
            else:
                feedback.reportError('결과 레이어가 유효하지 않습니다.')
                self._setValue(input_Folder, partner_shp, camera_mdb)
                return {}
        else:
            self._setValue(input_Folder, partner_shp, camera_mdb)
            return {}
        
    def _setValue(self,input_Folder, partner_shp, camera_mdb):
        self.Qsettings.setValue('로그폴더', input_Folder)
        self.Qsettings.setValue('안전DB', camera_mdb)
        self.Qsettings.setValue('협력사shp', partner_shp)

    def clickedOkBTN(self, camera_mdb, camera_crs):
        table_name = 'Camera'
        self.OpenFile(camera_mdb)
        self.mdbName, ext = os.path.splitext(os.path.basename(camera_mdb))
        query = "*"      
        self.ReadDatas(query, table_name)
        self.fields = QgsFields()
        self.GetColumns(table_name)
        self.lon_index = 10
        self.lat_index = 11

        self.layer = QgsVectorLayer(f"Point?crs={camera_crs.authid()}", f'{self.mdbName}_{table_name}', "memory")
        self.provider = self.layer.dataProvider()

        for col in self.columns:
            qvariant_type = self.convert_type_code_to_qvariant(col[1])
            self.fields.append(QgsField(col[0], qvariant_type))

        self.provider.addAttributes(self.fields)
        self.layer.updateFields()
        worker_layer = self.run()
        # QgsProject.instance().addMapLayer(worker_layer)
        return worker_layer

    def run(self):
        features = []
        count = 0
        total = len(self.datas)
        if total == 0:
            return

        for row in self.datas:

            new_feature = QgsFeature()
            new_feature.setFields(self.fields)

            try:
                x = row[self.lon_index] if 0 <= self.lon_index < len(row) else 0
                y = row[self.lat_index] if 0 <= self.lat_index < len(row) else 0

                # 좌표 값이 None / 빈 문자열 / 이상한 문자열인 경우 대비
                if x in (None, '') or y in (None, ''):
                    # 필요하면 continue로 그 행만 스킵하거나, 0,0으로 처리
                    # 여기서는 그냥 건너뛰는 예
                    continue
                
                point = QgsPointXY(float(x), float(y))
                geom = QgsGeometry.fromPointXY(point)
                new_feature.setGeometry(geom)

            except Exception as e:
                # 어떤 파일/행에서 깨지는지 디버그용 로그
                print(f"좌표 변환 오류: {e}, row={row}")
                continue  # 문제 행만 건너뛰고 계속

            attributes = []
            for i, value in enumerate(row):
                qvariant_type = self.fields.field(i).type()
                if qvariant_type == QVariant.DateTime and value is not None:
                    value = datetime.datetime.isoformat(value)
                attributes.append(value)
            new_feature.setAttributes(attributes)
            features.append(new_feature)

            count += 1

        self.provider.addFeatures(features)
        self.layer.updateExtents()
        return self.layer
    
    def convert_type_code_to_qvariant(self, type_code):
        type_code_to_qvariant = {
            int: QVariant.Int,
            str: QVariant.String,
            float: QVariant.Double,
            bool: QVariant.Bool,
            bytes: QVariant.ByteArray,
            datetime.date: QVariant.Date,
            datetime.time: QVariant.Time,
            datetime.datetime: QVariant.DateTime
        }
        return type_code_to_qvariant.get(type_code, QVariant.Invalid)
    
    # odbc 파일 오픈
    def OpenFile(self, filePath):
        self.con_string = r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ='
        self.con_string += filePath + r';'
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        # 테이블명 얻기
        self.tableNames = [x[2] for x in self.cursor.tables().fetchall() if x[3] == 'TABLE']
        self.connect.close()

    def GetColumns(self, tableName):
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        
        string = ("SELECT * FROM {}").format(tableName)
        self.cursor.execute(string)
        self.columns = [column for column in self.cursor.description]        
        self.connect.close()

    # 해당 해당 테이블에 쿼리문으로 Data 읽기
    def ReadDatas(self, query, table):
        self.connect = pyodbc.connect(self.con_string)
        self.cursor = self.connect.cursor()
        string = "SELECT {} FROM {} WHERE Cam_Kind IN (50, 51, 52, 53)".format(query, table)
        # string = ("SELECT {} FROM {}").format(query, table)
        self.cursor.execute(string)

        rows = self.cursor.fetchall()

        # ✅ 매번 “새 리스트 객체”를 만들어서 self.datas에 할당
        self.datas = list(rows)

        # camKindSet도 마찬가지로 새 set으로 만들기
        self.camKindSet = {row[0] for row in rows}

        self.connect.close()

    def name(self):
        return '영상인식 표지판 추출'

    def displayName(self):
        return '영상인식 표지판 추출'

    def group(self):
        return '영상인식'

    def groupId(self):
        return '영상인식'

    def shortHelpString(self):
        return "영상인식된 표지판 결과를 시각화 하며 기반영된 안전DB과 매칭하여 이상없음 또는 점검 대상을 추출합니다."

    def createInstance(self):
        return Sign_Extraction_Algorithm()
