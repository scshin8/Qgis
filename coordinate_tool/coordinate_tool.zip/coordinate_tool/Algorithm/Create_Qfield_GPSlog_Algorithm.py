from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

class Create_Qfield_GPSlog_Algorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 입력 파라미터 ID 정의
    PARAM_LOG_NAME = "LOG_NAME"
    PARAM_LOG = "LOG"
    PARAM_USER_NAME = "USER_NAME"
    PARAM_STYLE_FILE = 'STYLE_FILE'

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        logName = self.Qsettings.value('logName', '')
        log = self.Qsettings.value('log', '')
        userName = self.Qsettings.value('userName', '')

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LOG_NAME,
                "로그명",
                defaultValue=logName  # 기본값 설정
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LOG,
                "로그",
                defaultValue=log  # 기본값 설정
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_USER_NAME,
                "조사자",
                defaultValue=userName  # 기본값 설정
            )
        )

        # self.addParameter(
        #     QgsProcessingParameterFile(
        #         self.PARAM_STYLE_FILE,
        #         "QML 스타일 파일 (선택)",
        #         extension="qml",
        #         optional=True
        #     )
        # )

    def processAlgorithm(self, parameters, context, feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 입력된 값 가져오기기
        log_name = self.parameterAsString(parameters, self.PARAM_LOG_NAME, context)
        log = self.parameterAsString(parameters, self.PARAM_LOG, context)
        user_name = self.parameterAsString(parameters, self.PARAM_USER_NAME, context)
        # style_file = self.parameterAsString(parameters, self.PARAM_STYLE_FILE, context)

        # 바탕화면 경로로
        desktop_path = os.path.join(os.path.expanduser("~"), "desktop")
        date = '20'+log[2:8]

        # 로그 폴더 경로
        save_dir = f"{desktop_path}/survey/{log_name}/로그/{date}"
        # 로그 저장 경로
        file_path = os.path.join(save_dir, f'{log}.shp')

        # 4326좌표계
        crs = QgsCoordinateReferenceSystem("EPSG:4326")  # 좌표계 설정
        
        #로그 폴더 존재 유무 확인 > 없다면 생성성
        if not os.path.exists(save_dir) and not os.path.exists(file_path):
            os.makedirs(save_dir)  # 폴더 생성
        
            # Route 타일맵 추가
            RouteMap = "RouteMap Basic"
            layers = QgsProject.instance().mapLayersByName(RouteMap) # 레이어 목록중 RouteMap 레이어 탐색
            if layers:
                raster_layer = layers[0]   # 레이어가 있다면 
            else:
                url = "type=xyz&url=https://tiles.routo.com/tile/roadmap_image_basic/v1/{z}/{x}/{y}.webp"
                # XYZ 타일 레이어 생성
                raster_layer = QgsRasterLayer(url, RouteMap, "wms")  # 또는 "xyz"도 가능
                # 레이어가 유효한지 확인 후 프로젝트에 추가
                if raster_layer.isValid():
                    QgsProject.instance().addMapLayer(raster_layer)
                else:
                    feedback.pushWarning("RouteMap을을 추가할 수 없습니다. URL 또는 형식을 확인하세요.")

            self.Qsettings.setValue('logName', log_name)
            self.Qsettings.setValue('log', log)
            self.Qsettings.setValue('userName', user_name)

            new_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", log, "memory")
            provider = new_layer.dataProvider()

            # 추가할 필드와 기본값 정의
            fields_and_expressions = [
                ("log_name","@layer_name", QVariant.String),
                ("user_name",f"'{user_name}'", QVariant.String),

                ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
                ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
                
                ("speed", "round((@position_ground_speed * 3600) / 1000, 0)", QVariant.Int),
                ("angle", "round(@position_direction,0)", QVariant.Int),
                ("x", "x(@position_coordinate)", QVariant.Double),
                ("y", "y(@position_coordinate)", QVariant.Double),
                ("z", "z(@position_coordinate)", QVariant.Double),

                ("grs_lon", 'round("x" * 360000, 0)', QVariant.Int),
                ("grs_lat", 'round("y" * 360000, 0)', QVariant.Int),

                ("map_id", '''
                floor(((floor(round((("grs_lon" - 44617500) / 45000), 0)) - 1) / 8) + 2)
                ||
                floor(((floor(round((("grs_lat" - 11865000) / 30000), 0)) - 1) / 8) + 1)
                ||
                floor(floor((round((("grs_lon" - 44617500) / 45000), 0)) + 8) - (ceil(floor(round((("begrs_lon_lon" - 44617500) / 45000), 0)) / 8) * 8))
                ||
                floor(floor((round((("grs_lat" - 11865000) / 30000), 0)) + 8) - (ceil(floor(round((("grs_lat" - 11865000) / 30000), 0)) / 8) * 8))
                ''', QVariant.Int),

                # ("bes_x", 'x(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
                # ("bes_y", 'y(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
                # ("bes_lon", 'round("bes_x" * 360000,0)', QVariant.Int),
                # ("bes_lat", 'round("bes_y" * 360000,0)', QVariant.Int),
                # ("bessel", '''
                # "map_id"||\'(000000)(\'||
                # floor("bes_x")||'.'||
                # floor(("bes_x" - floor("bes_x")) * 60)||'.'||
                # round(((("bes_x" - floor("bes_x")) * 60) - floor(("bes_x" - floor("bes_x")) * 60)) * 60, 2)
                # ||'/'||
                # floor("bes_y")||'.'||
                # floor(("bes_y" - floor("bes_y")) * 60)||'.'||
                # round(((("bes_y" - floor("bes_y")) * 60) - floor(("bes_y" - floor("bes_y")) * 60)) * 60, 2)||')'
                # ''', QVariant.String),

                ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
                ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
                
                # ("username", "@cloud_username", QVariant.String),
                # ("useremail", "@cloud_useremail", QVariant.String),
                ("source", "@position_source_name", QVariant.String),
                # ("quality_description", "@position_quality_description", QVariant.String),
                ("h_acc", "@position_horizontal_accuracy", QVariant.Double),
                ("v_acc", "@position_vertical_accuracy", QVariant.Double),
                ("3d_acc", "@position_3d_accuracy", QVariant.Double),
                # ("orientation", "@position_orientation", QVariant.Double),
                # ("magnetic_variation", "@position_magnetic_variation", QVariant.Double),
                # ("vertical_speed", "@position_vertical_speed", QVariant.Double),
                # ("averaged_count", "@position_averaged_count", QVariant.Int),
                # ("pdop", "@position_pdop", QVariant.Double),
                # ("hdop", "@position_hdop", QVariant.Double),
                # ("vdop", "@position_vdop", QVariant.Double),
                ("number_of", "@position_number_of_used_satellites", QVariant.Int),
                # ("used_satellites", "@position_used_satellites", QVariant.String),
                # ("fix_status_description", "@position_fix_status_description", QVariant.String),
                # ("fix_mode", "@position_fix_mode", QVariant.String),
                ("flag", "@visible_flag", QVariant.String)
            ]

            # 편집 모드 시작
            new_layer.startEditing()

            # 필드 추가
            for field_name, expr, field_type in fields_and_expressions:
                provider.addAttributes([QgsField(field_name, field_type)])
            new_layer.updateFields()

            # ✅ 스타일 적용
            style_file = os.path.dirname(__file__) + '/style/Qfield_LogStyle.qml'
            if style_file and os.path.exists(style_file):
                applied = new_layer.loadNamedStyle(style_file)
                if applied:
                    feedback.pushInfo(f'레이어 "{log}"에 스타일 적용 완료: {style_file}')
                else:
                    feedback.pushWarning(f'레이어 "{log}" 스타일 적용 실패')
            else:
                feedback.pushWarning("스타일 파일이 제공되지 않았거나 찾을 수 없습니다.")

            # ✅ 기본값(표현식) 설정
            for field_name, expr, field_type in fields_and_expressions:
                idx = new_layer.fields().indexOf(field_name)
                if idx != -1:
                    default = QgsDefaultValue(expr, True)
                    new_layer.setDefaultValueDefinition(idx, default)

            # 스키마 갱신 및 저장
            new_layer.updateFields()
            new_layer.commitChanges()

            file_path = os.path.join(save_dir, f'{log}.shp')  # 파일 경로 설정
            QgsVectorFileWriter.writeAsVectorFormat(new_layer, file_path, "System", new_layer.crs(), "ESRI Shapefile")

            new_qml = os.path.join(save_dir, f'{log}.qml')
            new_layer.saveNamedStyle(new_qml)

            feedback.pushInfo(f'신규 레이어 "{log}" 생성 완료')

            file_path = f"{save_dir}/{log}.shp"  # 불러올 파일의 경로
            layer = QgsVectorLayer(file_path, f"{log}", "ogr")

            pjt = QgsProject.instance()
            pjt.addMapLayer(layer, True)

            # 화면 이동동
            canvas_crs = iface.mapCanvas().mapSettings().destinationCrs()
            transform = QgsCoordinateTransform(crs, canvas_crs, QgsProject.instance())
            x, y = transform.transform(float(128.05235384404628), float(36.241891424775254))
            rect = QgsRectangle(x, y, x, y)
            iface.mapCanvas().setExtent(rect)

            # 축척 1:2000000 로 설정
            iface.mapCanvas().zoomScale(2000000)

            # Qfield 플로그인 복사
            survey_file = os.path.dirname(__file__) + '/style/ONEMAN_SURVEY.qml'
            output_file = f"{save_dir}/{date}_log.qml"
            shutil.copy(survey_file, output_file)

            # 캔버스 새로고침
            iface.mapCanvas().refresh()

            # 현재 캔버스 프로젝트 저장
            project_path = f"{save_dir}/{date}_log.qgz"
            QgsProject.instance().write(project_path)

        else:
            feedback.pushWarning(f'기존파일이 존재합니다.')

        return {}

    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "create_log_layer"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield Log 생성"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return Create_Qfield_GPSlog_Algorithm()