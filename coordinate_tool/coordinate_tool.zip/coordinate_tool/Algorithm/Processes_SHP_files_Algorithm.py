# -*- coding: utf-8 -*-
"""
QGIS Processing Algorithm: SHP 파일 처리 및 압축
입력: 현재 날짜 기준 월과 주차 계산 (예: 2월2주)
출력: 지정된 폴더에 처리된 SHP 파일 및 압축 파일 생성
"""

import os
import zipfile
import shutil
import math
from datetime import datetime, timedelta

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProcessingAlgorithm,
                       QgsProcessingParameterString,
                       QgsProcessingFeatureSourceDefinition,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingFeedback,
                       QgsProcessingParameterFile,
                       QgsProcessingParameterEnum,
                       QgsCoordinateReferenceSystem)
from PyQt5.QtCore import QSettings

import processing

class Processes_SHP_files_Algorithm(QgsProcessingAlgorithm):
    """
    이 알고리즘은 지정된 폴더 내에서 SHP 파일을 처리(필드 계산, M/Z 값 삭제 등)한 후,
    결과 파일들을 압축하여 저장하는 기능을 수행합니다.
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    PARAM_WEEK  = 'WEEK'
    BASE_DIR    = 'BASE_DIR'
    BESSEL_DIR  = 'BESSEL_DIR'
    GRS_DIR     = 'GRS_DIR'
    ZIP_DIR     = 'ZIP_DIR'
    UNIT        = 'UNIT'

    def tr(self, string):
        return QCoreApplication.translate("ShpFileSaveZipAlgorithm", string)

    def createInstance(self):
        return Processes_SHP_files_Algorithm()

    def name(self):
        return "shpfile_save_zip"

    def displayName(self):
        return self.tr("SHP 파일 저장 및 ZIP 압축")

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "파일 관리"

    def shortHelpString(self):
        return self.tr("입력된 주(week) 값을 기반으로 SHP 파일을 처리하고, 결과를 압축 파일로 저장합니다.")

    def initAlgorithm(self, config=None):
        # 현재 날짜 기준 월과 주차 계산
        shifted_date = datetime.now() - timedelta(days=7)
        month = shifted_date.month
        # 요일 인덱스: 월요일=0, 일요일=6
        weekday_index = shifted_date.weekday()
        # 요일만큼 빼서 그 주의 월요일 날짜를 구함
        start_of_week = shifted_date - timedelta(days=weekday_index)
        # 그 월요일 날짜의 일(day)을 7로 나눠서 주차 계산
        week_number = math.ceil(start_of_week.day / 7)
        default_week_value = f"{month}월{week_number}주"

        plugin_dir = os.path.dirname(os.path.dirname(__file__))
        self.cpg_file = os.path.join(plugin_dir, 'style', 'cpg_file.cpg')

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_WEEK,
                self.tr("주차 (예: 1월2주)"),
                defaultValue=f'{default_week_value}'
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                '⚙️변환 선택',
                options=['베셀 → GRS 변환', '베셀 변환', 'GRS 변환'],
                defaultValue=0
            )
        )

        base_dir = self.Qsettings.value('base_dir', '')
        self.addParameter(
            QgsProcessingParameterFile(
                self.BASE_DIR,
                "📁 Shp 폴더 선택",
                behavior=QgsProcessingParameterFile.Folder,
                defaultValue = base_dir
            )
        )

        besShpFolder = self.Qsettings.value('besShpFolder', '')
        self.addParameter(
            QgsProcessingParameterFile(
                self.BESSEL_DIR,
                "Bessel Shp 폴더 선택",
                behavior=QgsProcessingParameterFile.Folder,
                defaultValue = besShpFolder
            )
        )

        grsShpFolder = self.Qsettings.value('grsShpFolder', '')
        self.addParameter(
            QgsProcessingParameterFile(
                self.GRS_DIR,
                "GRS Shp 폴더 선택",
                behavior=QgsProcessingParameterFile.Folder,
                defaultValue = grsShpFolder
            )
        )

        zipFolder = self.Qsettings.value('zipFolder', '')
        self.addParameter(
            QgsProcessingParameterFile(
                self.ZIP_DIR,
                "ZIP 업로드 폴더 선택",
                behavior=QgsProcessingParameterFile.Folder,
                defaultValue = zipFolder,
                optional=True
            )
        )

    def define_projection(self, input_layer, crs, context=None, feedback=None):
        params = {'CRS': QgsCoordinateReferenceSystem(crs), 'INPUT': input_layer}
        return processing.run('qgis:definecurrentprojection', params, context=context, feedback=QgsProcessingFeedback(), is_child_algorithm=True)

    def processAlgorithm(self, parameters, context, feedback):

        # 사용자 입력 값
        w               = self.parameterAsString(parameters, self.PARAM_WEEK, context)
        base_dir        = self.parameterAsString(parameters, self.BASE_DIR, context)
        besShpFolder    = self.parameterAsString(parameters, self.BESSEL_DIR, context)
        grsShpFolder    = self.parameterAsString(parameters, self.GRS_DIR, context)
        zipFolder       = self.parameterAsString(parameters, self.ZIP_DIR, context)
        if zipFolder:
            zip_folder  = os.path.join(zipFolder, w)
        mode            = self.parameterAsEnum(parameters, self.UNIT, context)

        self.Qsettings.setValue('base_dir', base_dir)
        self.Qsettings.setValue('besShpFolder', besShpFolder)
        self.Qsettings.setValue('grsShpFolder', grsShpFolder)
        self.Qsettings.setValue('zipFolder', zipFolder)

        feedback.pushInfo("입력된 주(week) 값: " + w)

        silent_feedback = QgsProcessingFeedback()

        # zip 폴더 생성
        if zipFolder and not os.path.exists(zip_folder):
            os.makedirs(zip_folder)
            feedback.pushInfo("ZIP 폴더 생성: " + zip_folder)

        folder_paths = [os.path.join(base_dir, w, "도로속성검수,레인정보"),
                        os.path.join(base_dir, w, "도로종별및표시레벨,회전규제,시변"),
                        os.path.join(base_dir, w, "도로종별및표시레벨,회전규제,시변"),
                        os.path.join(base_dir, w, "상용차구조화")]

        old_names = ['NodeShape', 'LinkShape', 'NodeShape', 'LinkShape']
        new_names = ['Node', 'LinkShape', 'NodeShape', 'cv_LinkShape']
        cv_files = ['cv_dt_bes', 'cv_link_bes']

        # prj = os.path.join(db_folder, "bes.prj")

        dbf_files = ['3DInfo', 'CityHigh', 'Common', 'HighWay', 'LaneInfo']
        Temp_files = ['TempTimeNode.dbf', 'TempTimeTrafficInfo.dbf']

        field_names = ['MN_ID', 'ML_ID', 'MN_ID', 'ML_ID']
        Expressions = [ '"Map_Id" || \'_\' || "Node_Id"',
                        '"Map_Id" || \'_\' || "Link_Id"',
                        '"Map_Id" || \'_\' || "Node_Id"',
                        '"Map_Id" || \'_\' || "Link_Id"' ]

        NodeShp = True
        LinkShp = True

        if mode==0 or mode==1:

            # 1. 각 폴더별 SHP 파일 처리 및 필드 계산
            for i in range(4):
                old_name = old_names[i]
                new_name = new_names[i]
                field_name = field_names[i]
                Expression = Expressions[i]

                folder_path = folder_paths[i]
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
                    feedback.pushInfo("생성된 폴더: " + folder_path)

                file_name = None
                # besShpFolder 내에서 파일 검색
                for file in os.listdir(besShpFolder):
                    if old_name in file and file.endswith(".shp"):
                        filename = os.path.splitext(file)[0]
                        cpg = os.path.join(besShpFolder, filename + '.cpg')
                        shutil.copy(self.cpg_file, cpg)

                        file_name = file
                        if len(file_name) > 15:
                            if old_name == 'NodeShape':
                                if NodeShp:
                                    NodeShp = False
                                    break
                                else:
                                    NodeShp = True
                            if old_name == 'LinkShape':
                                if LinkShp:
                                    LinkShp = False
                                    break
                                else:
                                    LinkShp = True

                if not file_name:
                    feedback.pushInfo(f"📢파일을 찾을 수 없습니다: {old_name}")
                    continue

                input_file = os.path.join(besShpFolder, file_name)
                output_file = os.path.join(folder_path, new_name + '.shp')
                # output_prj = os.path.join(folder_path, new_name + '.prj')

                # 입력 데이터를 위한 QgsProcessingFeatureSourceDefinition 생성
                input_layer = QgsProcessingFeatureSourceDefinition(input_file, selectedFeaturesOnly=False)

                # M/Z 값 삭제
                drop_mz_params = {
                    'DROP_M_VALUES': True,
                    'DROP_Z_VALUES': True,
                    'INPUT': input_layer,
                    'OUTPUT': 'memory:'
                }
                drop_mz_result = processing.run('native:dropmzvalues', drop_mz_params,
                                                context=context, feedback=silent_feedback)

                # Shapefile 좌표계 정의
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('USER:100000'),
                    'INPUT': drop_mz_result['OUTPUT']
                }
                projection = processing.run('qgis:definecurrentprojection', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

                # 필드 계산 실행
                alg_params = {
                    'FIELD_LENGTH': 30,
                    'FIELD_NAME': field_name,
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,
                    'FORMULA': Expression,
                    'INPUT': projection['INPUT'],
                    'OUTPUT': output_file
                }
                processing.run('native:fieldcalculator', alg_params,
                            context=context, feedback=silent_feedback)
                
                # shutil.copy(prj, output_prj)
                feedback.pushInfo(f"💾 {field_name} 생성 및 저장: {output_file}")

            # 2. 추가 파일 처리 및 압축
            for i in range(4):
                folder_path = folder_paths[i]

                if feedback.isCanceled():
                    return {}
                
                if i == 0:
                    # dbf 파일 저장
                    for dbf_file in dbf_files:
                        file_name = None

                        if feedback.isCanceled():
                            return {}
                        
                        for file in os.listdir(besShpFolder):
                            if dbf_file in file:
                                file_name = file
                                feedback.pushInfo(f"{file_name} -> {dbf_file}")
                                break

                            if feedback.isCanceled():
                                return {}
                            
                        if file_name:
                            input_file = os.path.join(besShpFolder, file_name)
                            output_file = os.path.join(folder_path, dbf_file + '.dbf')
                            shutil.copy(input_file, output_file)
                            feedback.pushInfo("dbf_file 저장: " + output_file)

                    files_to_zips = [['Node.cpg', 'Node.dbf', 'Node.prj', 'Node.shp', 'Node.shx'],
                                    ['LaneInfo.dbf', '3DInfo.dbf'],
                                    ['CityHigh.dbf', 'HighWay.dbf', 'Common.dbf']]
                    zip_filenames = ['Node.zip', '레인정보.zip', '이미지정보.zip']

                    if zipFolder:
                        for ii in range(3):
                            zip_filename = zip_filenames[ii]
                            files_to_zip = files_to_zips[ii]
                            zip_file_path = os.path.join(zip_folder, zip_filename)

                            if feedback.isCanceled():
                                return {}
                            
                            with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                                for file in files_to_zip:
                                    file_path = os.path.join(folder_path, file)
                                    if os.path.exists(file_path):
                                        zipf.write(file_path, arcname=file)

                                    if feedback.isCanceled():
                                        return {}

                            feedback.pushInfo(f"파일 압축 완료: {zip_file_path}")

                if i == 1:
                    # Temp 파일 저장
                    for Temp_file in Temp_files:
                        file_name = None

                        if feedback.isCanceled():
                            return {}
                        
                        for file in os.listdir(besShpFolder):

                            if feedback.isCanceled():
                                return {}   
                                                     
                            if Temp_file in file:
                                file_name = file
                                break

                        if file_name:
                            input_file = os.path.join(besShpFolder, file_name)
                            output_file = os.path.join(folder_path, Temp_file)
                            shutil.copy(input_file, output_file)
                            feedback.pushInfo("Temp_file 저장: " + output_file)

                        if feedback.isCanceled():
                            return {}

                    files_to_zips = [['LinkShape.cpg', 'LinkShape.dbf', 'LinkShape.prj', 'LinkShape.shp', 'LinkShape.shx'],
                                    ['NodeShape.cpg', 'NodeShape.dbf', 'NodeShape.prj', 'NodeShape.shp', 'NodeShape.shx'],
                                    ['TempTimeNode.dbf', 'TempTimeTrafficInfo.dbf']]
                    zip_filenames = ['LinkShape.zip', 'NodeShape.zip', '시변.zip']

                    if zipFolder:
                        for iii in range(3):
                            if feedback.isCanceled():
                                return {}
                        
                            zip_filename = zip_filenames[iii]
                            files_to_zip = files_to_zips[iii]
                            zip_file_path = os.path.join(zip_folder, zip_filename)
                            with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                                for file in files_to_zip:
                                    file_path = os.path.join(folder_path, file)

                                    if feedback.isCanceled():
                                        return {}
                                    
                                    if os.path.exists(file_path):
                                        zipf.write(file_path, arcname=file)
                            feedback.pushInfo(f"파일 압축 완료: {zip_file_path}")

                if i == 3:
                    for cv in cv_files:
                        file_name = None
                        if feedback.isCanceled():
                            return {}
                        for file in os.listdir(besShpFolder):
                            if feedback.isCanceled():
                                return {}
                            if cv in file:
                                parts = file.split('.')
                                if len(parts) > 1:
                                    ext = parts[1]
                                    if len(file) > 15:
                                        input_file = os.path.join(besShpFolder, file)
                                        output_file = os.path.join(folder_path, cv + '.' + ext)
                                        shutil.copy(input_file, output_file)
                                        # feedback.pushInfo("cv_file 저장: " + output_file)
                    feedback.pushInfo(f"💾 상용차DB 저장 완료")

                    # 상용차 자료 압축 및 저장
                    if zipFolder:
                        zip_file_path = os.path.join(zip_folder, "상용차.zip")
                        files_to_zip = ['cv_dt_bes.dbf', 'cv_dt_bes.shp', 'cv_dt_bes.shx',
                                        'cv_link_bes.dbf', 'cv_link_bes.shp','cv_link_bes.shx',
                                        'cv_LinkShape.cpg','cv_LinkShape.dbf','cv_LinkShape.prj','cv_LinkShape.shp','cv_LinkShape.shx']
                        with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                            for file in files_to_zip:
                                if feedback.isCanceled():
                                    return {}
                                file_path = os.path.join(folder_path, file)
                                if os.path.exists(file_path):
                                    zipf.write(file_path, arcname=file)
                            feedback.pushInfo(f"파일 압축 완료: {zip_file_path}")

        if mode==0 or mode==2:

            feedback.pushInfo("🚀 GRS SHP 변환 시작")
            # GRS SHP 변환
            feedback = QgsProcessingMultiStepFeedback(38, feedback)
            results = {}
            outputs = {}

            # shp_folder 내에서 파일 검색
            for grsFile in os.listdir(grsShpFolder):

                if feedback.isCanceled():
                    return {}
                
                if 'LinkShape' in grsFile and grsFile.endswith(".shp"):
                    filename = os.path.splitext(grsFile)[0]
                    cpg = os.path.join(grsShpFolder, filename + '.cpg')
                    shutil.copy(self.cpg_file, cpg)
                    if len(grsFile) > 15:
                        grsLinkShape = grsFile
            
                if 'NodeShape' in grsFile and grsFile.endswith(".shp"):
                    filename = os.path.splitext(grsFile)[0]
                    cpg = os.path.join(grsShpFolder, filename + '.cpg')
                    shutil.copy(self.cpg_file, cpg)
                    if len(grsFile) > 15:
                        grsNodeShape = grsFile

            if feedback.isCanceled():
                return {}
            
            if not grsLinkShape:
                feedback.pushInfo(self.tr("파일을 찾을 수 없습니다: LinkShape"))
                return {}

            if not grsNodeShape:
                feedback.pushInfo(self.tr("파일을 찾을 수 없습니다: NodeShape"))
                return {}
            
            if feedback.isCanceled():
                return {}
            
            input_grsLinkShape = os.path.join(grsShpFolder, grsLinkShape)
            input_grsNodeShape = os.path.join(grsShpFolder, grsNodeShape)

            input_Node_bes = os.path.join(folder_paths[0], "Node.shp")
            input_NodeShape_bes = os.path.join(folder_paths[1], "NodeShape.shp")


            output_LinkShape_GRS = os.path.join(folder_paths[1], "LinkShape_GRS.shp")
            output_Node_GRS = os.path.join(folder_paths[0], "Node_GRS.shp")
            output_NodeShape_GRS = os.path.join(folder_paths[1], "NodeShape_GRS.shp")

            # Shapefile 좌표계 정의
            outputs['projection'] = self.define_projection(input_grsLinkShape, 'USER:100001', context=context, feedback=silent_feedback)

            feedback.setCurrentStep(1)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkMapId
            params = {
                'INPUT': outputs['projection']['INPUT'],
                'FIELD_NAME': 'OriLkMapId', 
                'FIELD_TYPE': 2,
                'FIELD_LENGTH': 30,
                'FIELD_PRECISION': 0,
                'FORMULA': 'to_string(to_int(right("OriLkMapId", 4))+1001)||\'0000\'',
                'OUTPUT': 'memory:'
            }
            outputs['orilkmapid'] = processing.run('native:fieldcalculator', params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 Map_Id
            params = {
                'INPUT': outputs['orilkmapid']['OUTPUT'],
                'FIELD_NAME': 'Map_Id', 
                'FIELD_TYPE': 2,
                'FIELD_LENGTH': 30,
                'FIELD_PRECISION': 0,
                'FORMULA': 'to_string(to_int(right( "Map_Id"  ,4))+1001)||\'0000\'',
                'OUTPUT': 'memory:'
            }
            outputs['Map_id'] = processing.run('native:fieldcalculator', params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.setCurrentStep(3)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 ML_ID
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'ML_ID',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriLkMapId"||\'_\'||"OriLkId"',
                'INPUT': outputs['Map_id']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Ml_id'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4)
            if feedback.isCanceled():
                return {}

            # 범주 별 통계
            alg_params = {
                'CATEGORIES_FIELD_NAME': ['ML_ID'],
                'INPUT': outputs['Ml_id']['OUTPUT'],
                'VALUES_FIELD_NAME': '',
                'OUTPUT': 'memory:'
            }
            outputs['statisticsbycategories'] = processing.run('qgis:statisticsbycategories', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5)
            if feedback.isCanceled():
                return {}

            # 필드 값으로 속성 결합
            alg_params = {
                'INPUT': outputs['Ml_id']['OUTPUT'],    # 입력 레이어
                'FIELD': 'ML_ID',                       # 테이블 필드
                'INPUT_2': outputs['statisticsbycategories']['OUTPUT'],       # 입력 레이어2
                'FIELD_2': 'ML_ID',                     # 테이블 필드 2
                'FIELDS_TO_COPY': ['count'],            # 복사할 레이어 2필드  (모든 필드를 복사하려면 비워두기) [옵션]
                'METHOD': 1,                            # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'DISCARD_NONMATCHING': False,           # 결합할 수 없는 레코드 버리기
                'PREFIX': '',                           # 결합된 필드 접두사
                'OUTPUT': 'memory:'
            }
            outputs['join'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 OK
            alg_params = {
                'EXPRESSION': '"count" = 1 and  "OriLkMapId" = "Map_Id"',
                'INPUT': outputs['join']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Ok'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 NG1
            alg_params = {
                'EXPRESSION': '"count" = 1 and "OriLkMapId" <> "Map_Id"',
                'INPUT': outputs['join']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Ng1'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(8)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 NG2
            alg_params = {
                'EXPRESSION': '"count" <> 1',
                'INPUT': outputs['join']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Ng2'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(9)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkMapId > Map_Id 2
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Map_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriLkMapId"',
                'INPUT': outputs['Ng2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['OrilkmapidMap_id2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkId > Link_Id 2
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Link_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriLkId"',
                'INPUT': outputs['OrilkmapidMap_id2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Link_id2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(11)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkMapId > Map_Id1
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Map_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriLkMapId"',
                'INPUT': outputs['Ng1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['OrilkmapidMap_id1'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(12)
            if feedback.isCanceled():
                return {}

            # 디졸브
            alg_params = {
                'FIELD': ['ML_ID'],
                'INPUT': outputs['Link_id2']['OUTPUT'],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': 'memory:'
            }
            outputs['dissolve'] = processing.run('native:dissolve', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(13)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkId > Link_Id1
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Link_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriLkId"',
                'INPUT': outputs['OrilkmapidMap_id1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Link_id1'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(14)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 Length
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Length',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': 'to_int(length(@geometry))',
                'INPUT': outputs['dissolve']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Length'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(15)
            if feedback.isCanceled():
                return {}

            # 벡터 레이어 병합
            alg_params = {
                'CRS': None,
                'LAYERS': [outputs['Length']['OUTPUT'],outputs['Ok']['OUTPUT'],outputs['Link_id1']['OUTPUT']],
                'OUTPUT': 'memory:'
            }
            outputs['merge'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(16)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 협력사
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': '협력사',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # �ؽ�Ʈ (string)
                'FORMULA': '협력사( "Map_Id")',
                'INPUT': outputs['merge']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Partner'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(17)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 매스코
            alg_params = {
                'EXPRESSION': '"협력사" = \'매스코\'',
                'INPUT': outputs['Partner']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['masco'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(18)
            if feedback.isCanceled():
                return {}

            # 필드 삭제
            alg_params = {
                'COLUMN': ['OriLkMapId','OriLkId','count','layer','path','협력사'],
                'INPUT': outputs['masco']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['deletecolumn'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.pushInfo(f"GRS 링크SHP 수정 완료")
            feedback.setCurrentStep(19)
            if feedback.isCanceled():
                return {}

            # 필드 재작성
            alg_params = {
                'FIELDS_MAPPING': [ {'expression': '"Map_Id"','length': 30,'name': 'Map_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id"','length': 30,'name': 'Link_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"St_Nd_Id"','length': 30,'name': 'St_Nd_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Ed_Nd_Id"','length': 30,'name': 'Ed_Nd_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Level1"','length': 30,'name': 'Level1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Level2"','length': 30,'name': 'Level2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Length"','length': 30,'name': 'Length','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                    {'expression': '"Road_cate"','length': 30,'name': 'Road_cate','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_cate"','length': 30,'name': 'Link_cate','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_cate2"','length': 30,'name': 'Link_cate2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Facil_id"','length': 30,'name': 'Facil_id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_facil"','length': 30,'name': 'Link_facil','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Facil_Name"','length': 30,'name': 'Facil_Name','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Road_no"','length': 30,'name': 'Road_no','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Width"','length': 30,'name': 'Width','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Oneway"','length': 30,'name': 'Oneway','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"VarLane"','length': 30,'name': 'VarLane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Lane"','length': 30,'name': 'Lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"SpeedLL"','length': 30,'name': 'SpeedLL','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"SpeedLH"','length': 30,'name': 'SpeedLH','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Hov_lane"','length': 30,'name': 'Hov_lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"S_Hov_lane"','length': 30,'name': 'S_Hov_lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Car_lane"','length': 30,'name': 'Car_lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Emg_lane"','length': 30,'name': 'Emg_lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Var_lane"','length': 30,'name': 'Var_lane','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Prohi_Car"','length': 30,'name': 'Prohi_Car','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DB_Type"','length': 30,'name': 'DB_Type','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Road_name"','length': 30,'name': 'Road_name','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Barrier"','length': 30,'name': 'Barrier','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"ML_ID"','length': 30,'name': 'ML_ID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
                'INPUT': outputs['deletecolumn']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['refactorfields'] = processing.run('native:refactorfields', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.setCurrentStep(20)
            if feedback.isCanceled():
                return {}

            # 표현식으로 정렬
            alg_params = {
                'ASCENDING': True, # 오름차순으로 정렬
                'EXPRESSION': 'ML_ID', # 표현식
                'INPUT': outputs['refactorfields']['OUTPUT'], #입력레이어
                'NULLS_FIRST': False, # Null값 우선 정렬
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['orderbyexpression'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.setCurrentStep(21)
            if feedback.isCanceled():
                return {}

            # M/Z 값 삭제
            alg_params = {
                'DROP_M_VALUES': True,
                'DROP_Z_VALUES': True,
                'INPUT': outputs['orderbyexpression']['OUTPUT'], #입력레이어
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Mz'] = processing.run('native:dropmzvalues', alg_params, context=context, feedback=silent_feedback)

            feedback.setCurrentStep(22)
            if feedback.isCanceled():
                return {}

            # 단순화
            alg_params = {
                'INPUT': outputs['Mz']['OUTPUT'],
                'METHOD': 0,  # 거리 (Douglas-Peucker)
                'TOLERANCE': 0.5,
                'OUTPUT': output_LinkShape_GRS
            }
            processing.run('native:simplifygeometries', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.pushInfo(f"파일 저장 완료: {output_LinkShape_GRS}")
            feedback.setCurrentStep(23)
            if feedback.isCanceled():
                return {}

            # GRS 노드

            # Shapefile 좌표계 정의
            outputs['projection'] = self.define_projection(input_grsNodeShape, 'USER:100001', context=context, feedback=silent_feedback)

            feedback.setCurrentStep(24)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkMapId
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'OriNdMapId',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': ' to_string(to_int(right( "OriNdMapId"  ,4))+1001)||\'0000\'',
                'INPUT': outputs['projection']['INPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Orindmapid'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(25)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 ML_ID
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'MN_ID',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriNdMapId"||\'_\'||"OriNdId"',
                'INPUT': outputs['Orindmapid']['OUTPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Mn_id'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(26)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 OK
            alg_params = {
                'EXPRESSION': '"OriNdMapId" <> \'10020000\'',
                'INPUT': outputs['Mn_id']['OUTPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Ok'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(27)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriLkMapId > Map_Id
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Map_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriNdMapId"',
                'INPUT': outputs['Ok']['OUTPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Map_id'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(28)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 OriNdId > Node_Id
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Node_Id',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': '"OriNdId"',
                'INPUT': outputs['Map_id']['OUTPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['Node_id'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(29)
            if feedback.isCanceled():
                return {}

            # 필드 계산기 협력사
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': '협력사',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # �ؽ�Ʈ (string)
                'FORMULA': '협력사( "Map_Id")',
                'INPUT': outputs['Node_id']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['Partner'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(30)
            if feedback.isCanceled():
                return {}

            # 표현식으로 추출 매스코
            alg_params = {
                'EXPRESSION': '"협력사" = \'매스코\'',
                'INPUT': outputs['Partner']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['masco'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(31)
            if feedback.isCanceled():
                return {}

            # 필드 삭제
            alg_params = {
                'COLUMN': ['OriNdId','OriNdMapId'],
                'INPUT': outputs['masco']['OUTPUT'],
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['deletecolumn'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(32)
            if feedback.isCanceled():
                return {}

            # M/Z 값 삭제
            alg_params = {
                'DROP_M_VALUES': True,
                'DROP_Z_VALUES': True,
                'INPUT': outputs['deletecolumn']['OUTPUT'], #입력레이어
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['dropmz'] = processing.run('native:dropmzvalues', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.pushInfo(f"GRS 노드SHP 수정 완료")
            
            feedback.setCurrentStep(33)
            if feedback.isCanceled():
                return {}

            # 필드 값으로 속성 결합1
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'MN_ID',
                'FIELDS_TO_COPY': ['Node_Attr','Nd_Name','Link_Id1','Link_Id2','Link_Id3','Link_Id4','Link_Id5','Link_Id6','Link_Id7','Link_Id8','DirText_s0','DirText_s1','DirText_s2','DirText_s3','DirText_s4','DirText_s5','DirText_s6','DirText_s7','DirText_l0','DirText_l1','DirText_l2','DirText_l3','DirText_l4','DirText_l5','DirText_l6','DirText_l7'],
                'FIELD_2': 'MN_ID',
                'INPUT': outputs['dropmz']['OUTPUT'],
                'INPUT_2': input_Node_bes,
                'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
                'PREFIX': '',
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['join1'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(34)
            if feedback.isCanceled():
                return {}

            # 필드 재작성1
            alg_params = {
                'FIELDS_MAPPING': [ {'expression': '"Map_Id"','length': 30,'name': 'Map_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Node_Id"','length': 30,'name': 'Node_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Node_Attr"','length': 30,'name': 'Node_Attr','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Nd_Name"','length': 30,'name': 'Nd_Name','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id1"','length': 30,'name': 'Link_Id1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id2"','length': 30,'name': 'Link_Id2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id3"','length': 30,'name': 'Link_Id3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id4"','length': 30,'name': 'Link_Id4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id5"','length': 30,'name': 'Link_Id5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id6"','length': 30,'name': 'Link_Id6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id7"','length': 30,'name': 'Link_Id7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id8"','length': 30,'name': 'Link_Id8','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s0"','length': 30,'name': 'DirText_s0','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s1"','length': 30,'name': 'DirText_s1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s2"','length': 30,'name': 'DirText_s2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s3"','length': 30,'name': 'DirText_s3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s4"','length': 30,'name': 'DirText_s4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s5"','length': 30,'name': 'DirText_s5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s6"','length': 30,'name': 'DirText_s6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_s7"','length': 30,'name': 'DirText_s7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l0"','length': 30,'name': 'DirText_l0','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l1"','length': 30,'name': 'DirText_l1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l2"','length': 30,'name': 'DirText_l2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l3"','length': 30,'name': 'DirText_l3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l4"','length': 30,'name': 'DirText_l4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l5"','length': 30,'name': 'DirText_l5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l6"','length': 30,'name': 'DirText_l6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"DirText_l7"','length': 30,'name': 'DirText_l7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"X"','length': 30,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Y"','length': 30,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"MN_ID"','length': 30,'name': 'MN_ID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
                'INPUT': outputs['join1']['OUTPUT'],
                'OUTPUT': output_Node_GRS
            }
            processing.run('native:refactorfields', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            feedback.pushInfo(f"파일 저장 완료: {output_Node_GRS}")
            feedback.setCurrentStep(35)
            if feedback.isCanceled():
                return {}

            # 필드 값으로 속성 결합2
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'MN_ID',
                'FIELDS_TO_COPY': ['Node_Attr','RepNd_Id','Tra_Light','Nd_Name','Num_Link','Link_Id1','Link_Id2','Link_Id3','Link_Id4','Link_Id5','Link_Id6','Link_Id7','Link_Id8','t_code0','t_code1','t_code2','t_code3','t_code4','t_code5','t_code6','t_code7','d_code0','d_code1','d_code2','d_code3','d_code4','d_code5','d_code6','d_code7','AdjMap_Id','Unit_code','AdjNd_Id'],
                'FIELD_2': 'MN_ID',
                'INPUT': outputs['dropmz']['OUTPUT'],
                'INPUT_2': input_NodeShape_bes,
                'METHOD': 1,  # 1대1 결합
                'PREFIX': '',
                'OUTPUT': 'memory:' # 산출물
            }
            outputs['join2'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            
            feedback.setCurrentStep(36)
            if feedback.isCanceled():
                return {}

            # 필드 재작성2
            alg_params = {
                'FIELDS_MAPPING': [ {'expression': '"Map_Id"','length': 30,'name': 'Map_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Node_Id"','length': 30,'name': 'Node_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Node_Attr"','length': 30,'name': 'Node_Attr','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"RepNd_Id"','length': 30,'name': 'RepNd_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Tra_Light"','length': 30,'name': 'Tra_Light','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Nd_Name"','length': 30,'name': 'Nd_Name','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Num_Link"','length': 30,'name': 'Num_Link','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id1"','length': 30,'name': 'Link_Id1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id2"','length': 30,'name': 'Link_Id2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id3"','length': 30,'name': 'Link_Id3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id4"','length': 30,'name': 'Link_Id4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id5"','length': 30,'name': 'Link_Id5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id6"','length': 30,'name': 'Link_Id6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id7"','length': 30,'name': 'Link_Id7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Link_Id8"','length': 30,'name': 'Link_Id8','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code0"','length': 30,'name': 't_code0','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code1"','length': 30,'name': 't_code1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code2"','length': 30,'name': 't_code2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code3"','length': 30,'name': 't_code3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code4"','length': 30,'name': 't_code4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code5"','length': 30,'name': 't_code5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code6"','length': 30,'name': 't_code6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"t_code7"','length': 30,'name': 't_code7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code0"','length': 30,'name': 'd_code0','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code1"','length': 30,'name': 'd_code1','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code2"','length': 30,'name': 'd_code2','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code3"','length': 30,'name': 'd_code3','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code4"','length': 30,'name': 'd_code4','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code5"','length': 30,'name': 'd_code5','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code6"','length': 30,'name': 'd_code6','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"d_code7"','length': 30,'name': 'd_code7','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"AdjMap_Id"','length': 30,'name': 'AdjMap_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Unit_code"','length': 30,'name': 'Unit_code','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"AdjNd_Id"','length': 30,'name': 'AdjNd_Id','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"X"','length': 30,'name': 'X','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"Y"','length': 30,'name': 'Y','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                    {'expression': '"MN_ID"','length': 30,'name': 'MN_ID','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
                'INPUT': outputs['join2']['OUTPUT'],
                'OUTPUT': output_NodeShape_GRS
            }
            processing.run('native:refactorfields', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
            feedback.pushInfo(f"파일 저장 완료: {output_NodeShape_GRS}")
            feedback.setCurrentStep(37)
            if feedback.isCanceled():
                return {}

            output_folder_paths = [folder_paths[0], folder_paths[1], folder_paths[1]]

            files_to_zips = [
                ['Node_GRS.cpg', 'Node_GRS.dbf', 'Node_GRS.prj', 'Node_GRS.shp', 'Node_GRS.shx'],
                ['LinkShape_GRS.cpg', 'LinkShape_GRS.dbf', 'LinkShape_GRS.prj', 'LinkShape_GRS.shp', 'LinkShape_GRS.shx'],
                ['NodeShape_GRS.cpg', 'NodeShape_GRS.dbf', 'NodeShape_GRS.prj', 'NodeShape_GRS.shp', 'NodeShape_GRS.shx']]
            
            if zipFolder:
                zip_filenames = ['Node_GRS.zip', 'LinkShape_GRS.zip', 'NodeShape_GRS.zip']
                for i in range(3):
                    output_folder = output_folder_paths[i]
                    zip_filename = zip_filenames[i]
                    files_to_zip = files_to_zips[i]
                    zip_file_path = os.path.join(zip_folder, zip_filename)

                    if feedback.isCanceled():
                        return {}
                    
                    with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        for file in files_to_zip:
                            file_path = os.path.join(output_folder, file)
                            if os.path.exists(file_path):
                                zipf.write(file_path, arcname=file)
                            if feedback.isCanceled():
                                return {}
                    feedback.pushInfo(f"파일 압축 완료: {zip_file_path}")

                feedback.pushInfo("\n✨ SHP파일 변환, 저장, 압축을 완료 하였습니다.")

        return {}
