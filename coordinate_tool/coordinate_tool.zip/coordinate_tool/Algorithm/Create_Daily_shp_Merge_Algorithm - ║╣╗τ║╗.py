from qgis.core import (
    edit,
    QgsProject,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterFileDestination,
    QgsProcessingFeedback,
    QgsFeatureRequest,
    QgsSingleSymbolRenderer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingUtils,
    QgsVectorLayerJoinInfo,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsLineSymbol,
    QgsVectorLayer,
    QgsField,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterFeatureSink
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication
from PyQt5.QtCore import QSettings

import os, shutil, processing, glob
import pandas as pd
import re

class Create_Daily_shp_Merge_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('조사등록폴더', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '📁주차 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ADD_TO_CANVAS',
                    '병합 파일 화면에 추가',
                    defaultValue = False
                )
            )

        # self.addParameter(
        #         QgsProcessingParameterVectorLayer(
        #             'RTM_SHP', 
        #             '📝취합 원본 SHP', 
        #             types=[QgsProcessing.TypeVectorLine],
        #             optional=True  # 선택 입력으로 설정
        #         )
        #     )

        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             'RTM_ADD',
        #             '원본 파일에 조사결과 취합',
        #             defaultValue = False
        #         )
        #     )
        
        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             '본사',
        #             '본사 제외',
        #             defaultValue = False
        #         )
        #     )

        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             '대구',
        #             '대구 제외',
        #             defaultValue = False
        #         )
        #     )
        
        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             '광주',
        #             '광주 제외',
        #             defaultValue = False
        #         )
        #     )
        
        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             '원주',
        #             '원주 제외',
        #             defaultValue = False
        #         )
        #     )
        
        # self.addParameter(
        #         QgsProcessingParameterFeatureSink(
        #             'Ok', 
        #             'ML_ID 매칭', 
        #             type=QgsProcessing.TypeVectorAnyGeometry, 
        #             createByDefault=False, 
        #             supportsAppend=True, 
        #             defaultValue=None
        #         )
        #     )
        
        # self.addParameter(
        #         QgsProcessingParameterFeatureSink(
        #             'Ng', 
        #             'ML_ID 비매칭', 
        #             type=QgsProcessing.TypeVectorAnyGeometry, 
        #             createByDefault=True, 
        #             supportsAppend=True, 
        #             defaultValue=None
        #         )
        #     )
        
        self.addParameter(
                QgsProcessingParameterFeatureSink(
                    'ML_Null', 
                    'ML_ID_누락', 
                    type=QgsProcessing.TypeVectorAnyGeometry, 
                    createByDefault=True, 
                    supportsAppend=True, 
                    defaultValue=None
                )
            )

        # self.addParameter(
        #         QgsProcessingParameterFeatureSink(
        #             'test', 
        #             'test', 
        #             type=QgsProcessing.TypeVectorAnyGeometry, 
        #             createByDefault=True, 
        #             supportsAppend=True, 
        #             defaultValue=None
        #         )
        #     )

    def processAlgorithm(self, parameters, context, model_feedback):

        # ——— 출력 레이어 이름 고정 ———
        # parameters['Ng'].destinationName  = 'ML_ID 비매칭'
        # parameters['Ok'].destinationName  = 'ML_ID 매칭'
        parameters['ML_Null'].destinationName  = 'ML_ID 누락'

        # parameters['test'].destinationName  = 'test'

        input_Folder = self.parameterAsFile(parameters, '1', context)
        weekNum = input_Folder.split('\\')[-1]
        self.Qsettings.setValue('조사등록폴더', input_Folder)

        # 사용자의 체크박스 선택값 읽기
        add_to_canvas = self.parameterAsBool(parameters, 'ADD_TO_CANVAS', context)

        # 원본 shp 가져오기
        rtm_shp = self.parameterAsVectorLayer(parameters, 'RTM_SHP', context)
        # 원본 파일에 조사결과 취합 선택값 읽기
        add_to_rtm = self.parameterAsBool(parameters, 'RTM_ADD', context)
        # 제외 담당 선택값 읽기
        ay = self.parameterAsBool(parameters, '본사', context)
        dg = self.parameterAsBool(parameters, '대구', context)
        gj = self.parameterAsBool(parameters, '광주', context)
        wj = self.parameterAsBool(parameters, '원주', context)

        # 2) 제외할 담당 목록 생성
        exclude_roles = []
        if ay:
            exclude_roles.append('본사')
        if dg:
            exclude_roles.append('대구')
        if gj:
            exclude_roles.append('광주')
        if wj:
            exclude_roles.append('원주')


        m = re.match(r'\d+년(\d+)월(\d+)주', weekNum)
        month = int(m.group(1))
        week  = int(m.group(2))
        complete = month * 10 + week

        feedback = QgsProcessingMultiStepFeedback(52, model_feedback)
        silent_feedback = QgsProcessingFeedback()

        result_val = []
        # 1. 하위 모든 SHP 경로 수집
        chk = 0
        for subFolder in os.listdir(input_Folder):
            results = {}
            outputs = {}
            subFolder_Path = os.path.join(input_Folder, subFolder)
            fileName =f'{weekNum}_{subFolder}_조사등록'
            result_path = f'{input_Folder}/{fileName}.shp'
            result_merge_path = f'{input_Folder}/{weekNum}_조사등록.shp'

            if not os.path.isdir(subFolder_Path):
                continue
            all_shp_paths = None
            all_shp_paths = []
            for logFolder in os.listdir(subFolder_Path):
                logFolder_Path = os.path.join(subFolder_Path, logFolder)
                if not os.path.isdir(logFolder_Path):
                    continue
                shp_files = glob.glob(os.path.join(logFolder_Path, '*.shp'))
                for shp_path in shp_files:
                    layer = QgsVectorLayer(shp_path, os.path.basename(shp_path), 'ogr')
                    if not layer.isValid():
                        feedback.pushInfo(f"❗레이어 로딩 실패: {shp_path}")
                        continue

                    delete_fields = []
                    for field in layer.fields():
                        if field.name().lower() in ['layer','path','layer_name', 'layer_path', '조사완료','로그명','차수','조사담당','LEN', '조사구분']:
                            delete_fields.append(field.name())

                    if delete_fields:
                        with edit(layer):
                            for field_name in delete_fields:
                                idx = layer.fields().indexFromName(field_name)
                                if idx != -1:
                                    layer.deleteAttribute(idx)
                        layer.updateFields()
                        layer.commitChanges()
                feedback.pushWarning(f"🧺{logFolder} 취합완료")
                all_shp_paths.extend(shp_files) 

            if not all_shp_paths:
                chk = 21
                feedback.pushInfo(f'📢{subFolder}에 병합할 SHP 파일이 없습니다.')
                continue

            # 0. SHX/DBF/PRJ 파일 유무 체크
            missing = []
            for shp_path in all_shp_paths:
                base, _ = os.path.splitext(shp_path)
                shx = base + '.shx'
                dbf = base + '.dbf'
                prj = base + '.prj'
                # 필요한 파일만 검사하거나, 원하는 확장자를 추가하세요
                for f in (shx, dbf, prj):
                    if not os.path.exists(f):
                        missing.append(f)
            if missing:
                # 오류로 처리할지, 안내만 할지는 상황에 맞게 선택
                feedback.reportError(
                    '다음 파일이 누락되어 병합이 불가능합니다:\n' +
                    '\n'.join(sorted(set(missing)))
                )
                return {}  # 병합 중단

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS':  QgsCoordinateReferenceSystem('EPSG:4326'),
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs['1'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1 + chk)
            feedback.pushWarning(f"🧺{subFolder} 조사등록SHP 병합 완료")
            # 4_필드 삭제
            outputs['1_1'] = processing.run(
                'native:deletecolumn', 
                    {
                        'COLUMN': ['조사완료','로그명','차수','조사담당','LEN', '조사구분'],
                        'INPUT': outputs['1']['OUTPUT'],
                        'OUTPUT': 'memory:'
                    }, 
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 2_필드 계산기 LOG_NAME
            split_index = len(all_shp_paths[0].split('\\')) - 2
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '로그명',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f"string_to_array( \"path\" ,'\\\\')[{split_index}]",
                'INPUT': outputs['1_1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            # 2_1 필드 계산기 조사담당
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': '조사담당',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f'substr( "로그명", strpos( "로그명" ,\'(\') + 1, 2)',
                'INPUT': outputs['2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2_1'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2 + chk)
            
            # 3_필드 계산기 차수
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '차수',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f'left("layer",1)',
                'INPUT': outputs['2_1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3 + chk)

            # 4_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['3']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['4'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4 + chk)

            # 6_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'LEN',
                'FIELD_PRECISION': 3,
                'FIELD_TYPE': 0,  # 텍스트 (string)
                'FORMULA': "round(Length(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000,3)",
                'INPUT': outputs['4']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['6'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6 + chk)

            # 7_좌표계 수정  - 머지로 좌표계수정
            outputs['7'] = processing.run(
                'native:mergevectorlayers',
                    {
                        'LAYERS': [
                            outputs['6']['OUTPUT']
                        ],
                        'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),
                        'OUTPUT': 'memory:' # 또는 원하는 출력 파라미터
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(7 + chk)

            # 7_필드명 대문자 변경
            # 1) 방금 저장된 shapefile 레이어를 불러옵니다.
            # 메모리로 반환된 레이어 객체를 바로 사용
            final_layer = QgsProcessingUtils.mapLayerFromString(
                outputs['7']['OUTPUT'],
                context
            )
            # final_layer = QgsVectorLayer(result_path, fileName, 'ogr')
            if not final_layer.isValid():
                model_feedback.reportError('결과 레이어 로드에 실패했습니다.')
                return {}

            # 2) 필드 인덱스와 대문자 이름을 매핑합니다.
            provider = final_layer.dataProvider()
            rename_map = {}
            for idx, field in enumerate(final_layer.fields()):
                upper_name = field.name().upper()
                if field.name() != upper_name:
                    rename_map[idx] = upper_name

            # 3) 실제로 이름을 변경하고 필드 구조를 갱신합니다.
            if rename_map:
                provider.renameAttributes(rename_map)
                final_layer.updateFields()

            # 필드 이름으로 인덱스 조회 (없으면 필드생성)
            field_idx = final_layer.fields().indexOf('ROADKIND')

            if field_idx == -1:
                # 2) ROADKIND 필드가 없으면 추가
                new_field = QgsField('ROADKIND', QVariant.Int,  typeName='integer', len=10)
                provider.addAttributes([new_field])
                final_layer.updateFields()
                feedback.pushWarning(f"📝'ROADKIND' 필드를 새로 추가했습니다.")

            #  필드 이름으로 인덱스 조회 (없으면 필드생성)
            field_idx = final_layer.fields().indexOf('ML_ID')

            if field_idx == -1:
                # 2) ROADKIND 필드가 없으면 추가
                new_field = QgsField('ML_ID', QVariant.String,  typeName='varchar', len=50)
                provider.addAttributes([new_field])
                final_layer.updateFields()
                feedback.pushWarning(f"📝'ML_ID' 필드를 새로 추가했습니다.")

            # ------------------------------------------------------------
            # 여기서부터 두 번째 알고리즘 (8~14단계)
            # ------------------------------------------------------------
            # 8단계: ROADKIND가 null인 것 추출
            
            outputs['8'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['7']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,        # is null
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 9단계: ROADKIND 계산 (ROAD_KIND 값 복사)
            feedback.setCurrentStep(8 + chk)
            if feedback.isCanceled():
                return {}
            outputs['9'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['8']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,      # Integer
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROAD_KIND"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 10단계: null 남은 것 다시 추출
            feedback.setCurrentStep(9 + chk)

            outputs['10'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['9']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 11단계: ROADKIND 계산 (ROAD_CATE 값 복사)
            feedback.setCurrentStep(10 + chk)

            outputs['11'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['10']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROAD_CATE"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 12단계: 또 null 추출
            feedback.setCurrentStep(11 + chk)

            outputs['12'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['11']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 13단계: ROADKIND 계산 (ROADCATE 값 복사)
            feedback.setCurrentStep(12 + chk)

            outputs['13'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['12']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROADCATE"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            # 14단계: 네 개 레이어 최종 병합
            feedback.setCurrentStep(13 + chk)
            
            outputs['14'] = processing.run(
                'native:mergevectorlayers',
                    {
                        'LAYERS': [
                            outputs['8']['FAIL_OUTPUT'],
                            outputs['10']['FAIL_OUTPUT'],
                            outputs['12']['FAIL_OUTPUT'],
                            outputs['13']['OUTPUT']
                        ],
                        'CRS': None,
                        'OUTPUT': 'memory:'  # 또는 원하는 출력 파라미터
                    },
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(14 + chk)

            # 4_필드 삭제
            outputs['15'] = processing.run(
                'native:deletecolumn', 
                    {
                        'COLUMN': ['layer','path'],
                        'INPUT': outputs['14']['OUTPUT'],
                        'OUTPUT': 'memory:'
                    }, 
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(15 + chk)

            # ------------------------------------------------------------
            # 여기서부터 두 번째 알고리즘 (16~19단계)
            # ------------------------------------------------------------
            initial = outputs['15']['OUTPUT']
            layer_in = initial

            # 16단계: ML_ID가 null인 것 추출
            # (map_field, id_field) 조합 리스트
            combos = [
                ('LINK_MAP_I', 'LINK_ID'),
                ('LINKMAPI',   'LINKID'),
                ('LINK_MAP_I', 'LINKID'),
                ('LINKMAPI',   'LINK_ID'),
                ('MAP_ID',     'LINK_ID'),
                ('MAPID',      'LINKID'),
                ('MAPID',      'LINK_ID'),
                ('MAP_ID',     'LINKID'),
            ]

            ml_layers = []

            for idx, (map_f, id_f) in enumerate(combos, start=1):
                expr = f'"ML_ID" is Null and "{id_f}" is not Null and "{map_f}" is not Null'
                res = processing.run(
                    'native:extractbyexpression',
                    {
                        'EXPRESSION': expr,
                        'INPUT': layer_in,
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                    context=context, feedback=silent_feedback, is_child_algorithm=True
                )
                # ML_ID 계산
                formula = f'"{map_f}"||\'_\'||"{id_f}"'
                fc = processing.run(
                    'native:fieldcalculator',
                    {
                        'INPUT': res['OUTPUT'],
                        'FIELD_NAME': 'ML_ID',
                        'FIELD_TYPE': 2,
                        'FIELD_LENGTH': 30,
                        'FORMULA': formula,
                        'OUTPUT': 'memory:'
                    },
                    context=context, feedback=silent_feedback, is_child_algorithm=True
                )
                ml_layers.append(fc['OUTPUT'])
                layer_in = res['FAIL_OUTPUT']

            # 진행 상황 업데이트
            feedback.setCurrentStep(17 + chk)

            all_layers = [layer_in] + ml_layers

            # 18단계: 병합
            outputs['18'] = processing.run(
                'native:mergevectorlayers', 
                {
                    'CRS':  QgsCoordinateReferenceSystem('EPSG:4326'),
                    'LAYERS': all_layers,
                    'OUTPUT': 'memory:'
                }, 
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )
            
            alg_params = {
                'ASCENDING': True,
                'EXPRESSION': '"ML_ID"',
                'INPUT': outputs['18']['OUTPUT'],
                'NULLS_FIRST': True,
                'OUTPUT': 'memory:',
            }
            outputs['18_1'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)
        
            # 5_중복 도형 삭제
            alg_params = {
                'INPUT': outputs['18_1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['18_2'] = processing.run('native:deleteduplicategeometries', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            # 19_필드 삭제
            outputs['19'] = processing.run(
                'native:deletecolumn', 
                    {
                        'COLUMN': ['layer','path'],
                        'INPUT': outputs['18_2']['OUTPUT'],
                        'OUTPUT': 'memory:'
                    }, 
                context=context, feedback=silent_feedback, is_child_algorithm=True
            )
            
            feedback.setCurrentStep(19 + chk)

            # 20단계: 완료주차 계산
            outputs['20'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['19']['OUTPUT'],
                    'FIELD_NAME': '조사완료',
                    'FIELD_TYPE': 1,      # Integer
                    'FIELD_LENGTH': 10,
                    'FORMULA': complete,
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=silent_feedback, is_child_algorithm=True      
            )
            
            feedback.setCurrentStep(20 + chk)

            # 21단계: 조사구분 계산
            outputs[subFolder] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['20']['OUTPUT'],
                    'FIELD_NAME': '조사구분',
                    'FIELD_TYPE': 2,    
                    'FIELD_LENGTH': 10,
                    'FORMULA': f"'{subFolder}'",
                    'OUTPUT': result_path
                },
                context=context, feedback=silent_feedback, is_child_algorithm=True      
            )
            
            feedback.setCurrentStep(21 + chk)
            
            chk = 21

            feedback.pushWarning(f"💾 {subFolder} 조사등록파일 취합완료 : {result_path}")
            result_val.append(outputs[subFolder]['OUTPUT'])

            # # 조건에 따라 레이어 로드
            # if add_to_canvas and os.path.exists(result_path):
            #     result_layer = QgsVectorLayer(result_path, f'{fileName}', 'ogr')
            #     if result_layer.isValid():
            #         QgsProject.instance().addMapLayer(result_layer)
            #     else:
            #         feedback.reportError('결과 레이어가 유효하지 않습니다.')


        # 22단계: 병합
        outputs['22'] = processing.run(
            'native:mergevectorlayers', 
            {
                'CRS':  QgsCoordinateReferenceSystem('EPSG:4326'),
                'LAYERS': result_val,
                'OUTPUT': 'memory:'
            }, 
            context=context, feedback=silent_feedback, is_child_algorithm=True
        )
        
        feedback.setCurrentStep(22 + chk)
        
        # 23_필드 삭제
        outputs['23'] = processing.run(
            'native:deletecolumn', 
                {
                    'COLUMN': ['layer','path'],
                    'INPUT': outputs['22']['OUTPUT'],
                    'OUTPUT': 'memory:',
                }, 
            context=context, feedback=silent_feedback, is_child_algorithm=True
        )

        feedback.setCurrentStep(23 + chk)

        alg_params = {
            'ASCENDING': True,
            'EXPRESSION': ' "로그명" ||\'_\'|| "차수"',
            'INPUT': outputs['23']['OUTPUT'],
            'NULLS_FIRST': False,
            'OUTPUT': result_merge_path # 'memory:',
        }
        outputs['25'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

        feedback.setCurrentStep(24 + chk)

        # ML_ID가 null인 것 추출
        outputs['ML_Null'] = processing.run(
            'native:extractbyexpression', 
                {
                    'EXPRESSION': '"ML_ID" is Null',
                    'INPUT': outputs['25']['OUTPUT'],
                    'FAIL_OUTPUT':  'memory:',
                    'OUTPUT':parameters['ML_Null'] # 'memory:'
                }, 
            context=context, feedback=silent_feedback, is_child_algorithm=True
        )

        results[logFolder] = outputs['ML_Null']['OUTPUT']

        feedback.pushWarning(f"💾 조사등록파일 취합완료 : {result_merge_path}")

        feedback.setCurrentStep(25 + chk)
        if feedback.isCanceled():
            return {}
        
        algorithm_dir = os.path.dirname(__file__)
        plugin_root = os.path.dirname(algorithm_dir)
        # style/Survey_link_shp.qml 경로 생성
        style_file = os.path.join(plugin_root, 'style', 'Survey_link_shp.qml')

        output_file = f"{input_Folder}/{weekNum}_조사등록.qml"
        shutil.copy(style_file, output_file)

        # 조건에 따라 레이어 로드
        if add_to_canvas and os.path.exists(result_merge_path):
            result_layer = QgsVectorLayer(result_merge_path, f'{weekNum}_조사등록', 'ogr')

            if result_layer.isValid():
                QgsProject.instance().addMapLayer(result_layer)
            else:
                feedback.reportError('결과 레이어가 유효하지 않습니다.')
                return {}
            
        feedback.setCurrentStep(26 + chk)

        from collections import Counter
        result_layer = QgsVectorLayer(outputs['25']['OUTPUT'], f'{weekNum}_조사등록', 'ogr')
        in_key_idx_temp = result_layer.fields().indexOf('ML_ID')
        in_feats_list   = result_layer.getFeatures()
        in_keys = []
        for f in in_feats_list:
            kv = f.attribute(in_key_idx_temp)
            if kv is not None:
                in_keys.append(kv)

            if feedback.isCanceled():
                return {}
        dup_in_keys = [k for k, c in Counter(in_keys).items() if c > 1]
        if dup_in_keys:
            feedback.pushWarning(f'중복된 키 값이 있습니다: {dup_in_keys}')

        feedback.setCurrentStep(31 + chk)
        return results

    def tr(self, string):
        return QCoreApplication.translate("Create_Daily_shp_Merge_Algorithm", string)
    
    def name(self):
        return '조사등록SHP 병합'

    def displayName(self):
        return '조사등록SHP 병합'

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "파일 관리"

    def shortHelpString(self):
        return self.tr("지정 폴더에 있는 조사등록 SHP을 병합 합니다.")

    def createInstance(self):
        return Create_Daily_shp_Merge_Algorithm()