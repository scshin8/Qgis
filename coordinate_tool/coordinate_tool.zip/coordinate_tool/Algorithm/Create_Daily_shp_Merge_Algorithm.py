from qgis.core import (edit,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime, QCoreApplication
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

class Create_Daily_shp_Merge_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('조사등록폴더', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '주차 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             'ADD_TO_CANVAS',
        #             '결과 레이어를 화면에 추가',
        #             defaultValue = False
        #         )
        #     )
        # self.addParameter(QgsProcessingParameterFeatureSink('2', '조사등록', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, '1', context)
        weekNum = input_Folder.split('\\')[-1]
        self.Qsettings.setValue('조사등록폴더', input_Folder)

        # 총 14단계로 늘립니다 (기존 7 + 추가 7)
        feedback = QgsProcessingMultiStepFeedback(14, model_feedback)

        # 1. 하위 모든 SHP 경로 수집
        for subFolder in os.listdir(input_Folder):
            results = {}
            outputs = {}
            subFolder_Path = os.path.join(input_Folder, subFolder)
            fileName =f'{weekNum}_{subFolder}_조사등록'
            result_path = f'{input_Folder}/{fileName}.shp'
            result_path1 = f'{input_Folder}/{fileName}_1.shp'
            if not os.path.isdir(subFolder_Path):
                continue
            all_shp_paths = None
            all_shp_paths = []
            for logFolder in os.listdir(subFolder_Path):
                logFolder_Path = os.path.join(subFolder_Path, logFolder)
                if not os.path.isdir(logFolder_Path):
                    continue
                shp_files = glob.glob(os.path.join(logFolder_Path, '*.shp'))
                for shp_path in shp_files:
                    layer = QgsVectorLayer(shp_path, os.path.basename(shp_path), 'ogr')
                    if not layer.isValid():
                        model_feedback.pushInfo(f"레이어 로딩 실패: {shp_path}")
                        continue

                    delete_fields = []
                    for field in layer.fields():
                        if field.name().lower() in ['path', 'layer']:
                            delete_fields.append(field.name())

                    if delete_fields:
                        with edit(layer):
                            for field_name in delete_fields:
                                idx = layer.fields().indexFromName(field_name)
                                if idx != -1:
                                    layer.deleteAttribute(idx)
                        layer.updateFields()
                        layer.commitChanges()

                all_shp_paths.extend(shp_files)

            if not all_shp_paths:
                model_feedback.pushInfo('병합할 SHP 파일이 없습니다.')
                return {}


            # 0. SHX/DBF/PRJ 파일 유무 체크
            missing = []
            for shp_path in all_shp_paths:
                base, _ = os.path.splitext(shp_path)
                shx = base + '.shx'
                dbf = base + '.dbf'
                prj = base + '.prj'
                # 필요한 파일만 검사하거나, 원하는 확장자를 추가하세요
                for f in (shx, dbf, prj):
                    if not os.path.exists(f):
                        missing.append(f)
            if missing:
                # 오류로 처리할지, 안내만 할지는 상황에 맞게 선택
                model_feedback.reportError(
                    '다음 파일이 누락되어 병합이 불가능합니다:\n' +
                    '\n'.join(sorted(set(missing)))
                )
                return {}  # 병합 중단

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS': None,
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs['1'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1)
            if feedback.isCanceled():
                return {}
            
            # 2_필드 계산기 path
            split_index = len(all_shp_paths[0].split('\\')) - 2
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': 'LOG_NAME',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f"string_to_array( \"path\" ,'\\\\')[{split_index}]",
                'INPUT': outputs['1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2)
            if feedback.isCanceled():
                return {}
            
            # 3_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '차수',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f'left("layer",1)',
                'INPUT': outputs['2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3)
            if feedback.isCanceled():
                return {}

            # 4_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['3']['OUTPUT'],
                'OUTPUT':  'memory:'
            }
            outputs['4'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4)
            if feedback.isCanceled():
                return {}
    
            # 5_중복 도형 삭제
            alg_params = {
                'INPUT': outputs['4']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['5'] = processing.run('native:deleteduplicategeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5)
            if feedback.isCanceled():
                return {}

            # 6_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'LEN_',
                'FIELD_PRECISION': 3,
                'FIELD_TYPE': 0,  # 텍스트 (string)
                'FORMULA': "Length(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000",
                'INPUT': outputs['5']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['6'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6)
            if feedback.isCanceled():
                return {}

            # 7_좌표계 수정
            alg_params = {
                'INPUT': outputs['6']['OUTPUT'],
                'OPERATION': '',
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:4326'),
                'OUTPUT': 'memory:' 
            }
            outputs['7'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7)
            if feedback.isCanceled():
                return {}

            # 7_필드명 대문자 변경
            # 1) 방금 저장된 shapefile 레이어를 불러옵니다.
            # 메모리로 반환된 레이어 객체를 바로 사용
            final_layer = QgsProcessingUtils.mapLayerFromString(
                outputs['7']['OUTPUT'],
                context
            )
            # final_layer = QgsVectorLayer(result_path, fileName, 'ogr')
            if not final_layer.isValid():
                model_feedback.reportError('결과 레이어 로드에 실패했습니다.')
                return {}

            # 2) 필드 인덱스와 대문자 이름을 매핑합니다.
            provider = final_layer.dataProvider()
            rename_map = {}
            for idx, field in enumerate(final_layer.fields()):
                upper_name = field.name().upper()
                if field.name() != upper_name:
                    rename_map[idx] = upper_name

            # 3) 실제로 이름을 변경하고 필드 구조를 갱신합니다.
            if rename_map:
                provider.renameAttributes(rename_map)
                final_layer.updateFields()

            # 필드 이름으로 인덱스 조회 (없으면 -1 리턴)
            field_idx = final_layer.fields().indexOf('ROADKIND')

            if field_idx == -1:
                # 2) ROADKIND 필드가 없으면 추가
                new_field = QgsField('ROADKIND', QVariant.Int,  typeName='integer', len=10)
                provider.addAttributes([new_field])
                final_layer.updateFields()
                print("'ROADKIND' 필드를 새로 추가했습니다.")
                
            # ------------------------------------------------------------
            # 여기서부터 두 번째 알고리즘 (8~14단계)
            # ------------------------------------------------------------
            # 8단계: ROADKIND가 null인 것 추출

            feedback.setCurrentStep(7)
            if feedback.isCanceled():
                return {}
            outputs['8'] = processing.run(
                'native:extractbyattribute',
                {
                    'INPUT': outputs['7']['OUTPUT'],
                    'FIELD': 'ROADKIND',
                    'OPERATOR': 8,        # is null
                    'VALUE': '',
                    'FAIL_OUTPUT': 'memory:',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 9단계: ROADKIND 계산 (ROAD_KIND 값 복사)
            feedback.setCurrentStep(8)
            if feedback.isCanceled():
                return {}
            outputs['9'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['8']['OUTPUT'],
                    'FIELD_NAME': 'ROADKIND',
                    'FIELD_TYPE': 1,      # Integer
                    'FIELD_LENGTH': 10,
                    'FORMULA': '"ROAD_KIND"',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 10단계: null 남은 것 다시 추출
            feedback.setCurrentStep(9)
            if feedback.isCanceled():
                return {}
            outputs['10'] = processing.run(
                'native:extractbyattribute',
                {
                    'INPUT': outputs['9']['OUTPUT'],
                    'FIELD': 'ROADKIND',
                    'OPERATOR': 8,
                    'VALUE': '',
                    'FAIL_OUTPUT': 'memory:',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 11단계: ROADKIND 계산 (ROAD_CATE 값 복사)
            feedback.setCurrentStep(10)
            if feedback.isCanceled():
                return {}
            outputs['11'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['10']['OUTPUT'],
                    'FIELD_NAME': 'ROADKIND',
                    'FIELD_TYPE': 1,
                    'FIELD_LENGTH': 10,
                    'FORMULA': '"ROAD_CATE"',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 12단계: 또 null 추출
            feedback.setCurrentStep(11)
            if feedback.isCanceled():
                return {}
            outputs['12'] = processing.run(
                'native:extractbyattribute',
                {
                    'INPUT': outputs['11']['OUTPUT'],
                    'FIELD': 'ROADKIND',
                    'OPERATOR': 8,
                    'VALUE': '',
                    'FAIL_OUTPUT': 'memory:',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 13단계: ROADKIND 계산 (ROADCATE 값 복사)
            feedback.setCurrentStep(12)
            if feedback.isCanceled():
                return {}
            outputs['13'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['12']['OUTPUT'],
                    'FIELD_NAME': 'ROADKIND',
                    'FIELD_TYPE': 1,
                    'FIELD_LENGTH': 10,
                    'FORMULA': '"ROADCATE"',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 14단계: 네 개 레이어 최종 병합
            feedback.setCurrentStep(13)
            if feedback.isCanceled():
                return {}
            outputs['14'] = processing.run(
                'native:mergevectorlayers',
                {
                    'LAYERS': [
                        outputs['8']['FAIL_OUTPUT'],
                        outputs['10']['FAIL_OUTPUT'],
                        outputs['12']['FAIL_OUTPUT'],
                        outputs['13']['OUTPUT']
                    ],
                    'CRS': None,
                    'OUTPUT': 'memory:'  # 또는 원하는 출력 파라미터
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(14)
            if feedback.isCanceled():
                return {}

            # 4_필드 삭제
            outputs['15'] = processing.run(
                'native:deletecolumn', 
                {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['14']['OUTPUT'],
                'OUTPUT':  result_path
            }, 
            context=context, feedback=feedback, is_child_algorithm=True)

    def tr(self, string):
        return QCoreApplication.translate("Create_Daily_shp_Merge_Algorithm", string)
    
    def name(self):
        return '조사등록SHP_병합'

    def displayName(self):
        return '조사등록SHP_병합'

    # def group(self):
    #     return 'wkt_geom_TO_shp'

    # def groupId(self):
    #     return 'wkt_geom_TO_shp'

    def shortHelpString(self):
        return self.tr("지정 폴더에 있는 조사등록 SHP을 병합 합니다.")

    def createInstance(self):
        return Create_Daily_shp_Merge_Algorithm()