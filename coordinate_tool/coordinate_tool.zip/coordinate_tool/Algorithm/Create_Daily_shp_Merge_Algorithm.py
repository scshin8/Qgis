from qgis.core import (
    edit,
    QgsProject,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterFileDestination,
    QgsFeatureRequest,
    QgsSingleSymbolRenderer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingUtils,
    QgsVectorLayerJoinInfo,
    QgsProcessingParameterFile,
    QgsLineSymbol,
    QgsVectorLayer,
    QgsField,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterFeatureSink
)
from qgis.PyQt.QtCore import QVariant, QCoreApplication
from PyQt5.QtCore import QSettings

import os, shutil, processing, glob
import pandas as pd
import re

class Create_Daily_shp_Merge_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('조사등록폴더', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '주차 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ADD_TO_CANVAS',
                    '병합 파일 화면에 추가',
                    defaultValue = False
                )
            )

        self.addParameter(
                QgsProcessingParameterVectorLayer(
                    'RTM_SHP', 
                    '취합 원본 SHP', 
                    types=[QgsProcessing.TypeVectorLine],
                    optional=True  # 선택 입력으로 설정
                )
            )

        self.addParameter(
                QgsProcessingParameterBoolean(
                    'RTM_ADD',
                    '원본 파일에 조사결과 취합',
                    defaultValue = True
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFeatureSink(
                    'Ok', 
                    'ML_ID 매칭', 
                    type=QgsProcessing.TypeVectorAnyGeometry, 
                    createByDefault=False, 
                    supportsAppend=True, 
                    defaultValue=None
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFeatureSink(
                    'Ng', 
                    'ML_ID 비매칭', 
                    type=QgsProcessing.TypeVectorAnyGeometry, 
                    createByDefault=True, 
                    supportsAppend=True, 
                    defaultValue=None
                )
            )

    def processAlgorithm(self, parameters, context, model_feedback):

        # ——— 출력 레이어 이름 고정 ———
        parameters['Ng'].destinationName  = 'ML_ID 비매칭'
        parameters['Ok'].destinationName  = 'ML_ID 매칭'

        input_Folder = self.parameterAsFile(parameters, '1', context)
        weekNum = input_Folder.split('\\')[-1]
        self.Qsettings.setValue('조사등록폴더', input_Folder)

        # 사용자의 체크박스 선택값 읽기
        add_to_canvas = self.parameterAsBool(parameters, 'ADD_TO_CANVAS', context)

        # 원본 shp 가져오기
        rtm_shp = self.parameterAsVectorLayer(parameters, 'RTM_SHP', context)
        # 원본 파일에 조사결과 취합 선택값 읽기
        add_to_rtm = self.parameterAsBool(parameters, 'RTM_ADD', context)

        m = re.match(r'\d+년(\d+)월(\d+)주', weekNum)
        month = int(m.group(1))
        week  = int(m.group(2))
        complete = month * 10 + week

        # 총 14단계로 늘립니다 (기존 7 + 추가 7)
        feedback = QgsProcessingMultiStepFeedback(52, model_feedback)
        result_val = []
        # 1. 하위 모든 SHP 경로 수집
        chk = 0
        for subFolder in os.listdir(input_Folder):
            results = {}
            outputs = {}
            subFolder_Path = os.path.join(input_Folder, subFolder)
            fileName =f'{weekNum}_{subFolder}_조사등록'
            result_path = f'{input_Folder}/{fileName}.shp'
            result_merge_path = f'{input_Folder}/{weekNum}_조사등록.shp'

            if not os.path.isdir(subFolder_Path):
                continue
            all_shp_paths = None
            all_shp_paths = []
            for logFolder in os.listdir(subFolder_Path):
                logFolder_Path = os.path.join(subFolder_Path, logFolder)
                if not os.path.isdir(logFolder_Path):
                    continue
                shp_files = glob.glob(os.path.join(logFolder_Path, '*.shp'))
                for shp_path in shp_files:
                    layer = QgsVectorLayer(shp_path, os.path.basename(shp_path), 'ogr')
                    if not layer.isValid():
                        model_feedback.pushInfo(f"레이어 로딩 실패: {shp_path}")
                        continue

                    delete_fields = []
                    for field in layer.fields():
                        if field.name().lower() in ['path', 'layer']:
                            delete_fields.append(field.name())

                    if delete_fields:
                        with edit(layer):
                            for field_name in delete_fields:
                                idx = layer.fields().indexFromName(field_name)
                                if idx != -1:
                                    layer.deleteAttribute(idx)
                        layer.updateFields()
                        layer.commitChanges()

                all_shp_paths.extend(shp_files)

            if not all_shp_paths:
                chk = 21
                model_feedback.pushInfo(f'{subFolder}에 병합할 SHP 파일이 없습니다.')
                continue


            # 0. SHX/DBF/PRJ 파일 유무 체크
            missing = []
            for shp_path in all_shp_paths:
                base, _ = os.path.splitext(shp_path)
                shx = base + '.shx'
                dbf = base + '.dbf'
                prj = base + '.prj'
                # 필요한 파일만 검사하거나, 원하는 확장자를 추가하세요
                for f in (shx, dbf, prj):
                    if not os.path.exists(f):
                        missing.append(f)
            if missing:
                # 오류로 처리할지, 안내만 할지는 상황에 맞게 선택
                model_feedback.reportError(
                    '다음 파일이 누락되어 병합이 불가능합니다:\n' +
                    '\n'.join(sorted(set(missing)))
                )
                return {}  # 병합 중단

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS': None,
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs['1'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1 + chk)
            if feedback.isCanceled():
                return {}
            
            # 2_필드 계산기 LOG_NAME
            split_index = len(all_shp_paths[0].split('\\')) - 2
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '로그명_',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f"string_to_array( \"path\" ,'\\\\')[{split_index}]",
                'INPUT': outputs['1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            # 2_1 필드 계산기 조사담당
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': '조사담당_',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f'substr( "로그명_", strpos( "로그명_" ,\'(\') + 1, 2)',
                'INPUT': outputs['2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2_1'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2 + chk)
            if feedback.isCanceled():
                return {}
            
            # 3_필드 계산기 차수
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '차수_',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f'left("layer",1)',
                'INPUT': outputs['2_1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3 + chk)
            if feedback.isCanceled():
                return {}

            # 4_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['3']['OUTPUT'],
                'OUTPUT':  'memory:'
            }
            outputs['4'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4 + chk)
            if feedback.isCanceled():
                return {}
    
            # 5_중복 도형 삭제
            alg_params = {
                'INPUT': outputs['4']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['5'] = processing.run('native:deleteduplicategeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5 + chk)
            if feedback.isCanceled():
                return {}

            # 6_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'LEN_',
                'FIELD_PRECISION': 3,
                'FIELD_TYPE': 0,  # 텍스트 (string)
                'FORMULA': "Length(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000",
                'INPUT': outputs['5']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['6'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6 + chk)
            if feedback.isCanceled():
                return {}

            # 7_좌표계 수정
            alg_params = {
                'INPUT': outputs['6']['OUTPUT'],
                'OPERATION': '',
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:4326'),
                'OUTPUT': 'memory:' 
            }
            outputs['7'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7 + chk)
            if feedback.isCanceled():
                return {}

            # 7_필드명 대문자 변경
            # 1) 방금 저장된 shapefile 레이어를 불러옵니다.
            # 메모리로 반환된 레이어 객체를 바로 사용
            final_layer = QgsProcessingUtils.mapLayerFromString(
                outputs['7']['OUTPUT'],
                context
            )
            # final_layer = QgsVectorLayer(result_path, fileName, 'ogr')
            if not final_layer.isValid():
                model_feedback.reportError('결과 레이어 로드에 실패했습니다.')
                return {}

            # 2) 필드 인덱스와 대문자 이름을 매핑합니다.
            provider = final_layer.dataProvider()
            rename_map = {}
            for idx, field in enumerate(final_layer.fields()):
                upper_name = field.name().upper()
                if field.name() != upper_name:
                    rename_map[idx] = upper_name

            # 3) 실제로 이름을 변경하고 필드 구조를 갱신합니다.
            if rename_map:
                provider.renameAttributes(rename_map)
                final_layer.updateFields()

            # 필드 이름으로 인덱스 조회 (없으면 필드생성)
            field_idx = final_layer.fields().indexOf('ROADKIND')

            if field_idx == -1:
                # 2) ROADKIND 필드가 없으면 추가
                new_field = QgsField('ROADKIND', QVariant.Int,  typeName='integer', len=10)
                provider.addAttributes([new_field])
                final_layer.updateFields()
                feedback.pushWarning(f"'ROADKIND' 필드를 새로 추가했습니다.")

            #  필드 이름으로 인덱스 조회 (없으면 필드생성)
            field_idx = final_layer.fields().indexOf('ML_ID')

            if field_idx == -1:
                # 2) ROADKIND 필드가 없으면 추가
                new_field = QgsField('ML_ID', QVariant.String,  typeName='varchar', len=50)
                provider.addAttributes([new_field])
                final_layer.updateFields()
                feedback.pushWarning(f"'ML_ID' 필드를 새로 추가했습니다.")

            # ------------------------------------------------------------
            # 여기서부터 두 번째 알고리즘 (8~14단계)
            # ------------------------------------------------------------
            # 8단계: ROADKIND가 null인 것 추출
            
            outputs['8'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['7']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,        # is null
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 9단계: ROADKIND 계산 (ROAD_KIND 값 복사)
            feedback.setCurrentStep(8 + chk)
            if feedback.isCanceled():
                return {}
            outputs['9'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['8']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,      # Integer
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROAD_KIND"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 10단계: null 남은 것 다시 추출
            feedback.setCurrentStep(9 + chk)
            if feedback.isCanceled():
                return {}
            outputs['10'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['9']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 11단계: ROADKIND 계산 (ROAD_CATE 값 복사)
            feedback.setCurrentStep(10 + chk)
            if feedback.isCanceled():
                return {}
            outputs['11'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['10']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROAD_CATE"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 12단계: 또 null 추출
            feedback.setCurrentStep(11 + chk)
            if feedback.isCanceled():
                return {}
            outputs['12'] = processing.run(
                'native:extractbyattribute',
                    {
                        'INPUT': outputs['11']['OUTPUT'],
                        'FIELD': 'ROADKIND',
                        'OPERATOR': 8,
                        'VALUE': '',
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 13단계: ROADKIND 계산 (ROADCATE 값 복사)
            feedback.setCurrentStep(12 + chk)
            if feedback.isCanceled():
                return {}
            outputs['13'] = processing.run(
                'native:fieldcalculator',
                    {
                        'INPUT': outputs['12']['OUTPUT'],
                        'FIELD_NAME': 'ROADKIND',
                        'FIELD_TYPE': 1,
                        'FIELD_LENGTH': 10,
                        'FORMULA': '"ROADCATE"',
                        'OUTPUT': 'memory:'
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            # 14단계: 네 개 레이어 최종 병합
            feedback.setCurrentStep(13 + chk)
            if feedback.isCanceled():
                return {}
            outputs['14'] = processing.run(
                'native:mergevectorlayers',
                    {
                        'LAYERS': [
                            outputs['8']['FAIL_OUTPUT'],
                            outputs['10']['FAIL_OUTPUT'],
                            outputs['12']['FAIL_OUTPUT'],
                            outputs['13']['OUTPUT']
                        ],
                        'CRS': None,
                        'OUTPUT': 'memory:'  # 또는 원하는 출력 파라미터
                    },
                context=context, feedback=feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(14 + chk)
            if feedback.isCanceled():
                return {}

            # 4_필드 삭제
            outputs['15'] = processing.run(
                'native:deletecolumn', 
                    {
                        'COLUMN': ['layer','path'],
                        'INPUT': outputs['14']['OUTPUT'],
                        'OUTPUT': 'memory:'
                    }, 
                context=context, feedback=feedback, is_child_algorithm=True
            )

            feedback.setCurrentStep(15 + chk)
            if feedback.isCanceled():
                return {}
            
            # ------------------------------------------------------------
            # 여기서부터 두 번째 알고리즘 (16~19단계)
            # ------------------------------------------------------------

            # 16단계: ML_ID가 null인 것 추출
            outputs['16'] = processing.run(
                'native:extractbyexpression', 
                    {
                        'EXPRESSION': '"ML_ID" is Null and  "LINK_ID" is not Null and  "LINK_MAP_I" is not Null',
                        'INPUT': outputs['15']['OUTPUT'],
                        'FAIL_OUTPUT': 'memory:',
                        'OUTPUT': 'memory:'
                    }, 
                context=context, feedback=feedback, is_child_algorithm=True
            )
            
            feedback.setCurrentStep(16 + chk)
            if feedback.isCanceled():
                return {}

            # 17단계: ML_ID 계산
            outputs['17'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['16']['OUTPUT'],
                    'FIELD_NAME': 'ML_ID',
                    'FIELD_TYPE': 1,      # Integer
                    'FIELD_LENGTH': 10,
                    'FORMULA': '"LINK_MAP_I"||\'_\'||"LINK_ID"',
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True      
            )
            
            feedback.setCurrentStep(17 + chk)
            if feedback.isCanceled():
                return {}

            # 18단계: 병합
            outputs['18'] = processing.run(
                'native:mergevectorlayers', 
                {
                    'CRS': None,
                    'LAYERS': [outputs['16']['FAIL_OUTPUT'],outputs['17']['OUTPUT']],
                    'OUTPUT': 'memory:'
                }, 
                context=context, feedback=feedback, is_child_algorithm=True
            )
            
            feedback.setCurrentStep(18 + chk)
            if feedback.isCanceled():
                return {}
            
            # 19_필드 삭제
            outputs['19'] = processing.run(
                'native:deletecolumn', 
                    {
                        'COLUMN': ['layer','path'],
                        'INPUT': outputs['18']['OUTPUT'],
                        'OUTPUT':  'memory:'
                    }, 
                context=context, feedback=feedback, is_child_algorithm=True
            )
            
            feedback.setCurrentStep(19 + chk)
            if feedback.isCanceled():
                return {}
            
            # 20단계: 완료주차 계산
            outputs['20'] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['19']['OUTPUT'],
                    'FIELD_NAME': '완료_',
                    'FIELD_TYPE': 1,      # Integer
                    'FIELD_LENGTH': 10,
                    'FORMULA': complete,
                    'OUTPUT': 'memory:'
                },
                context=context, feedback=feedback, is_child_algorithm=True      
            )
            
            feedback.setCurrentStep(20 + chk)
            if feedback.isCanceled():
                return {}
            
            # 21단계: 조사구분 계산
            outputs[subFolder] = processing.run(
                'native:fieldcalculator',
                {
                    'INPUT': outputs['20']['OUTPUT'],
                    'FIELD_NAME': '구분_',
                    'FIELD_TYPE': 2,    
                    'FIELD_LENGTH': 10,
                    'FORMULA': f"'{subFolder}'",
                    'OUTPUT': result_path
                },
                context=context, feedback=feedback, is_child_algorithm=True      
            )
            
            feedback.setCurrentStep(21 + chk)
            if feedback.isCanceled():
                return {}
            
            chk = 21

            feedback.pushWarning(f"조사등록파일 취합완료 : {result_path}")
            result_val.append(outputs[subFolder]['OUTPUT'])

            # # 조건에 따라 레이어 로드
            # if add_to_canvas and os.path.exists(result_path):
            #     result_layer = QgsVectorLayer(result_path, f'{fileName}', 'ogr')
            #     if result_layer.isValid():
            #         QgsProject.instance().addMapLayer(result_layer)
            #     else:
            #         feedback.reportError('결과 레이어가 유효하지 않습니다.')


        # 22단계: 병합
        outputs['22'] = processing.run(
            'native:mergevectorlayers', 
            {
                'CRS': None,
                'LAYERS': result_val,
                'OUTPUT': 'memory:'
            }, 
            context=context, feedback=feedback, is_child_algorithm=True
        )
        
        feedback.setCurrentStep(22 + chk)
        if feedback.isCanceled():
            return {}
        
        # 23_필드 삭제
        outputs['23'] = processing.run(
            'native:deletecolumn', 
                {
                    'COLUMN': ['layer','path'],
                    'INPUT': outputs['22']['OUTPUT'],
                    'OUTPUT': 'memory:',
                }, 
            context=context, feedback=feedback, is_child_algorithm=True
        )

        feedback.setCurrentStep(23 + chk)
        if feedback.isCanceled():
            return {}
        
        alg_params = {
            'ASCENDING': True,
            'EXPRESSION': ' "로그명_" ||\'_\'|| "차수_" ||\'_\'|| "ROADKIND" ||\'_\'|| "ML_ID"',
            'INPUT': outputs['23']['OUTPUT'],
            'NULLS_FIRST': False,
            'OUTPUT': 'memory:',
        }
        outputs['24'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(24 + chk)
        if feedback.isCanceled():
            return {}

        alg_params = {
            'FIELDS': ['ML_ID','ROADKIND','로그명_','LEN_'],
            'INPUT': outputs['24']['OUTPUT'],
            'DUPLICATES': 'memory:',
            'OUTPUT': result_merge_path
        }
        outputs['25'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(25 + chk)
        if feedback.isCanceled():
            return {}

        # 조건에 따라 레이어 로드
        if add_to_canvas and os.path.exists(result_merge_path):
            result_layer = QgsVectorLayer(result_merge_path, f'{weekNum}_조사등록', 'ogr')
            if result_layer.isValid():
                QgsProject.instance().addMapLayer(result_layer)
            else:
                feedback.reportError('결과 레이어가 유효하지 않습니다.')
                return {}
            
        feedback.setCurrentStep(26 + chk)
        if feedback.isCanceled():
            return {}
        
        # 원본 파일에 조사결과 취합
        if add_to_rtm and rtm_shp:
            # 필드 값으로 속성 결합  
            alg_params = {
                'INPUT': outputs['25']['OUTPUT'],
                'FIELD': 'ml_id',
                'INPUT_2': rtm_shp,
                'FIELD_2': 'ml_id',
                'FIELDS_TO_COPY': ['1'], # 복사할 레이어
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'DISCARD_NONMATCHING': True, # 결합할 수 없는 레코드 버리기
                'PREFIX': '',
                'OUTPUT': parameters['Ok'],
                'NON_MATCHING': parameters['Ng']
            }
            outputs['26'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            results['OUTPUT'] = outputs['26']['OUTPUT']
            results['NON_MATCHING'] = outputs['26']['NON_MATCHING']

            feedback.setCurrentStep(27 + chk)
            if feedback.isCanceled():
                return {}

            NG_result = QgsLineSymbol.createSimple({
                'color': '255,0,0',
                'width': '3'
            })

            OK_result = QgsLineSymbol.createSimple({
                'color': '50,180,60',
                'width': '1'
            })

            # context에서 레이어 객체 꺼내오기
            OK_layer = context.getMapLayer(results['OUTPUT'])
            NG_layer = context.getMapLayer(results['NON_MATCHING'])

            # 렌더러 교체
            OK_layer.setRenderer(QgsSingleSymbolRenderer(OK_result))
            NG_layer.setRenderer(QgsSingleSymbolRenderer(NG_result))

            # 맵 캔버스 갱신
            OK_layer.triggerRepaint()
            NG_layer.triggerRepaint()
            
            feedback.setCurrentStep(28 + chk)

            # 1) 조인 결과 레이어 불러오기
            join_layer = QgsProcessingUtils.mapLayerFromString(
                outputs['24']['OUTPUT'], context
            )

            # 2) 원본 rtm_shp 레이어의 data provider 가져오기
            provider = rtm_shp.dataProvider()

            # 3) 필드 인덱스 조회
            idx_complete  = rtm_shp.fields().indexOf('완료')
            idx_log       = rtm_shp.fields().indexOf('로그명')
            idx_survey    = rtm_shp.fields().indexOf('차수')
            idx_center    = rtm_shp.fields().indexOf('조사담당')

            # 1) join_layer 에서 ML_ID → (완료_, 로그명_, 차수_, 조사담당_) 매핑 생성
            join_map = {
                feat['ML_ID']: (feat['완료_'], feat['로그명_'], feat['차수_'], feat['조사담당_'])
                for feat in join_layer.getFeatures()
                if feat['ML_ID'] is not None
            }

            feedback.setCurrentStep(29 + chk)

            # 2) ML_ID 목록 추출
            ml_ids = list(join_map.keys())

            if ml_ids:
                # 3) IN 연산자로 한 번에 필터 표현식 생성
                #    'A','B','C' 형태로 묶이도록 join
                quoted = ", ".join(f"'{x}'" for x in ml_ids)
                expr = f"\"ML_ID\" IN ({quoted})"

                # 4) 한 번의 FeatureRequest 로 PostGIS 레이어에서 필요한 피처만 조회
                req = QgsFeatureRequest().setFilterExpression(expr)

                # 5) 배치 업데이트용 changes dict 생성
                changes = {}

                feedback.pushInfo("\n완료 주차를 입력합니다.\n")

                getFeatures = rtm_shp.getFeatures(req)

                for i, target in enumerate(getFeatures):
                    completed, log_name, survey,  center = join_map[target['ML_ID']]
                    changes[target.id()] = {
                        idx_complete: completed,
                        idx_log     : log_name,
                        idx_survey  : survey,
                        idx_center  : center
                    }

                feedback.setCurrentStep(30 + chk)

                # 6) 한 번에 속성 값 변경
                if changes:
                    provider = rtm_shp.dataProvider()
                    provider.changeAttributeValues(changes)
                    rtm_shp.triggerRepaint()

            else:
                feedback.pushInfo("\n조인할 ML_ID가 없습니다.\n")

            feedback.setCurrentStep(31 + chk)
            return results
        
        else:
            feedback.setCurrentStep(31 + chk)
            return{}
    
    def tr(self, string):
        return QCoreApplication.translate("Create_Daily_shp_Merge_Algorithm", string)
    
    def name(self):
        return '조사등록SHP_병합'

    def displayName(self):
        return '조사등록SHP_병합'

    # def group(self):
    #     return 'wkt_geom_TO_shp'

    # def groupId(self):
    #     return 'wkt_geom_TO_shp'

    def shortHelpString(self):
        return self.tr("지정 폴더에 있는 조사등록 SHP을 병합 합니다.")

    def createInstance(self):
        return Create_Daily_shp_Merge_Algorithm()