from qgis.core import (
    QgsProject,
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsProcessingFeedback,
    QgsProcessingParameterFile,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterDefinition,  # ⬅ (선택) 고급옵션 설정용
)
from qgis.PyQt.QtCore import QVariant

from PyQt5.QtCore import QSettings

import os, processing, glob
import pandas as pd
import re

class Processes_Import_shp_files_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    BASE_DIR    = 'BASE_DIR'
    UNIT        = 'UNIT'
    FIELD_NAME  = 'FIELD_NAME'   # 자동 증가 필드 이름
    START_VALUE = 'START_VALUE'  # 시작 값
    STEP_VALUE  = 'STEP_VALUE'   # 증가 값
    
    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('파일수집폴더', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    self.BASE_DIR,
                    '📁 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                '⚙️파일 취합 후 처리',
                options=['병합', '자동 증가 필드 추가', '레이어에 추가', '리스트 추출'],
                defaultValue=0
            )
        )

        # 📌 자동 증가 필드 이름 (기본값: AUTO_ID)
        field_param = QgsProcessingParameterString(
            self.FIELD_NAME,
            '📌 자동 증가 필드 이름',
            defaultValue='AUTO_ID',
            optional=True,
        )

        # (선택) 고급 옵션으로 숨기고 싶으면:
        field_param.setFlags(field_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)

        self.addParameter(field_param)

        # 🔢 시작 값 (기본: 1)
        start_param = QgsProcessingParameterNumber(
            self.START_VALUE,
            '🔢 시작 값',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1,
            optional=True
        )
        start_param.setFlags(start_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(start_param)

        # 🔢 증가 값 (기본: 1)
        step_param = QgsProcessingParameterNumber(
            self.STEP_VALUE,
            '🔢 증가 값',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1,
            optional=True
        )
        step_param.setFlags(step_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(step_param)

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
        mode         = self.parameterAsEnum(parameters, self.UNIT, context)
        
        # 필드 이름 파라미터 (기본값 AUTO_ID)
        field_name   = self.parameterAsString(parameters, self.FIELD_NAME, context)
        if not field_name:
            field_name = "AUTO_ID"

        # 시작 값 (기본 1)
        start_value = self.parameterAsInt(parameters, self.START_VALUE, context)
        if start_value is None:
            start_value = 1

        # 증가 값 (기본 1, 0은 허용 X)
        step_value = self.parameterAsInt(parameters, self.STEP_VALUE, context)
        if step_value is None or step_value == 0:
            model_feedback.pushWarning("⚠️ 증가 값이 0이어서 1로 대체합니다.")
            step_value = 1

        self.Qsettings.setValue('파일수집폴더', input_Folder)

        all_shp_paths = None
        all_shp_paths = []

        results = {}
        outputs = {}

        silent_feedback = QgsProcessingFeedback()

        # **를 사용하고 recursive=True 옵션을 주면 하위 폴더까지 탐색합니다.
        # shp_files = glob.glob(os.path.join(input_Folder, '**', '*.shp'), recursive=True)

        shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))

        model_feedback.pushWarning(f"🧺{input_Folder} SHP 취합완료")
        all_shp_paths.extend(shp_files)

        results['shp'] = all_shp_paths

        if model_feedback.isCanceled():
            return {}
        
        if mode == 0:
            # 벡터 레이어 병합
            alg_params = {
                'CRS': None,
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs = processing.run('native:mergevectorlayers', alg_params)

            if model_feedback.isCanceled():
                return {}

            stats_layer = outputs['OUTPUT']
            stats_layer.setName(f"병합한 레이어")
            QgsProject.instance().addMapLayer(stats_layer)
            model_feedback.pushWarning(f"🔹파일 취합후 병합 완료")
        if mode == 1:
            # 자동 증가 필드 추가
            auto_field_name = field_name

            for path in shp_files:
                layer_name = os.path.basename(path)
                vl = QgsVectorLayer(path, layer_name, 'ogr')

                if not vl.isValid():
                    model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
                    continue

                prov = vl.dataProvider()

                # 이미 AUTO_ID 필드가 있는지 확인
                idx = vl.fields().indexOf(auto_field_name)
                if idx < 0:
                    # 없으면 필드 추가
                    prov.addAttributes([QgsField(auto_field_name, QVariant.Int)])
                    vl.updateFields()
                    idx = vl.fields().indexOf(auto_field_name)

                if idx < 0:
                    model_feedback.pushWarning(f"⚠️ {layer_name} 에 {auto_field_name} 필드를 추가하지 못했습니다.")
                    continue

                # 편집 시작
                if not vl.isEditable():
                    vl.startEditing()

                # 📌 각 레이어마다 동일한 시작 값에서 시작
                current_value = start_value

                for feat in vl.getFeatures():
                    feat[idx] = current_value
                    vl.updateFeature(feat)
                    current_value += step_value

                    if model_feedback.isCanceled():
                        vl.rollBack()
                        return {}

                # 변경 내용 commit
                if not vl.commitChanges():
                    model_feedback.pushWarning(f"⚠️ {layer_name} 의 변경사항 저장 실패")
                else:
                    count = vl.featureCount()
                    model_feedback.pushWarning(
                        f"🔹 {layer_name} 에 {auto_field_name} 필드 추가 및 순번 부여 완료 "
                        f"(총 {count}개, 시작={start_value}, 증가={step_value})"
                    )

        if mode == 2:
            # mode 1: 수집된 shapefile을 각각 레이어로 추가
            for path in shp_files:
                layer_name = os.path.basename(path)
                vl = QgsVectorLayer(path, layer_name, 'ogr')
                if not vl.isValid():
                    model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
                    continue
                QgsProject.instance().addMapLayer(vl)
            model_feedback.pushWarning("🔹 모든 SHP 레이어 추가 완료")
        if mode == 3:
            # mode 2: 파일 경로 리스트만 속성 테이블 형태로 추가
            # Geometry-less 메모리 레이어 생성
            table_layer = QgsVectorLayer("None", "SHP 파일 목록", "memory")
            prov = table_layer.dataProvider()
            prov.addAttributes([QgsField("path", QVariant.String)])
            table_layer.updateFields()
            
            feats = []
            for path in shp_files:
                feat = QgsFeature(table_layer.fields())
                feat["path"] = path
                feats.append(feat)
            prov.addFeatures(feats)
            QgsProject.instance().addMapLayer(table_layer)
            model_feedback.pushWarning("🔹 SHP 파일 목록 테이블 추가 완료")

        return {}

    def name(self):
        return '폴더 내 SHP파일 수집'

    def displayName(self):
        return '폴더 내 SHP파일 수집'

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "파일 관리"
    
    def shortHelpString(self):
        return "지정 폴더에 있는 SHP를 가져와 처리합니다."

    def createInstance(self):
        return Processes_Import_shp_files_Algorithm()