from qgis.core import (
    QgsProject,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsProcessingFeedback,
    QgsProcessingParameterFile,
    QgsProcessingParameterBoolean,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterDefinition,   # ⬅ (선택) 고급옵션 설정용
    QgsExpression,                      # ⬅ 추가 필드계산식
    QgsExpressionContext,               # ⬅ 추가 필드계산식
    QgsExpressionContextUtils,          # ⬅ 추가 필드계산식
    QgsProcessingParameterExpression,   # ⬅ 추가 필드계산식
)
from qgis.PyQt.QtCore import QVariant

from PyQt5.QtCore import QSettings

import os, processing, glob
import pandas as pd
import re
    
class Processes_merge_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    BASE_DIR    = 'BASE_DIR'
    INCLUDE_SUBDIRS = 'INCLUDE_SUBDIRS'   # ⬅ 하위 폴더 포함 여부

    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('SHP파일 수집 폴더', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    self.BASE_DIR,
                    '📁 수집 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        # ✅ 하위 폴더 포함 체크박스
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_SUBDIRS,
                '하위 폴더까지 탐색',
                defaultValue=False
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
        include_subdirs = self.parameterAsBool(parameters, self.INCLUDE_SUBDIRS, context)

        self.Qsettings.setValue('SHP파일 수집 폴더', input_Folder)

        all_shp_paths = []

        # ─────────────────────────────────────
        # 1) SHP 파일 수집 (하위 폴더 여부에 따라 분기)
        # ─────────────────────────────────────
        if include_subdirs:
            # 하위 폴더까지 전부 탐색
            for root, dirs, files in os.walk(input_Folder):
                for f in files:
                    if f.lower().endswith('.shp'):
                        all_shp_paths.append(os.path.join(root, f))
            model_feedback.pushWarning(
                f"🧺 {input_Folder} 및 하위 폴더에서 SHP {len(all_shp_paths)}개 수집 완료"
            )
        else:
            # 현재 폴더만
            shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))
            all_shp_paths.extend(shp_files)
            model_feedback.pushWarning(
                f"🧺 {input_Folder}에서 SHP {len(all_shp_paths)}개 수집 완료"
            )

        # 파일이 하나도 없으면 종료
        if not all_shp_paths:
            model_feedback.pushWarning("⚠️ 병합할 SHP 파일이 없습니다.")
            return {}

        if model_feedback.isCanceled():
            return {}
        
        # ─────────────────────────────────────
        # 2) 벡터 레이어 병합
        # ─────────────────────────────────────
        alg_params = {
            'CRS': None,
            'LAYERS': all_shp_paths,
            'OUTPUT': 'memory:'
        }
        outputs = processing.run('native:mergevectorlayers', alg_params)

        if model_feedback.isCanceled():
            return {}

        stats_layer = outputs['OUTPUT']
        stats_layer.setName(f"병합한 레이어")
        count = len(all_shp_paths)
        QgsProject.instance().addMapLayer(stats_layer)
        model_feedback.pushWarning(f"✅ {count}개 파일 취합후 병합 완료")

        return {}

    def name(self):
        return '1.SHP파일 병합'

    def displayName(self):
        return '1.SHP파일 병합'

    def group(self):
        return "폴더 내 SHP파일 수집"

    def groupId(self):
        return "폴더 내 SHP파일 수집"
    
    def shortHelpString(self):
        return "지정한 폴더(및 선택 시 하위 폴더)의 모든 SHP 파일을 병합한 결과를 출력합니다."

    def createInstance(self):
        return Processes_merge_Algorithm()
    
class Processes_autoIncremental_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    BASE_DIR    = 'BASE_DIR'
    INCLUDE_SUBDIRS = 'INCLUDE_SUBDIRS'   # ⬅ 하위 폴더 포함 여부

    FIELD_NAME  = 'FIELD_NAME'   # 자동 증가 필드 이름
    START_VALUE = 'START_VALUE'  # 시작 값
    STEP_VALUE  = 'STEP_VALUE'   # 증가 값

    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('SHP파일 수집 폴더', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    self.BASE_DIR,
                    '📁 수집 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        # ✅ 하위 폴더 포함 체크박스
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_SUBDIRS,
                '하위 폴더까지 탐색',
                defaultValue=False
            )
        )

        # 📌 자동 증가 필드 이름 (기본값: AUTO_ID)
        field_param = QgsProcessingParameterString(
            self.FIELD_NAME,
            '📌 자동 증가 필드 이름',
            defaultValue='AUTO_ID',
            optional=True,
        )

        # (선택) 고급 옵션으로 숨기고 싶으면:
        # ield_param.setFlags(field_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(field_param)

        # 🔢 시작 값 (기본: 1)
        start_param = QgsProcessingParameterNumber(
            self.START_VALUE,
            '🔷 시작 값',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1,
            optional=True
        )
        # start_param.setFlags(start_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(start_param)

        # 🔢 증가 값 (기본: 1)
        step_param = QgsProcessingParameterNumber(
            self.STEP_VALUE,
            '➕ 증가 값',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1,
            optional=True
        )
        # step_param.setFlags(step_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(step_param)

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
        include_subdirs = self.parameterAsBool(parameters, self.INCLUDE_SUBDIRS, context)

        
        # 필드 이름 파라미터 (기본값 AUTO_ID)
        field_name   = self.parameterAsString(parameters, self.FIELD_NAME, context)
        if not field_name:
            field_name = "AUTO_ID"

        # 시작 값 (기본 1)
        start_value = self.parameterAsInt(parameters, self.START_VALUE, context)
        if start_value is None:
            start_value = 1

        # 증가 값 (기본 1, 0은 허용 X)
        step_value = self.parameterAsInt(parameters, self.STEP_VALUE, context)
        if step_value is None or step_value == 0:
            model_feedback.pushWarning("⚠️ 증가 값이 0이어서 1로 대체합니다.")
            step_value = 1

        self.Qsettings.setValue('SHP파일 수집 폴더', input_Folder)

        all_shp_paths = []
        results = {}

        # ─────────────────────────────────────
        # 1) SHP 파일 수집 (하위 폴더 여부에 따라 분기)
        # ─────────────────────────────────────
        if include_subdirs:
            # 하위 폴더까지 전부 탐색
            for root, dirs, files in os.walk(input_Folder):
                for f in files:
                    if f.lower().endswith('.shp'):
                        all_shp_paths.append(os.path.join(root, f))
            model_feedback.pushWarning(
                f"🧺 {input_Folder} 및 하위 폴더에서 SHP {len(all_shp_paths)}개 수집 완료"
            )
        else:
            # 현재 폴더만
            shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))
            all_shp_paths.extend(shp_files)
            model_feedback.pushWarning(
                f"🧺 {input_Folder}에서 SHP {len(all_shp_paths)}개 수집 완료"
            )

        # 파일이 하나도 없으면 종료
        if not all_shp_paths:
            model_feedback.pushWarning("⚠️ 병합할 SHP 파일이 없습니다.")
            return {}

        if model_feedback.isCanceled():
            return {}
        
        # 자동 증가 필드 추가
        auto_field_name = field_name

        for path in all_shp_paths:
            # ✅ 취소 버튼 눌리면 즉시 전체 알고리즘 중단
            if model_feedback.isCanceled():
                model_feedback.pushWarning("⏹ 사용자가 알고리즘을 취소했습니다.")
                return {}
            
            layer_name = os.path.basename(path)
            vl = QgsVectorLayer(path, layer_name, 'ogr')

            if not vl.isValid():
                model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
                continue

            prov = vl.dataProvider()

            # 대상 필드 존재 여부 확인
            fields = vl.fields()
            idx = fields.indexOf(auto_field_name)

            if idx < 0:
                new_field = QgsField(auto_field_name, QVariant.Int, None, 10)
                # 없으면 필드 추가
                if not prov.addAttributes([new_field]):
                    model_feedback.pushWarning(
                        f"⚠️ {layer_name} 에 {auto_field_name} 필드를 추가하지 못했습니다."
                    )
                    continue

                vl.updateFields()
                idx = vl.fields().indexOf(auto_field_name)

            if idx < 0:
                model_feedback.pushWarning(f"⚠️ {layer_name} 에 {auto_field_name} 필드를 생성/찾지 못했습니다.")
                continue

            # 📌 각 레이어마다 동일한 시작 값에서 시작
            current_value = start_value
            changes = {}  # { fid: { idx: new_value } }

            for feat in vl.getFeatures():
                # ✅ 취소 버튼 눌리면 즉시 전체 알고리즘 중단
                if model_feedback.isCanceled():
                    model_feedback.pushWarning("⏹ 사용자가 알고리즘을 취소했습니다.")
                    return {}
                
                changes[feat.id()] = {idx: current_value}
                # feat[idx] = current_value
                # vl.updateFeature(feat)
                current_value += step_value

            # ✅ 한 번에 변경 적용 (레이어 메서드 사용)
            if not prov.changeAttributeValues(changes):
                model_feedback.pushWarning(
                    f"⚠️ {layer_name} 의 순번 부여 실패했습니다."
                )
            else:
                count = vl.featureCount()
                model_feedback.pushWarning(
                    f"✅ {layer_name} 에 {auto_field_name} 필드 추가 및 순번 부여 완료 "
                    f"(총 {count}개, 시작={start_value}, 증가={step_value})"
                )

        return {}

    def name(self):
        return '2.자동증가필드'

    def displayName(self):
        return '2.자동증가필드'

    def group(self):
        return "폴더 내 SHP파일 수집"

    def groupId(self):
        return "폴더 내 SHP파일 수집"
    
    def shortHelpString(self):
        return "지정한 폴더(및 선택 시 하위 폴더)의 모든 SHP 파일에 자동증가필드를 일괄 적용합니다."

    def createInstance(self):
        return Processes_autoIncremental_Algorithm()


class Processes_Calculator_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    BASE_DIR    = 'BASE_DIR'
    INCLUDE_SUBDIRS = 'INCLUDE_SUBDIRS'   # ⬅ 하위 폴더 포함 여부

    CALC_FIELD  = 'CALC_FIELD'   # 필드 계산 결과를 저장할 필드명
    CALC_EXPR   = 'CALC_EXPR'    # QGIS 표현식
    CALC_FIELD_TYPE = 'CALC_FIELD_TYPE'   # ⬅ 필드 타입 선택
    EXPR_LAYER = 'EXPR_LAYER'

    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('SHP파일 수집 폴더', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    self.BASE_DIR,
                    '📁 수집 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )

        # ✅ 하위 폴더 포함 체크박스
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_SUBDIRS,
                '하위 폴더까지 탐색',
                defaultValue=False
            )
        )

        # 📝 필드 계산 결과를 저장할 필드 이름 (기존 필드 또는 새 필드)
        calc_field_param = QgsProcessingParameterString(
            self.CALC_FIELD,
            '📝 필드 계산 대상 필드명 (기존/신규 공통)',
            optional=True
        )
        # calc_field_param.setFlags(calc_field_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(calc_field_param)

        # 🔠 필드 타입 선택 (정수 / 실수 / 문자열)
        calc_field_type_param = QgsProcessingParameterEnum(
            self.CALC_FIELD_TYPE,
            '🔠 새 필드 타입 (없을 때 생성 시)',
            options=['정수(Integer)', '실수(Real)', '문자열(String)'],
            defaultValue=1,   # 0: 정수, 1: 실수, 2: 문자열
            optional=True
        )
        # calc_field_type_param.setFlags(calc_field_type_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(calc_field_type_param)

        # # initAlgorithm 안에서
        # self.addParameter(
        #     QgsProcessingParameterVectorLayer(
        #         self.EXPR_LAYER,
        #         '표현식 미리보기용 레이어 (선택)',
        #         types=[QgsProcessing.TypeVectorAnyGeometry],
        #         optional=True
        #     )
        # )

        # 🧮 QGIS 표현식 (Expression 위젯 사용)
        calc_expr_param = QgsProcessingParameterExpression(
            self.CALC_EXPR,
            '⚙️ 필드 계산식 (QGIS 표현식)',
            parentLayerParameterName=self.EXPR_LAYER,   # ⬅ 여기
            defaultValue='',
            optional=True,
            # parentLayerParameterName=''   # 필요하다면 아래에서 설명
        )
        # calc_expr_param.setFlags(calc_expr_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(calc_expr_param)

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
        include_subdirs = self.parameterAsBool(parameters, self.INCLUDE_SUBDIRS, context)

        # 🔢 필드 계산기 파라미터 읽기
        calc_field = self.parameterAsString(parameters, self.CALC_FIELD, context)
        calc_expr  = self.parameterAsString(parameters, self.CALC_EXPR, context)

        # 🔠 새 필드 타입 (0: 정수, 1: 실수, 2: 문자열)
        calc_field_type_idx = self.parameterAsEnum(parameters, self.CALC_FIELD_TYPE, context)
        if calc_field_type_idx is None:
            calc_field_type_idx = 1   # 기본: 실수

        self.Qsettings.setValue('SHP파일 수집 폴더', input_Folder)

        all_shp_paths = []
        results = {}
        outputs = {}

        # ─────────────────────────────────────
        # 1) SHP 파일 수집 (하위 폴더 여부에 따라 분기)
        # ─────────────────────────────────────
        if include_subdirs:
            # 하위 폴더까지 전부 탐색
            for root, dirs, files in os.walk(input_Folder):
                for f in files:
                    if f.lower().endswith('.shp'):
                        all_shp_paths.append(os.path.join(root, f))
            model_feedback.pushWarning(
                f"🧺 {input_Folder} 및 하위 폴더에서 SHP {len(all_shp_paths)}개 수집 완료"
            )
        else:
            # 현재 폴더만
            shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))
            all_shp_paths.extend(shp_files)
            model_feedback.pushWarning(
                f"🧺 {input_Folder}에서 SHP {len(all_shp_paths)}개 수집 완료"
            )

        # 파일이 하나도 없으면 종료
        if not all_shp_paths:
            model_feedback.pushWarning("⚠️ 병합할 SHP 파일이 없습니다.")
            return {}

        if model_feedback.isCanceled():
            return {}
        

        if not calc_field or not calc_expr:
            model_feedback.pushWarning("⚠️ 필드계산기 모드에서는 '필드명'과 '표현식'을 모두 입력해야 합니다.")
            return {}

        expr = QgsExpression(calc_expr)
        if expr.hasParserError():
            model_feedback.reportError(f"❌ 표현식 구문 오류: {expr.parserErrorString()}")
            return {}

        for path in all_shp_paths:
            # ✅ 취소 버튼 눌리면 즉시 전체 알고리즘 중단
            if model_feedback.isCanceled():
                model_feedback.pushWarning("⏹ 사용자가 알고리즘을 취소했습니다.")
                return {}   
            layer_name = os.path.basename(path)
            vl = QgsVectorLayer(path, layer_name, 'ogr')

            if not vl.isValid():
                model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
                continue

            prov = vl.dataProvider()

            # 대상 필드 존재 여부 확인
            fields = vl.fields()
            idx = fields.indexOf(calc_field)

            # 없으면 새 필드 생성 (기본: Double)
            if idx < 0:
                # 선택된 타입에 따라 QVariant 타입 결정
                if calc_field_type_idx == 0:
                    new_field = QgsField(calc_field, QVariant.Int, None, 11)
                elif calc_field_type_idx == 1:
                    new_field = QgsField(calc_field, QVariant.Double, None, 20, 6)
                else:  # 2: 문자열
                    new_field = QgsField(calc_field, QVariant.String, None, 255)

                if not prov.addAttributes([new_field]):
                    model_feedback.pushWarning(
                        f"⚠️ {layer_name} 에 {calc_field} 필드를 추가하지 못했습니다."
                    )
                    continue

                vl.updateFields()
                fields = vl.fields()
                idx = fields.indexOf(calc_field)

                # model_feedback.pushWarning(f"✅ {layer_name} 에 {calc_field} 필드 생성완료.")

            if idx < 0:
                model_feedback.pushWarning(
                    f"⚠️ {layer_name} 에 {calc_field} 필드를 생성/찾지 못했습니다."
                )
                continue

            expr_context = QgsExpressionContext()
            expr_context.appendScopes(
                QgsExpressionContextUtils.globalProjectLayerScopes(vl)
            )

            layer_has_error  = False
            changes = {}  # { fid: { idx: new_value } }

            for feat in vl.getFeatures():
                # ✅ 취소 버튼 눌리면 즉시 전체 알고리즘 중단
                if model_feedback.isCanceled():
                    model_feedback.pushWarning("⏹ 사용자가 알고리즘을 취소했습니다.")
                    return {}                
                
                expr_context.setFeature(feat)
                value = expr.evaluate(expr_context)

                # ✅ 표현식 평가 오류 → 이 레이어만 건너뛰고 다음 파일 진행
                if expr.hasEvalError():
                    model_feedback.reportError(
                        f"❌ 표현식 평가 오류: 레이어={layer_name}, FID={feat.id()}, "
                        f"메시지={expr.evalErrorString()}"
                    )
                    layer_has_error  = True
                    break

                # vl.changeAttributeValue(feat.id(), idx, value)
                changes[feat.id()] = {idx: value}

            # 이 레이어에서 에러가 났다면, 변경사항은 provider에 아직 안 넘겼으므로
            # 그냥 건너뛰고 다음 레이어로
            if layer_has_error :
                model_feedback.pushWarning(
                    f"⚠️ {layer_name} 에서 오류가 발생하여 이 레이어는 건너뜁니다."
                )
                continue

            # ✅ 한 번에 변경 적용 (레이어 메서드 사용)
            if not prov.changeAttributeValues(changes):
                vl.rollBack()
                model_feedback.pushWarning(
                    f"⚠️ {layer_name} 의 필드 값 변경에 실패했습니다."
                )
            else:
                model_feedback.pushWarning(
                    f"✅ {layer_name} 필드 계산 완료: '{calc_field}' <- {calc_expr}"
                )

        return {}

    def name(self):
        return '3.필드계산기'

    def displayName(self):
        return '3.필드계산기'

    def group(self):
        return "폴더 내 SHP파일 수집"

    def groupId(self):
        return "폴더 내 SHP파일 수집"
    
    def shortHelpString(self):
        return "지정한 폴더(및 선택 시 하위 폴더)의 모든 SHP 파일에 필드 계산식을 일괄 적용합니다."

    def createInstance(self):
        return Processes_Calculator_Algorithm()
    


# class Processes_Import_shp_files_Algorithm(QgsProcessingAlgorithm):
#     Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

#     # 파라미터 키 정의
#     BASE_DIR    = 'BASE_DIR'
#     UNIT        = 'UNIT'

#     FIELD_NAME  = 'FIELD_NAME'   # 자동 증가 필드 이름
#     START_VALUE = 'START_VALUE'  # 시작 값
#     STEP_VALUE  = 'STEP_VALUE'   # 증가 값

#     CALC_FIELD  = 'CALC_FIELD'   # 필드 계산 결과를 저장할 필드명
#     CALC_EXPR   = 'CALC_EXPR'    # QGIS 표현식
#     EXPR_LAYER = 'EXPR_LAYER'

#     def initAlgorithm(self, config=None):
#         input_Folder = self.Qsettings.value('SHP파일 수집 폴더', '')
#         self.addParameter(
#                 QgsProcessingParameterFile(
#                     self.BASE_DIR,
#                     '📁 수집 폴더',
#                     behavior = QgsProcessingParameterFile.Folder,
#                     defaultValue = input_Folder
#                 )
#             )

#         self.addParameter(
#             QgsProcessingParameterEnum(
#                 self.UNIT,
#                 '⚙️파일 취합 후 처리',
#                 options=['SHP병합', '필드계산기', '자동 증가 필드 추가', '레이어에 추가', '리스트 추출'],
#                 defaultValue=0
#             )
#         )

#         # 📝 필드 계산 결과를 저장할 필드 이름 (기존 필드 또는 새 필드)
#         calc_field_param = QgsProcessingParameterString(
#             self.CALC_FIELD,
#             '📝 필드 계산 대상 필드명 (기존/신규 공통)',
#             optional=True
#         )
#         calc_field_param.setFlags(calc_field_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
#         self.addParameter(calc_field_param)

#         # # initAlgorithm 안에서
#         # self.addParameter(
#         #     QgsProcessingParameterVectorLayer(
#         #         self.EXPR_LAYER,
#         #         '표현식 미리보기용 레이어 (선택)',
#         #         types=[QgsProcessing.TypeVectorAnyGeometry],
#         #         optional=True
#         #     )
#         # )

#         # 🧮 QGIS 표현식 (Expression 위젯 사용)
#         calc_expr_param = QgsProcessingParameterExpression(
#             self.CALC_EXPR,
#             '🧮 필드 계산식 (QGIS 표현식)',
#             parentLayerParameterName=self.EXPR_LAYER,   # ⬅ 여기
#             defaultValue='',
#             optional=True,
#             # parentLayerParameterName=''   # 필요하다면 아래에서 설명
#         )
#         calc_expr_param.setFlags(calc_expr_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
#         self.addParameter(calc_expr_param)

#         # 📌 자동 증가 필드 이름 (기본값: AUTO_ID)
#         field_param = QgsProcessingParameterString(
#             self.FIELD_NAME,
#             '🔶 자동 증가 필드 이름',
#             defaultValue='AUTO_ID',
#             optional=True,
#         )

#         # (선택) 고급 옵션으로 숨기고 싶으면:
#         field_param.setFlags(field_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)

#         self.addParameter(field_param)

#         # 🔢 시작 값 (기본: 1)
#         start_param = QgsProcessingParameterNumber(
#             self.START_VALUE,
#             '🔷 시작 값',
#             type=QgsProcessingParameterNumber.Integer,
#             defaultValue=1,
#             optional=True
#         )
#         start_param.setFlags(start_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
#         self.addParameter(start_param)

#         # 🔢 증가 값 (기본: 1)
#         step_param = QgsProcessingParameterNumber(
#             self.STEP_VALUE,
#             '🔷 증가 값',
#             type=QgsProcessingParameterNumber.Integer,
#             defaultValue=1,
#             optional=True
#         )
#         step_param.setFlags(step_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
#         self.addParameter(step_param)

#     def processAlgorithm(self, parameters, context, model_feedback):

#         input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
#         mode         = self.parameterAsEnum(parameters, self.UNIT, context)
        
#         # 필드 이름 파라미터 (기본값 AUTO_ID)
#         field_name   = self.parameterAsString(parameters, self.FIELD_NAME, context)
#         if not field_name:
#             field_name = "AUTO_ID"

#         # 시작 값 (기본 1)
#         start_value = self.parameterAsInt(parameters, self.START_VALUE, context)
#         if start_value is None:
#             start_value = 1

#         # 증가 값 (기본 1, 0은 허용 X)
#         step_value = self.parameterAsInt(parameters, self.STEP_VALUE, context)
#         if step_value is None or step_value == 0:
#             model_feedback.pushWarning("⚠️ 증가 값이 0이어서 1로 대체합니다.")
#             step_value = 1

#         self.Qsettings.setValue('파일수집폴더', input_Folder)

#         all_shp_paths = None
#         all_shp_paths = []

#         results = {}
#         outputs = {}

#         silent_feedback = QgsProcessingFeedback()

#         # **를 사용하고 recursive=True 옵션을 주면 하위 폴더까지 탐색합니다.
#         # shp_files = glob.glob(os.path.join(input_Folder, '**', '*.shp'), recursive=True)

#         shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))

#         model_feedback.pushWarning(f"🧺{input_Folder} SHP 취합완료")
#         all_shp_paths.extend(shp_files)

#         results['shp'] = all_shp_paths

#         if model_feedback.isCanceled():
#             return {}
        
#         if mode == 0:

#             # 벡터 레이어 병합
#             alg_params = {
#                 'CRS': None,
#                 'LAYERS': all_shp_paths,
#                 'OUTPUT': 'memory:'
#             }
#             outputs = processing.run('native:mergevectorlayers', alg_params)

#             if model_feedback.isCanceled():
#                 return {}

#             stats_layer = outputs['OUTPUT']
#             stats_layer.setName(f"병합한 레이어")
#             QgsProject.instance().addMapLayer(stats_layer)
#             model_feedback.pushWarning(f"🔹파일 취합후 병합 완료")

#         if mode == 2:
#             # 자동 증가 필드 추가
#             auto_field_name = field_name

#             for path in shp_files:
#                 layer_name = os.path.basename(path)
#                 vl = QgsVectorLayer(path, layer_name, 'ogr')

#                 if not vl.isValid():
#                     model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
#                     continue

#                 prov = vl.dataProvider()

#                 # 이미 AUTO_ID 필드가 있는지 확인
#                 idx = vl.fields().indexOf(auto_field_name)
#                 if idx < 0:
#                     # 없으면 필드 추가
#                     prov.addAttributes([QgsField(auto_field_name, QVariant.Int)])
#                     vl.updateFields()
#                     idx = vl.fields().indexOf(auto_field_name)

#                 if idx < 0:
#                     model_feedback.pushWarning(f"⚠️ {layer_name} 에 {auto_field_name} 필드를 추가하지 못했습니다.")
#                     continue

#                 # 편집 시작
#                 if not vl.isEditable():
#                     vl.startEditing()

#                 # 📌 각 레이어마다 동일한 시작 값에서 시작
#                 current_value = start_value

#                 for feat in vl.getFeatures():
#                     feat[idx] = current_value
#                     vl.updateFeature(feat)
#                     current_value += step_value

#                     if model_feedback.isCanceled():
#                         vl.rollBack()
#                         return {}

#                 # 변경 내용 commit
#                 if not vl.commitChanges():
#                     model_feedback.pushWarning(f"⚠️ {layer_name} 의 변경사항 저장 실패")
#                 else:
#                     count = vl.featureCount()
#                     model_feedback.pushWarning(
#                         f"🔹 {layer_name} 에 {auto_field_name} 필드 추가 및 순번 부여 완료 "
#                         f"(총 {count}개, 시작={start_value}, 증가={step_value})"
#                     )

#         if mode == 3:
#             # mode 1: 수집된 shapefile을 각각 레이어로 추가
#             for path in shp_files:
#                 layer_name = os.path.basename(path)
#                 vl = QgsVectorLayer(path, layer_name, 'ogr')
#                 if not vl.isValid():
#                     model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
#                     continue
#                 QgsProject.instance().addMapLayer(vl)
#             model_feedback.pushWarning("🔹 모든 SHP 레이어 추가 완료")
#         if mode == 4:
#             # mode 2: 파일 경로 리스트만 속성 테이블 형태로 추가
#             # Geometry-less 메모리 레이어 생성
#             table_layer = QgsVectorLayer("None", "SHP 파일 목록", "memory")
#             prov = table_layer.dataProvider()
#             prov.addAttributes([QgsField("path", QVariant.String)])
#             table_layer.updateFields()
            
#             feats = []
#             for path in shp_files:
#                 feat = QgsFeature(table_layer.fields())
#                 feat["path"] = path
#                 feats.append(feat)
#             prov.addFeatures(feats)
#             QgsProject.instance().addMapLayer(table_layer)
#             model_feedback.pushWarning("🔹 SHP 파일 목록 테이블 추가 완료")

#         return {}

#     def name(self):
#         return '폴더 내 SHP파일 수집'

#     def displayName(self):
#         return '폴더 내 SHP파일 수집'

#     def group(self):
#         return "폴더 내 SHP파일 수집"

#     def groupId(self):
#         return "폴더 내 SHP파일 수집"
    
#     def shortHelpString(self):
#         return "지정 폴더에 있는 SHP를 가져와 처리합니다."

#     def createInstance(self):
#         return Processes_Import_shp_files_Algorithm()