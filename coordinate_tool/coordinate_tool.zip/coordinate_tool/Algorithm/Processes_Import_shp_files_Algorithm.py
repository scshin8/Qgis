
from qgis.core import (
    QgsProject,
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsProcessingFeedback,
    QgsProcessingParameterFile,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
)
from qgis.PyQt.QtCore import QVariant

from PyQt5.QtCore import QSettings

import os, processing, glob
import pandas as pd
import re

class Processes_Import_shp_files_Algorithm(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 파라미터 키 정의
    BASE_DIR    = 'BASE_DIR'
    UNIT        = 'UNIT'

    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('파일수집폴더', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    self.BASE_DIR,
                    '📁 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        

        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                '⚙️파일 취합 후 처리',
                options=['병합', '레이어에 추가', '리스트 추출', ],
                defaultValue=0
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, self.BASE_DIR, context)
        mode         = self.parameterAsEnum(parameters, self.UNIT, context)

        self.Qsettings.setValue('파일수집폴더', input_Folder)

        all_shp_paths = None
        all_shp_paths = []

        results = {}
        outputs = {}

        silent_feedback = QgsProcessingFeedback()

        # **를 사용하고 recursive=True 옵션을 주면 하위 폴더까지 탐색합니다.
        # shp_files = glob.glob(os.path.join(input_Folder, '**', '*.shp'), recursive=True)

        shp_files = glob.glob(os.path.join(input_Folder, '*.shp'))

        model_feedback.pushWarning(f"🧺{input_Folder} SHP 취합완료")
        all_shp_paths.extend(shp_files)

        results['shp'] = all_shp_paths

        if model_feedback.isCanceled():
            return {}
        
        if mode == 0:
            # 벡터 레이어 병합
            alg_params = {
                'CRS': None,
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs = processing.run('native:mergevectorlayers', alg_params)

            if model_feedback.isCanceled():
                return {}

            stats_layer = outputs['OUTPUT']
            stats_layer.setName(f"병합한 레이어")
            QgsProject.instance().addMapLayer(stats_layer)
            model_feedback.pushWarning(f"🔹파일 취합후 병합 완료")

        if mode == 1:
            # mode 1: 수집된 shapefile을 각각 레이어로 추가
            for path in shp_files:
                layer_name = os.path.basename(path)
                vl = QgsVectorLayer(path, layer_name, 'ogr')
                if not vl.isValid():
                    model_feedback.pushWarning(f"⚠️ 레이어 로드 실패: {path}")
                    continue
                QgsProject.instance().addMapLayer(vl)
            model_feedback.pushWarning("🔹 모든 SHP 레이어 추가 완료")
        if mode == 2:
            # mode 2: 파일 경로 리스트만 속성 테이블 형태로 추가
            # Geometry-less 메모리 레이어 생성
            table_layer = QgsVectorLayer("None", "SHP 파일 목록", "memory")
            prov = table_layer.dataProvider()
            prov.addAttributes([QgsField("path", QVariant.String)])
            table_layer.updateFields()
            
            feats = []
            for path in shp_files:
                feat = QgsFeature(table_layer.fields())
                feat["path"] = path
                feats.append(feat)
            prov.addFeatures(feats)
            QgsProject.instance().addMapLayer(table_layer)
            model_feedback.pushWarning("🔹 SHP 파일 목록 테이블 추가 완료")

        return {}

    def name(self):
        return '폴더 내 SHP파일 수집'

    def displayName(self):
        return '폴더 내 SHP파일 수집'

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "파일 관리"
    
    def shortHelpString(self):
        return "지정 폴더에 있는 SHP를 가져와 처리합니다."

    def createInstance(self):
        return Processes_Import_shp_files_Algorithm()