from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterField,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsFeatureSink,
    QgsWkbTypes,
    QgsVectorLayer,
    QgsProcessingUtils,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSource,
    QgsProcessingException,
    QgsCoordinateReferenceSystem,
    QgsProcessingFeedback,
    QgsFeatureRequest
)
from qgis.PyQt.QtCore import QVariant
import os, processing, math

from pyproj import Proj, transform

class Processes_Log_vertex(QgsProcessingAlgorithm):

    INPUT_TARGET = 'INPUT_TARGET'
    RANGE = 'RANGE'
    UNIT = 'UNIT'
    OUTPUT = 'End'

    def initAlgorithm(self, config=None):
        # 백터 레이어 가져오기
        # self.addParameter(
        #     QgsProcessingParameterVectorLayer(
        #         self.INPUT_TARGET,
        #         '로그_SHP',
        #         [QgsProcessing.TypeVectorAnyGeometry]
        #     )
        # )

        # 백터 객체 가져오기
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_TARGET,
                '✅로그_SHP',
                types=[QgsProcessing.TypeVectorAnyGeometry],
                defaultValue=None
            )
        )

        # self.addParameter(
        #     QgsProcessingParameterField(
        #         'logField', 
        #         '로그명 필드 선택',
        #         optional=True,
        #         type=QgsProcessingParameterField.Any, 
        #         parentLayerParameterName=self.INPUT_TARGET, 
        #         allowMultiple=False, 
        #         defaultValue=None
        #     )
        # )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.RANGE, 
                '📏제외 거리', 
                type=QgsProcessingParameterNumber.Integer, 
                minValue=1, 
                maxValue=10000, 
                defaultValue=1
            )
        )

        # 2) 단위 콤보박스 (m 또는 km)
        self.addParameter(
            QgsProcessingParameterEnum(
                self.UNIT,
                '⚙️단위',
                options=['m', 'km'],
                defaultValue=1  # 기본 인덱스: 0 → 'm'
            )
        )

        self.addParameter(QgsProcessingParameterFeatureSink(
                'End',
                '💾결과 파일', 
                type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        # def calculate_angle_difference(a, b):
        #     try:
        #         diff = abs((b - a) % 360)  # 두 각도의 차이를 360으로 나눈 나머지를 계산
        #         if diff > 180:  # 차이가 180보다 크면 보정하여 음수로 변환
        #             diff = abs(360 - diff)
        #         return diff
        #     except:
        #         return 0

        def getDistance(lastTM_x, lastTM_y, TM_x, TM_y):
            # 두좌표간 거리 추출
            distance = math.sqrt( math.pow(lastTM_x - TM_x, 2) 
                                + math.pow(lastTM_y - TM_y, 2))
            # print("거리 : " + "{0:0.2f}".format(distance))
            return distance

        results = {}
        outputs = {}

        # Log_layer = self.parameterAsVectorLayer(parameters, self.INPUT_TARGET, context)
        source = self.parameterAsSource(parameters, self.INPUT_TARGET, context)
        # log_fields = self.parameterAsFields(parameters, 'logField', context)

        raw_distance = self.parameterAsInt(parameters, self.RANGE, context)
        unit_index  = self.parameterAsEnum(parameters, self.UNIT, context)
        
        # 2) 단위별 환산 (m 또는 km)
        if unit_index == 1:   # 'km' 선택 시
            distance_m = raw_distance * 1000
            unit = 'km'
        else:                 # 'm' 선택 시 (기본)
            distance_m = raw_distance
            unit = 'm'

        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT_TARGET))
        # 실제 QgsVectorLayer 객체 얻기
        Log_layer = QgsProcessingUtils.mapLayerFromString(source.sourceName(), context)
        if Log_layer is None:
            raise QgsProcessingException("벡터 레이어를 찾을 수 없습니다.")
        name = Log_layer.name()

        # logField = log_fields[0] if log_fields else None
        parameters['End'].destinationName = f'{name}_보정_{raw_distance}{unit}'

        crs = Log_layer.crs()
        log_results = []
        
        silent_feedback = QgsProcessingFeedback()
        stap = 0
        feedback = QgsProcessingMultiStepFeedback(100, feedback)

        new_feat = None

        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': '_KEY_',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # Integer (32 bit)
            'FORMULA': '$id',
            'INPUT': Log_layer,
            'OUTPUT': 'memory:'
        }

        outputs['_KEY_'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

        key_layer  = QgsProcessingUtils.mapLayerFromString(outputs['_KEY_']['OUTPUT'], context)
        orig_fields = [f.name() for f in Log_layer.fields()]

        # 3) 이 레이어에서 Features 리스트 생성
        Features = list(key_layer.getFeatures())
        featCount = len(Features)

        feedback.pushInfo(f'ℹ️ 로그 이격 {raw_distance}{unit} 이상 제외')

        for feat in Features:

            # 해당 피처의 속성값 리스트 얻기
            attr_values = feat.attributes()

            # 피처 하나만 포함하는 임시 레이어 생성
            single_layer = QgsVectorLayer("LineString?crs=" + crs.authid(), "temp", "memory")
            prov = single_layer.dataProvider()
            prov.addAttributes(Log_layer.fields())

            new_feat = QgsFeature(feat)
            new_feat.setGeometry(feat.geometry())
            new_feat.setFields(single_layer.fields())
            new_feat.setAttributes(attr_values)

            prov.addFeature(new_feat)
            single_layer.updateFields()

            new_feat = None

            _key_ = feat['_KEY_']

            stap += 1
            # feedback.pushWarning(f'[{featCount}/{stap}]  로그명:{logName}')
            feedback.setCurrentStep(int((stap / featCount) * 100))

            # alg_params = {
            #     'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            #     'LAYERS': single_layer,
            #     'OUTPUT': 'memory:'
            # }
            # outputs['merge'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            alg_params = {
                'INPUT': single_layer,
                'TOLERANCE': 1e-06,
                'USE_Z_VALUE': False,
                'OUTPUT': 'memory:'
            }
            outputs['0'] = processing.run('native:removeduplicatevertices', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'INPUT': outputs['0']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['1'] = processing.run('native:extractvertices', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'COLUMN': ['angle'],
                'INPUT': outputs['1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['deletecolumn'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'INPUT': outputs['0']['OUTPUT'],
                'VERTICES': 1,
                'OUTPUT': 'memory:'
            }
            outputs['추가'] = processing.run('native:densifygeometries', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'INPUT': outputs['추가']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['추가_extractvertices'] = processing.run('native:extractvertices', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'EXPRESSION': '"vertex_index" % 2 = 1',
                'INPUT': outputs['추가_extractvertices']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['extractbyexpression'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'vertex_index',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': ' ( "vertex_index" - 1 ) / 2',
                'INPUT': outputs['extractbyexpression']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['fieldcalculator'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'vertex_index',
                'FIELDS_TO_COPY': ['angle'],
                'FIELD_2': 'vertex_index',
                'INPUT': outputs['deletecolumn']['OUTPUT'],
                'INPUT_2': outputs['fieldcalculator']['OUTPUT'],
                'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['joinattributestable'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'angle',
                'FIELD_PRECISION': 1,
                'FIELD_TYPE': 0,  # Decimal (double)
                'FORMULA': 'round(angle, 1)',
                'INPUT': outputs['joinattributestable']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['angle'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                'INPUT': outputs['angle']['OUTPUT'],
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['4'] = processing.run('native:addxyfields', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'ASCENDING': True,
                'EXPRESSION': 'vertex_index',
                'INPUT': outputs['4']['OUTPUT'],
                'NULLS_FIRST': False,
                'OUTPUT': 'memory:'
            }
            outputs['5'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'group_index',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 0,  # Integer (32 bit)
                'INPUT': outputs['5']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['6'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            layer_id = outputs['6']['OUTPUT']
            result_layer = QgsProcessingUtils.mapLayerFromString(layer_id, context)
            group_idx = result_layer.fields().indexOf('group_index')

            id_mod = 0
            changes = {}
            features = list(result_layer.getFeatures())

            for num, feat in enumerate (features):
                # endIdx = int(feat['vertex_index'])
                # try:    
                #     endAngle = feat['angle']
                # except:
                #     endAngle = 0
                    
                TM_x = feat['x']
                TM_y = feat['y']
                if num != 0:
                    # idxV = endIdx - lastIdx
                    endDistance = getDistance(lastTM_x, lastTM_y, TM_x, TM_y)
                    # distance = endDistance - lastDistance
                    # diff = calculate_angle_difference(endAngle, lastAngle)

                    if endDistance >= distance_m: # or diff > 120: 
                        id_mod += 1

                # else:
                #     endAngle = feat['angle']

                changes[feat.id()] = {
                        group_idx: id_mod,
                    }
                # lastIdx =  endIdx

                # lastAngle = endAngle
                lastTM_x = TM_x
                lastTM_y = TM_y

            if changes:
                provider = result_layer.dataProvider()
                provider.changeAttributeValues(changes)
                result_layer.triggerRepaint()

            # # group_index 기준으로 경로 재생성
            alg_params = {
                'CLOSE_PATH': False,
                'GROUP_EXPRESSION': 'group_index',
                'INPUT': result_layer,
                'NATURAL_SORT': True,
                'ORDER_EXPRESSION': 'vertex_index',
                'OUTPUT': 'memory:'
            }
            outputs['7'] = processing.run('native:pointstopath', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'FIELD': [''],
                'INPUT': outputs['7']['OUTPUT'],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': 'memory:'
            }
            outputs['8'] = processing.run('native:dissolve', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': '__KEY__',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # Integer (32 bit)
                'FORMULA': f"{_key_}",
                'INPUT': outputs['8']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['9'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

            join_params = {
                'INPUT':       outputs['9']['OUTPUT'],   # 메모리 레이어
                'INPUT_2':     outputs['_KEY_']['OUTPUT'],                    # 원본 레이어
                'FIELDS_TO_COPY': orig_fields,               # 복사할 필드명 리스트
                'FIELD':       '__KEY__',                   # 메모리 레이어 쪽 조인 키
                'FIELD_2':     '_KEY_',                     # 원본 레이어 쪽 조인 키
                'METHOD':      1,                            # 1: 1:1 매칭
                'DISCARD_NONMATCHING': False,
                'PREFIX':      '',                           # 접두사 없앰
                'OUTPUT':      'memory:'
            }

            joined = processing.run(
                'native:joinattributestable',
                join_params,
                context=context,
                feedback=silent_feedback,
                is_child_algorithm=True

            )
            # 1. 조인 결과 레이어 객체 얻기
            joined_layer = QgsProcessingUtils.mapLayerFromString(
                joined['OUTPUT'], context)

            # 2. 전체 필드명 리스트
            all_fields = [f.name() for f in joined_layer.fields()]

            # 3. 남기고 싶은 필드(orig_fields)에 조인 키(logField)도 추가
            keep_fields = set(orig_fields) #  | { 'log_name' }  # 예: 'log_name'이 조인 키라면

            # 4. 제거할 필드 목록 계산
            remove_fields = [f for f in all_fields if f not in keep_fields]

            # joined_layer 는 QgsVectorLayer 객체
            provider = joined_layer.dataProvider()
            # 삭제할 필드 인덱스 리스트 계산
            idxs = [joined_layer.fields().indexOf(f) for f in remove_fields]
            provider.deleteAttributes(idxs)
            joined_layer.updateFields()

            log_results.append(joined_layer)

        alg_params = {
            'CRS':  QgsCoordinateReferenceSystem(crs.authid()),
            'LAYERS': log_results,
            'OUTPUT': 'memory:'
        }
        outputs['merge'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

        alg_params = {
            'COLUMN': ['group_index','begin','end','layer','path'],
            'INPUT': outputs['merge']['OUTPUT'],
            'OUTPUT': parameters['End'] 
        }
        outputs['end'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=silent_feedback, is_child_algorithm=True)

        results['End'] = outputs['end']['OUTPUT']

        return results

    def name(self):
        return "Edit_log_vertex"

    def displayName(self):
        return "로그 궤적 보정"

    # def group(self):
    #     return "사용자 스크립트"

    # def groupId(self):
    #     return "customscripts"

    def createInstance(self):
        return Processes_Log_vertex()
