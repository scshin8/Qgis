from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd

class GuidedLine_Extraction_Algorithm(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def initAlgorithm(self, config=None):

        input_Folder = self.Qsettings.value('로그폴더', '')
        guideLine_shp = self.Qsettings.value('유도선shp', '')
        partner_shp = self.Qsettings.value('협력사shp', '')
        TG_shp = self.Qsettings.value('톨게이트shp', '')
        exc_shp = self.Qsettings.value('기반영shp', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '로그 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        self.addParameter(
                QgsProcessingParameterFile(
                    '2',
                    "주단위 유도선shp",
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = guideLine_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '3',
                    '협력사shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = partner_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '4',
                    '톨게이트shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = TG_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '5',
                    '기반영shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = exc_shp,
                    optional=True  # 선택 입력으로 설정
                )
            )
        
        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ADD_TO_CANVAS',
                    '결과 레이어를 화면에 추가',
                    defaultValue = False
                )
            )
        
    def processAlgorithm(self, parameters, context, model_feedback):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model


        """전체 하위 폴더 목록을 가져오는 로직"""
        input_Folder = self.parameterAsFile(parameters, '1', context)
        guideLine_shp = self.parameterAsFile(parameters, '2', context)
        partner_shp = self.parameterAsFile(parameters, '3', context)
        TG_shp = self.parameterAsFile(parameters, '4', context)
        exc_shp = self.parameterAsFile(parameters, '5', context)
        
        self.Qsettings.setValue('로그폴더', input_Folder)
        self.Qsettings.setValue('유도선shp', guideLine_shp)
        self.Qsettings.setValue('협력사shp', partner_shp)
        self.Qsettings.setValue('톨게이트shp', TG_shp)
        self.Qsettings.setValue('기반영shp', exc_shp)

        if not os.path.isdir(input_Folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        weekNum = input_Folder.split('\\')[-1]
        Result_Shp = f'{input_Folder}/{weekNum}.shp'

        """하위 폴더 목록을 가져오는 로직"""
        subfolders = [f for f in os.listdir(input_Folder) if os.path.isdir(os.path.join(input_Folder, f))]

        # for root, dirs, _ in os.walk(input_folder):
        #     for directory in dirs:
        #         full_path = os.path.join(root, directory)
        #         all_folders.append(full_path)

        feedback = QgsProcessingMultiStepFeedback(94 * len(subfolders) + 2, model_feedback)
        feedback.pushInfo(f"총 {len(subfolders)}개의 폴더를 찾았습니다.")
        feedback.pushInfo(f"{subfolders}")

        detectResult=[]
        idx = 0
        for logFolder in subfolders:
            Stepnum = 94 * idx
            results = {}
            outputs = {}
            # 1_문자열 연결_로그
            # E:\Survey_Log\   로그명 앞 경로 설정 필요
            alg_params = {
                'INPUT_1': input_Folder,
                'INPUT_2': f'/{logFolder}'
            }
            outputs['1'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 2_문자열 연결_3_detection_results_clust_END
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/3_detection_results_clust_END.csv'
            }
            outputs['2'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 3_문자열 연결_RESULT
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/RESULT'
            }
            outputs['3'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 4_디렉터리 생성
            path_to_create = outputs['3']['CONCATENATION']
            if not os.path.exists(path_to_create):
                os.makedirs(path_to_create)

            # alg_params = {
            #     'PATH': outputs['3']['CONCATENATION']
            # }
            # outputs['4'] = processing.run('native:createdirectory', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 5_문자열 연결_00_Detection_Results.shp
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/00_Detection_Results.shp'
            }
            outputs['5'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 6_문자열 연결_00_Detection_Results.qml
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/00_Detection_Results.qml'
            }
            outputs['6'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 7_문자열 연결_00_Detection_Results_END.shp
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}.shp'
            }
            outputs['7'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 8_문자열 연결_00_Detection_Results_END.qml
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}.qml'
            }
            outputs['8'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(8 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 9_파일 다운로드
            alg_params = {
                'DATA': '',
                'METHOD': 0,  # GET
                'OUTPUT': outputs['6']['CONCATENATION'],
                'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results.qml'
            }
            outputs['9'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(9 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 10_파일 다운로드
            alg_params = {
                'DATA': '',
                'METHOD': 0,  # GET
                'OUTPUT': outputs['8']['CONCATENATION'],
                'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results_END.qml'
            }
            outputs['10'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 11_테이블에서 포인트 생성
            alg_params = {
                'INPUT': outputs['2']['CONCATENATION'],
                'MFIELD': '',
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                'XFIELD': 'x',
                'YFIELD': 'y',
                'ZFIELD': '',
                'OUTPUT': 'memory:'
            }
            outputs['11'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(11 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 12_필드 계산기 group
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'group',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': ' "id_mod" ||\'_\'|| "color_mod" ',
                'INPUT': outputs['11']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['12'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(12 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 13_표현식으로 추출
            alg_params = {
                'EXPRESSION': '"color_mod" <> \'단일\' and "color_mod" <> \'enemy\'',
                'INPUT': outputs['12']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['13'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(13 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 14_포인트를 경로로
            alg_params = {
                'CLOSE_PATH': False,
                'GROUP_EXPRESSION': ' "id_mod" ||\'_\'|| "color_mod" ',
                'INPUT': outputs['13']['OUTPUT'],
                'NATURAL_SORT': False,
                'ORDER_EXPRESSION': ' "NO" ',
                'OUTPUT': 'memory:'
            }
            outputs['14'] = processing.run('native:pointstopath', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(14 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 15_중복 꼭짓점 제거
            alg_params = {
                'INPUT': outputs['14']['OUTPUT'],
                'TOLERANCE': 1e-06,
                'USE_Z_VALUE': False,
                'OUTPUT': 'memory:'
            }
            outputs['15'] = processing.run('native:removeduplicatevertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(15 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 16_필드 계산기 len
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'len',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round($length,0)',
                'INPUT': outputs['15']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['16'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(16 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 17_표현식으로 추출
            alg_params = {
                'EXPRESSION': '"len">0',
                'INPUT': outputs['16']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['17'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(17 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 18_필드 계산기 ang
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Angle_Sur',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round(line_interpolate_angle($geometry,distance:=0),0)',
                'INPUT': outputs['17']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['18'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(18 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 19_필드 계산기 영상_컬러
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'Color_Sur',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': 'substr( "group",strpos( "group" ,\'_\')+1,10)',
                'INPUT': outputs['18']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['19'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(19 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 20_꼭짓점 추출
            alg_params = {
                'INPUT': outputs['19']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['20'] = processing.run('native:extractvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(20 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 21_범주 별 통계
            alg_params = {
                'CATEGORIES_FIELD_NAME': ['group'],
                'INPUT': outputs['20']['OUTPUT'],
                'VALUES_FIELD_NAME': '',
                'OUTPUT': 'memory:'
            }
            outputs['21'] = processing.run('qgis:statisticsbycategories', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(21 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 22_필드 값으로 속성 결합 count
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['count'],
                'FIELD_2': 'group',
                'INPUT': outputs['12']['OUTPUT'],
                'INPUT_2': outputs['21']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['22'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(22 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 23_벡터 피처를 파일로 저장_1
            # 00_Detection_Results.shp
            alg_params = {
                'DATASOURCE_OPTIONS': '',
                'INPUT': outputs['22']['OUTPUT'],
                'LAYER_NAME': '',
                'LAYER_OPTIONS': '',
                'OUTPUT': outputs['5']['CONCATENATION'],
            }
            outputs['23'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(23 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 24_필드 값으로 속성 결합 count
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['count'],
                'FIELD_2': 'group',
                'INPUT': outputs['19']['OUTPUT'],
                'INPUT_2': outputs['21']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['24'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(24 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 25_표현식으로 추출 확인대상
            alg_params = {
                'EXPRESSION': '"len"<> 0 and "Color_Sur"<>\'enemy\' and "count">=4',
                'INPUT': outputs['24']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['25'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(25 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 26_특정 꼭짓점 추출
            alg_params = {
                'INPUT': outputs['25']['OUTPUT'],
                'VERTICES': '0',
                'OUTPUT': 'memory:'
            }
            outputs['26'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(26 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 27_위치에 따라 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['26']['OUTPUT'],
                'JOIN': outputs['13']['OUTPUT'],
                'JOIN_FIELDS': ['NO','score','date','time','mask','RESULT_IMG','filepath','Coordinate','file'],
                'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['27'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(27 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 28_표현식으로 추출  NO
            alg_params = {
                'EXPRESSION': ' "begin" = "NO" ',
                'INPUT': outputs['27']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['28'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(28 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 29_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['NO','score','date','time','mask','RESULT_IMG','filepath','Coordinate','file'],
                'FIELD_2': 'group',
                'INPUT': outputs['25']['OUTPUT'],
                'INPUT_2': outputs['28']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['29'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(29 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 30_위치에 따라 속성 결합 _ 인덱스 결합
            # 협력사 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['29']['OUTPUT'],
                # 'JOIN': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/협력사_22년.shp',
                'JOIN': partner_shp,
                'JOIN_FIELDS': ['Area'],
                'METHOD': 2,  # 최대 중첩 영역을 가진 피처의 속성만 가져오기 (1대1)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['30'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(30 + Stepnum)
            if feedback.isCanceled():
                return {}

            # # 31_문자열 연결_유도선
            # alg_params = {
            #     # 'INPUT_1': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/2025/',
            #     'INPUT_1': guideLine_shp,
            #     'INPUT_2': ''
            # }
            # outputs['31'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            # feedback.setCurrentStep(31)
            # if feedback.isCanceled():
            #     return {}
            # feedback.pushInfo(f"31")
            # # 32_문자열 연결_유도선2
            # alg_params = {
            #     'INPUT_1': outputs['31']['CONCATENATION'],
            #     'INPUT_2': ''
            # }
            # outputs['32'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            # feedback.setCurrentStep(32)
            # if feedback.isCanceled():
            #     return {}

            # 33_필드 계산기 ang_2
            # 주단위_유도선.shp
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Angle_Gui',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round(line_interpolate_angle($geometry,distance:=0),0)',
                'INPUT': guideLine_shp,
                'OUTPUT': 'memory:'
            }
            outputs['33'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(33 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 34_필드 계산기 유도선_컬러
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'Color_Gui',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': 'if("컬러"=\'1\',\'pink\',if("컬러"=\'3\',\'green\',if("컬러"=\'6\',\'blue\',\'\')))',
                'INPUT': outputs['33']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['34'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(34 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 35_공간 인덱스 생성_유도선
            alg_params = {
                'INPUT': outputs['34']['OUTPUT']
            }
            outputs['35'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(35 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 36_벡터 피처를 파일로 저장
            # # 11_Detection_Point_Line.shp
            # alg_params = {
            #     'DATASOURCE_OPTIONS': '',
            #     'INPUT': outputs['30']['OUTPUT'],
            #     'LAYER_NAME': '',
            #     'LAYER_OPTIONS': '',
            #     'OUTPUT': 'F:/RESULT/11_Detection_Point_Line.shp',
            #     'OUTPUT': 'memory:'
            # }
            # outputs['36'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(36 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 37_라인 오프셋
            alg_params = {
                'DISTANCE': QgsProperty.fromExpression('if ( "Color_Sur" = \'pink\' , -1 , if ( "Color_Sur" = \'blue\' , 1 , 3 ))'),
                'INPUT': outputs['30']['OUTPUT'],
                'JOIN_STYLE': 1,  # 마이터(miter)
                'MITER_LIMIT': 2,
                'SEGMENTS': 8,
                'OUTPUT': 'memory:'
            }
            outputs['37'] = processing.run('native:offsetline', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(37 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 38_버퍼
            alg_params = {
                'DISSOLVE': False,
                'DISTANCE': 50,
                'END_CAP_STYLE': 0,  # 둥글게
                'INPUT': outputs['30']['OUTPUT'],
                'JOIN_STYLE': 0,  # 둥글게
                'MITER_LIMIT': 2,
                'SEGMENTS': 8,
                'OUTPUT': 'memory:'
            }
            outputs['38'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(38 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 39_공간 인덱스 생성_버퍼
            alg_params = {
                'INPUT': outputs['38']['OUTPUT']
            }
            outputs['39'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(39 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 40_위치에 따라 속성 결합 유도선 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['39']['OUTPUT'],
                'JOIN': outputs['35']['OUTPUT'],
                'JOIN_FIELDS': ['Angle_Gui','Color_Gui'],
                'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['40'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        
            feedback.setCurrentStep(40 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 41_표현식으로 추출 색상일치
            alg_params = {
                'EXPRESSION': '("Color_Sur" = "Color_Gui") \nand \r\nabs(\r\nwith_variable(\'ang\',abs(("Angle_Gui" - "Angle_Sur") % 360), if( @ang > 180, 360-(@ang), @ang))\r\n) <= 45\r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['41'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(41 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 42_속성으로 중복 삭제 색상일치
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['41']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['42'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(42 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 43_필드 계산기 Match
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'01_일치'",
                'INPUT': outputs['42']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['43'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(43 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 44 비활성화
            feedback.setCurrentStep(44 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 45_표현식으로 추출 색상일치 각도확인
            alg_params = {
                'EXPRESSION': '"Color_Sur" = "Color_Gui" \r\nAND\r\nabs( if(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360-abs(("Angle_Gui" - "Angle_Sur") % 360), abs(("Angle_Gui" - "Angle_Sur") % 360))) > 45\r\nAND \r\n"Color_Sur" <> \'enemy\' \r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['45'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(45 + Stepnum)
            if feedback.isCanceled():
                return {}


            # 46_필드 값으로 속성 결합 색상일치 각도확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['45']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['46'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(46 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 47_속성으로 중복 삭제 색상일치 각도확인
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['46']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['47'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(47 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 48_필드 계산기 색상일치 각도확인
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Error_Type',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'각도확인'",
                'INPUT': outputs['47']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['48'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(48 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 49_필드 계산기 Mismatch1
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'02_불일치'",
                'INPUT': outputs['48']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['49'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(49 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 50_표현식으로 추출 각도일치 색상확인
            alg_params = {
                'EXPRESSION': '"Color_Sur" <> "Color_Gui"\r\nAND \r\nabs(if(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360 - abs(("Angle_Gui" - "Angle_Sur") % 360), ("Angle_Gui" - "Angle_Sur") % 360)) <= 45 \r\nAND \r\n"Color_Sur" <> \'enemy\' \r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['50'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(50 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 51_필드 값으로 속성 결합 각도일치 색상확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['50']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['51'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(51 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 52_필드 값으로 속성 결합 각도일치 색상확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['51']['NON_MATCHING'],
                'INPUT_2': outputs['45']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['52'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(52 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 53_필드 계산기 각도일치 색상확인
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Error_Type',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'색상확인'",
                'INPUT': outputs['52']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['53'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(53 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 54_필드 계산기 Mismatch2
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'02_불일치'",
                'INPUT': outputs['53']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['54'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(54 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS': None,
                'LAYERS': [outputs['49']['OUTPUT'],outputs['54']['OUTPUT']],
                'OUTPUT': 'memory:'
            }
            outputs['55'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(55 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 56_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['55']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['56'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(56 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 57 비활성화
            feedback.setCurrentStep(57 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 58_표현식으로 추출 색상비매칭
            alg_params = {
                'EXPRESSION': '"Color_Gui" is Null and  "Color_Sur" <> \'enemy\' \r\nor\r\n("Color_Sur" <> "Color_Gui"\r\nand \r\nabs(\r\nif(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360 - abs(("Angle_Gui" - "Angle_Sur") % 360), ("Angle_Gui" - "Angle_Sur") % 360)\r\n) > 45)',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['58'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(58 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 59_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['58']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['59'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(59 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 60_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['59']['NON_MATCHING'],
                'INPUT_2': outputs['45']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['60'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(60 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 61_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['60']['NON_MATCHING'],
                'INPUT_2': outputs['50']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['61'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(61 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 62_속성으로 중복 삭제
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['61']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['62'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(62 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 63_속성으로 추출 other
            alg_params = {
                'FIELD': 'Area',
                'INPUT': outputs['62']['OUTPUT'],
                'OPERATOR': 1,  # ≠
                'VALUE': '매스코',
                'FAIL_OUTPUT': 'memory:',
                'OUTPUT': 'memory:'
            }
            outputs['63'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(63 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 64_필드 삭제 other
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['63']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['64'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(64 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 65_필드 계산기 비매칭
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'05_타권역'",
                'INPUT': outputs['64']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['65'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(65 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 66 비활성화
            feedback.setCurrentStep(66 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 67_최근접 거리를 이용하여 속성을 결합
            # 톨게이트 취근접 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELDS_TO_COPY': ['1'],
                'INPUT': outputs['63']['FAIL_OUTPUT'],
                # 'INPUT_2': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/톨게이트.shp',
                'INPUT_2': TG_shp,
                'MAX_DISTANCE': None,
                'NEIGHBORS': 1,
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['67'] = processing.run('native:joinbynearest', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(67 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 68_속성으로 추출 색상비매칭
            alg_params = {
                'FIELD': 'distance',
                'INPUT': outputs['67']['OUTPUT'],
                'OPERATOR': 4,  # <
                'VALUE': '70',
                'FAIL_OUTPUT': 'memory:',
                'OUTPUT': 'memory:'
            }
            outputs['68'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(68 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 69_필드 삭제 색상불일치 TG
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['68']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['69'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(69 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 70_속성으로 중복 삭제 TG
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['69']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['70'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(70 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 71_필드 계산기 TG
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'04_톨게이트'",
                'INPUT': outputs['70']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['71'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(71 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 72 비활성화
            feedback.setCurrentStep(72 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 73_필드 삭제 색상불일치 masco
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['68']['FAIL_OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['73'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(73 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 74_속성으로 중복 삭제 masco
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['73']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['74'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(74 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 75_필드 계산기 masco
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'03_비매칭'",
                'INPUT': outputs['74']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['75'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(75 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 76 비활성화
            feedback.setCurrentStep(76 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 기반영shp 있다면 > 기반영 객체 이상없으로 처리
            if os.path.exists(exc_shp):
                feedback.pushInfo(f"기반영 예외처리")
                # 77_벡터 레이어 병합 불일치
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['49']['OUTPUT'],outputs['54']['OUTPUT'],outputs['65']['OUTPUT'],outputs['71']['OUTPUT'],outputs['75']['OUTPUT']],
                    'OUTPUT': 'memory:'
                }
                outputs['77'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(77 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 78_위치에 따라 속성 결합 예외 유도선 결합
                # 기반영.shp
                alg_params = {
                    'DISCARD_NONMATCHING': False,
                    'INPUT': outputs['77']['OUTPUT'],
                    'JOIN': exc_shp,
                    'JOIN_FIELDS': ['영상_각도','영상_색상'],
                    'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                    'PREDICATE': [0],  # intersect
                    'PREFIX': '',
                    'OUTPUT': 'memory:'
                }
                outputs['78'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(78 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 79_표현식으로 추출 예외 색상일치
                alg_params = {
                    'EXPRESSION': '("Color_Sur" = "영상_색상") \nand \r\nabs(\r\nwith_variable(\'ang\',abs(("영상_각도" - "Angle_Sur") % 360), if( @ang > 180, 360-(@ang), @ang))\r\n) <= 45\r\n\n',
                    'INPUT': outputs['78']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['79'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(79 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 80_속성으로 중복 삭제 예외 일치
                alg_params = {
                    'FIELDS': ['group'],
                    'INPUT': outputs['79']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['80'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(75 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 81_필드 계산기 Match
                alg_params = {
                    'FIELD_LENGTH': 30,
                    'FIELD_NAME': 'Class',
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,  # 텍스트 (string)
                    'FORMULA': "'01_일치'",
                    'INPUT': outputs['80']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['81'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(81 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 82_필드 계산기 Match
                alg_params = {
                    'FIELD_LENGTH': 30,
                    'FIELD_NAME': 'Error_Type',
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,  # 텍스트 (string)
                    'FORMULA': "''",
                    'INPUT': outputs['81']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['82'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(82 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 83_필드 값으로 속성 결합 불일치 예외
                alg_params = {
                    'DISCARD_NONMATCHING': False,
                    'FIELD': 'group',
                    'FIELDS_TO_COPY': ['1'],
                    'FIELD_2': 'group',
                    'INPUT': outputs['77']['OUTPUT'],
                    'INPUT_2': outputs['82']['OUTPUT'],
                    'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                    'PREFIX': '',
                    'NON_MATCHING': 'memory:'
                }
                outputs['83'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(83 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 84_벡터 레이어 병합
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['43']['OUTPUT'],outputs['82']['OUTPUT'],outputs['83']['NON_MATCHING']],
                    'OUTPUT': 'memory:'
                }
                outputs['84'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(84 + Stepnum)
                if feedback.isCanceled():
                    return {}
            else:
                feedback.pushInfo(f"기반영shp 미존재")
                # 84_벡터 레이어 병합
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['43']['OUTPUT'],outputs['49']['OUTPUT'],outputs['54']['OUTPUT'],outputs['65']['OUTPUT'],outputs['71']['OUTPUT'],outputs['75']['OUTPUT']],
                    'OUTPUT': 'memory:'
                }
                outputs['84'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(84 + Stepnum)
                if feedback.isCanceled():
                    return {}


            # 85_필드 값으로 속성 결합 1
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': [''],
                'FIELD_2': 'group',
                'INPUT': outputs['37']['OUTPUT'],
                'INPUT_2': outputs['84']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['85'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(85 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 86_속성 테이블에 필드 추가 확인결과
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '확인결과',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['85']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['86'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(86 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 87_속성 테이블에 필드 추가 실제색상
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '실제색상',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['86']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['87'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(87 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 88_속성 테이블에 필드 추가 비고
            alg_params = {
                'FIELD_LENGTH': 200,
                'FIELD_NAME': '비고',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['87']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['88'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(88 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 89_속성 테이블에 필드 추가 작업자
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '작업자',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['88']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['89'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(89 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 90_속성 테이블에 필드 추가 작업일
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '작업일',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 4,  # 날짜
                'INPUT': outputs['89']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['90'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(90 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 91_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path','group_2','begin_2','end_2','len_2','Color_Sur_2','Angle_Sur_2','index_2','score_2','RESULT_IMG_2','filepath_2','Coordinate_2','Area_2','count_2','NO_2','date_2','time_2','file_2','NO','len','count'],
                'INPUT': outputs['90']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['91'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(91 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 92_표현식으로 정렬
            alg_params = {
                'ASCENDING': True,
                'EXPRESSION': '"Class" ',
                'INPUT': outputs['91']['OUTPUT'],
                'NULLS_FIRST': False,
                'OUTPUT': 'memory:'
            }
            outputs['92'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(92 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 93_필드 재작성
            alg_params = {
                'FIELDS_MAPPING': [{'expression': '"filepath"','length': 254,'name': 'filepath','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"file"','length': 254,'name': 'file','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"group"','length': 254,'name': 'group','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': 'date','length': 0,'name': 'date','precision': 0,'sub_type': 0,'type': 14,'type_name': 'date'},
                                   {'expression': 'time','length': 8,'name': 'time','precision': 0,'sub_type': 0,'type': 15,'type_name': 'time'},
                                   {'expression': '"Coordinate"','length': 254,'name': 'Coordinate','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Area"','length': 10,'name': 'Area','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"score"','length': 3,'name': 'score','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                   {'expression': '"mask"','length': 10,'name': 'mask','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                   {'expression': '"Angle_Sur"','length': 10,'name': '영상_각도','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},
                                   {'expression': '"Angle_Gui"','length': 10,'name': '유도선_각도','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},
                                   {'expression': '"Color_Sur"','length': 50,'name': '영상_색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Color_Gui"','length': 50,'name': '유도선_색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Class"','length': 30,'name': 'Class','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Error_Type"','length': 10,'name': 'Error_Type','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"RESULT_IMG"','length': 254,'name': 'RESULT_IMG','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"확인결과"','length': 50,'name': '확인결과','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"실제색상"','length': 50,'name': '실제색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"비고"','length': 254,'name': '비고','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"작업자"','length': 50,'name': '작업자','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"작업일"','length': 50,'name': '작업일','precision': 0,'sub_type': 0,'type': 16,'type_name': 'datetime'}],
                'INPUT': outputs['92']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['93'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(93 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 94_벡터 피처를 파일로 저장2
            alg_params = {
                'DATASOURCE_OPTIONS': '',
                'INPUT': outputs['93']['OUTPUT'],
                'LAYER_NAME': '',
                'LAYER_OPTIONS': '',
                'OUTPUT': outputs['7']['CONCATENATION']
            }
            outputs['94'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(94 + Stepnum)
            if feedback.isCanceled():
                return {}

            detectResult.append(outputs['94']['OUTPUT'])
            idx += 1
        print(detectResult)
        # 95_파일 다운로드
        alg_params = {
            'DATA': '',
            'METHOD': 0,  # GET
            'OUTPUT': f'{input_Folder}/{weekNum}.qml',
            'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results_END.qml'
        }
        outputs['95'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(95 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 96_벡터 레이어 병합
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'LAYERS': detectResult,
            'OUTPUT': f'{input_Folder}/{weekNum}.shp'
        }
        outputs['96'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(96 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 결과 병합 후 레이어 경로
        result_path = f'{input_Folder}/{weekNum}.shp'

        # 사용자의 체크박스 선택값 읽기
        add_to_canvas = self.parameterAsBool(parameters, 'ADD_TO_CANVAS', context)

        # 조건에 따라 레이어 로드
        if add_to_canvas and os.path.exists(result_path):
            result_layer = QgsVectorLayer(result_path, weekNum, 'ogr')
            if result_layer.isValid():
                # 스타일 적용 (선택)
                qml_path = f'{input_Folder}/{weekNum}.qml'
                if os.path.exists(qml_path):
                    result_layer.loadNamedStyle(qml_path)
                QgsProject.instance().addMapLayer(result_layer)
            else:
                feedback.reportError('결과 레이어가 유효하지 않습니다.')
                return {}

    def name(self):
        return '영상인식_유도선추출'

    def displayName(self):
        return '영상인식_유도선추출'

    # def group(self):
    #     return '영상인식_유도선추출'

    # def groupId(self):
    #     return '영상인식_유도선추출'

    def createInstance(self):
        return GuidedLine_Extraction_Algorithm()