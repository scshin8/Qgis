'''
도형계산기 코드
'''
from qgis.PyQt import uic, QtWidgets

from qgis.core import   (Qgis,
                         QgsDefaultValue,
                         QgsExpression,
                         QgsExpressionContextUtils,
                         QgsExpressionContext,
                         QgsFields,
                         QgsUnitTypes,
                         QgsMapLayerType,
                         QgsCoordinateTransformContext,
                         QgsCoordinateReferenceSystem,
                         QgsWkbTypes,
                         QgsCoordinateTransform,
                         QgsField,
                         QgsPointXY,
                         QgsVectorLayer,
                         QgsGeometry)

from PyQt5.QtCore import (QSettings,QObject,QThread,pyqtSignal,
                          QVariant,
                          Qt)

from qgis.PyQt.QtWidgets import QMessageBox, QDialog, QProgressBar, QLabel

from PyQt5.QtGui import QKeySequence

from PyQt5.QtWidgets import (QCompleter,
                             QDialogButtonBox,
                             QComboBox,
                             QCheckBox)

import os
import time

crsNone = QgsCoordinateReferenceSystem()
epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg4004 = QgsCoordinateReferenceSystem('EPSG:4004')
epsg3857 = QgsCoordinateReferenceSystem('EPSG:3857')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

distance_units = (QgsUnitTypes.DistanceMeters,
                  QgsUnitTypes.DistanceKilometers,
                  QgsUnitTypes.DistanceFeet,
                  QgsUnitTypes.DistanceYards,
                  QgsUnitTypes.DistanceMiles,
                  QgsUnitTypes.DistanceNauticalMiles,
                  QgsUnitTypes.DistanceCentimeters,
                  QgsUnitTypes.DistanceMillimeters,
                  QgsUnitTypes.DistanceDegrees,
                  QgsUnitTypes.DistanceUnknownUnit)
area_units     = (QgsUnitTypes.AreaSquareMeters,
                  QgsUnitTypes.AreaSquareKilometers,
                  QgsUnitTypes.AreaSquareFeet,
                  QgsUnitTypes.AreaSquareYards,
                  QgsUnitTypes.AreaSquareMiles,
                  QgsUnitTypes.AreaHectares,
                  QgsUnitTypes.AreaAcres,
                  QgsUnitTypes.AreaSquareNauticalMiles,
                  QgsUnitTypes.AreaSquareCentimeters,
                  QgsUnitTypes.AreaSquareMillimeters,
                  QgsUnitTypes.AreaSquareDegrees,
                  QgsUnitTypes.AreaUnknownUnit) 

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Geometry.ui'))

class Worker(QObject):
    finished = pyqtSignal()
    cancel = pyqtSignal()
    progress = pyqtSignal(int, str)
    stopped = pyqtSignal()

    def __init__(self, layer, expression, addfieldnames, use_checkBox_0):
        super().__init__()
        self.layer = layer
        self.expression = expression
        self.addfieldnames = addfieldnames
        self.use_checkBox_0 = use_checkBox_0
        self._is_stopped = False

    def run(self):

        # 에러 유무 판별
        try:
            # 필드명과, 표현식 순환 
            count = 0
            fields = self.layer.fields()
            for vf in self.addfieldnames:
                if fields.indexOf(vf) < 0:
                    field = QgsField(vf, QVariant.Double)
                    self.layer.dataProvider().addAttributes([field])
            self.layer.updateFields()
            # self.layer.commitChanges()
            for name , expre in zip(self.addfieldnames , self.expression):
                if self._is_stopped:
                    self.stopped.emit()
                    return
                
                expression = QgsExpression(expre)
                context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(self.layer))
                
                # 객체 확인
                objects = (self.layer.selectedFeatures()
                            if self.use_checkBox_0
                            else self.layer.getFeatures())
                objectCount = (self.layer.selectedFeatureCount()
                            if self.use_checkBox_0
                            else self.layer.featureCount())


                # 만들 필드명이 기존에 있는지 판별 있다면. 필드 번호 반환 없다면 -1 값 반환
                idx = self.layer.fields().indexOf(name)
            
                # 입력 필드가 가상 필드 일때 True
                if self.layer.fields().fieldOrigin(idx) == QgsFields.OriginExpression:
                    # 표현식으로 새로운값 업데이트
                    self.layer.updateExpressionField(idx, expre)
                    percent = 100
                    count = objectCount

                # 입력 필드가 일반 필드 일때 True
                elif self.layer.fields().fieldOrigin(idx) in (
                        QgsFields.OriginProvider, QgsFields.OriginEdit):

                    changes = {}
                    for object in objects:
                        if self._is_stopped:
                            self.stopped.emit()
                            return
                        context.setFeature(object)
                        new_value = expression.evaluate(context)
                        changes[object.id()] = {idx: new_value}
                        count += 1
                        percent = ((count/len(self.addfieldnames))/float(objectCount)) * 100
                        self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfieldnames),0))}]") 
                        # self.iface.mainWindow().statusBar().showMessage("{}/{} : Processed {} %".format(objectCount,count,int(percent)))
                    
                    self.layer.startEditing()
                    self.layer.dataProvider().changeAttributeValues(changes)
                    # self.layer.commitChanges()
                    # self.layer.triggerRepaint()
                    # 기본값 으로 저장
                    #     default = QgsDefaultValue(expre, True)
                    #     layer.setDefaultValueDefinition(idx, default)    

            # 변환 완료        
            # self.iface.messageBar().pushMessage("도형 계산기 처리 완료", level=Qgis.Info, duration=4)

            # self.progressBar.setValue(0)
            # self.progressBar.setTextVisible(False)
            # self.label.setText('변환 완료')

            if self._is_stopped:
                self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfieldnames),0))}] 변환 중단")
                self.cancel.emit()
            else:
                self.progress.emit(percent, f"[{objectCount}/{int(round(count/len(self.addfieldnames),0))}] 변환 완료")
                self.finished.emit()
            # 에러가 있다면
        except Exception as e:
            self.cancel.emit()
            self.messageBar().pushMessage(f"Error : {e}, '{name}' 필드 처리 불가", level=Qgis.Warning, duration=4)

    def stop(self):
        self._is_stopped = True

class CoordinateToolGeometry(QDialog, FORM_CLASS):
    def __init__(self,iface, parent):
        
        super(CoordinateToolGeometry, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.toggle)
        
        self.mMapLayerComboBox.layerChanged.connect(self.LayerChange)
        self.mMapLayerComboBox.setAllowEmptyLayer(True)
        self.mMapLayerComboBox.setCurrentIndex(0)
        
        self.Line_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_0,'Line','0'))
        self.Line_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_1,'Line','1'))
        self.Line_checkBox_2.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_2,'Line','2'))
        self.Polygon_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_0,'Polygon','0'))
        self.Polygon_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_1,'Polygon','1'))
        self.Polygon_checkBox_2.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_2,'Polygon','2'))
        self.Polygon_checkBox_3.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_3,'Polygon','3'))
        self.Point_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Point_checkBox_0,'Point','0'))
        self.Point_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Point_checkBox_1,'Point','1'))
        
        self.Transform_checkBox.stateChanged.connect(self.Transformchk)
        
        self.Line_UnitsComboBox_1.currentIndexChanged.connect(lambda : self.ComboBoxChange('1'))
        self.Line_UnitsComboBox_2.currentIndexChanged.connect(lambda : self.ComboBoxChange('2'))
        
        # self.buttonBox.button(QDialogButtonBox.Ok).clicked.connect(self.run)
        self.pushButton.clicked.connect(self.run)

        self.pushButton_2.clicked.connect(self.close)

        # self.buttonBox.button(QDialogButtonBox.Cancel).clicked.connect(self.cancelRun)
        
    def Transformchk(self): 
        if self.Transform_checkBox.isChecked():
            layer = self.mMapLayerComboBox.currentLayer()
            self.mQgsProjectionSelectionWidget.setEnabled(True)
            self.mQgsProjectionSelectionWidget.setCrs(layer.crs())
        else:
            self.mQgsProjectionSelectionWidget.setEnabled(False)
            self.mQgsProjectionSelectionWidget.setCrs(crsNone)
        
    def ComboBoxChange(self, idx):
        if idx=='1' :
            self.Line_FieldComboBox_1.setEditText(str(self.Line_UnitsComboBox_1.currentText()[:3])+'_X')
        if idx=='2' :
            self.Line_FieldComboBox_2.setEditText(str(self.Line_UnitsComboBox_2.currentText()[:3])+'_Y')
    
    def chkset(self, checkBox, obj, idx):
        val = True if checkBox.isChecked() else False
        if obj== 'Line':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)
            self.findChild(QComboBox,obj+'_UnitsComboBox_'+idx).setEnabled(val)
            if idx=='1' :
                self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEditText(str(self.Line_UnitsComboBox_1.currentText()[:3])+'_X')
            if idx=='2' :
                self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEditText(str(self.Line_UnitsComboBox_2.currentText()[:3])+'_Y')
                
        if obj== 'Polygon':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)
            if idx=='0' or idx=='1':
                self.findChild(QComboBox,obj+'_UnitsComboBox_'+idx).setEnabled(val)
        if obj== 'Point':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)

    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.close()
        if e.matches(QKeySequence.InsertParagraphSeparator):
            self.run()
            
    def toggle(self):
        # 현재 레이어층 가져오기
        # layer = self.canvas.currentLayer()
        layer = self.mMapLayerComboBox.currentLayer()
        
        if layer and layer.type() == layer.VectorLayer:
            try:
                layer.editingStarted.disconnect(self.toggle)
            except:
                pass
            try:
                layer.editingStopped.disconnect(self.toggle)
            except:
                pass
            
            # 현재 도면층이 편집 가능하고 선택한 피쳐가 있는지 확인
            # 그리고 플러그인 버튼을 활성화할지 비활성화할지 결정합니다.
            # 도면층 편집 활성화
            # if layer.isEditable():
            if layer.selectedFeatureCount() > 0:
                self.checkBox_0.setEnabled(True)
                self.checkBox_0.setChecked(True)
            else:
                self.checkBox_0.setChecked(False)
                self.checkBox_0.setEnabled(False)
            layer.editingStopped.connect(self.toggle)
            # 도면층을 편집 비활성화
            # else:
            #     for i in range(len(self.actions)-1):
            #         self.actions[i].setEnabled(False)
            #     layer.editingStarted.connect(self.toggle)
        else:
            self.checkBox_0.setChecked(False)
            self.checkBox_0.setEnabled(False)

    # def closeEvent(self,e):
        # self.CTool.coordinateGeometry.setChecked(False)
        
    def showEvent(self,e):
        # self.CTool.coordinateGeometry.setChecked(True)
        self.tab_1.setEnabled(False)
        self.tab_2.setEnabled(False)
        self.tab_3.setEnabled(False)
        self.Transform_checkBox.setEnabled(False)
        self.mQgsProjectionSelectionWidget.setEnabled(False)
        self.mMapLayerComboBox.setCurrentIndex(0)      
        for checkstate in self.findChildren(QCheckBox):
            checkstate.setChecked(False)
            
        self.label.setText('')
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(False)

    def LayerChange(self):
        layer = self.mMapLayerComboBox.currentLayer()
        fields = []
        # print(layer.type())
        # print(layer.geometryType())
        # print(layer .wkbType())
        # print(QgsWkbTypes.displayString(layer .wkbType()))
        
        for checkstate in self.findChildren(QCheckBox):
            checkstate.setChecked(False)
        
        if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
            laytype = layer.geometryType()
            self.Transform_checkBox.setEnabled(True)
            
            self.checkBox_0.setEnabled(True) if layer.selectedFeatureCount() > 0 else self.checkBox_0.setChecked(False)
            self.checkBox_0.setChecked(True) if layer.selectedFeatureCount() > 0 else self.checkBox_0.setChecked(False)
                
            for x in layer.fields():
                fields.append(x.name())
                
            self.tab_1.setEnabled(False)
            self.tab_2.setEnabled(False)
            self.tab_3.setEnabled(False)
                
            def combo(combobox):
                for ComboBox in combobox:
                    text = ComboBox.currentText()
                    ComboBox.clear()
                    ComboBox.addItems(fields)
                    ComboBox.setCompleter(QCompleter(fields))
                    ComboBox.setEditText(text)
                    
            if laytype ==  QgsWkbTypes.LineGeometry:
                self.tabWidget.setCurrentIndex(0)
                combobox=[self.Line_FieldComboBox_0,self.Line_FieldComboBox_1,self.Line_FieldComboBox_2]
                combo(combobox)
                self.tab_1.setEnabled(True) 
                
            elif laytype ==  QgsWkbTypes.PolygonGeometry:
                self.tabWidget.setCurrentIndex(1)
                combobox=[self.Polygon_FieldComboBox_0,self.Polygon_FieldComboBox_1,self.Polygon_FieldComboBox_2,self.Polygon_FieldComboBox_2]
                combo(combobox)
                self.tab_2.setEnabled(True)

            elif laytype ==  QgsWkbTypes.PointGeometry:
                self.tabWidget.setCurrentIndex(2)
                combobox=[self.Point_FieldComboBox_0,self.Point_FieldComboBox_1]
                combo(combobox)
                self.tab_3.setEnabled(True)
        else:
            self.Transform_checkBox.setEnabled(False)
            self.tabWidget.setCurrentIndex(0)
            self.tab_1.setEnabled(False)
            self.tab_2.setEnabled(False)
            self.tab_3.setEnabled(False)

    def startset(self):
        self.time_start = time.perf_counter()
        self.label.setText('')
        self.worker_stopped = False
        
    def reportProgress(self, value, txt):
        self.progressBar.setValue(value)
        self.label.setText(txt)

    def getExpression(self):
        layer = self.mMapLayerComboBox.currentLayer()
        laytype = layer.geometryType()

        addfieldnames=[]
        expression=[]
        TransCrs = self.mQgsProjectionSelectionWidget.crs().authid()
        TransCrs=f"'{TransCrs}'"
        Transform=self.Transform_checkBox.isChecked()
        setCrs = TransCrs if Transform else '@layer_crs'
        
        if laytype ==  QgsWkbTypes.LineGeometry:
            if self.Line_checkBox_0.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_0.currentText())
                expression.append("round(Length(transform( $geometry, @layer_crs, 'EPSG:5179' )),2)" if self.Line_UnitsComboBox_0.currentIndex()==0 else "round(Length(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000,5)")
            if self.Line_checkBox_1.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_1.currentText())
                if self.Line_UnitsComboBox_1.currentIndex()==0:
                    expression.append(f'x(transform(start_point($geometry),@layer_crs,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==1:
                    expression.append(f'x(transform(line_interpolate_point(geometry:=$geometry,distance:=length(geom_from_wkt( geom_to_wkt( $geometry)))/2),@layer_crs ,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==2:
                    expression.append(f'x(transform(end_point($geometry),@layer_crs,{setCrs}))')
            if self.Line_checkBox_2.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_2.currentText())
                if self.Line_UnitsComboBox_1.currentIndex()==0:
                    expression.append(f'y(transform(start_point($geometry),@layer_crs,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==1:
                    expression.append(f'y(transform(line_interpolate_point(geometry:=$geometry,distance:=length(geom_from_wkt( geom_to_wkt( $geometry)))/2),@layer_crs ,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==2:
                    expression.append(f'y(transform(start_point($geometry),@layer_crs,{setCrs}))')
        elif laytype ==  QgsWkbTypes.PolygonGeometry:
            if self.Polygon_checkBox_0.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_0.currentText())
                expression.append(("area(transform( $geometry, @layer_crs, 'EPSG:5179' ))" if self.Polygon_UnitsComboBox_0.currentIndex()==0 else "area(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000000"))
            if self.Polygon_checkBox_1.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_1.currentText())
                expression.append(("Perimeter(transform( $geometry, @layer_crs, 'EPSG:5179' ))" if self.Polygon_UnitsComboBox_1.currentIndex()==0 else "Perimeter(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000"))
            if self.Polygon_checkBox_2.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_2.currentText())
                expression.append(f'x( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
            if self.Polygon_checkBox_3.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_3.currentText())
                expression.append(f'y( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
        elif laytype ==  QgsWkbTypes.PointGeometry:
            if self.Point_checkBox_0.isChecked():
                addfieldnames.append(self.Point_FieldComboBox_0.currentText())
                expression.append(f'x( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
            if self.Point_checkBox_1.isChecked():
                addfieldnames.append(self.Point_FieldComboBox_1.currentText())
                expression.append(f'y( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')

        print(expression, addfieldnames)
        
        return  expression, addfieldnames

    def run(self):
        try:
            self.startset()
            self.pushButton_2.setText('취소')
            self.pushButton_2.clicked.disconnect()
            self.pushButton_2.clicked.connect(self.cancelRun)
        # # creating a label widget 
        #     progressLabel = QLabel() 
        #     progressLabel.setAlignment(Qt.AlignVCenter |Qt.AlignLeft) # AlignLeft  AlignRight AlignCenter 
        #     progressLabel.setStyleSheet("QLabel {margin: 0px;}")  # 테두리 설정 "border :2px solid blue;"
        #     # progressLabel.setFixedWidth(200)
        #     progressLabel.adjustSize()
        #     progressLabel.setText('좌표변환기')
        # # adding label to status bar ㄴ
        #     # self.iface.mainWindow().statusBar().addWidget(progressLabel)
        # # 프로그레스바 설정
        #     progress = QProgressBar()
        #     progress.setMaximum(100)
        #     progress.setMinimumWidth(300) # 최소 가로 크기 설정
        #     # progress.setMaximumWidth(400)  # 최대 가로 크기 설정
        # # 글자위치 설정
        #     progress.setAlignment(Qt.AlignVCenter | Qt.AlignCenter) # Qt.AlignLeft
        # # 스타일시트를 사용하여 ProgressBar의 색상 설정
        #     progress.setStyleSheet("QProgressBar {"
        #                                     "border: 1px solid grey;"
        #                                     "border-radius: 0px;"
        #                                     "background-color: #FFFFFF;"
        #                                     "}"

        #                                     "QProgressBar::chunk {"
        #                                     "background-color: #37c9e1;"
        #                                     "}")

        #     # self.iface.mainWindow().statusBar().addWidget(progress)

            self.layer = self.mMapLayerComboBox.currentLayer()

            # 변환옵션에 맞춰 표현식 작성
            expression, addfieldnames = self.getExpression()

            self.progressBar.setValue(0)
            self.progressBar.setTextVisible(True)

            # 편집모드 활성화
            self.layer.startEditing()

            self.layer.beginEditCommand("Feature Start Editing")
            self.layer.undoStack().beginMacro('도형계산기')

            # fields = self.layer.fields()
            # for vf in self.addfieldnames:
            #     if fields.indexOf(vf) < 0:
            #         field = QgsField(vf, QVariant.Double)
            #         self.layer.addAttribute(field)
            # self.layer.updateFields()
            # self.layer.commitChanges()

            use_checkBox_0 = self.checkBox_0.isChecked()

            self.thread = QThread()
            self.worker = Worker(self.layer, expression, addfieldnames, use_checkBox_0)
            self.worker.moveToThread(self.thread)

            self.thread.started.connect(self.worker.run)
            self.worker.finished.connect(self.thread.quit)
            self.worker.finished.connect(self.worker.deleteLater)
            self.thread.finished.connect(self.thread.deleteLater)
            self.worker.progress.connect(self.reportProgress)
            self.worker.stopped.connect(self.onThreadStopped)
            self.thread.start()
            self.thread.finished.connect(self.onThreadFinished)
            self.pushButton.setEnabled(False)
            self.thread.finished.connect(lambda: self.pushButton.setEnabled(True))

            # layer.undoStack().endMacro()

        except Exception as e:
            print(f"Error: {e}")
            self.layer.rollBack()

    def onThreadFinished(self):
        if not self.worker_stopped:
            self.canvas.refresh()
            QMessageBox.information(self, "작업 완료", "작업이 완료되었습니다.")
        self.worker_stopped = False
        self.mMapLayerComboBox.currentLayer().triggerRepaint()
        self.colse_set()

    def cancelRun(self):
        self.worker_stopped = True
        try:
            if hasattr(self, 'worker') and hasattr(self, 'thread') and self.thread.isRunning():
                self.worker.stop()
                self.thread.quit()
                self.thread.wait()
                self.canvas.refresh()
                QMessageBox.information(self, "작업 취소", "작업이 취소되었습니다.")
                self.onThreadStopped()
                if self.mMapLayerComboBox.currentLayer().isEditable():
                    self.mMapLayerComboBox.currentLayer().rollBack()
                self.colse_set()
        except:
            self.colse_set()
            pass

    def onThreadStopped(self):
        self.colse_set()
        self.progressBar.setValue(0)
        self.label.setText('작업이 취소되었습니다')
        self.pushButton.setEnabled(True)
        self.colse_set()

    def colse_set(self):
        self.pushButton_2.setText('닫기')
        self.pushButton_2.clicked.disconnect()
        self.pushButton_2.clicked.connect(self.close)
        self.canvas.refresh()
