# -*- coding: utf-8 -*-

from qgis.PyQt import QtWidgets
from qgis.PyQt.uic import loadUiType
from qgis.core import NULL, Qgis, QgsWkbTypes, QgsVectorLayer, QgsFeature, QgsProject, QgsField, QgsClassificationJenks, QgsSpatialIndex, QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer
from qgis.PyQt.QtCore import QSettings, QVariant
from qgis.PyQt.QtWidgets import QComboBox, QSpinBox, QCheckBox, QLabel, QToolButton
from qgis.PyQt.QtGui import QColor, QIcon

from scipy.stats import gaussian_kde # KDE 계산을 위해 필요
import matplotlib.pyplot as plt
import numpy as np
import os

# UI 파일 로드
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui','Coordinate_Tool_Jenks.ui'))

class JenksDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """플러그인 초기화 및 UI 시그널 연결"""
        super(JenksDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        
        self.chk = False
        self.mFieldComboBox = False
        
        self.dirPath = os.path.dirname(__file__)

        # 1. 레이어 선택 콤보박스 설정
        self.layerListComboBox.layerChanged.connect(lambda *_: self.LayerChange())
        self.layerListComboBox.setAllowEmptyLayer(True)
        self.layerListComboBox.setCurrentIndex(0)

        # 2. 분류 단계 설정 이벤트 연결
        self.comboBox.currentIndexChanged.connect(lambda *_: self.checkBox_Cha(0))

        # 3. 필드 선택 이벤트 연결
        for i in range(1, 6):
            f_combo = self.findChild(QComboBox, f'mFieldComboBox_{i}')
            f_combo.currentIndexChanged.connect(lambda _, idx=i: self.FieldComboBox_Cha(idx))
            t_button = self.findChild(QToolButton, f'toolButton_{i}')
            t_button.setIcon(QIcon(os.path.join(self.dirPath, "icons/down.png")))
            t_button.clicked.connect(lambda _, idx=i: self.ToolButton_Cha(idx))

            s_lab = self.findChild(QLabel, f'label_sorted_{i}')
            s_lab.setText('내림차순')
            if i != 1:
                f_combo.hide()
                t_button.hide()
                s_lab.hide()
                self.findChild(QLabel, f'label_{i}').hide()
                self.findChild(QSpinBox, f'spinBox_ratio{i}').hide()

        # 4. 필드 추가삭제 이벤트 연결
        self.toolButton_add.clicked.connect(lambda *_: self.fieldSet('add'))
        self.toolButton_add.setIcon(QIcon(os.path.join(self.dirPath, "icons/memo_add.png")))
        self.toolButton_del.clicked.connect(lambda *_: self.fieldSet('del'))
        self.toolButton_del.setIcon(QIcon(os.path.join(self.dirPath, "icons/memo_remove.png")))
        self.toolButton_re.clicked.connect(lambda *_: self.fieldSet('reset'))
        self.toolButton_re.setIcon(QIcon(os.path.join(self.dirPath, "icons/reload.png")))
        self.fieldSetval = 1

        # 5. 그룹 네이밍 설정 이벤트 연결
        self.comboBox_naming.currentIndexChanged.connect(lambda *_: self.naming_chk(0))

        # 6. 옵션 체크박스 이벤트 연결
        self.checkBox_0.stateChanged.connect(lambda *_: self.checkBox_Cha(0))
        self.groupBox_2.hide() # 인접 가산점 그룹박스 초기 숨김

        for i in range(1, 11):
            chk_box = self.findChild(QCheckBox, f'checkBox_{i}')
            chk_box.stateChanged.connect(lambda _, idx=i: self.checkBox_Cha(idx))

        # 7. QGIS 인터페이스 이벤트 연결
        # self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        # self.canvas.selectionChanged.connect(self.toggle)

        self.chk = True

    # --------------------------------------------------------------------------
    # UI 이벤트 핸들러
    # --------------------------------------------------------------------------
    def ToolButton_Cha(self, idx):
        s_lab = self.findChild(QLabel, f'label_sorted_{idx}')
        t_button = self.findChild(QToolButton, f'toolButton_{idx}')
        if s_lab.text() == '내림차순':
            t_button.setIcon(QIcon(os.path.join(self.dirPath, "icons/up.png")))
            s_lab.setText('오름차순')
        else:
            t_button.setIcon(QIcon(os.path.join(self.dirPath, "icons/down.png")))
            s_lab.setText('내림차순')

    def naming_chk(self,idx):
        naming_type = self.comboBox_naming.currentText() # 123, ABC, 가나다 
        if naming_type == "123...":
            self.comboBox.setEnabled(True)
        elif naming_type == "ABC...":
            self.comboBox.setEnabled(True)
        elif naming_type == "가나다...":
            self.comboBox.setEnabled(True)
        elif naming_type == "상/중/하" or naming_type == "높음/보통/낮음":
            self.comboBox.setCurrentIndex(1)
            self.comboBox.setEnabled(False)
        elif naming_type == "탁월/우수/양호/보통/미흡" or naming_type == "매우밀집/밀집/보통/낮음/희소":
            self.comboBox.setCurrentIndex(3)
            self.comboBox.setEnabled(False)

        raw_labels = self.group_labels(naming_type)
        G_LABELS = raw_labels[::-1]
        count = 1
        for g_label in G_LABELS:
            self.findChild(QCheckBox, f'checkBox_{count}').setText(str(g_label))
            count +=1
        for i in range(count, 11):
            self.findChild(QCheckBox, f'checkBox_{i}').setText(str(i))

    def fieldSet(self,type):
        if type == 'add' and self.fieldSetval < 5:
            self.fieldSetval += 1
            self.findChild(QLabel, f'label_{self.fieldSetval}').show()
            self.findChild(QComboBox, f'mFieldComboBox_{self.fieldSetval}').show()
            self.findChild(QSpinBox, f'spinBox_ratio{self.fieldSetval}').show()
            self.findChild(QToolButton, f'toolButton_{self.fieldSetval}').show()
            self.findChild(QToolButton, f'toolButton_{self.fieldSetval}').setIcon(QIcon(os.path.join(self.dirPath, "icons/down.png")))
            self.findChild(QLabel, f'label_sorted_{self.fieldSetval}').show()
            self.findChild(QLabel, f'label_sorted_{self.fieldSetval}').setText('내림차순')

        elif type == 'del' and self.fieldSetval > 1:
            self.findChild(QLabel, f'label_{self.fieldSetval}').hide()
            self.findChild(QComboBox, f'mFieldComboBox_{self.fieldSetval}').setCurrentIndex(0)
            self.findChild(QComboBox, f'mFieldComboBox_{self.fieldSetval}').hide()
            self.findChild(QSpinBox, f'spinBox_ratio{self.fieldSetval}').hide()
            self.findChild(QSpinBox, f'spinBox_ratio{self.fieldSetval}').setValue(0)
            self.findChild(QToolButton, f'toolButton_{self.fieldSetval}').hide()
            self.findChild(QToolButton, f'toolButton_{self.fieldSetval}').setIcon(QIcon(os.path.join(self.dirPath, "icons/down.png")))
            self.findChild(QLabel, f'label_sorted_{self.fieldSetval}').hide()
            self.findChild(QLabel, f'label_sorted_{self.fieldSetval}').setText('내림차순')
            self.fieldSetval -= 1

        elif type == 'reset':
            for i in range(2, 6):
                self.findChild(QLabel, f'label_{i}').hide()
                self.findChild(QComboBox, f'mFieldComboBox_{i}').setCurrentIndex(0)
                self.findChild(QComboBox, f'mFieldComboBox_{i}').hide()
                self.findChild(QSpinBox, f'spinBox_ratio{i}').hide()
                self.findChild(QToolButton, f'toolButton_{i}').hide()
                self.findChild(QToolButton, f'toolButton_{i}').setIcon(QIcon(os.path.join(self.dirPath, "icons/down.png")))
                self.findChild(QLabel, f'label_sorted_{i}').hide()
                self.findChild(QLabel, f'label_sorted_{i}').setText('내림차순')
            self.mFieldComboBox_1.setCurrentIndex(0)
            self.label_sorted_1.setText('내림차순')
            self.spinBox_ratio1.setValue(0)
            self.fieldSetval = 1

    def FieldComboBox_Cha(self,idx):
        """지표 필드 선택 시 가중치(Ratio) 자동 배분"""
        if self.mFieldComboBox:
            active_boxes = []
            empty_boxes = []
            for i in range(1, 6):
                f_box = self.findChild(QComboBox, f'mFieldComboBox_{i}')
                s_box = self.findChild(QSpinBox, f'spinBox_ratio{i}')
                if f_box.currentIndex() > 0:
                    active_boxes.append(s_box)
                else:
                    empty_boxes.append(s_box)
            
            if active_boxes:
                ratio = round(100 / len(active_boxes))
                for s in active_boxes: s.setValue(ratio)
                for s in empty_boxes: s.setValue(0)

    def checkBox_Cha(self,idx):
        """체크박스 상태에 따른 UI 활성화/비활성화 제어✒️"""
        if idx == 0: # 인접 가산점 사용 여부
            if self.checkBox_0.isChecked():
                self.groupBox_2.show()
                group_cnt = int(self.comboBox.currentText())-1
                for i in range(1, 11):
                    self.findChild(QCheckBox, f'checkBox_{i}').setVisible(i <= group_cnt)
                    self.findChild(QSpinBox, f'spinBox_index_{i}').setVisible(i <= group_cnt)
                self.naming_chk(0)
            else:
                self.groupBox_2.hide()
        else: # 개별 등급별 가산점 활성화
            chk = self.findChild(QCheckBox, f'checkBox_{idx}')
            spin = self.findChild(QSpinBox, f'spinBox_index_{idx}')
            spin.setEnabled(chk.isChecked())

    # def toggle(self):
    #     """레이어 상태 변경 시 동기화"""
    #     if not self.chk: return
    #     layer = self.layerListComboBox.currentLayer()
    #     if not (layer and layer.type() == layer.VectorLayer):
    #         self.groupBox_2.hide()

    # --------------------------------------------------------------------------
    # 레이어 변경 이벤트
    # --------------------------------------------------------------------------
    def LayerChange(self):
        """선택 레이어 변경 시 필드 목록 업데이트"""
        self.mFieldComboBox = False
        if not self.chk: return

        try: self.pushButton.clicked.disconnect(self.run)
        except: pass

        self.layer = self.layerListComboBox.currentLayer()
        if self.layerListComboBox.currentIndex() > 0:
            self.groupBox.setEnabled(True)
            self.comboBox.setEnabled(True)
            self.comboBox_naming.setEnabled(True)
            self.checkBox_0.setEnabled(True)
            for i in range(1,6):
                f_box = self.findChild(QComboBox, f'mFieldComboBox_{i}')
                sp_box = self.findChild(QSpinBox, f'spinBox_ratio{i}')
                s_lab = self.findChild(QLabel, f'label_sorted_{i}')
                f_box.setLayer(self.layer)
                f_box.setAllowEmptyFieldName(True)
                f_box.setCurrentIndex(0)
                s_lab.setText('내림차순')
                sp_box.setValue(0)
            self.mFieldComboBox = True
            self.naming_chk(0)
            self.pushButton.clicked.connect(self.run)
        else:
            self.groupBox.setEnabled(False)
            self.comboBox.setEnabled(False)
            self.comboBox.setCurrentIndex(1)
            self.comboBox_naming.setEnabled(False)
            self.comboBox_naming.setCurrentIndex(0)
            self.checkBox_0.setEnabled(False)
            self.fieldSet('reset')

            for i in range(1,6):
                self.findChild(QComboBox,'mFieldComboBox_'+str(i)).setLayer(None)
                self.findChild(QSpinBox,'spinBox_ratio'+str(i)).setValue(0)
                self.findChild(QLabel, f'label_sorted_{i}').setText('내림차순')

        # self.toggle()

    # --------------------------------------------------------------------------
    # 분류 등급 라벨링
    # --------------------------------------------------------------------------

    def group_labels(self, naming_type):
        K = int(self.comboBox.currentIndex()) + 2 # 등급 개수
        # 선택한 네이밍 방식에 따라 등급 리스트 생성 (가장 오른쪽이 최고 등급)
        if naming_type == "ABC...":
            import string
            # K가 5라면 ['E', 'D', 'C', 'B', 'A'] 생성 (A가 최고 등급)
            raw_labels = list(string.ascii_uppercase[:K])
            GROUP_LABELS = raw_labels[::-1]
        elif naming_type == "가나다...":
            # K가 5라면 ['마', '라', '다', '나', '가'] 생성 (가가 최고 등급)
            ganada = ["가", "나", "다", "라", "마", "바", "사", "아", "자", "차"]
            raw_labels = ganada[:K]
            GROUP_LABELS = raw_labels[::-1]
        elif naming_type == "123...":
            # K가 5라면 ['5', '4', '3', '2', '1'] 생성 (1이 최고 등급)
            GROUP_LABELS = [str(i) for i in range(K, 0, -1)]
        elif naming_type == "상/중/하":
            GROUP_LABELS = ["상", "중", "하"][::-1]
        elif naming_type == "높음/보통/낮음":
            GROUP_LABELS = ["높음", "보통", "낮음"][::-1]
        elif naming_type == "탁월/우수/양호/보통/미흡":
            GROUP_LABELS = ["탁월", "우수", "양호", "보통", "미흡"][::-1]
        elif naming_type == "매우밀집/밀집/보통/낮음/희소":
            GROUP_LABELS = ["매우밀집", "밀집", "보통", "낮음", "희소"][::-1]

        return GROUP_LABELS
    
    # --------------------------------------------------------------------------
    # 핵심 분석 로직 (Run)
    # --------------------------------------------------------------------------

    def run(self):
        """데이터 분석 및 등급 분류 실행"""
        layer = self.layerListComboBox.currentLayer()
        if not layer: return

        K = int(self.comboBox.currentIndex()) + 2 # 등급 개수
        naming_type = self.comboBox_naming.currentText() # 123, ABC, 가나다 
        GROUP_LABELS = self.group_labels(naming_type)
        
        # 등급 우선순위 (가산점 계산 시 비교용)
        # 예: 'A'는 인덱스 4이므로 'B'(인덱스 3)보다 높은 우선순위를 가짐
        grade_priority = {label: i for i, label in enumerate(GROUP_LABELS)}

        # 2. 분석 지표 및 가중치 수집
        METRICS_MAP = {}

        for i in range(1, 6):
            f_name = self.findChild(QComboBox, f'mFieldComboBox_{i}').currentField()
            if f_name:
                sp_box_val = self.findChild(QSpinBox, f'spinBox_ratio{i}').value()
                sorted_idx = 0 if '내림차순' == self.findChild(QLabel, f'label_sorted_{i}').text() else 1

                METRICS_MAP[f_name] = [sp_box_val / 100.0, sorted_idx]
                
        if not METRICS_MAP:
            self.iface.messageBar().pushMessage("오류", "필드와 가중치를 설정해주세요.", level=Qgis.Warning)
            return

        # 3. 결과 저장용 메모리 레이어 생성 및 필드 정의
        uri = f"{QgsWkbTypes.displayString(layer.wkbType())}?crs={layer.crs().authid()}"
        memory_layer = QgsVectorLayer(uri, f"{layer.name()}_분석결과", "memory")
        memory_layer_data = memory_layer.dataProvider()

        # 기존 필드 + 새 분석 필드 추가
        new_fields = list(layer.fields())
        metric_fields = list(METRICS_MAP.keys())

        for m in metric_fields:
            new_fields.append(QgsField(f"{m}_표준화점수", QVariant.Double))
            new_fields.append(QgsField(f"{m}_등급", QVariant.String))

        new_fields += [
            QgsField("종합점수", QVariant.Double),
            QgsField("종합등급", QVariant.String)
        ]

        if layer.isSpatial() and self.checkBox_0.isChecked():
            new_fields += [
                QgsField("인접가산점", QVariant.Double),
                QgsField("인접가산_종합점수", QVariant.Double),
                QgsField("인접가산_종합등급", QVariant.String)
            ]

        memory_layer_data.addAttributes(new_fields)
        memory_layer.updateFields()
        indices = {n: memory_layer.fields().indexFromName(n) for n in memory_layer.fields().names()}

        # 4. 데이터 수집 및 결측치 필터링 (통계 왜곡 방지)
        collected_data = []     # 계산 대상 (하나라도 값이 있는 객체)
        temp_features = []      # 유효 피처 리스트
        excluded_features = []  # 모든 값이 NULL인 피처 (보관 후 나중에 합침)

        for f in layer.getFeatures():
            row_values = {}
            has_valid_data = False # 모든 필드가 NULL인지 확인하기 위한 플래그

            for m in metric_fields:
                val = f[m]
                # NULL 체크 (QVariant NULL, None, 'NULL' 문자열 모두 대응)
                if val == NULL or val is None or val == 'NULL' or str(val).strip().upper() == 'NULL':
                    row_values[m] = None 
                else:
                    try:
                        row_values[m] = float(val)
                        has_valid_data = True # 숫자로 변환 가능한 값이 하나라도 있으면 True
                    except (ValueError, TypeError):
                        row_values[m] = None

            feat = QgsFeature(memory_layer.fields())
            feat.setGeometry(f.geometry())
            feat.setAttributes(f.attributes())

            if has_valid_data:
                temp_features.append(feat)
                # 통계 계산용 데이터 리스트에도 추가
                collected_data.append({"data": {"values": row_values}, "fid": None})
            else:
                # 모든 지표가 없는 경우, 나중에 추가하기 위해 따로 저장
                excluded_features.append(feat)

        # 5. 유효 데이터 추가 및 통계 계산
        res = memory_layer_data.addFeatures(temp_features)
        ok = res[0] if isinstance(res, tuple) else res

        if not ok:
            self.iface.messageBar().pushMessage("오류", "메모리 레이어 피처 추가 실패", level=Qgis.Warning)
            return

        # addFeatures가 feat.id()를 채워주는 전제(대부분의 QGIS 버전에서 in-place로 채워짐)
        for i, f in enumerate(memory_layer.getFeatures()):
            collected_data[i]["fid"] = f.id()

        if not temp_features:
            self.iface.messageBar().pushMessage("알림", "유효한 데이터가 있는 행이 없습니다.", level=Qgis.Info)
            return
        
        memory_layer.startEditing()
        all_weighted_z_scores = []

        # 지표별 표준화(Z-Score) 및 Jenks 등급 산정
        for f_name in metric_fields:
            # 1. 값이 있는 데이터만 필터링 (결측치 제외)
            valid_indices = [i for i, d in enumerate(collected_data) if d["data"]["values"][f_name] is not None]
            valid_vals = np.array([collected_data[i]["data"]["values"][f_name] for i in valid_indices])
            
            if len(valid_vals) > 0:
                mean = np.mean(valid_vals)
                std = np.std(valid_vals) if np.std(valid_vals) != 0 else 1.0
                cls = QgsClassificationJenks()
                brks = [c.lowerBound() for c in cls.classes(valid_vals.tolist(), K)] + [valid_vals.max()]
                
                # 정렬 방식 가져오기 (0: 내림차순, 1: 오름차순) [cite: 126]
                sort_type = METRICS_MAP[f_name][1]

                z_scores = np.zeros(len(collected_data))
                for i, d in enumerate(collected_data):
                    val = d["data"]["values"][f_name]
                    fid = d["fid"]
                    if val is not None:
                        # Jenks 그룹 인덱스 계산 (0 ~ K-1)
                        idx = next((j for j, b in enumerate(brks[:-1]) if brks[j] <= val <= brks[j+1]), 0)

                        if sort_type == 0: # 내림차순 (큰 수가 1등급)
                            z = (val - mean) / std
                            grade = GROUP_LABELS[idx]
                        else: # 오름차순 (작은 수가 1등급)
                            z = -(val - mean) / std  # Z-score 부호를 반전시켜 낮은 값이 높은 점수가 되게 함
                            grade = GROUP_LABELS[(K - 1) - idx] # 라벨 인덱스를 반전
                    else:
                        z = -3.0 
                        grade = GROUP_LABELS[0]   # 최저등급

                    z_scores[i] = z
                    memory_layer.changeAttributeValue(fid, indices[f"{f_name}_표준화점수"], float(z))
                    memory_layer.changeAttributeValue(fid, indices[f"{f_name}_등급"], grade)
                
                all_weighted_z_scores.append(z_scores * METRICS_MAP[f_name][0])

        # 종합 점수 및 등급 산정
        total_scores = np.sum(all_weighted_z_scores, axis=0)
        score_cls = QgsClassificationJenks()
        score_brks = [c.lowerBound() for c in score_cls.classes(total_scores.tolist(), K)] + [total_scores.max()]

        for i, d in enumerate(collected_data):
            score = float(total_scores[i])
            idx = next((j for j, b in enumerate(score_brks[:-1]) if score_brks[j] <= score <= score_brks[j+1]), 0)
            memory_layer.changeAttributeValue(d["fid"], indices["종합점수"], score)
            memory_layer.changeAttributeValue(d["fid"], indices["종합등급"], GROUP_LABELS[idx])

        memory_layer.commitChanges()

        # 6. 공간 인접 가산점 처리 (선택 옵션)
        # layer.isSpatial()은 레이어에 기하학적 정보가 있는지 True/False로 반환합니다.   수정전 QgsWkbTypes.displayString(layer .wkbType()) == "NoGeometry"
        if layer.isSpatial() and self.checkBox_0.isChecked():
            final_grade_field = "인접가산_종합등급"
            final_score_field = "인접가산_종합점수"
            self.apply_adjacency_bonus(memory_layer, indices, K, score_brks, GROUP_LABELS, grade_priority)
        else:
            final_grade_field = "종합등급"
            final_score_field = "종합점수"

        # 7. 심볼화 적용 및 레이어 추가
        if layer.isSpatial():
            self.apply_symbology(memory_layer, K, GROUP_LABELS, final_grade_field)

        #  요약 레이어 출력
        if self.checkBox_sumry.isChecked():
            # 최종 필드명(final_score_field, final_grade_field)을 함께 전달
            self.apply_sumry(layer, memory_layer, metric_fields, naming_type, GROUP_LABELS, final_score_field, final_grade_field)

        # 제외되었던 NULL 객체들 최종 병합 (Else 심볼로 표시됨)
        if excluded_features:
            memory_layer_data.addFeatures(excluded_features)

        QgsProject.instance().addMapLayer(memory_layer)

        # 8. 시각화 차트 출력
        if self.checkBox_charts.isChecked():
            data_dict = {f: [d["data"]["values"][f] for d in collected_data if d["data"]["values"][f] is not None] for f in metric_fields}
            self.show_distribution_charts(metric_fields, data_dict, total_scores, score_brks, K, final_grade_field)
    
    # --------------------------------------------------------------------------
    # 보조 분석 및 시각화 함수
    # --------------------------------------------------------------------------

    def apply_sumry(self, layer, memory_layer, metric_fields, naming_type, GROUP_LABELS, final_score_field, final_grade_field):
        """종합 통계 요약 레이어 생성 및 데이터 추가"""
        # 통계용 메모리 레이어 생성
        stat_uri = "None?crs=" + layer.crs().authid() 
        stat_layer = QgsVectorLayer(stat_uri, f"{layer.name()}_종합통계표", "memory")
        stat_data = stat_layer.dataProvider()

        # 선택한 네이밍 방식에 따라 등급 리스트 생성 (가장 오른쪽이 최고 등급)
        if naming_type == "123...":
            g_field = QgsField("그룹", QVariant.Int)
        else: # "123"
            g_field = QgsField("그룹", QVariant.String)

        # 필드 구성
        stat_fields = [
            QgsField("지표", QVariant.String),
            g_field,
            QgsField("건수", QVariant.Int),
            QgsField("최대", QVariant.Double),
            QgsField("최소", QVariant.Double),
            QgsField("평균", QVariant.Double)
        ]
        stat_data.addAttributes(stat_fields)
        stat_layer.updateFields()
        
        stat_features = []
        # 통계 계산 시 속도를 위해 피처 리스트화 (NULL 값 제외 필터링 포함)
        all_feats = list(memory_layer.getFeatures())
        # 정렬 순서: 최고 등급(1, A, 가)이 표 상단에 오도록 GROUP_LABELS를 역순으로 순회 
        sorted_labels = GROUP_LABELS[::-1]

        # (1) 개별 지표별 등급 통계
        for m_name in metric_fields:
            grade_field = f"{m_name}_등급"
            for label in sorted_labels:
                # 해당 지표 값이 NULL이 아니고 등급이 일치하는 데이터만 추출
                vals = [float(f[m_name]) for f in all_feats 
                if str(f[grade_field]) == label and f[m_name] != NULL]
                
                if vals:
                    feat = QgsFeature(stat_layer.fields())
                    feat.setAttributes([
                        m_name, 
                        label, 
                        len(vals), 
                        float(np.max(vals)), 
                        float(np.min(vals)), 
                        float(np.mean(vals))
                    ])
                    stat_features.append(feat)
            
        # (2) 종합 점수 등급 통계 (전달받은 최종 필드명 사용)
        # 인접가산을 썼다면: 최초(종합점수) + 최종(인접가산_종합점수) 둘 다 요약에 추가
        is_adj = (final_score_field != "종합점수") or (final_grade_field != "종합등급")
        if is_adj:
            # (2-1) 종합 점수 등급 통계 (최초: 가산 전)
            for label in sorted_labels:
                vals = [float(f["종합점수"]) for f in all_feats
                        if str(f["종합등급"]) == label and f["종합점수"] != NULL]
                if vals:
                    feat = QgsFeature(stat_layer.fields())
                    feat.setAttributes([
                        '종합점수',
                        label,
                        len(vals),
                        float(np.max(vals)),
                        float(np.min(vals)),
                        float(np.mean(vals))
                    ])
                    stat_features.append(feat)

        # (2-2) 종합 점수 등급 통계
        for label in sorted_labels:
            # 종합 점수가 NULL이 아니고 등급이 일치하는 데이터 추출
            vals = [float(f[final_score_field]) for f in all_feats 
                if str(f[final_grade_field]) == label and f[final_score_field] != NULL]
            if vals:
                feat = QgsFeature(stat_layer.fields())
                feat.setAttributes([
                    final_score_field, 
                    label, 
                    len(vals), 
                    float(np.max(vals)), 
                    float(np.min(vals)), 
                    float(np.mean(vals))
                ])
                stat_features.append(feat)
    
        # 데이터 추가 및 레이어 로드
        if stat_features:
            stat_data.addFeatures(stat_features)
            QgsProject.instance().addMapLayer(stat_layer)
        else:
            self.iface.messageBar().pushMessage("알림", "통계 요약을 생성할 데이터가 없습니다.", level=Qgis.Info)

    def apply_adjacency_bonus(self, layer, indices, K, brks, labels, priority):
        """공간 인접성을 기반으로 점수 가산 및 등급 재산정"""
        # 레이어가 비공간적이라면 즉시 종료
        if not layer.isSpatial():
            return
        
        layer.startEditing()
        spatial_index = QgsSpatialIndex(layer.getFeatures())
        
        # 가산점 설정값 수집
        # 등급 명칭(labels)과 가산점 설정값(SpinBox) 매칭
        # labels[-1]은 항상 최고 등급(1, A, 가)이고, 이는 SpinBox_index_1과 매칭됩니다.
        sens_dict = {}
        for i in range(1, K + 1):
            chk_box = self.findChild(QCheckBox, f'checkBox_{i}')
            if chk_box and chk_box.isChecked():
                spin_box = self.findChild(QSpinBox, f'spinBox_index_{i}')
                # 역순 인덱싱을 통해 labels의 등급 명칭을 키로 사용 (예: "A": 0.2)
                grade_label = labels[-i] 
                sens_dict[grade_label] = spin_box.value() / 100.0

        # 등급 구간의 너비 계산
        class_widths = [brks[i+1] - brks[i] for i in range(len(brks)-1)]

        for feat in layer.getFeatures():
            curr_grade = feat["종합등급"]
            curr_idx = priority[curr_grade]
            
            # 기본값 복사
            layer.changeAttributeValue(feat.id(), indices["인접가산_종합점수"], feat["종합점수"])
            layer.changeAttributeValue(feat.id(), indices["인접가산_종합등급"], curr_grade)

            # 최고 등급(labels[-1])인 경우 가산점 계산 제외 _ 1, A, 가
            if curr_grade == labels[-1]: 
                continue

            # 인접 피처 탐색 및 가산점 계산
            neighbors = spatial_index.intersects(feat.geometry().boundingBox())
            max_bonus = 0

            for nid in neighbors:
                if nid == feat.id(): continue
                nb_f = layer.getFeature(nid)

                # 실제로 닿아있는지 확인
                if nb_f.geometry().touches(feat.geometry()):
                    nb_grade = nb_f["종합등급"]

                    # 인접한 피처가 가산점 설정 대상이고, 현재 피처보다 높은 등급(우선순위)인 경우
                    if nb_grade in sens_dict and priority[nb_grade] > curr_idx:
                        max_bonus = max(max_bonus, sens_dict[nb_grade])

            # 가산점 적용 및 등급 재결정
            if max_bonus > 0:
                # 현재 등급 구간 너비에 가산율을 곱해 점수 계산
                b_score = class_widths[curr_idx] * max_bonus
                f_score = feat["종합점수"] + b_score
                # 새로운 점수가 어느 등급 구간에 속하는지 확인
                f_idx = next((j for j, b in enumerate(brks[:-1]) if brks[j] <= f_score <= brks[j+1]), K-1)
                layer.changeAttributeValue(feat.id(), indices["인접가산점"], b_score)
                layer.changeAttributeValue(feat.id(), indices["인접가산_종합점수"], f_score)
                layer.changeAttributeValue(feat.id(), indices["인접가산_종합등급"], labels[f_idx])
        layer.commitChanges()

    # 결과 레이어 심볼 설정
    def apply_symbology(self, layer, K, GROUP_LABELS, field_name):
        
        """등급별 색상 및 데이터 없음(Else) 심볼 설정"""
        colors = ["#d7191c", "#e65538", "#f59053", "#fdbe74", "#fedf99", "#ffffbf", "#ddf1b4", "#bce4a9", "#91cba8", "#5ea7b1"]
        categories = []
        sorted_labels = GROUP_LABELS[::-1]
        # 1. 유효 등급 심볼 (1 ~ K)
        for i in range(K):
            lbl = str(sorted_labels[i])
            sym = QgsSymbol.defaultSymbol(layer.geometryType())
            c_idx = int((i / (K-1)) * (len(colors)-1)) if K > 1 else 0
            sym.setColor(QColor(colors[c_idx]))
            categories.append(QgsRendererCategory(lbl, sym, lbl))

        # 2. 데이터 없음(NULL) 심볼 추가
        null_sym = QgsSymbol.defaultSymbol(layer.geometryType())
        null_sym.setColor(QColor("#d3d3d3")) # 회색
        null_sym.setOpacity(0.2)
        categories.append(QgsRendererCategory("", null_sym, "데이터 없음(NULL)"))

        layer.setRenderer(QgsCategorizedSymbolRenderer(field_name, categories))
        layer.triggerRepaint()

    def show_distribution_charts(self, metrics, data_dict, final_scores, score_breaks, K, final_grade_field):
        """분포도 및 Jenks 경계 시각화"""
        plt.rcParams['font.family'] = 'Malgun Gothic'
        plt.rcParams['axes.unicode_minus'] = False

        # 1. 시각화 대상 설정 (지표 필드들 + 종합점수)
        targets = metrics + [final_grade_field]
        num_plots = len(targets)
        # 2. 행렬 크기 자동 계산 (2열 고정)
        cols = 2
        rows = (num_plots + 1) // cols  # 올림 계산
        fig, axes = plt.subplots(rows, cols, figsize=(12, 4 if rows == 1 else (rows * 3) ))
        
        # 차트가 1개뿐일 경우 axes가 배열이 아니므로 배열로 강제 변환
        if num_plots == 1:
            axes = np.array([axes])
        else:
            axes = axes.flatten()

        for i, col in enumerate(targets):
            ax = axes[i]
            # 데이터 추출 (종합점수 또는 개별지표)
            vals = np.asarray(final_scores if col == final_grade_field else data_dict[col], dtype=float)
            vals = vals[~np.isnan(vals)]
            if len(vals) == 0: continue

            # 히스토그램 및 밀도 곡선(KDE)
            ax.hist(vals, bins=30, density=True, color="skyblue", edgecolor="white", alpha=0.7)
            try:
                kde = gaussian_kde(vals)
                xr = np.linspace(vals.min(), vals.max(), 100)
                ax.plot(xr, kde(xr), color="#1f77b4", linewidth=1)
            except: pass

            # Jenks 경계선 표시
            curr_brks = score_breaks if col == final_grade_field else \
                        ([c.lowerBound() for c in QgsClassificationJenks().classes(vals.tolist(), K)] + [vals.max()])
            
            y_max = ax.get_ylim()[1]
            for b in curr_brks[1:-1]:
                ax.axvline(b, color='red', linestyle='--', alpha=0.7, linewidth=1)
                ax.text(b, y_max * 0.95, f'{b:.2f}', color='red', ha='center', fontsize=9, bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
            
            ax.set_title(f"[{col}] 분포 및 등급 경계", fontsize=10, pad=15)
            ax.set_xlabel("값")
            ax.set_ylabel("밀도 (Density)")

        # 3. [핵심] 사용하지 않는 나머지 빈 칸(Axis) 제거
        for j in range(i + 1, len(axes)):
            fig.delaxes(axes[j])

        plt.tight_layout()
        plt.subplots_adjust(top=0.9, bottom=0.1, hspace=0.4, wspace=0.2)
        plt.show()