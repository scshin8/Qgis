'''
***************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

***************************************************************************

* 2022.05.14 - 최초개발시작 
* 2022.05.16 - 좌표이동(개별툴)
* 2022.05.18 - 좌표복사(개별툴)
* 2022.07.06 - 좌표복사, 이동 개별툴에서 하나로 통합
* 2022.07.25 - API이용한 주소보기 및 이동 추가(카카오,네이버,브이월드)
             - 복사 및 이동 좌표계 설정가능하도록 수정
             - 웹지도 열기 추가(다음,네이버)
             - 도엽이동 및 경위도 이동 추가
             - 좌표정보 보기 기능 추가
* 2022.09.22 - 키워드 검색 기능 추가(카카오, Ruoto)
             - 주변POI검색기능 추가(Ruoto)
* 2022.10.13 - 경로탑색기능 추가 Ruoto
* 2022.11.07 - 경로탑색기능 추가 네이버
             - SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 2022.11.12 - 좌표변환 기능 추가
             - 필드계산기 함수 추가
             - MMS좌표복사 기능 추가
             - 도형계산기 기능 추가
* 2023.01.30 - speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가
* 2023.02.05 - pip module "pyautogui" 설치 기능 추가
             - 경로탐색 검색기능 개선(카카오 추가), 경로탐색 속도 개선
* 2023.02.07 - pip module 자동 설치 추가
* 2023.02.10 - Coconut 이동 시 Bessel 및 GRS 선택 기능 추가 - 삭제 2024.12.17
* 2023.02.20 - 구글 경로 탐색 기능 개선 (경유지 검색 개선, 구글 탭 추가, 폴리라인 표출 최적화)
* 2023.03.09 - 구글 좌표 주변 검색 기능 추가 및 웹지도 열기 코드 개선
* 2023.03.12 - 경로 탐색 개선
* 2023.09.02 - 검색기능 추가, 협력사 인덱스 추가, 도움말 링크 추가(플러그인 메뉴얼)
* 2023.09.10 - 대권역 속성값 수정, API Key 암호화, 중복 코드 수정
* 2023.09.11 - 행정계 SHP 교체 (군위군 대구광역시 편입)
* 2023.09.17 - 메모장 패널 추가
* 2023.09.18 - 좌표도구 메뉴바 수정
* 2023.09.19 - 메모장 패널 수정(위치 이동, 탭제목 수정기능 추가)
* 2023.09.20 - 웹지도(로드뷰) 방향 설정 추가
* 2023.09.25 - 검색 및 이동 패널 분리, 좌표 복사 시 마우스 위치 정보 표시 기능 추가
* 2023.10.12 - 보간점 표시, 링크 각도 표시 기능 추가 
* 2023.10.12 - 선택한 객체 레이어 복사 기능 추가 
* 2023.10.22 - 링크 각도 표시 기능의 멀티파트 오류 수정
* 2023.11.22 - 속성필터 기능 추가
* 2023.11.26 - 속성 필터 통계값 표시 기능 추가
* 2023.12.01 - 속성 필터 위젯을 도킹 패널 형태로 개선
* 2023.12.10 - 속성 필터에서 통계 패널을 분리 및 필터 속성값 조정
* 2024.01.02 - 인증키 수정
* 2024.01.28 - 좌표변화기, 도형계산기 프로그래스바 추가
* 2024.02.28 - Ruoto 경로 탐색 오류 수정 (경유지 탐색 기능 개선 예정) - 개선 완료 2025.01.16
* 2024.03.06 - 구글스트릿뷰 수정, 속성필터 수정
* 2024.03.29 - 주변POI 카테고리 검색 추가
* 2024.04.14 - 현재위치 검색 추가
* 2024.05.23 - Vworld APIKEY 수정
* 2024.06.03 - 필드계산기 함수 수정
* 2024.06.05 - 카카오, 루토 검색 코드 수정
* 2024.06.18 - 인덱스SHP 가상레이어 가져오기로 수정
* 2024.06.18 - 인덱스SHP 스타일 수정
* 2024.07.11 - MDB To SHP 플러그인 추가
* 2024.10.09 - 보간점 표시 심볼 수정
* 2024.10.12 - 설정 값이 레지스트리에 저장되도록 개선, API 인증키 수정
* 2024.10.15 - 좌표변환기 코드 수정
* 2024.10.16 - 도형계산기 코드 수정
* 2024.10.30 - 선택 레이어 병합 추가
* 2024.11.02 - 선택 레이어 파일 경로 열기 기능 추가 및 SHP 파일 다운로드 방식 개선
* 2024.12.07 - 좌표복사, 메모장, 좌표변환기, 도형계산기 일부 코드 수정
* 2024.12.11 - MDB To SHP UI 변경 및 코드 수정
* 2024.12.15 - 각도 표시 코드 수정 및 라벨 설정 추가
* 2024.12.17 - MacOS 설치 오류 수정 및 Coconut 좌표 이동 기능 최적화
* 2024.12.30 - 선택 객체 복사 시 동일 스타일 유지 기능 추가
* 2025.01.16 - 루토 경유지 경탐 수정
* 2025.01.20 - xyz 타일맵 불러오기 추가 경로:[ 설정 -> 플러그인 설정 -> 타일맵 추가 클릭 ]
             - QGIS 설정 초기화 추가
* 2025.02.14 - 선택 객체 복사 시 객체만 복사 또는 레이어 스타일까지 복사 여부 선택 가능
* 2025.02.17 - 툴박스 알고리즘 추가
                # Qfield Log레이어 생성, 경로의 하위 폴더 리스트 추출
* 2025.02.27 - MDB To SHP 다중 파일 일괄 추출 기능 추가

***************************************************************************
'''

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsApplication,
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer, 
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling,
                       QgsSymbol,
                       QgsSimpleFillSymbolLayer,
                       QgsRendererCategory,
                       QgsCategorizedSymbolRenderer,
                       QgsMapLayer,
                       QgsMarkerSymbol,
                       QgsCoordinateTransform,
                       QgsTextAnnotation,
                       QgsFeatureRequest,
                       QgsProcessingFeatureSourceDefinition,
                       Qgis,
                       QgsFields,
                       QgsField, 
                       QgsFeature)

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF,
                          QVariant)

from qgis.gui import (QgsDockWidget,
                      QgsRubberBand,
                      QgsVertexMarker,
                      QgsMapCanvasAnnotationItem)

from PyQt5.QtGui import (QColor,
                         QIcon,
                         QFont,
                         QTextDocument,
                         QTextCharFormat,
                         QPen,
                         QTextCursor)

from qgis.PyQt.QtWidgets import (QMenu,
                                 QMessageBox)

from PyQt5.QtWidgets import (QApplication,                              
                             QAction, 
                             QToolButton)

from qgis.utils import unloadPlugin

from .CoordinateFunctions import InitLatLonFunctions, UnloadLatLonFunctions
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Move import CoordinateToolMove
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_info import CoordinateToolinfo
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Funtion import Coordinate_funtion
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converte import CoordinateToolConverte
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_Memo import CoordinateToolMemo
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
from .Coordinate_Tool_Searchlayer import LayerSearchDialog
from .Coordinate_Tool_Simple_filter import simple_filterDialog
from .Coordinate_Tool_Statistics import StatisticsDialog
from .Coordinate_Tool_mdbToShp import CoordinateToolmdbToShp
from .toolBox_provider import MyToolBoxProvider

import os, os.path, requests, webbrowser, random, datetime, time, math, subprocess, zipfile, processing, shutil

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

class CoordinateTool:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.crossRb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard = QApplication.clipboard()

    # 좌표도구 툴바 설정
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')

    # 좌표도구 메뉴바 설정
        self.menu = QMenu( "좌표도구(&T)", self.iface.mainWindow().menuBar() )
        self.menu = QMenu(self.iface.mainWindow())
        self.menu.setObjectName("'Coordinate_Tool_menu")
        self.menu.setTitle("좌표도구 (&T)")

        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None  
        self.MediaCenterTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.searchDialog = None
        self.simplefilterDialog = None
        self.Delete_Marker_timer = QTimer()
        self.Markers=[]
        self.MarkerSymbol = []
        self.AngleSymbol = []

        self.vertex_run_chk = False
        self.angle_run_chk = False

        self.plugin_dir = os.path.dirname(__file__)
        self.Plugin='coordinate_tool'
        # self.QSettings = QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        # 함수
        self.Funtion = Coordinate_funtion(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 이동
        self.indexMove = CoordinateToolMove(self, self.iface, self.iface.mainWindow())
        # 좌표변환
        self.Converter = CoordinateToolConverte(self.iface, self.iface.mainWindow())
        # 도형계산기
        self.Geometry = CoordinateToolGeometry(self.iface, self.iface.mainWindow())
        # mdb쉐입생성
        self.mdbToShp = CoordinateToolmdbToShp(self.iface, self.iface.mainWindow())
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        
        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()
        
        # 좌표변환창 위젯 설정
        self.dlgconversion = CoordinateToolinfo(self,self.iface)
        self.dlgconversionwidget = QgsDockWidget("좌표정보" , self.iface.mainWindow() )
        self.dlgconversionwidget.setObjectName("좌표정보")
        self.dlgconversionwidget.setWidget(self.dlgconversion)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgconversionwidget )
        self.dlgconversionwidget.hide()
        
        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        # 메모장 위젯 설정
        self.dlgmemo = CoordinateToolMemo(self,self.iface)
        self.dlgmemowidget = QgsDockWidget("메모장" , self.iface.mainWindow() )
        self.dlgmemowidget.setObjectName("메모장")
        self.dlgmemowidget.setWidget(self.dlgmemo)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgmemowidget )
        self.dlgmemowidget.hide()

        # 필터 위젯 설정
        self.simplefilter = simple_filterDialog(self,self.iface)
        self.simplefilterwidget = QgsDockWidget("속성필터" , self.iface.mainWindow() )
        self.simplefilterwidget.setObjectName("속성필터")
        self.simplefilterwidget.setWidget(self.simplefilter)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.simplefilterwidget )
        self.simplefilterwidget.hide()

        # 통계 위젯 설정
        self.Statistics = StatisticsDialog(self,self.iface)
        self.Statisticswidget = QgsDockWidget("속성통계" , self.iface.mainWindow() )
        self.Statisticswidget.setObjectName("속성통계")
        self.Statisticswidget.setWidget(self.Statistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Statisticswidget )
        self.Statisticswidget.hide()

        self.provider = MyToolBoxProvider()

        # self.canvas.xyCoordinates.connect(self.CanvasMoveConnect)
        # # self.canvas.xyCoordinates.disconnect()
        # self.canvas.selectionChanged.connect(self.CanvasSelectionChanged)

    def unload(self):
        unloadPlugin(self.Plugin)

    # def CanvasSelectionChanged(self):
    #     layer = self.canvas.currentLayer()
    #     if layer.selectedFeatureCount() > 1:
    #         self.canvas.xyCoordinates.disconnect()
    #     elif layer.selectedFeatureCount() == 0:
    #         self.canvas.xyCoordinates.connect(self.CanvasMoveConnect)

    # def CanvasMoveConnect(self, point):
    #     try:
    #         originalPoint = point
    #         canvasCRS = self.canvas.mapSettings().destinationCrs()
    #         transform = QgsCoordinateTransform(canvasCRS,epsg4162, QgsProject.instance())
    #         BESPoint = transform.transform(originalPoint)
    #         bes = self.Funtion.fscoordinate(BESPoint)
    #         # maid8Lv = self.Funtion.mapid_8Lv(BESPoint)
    #         map, company, team, ctp, sig = self.Funtion.mapidinfo(bes)
    #         self.iface.statusBarIface().showMessage("{} / {} / {} / {} / {} / {}".format(company, team, ctp, sig, map, bes))
    #     except:
    #         self.iface.statusBarIface().showMessage("canvasMoveEvent : Error")

    def initGui(self):

        # 필드계산기 함수 추가
        InitLatLonFunctions()
        
        # # 메뉴바 생성
        # self.menu = '&좌표도구'

        QgsApplication.processingRegistry().addProvider(self.provider)

# ===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("복사")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('copymenu')

    # 좌표 복사
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)
        self.copy1 = Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 
        # self.Coordinatecapture.setEnabled(False)

    # 미디어센터 좌표 이동
        icon = QIcon(self.plugin_dir + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        self.copy2 = Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 
        # self.MediaCenter.setEnabled(False)

    # 주소확인
        icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소보기", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소보기')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.copy.addAction(self.mapaddress)
        self.copy3 = Menu.addAction(self.mapaddress)

    # 좌표 정보
        icon = QIcon(self.plugin_dir + '/icons/information.png')
        self.conversion = QAction(icon, "좌표정보", self.iface.mainWindow())
        self.conversion.setObjectName('좌표정보')
        self.conversion.triggered.connect(self.conversionwidget)
        self.conversion.setCheckable(True)
        self.copy.addAction(self.conversion)
        self.copy4 = Menu.addAction(self.conversion)
        # self.iface.registerMainWindowAction(self.conversion,'Shift+I')
        self.dlgconversionwidget.setToggleVisibilityAction(self.conversion)

    # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.copy)

    # 메뉴에 드롭다운 목록 추가
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.copycopy = QAction(icon, '좌표,주소,미디어센터', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)

        # 플러그인 메뉴에 추가
        # self.iface.addPluginToMenu("좌표도구" , self.copycopy)

        self.menu.addAction(self.copycopy)

#===============================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('movemenu')

    # 좌표이동 1
        icon = QIcon(self.plugin_dir + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(lambda : self.mapMove(1,self.movemap1))
        self.movemap.addAction(self.movemap1)
        self.movemap.setDefaultAction(self.movemap1)
        self.movemenu1 = Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        # self.movemap1.setEnabled(False)

    # 좌표이동 2
        icon = QIcon(self.plugin_dir + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(lambda : self.mapMove(2,self.movemap2))
        self.movemap.addAction(self.movemap2)
        self.movemenu2 = Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        # self.movemap2.setEnabled(False)

    # 좌표이동 3
        icon = QIcon(self.plugin_dir + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(lambda : self.mapMove(3,self.movemap3))
        self.movemap.addAction(self.movemap3)
        self.movemenu3 = Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        # self.movemap3.setEnabled(False)

    # 도엽, 주소, 경위도 이동
        icon = QIcon(self.plugin_dir + '/icons/indexMove.png')
        self.moveIndex = QAction(icon, "도엽이동", self.iface.mainWindow())
        self.moveIndex.setObjectName('도엽이동')
        # self.coordinateConverter.setCheckable(True)
        self.moveIndex.triggered.connect(self.Move)
        self.movemap.addAction(self.moveIndex)
        self.movemenu4 = Menu.addAction(self.moveIndex)
        self.iface.registerMainWindowAction(self.moveIndex,'Alt+F')

    # 웹검색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/search.png')
        self.search = QAction(icon, "검색", self.iface.mainWindow())
        self.search.setObjectName('검색')
        self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.movemap.addAction(self.search)
        self.movemenu4 = Menu.addAction(self.search)
        # self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)

    # 경로탐색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        self.path_search.triggered.connect(self.PathSearchwidget)
        self.path_search.setCheckable(True)
        self.movemap.addAction(self.path_search)
        self.movemenu5 = Menu.addAction(self.path_search)
        # self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)

        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(self.plugin_dir + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)

        self.menu.addAction(self.movemove)

#===========================================================================================================================
    # 웹지도 열기
        icon = QIcon(self.plugin_dir + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        # self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        # self.ShowOnmap.setEnabled(False)
        self.menu.addAction(self.ShowOnmap)

#===========================================================================================================================
    # 속성필터 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/filter.png')
        self.simple_filter = QAction(icon, "속성필터", self.iface.mainWindow())
        self.simple_filter.setObjectName('속성필터')
        # self.simple_filter.triggered.connect(self.filterRun)
        self.simple_filter.setCheckable(True)
        self.toolbar.addAction(self.simple_filter)
        # self.iface.registerMainWindowAction(self.simple_filter,'F4')
        self.simplefilterwidget.setToggleVisibilityAction(self.simple_filter)
        self.menu.addAction(self.simple_filter)

#===========================================================================================================================
    # 속성통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.selectStatistics = QAction(icon, "속성통계", self.iface.mainWindow())
        self.selectStatistics.setObjectName('속성통계')
        self.selectStatistics.setCheckable(True)
        self.toolbar.addAction(self.selectStatistics)
        # self.iface.registerMainWindowAction(self.simple_filter,'F4')
        self.Statisticswidget.setToggleVisibilityAction(self.selectStatistics)
        self.menu.addAction(self.selectStatistics)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
    # 좌표변환 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        # self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        self.geo1=Menu.addAction(self.coordinateConverter)
        # self.coordinateConverter.setEnabled(False)

    # 도형계산 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        # self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        self.geo2=Menu.addAction(self.coordinateGeometry)
        # self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.geo)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.indexshp = QToolButton(self.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('쉐입파일')

    # 베셀인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(lambda : self.shpIndex(1, self.besindex, "Bessel_Index", "Bessel_Index.shp",  "MAP_ID", "협력사", 0.3 ))
        self.indexshp.addAction(self.besindex)
        self.indexshp.setDefaultAction(self.besindex)
        self.shp1=Menu.addAction(self.besindex)

    # GRS인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "GRS인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('GRS인덱스')
        self.grsindex.triggered.connect(lambda : self.shpIndex(2, self.grsindex, "GRS_Index", "GRS_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex)
        self.shp2=Menu.addAction(self.grsindex)

    # WGS84인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/wgsindex.png')
        self.wgsindex = QAction(icon, "WGS인덱스", self.iface.mainWindow())
        self.wgsindex.setObjectName('WGS인덱스')
        self.wgsindex.triggered.connect(lambda : self.shpIndex(3, self.wgsindex, "WGS84_Index", "WGS84_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex)
        self.shp3=Menu.addAction(self.wgsindex)

    # 협력사 구문 인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/partnerindex.png')
        self.parindex = QAction(icon, "협력사인덱스", self.iface.mainWindow())
        self.parindex.setObjectName('협력사인덱스')
        self.parindex.triggered.connect(lambda : self.shpIndex(4, self.parindex, "협력사_Index", "Partner_Index.shp","협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex)
        self.shp4=Menu.addAction(self.parindex)

    # 시도행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(lambda : self.shpIndex(5, self.ctpshp, "시도행정계", "ctp.shp", "CTP_KOR_NM", "CTP_KOR_NM", 0.6))
        self.indexshp.addAction(self.ctpshp)
        self.shp5=Menu.addAction(self.ctpshp)

    # 시군구행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(lambda : self.shpIndex(6, self.sigshp, "시군구행정계", "sig.shp", "SIG_KOR_NM", "CTP_KOR_NM", 0.3))
        self.indexshp.addAction(self.sigshp)
        self.shp6=Menu.addAction(self.sigshp)

    # 읍명동 행정계 쉐입 열기
        # icon = QIcon(self.plugin_dir + '/icons/emd.png')
        # self.emdshp = QAction(icon, "읍면동행정계", self.iface.mainWindow())
        # self.emdshp.setObjectName('읍면동행정계')
        # self.emdshp.triggered.connect(lambda : self.shpIndex(7))
        # self.indexshp.addAction(self.emdshp)
        # self.shp6=Menu.addAction(self.emdshp)

    # 파일열기 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.shpfileopen = QAction(icon, "파일열기", self.iface.mainWindow())
        self.shpfileopen.setObjectName('파일열기')
        self.shpfileopen.triggered.connect(self.fileopen)
        # self.shpfileopen.setCheckable(True)
        self.indexshp.addAction(self.shpfileopen)
        # self.indexshp.setDefaultAction(self.shpfileopen)
        self.shp7=Menu.addAction(self.shpfileopen)
        # self.iface.registerMainWindowAction(self.shpfileopen,'Shift+O')

    # 북마크 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self.indexshp.addAction(self.Bookmark)
        self.shp8=Menu.addAction(self.Bookmark)

        self.toolbar.addWidget( self.indexshp)
        
        icon = QIcon(self.plugin_dir + '/icons/shp.png')
        self.shp = QAction(icon, '쉐입파일', self.iface.mainWindow())
        self.shp.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.shp)

        self.menu.addAction(self.shp)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self._addin = QToolButton(self.toolbar)
        self._addin.setPopupMode(QToolButton.MenuButtonPopup)
        self._addin.setObjectName("추가기능")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('추가기능')

    # 메모 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/memo.png')
        self.memo = QAction(icon, "메모장", self.iface.mainWindow())
        self.memo.setObjectName('메모장')
        self.memo.triggered.connect(self.notepad)
        self.memo.setCheckable(True)
        self._addin.addAction(self.memo)
        self._addin.setDefaultAction(self.memo)
        # self.iface.addPluginToMenu("좌표도구", self.memo)
        self.dlgmemowidget.setToggleVisibilityAction(self.memo)
        # self.iface.registerMainWindowAction(self.memo,'F2')
        self.shp1=Menu.addAction(self.memo)

    # mdb to shp
        icon = QIcon(self.plugin_dir + '/icons/mdbToShp.png')
        self._mdbToShp = QAction(icon, "MDB쉐입생성", self.iface.mainWindow())
        self._mdbToShp.setObjectName('MDB쉐입생성')
        self._mdbToShp.triggered.connect(self.show_mdbToShp)
        self._addin.addAction(self._mdbToShp)
        # self.iface.registerMainWindowAction(self.searchAction,'F4')
        self.shp2=Menu.addAction(self._mdbToShp)

    # 속성검색 위젯 열기
        # icon = QIcon(self.plugin_dir + '/icons/searchLayers.png')
        # self.searchAction = QAction(icon, "속성검색", self.iface.mainWindow())
        # self.searchAction.setObjectName('속성검색')
        # self.searchAction.triggered.connect(self.showSearchDialog)
        # self._addin.addAction(self.searchAction)
        # # self.iface.registerMainWindowAction(self.searchAction,'F4')
        # self.shp2=Menu.addAction(self.searchAction)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate1.png')
        self.duplicate = QAction(icon, "선택객체복사(스타일X)", self.iface.mainWindow())
        self.duplicate.setObjectName('선택객체복사')
        self.duplicate.triggered.connect(lambda : self.duplicate_run(False))
        # self._addin.addAction(self.duplicate)
        self.iface.addCustomActionForLayerType(self.duplicate, None, QgsMapLayer.VectorLayer, True)
        self.shp3=Menu.addAction(self.duplicate)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate1 = QAction(icon, "선택객체복사(스타일O)", self.iface.mainWindow())
        self.duplicate1.setObjectName('선택객체복사')
        self.duplicate1.triggered.connect(lambda : self.duplicate_run(True))
        # self._addin.addAction(self.duplicate)
        self.iface.addCustomActionForLayerType(self.duplicate1, None, QgsMapLayer.VectorLayer, True)
        self.shp4=Menu.addAction(self.duplicate1)

    # 선택레이어병합 실행
        icon = QIcon(self.plugin_dir + '/icons/merge.png')
        self.layermerge = QAction(icon, "선택레이어병합", self.iface.mainWindow())
        self.layermerge.setObjectName('선택레이어병합')
        self.layermerge.triggered.connect(self.layermerge_run)
        # self._addin.addAction(self.layermerge)
        self.iface.addCustomActionForLayerType(self.layermerge, None, QgsMapLayer.VectorLayer, True)
        self.shp5=Menu.addAction(self.layermerge)

    # 선택레이어경로 열기
        icon = QIcon(self.plugin_dir + '/icons/folderPath.png')
        self.folderPath = QAction(icon, "레이어경로열기", self.iface.mainWindow())
        self.folderPath.setObjectName('레이어경로열기')
        self.folderPath.triggered.connect(self.folderOpen)
        # self._addin.addAction(self.folderPath)
        self.iface.addCustomActionForLayerType(self.folderPath, None, QgsMapLayer.VectorLayer, True)
        self.shp6=Menu.addAction(self.folderPath)

    # 선택객체 보간점 표시
        icon = QIcon(self.plugin_dir + '/icons/vertex.png')
        self.vertex = QAction(icon, "보간점 표시", self.iface.mainWindow())
        self.vertex.setObjectName('보간점 표시')
        self.vertex.setCheckable(True)
        self.vertex.triggered.connect(self.vertex_run)
        self.iface.registerMainWindowAction(self.vertex,'Shift+B')
        self._addin.addAction(self.vertex)
        self.shp7=Menu.addAction(self.vertex)

    # 선택객체 각도 표기
        icon = QIcon(self.plugin_dir + '/icons/angle.png')
        self.angle = QAction(icon, "각도 표시", self.iface.mainWindow())
        self.angle.setObjectName('각도 표시')
        self.angle.setCheckable(True)
        self.angle.triggered.connect(self.angle_run)
        self.iface.registerMainWindowAction(self.angle,'Shift+A')
        self._addin.addAction(self.angle)
        self.shp8=Menu.addAction(self.angle)

        self.toolbar.addWidget( self._addin)

        icon = QIcon(self.plugin_dir + '/icons/addin.png')
        self.__addin = QAction(icon, '추가기능', self.iface.mainWindow())
        self.__addin.setMenu(Menu)

        self.menu.addAction(self.__addin)

#===========================================================================================================================
    # 좌표도구 설정창
        icon = QIcon(self.plugin_dir + '/icons/setting.png')
        self.set = QAction(icon, "좌표도구설정", self.iface.mainWindow())
        self.set.setObjectName('좌표도구설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        # self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')

        self.menu.addAction(self.set)

#===========================================================================================================================
    # Help
        icon = QIcon(self.plugin_dir + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        # self.iface.addPluginToMenu('좌표도구', self.helpAction)

        self.menu.addAction(self.helpAction)

#===========================================================================================================================
    # 상단 메뉴바에 좌표변환 메뉴 추가 
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(),
                           self.menu)

#===========================================================================================================================
    # # 플러그인 확인
    #     today = datetime.date.today()
    #     yyyy = today.year
    #     # 인증 MyPlugin
    #     if yyyy > 2024:
    #         QMessageBox.information(self.iface.mainWindow(), '플러그인 재설치' , '좌표도구 플러그인 업데이트(재설치)가 필요합니다.')  
    #         self.unload()
    #     # self.toggle()

# 도움말===================================================================================================================================================================
    def help(self):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"  
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화========================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        QgsApplication.processingRegistry().removeProvider(self.provider)

    # 메뉴삭제
        self.menu.deleteLater()

        self.vertex.setChecked(False)
        self.vertexdisplay()
        self.angle.setChecked(False)
        self.angledisplay()

    # 화면 정리
        try:
            self.Delete_Marker()
        except:
            pass
        # 경탐 삭제
        try:
            self.dlgPathSearch.delete()
        except:
            pass
        # 검색 삭제
        try:
            self.dlgSearch.RemoveAll()
        except:
            pass
        
    # 보간점, 각도 마크 삭제
        self.remove_Marker()
        self.remove_Angle()

        try:
            self.canvas.selectionChanged.disconnect()
            self.canvas.selectionChanged.disconnect()
        except:
            pass

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        # self.iface.removeToolBarIcon(self.CoordinateSpeedFs)
        # self.iface.removeToolBarIcon(self.CoordinateCoconut)
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.moveIndex)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.conversion)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.shpfileopen)
        self.iface.removeToolBarIcon(self.besindex)
        self.iface.removeToolBarIcon(self.grsindex)
        self.iface.removeToolBarIcon(self.wgsindex)
        self.iface.removeToolBarIcon(self.parindex)
        self.iface.removeToolBarIcon(self.ctpshp)
        self.iface.removeToolBarIcon(self.sigshp)
        # self.iface.removeToolBarIcon(self.emdshp)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.memo)
        self.iface.removeToolBarIcon(self.set)
        # self.iface.removeToolBarIcon(self.searchAction)
        self.iface.removeToolBarIcon(self.simple_filter)
        self.iface.removeToolBarIcon(self.selectStatistics)
        self.iface.removeToolBarIcon(self.layermerge)
        self.iface.removeToolBarIcon(self.folderPath)
        self.iface.removeToolBarIcon(self.vertex)
        self.iface.removeToolBarIcon(self.angle)
        self.iface.removeToolBarIcon(self.duplicate)
        self.iface.removeToolBarIcon(self.duplicate1)

        try:
            del self.toolbar
        except:
            pass

        # 필드계산기 표현식 삭제
        UnloadLatLonFunctions()

        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgconversionwidget)
        self.dlgconversionwidget = None
        self.dlgconversion = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None

        self.iface.mainWindow().removeDockWidget(self.dlgmemowidget)
        self.dlgmemowidget = None
        self.dlgmemo = None

        self.iface.mainWindow().removeDockWidget(self.simplefilterwidget)
        self.simplefilterwidget = None
        self.simplefilter = None

        self.iface.mainWindow().removeDockWidget(self.Statisticswidget)
        self.Statisticswidget = None
        self.Statistics = None

        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        # self.iface.unregisterMainWindowAction(self.CoordinateSpeedFs)
        # self.iface.unregisterMainWindowAction(self.CoordinateCoconut)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.moveIndex)
        self.iface.unregisterMainWindowAction(self.shpfileopen)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.conversion)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.simple_filter)
        self.iface.unregisterMainWindowAction(self.memo)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        # 화면 위치변경 이벤트 해제
        # self.canvas.xyCoordinates.disconnect(self.handleCanvasMove)

        # 레이어 우클릭 목록 삭제
        self.iface.removeCustomActionForLayerType(self.duplicate)
        self.iface.removeCustomActionForLayerType(self.duplicate1)
        self.iface.removeCustomActionForLayerType(self.layermerge)
        self.iface.removeCustomActionForLayerType(self.folderPath)

        mac_dir = os.path.join(os.path.dirname(self.plugin_dir), 'coordinate_tool_mac')

        if os.path.exists(mac_dir):
            shutil.rmtree(mac_dir)

# 레이어 선택 토글 함수 =====================================================================================================================================================
    # def toggle(self):
    #     layer = self.canvas.currentLayer()
    #     if layer :
    #         try:
    #             layer.editingStarted.disconnect(self.toggle)
    #         except:
    #             pass
    #         try:
    #             layer.editingStopped.disconnect(self.toggle)
    #         except:
    #             pass

    #         enabled_flag = True

    #         if layer and layer.type() == layer.VectorLayer:
    #             self.searchAction.setEnabled(True)
    #         else:
    #             self.searchAction.setEnabled(False)

    #         enabled_flag = True
    #     else:
    #         self.searchAction.setEnabled(False)
    #         enabled_flag = False

    #     self.Coordinatecapture.setEnabled(enabled_flag)
    #     # self.CoordinateSpeedFs.setEnabled(enabled_flag)
    #     # self.CoordinateCoconut.setEnabled(enabled_flag)
    #     self.MediaCenter.setEnabled(enabled_flag)
    #     self.movemap1.setEnabled(enabled_flag)
    #     self.movemap2.setEnabled(enabled_flag)
    #     self.movemap3.setEnabled(enabled_flag)
    #     self.ShowOnmap.setEnabled(enabled_flag)
    #     self.mapaddress.setEnabled(enabled_flag)
    #     self.search.setEnabled(enabled_flag)
    #     self.conversion.setEnabled(enabled_flag)
    #     self.path_search.setEnabled(enabled_flag)
    #     self.coordinateConverter.setEnabled(enabled_flag)
    #     self.coordinateGeometry.setEnabled(enabled_flag)

# 좌표 캡쳐 실행==============================================================================================================================================================
    def capture(self):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행=============================================================================================================================================================
    def mediaCenter(self):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionPan().trigger() 

# 주소 복사 실행================================================================================================================================================================
    def address(self):
        # 마커 표시 삭제
        self.copy.setDefaultAction(self.mapaddress)
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionPan().trigger()

# 좌표 정보 확인=============================================================================================================================================================
    def conversionwidget(self):
        self.copy.setDefaultAction(self.conversion)

# 좌표 이동 실행===============================================================================================================================================================
    def mapMove(self, idx, movemap):
        clipText = self.clipboard.text().strip()
        SeqOrder=int(self.QSettings.value('ComboBox' + str(idx+2), 0))
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project' + str(idx+2),'USER:100000'))
        try:
            lon, lat = self.Funtion.setval(setCRS,clipText) # 복사된 좌표 X, Y 좌표 변환
            self.movemap.setDefaultAction(movemap)
            self.Funtion.moveto(setCRS, lon, lat, SeqOrder)
            self.canvas.refresh()
            self.iface.actionPan().trigger()
        except:
            pass

# 도엽이동 실행===================================================================================================================================================================
    def Move(self):
        self.movemap.setDefaultAction(self.moveIndex)
        self.Delete()
        self.canvas.refresh()
        self.indexMove.show()
        
# 검색창 실행===================================================================================================================================================================
    def searchtool(self):
        self.movemap.setDefaultAction(self.search)
        
# 경로탐색 실행 =================================================================================================================================================================
    def PathSearchwidget(self):
        self.movemap.setDefaultAction(self.path_search)

# 웹지도 실행==================================================================================================================================================================
    def ShowOn(self):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            self.iface.actionPan().trigger()

# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================
    def Geometrywidget(self):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        self.Geometry.show() 

# 파일열기 =======================================================================================================================================================================
    def fileopen(self):
        self.indexshp.setDefaultAction(self.shpfileopen)
        self.Delete()
        self.shpBookmark.getOpenFile()

# 쉐입인덱스 불러오기 ============================================================================================================================================================
    def shpIndex(self, idx, Action, cmtName, fileName, leLabefield, symbolfield, lineWidth):
        self.Delete()
        self.indexshp.setDefaultAction(Action)
        layers = QgsProject.instance().mapLayersByName(cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
        # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
            layer.triggerRepaint()   
        else:
        # 인덱스 레이어가 없다면 레이어 추가
            filepath = os.path.join(self.plugin_dir,'shp',fileName)

        # shp 파일이 있다면
            if os.path.isfile(filepath):
            # 서버의 파일과 수정된 시간을 비교하여 파일 업로드 결정
                from datetime import datetime
                from io import BytesIO

            # 로컬파일 시간 가져오기
                modification_time = os.path.getmtime(filepath)
                getctime_time  = datetime.fromtimestamp(int(modification_time))

                file_zip = fileName.split('.')[0] + '.zip'
                raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip

            # 압축 파일 다운로드하지 않고 압축 파일 내부의 시간 정보 확인
                response = requests.get(raw_url, verify=False)
                if response.status_code == 200:
                    with zipfile.ZipFile(BytesIO(response.content)) as shp_zip:
                        try:
                            zipinfo = shp_zip.getinfo(fileName)
                            zipinfo_time = datetime(*zipinfo.date_time)
                            print("압축 파일 내부의 시간:", zipinfo_time)
                        except KeyError:
                            print("해당 파일이 압축 파일 내에 존재하지 않습니다.")
                else:
                    print("파일 다운로드에 실패했습니다. HTTP 상태 코드:", response.status_code)

            # 시간 비교 서버의 파일이 최신이라면 압축해제
                if zipinfo_time > getctime_time:
                    self.indexdownload(fileName)

                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

            else:
                print("파일이 존재하지 않습니다.")
            # shp 파일 다운로드
                self.indexdownload(fileName)
            # 대기
                time.sleep(1)
            # shp 파일 가져오기
                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

    def shpimport(self, idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth):

        existing_layer = QgsVectorLayer(filepath, cmtName, "ogr")
        # QgsProject.instance().addMapLayer(existing_layer)
        # 기존 레이어의 CRS 가져오기
        crs = existing_layer.crs().authid()
        memory_layer = QgsVectorLayer(f"Polygon?crs={crs}", cmtName, "memory")

        # 기존 레이어의 피처를 가상 메모리 레이어로 복사합니다.
        memory_layer_data_provider = memory_layer.dataProvider()
        memory_layer.startEditing()
        memory_layer_data_provider.addAttributes(existing_layer.fields().toList())
        memory_layer.updateFields()

        # 기존 레이어의 피처 한 번에 복사
        features = list(existing_layer.getFeatures())
        memory_layer_data_provider.addFeatures(features)

        # # 기존 레이어의 피처 복사
        # for feature in existing_layer.getFeatures():
        #     memory_layer_data_provider.addFeatures([feature])
        
        memory_layer.commitChanges()
        
        # 레이어를 QGIS 프로젝트에 추가합니다.
        QgsProject.instance().addMapLayer(memory_layer)

        if idx in (1,2,3):
            filepath = str('/shp/' + fileName)
            memory_layer.loadNamedStyle(os.path.join(self.plugin_dir, 'style', "index.qml"))
        else:
            self.setsymbol(memory_layer,leLabefield, symbolfield, lineWidth)
        memory_layer.triggerRepaint()   


    def indexdownload(self, fileName):
        file_zip = fileName.split('.')[0] + '.zip'
    # 저장경로지정
        destination_path = os.path.join(self.plugin_dir, file_zip)
    # 폴더 생성
        extracted_folder = os.path.join(self.plugin_dir,'shp')
        if not os.path.exists(extracted_folder):
            os.makedirs(extracted_folder)
    # 파일 다운로드
        raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip
        response = requests.get(raw_url, verify=False)
        with open(destination_path, 'wb') as file:
            file.write(response.content)
    # 추출할 디렉토리로 압축 해제
        with zipfile.ZipFile(destination_path, 'r') as zip_ref:
            zip_ref.extractall(self.plugin_dir + '/shp')
    # 압축파일 삭제
        if os.path.exists(destination_path):  # 파일이 존재하는지 확인합니다.
            os.remove(destination_path)  # 파일을 삭제합니다.

# 심볼 설정 =================================================================================================================================================================  
    def setsymbol(self,layer,leLabefield, symbolfield, lineWidth): 

        fni = layer.dataProvider().fields().indexFromName(symbolfield)
        unique_values = layer.uniqueValues(fni)

        # fill categories
        categories = []
        for unique_value in unique_values:
            # initialize the default symbol for this geometry type
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())

            # configure a symbol layer
            layer_style = {}
            # layer_style['joinstyle'] = 'bevel'
            layer_style['style'] = 'no'
            layer_style['color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_width'] = lineWidth
            symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)

            # replace default symbol layer with the configured one
            if symbol_layer is not None:
                symbol.changeSymbolLayer(0, symbol_layer)

            # create renderer object
            category = QgsRendererCategory(unique_value, symbol, str(unique_value))
            # entry for the list of category items
            categories.append(category)

        # create renderer object
        renderer = QgsCategorizedSymbolRenderer(symbolfield, categories)

        # assign the created renderer to the layer
        if renderer is not None:
            layer.setRenderer(renderer)

        layer.triggerRepaint()

        #라벨 스타일 설정
        layer_settings  = QgsPalLayerSettings()

        text_format = QgsTextFormat() # 텍스트 포멧 정의
        text_format.setFont(QFont("맑은 고딕")) # 폰트
        text_format.setSize(9) # 크기
        # text_format.setColor(QColor(255, 0, 255, 255)) # 컬러
        
        # 폰트 버퍼 설정
        # buffer_settings = QgsTextBufferSettings()
        # buffer_settings.setEnabled(True) # 버퍼 활성화
        # buffer_settings.setSize(1) # 버퍼 사이즈
        # buffer_settings.setColor(QColor("white")) # 버퍼 컬러
        # text_format.setBuffer(buffer_settings) # 폰트에 버퍼 셋팅
        
        layer_settings.setFormat(text_format) #라벨 스타일에 폰트 셋팅

        layer_settings.fieldName = leLabefield
        # layer_settings.placement = 2
        
        layer_settings.enabled = True
    
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        # 스타일 새로고침
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        # 단일 심볼 스타일 설정
        # 심볼설정
        # soldcol = QColor(0, 0, 0, 0) # 채우기색
        # linecol = QColor(103, 153, 141, 255) # 테두리색 R / G / B / 투명도
        # linecol = QColor(random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256), 255) # 테두리색 R / G / B / 투명도
        # lineWidth = 0.3 # 테두리 너비
        # layer.renderer().symbol().setColor(soldcol) # 채우기색
        # layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 (R , G , B , 투명도) QColor(255, 0, 255, 255)
        # layer.renderer().symbol().symbolLayer(0).setStrokeWidth(lineWidth) # 테두리 너비
        # layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine

# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self):
        self.indexshp.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()

# 메모 패널 실행=====================================================================================================================================================================
    def notepad(self):
        self._addin.setDefaultAction(self.memo)

    def show_mdbToShp(self):
        self._addin.setDefaultAction(self._mdbToShp)
        self.Delete()
        self.mdbToShp.show()

# 검색 실행=====================================================================================================================================================================
    # def showSearchDialog(self):
    #     self._addin.setDefaultAction(self.searchAction)
    #     if self.searchDialog is None:
    #         # All the work is done in the LayerSearchDialog
    #         self.searchDialog = LayerSearchDialog(self.iface, self.iface.mainWindow())
    #         # self._addin.setDefaultAction(self.searchAction)
    #     self.searchDialog.show()

# 설정창 실행===================================================================================================================================================================
    def setting(self):
        self.Delete()
        self.dlg.show()

# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self,t):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시======================================================================================================================================================================
    def Draw_Marker(self,point,idx):
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)

        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()

# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None
        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)

    def vertexdisplay(self):
        self.time_start = time.perf_counter()
        if self.vertex_run_chk:
            layer = self.iface.activeLayer()
            featuresCount = layer.selectedFeatureCount()
        # 선택 객체가 1개 이상 또는 20개 이하 일때만 보간점 표시함
            if featuresCount >= 1 and featuresCount <= 20:
                selected_features = layer.selectedFeatures()
                idx = 0
                # 기존 마커 삭제e
                self.remove_Marker()
                # 리스트 초기화
                selected_objects =[]
                # 프로젝트와 레이어 좌표계 가져오기
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                layer_crs=layer.crs()

                # 선택한 피처의 꼭지점 좌표 출력
                for feature in selected_features:
                    geometry = feature.geometry()
                    wkbType = geometry.wkbType()
                    if geometry:
                        if geometry.wkbType() in (QgsWkbTypes.Point, QgsWkbTypes.PointZM, 
                                                  QgsWkbTypes.MultiPoint, QgsWkbTypes.MultiPointZM):
                            pass
                        else:
                            # 라인스트링, 멀티라인스트링, 다각형, 멀티다각형인 경우 처리
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                vertexs = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                multi_lines = geometry.asMultiPolyline()
                                vertexs = [vertex for lines in multi_lines for vertex in lines]
                            elif wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.PolygonZM:
                                rings = geometry.asPolygon()
                                vertexs = [vertex for ring in rings for vertex in ring[:-1]]
                            elif wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.MultiPolygonZM:
                                multi_Polygons = geometry.asMultiPolygon()
                                vertexs = [vertex for Polygons in multi_Polygons for Polygon in Polygons for vertex in Polygon[:-1]]

                            for vertex in vertexs:
                                transform = QgsCoordinateTransform(layer_crs,canvasCRS, QgsProject.instance())
                                txtProjectPoint = transform.transform(vertex.x(), vertex.y())
                                # print(txtProjectPoint.x(),txtProjectPoint.y())
                                selected_objects.append([txtProjectPoint, idx])
                                idx += 1
                            idx = 0

                # QgsMarkerSymbol 생성 및 설정
                if layer.isEditable():
                    marker_symbol = QgsMarkerSymbol.createSimple({"name":"rectangle", "color":"red","outline_color": "0,0,0,255","outline_style": "no", "size":"0"})  # Arrow Octagon Hexagon Pentagon Ellipse diamond square star Triangle rectangle "outline_style": "sold"
                else:
                    marker_symbol = QgsMarkerSymbol.createSimple({"name":"rectangle", "color":"red","outline_color": "0,0,0,255","outline_style": "no", "size":"0.6"})  # Arrow Octagon Hexagon Pentagon Ellipse diamond square star Triangle rectangle "outline_style": "sold"
                # marker_symbol.setSize(3)
                # marker_symbol.setColor(QColor(255, 0, 0))
                
                # QgsTextAnnotation을 담을 리스트를 생성합니다.
                text_annotations = []   

                size = int(self.QSettings.value('spinBox', 10))
                txtColor = QColor(self.QSettings.value('markerColorButton_5', '#ff0000')).name()
                backColor = QColor(self.QSettings.value('markerColorButton_6', '#ff0000')).name()

                for Vertex, idx in selected_objects:
                    # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                    text_content = f'{str(idx)}'  # 원하는 텍스트를 문자열로 변환
                    # html_text = f'<span style="font-size: 10pt;"><p style="color : #204060">{text_content}</span>'  # <p style="color : #b4b4b4"><b>LonLat2Fs</b>#204060

                    if int(self.QSettings.value('background_checkBox', Qt.Unchecked)) == 0: # 배경 없음

                        html_text = f'<span style="font-size: {size}pt; color : {txtColor};">{text_content}</span>' #  font-weight: bold;  background-color: #ffffff;  #ff0000
                    else:
                        html_text = f'<span style="font-size: {size}pt; color : {txtColor}; background-color: {backColor};">{text_content}</span>' #  font-weight: bold;  background-color: #ffffff;  #ff0000

                    text_document = QTextDocument()
                    text_document.setHtml(html_text)
                    fontDefault = QFont('맑은 고딕')
                    fontDefault.setBold(True)
                    text_document.setDefaultFont(fontDefault)

                    # QgsTextAnnotation 생성 및 설정
                    text_annotation = QgsTextAnnotation(self.canvas)
                    text_annotation.setDocument(text_document)

                    # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                    text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0,0))
                    text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,0))
                    # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                    # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                    text_annotation.setMapPosition(Vertex)
                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                    text_annotation.setMarkerSymbol(marker_symbol)
                    # text_annotation의 크기를 조절
                    text_annotation.setFrameSize(QSizeF(text_document.size().width(),text_document.size().height()))  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                    # QgsTextAnnotation을 리스트에 추가합니다.
                    text_annotations.append(text_annotation)

                # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                self.MarkerSymbol.extend(annotation_items)
                self.canvas.refresh()
            else:
                # 선택한 객체가 없다면
                self.remove_Marker()
                selected_objects = []
                text_annotations = []        
        else:
            self.remove_Marker()    
        # print(time.perf_counter() - self.time_start)

    def angledisplay(self):
        if self.angle_run_chk:
            self.time_start = time.perf_counter()
            layer = self.iface.activeLayer()
            featuresCount = layer.selectedFeatureCount()
            if featuresCount > 0:
                # 기존 마커 삭제
                self.remove_Angle()
                selected_features =layer.selectedFeatures()

                if len(selected_features) != 1:
                    self.iface.messageBar().clearWidgets()
                    # self.iface.messageBar().pushMessage(f'진입링크는 하나만 선택해야 합니다', level=Qgis.Info, duration=3)
                else:
                    self.selected_feature = selected_features[0]
                    # 선택한 링크의 양끝점 좌표를 가져옵니다.
                    geometry = self.selected_feature.geometry()
                    if geometry != None:
                        parts = geometry.asGeometryCollection()
                        # if not geometry.isMultipart():
                        if len(parts) != 1:
                            self.iface.messageBar().pushMessage(f'멀티파츠 객체입니다.', level=Qgis.Info, duration=3)  
                            return

                        wkbType = geometry.wkbType()
                        if geometry:
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                geometry_points = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                geometry_points = geometry.asMultiPolyline()[0]
                            else:   # wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.Point or wkbType == QgsWkbTypes.MultiPoint:
                                return
                        self.start_point0 = geometry_points[0]
                        self.start_point1 = geometry_points[1]
                        self.end_point0 = geometry_points[-1]
                        self.end_point1 = geometry_points[-2]

                        # 기존 메세지창 삭제
                        # self.iface.messageBar().clearWidgets()
                        # self.iface.messageBar().pushMessage(f'진입링크[{self.selected_feature.id()}] 가 선택되었습니다.', level=Qgis.Info, duration=3)

                        map_crs = self.canvas.mapSettings().destinationCrs()  # 화면 좌표계
                        layer_crs = layer.crs()  # 레이어 좌표계
                        transform = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())

                        # 화면 경계를 레이어 좌표계로 변환
                        extent = self.canvas.extent()  # 화면 경계
                        transformed_extent = transform.transformBoundingBox(extent)

                        request = QgsFeatureRequest().setFilterRect(transformed_extent)

                        # 화면에 보이는 피처만 가져오기
                        visible_features = list(layer.getFeatures(request))

                        # 화면 내 인접 피처 찾기
                        adjacent_features = []
                        for feature in visible_features:
                            if feature.id() != self.selected_feature.id():  # 자기 자신 제외
                                if geometry.touches(feature.geometry()):  # 지오메트리가 인접한지 확인
                                    adjacent_features.append(feature)

                    if len(adjacent_features) == 0:
                        return
                    # 인접링크 리스트 생성
                    adjacent_links = []
                    for link_id in adjacent_features:
                        if link_id.id() == self.selected_feature.id():
                            continue  # 선택한 링크 자체는 제외합니다.
                        feature = layer.getFeature(link_id.id())
                        adjacent_geometry = feature.geometry()
                        if adjacent_geometry != None:
                            parts = adjacent_geometry.asGeometryCollection()
                            # if len(parts) == 1:
                            #     wkbType = adjacent_geometry.wkbType()
                            #     # 링크싀
                            #     if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                            #         adjacent_geometry_points = adjacent_geometry.asPolyline()
                            #         adjacent_points_len = len(adjacent_geometry_points)
                            #     elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                            #         adjacent_geometry_points = adjacent_geometry.asMultiPolyline()[0]
                            #         adjacent_points_len = len(adjacent_geometry_points)
                            #     # 꼭지점 좌표 변환
                            #     adjacent_start_point0 = adjacent_geometry_points[0]
                            #     adjacent_start_point1 = adjacent_geometry_points[1]
                            #     adjacent_end_point0 = adjacent_geometry_points[-1]
                            #     adjacent_end_point1 = adjacent_geometry_points[-2]
                            #     length = adjacent_geometry.length()

                            #     # 인접 위치 판별( 시점, 종점 )
                                
                            #     # 디스플레이 좌표
                            #     third_point = adjacent_geometry.interpolate(length * 0.5).asPoint()
                            #     # 시점과 시점 인접
                            #     if self.start_point0 == adjacent_start_point0:
                            #         # 길이의 1/2 지점 좌표 계산
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.2).asPoint() # 0.2
                            #         # else:
                            #         #     third_point = adjacent_start_point1
                            #         adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                            #     # 시점과 종점 인접
                            #     elif self.start_point0 == adjacent_end_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.8).asPoint() # 0.8
                            #         # else:
                            #         #     third_point = adjacent_end_point1
                            #         adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                            #     # 종점과 시점 인접
                            #     elif self.end_point0 == adjacent_start_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.2).asPoint() # 0.2
                            #         # else:
                            #         #     third_point = adjacent_start_point1
                            #         adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                            #     # 종점과 종점 인접
                            #     elif self.end_point0 == adjacent_end_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.8).asPoint() # 0.8
                            #         # else:
                            #         #     third_point = adjacent_end_point1
                            #         adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                            # else:
                            for adjacent_geometry in parts:

                                wkbType = adjacent_geometry.wkbType()
                                # 링크싀
                                if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asPolyline()
                                    adjacent_points_len = len(adjacent_geometry_points)
                                elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asMultiPolyline()[0]
                                    adjacent_points_len = len(adjacent_geometry_points)
                                # 꼭지점 좌표 변환
                                adjacent_start_point0 = adjacent_geometry_points[0]
                                adjacent_start_point1 = adjacent_geometry_points[1]
                                adjacent_end_point0 = adjacent_geometry_points[-1]
                                adjacent_end_point1 = adjacent_geometry_points[-2]
                                length = adjacent_geometry.length()

                                # 인접 위치 판별( 시점, 종점 )

                                # 디스플레이 좌표
                                third_point = adjacent_geometry.interpolate(length * 0.5).asPoint()
                                # 시점과 시점 인접
                                if self.start_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 시점과 종점 인접
                                elif self.start_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                                # 종점과 시점 인접
                                elif self.end_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 종점과 종점 인접
                                elif self.end_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])

                            # 결과값 리스트
                            angles_result = []
                        # 선택한 링크와 인접한 링크의 각도를 계산합니다.
                            for adjacent_link, start_point0, start_point1, end_point0, end_point1,txtPoint in adjacent_links:

                                angle = math.atan2(start_point1.x() - start_point0.x(), start_point1.y() - start_point0.y())
                                selected_feature_angle = math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180

                                angle = math.atan2(end_point1.x() - end_point0.x(), end_point1.y() - end_point0.y())
                                adjacent_feature_angle = math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180

                                abs_angle = round(abs((selected_feature_angle-adjacent_feature_angle) % 360),1)
                                angle_value  = abs_angle -360 if abs_angle > 180 else abs_angle

                                angle_value  = "%g" %round(abs_angle if abs_angle < 0 else 180 - abs_angle, 1)

                            # 좌표를 프로젝트 좌표로 변환 
                                canvasCRS = self.canvas.mapSettings().destinationCrs()
                                layer_crs=layer.crs()
                                transform = QgsCoordinateTransform(layer_crs,canvasCRS, QgsProject.instance())
                                txtProjectPoint = transform.transform(txtPoint.x(), txtPoint.y())

                                angles_result.append([txtProjectPoint,angle_value])

                            # QgsMarkerSymbol 생성 및 설정
                            marker_symbol = QgsMarkerSymbol.createSimple({"name":"rectangle", "color":"red","outline_color": "0,0,0,255","outline_style": "no", "size":"0"}) #"name":"rectangle", 'size_unit': 'MapUnit', 'outline_style': 'solid',
                            # marker_symbol.setSize(0)

                            # QgsTextAnnotation을 담을 리스트를 생성합니다.
                            text_annotations = []   
                                        
                            size = int(self.QSettings.value('spinBox_2', 10))
                            txtColor = QColor(self.QSettings.value('markerColorButton_7', '#ff0000')).name()
                            backColor = QColor(self.QSettings.value('markerColorButton_8', '#ff0000')).name()

                            for point, angle in angles_result:
                                # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                                text_content = str(angle)  # 원하는 텍스트를 문자열로 변환

                                if int(self.QSettings.value('background_checkBox_2', Qt.Unchecked)) == 0: # 배경 없음

                                    html_text = f'<span style="font-size: {size}pt; color : {txtColor};">{text_content}</span>' #  font-weight: bold;  background-color: #ffffff;  #ff0000
                                else:
                                    html_text = f'<span style="font-size: {size}pt; color : {txtColor}; background-color: {backColor};">{text_content}</span>' #  font-weight: bold;  background-color: #ffffff;  #ff0000

                                text_document = QTextDocument()
                                text_document.setHtml(html_text)
                                fontDefault = QFont('맑은 고딕')
                                fontDefault.setBold(True)
                                text_document.setDefaultFont(fontDefault)

                                # QgsTextAnnotation 생성 및 설정
                                text_annotation = QgsTextAnnotation(self.canvas)
                                text_annotation.setDocument(text_document)

                                # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                                text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0,0))
                                text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,0))
                                # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                                # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                                text_annotation.setMapPosition(point)
                                if layer.isEditable():
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                                else:
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(-(text_document.size().width()/2), - (text_document.size().height()/2)))

                                text_annotation.setMarkerSymbol(marker_symbol)
                                # text_annotation의 크기를 조절
                                text_annotation.setFrameSize(QSizeF(text_document.size().width(),text_document.size().height()))  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                                # QgsTextAnnotation을 리스트에 추가합니다.
                                text_annotations.append(text_annotation)

                    # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                    annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                    self.AngleSymbol.extend(annotation_items)
                    self.canvas.refresh()  
            else:
                self.remove_Angle()
                angles_result = []
                text_annotations = []
        else:
            self.remove_Angle()

    def vertex_run(self):
        if self.vertex.isChecked():
            self._addin.setDefaultAction(self.vertex)
            self.canvas.selectionChanged.connect(self.vertexdisplay)
            self.vertex_run_chk = True
            self.vertexdisplay()
        else:
            self.canvas.selectionChanged.disconnect(self.vertexdisplay)
            self.remove_Marker()
            self.vertex_run_chk = False

    def angle_run(self):
        if self.angle.isChecked():
            self._addin.setDefaultAction(self.angle)
            self.canvas.selectionChanged.connect(self.angledisplay)
            self.angle_run_chk = True
        else:
            self.canvas.selectionChanged.disconnect(self.angledisplay)
            self.remove_Angle()
            self.angle_run_chk = False


    def duplicate_run(self, style):
        # 프로그래스바 추가??
        self._addin.setDefaultAction(self.duplicate)
        self.layer_set = set()
        layer = self.iface.activeLayer()
        try:
            selected_features = layer.selectedFeatures()
        except:
            return

        self.layer_set.add(layer)
        for layer in self.layer_set:
            new_name = '__'+layer.name()
            wkb_type = layer.wkbType()
            layer_crs = layer.sourceCrs()
            fields = QgsFields(layer.fields())
            new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
            dp = new_layer.dataProvider()
            dp.addAttributes(fields)
        new_layer.updateFields()

        if style:
            # 스타일을 임시 XML 파일에 저장
            temp_style_file = os.path.join(self.plugin_dir, 'style', 'temp_style.qml')
            layer.saveNamedStyle(temp_style_file)

            # 새 레이어에 스타일 XML 적용
            new_layer.loadNamedStyle(temp_style_file)

        QgsProject.instance().addMapLayer(new_layer)
        new_layer.startEditing()

        for feature in selected_features:
            # 속성 값 가져오기
            attributes = feature.attributes()
            f = QgsFeature()
            f.setGeometry(feature.geometry())  # 올바른 방법: QgsGeometry 객체를 전달
            f.setAttributes(attributes) # 새로운 QgsFeature에 속성 설정
            new_layer.dataProvider().addFeatures([f])

        new_layer.updateExtents()
        self.canvas.refresh()

    def layermerge_run(self):
        self.iface.messageBar().clearWidgets()
        selected_layers = [layer for layer in QgsProject.instance().mapLayers().values() if layer in self.iface.layerTreeView().selectedLayers()]
        if len(selected_layers) < 2:
            self.iface.messageBar().pushMessage(f'병합할 레이어가 두 개 이상 선택되어야 합니다.', level=Qgis.critical, duration=3)
        else:
            # 각 레이어에 "layer_name" 가상 필드 추가
            for layer in selected_layers:
                layer_name = layer.name()  # 현재 레이어 이름
                layer_path = layer.source() # 현재 레이어 경로

                # 가상 필드 추가
                layer.addExpressionField(
                    f"'{layer_name}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_name", QVariant.String),  # 필드명과 유형 설정
                )

                layer.addExpressionField(
                    f"'{layer_path}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_path", QVariant.String),  # 필드명과 유형 설정
                )

            # 병합 처리 실행
            try:
                result = processing.run("native:mergevectorlayers", {
                    "LAYERS": selected_layers,
                    "CRS": selected_layers[0].crs(),
                    "OUTPUT": "memory:"  # 결과를 메모리 레이어로 저장
                })
                # 결과 레이어 이름 지정 및 추가
                merged_layer = result["OUTPUT"]
                merged_layer.setName("병합한 레이어")  # 여기서 이름을 설정

                # 편집 모드 시작
                merged_layer.startEditing()
                for field_name in ["layer", "path"]:  # 제거할 필드 목록
                    idx = merged_layer.fields().indexOf(field_name)
                    if idx != -1:
                        merged_layer.deleteAttribute(idx)
                
                # 편집 모드 종료 및 변경사항 저장
                merged_layer.commitChanges()

                # 병합 레이어 추가
                QgsProject.instance().addMapLayer(merged_layer)

                self.iface.messageBar().pushMessage(f'레이어 병합', level=Qgis.Info, duration=5)
            except Exception as e:
                self.iface.messageBar().pushMessage(f'레이어 병합 오류 : {e}', level=Qgis.critical, duration=5)
                pass

    def folderOpen(self):
        self.iface.messageBar().clearWidgets()
        # 활성화된 레이어 가져오기
        layer = self.iface.activeLayer()
        
        # 레이어가 없는 경우
        if not layer:
            return

        # 임시 레이어인지 확인
        if layer.isTemporary():
            self.iface.messageBar().pushMessage(f'임시 레이어는 경로를 열 수 없습니다.', level=Qgis.Warning, duration=5)
            return

        # 레이어의 소스 경로 가져오기
        layer_source = layer.source()

        # 로컬 파일 경로가 아닌 경우
        if not os.path.isfile(layer_source):
            self.iface.messageBar().pushMessage(f'이 레이어는 로컬 파일이 아닙니다.', level=Qgis.Warning, duration=5)
            return

        # 탐색기에서 경로 열기
        folder_path = os.path.dirname(layer_source)
        os.startfile(folder_path)  # Windows에서 탐색기를 엽니다.

    def remove_Marker(self):
        if len(self.MarkerSymbol) > 0:
            for mark in self.MarkerSymbol:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol = []
        self.canvas.refresh()  
        # items = self.canvas.scene().items()
        # items_to_remove = []
        # for item in items:
        #     if isinstance(item, QgsMapCanvasItem):
        #         if isinstance(item, QgsMapCanvasAnnotationItem):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QTextDocument):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QgsMarkerSymbol):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QgsTextAnnotation):
        #             items_to_remove.append(item)

        # # 찾은 아이템을 캔버스에서 제거
        # for item in items_to_remove:
        #     self.canvas.scene().removeItem(item)
        # self.canvas.refresh()  

    def remove_Angle(self):
        if len(self.AngleSymbol) > 0:
            for mark in self.AngleSymbol:
                self.canvas.scene().removeItem(mark)
        self.AngleSymbol = []
        self.canvas.refresh() 