'''
***************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

***************************************************************************

* 2022.05.14 - 최초개발시작 
* 2022.05.16 - 좌표이동(개별툴)
* 2022.05.18 - 좌표복사(개별툴)
* 2022.07.06 - 좌표복사, 이동 개별툴에서 하나로 통합
* 2022.07.25 - API이용한 주소보기 및 이동 추가(카카오,네이버,브이월드)
             - 복사 및 이동 좌표계 설정가능하도록 수정
             - 웹지도 열기 추가(다음,네이버)
             - 도엽이동 및 경위도 이동 추가
             - 좌표정보 보기 기능 추가
* 2022.09.22 - 키워드 검색 기능 추가(카카오, Ruoto)
             - 주변POI검색기능 추가(Ruoto)
* 2022.10.13 - 경로탑색기능 추가 Ruoto
* 2022.11.07 - 경로탑색기능 추가 네이버
             - SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 2022.11.12 - 좌표변환 기능 추가
             - 필드계산기 함수 추가
             - MMS좌표복사 기능 추가
             - 도형계산기 기능 추가
* 2023.01.30 - speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가
* 2023.02.05 - pip module "pyautogui" 설치 기능 추가
             - 경로탐색 검색기능 개선(카카오 추가), 경로탐색 속도 개선
* 2023.02.07 - pip module 자동 설치 추가
* 2023.02.10 - Coconut 이동 시 Bessel 및 GRS 선택 기능 추가 - 삭제 2024.12.17
* 2023.02.20 - 구글 경로 탐색 기능 개선 (경유지 검색 개선, 구글 탭 추가, 폴리라인 표출 최적화)
* 2023.03.09 - 구글 좌표 주변 검색 기능 추가 및 웹지도 열기 코드 개선
* 2023.03.12 - 경로 탐색 개선
* 2023.09.02 - 검색기능 추가, 협력사 인덱스 추가, 도움말 링크 추가(플러그인 메뉴얼)
* 2023.09.10 - 대권역 속성값 수정, API Key 암호화, 중복 코드 수정
* 2023.09.11 - 행정계 SHP 교체 (군위군 대구광역시 편입)
* 2023.09.17 - 메모장 패널 추가
* 2023.09.18 - 좌표도구 메뉴바 수정
* 2023.09.19 - 메모장 패널 수정(위치 이동, 탭제목 수정기능 추가)
* 2023.09.20 - 웹지도(로드뷰) 방향 설정 추가
* 2023.09.25 - 검색 및 이동 패널 분리, 좌표 복사 시 마우스 위치 정보 표시 기능 추가
* 2023.10.12 - 보간점 표시, 링크 각도 표시 기능 추가 
* 2023.10.12 - 선택한 객체 레이어 복사 기능 추가 
* 2023.10.22 - 링크 각도 표시 기능의 멀티파트 오류 수정
* 2023.11.22 - 속성필터 기능 추가
* 2023.11.26 - 속성 필터 통계값 표시 기능 추가
* 2023.12.01 - 속성 필터 위젯을 도킹 패널 형태로 개선
* 2023.12.10 - 속성 필터에서 통계 패널을 분리 및 필터 속성값 조정
* 2024.01.02 - 인증키 수정
* 2024.01.28 - 좌표변화기, 도형계산기 프로그래스바 추가
* 2024.02.28 - Ruoto 경로 탐색 오류 수정 (경유지 탐색 기능 개선 예정) - 개선 완료 2025.01.16
* 2024.03.06 - 구글스트릿뷰 수정, 속성필터 수정
* 2024.03.29 - 주변POI 카테고리 검색 추가
* 2024.04.14 - 현재위치 검색 추가
* 2024.05.23 - Vworld API key 수정
* 2024.06.03 - 필드계산기 함수 수정
* 2024.06.05 - 카카오, 루토 검색 코드 수정
* 2024.06.18 - 인덱스SHP 가상레이어 가져오기로 수정
* 2024.06.18 - 인덱스SHP 스타일 수정
* 2024.07.11 - MDB To SHP 플러그인 추가
* 2024.10.09 - 보간점 표시 심볼 수정
* 2024.10.12 - 설정 값이 레지스트리에 저장되도록 개선, API 인증키 수정
* 2024.10.15 - 좌표변환기 코드 수정
* 2024.10.16 - 도형계산기 코드 수정
* 2024.10.30 - 선택 레이어 병합 추가
* 2024.11.02 - 선택 레이어 파일 경로 열기 기능 추가 및 SHP 파일 다운로드 방식 개선
* 2024.12.07 - 좌표복사, 메모장, 좌표변환기, 도형계산기 일부 코드 수정
* 2024.12.11 - MDB To SHP UI 변경 및 코드 수정
* 2024.12.15 - 각도 표시 코드 수정 및 라벨 설정 추가
* 2024.12.17 - MacOS 설치 오류 수정 및 Coconut 좌표 이동 기능 최적화
* 2024.12.30 - 선택 객체 복사 시 동일 스타일 유지 기능 추가
* 2025.01.16 - 루토 경유지 경탐 수정
* 2025.01.20 - xyz 타일맵 불러오기 추가 경로:[ 설정 -> 플러그인 설정 -> 타일맵 추가 클릭 ]
             - QGIS 설정 초기화 추가
* 2025.02.14 - 선택 객체 복사 시 객체만 복사 또는 레이어 스타일까지 복사 여부 선택 가능
* 2025.02.17 - 툴박스 알고리즘 추가
             - Qfield Log레이어 생성, 경로의 하위 폴더 리스트 추출
* 2025.02.27 - MDB To SHP 다중 파일 일괄 추출 기능 추가
* 2025.04.12 - 화면 이동 히스토리 저장 추가
* 2025.05.08 - Qfield Log레이어 생성 코드 수정
* 2025.05.11 - 툴박스 알고리즘 추가 - 영상인식 유도선 변경 추출
* 2025.05.13 - 툴박스 알고리즘 추가 - WKT 변환기("wkt_geom"필드 활용)
* 2025.05.15 - 툴박스 알고리즘 추가 - 조사등록shp 병합
* 2025.05.16 - 툴박스 알고리즘 추가 - Qfield 조사링크 추출
* 2025.05.22 - 툴박스 알고리즘 추가 - Qfield 전기차 실사건
* 2025.05.27 - 메모장 백업 기능 추가(현재 탭의 내용 깃허브 메모장에 저장 및 가져오기)
* 2025.06.08 - 툴박스 알고리즘 추가 - SHP 파일 저장 및 ZIP 압축
* 2025.06.13 - 툴박스 알고리즘 추가 - 조사등록shp 병합 코드 수정
* 2025.06.24 - 툴박스 알고리즘 추가 - GPS로그 궤적 보정 추가
* 2025-06-29 - 속성통계 코드 수정(버전3.40 이상에서 오류 수정)
             - 툴박스 알고리즘 추가 - 키로 속성 결합(VLOOKUP)
* 2025-07-02 - 키값 생성 코드 추가(레이어 우클릭 메뉴)
		     - 레이어(전체)복사 기능 추가(레이어 우클릭 메뉴)
		     - 툴박스 알고리즘 수정 - SHP 파일 저장 및 ZIP 압축 코드 수정 (BES, GRS 단계 분리)
* 2025-07-06 - 범주 별 통계 기능 추가
             - 검색 패널 코드 수정
             - 도형계산기, 좌표변환기 처리 속도 개선
* 2025-07-10 - 네이버 거리뷰 차단으로 수정함
             - GPS로그 궤적 보정 코드 수정 및 오류 수정
* 2025-07-28 - 객체선택 히스토리 저장 추가
             - 네이버 거리뷰 위치 이격 수정
* 2025-08-01 - 시도, 시군구 행정계 SHP 수정
             - Vworld API key 수정
             - 메모장 백업 기능 제외
* 2025-08-08 - 루토 API key 수정
             - 우클릭 메뉴 신규 추가 (설정 > 플러그인 설정 > 우클릭 메뉴)
* 2025-08-14 - 좌표변환기 코드 수정
* 2025-08-22 - 도형계산기 코드 수정
* 2025-08-28 - SpeedFs, coconut 바로가기 추가
             - MDB To SHP 좌표값 X, Y 오류 수정
* 2025-09-25 - NAVER MAPS API 유료화로 관련된 코드 수정
* 2025-10-14 - 툴박스 알고리즘 수정 - 유도선 변경 추출:  예외항목-미구축대상 추가
* 2025-11-28 - 툴박스 알고리즘 수정 - 폴더 내 SHP파일 수집: 자동 증가 필드 추가
             - 도형계산기 코드수정
             - 루토 경탐 코드 수정
* 2025-12-11 - MDB To SHP 코드 수정
* 2025-12-24 - 등급분류(경계선 찾기) 기능 추가
* 2026-01-12 - 일부 코드 수정
* 2026-03-13 - 인덱스 권역, 협력사 수정
* 2026-03-25 - 26년 권역을 기본인덱스로 설정하고 25년 인덱스도 볼러올수있도록 추가(3~4개월내 삭제 예정)
* 2026-03-30 - 키값 생성 코드 수정 _ 피알이 postgreSQL서버에 있어도 필드 생성 되도록 수정
* 2026-04-03 - 피벗 테이블 기능 추가 - "GroupStats" 플러그인 이식
* 2026-04-04 - 네이버 거리뷰 수정
* 2026-04-09 - 피벗 테이블 코드 수정
* 2026-04-12 - 작업 관리자 추가(작업자 관리 및 분배 완료 취합관리)
* 2026-05-06 - 툴박스 알고리즘 추가 - 영상인식 표지판 추출
* 2026-05-19 - cython 컴파일 변환
             - 네이버 거리뷰, 주소보기 코드 수정
* 2026-05-20 - 플러그인 인증 기능 강화
             - 검색, 주변POI검색 코드 수정
* 2026-06-01 - MDB To SHP 필드 속성 필터 기능 추가(선택한 값만 SHP변환)
* 2026-06-08 - 플러그인 인증 기능 강화
* 2026-06-21 - 영상인식 추출 코드 에러 수정
* 2026-07-14 - 플러그인 인증 코드 수정, 검색 코드 수정
* 2026-07-23 - 각도표시 코드 수정, 링크 회전정보 표시 추가
* 2026-08-10 - 지도비교웹 연동 기능 추가
* 2026-08-12 - MMS좌표계 설정 추가, 플러그인 인증코드 수정

***************************************************************************
'''

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsApplication,
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling,
                       QgsSymbol,
                       QgsSimpleFillSymbolLayer,
                       QgsRendererCategory,
                       QgsCategorizedSymbolRenderer,
                       QgsMapLayer,
                       QgsMarkerSymbol,
                       QgsCoordinateTransform,
                       QgsTextAnnotation,
                       QgsFeatureRequest,
                       QgsExpressionContextUtils,
                       QgsExpressionContext,
                       Qgis,
                       QgsFields,QgsPointXY,
                       QgsRectangle,
                       QgsMapLayerType,
                       QgsExpression,
                       QgsField,
                       QgsGeometry)

from qgis.PyQt.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF,
                          QVariant,
                          QCoreApplication)

from qgis.gui import (QgsDockWidget,
                      QgsRubberBand,
                      QgsVertexMarker,
                      QgsMapCanvasItem,
                      QgsMapCanvasAnnotationItem)

from qgis.PyQt.QtGui import (QColor,
                            QCursor,
                            QIcon,
                            QFont,
                            QPen,
                            QTextDocument)

from qgis.PyQt.QtWidgets import (QMenu,
                                QApplication,
                                QDialogButtonBox,
                                QInputDialog,
                                QAction,QActionGroup,QFrame,
                                QToolButton,
                                QMessageBox,
                                QCheckBox,
                                QFileDialog)

from qgis.utils import unloadPlugin, loadPlugin, startPlugin
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit

from . import Coordinate_Tool_data
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Move import CoordinateToolMove
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Function import Coordinate_function
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converter import CoordinateToolConverter
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_Memo import CoordinateToolMemo
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
from .Coordinate_Tool_Simple_filter import simple_filterDialog
from .Coordinate_Tool_Statistics import StatisticsDialog
from .Coordinate_Tool_fieldStatistics import fieldStatisticsDialog
from .Coordinate_Tool_Jenks import JenksDialog
from .Coordinate_Tool_GroupStats import CoordinateToolGroupStats
from .Coordinate_Tool_TaskManager import CoordinateToolTaskManager

from .Coordinate_Tool_mdbToShp import CoordinateToolmdbToShp
from .Coordinate_Tool_Algorithm import Coordinate_Tool_Algorithm
from .Coordinate_Tool_Keyfield import CoordinateToolKeyfield
from .link import MapCompareCoordinateLink, SETTINGS_KEY as MAPCOMPARE_SETTINGS_KEY

# 지도비교 동기화 모드 (QSettings에 문자열로 저장)
MC_OFF  = "off"     # 끄기
MC_BOTH = "both"    # 양방향
MC_PUSH = "push"    # QGIS -> 서버
MC_PULL = "pull"    # 서버 -> QGIS

# 좌표복사 시 지도웹 이동 on/off (모드와 독립된 별도 설정)
MAPCOMPARE_COPYMOVE_KEY = "coordinate_tool/mapcompare_copymove"

import os, sys, os.path, uuid, requests, webbrowser, random, datetime, time, math, subprocess, zipfile, processing, shutil, platform, socket
import hashlib, base64  # [추가됨] MAC 주소 해시 처리 모듈
from datetime import date  # [추가됨] 오늘 날짜 확인 모듈

full_version = Qgis.QGIS_VERSION
QGIS_VERSION = f"QGIS {full_version.split('-')[0]}"  # '3.40.6'
python_path = f"C:/Program Files/{QGIS_VERSION}/bin/python.exe"
try:
    import pyperclip
except:
    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'pyperclip'])
    else:
        subprocess.check_call(['python','-m', 'pip', 'install', 'pyperclip'])
    import pyperclip

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')


class CenterCrossItem(QgsMapCanvasItem):
    """QGIS 캔버스(뷰포트) 정중앙에 항상 고정되는 작은 십자가.
    드래그(팬)/줌 도중에도 화면 중앙을 유지한다.

    구현: 아이템은 씬 원점에 두고, paint 시점에 '뷰포트 픽셀 중앙'을 씬 좌표로
    얻은 뒤(mapToScene) 아이템 로컬 좌표로 역변환(mapFromScene)해서 그린다.
    맵 좌표가 아니라 화면 픽셀 기준이라 팬 중에도 중앙을 유지한다."""

    def __init__(self, canvas, size=10, color="#ff0000", width=1):
        super().__init__(canvas)
        self._canvas = canvas
        self._size = size          # 십자가 팔 길이(픽셀)
        self._color = QColor(color)
        self._width = width
        self.setZValue(1000)       # 다른 아이템 위에
        try:
            self.setPos(0, 0)
        except Exception:
            pass

    def set_style(self, size=None, color=None, width=None):
        if size is not None:
            self._size = size
        if color is not None:
            self._color = QColor(color)
        if width is not None:
            self._width = width
        self.update()

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:
            pass
        self.update()

    def _center_local(self):
        """뷰포트 픽셀 중앙을 아이템 로컬 좌표로 환산."""
        from qgis.PyQt.QtCore import QPoint
        vp = self._canvas.viewport()
        px = QPoint(vp.width() // 2, vp.height() // 2)
        scene_pt = self._canvas.mapToScene(px)
        return self.mapFromScene(scene_pt)

    def boundingRect(self):
        from qgis.PyQt.QtCore import QRectF
        vp = self._canvas.viewport()
        w, h = vp.width(), vp.height()
        return QRectF(-2 * w, -2 * h, 4 * w, 4 * h)

    def paint(self, painter, *args):
        try:
            c = self._center_local()
        except Exception:
            return
        cx, cy = c.x(), c.y()
        s = self._size
        gap = 2   # 중심점을 가리지 않도록 가운데를 살짝 비움
        pen = QPen(self._color)
        pen.setWidth(self._width)
        pen.setCosmetic(True)
        painter.setPen(pen)
        painter.drawLine(QPointF(cx - s, cy), QPointF(cx - gap, cy))
        painter.drawLine(QPointF(cx + gap, cy), QPointF(cx + s, cy))
        painter.drawLine(QPointF(cx, cy - s), QPointF(cx, cy - gap))
        painter.drawLine(QPointF(cx, cy + gap), QPointF(cx, cy + s))


class CoordinateTool:
    def __init__(self, iface):
        self.iface      = iface

        # 변수값 저장 설정
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        # # ---------------------------------------------------------
        # # 플러그인 로드 시 라이선스 인증 검사
        # # ---------------------------------------------------------
        # self.is_licensed = bool(self.check_license())
        # # self.is_licensed = True
        # print('인증확인: ',self.is_licensed)

        self.canvas     = iface.mapCanvas()
        self.crossRb    = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard  = QApplication.clipboard()

    # 좌표도구 메뉴바 설정
        self.menu = QMenu( "좌표도구(&T)", self.iface.mainWindow().menuBar() )
        self.menu.setObjectName("'Coordinate_Tool_menu")

    # 좌표도구 툴바 설정
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')
        self.toolbar.setToolTip('좌표도구 툴바')

        # 영역 툴바 설정 인증 pc만 사용가능
        self.zoom_toolbar = self.iface.addToolBar('영역이동 툴바')
        self.zoom_toolbar.setObjectName('Coordinate_Tool_zoom_toolbar')
        self.zoom_toolbar.setToolTip('영역이동 툴바')
        # 우클릭 메뉴 인증 pc만 사용가능
        self.setup_context_menu()

        self.copytoMMSmapTool   = None
        self.copytoSpeedFsTool  = None
        self.copytoCoconutTool  = None  
        self.MediaCenterTool    = None
        self.ShowOnMapTool      = None
        self.mapaddressTool     = None
        self.searchDialog       = None
        self.simplefilterDialog = None
        self.Converter          = None
        self.Geometry           = None
        self.GroupStats         = None
        self.TaskManager        = None
        
        self.Markers            = []
        self.MarkerSymbol       = []
        self.AngleSymbol        = []
        self.TurnSymbol         = []          # 회전정보 색상 마커

        self.vertex_run_chk     = False
        self.angle_run_chk      = False
        self.turn_run_chk       = False       # 회전정보 표시 on/off
        self.turn_node_cache    = None        # {격자좌표키: [노드정보,...]} 캐시(현재 미사용, 킵)
        self.turn_node_layer    = None        # 즉시조회용 노드 레이어 참조(1회 오픈)
        self.turn_node_path     = None        # 로드된 노드파일 경로
        self.turn_last_fid      = None        # 시/종점 토글: 직전 선택 링크 id
        self.turn_use_end       = False       # False=시점 기준, True=종점 기준
        self.chk = True
        self.Delete_Marker_timer = QTimer()


        # 플러그인 로컬 경로
        self.plugin_dir = os.path.dirname(__file__)
        # 플러그인 설정
        self.Plugin='coordinate_tool'

        # 함수
        self.Function = Coordinate_function(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 이동
        self.indexMove = CoordinateToolMove(self, self.iface, self.iface.mainWindow())
        # mdb쉐입생성
        self.mdbToShp = CoordinateToolmdbToShp(self.iface, self.iface.mainWindow())
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        # 키필드 생성
        self.addKey = CoordinateToolKeyfield(self, self.iface, self.iface.mainWindow())

        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()

        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        # 메모장 위젯 설정
        self.dlgmemo = CoordinateToolMemo(self,self.iface)
        self.dlgmemowidget = QgsDockWidget("메모장" , self.iface.mainWindow() )
        self.dlgmemowidget.setObjectName("메모장")
        self.dlgmemowidget.setWidget(self.dlgmemo)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgmemowidget )
        self.dlgmemowidget.hide()

        # 필터 위젯 설정
        self.simplefilter = simple_filterDialog(self,self.iface)
        self.simplefilterwidget = QgsDockWidget("속성필터" , self.iface.mainWindow() )
        self.simplefilterwidget.setObjectName("속성필터")
        self.simplefilterwidget.setWidget(self.simplefilter)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.simplefilterwidget )
        self.simplefilterwidget.hide()

        # 통계 위젯 설정
        self.Statistics = StatisticsDialog(self,self.iface)
        self.Statisticswidget = QgsDockWidget("속성통계" , self.iface.mainWindow() )
        self.Statisticswidget.setObjectName("속성통계")
        self.Statisticswidget.setWidget(self.Statistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Statisticswidget )
        self.Statisticswidget.hide()

        # 범주 별 통계 위젯 설정
        self.fieldStatistics = fieldStatisticsDialog(self,self.iface)
        self.fieldStatistics_Widget = QgsDockWidget("범주 별 통계" , self.iface.mainWindow() )
        self.fieldStatistics_Widget.setObjectName("범주 별 통계")
        self.fieldStatistics_Widget.setWidget(self.fieldStatistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.fieldStatistics_Widget )
        self.fieldStatistics_Widget.hide()

        # 범주 별 통계 위젯 설정
        self.Jenks = JenksDialog(self,self.iface)
        self.Jenks_Widget = QgsDockWidget("등급 분류" , self.iface.mainWindow() )
        self.Jenks_Widget.setObjectName("등급 분류")
        self.Jenks_Widget.setWidget(self.Jenks)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Jenks_Widget )
        self.Jenks_Widget.hide()

        self.provider = Coordinate_Tool_Algorithm()

        # 영역 히스토리 리스트
        self.history = None
        self.history = []
        self._block = False  # 자동 루프 방지

        # ✅ 초기 상태 저장
        initial_extent = self.canvas.extent()
        initial_crs = self.canvas.mapSettings().destinationCrs()
        self.history.append((initial_extent, initial_crs))
        self.current_index = -1

        self.canvas.extentsChanged.connect(self.on_extent_changed)

        # 지도비교서버 양방향 동기화 브릿지
        self.mapCompareLink = MapCompareCoordinateLink(self.iface)

        # 시작 시 동기화는 항상 OFF 로 초기화 (이전 세션 모드를 이어받지 않음)
        self.mapCompareMode = MC_OFF
        try:
            QSettings().setValue(MAPCOMPARE_SETTINGS_KEY, MC_OFF)
        except Exception:
            pass

        # 화면 중앙 십자가 (동기화 ON일 때만 표시)
        self.centerCross = CenterCrossItem(self.canvas)
        self.centerCross.hide()
        # 팬(드래그) 도중에도 중앙 유지: 마우스 이동 시그널로 실시간 갱신
        try:
            self.canvas.xyCoordinates.connect(self._refresh_center_cross)
        except Exception:
            pass
        # 저장된 동기화 상태에 맞춰 십자가 초기 표시
        try:
            self._update_center_cross_visible()
        except Exception:
            pass

        self.select_history = None
        self.select_history = []    # (layer, fids) 튜플을 담을 리스트
        self.select_index = -1      # 현재 히스토리 인덱스
        self._block1 = False        # re_select 수행 시 select_toggle 진입 방지 플래그
        # self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.select_toggle)

    # # ---------------------------------------------------------
    # # [추가됨] 하드웨어 ID 추출 및 서버 인증 검증 함수
    # # ---------------------------------------------------------
    # def get_hardware_info(self, *args):
    #     # 1. MAC 주소
    #     # mac_num = uuid.getnode()
    #     # mac_hex = "{:012X}".format(mac_num)
    #     # mac_address = "-".join([mac_hex[i:i+2] for i in range(0, 12, 2)])
    #     mac_address = "Unknown"
    #     out = subprocess.check_output(
    #         'wmic nic where "PhysicalAdapter=true and NetConnectionStatus=2" get MACAddress,PNPDeviceID /format:csv'
    #     ).decode(errors='ignore')

    #     for line in out.strip().splitlines():
    #         parts = line.split(',')
    #         # 열 순서(알파벳): Node, MACAddress, PNPDeviceID
    #         if len(parts) >= 3 and parts[2].strip().upper().startswith('PCI'):
    #             mac_address = parts[1].strip().replace(':', '-')

    #     return mac_address

    # # ---------------------------------------------------------
    # # [추가됨] MAC 주소 해시 생성 (CSV 평문 노출 방지)
    # #   - 대소문자 / 구분자(:, -) / 공백 차이를 정규화하여 항상 동일 해시 생성
    # #   - CSV 등록 시에도 반드시 이 함수로 만든 값을 사용할 것
    # #   - base64 결과는 대소문자를 구분하므로 대조 시 .upper() 사용 금지
    # # ---------------------------------------------------------
    # def _hash_mac(self, mac):
    #     SALT = "Masco!1"
    #     norm = mac.strip().upper().replace(':', '-')
    #     raw = hashlib.sha256((SALT + norm).encode()).digest()
    #     return base64.urlsafe_b64encode(raw).decode().rstrip('=')[:16]

    # def check_license(self, *args):
    #     mac = self.get_hardware_info()
    #     # [추가됨] 평문 MAC 대신 해시값으로 대조 (CSV 평문 노출 방지)
    #     my_hash = self._hash_mac(mac)
        
    #     # 2. 깃허브 Raw 주소 입력 (반드시 복사한 본인의 주소로 변경하세요)
    #     raw_url = "https://scshin8.github.io/Qgis/auth_list.csv"

    #     try:
    #         # 깃허브에서 명단 다운로드 (단방향)
    #         response = requests.get(raw_url, timeout=5, verify=False)
            
    #         if response.status_code == 200:
    #             csv_data = response.text

    #             # CSV 한 줄씩 읽어서 대조
    #             for line in csv_data.split('\n'):
    #                 # 빈 줄이거나 첫 번째 헤더 줄이면 건너뜀
    #                 if not line.strip() or line.startswith('팀명'): 
    #                     continue
                        
    #                 parts = line.split(',')
    #                 if len(parts) >= 7:
    #                     status = parts[2].strip().upper()
    #                     # [수정됨] CSV 5번째 컬럼에는 평문 MAC이 아니라 해시값이 저장됨
    #                     #          base64 해시는 대소문자를 구분하므로 .upper() 사용 금지
    #                     registered_hash = parts[4].strip()
                        
    #                     # 명단에 내 MAC 해시가 있고 'APPROVED'인지 확인 후 즉시 반환
    #                     if registered_hash == my_hash and status == "APPROVED":
    #                         return True
                        
    #             # 순회를 마쳤는데도 반환되지 않았다면 미승인 상태
    #             msg_box = QMessageBox(self.iface.mainWindow())
    #             msg_box.setIcon(QMessageBox.Warning)
    #             msg_box.setWindowTitle("좌표도구 사용 승인 필요")
    #             # [수정됨] 평문 MAC 대신 해시값(인증코드)을 전달하도록 안내
    #             msg_box.setText(f"등록되지 않은 PC이거나 승인 대기 중입니다.\n관리자에게 아래의 인증코드를 전달하여 승인을 요청하세요.\n\n[내 PC 정보]\n인증코드: {my_hash}")
    #             msg_box.setWindowFlags(msg_box.windowFlags() | Qt.WindowStaysOnTopHint)
    #             msg_box.exec_()

    #             return False
            
    #         else:
    #             QMessageBox.critical(self.iface.mainWindow(), "좌표도구 인증 실패", "인증 결과를 읽어올 수 없습니다.\n관리자에게 문의하세요")
    #             return False
                
    #     except Exception as e:
    #         QMessageBox.critical(self.iface.mainWindow(), "통신 오류", f"명단 확인 중 네트워크 오류가 발생했습니다:\n{e}")
    #         return False


        # # 1. [추가됨] 오늘 날짜 문자열 생성 (예: "2026-05-16")
        # today_str = date.today().isoformat()

        # # 2. [추가됨] 레지스트리에서 오늘 날짜 인증 기록이 있는지 선행 검사
        # try:

        #     last_auth_date = self.QSettings.value('LastAuthDate', '')

            
        #     # 레지스트리에 기록된 날짜가 오늘 날짜와 완벽히 일치하면 서버 통신 없이 즉시 통과!
        #     if last_auth_date == today_str:
        #         return True
        # except FileNotFoundError:
        #     # 레지스트리 키나 값이 아직 없는 경우(최초 실행 등)에는 에러 없이 통과하여 서버 체크 진행
        #     pass
        # except Exception:
        #     # 기타 보안 제한 등의 예외 발생 시에도 안전하게 서버 체크로 넘어가도록 처리
        #     pass

        # # 3. 오늘 자 인증 기록이 없다면, 기존 방식대로 구글 서버 인증 진행
        # mac, board_id, qgis_ver, pc_name = self.get_hardware_info()
        # api_url = "https://script.google.com/macros/s/AKfycbyfTaSqXArQuPkSiUoPqNzd6bRRtGnxnYDBstmJH9doC6i33NqP8ziT43KcuqqaAeid/exec"
        
        # try:
        #     payload = {
        #         'mac': mac,
        #         'board': board_id,
        #         'qgis': qgis_ver,
        #         'pc_name': pc_name,
        #         'action': 'check' 
        #     }
        #     # [추가됨] 파이썬의 신분을 최신 윈도우 크롬 브라우저로 위장하는 신분증(Header)
        #     custom_headers = {
        #         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        #     }
            
        #     # [수정된 부분] 똑똑한 재시도 로직 + SSL 무시 + 신분증(headers) 제시
        #     try:
        #         # 1차 시도 (headers=custom_headers 옵션 추가)
        #         response = requests.get(api_url, params=payload, headers=custom_headers, timeout=5, verify=False)
        #     except requests.exceptions.Timeout:
        #         # 2차 시도 (headers=custom_headers 옵션 추가)
        #         response = requests.get(api_url, params=payload, headers=custom_headers, timeout=15, verify=False)

        #     if response.status_code == 200:
        #         # [수정됨] JSON 해독 중 에러가 나면 날것 그대로의 응답 텍스트를 창에 띄움
        #         try:
        #             data = response.json()
        #             status = data.get("status")
        #         except Exception as e:
        #             # JSON이 아닐 경우, 서버가 보낸 텍스트 앞부분 500자만 잘라서 화면에 표시
        #             error_text = response.text[:500]
        #             QMessageBox.critical(
        #                 self.iface.mainWindow(), 
        #                 "데이터 해독 오류", 
        #                 f"서버가 JSON이 아닌 웹페이지를 반환했습니다.\n\n[수신된 텍스트 내용]\n{error_text}\n\n이 내용을 캡처해서 확인해주세요."
        #             )
        #             return False
                
        #         if status == "Approved":
        #             # 4. [추가됨] 구글 승인이 확인되면, 오늘 자 인증 날짜를 레지스트리에 기록하여 저장
        #             try:
        #                 self.QSettings.setValue('LastAuthDate', today_str)
        #             except:
        #                 # 관리자 권한 등으로 레지스트리 쓰기가 일시 실패해도 플러그인은 실행되도록 예외 처리
        #                 pass
                        
        #             return True  
                    
        #         elif status == "Pending":
        #             QMessageBox.information(
        #                 self.iface.mainWindow(), 
        #                 "좌표도구 승인 대기 중", 
        #                 "관리자에게 사용 요청이 전달되었습니다.\n승인이 완료될 때까지 잠시 기다려주세요."
        #             )
        #             return False
                    
        #         elif status == "Not Registered":
        #             reply = QMessageBox.question(
        #                 self.iface.mainWindow(),
        #                 "좌표도구 미등록 PC",
        #                 "등록되지 않은 PC입니다.\n관리자에게 사용 승인 요청을 보내시겠습니까?",
        #                 QMessageBox.Yes | QMessageBox.No,
        #                 QMessageBox.No
        #             )

        #             if reply == QMessageBox.No:
        #                 return False 

        #             dialog = QDialog(self.iface.mainWindow())
        #             dialog.setWindowTitle("좌표도구 사용자 인증 요청")
        #             dialog.resize(300, 150)
                    
        #             layout = QVBoxLayout()
        #             info_label = QLabel("승인받을 본인의 정보를 입력해주세요.")
        #             layout.addWidget(info_label)
                    
        #             name_layout = QHBoxLayout()
        #             name_label = QLabel("이름:")
        #             name_input = QLineEdit()
        #             name_input.setPlaceholderText("예: 홍길동")
        #             name_layout.addWidget(name_label)
        #             name_layout.addWidget(name_input)
        #             layout.addLayout(name_layout)
                    
        #             team_layout = QHBoxLayout()
        #             team_label = QLabel("팀명:")
        #             team_input = QLineEdit()
        #             team_input.setPlaceholderText("예: 인포2팀")
        #             team_layout.addWidget(team_label)
        #             team_layout.addWidget(team_input)
        #             layout.addLayout(team_layout)

        #             button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        #             button_box.accepted.connect(dialog.accept)
        #             button_box.rejected.connect(dialog.reject)
        #             layout.addWidget(button_box)
                    
        #             dialog.setLayout(layout)
                    
        #             if dialog.exec_() == QDialog.Accepted:
        #                 user_name = name_input.text().strip()
        #                 team_name = team_input.text().strip()
                        
        #                 if not user_name or not team_name:
        #                     QMessageBox.warning(self.iface.mainWindow(), "입력 오류", "이름과 팀명을 모두 입력해야 요청할 수 있습니다.")
        #                     return False
                            
        #                 register_payload = {
        #                     'mac': mac,
        #                     'board': board_id,
        #                     'qgis': qgis_ver,
        #                     'name': user_name,
        #                     'team': team_name,
        #                     'pc_name': pc_name,
        #                     'action': 'register'
        #                 }

        #                 reg_response = requests.get(api_url, params=register_payload, headers=custom_headers, timeout=5, verify=False)

        #                 if reg_response.status_code == 200:
        #                     QMessageBox.information(
        #                         self.iface.mainWindow(), 
        #                         "요청 완료", 
        #                         "관리자에게 사용 승인 요청을 보냈습니다.\n승인 후 플러그인을 다시 실행해주세요."
        #                     )
        #             return False
                    
        #         else:
        #             QMessageBox.critical(self.iface.mainWindow(), "접근 차단", "사용이 차단된 PC입니다.")
        #             return False
        #     else:
        #         QMessageBox.warning(self.iface.mainWindow(), "서버 오류", "인증 서버와 통신할 수 없습니다.")
        #         return False
                
        # except Exception as e:
        #     QMessageBox.critical(self.iface.mainWindow(), "통신 오류 상세 확인", f"서버 통신 실패 원인:\n\n{type(e).__name__}\n{e}\n\n이 화면을 캡처해서 확인해주세요.")
        #     return False

    def setup_context_menu(self, *args):
        try:
            self.canvas.contextMenuAboutToShow.connect(self.show_context_menu, type=Qt.UniqueConnection)
        except Exception as e:
            print('show_context_menu Error: ' + e)
            pass
        
    def show_context_menu(self, menu, point, *args):
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, (QgsVectorLayer, QgsRasterLayer)):
            return

        menuchk = False
        # QgsMapTool에 정의된 메서드 사용
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(point.x(), point.y())
        menu.setToolTipsVisible(True)
        menu.addSeparator()

        if self.dlg.checkBox_Capture.checkState() == 2:
            point_capture = QMenu("좌표복사", menu)
            icon = QIcon(self.plugin_dir + '/icons/capture.png')
            point_capture.menuAction().setIcon(icon)
            menu.addMenu(point_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture = QAction("Bessel (FS)", self.iface.mainWindow())
            # bes_capture.setStatusTip("EPSG:4162 (Bessel)")
            bes_capture. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'Bessel_Fs'))
            point_capture.addAction(bes_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture_MMS = QAction("Bessel (MMS)", self.iface.mainWindow())
            bes_capture_MMS. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'Bessel_MMS'))
            point_capture.addAction(bes_capture_MMS)

            point_capture.addSeparator()

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture = QAction("GRS (FS)", self.iface.mainWindow())
            grs_capture. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'GRS_Fs'))
            point_capture.addAction(grs_capture)

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture_MMS = QAction("GRS (MMS)", self.iface.mainWindow())
            grs_capture_MMS. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'GRS_MMS'))
            point_capture.addAction(grs_capture_MMS)
            menuchk = True

        if self.dlg.checkBox_RoadView.checkState() == 2:
            # ShowOnMap = QMenu("로드뷰", menu)
            # icon = QIcon(self.plugin_dir + '/icons/roadview.png')
            # ShowOnMap.menuAction().setIcon(icon)
            # menu.addMenu(ShowOnMap)

            icon = QIcon(self.plugin_dir + '/icons/naver.png')
            naver_map = QAction(icon, "NAVER_거리뷰", self.iface.mainWindow())
            naver_map. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'NAVER'))
            # ShowOnMap.addAction(naver_map)
            menu.addAction(naver_map)

            icon = QIcon(self.plugin_dir + '/icons/kakao.png')
            kakao_map = QAction(icon, "KAKAO_로드뷰", self.iface.mainWindow())
            kakao_map. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'KAKAO'))
            # ShowOnMap.addAction(kakao_map)
            menu.addAction(kakao_map)
            menu.addSeparator()
            menuchk = True
        if self.dlg.checkBox_address.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
            address_action = QAction(icon, "주소 보기", self.iface.mainWindow())
            address_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'address'))
            menu.addAction(address_action)
            menuchk = True
        if self.dlg.checkBox_SpeedFS.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/fs.png')
            fs_action = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
            fs_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'SpeedFS'))
            menu.addAction(fs_action)
            menuchk = True

        # if self.dlg.checkBox_coconut.checkState() == 2:
            # icon = QIcon(self.plugin_dir + '/icons/coconut.png')
            # coco_action = QAction(icon, "coconut_이동", self.iface.mainWindow())
            # coco_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'coconut'))
            # menu.addAction(coco_action)
            # menuchk = True

        if self.dlg.checkBox_Zoom.checkState() == 2:
            menu.addSeparator()
            icon = QIcon(self.plugin_dir + '/icons/move1.png')
            map_action1 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project3','USER:100000')).description()})", self.iface.mainWindow())
            map_action1. triggered. connect(lambda *args: self.mapMove(1,self.movemap1))
            menu.addAction(map_action1)

            icon = QIcon(self.plugin_dir + '/icons/move2.png')
            map_action2 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project4','USER:100001')).description()})", self.iface.mainWindow())
            map_action2. triggered. connect(lambda *args: self.mapMove(2,self.movemap2))
            menu.addAction(map_action2)

            icon = QIcon(self.plugin_dir + '/icons/move3.png')
            map_action3 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project5','USER:100001')).description()})", self.iface.mainWindow())
            map_action3. triggered. connect(lambda *args: self.mapMove(3,self.movemap3))
            menu.addAction(map_action3)
            menuchk = True

        if menuchk:
            TARGETS = {"좌표 복사"}
            # 1) 기본 메뉴 중 "좌표 복사" 액션 제거
            for act in list(menu.actions()):
                sub = act.menu()                      # 서브메뉴면 QMenu, 아니면 None
                title = (sub.title() if sub else act.text() or "").replace("&", "")
                if title in TARGETS:
                    menu.removeAction(act)

    def chk_timer(self, *args):
        self.chk = True

    def rClick_capture(self, map_pt, crs, msg, *args):
        if self.copytoMMSmapTool is None:
            self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
        if self.ShowOnMapTool is None:
            self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
        clipboard_point = None
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        # 좌표값 분리
        Lon = format(map_pt[0])
        Lat = format(map_pt[1])
        # 좌표 변환
        transform   = QgsCoordinateTransform(canvasCRS, crs, QgsProject.instance())
        trans_point = transform.transform(float(Lon), float(Lat))
        point_fs    = self.Function.fscoordinate(trans_point)

        if msg == 'Bessel_Fs' or msg == 'GRS_Fs':
            # 좌표 클립보드 저장
            self.clipboard.setText(point_fs)
            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs
            self.Draw_Marker(map_pt, 1)

        elif msg == 'Bessel_MMS' or msg == 'GRS_MMS':
            fsLon = round(float(trans_point[0]*360000),3)
            fsLat = round(float(trans_point[1]*360000),3)
            fsmms = '('+str(fsLon)+','+str(fsLat)+')'

            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + fsmms
            msg = f"{msg} copied to the clipboard"
            clipboard_point = fsmms
            self.Draw_Marker(map_pt, 1)

        elif msg == 'SpeedFS':
            msg = None
            if self.chk:
                fsLon = float(trans_point[0]*360000)
                fsLat = float(trans_point[1]*360000)
                fsmms = '('+str(fsLon)+','+str(fsLat)+')'
                pyperclip.copy(fsmms)
                msg = self.copytoMMSmapTool.SpeedFS(fsmms)

                self.chk = False
                self.timer = QTimer()
                # self.timer.setSingleShot(True)
                self.timer.start(1500)
                self.timer.timeout.connect(self.chk_timer)
                self.Draw_Marker(map_pt, 1)
                
            if msg is None:
                self.chk = True
                self.timer.setSingleShot(False)
                return

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'coconut':
            point_fs = None
            msg, point_fs = self.copytoMMSmapTool.coconut(canvasCRS, map_pt)

            if msg is None:
                return
            
            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'address':

            ctp, sig, roadaddress, jibunaddress = self.Function.Routojoso(trans_point)

            QMessageBox.information(self.iface.mainWindow(), 'Routo' , f'# 도로명주소\n{roadaddress}\n\n# 지번주소\n{jibunaddress}')

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + roadaddress
            msg = f"{msg} copied to the clipboard"
            clipboard_point = roadaddress
            self.Draw_Marker(map_pt, 1)

        elif msg == 'NAVER':
            na = Coordinate_Tool_data.MAP_PROVIDERS[0][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[0][1]
            mapZoom = 18

            lon, lat, id = self.ShowOnMapTool.naver_panoid(map_pt, canvasCRS)

            ms = ms.replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat)).replace('{id}', str(id)) # ms.replace('{id}'
            ms = ms.replace('{zoom}', str(mapZoom))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'KAKAO':
            na = Coordinate_Tool_data.MAP_PROVIDERS[6][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[6][1]
            lon, lat, id = self.ShowOnMapTool.kakaoURL(map_pt,canvasCRS)
            ms = ms.replace('{id}', str(id)).replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        self.clipboard.setText(clipboard_point)
        # 기존 메세지창 삭제
        self.iface.messageBar().clearWidgets()
        # 좌표복사 메세지 표출
        self.iface.messageBar().pushMessage(f"{msg}", level=Qgis.Info, duration=5)
        msg = None
        self.Delete_Marker_Shot(3000)

    def _mapcompare_copymove_enabled(self, *args):
        v = QSettings().value(MAPCOMPARE_COPYMOVE_KEY, False)
        if isinstance(v, str):
            return v.strip().lower() in {"1", "true", "yes", "on"}
        return bool(v)

    def toggle_mapcompare_copymove(self, checked, *args):
        QSettings().setValue(MAPCOMPARE_COPYMOVE_KEY, bool(checked))
        self.iface.messageBar().pushInfo(
            "", "좌표복사 시 지도웹 이동: %s" % ("ON" if checked else "OFF"))

    def mapcompare_goto(self, point, source_crs, *args):
        """좌표복사(클릭) 지점을 지도웹으로 이동시킨다.
        동기화 4개 모드(끄기/양방향/QGIS→지도웹/지도웹→QGIS)와 완전히 독립이며,
        오직 '좌표복사 시 이동' 토글이 켜져 있을 때만 동작한다.
        지도웹(서버)이 꺼져 있으면 전송이 실패하지만 부작용은 없다.
        """
        try:
            if not self._mapcompare_copymove_enabled():
                return
            link = getattr(self, 'mapCompareLink', None)
            if link is None or point is None:
                return
            link.submit_force(point, source_crs)
        except Exception:
            pass

    def set_mapcompare_mode(self, mode, *args):
        """지도비교 동기화 모드 설정: 끄기/양방향/QGIS→서버/QGIS←서버."""
        if mode not in (MC_OFF, MC_BOTH, MC_PUSH, MC_PULL):
            mode = MC_OFF
        self.mapCompareMode = mode
        # link.py 가 읽는 QSettings 키에 모드 문자열 저장(송신/수신을 각각 판단)
        QSettings().setValue(MAPCOMPARE_SETTINGS_KEY, mode)

        # 중앙 십자가: 끄기가 아니면 표시
        try:
            self._update_center_cross_visible()
        except Exception:
            pass

        # 라디오 체크 상태 동기화
        try:
            self._sync_mapcompare_menu_checks()
        except Exception:
            pass

        # 송신 계열(양방향/QGIS→서버)일 때, 켜는 즉시 현재 중심을 한 번 보내 맞춤
        if mode in (MC_BOTH, MC_PUSH):
            try:
                if getattr(self, 'mapCompareLink', None) is not None:
                    center = self.canvas.extent().center()
                    crs = self.canvas.mapSettings().destinationCrs()
                    self.mapCompareLink.submit(center, crs)
            except Exception:
                pass

        labels = {MC_OFF: "끄기", MC_BOTH: "양방향",
                  MC_PUSH: "QGIS→서버", MC_PULL: "QGIS←서버"}
        self.iface.messageBar().pushInfo("", "지도웹 연동: %s" % labels[mode])

    def _sync_mapcompare_menu_checks(self, *args):
        mapping = getattr(self, '_mc_actions', None)
        if not mapping:
            return
        for m, act in mapping.items():
            try:
                act.blockSignals(True)
                act.setChecked(m == self.mapCompareMode)
                act.blockSignals(False)
            except Exception:
                pass

        # 상위 메뉴 제목에 현재 모드를 표시 (서브메뉴를 열지 않아도 확인 가능)
        labels = {MC_OFF: "끄기", MC_BOTH: "양방향",
                  MC_PUSH: "QGIS→서버", MC_PULL: "QGIS←서버"}
        cur = getattr(self, 'mapCompareMode', MC_OFF)
        title = "지도웹 연동 [%s]" % labels.get(cur, "끄기")
        try:
            if getattr(self, 'mapCompareMenuAction', None) is not None:
                self.mapCompareMenuAction.setText(title)
                # 상위 아이콘도 현재 모드 아이콘으로 (끄기면 기본 compare 아이콘 유지)
                icons = getattr(self, '_mc_icons', None)
                if icons is not None:
                    ic = icons.get(cur)
                    if ic is not None and not ic.isNull():
                        self.mapCompareMenuAction.setIcon(ic)
                        try:
                            self.mapCompareMenu.setIcon(ic)
                        except Exception:
                            pass
            if getattr(self, 'mapCompareMenu', None) is not None:
                self.mapCompareMenu.setTitle(title)
        except Exception:
            pass

    def _mapcompare_enabled(self, *args):
        # 끄기가 아니면 활성(십자가 표시용)
        return getattr(self, 'mapCompareMode', MC_OFF) != MC_OFF

    def _update_center_cross_visible(self, *args):
        cc = getattr(self, 'centerCross', None)
        if cc is None:
            return
        if self._mapcompare_enabled():
            cc.updatePosition()
            cc.show()
        else:
            cc.hide()

    def _refresh_center_cross(self, *args):
        # 팬/마우스 이동 중 십자가를 화면 중앙에 다시 그린다(표시 중일 때만)
        try:
            cc = getattr(self, 'centerCross', None)
            if cc is not None and cc.isVisible():
                cc.update()
        except Exception:
            pass

    def on_extent_changed(self, *args):
        # 화면 중앙 십자가 위치 갱신(표시 중일 때만)
        try:
            cc = getattr(self, 'centerCross', None)
            if cc is not None and cc.isVisible():
                cc.updatePosition()
        except Exception:
            pass

        # 지도비교서버 동기화 (송신 계열 모드에서 화면 중심 전송)
        # link.py 내부에서도 송신 허용 여부를 재확인하므로 이중 안전
        try:
            if getattr(self, 'mapCompareMode', MC_OFF) in (MC_BOTH, MC_PUSH) \
                    and getattr(self, 'mapCompareLink', None) is not None:
                center = self.canvas.extent().center()
                crs = self.canvas.mapSettings().destinationCrs()
                self.mapCompareLink.submit(center, crs)
        except Exception:
            pass

        if self._block:
            return
        else:
            extent = self.canvas.extent()
            crs = self.canvas.mapSettings().destinationCrs()
            # 현재 인덱스 이후 히스토리는 삭제 (redo 불가능 상태)
            self.history = self.history[:self.current_index+1]
            self.history.append((extent, crs))
            self.current_index = len(self.history)-1
            self.update_buttons()

    # 영역 뒤로가기
    def go_back(self, *args):
        if self.current_index > 0:
            self._block = True
            self.current_index -= 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()
    # 영역 앞으로가기
    def go_forward(self, *args):
        if self.current_index < len(self.history) - 1:
            self._block = True
            self.current_index += 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()

    def restore_extent(self, extent_crs_tuple, *args):
        extent, saved_crs = extent_crs_tuple
        current_crs = self.canvas.mapSettings().destinationCrs()
        if saved_crs != current_crs:
            # 좌표계 변환
            transform = QgsCoordinateTransform(
                saved_crs,
                current_crs,
                QgsProject.instance().transformContext()
            )
            extent = transform.transformBoundingBox(extent)

        self.canvas.setExtent(extent)
        self.canvas.refresh()

    def update_buttons(self, *args):
        if hasattr(self, 'action_back'):
            self.action_back.setEnabled(self.current_index > 0)
        if hasattr(self, 'action_forward'):
            self.action_forward.setEnabled(self.current_index < len(self.history) - 1)

    def select_toggle(self, layer, *args):
        if self._block1:
            return
        
        if not layer or layer.selectedFeatureCount() == 0:
            self.select_index = len(self.select_history)
            return
        
        layer_id = layer.id()
        fids = layer.selectedFeatureIds()
        self.select_history = self.select_history[:self.select_index + 1]
        self.select_history.append((layer_id, fids))
        self.select_index = len(self.select_history)-1
        self.update_buttons1()
        
    def clean_select_history(self, *args):
        """삭제된 레이어 기록을 제거하고 select_index 를 정상화."""
        project = QgsProject.instance()
        # 유효한(아직 로드된) 레코드만 남기기
        new_hist = [
            (lid, fids)
            for (lid, fids) in self.select_history
            if project.mapLayer(lid)
        ]
        self.select_history = new_hist

        if not new_hist:
            self.select_index = -1
        else:
            # 인덱스가 히스토리 길이를 초과하지 않도록
            self.select_index = min(self.select_index, len(new_hist) - 1)

        self.update_buttons1()

    def re_select(self, select_tuple, *args):
        layer_id, fids = select_tuple
        project = QgsProject.instance()

        layer = project.mapLayer(layer_id)
        if not layer:
            # 레이어가 이미 삭제된 경우
            self.clean_select_history()
            return

        # 2) 원래 레이어의 모든 선택 해제
        layer.removeSelection()
        # 3) 기록된 ID로 재선택
        layer.selectByIds(fids)
        # 간단히: 선택된 피처로 바로 줌(레이어 CRS→캔버스 CRS 자동 처리)
        self.canvas.zoomToSelected(layer)
        self.canvas.refresh()

    def go_select_back(self, *args):
        if self.select_index > 0:
            active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
            if not active_layer:
                return
            target_layer_id = active_layer.id()

            # 현재 인덱스 이전 기록 중, 같은 레이어 ID를 가진 가장 가까운 과거 인덱스 찾기
            found_index = -1
            for i in range(self.select_index - 1, -1, -1):
                if self.select_history[i][0] == target_layer_id:
                    found_index = i
                    break

            if found_index != -1:
                self._block1 = True
                self.select_index = found_index
                self.re_select(self.select_history[self.select_index])
                self._block1 = False
                self.update_buttons1()

    def go_select_forward(self, *args):
        if self.select_index < len(self.select_history) - 1:
            active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
            if not active_layer:
                return
            target_layer_id = active_layer.id()

            # 현재 인덱스 이후 기록 중, 같은 레이어 ID를 가진 가장 가까운 미래 인덱스 찾기
            found_index = -1
            for i in range(self.select_index + 1, len(self.select_history)):
                if self.select_history[i][0] == target_layer_id:
                    found_index = i
                    break

            if found_index != -1:
                self._block1 = True
                self.select_index = found_index
                self.re_select(self.select_history[self.select_index])
                self._block1 = False
                self.update_buttons1()

    def update_buttons1(self, *args):
        # 활성 레이어를 기준으로 이전/이후 기록이 있는지 판단
        active_layer = getattr(self, 'iface', None) and self.iface.activeLayer()
        if not active_layer:
            if hasattr(self, 'select_back'):
                self.select_back.setEnabled(False)
            if hasattr(self, 'select_forward'):
                self.select_forward.setEnabled(False)
            return

        target_layer_id = active_layer.id()

        # 현재 인덱스 앞뒤로 동일한 레이어의 히스토리가 존재하는지 검사
        has_back = any(h[0] == target_layer_id for h in self.select_history[:self.select_index])
        has_forward = any(h[0] == target_layer_id for h in self.select_history[self.select_index + 1:])

        if hasattr(self, 'select_back'):
            self.select_back.setEnabled(has_back)
        if hasattr(self, 'select_forward'):
            self.select_forward.setEnabled(has_forward)

    def unload(self, *args):
        unloadPlugin(self.Plugin)

    def current_map_point(self, *args):
        # 1) 화면(글로벌) 좌표 → 2) 캔버스 좌표 → 3) 지도 좌표
        global_pt = QCursor.pos()
        canvas_pt = self.canvas.mapFromGlobal(global_pt)          # QPoint
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(
            canvas_pt.x(), canvas_pt.y()
        )
        return map_pt  # QgsPointXY

    def initGui(self):

        # # ---------------------------------------------------------
        # # [추가됨] 인증 실패 시 플러그인 UI를 전혀 생성하지 않고 완전 차단
        # #   - 기본 기능(좌표복사 등)도 로드되지 않도록 입구에서 차단
        # # ---------------------------------------------------------
        # if not self.is_licensed:
        #     return

        # 필드계산기 함수 추가
        from .Coordinate_Tool_FieldCalculator import InitLatLonFunctions
        InitLatLonFunctions()
        # 툴박스 알고리즘 추가
        QgsApplication.processingRegistry().addProvider(self.provider)


        # 툴바 드롭다운 목록 생성
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("복사")

# ===========================================================================================================================

        # 메뉴 목록 생성
        Menu = QMenu()
        Menu.setObjectName('copymenu')

        # 좌표 복사
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 

        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)


        # 미디어센터 좌표 이동
        icon = QIcon(self.plugin_dir + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 

        # 주소확인
        icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소보기", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소보기')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.copy.addAction(self.mapaddress)
        Menu.addAction(self.mapaddress)

        icon = QIcon(self.plugin_dir + '/icons/fs.png')
        self.fs = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
        self.fs.setObjectName('SpeedFs_이동')
        self.fs.triggered.connect(lambda *args: self.rClick_capture(self.current_map_point(), epsg4162, 'SpeedFS'))
        # self.fs.setCheckable(True)
        # self.copy.addAction(self.fs)
        Menu.addAction(self.fs)
        self.iface.registerMainWindowAction(self.fs,'H')

        # icon = QIcon(self.plugin_dir + '/icons/coconut.png')
        # self.coconut = QAction(icon, "coconut_이동", self.iface.mainWindow())
        # self.coconut.setObjectName('coconut_이동')
        # self.coconut.triggered.connect(lambda *args: self.rClick_capture(self.current_map_point(), epsg4162, 'coconut'))
        # # self.fs.setCheckable(True)
        # # self.copy.addAction(self.coconut)
        # Menu.addAction(self.coconut)
        # self.iface.registerMainWindowAction(self.coconut,'Y')

    # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.copy)
        # 메뉴에 드롭다운 목록 추가
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.copycopy = QAction(icon, '좌표,주소,미디어센터', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)
        self.menu.addAction(self.copycopy)

#===============================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('movemenu')

        # 웹검색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/search.png')
        self.search = QAction(icon, "검색", self.iface.mainWindow())
        self.search.setObjectName('검색')
        self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.movemap.addAction(self.search)
        self.movemap.setDefaultAction(self.search)
        Menu.addAction(self.search)
        # self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)

    # 좌표이동 1
        icon = QIcon(self.plugin_dir + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(lambda *args: self.mapMove(1,self.movemap1))
        self.movemap.addAction(self.movemap1)
        # self.movemap.setDefaultAction(self.movemap1)
        Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        # self.movemap1.setEnabled(False)

    # 좌표이동 2
        icon = QIcon(self.plugin_dir + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(lambda *args: self.mapMove(2,self.movemap2))
        self.movemap.addAction(self.movemap2)
        Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        # self.movemap2.setEnabled(False)

    # 좌표이동 3
        icon = QIcon(self.plugin_dir + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(lambda *args: self.mapMove(3,self.movemap3))
        self.movemap.addAction(self.movemap3)
        Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        # self.movemap3.setEnabled(False)

    # 도엽, 주소, 경위도 이동
        icon = QIcon(self.plugin_dir + '/icons/indexMove.png')
        self.moveIndex = QAction(icon, "도엽이동", self.iface.mainWindow())
        self.moveIndex.setObjectName('도엽이동')
        # self.coordinateConverter.setCheckable(True)
        self.moveIndex.triggered.connect(self.Move)
        self.movemap.addAction(self.moveIndex)
        Menu.addAction(self.moveIndex)
        self.iface.registerMainWindowAction(self.moveIndex,'Alt+F')

    # 경로탐색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        self.path_search.triggered.connect(lambda *args: self.DefaultAction(self.movemap, self.path_search))
        self.path_search.setCheckable(True)
        self.movemap.addAction(self.path_search)
        Menu.addAction(self.path_search)
        # self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)

        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(self.plugin_dir + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)

        self.menu.addAction(self.movemove)

#===========================================================================================================================
    # 웹지도 열기
        icon = QIcon(self.plugin_dir + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        # self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        # self.ShowOnmap.setEnabled(False)
        self.menu.addAction(self.ShowOnmap)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.attribute = QToolButton(self.toolbar)
        self.attribute.setPopupMode(QToolButton.MenuButtonPopup)
        self.attribute.setObjectName("속성통계필터")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('속성통계필터')

    # 피벗테이블
        icon = QIcon(self.plugin_dir + '/icons/GroupStats.png')
        self.pivot_table = QAction(icon, "피벗테이블", self.iface.mainWindow())
        self.pivot_table.setObjectName('피벗테이블')
        self.pivot_table.triggered.connect(self.pivot_table_run)
        self.attribute.setDefaultAction(self.pivot_table)
        Menu.addAction(self.pivot_table)

    # 피벗테이블
        icon = QIcon(self.plugin_dir + '/icons/tesk.png')
        self.Assigner = QAction(icon, "작업관리자", self.iface.mainWindow())
        self.Assigner.setObjectName('작업관리자')
        self.Assigner.triggered.connect(self.TaskManager_run)
        self.attribute.addAction(self.Assigner)
        Menu.addAction(self.Assigner)

    # 유일값통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics1.png')
        self.fieldUniqueStatistics = QAction(icon, "범주별통계", self.iface.mainWindow())
        self.fieldUniqueStatistics.setObjectName('범주별통계')
        self.fieldUniqueStatistics.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.fieldUniqueStatistics))
        self.fieldUniqueStatistics.setCheckable(True)
        self.attribute.addAction(self.fieldUniqueStatistics)
        # self.attribute.setDefaultAction(self.fieldUniqueStatistics)
        self.fieldStatistics_Widget.setToggleVisibilityAction(self.fieldUniqueStatistics)
        Menu.addAction(self.fieldUniqueStatistics)

    # Jenks(자연구간) 경계값 찾기 등급분류
        icon = QIcon(self.plugin_dir + '/icons/Jenks.png')
        self.Jenksfind = QAction(icon, "등급분류", self.iface.mainWindow())
        self.Jenksfind.setObjectName('등급분류')
        self.Jenksfind.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.Jenksfind))
        self.Jenksfind.setCheckable(True)
        self.attribute.addAction(self.Jenksfind)
        self.Jenks_Widget.setToggleVisibilityAction(self.Jenksfind)
        Menu.addAction(self.Jenksfind)

    # 속성필터 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/filter.png')
        self.simple_filter = QAction(icon, "속성필터", self.iface.mainWindow())
        self.simple_filter.setObjectName('속성필터')
        self.simple_filter.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.simple_filter))
        self.simple_filter.setCheckable(True)
        self.attribute.addAction(self.simple_filter)
        self.simplefilterwidget.setToggleVisibilityAction(self.simple_filter)
        Menu.addAction(self.simple_filter)

    # 속성통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.selectStatistics = QAction(icon, "속성통계", self.iface.mainWindow())
        self.selectStatistics.setObjectName('속성통계')
        self.selectStatistics.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.selectStatistics))
        self.selectStatistics.setCheckable(True)
        self.attribute.addAction(self.selectStatistics)
        self.Statisticswidget.setToggleVisibilityAction(self.selectStatistics)
        Menu.addAction(self.selectStatistics)

        self.toolbar.addWidget( self.attribute)

        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.attr = QAction(icon, '속성통계필터', self.iface.mainWindow())
        self.attr.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.attr)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
    # 좌표변환 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        # self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        Menu.addAction(self.coordinateConverter)
        # self.coordinateConverter.setEnabled(False)

    # 도형계산 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        # self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        Menu.addAction(self.coordinateGeometry)
        # self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.geo)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.indexshp = QToolButton(self.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('쉐입파일')

    # 베셀인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(lambda *args: self.shpIndex(1, self.besindex, "Bessel_Index", "Bessel_Index.shp",  "MAP_ID", "협력사", 0.3 ))
        self.indexshp.addAction(self.besindex)
        self.indexshp.setDefaultAction(self.besindex)
        Menu.addAction(self.besindex)

    # GRS인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "GRS인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('GRS인덱스')
        self.grsindex.triggered.connect(lambda *args: self.shpIndex(2, self.grsindex, "GRS_Index", "GRS_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex)
        Menu.addAction(self.grsindex)

    # WGS84인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/wgsindex.png')
        self.wgsindex = QAction(icon, "WGS인덱스", self.iface.mainWindow())
        self.wgsindex.setObjectName('WGS인덱스')
        self.wgsindex.triggered.connect(lambda *args: self.shpIndex(3, self.wgsindex, "WGS84_Index", "WGS84_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex)
        Menu.addAction(self.wgsindex)

    # 협력사 구문 인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/partnerindex.png')
        self.parindex = QAction(icon, "협력사인덱스", self.iface.mainWindow())
        self.parindex.setObjectName('협력사인덱스')
        self.parindex.triggered.connect(lambda *args: self.shpIndex(4, self.parindex, "협력사_Index", "Partner_Index.shp","협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex)
        Menu.addAction(self.parindex)

    # 시도행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(lambda *args: self.shpIndex(5, self.ctpshp, "시도행정계", "ctp.shp", "CTP_KOR_NM", "CTP_KOR_NM", 0.6))
        self.indexshp.addAction(self.ctpshp)
        Menu.addAction(self.ctpshp)

    # 시군구행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(lambda *args: self.shpIndex(6, self.sigshp, "시군구행정계", "sig.shp", "SIG_KOR_NM", "CTP_KOR_NM", 0.3))
        self.indexshp.addAction(self.sigshp)
        Menu.addAction(self.sigshp)

    # 읍명동 행정계 쉐입 열기
        # icon = QIcon(self.plugin_dir + '/icons/emd.png')
        # self.emdshp = QAction(icon, "읍면동행정계", self.iface.mainWindow())
        # self.emdshp.setObjectName('읍면동행정계')
        # self.emdshp.triggered.connect(lambda *args: self.shpIndex(7))
        # self.indexshp.addAction(self.emdshp)
        # Menu.addAction(self.emdshp)

    # 파일열기 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.shpfileopen = QAction(icon, "파일열기", self.iface.mainWindow())
        self.shpfileopen.setObjectName('파일열기')
        self.shpfileopen.triggered.connect(self.fileopen)
        # self.shpfileopen.setCheckable(True)
        self.indexshp.addAction(self.shpfileopen)
        # self.indexshp.setDefaultAction(self.shpfileopen)
        Menu.addAction(self.shpfileopen)
        # self.iface.registerMainWindowAction(self.shpfileopen,'Shift+O')

    # 북마크 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self.indexshp.addAction(self.Bookmark)
        Menu.addAction(self.Bookmark)

        self.toolbar.addWidget( self.indexshp)
        
        icon = QIcon(self.plugin_dir + '/icons/shp.png')
        self.shp = QAction(icon, '쉐입파일', self.iface.mainWindow())
        self.shp.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.shp)

        self.menu.addAction(self.shp)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self._addin = QToolButton(self.toolbar)
        self._addin.setPopupMode(QToolButton.MenuButtonPopup)
        self._addin.setObjectName("추가기능")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('추가기능')

    # 메모 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/memo.png')
        self.memo = QAction(icon, "메모장", self.iface.mainWindow())
        self.memo.setObjectName('메모장')
        self.memo.triggered.connect(self.notepad)
        self.memo.setCheckable(True)
        self._addin.addAction(self.memo)
        self._addin.setDefaultAction(self.memo)
        # self.iface.addPluginToMenu("좌표도구", self.memo)
        self.dlgmemowidget.setToggleVisibilityAction(self.memo)
        # self.iface.registerMainWindowAction(self.memo,'F2')
        Menu.addAction(self.memo)

    # mdb to shp
        icon = QIcon(self.plugin_dir + '/icons/mdbToShp.png')
        self._mdbToShp = QAction(icon, "MDB쉐입생성", self.iface.mainWindow())
        self._mdbToShp.setObjectName('MDB쉐입생성')
        self._mdbToShp.triggered.connect(self.show_mdbToShp)
        self._addin.addAction(self._mdbToShp)
        # self.iface.registerMainWindowAction(self.searchAction,'F4')
        Menu.addAction(self._mdbToShp)

        # 1. 메뉴 생성
        self.duplicate_menu = QMenu("선택객체복사", self.iface.mainWindow())
        self.duplicate_menu.setObjectName('선택객체복사메뉴')
        group_icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate_menu.menuAction().setIcon(group_icon)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate1.png')
        self.duplicate = QAction(icon, "선택객체복사(스타일X)", self.iface.mainWindow())
        self.duplicate.setObjectName('선택객체복사')
        self.duplicate.triggered.connect(lambda *args: self.duplicate_run(False))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicate, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicate)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate1 = QAction(icon, "선택객체복사(스타일O)", self.iface.mainWindow())
        self.duplicate1.setObjectName('선택객체복사')
        self.duplicate1.triggered.connect(lambda *args: self.duplicate_run(True))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicate1, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicate1)

        # 3. 하위 액션을 메뉴에 추가
        self.duplicate_menu.addAction(self.duplicate)
        self.duplicate_menu.addAction(self.duplicate1)

        self.duplicate_action = self.duplicate_menu.menuAction()  # QAction 획득
        # 4. 생성한 메뉴를 레이어 우클릭 메뉴에 추가
        self.iface.addCustomActionForLayerType(self.duplicate_action, None, QgsMapLayer.VectorLayer, True)

        # 1. 메뉴 생성
        self.duplicateAll_menu = QMenu("레이어복사", self.iface.mainWindow())
        self.duplicateAll_menu.setObjectName('레이어복사메뉴')
        group_icon = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll_menu.menuAction().setIcon(group_icon)
    # 레이어전체 복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicateALL1.png')
        self.duplicateAll = QAction(icon, "레이어복사(스타일X)", self.iface.mainWindow())
        self.duplicateAll.setObjectName('레이어복사')
        self.duplicateAll.triggered.connect(lambda *args: self.duplicate_run(False, 1))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicateAll, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicateAll)

    # 레이어전체 복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll1 = QAction(icon, "레이어복사(스타일O)", self.iface.mainWindow())
        self.duplicateAll1.setObjectName('레이어복사')
        self.duplicateAll1.triggered.connect(lambda *args: self.duplicate_run(True, 1))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicateAll1, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicateAll1)

        # 3. 하위 액션을 메뉴에 추가
        self.duplicateAll_menu.addAction(self.duplicateAll)
        self.duplicateAll_menu.addAction(self.duplicateAll1)
        
        self.duplicateAll_action = self.duplicateAll_menu.menuAction()  # QAction 획득
        # 4. 생성한 메뉴를 레이어 우클릭 메뉴에 추가
        self.iface.addCustomActionForLayerType(self.duplicateAll_action, None, QgsMapLayer.VectorLayer, True)

    # 키 필드 생성
        icon = QIcon(self.plugin_dir + '/icons/key.png')
        self.keyfield = QAction(icon, "Key 필드 생성", self.iface.mainWindow())
        self.keyfield.setObjectName('Key 필드 생성')
        self.keyfield.triggered.connect(self.addKeyfield)
        # self._addin.addAction(self.layermerge)
        self.iface.addCustomActionForLayerType(self.keyfield, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.keyfield)

    # 선택레이어병합 실행
        icon = QIcon(self.plugin_dir + '/icons/merge.png')
        self.layermerge = QAction(icon, "선택레이어병합", self.iface.mainWindow())
        self.layermerge.setObjectName('선택레이어병합')
        self.layermerge.triggered.connect(self.layermerge_run)
        # self._addin.addAction(self.layermerge)
        self.iface.addCustomActionForLayerType(self.layermerge, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.layermerge)

    # 선택레이어경로 열기
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.folderPath = QAction(icon, "레이어경로열기", self.iface.mainWindow())
        self.folderPath.setObjectName('레이어경로열기')
        self.folderPath.triggered.connect(self.folderOpen)
        # self._addin.addAction(self.folderPath)
        self.iface.addCustomActionForLayerType(self.folderPath, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.folderPath)

    # 선택객체 각도 표기
        icon = QIcon(self.plugin_dir + '/icons/angle.png')
        self.angle = QAction(icon, "각도 표시", self.iface.mainWindow())
        self.angle.setObjectName('각도 표시')
        self.angle.setCheckable(True)
        self.angle.triggered.connect(self.angle_run)
        self.iface.registerMainWindowAction(self.angle,'Shift+A')
        self.menu.addAction(self.angle)

    # 선택객체 회전정보 색상 표시
        icon = QIcon(self.plugin_dir + '/icons/turn.png')
        self.turn = QAction(icon, "회전정보 표시", self.iface.mainWindow())
        self.turn.setObjectName('회전정보 표시')
        self.turn.setCheckable(True)
        self.turn.triggered.connect(self.turn_run)
        self.iface.registerMainWindowAction(self.turn,'Shift+T')
        self.menu.addAction(self.turn)

    # 선택객체 보간점 표시
        icon = QIcon(self.plugin_dir + '/icons/vertex.png')
        self.vertex = QAction(icon, "보간점 표시", self.iface.mainWindow())
        self.vertex.setObjectName('보간점 표시')
        self.vertex.setCheckable(True)
        self.vertex.triggered.connect(self.vertex_run)
        self.iface.registerMainWindowAction(self.vertex,'Shift+B')
        self.menu.addAction(self.vertex)

        self.toolbar.addWidget( self._addin)

        icon = QIcon(self.plugin_dir + '/icons/go_back.png')
        self.action_back = QAction(icon, "뒤로 가기", self.iface.mainWindow())
        self.action_back.setObjectName('뒤로 가기')
        self.action_back.setEnabled(False)
        self.action_back.triggered.connect(self.go_back)
        self.zoom_toolbar.addAction(self.action_back)

        icon = QIcon(self.plugin_dir + '/icons/go_forward.png')
        self.action_forward = QAction(icon, "앞으로 가기", self.iface.mainWindow())
        self.action_forward.setObjectName('앞으로 가기')
        self.action_forward.setEnabled(False)
        self.action_forward.triggered.connect(self.go_forward)
        self.zoom_toolbar.addAction(self.action_forward)

        # 세로바 생성
        vertical_line = QFrame(self.iface.mainWindow())
        vertical_line.setFixedWidth(5)
        vertical_line.setFrameShape(QFrame.VLine)
        vertical_line.setFrameShadow(QFrame.Sunken)
        self.zoom_toolbar.addWidget(vertical_line)

        icon = QIcon(self.plugin_dir + '/icons/select_back.png')
        self.select_back = QAction(icon, "선택 되돌리기", self.iface.mainWindow())
        self.select_back.setObjectName('선택 되돌리기')
        self.select_back.setEnabled(False)
        self.select_back.triggered.connect(self.go_select_back)
        self.zoom_toolbar.addAction(self.select_back)

        icon = QIcon(self.plugin_dir + '/icons/select_forward.png')
        self.select_forward = QAction(icon, "선택 다시하기", self.iface.mainWindow())
        self.select_forward.setObjectName('선택 다시하기')
        self.select_forward.setEnabled(False)
        self.select_forward.triggered.connect(self.go_select_forward)
        self.zoom_toolbar.addAction(self.select_forward)

        icon = QIcon(self.plugin_dir + '/icons/addin.png')
        self.__addin = QAction(icon, '추가기능', self.iface.mainWindow())
        self.__addin.setMenu(Menu)

        self.menu.addAction(self.__addin)

#===========================================================================================================================
    # 좌표도구 설정창
        icon = QIcon(self.plugin_dir + '/icons/setting.png')
    # 지도비교서버 동기화 메뉴 (끄기 / 양방향 / QGIS→서버 / QGIS←서버)
        mapcompare_icon = QIcon(self.plugin_dir + '/icons/compare.png')
        self.mapCompareMenu = QMenu("지도웹 연동", self.iface.mainWindow())
        self.mapCompareMenu.setIcon(mapcompare_icon)
        self.mapCompareMenu.setObjectName('지도웹 연동')

        # 각 모드별 아이콘 (기존 아이콘 재사용)
        # self._mc_icons = {
        #     MC_OFF:  QIcon(),  # 끄기: 아이콘 없음
        #     MC_BOTH: QIcon(self.plugin_dir + '/icons/compare.png'),
        #     MC_PUSH: QIcon(self.plugin_dir + '/icons/go_forward.png'),
        #     MC_PULL: QIcon(self.plugin_dir + '/icons/go_back.png'),
        # }

        self._mc_group = QActionGroup(self.iface.mainWindow())
        self._mc_group.setExclusive(True)
        self._mc_actions = {}
        for _mode, _label in ((MC_OFF, "끄기"), (MC_BOTH, "양방향"),
                              (MC_PUSH, "QGIS → 지도웹"), (MC_PULL, "지도웹 → QGIS")):
            _act = QAction(_label, self.iface.mainWindow()) # self._mc_icons.get(_mode, QIcon())
            _act.setCheckable(True)
            _act.setChecked(_mode == self.mapCompareMode)  # 시작 시 끄기
            _act.triggered.connect(lambda checked, m=_mode: self.set_mapcompare_mode(m))
            self._mc_group.addAction(_act)
            self.mapCompareMenu.addAction(_act)
            self._mc_actions[_mode] = _act

        self.mapCompareMenuAction = QAction(mapcompare_icon, "지도웹 연동", self.iface.mainWindow())
        self.mapCompareMenuAction.setMenu(self.mapCompareMenu)
        self.menu.addAction(self.mapCompareMenuAction)

        # 구분선 + 좌표복사 시 지도웹 이동 토글 (모드와 독립)
        self.mapCompareMenu.addSeparator()
        self.mapCompareCopyMove = QAction("좌표복사 시 이동", self.iface.mainWindow())
        self.mapCompareCopyMove.setCheckable(True)
        # 시작 시 항상 OFF 로 초기화 (이전 세션 상태를 이어받지 않음)
        try:
            QSettings().setValue(MAPCOMPARE_COPYMOVE_KEY, False)
        except Exception:
            pass
        self.mapCompareCopyMove.setChecked(False)
        self.mapCompareCopyMove.toggled.connect(self.toggle_mapcompare_copymove)
        self.mapCompareMenu.addAction(self.mapCompareCopyMove)

        # 상위 메뉴 제목/아이콘을 현재 모드로 초기 갱신
        try:
            self._sync_mapcompare_menu_checks()
        except Exception:
            pass

        self.set = QAction(icon, "좌표도구설정", self.iface.mainWindow())
        self.set.setObjectName('좌표도구설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        # self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')

        self.menu.addAction(self.set)

#===========================================================================================================================
    # Help
        icon = QIcon(self.plugin_dir + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        # self.iface.addPluginToMenu('좌표도구', self.helpAction)

        self.menu.addAction(self.helpAction)

#===========================================================================================================================
    # 상단 메뉴바에 좌표변환 메뉴 추가 
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

#===========================================================================================================================
    # # 플러그인 확인
    #     today = datetime.date.today()
    #     yyyy = today.year
    #     # 인증 MyPlugin
    #     if yyyy > 2024:
    #         QMessageBox.information(self.iface.mainWindow(), '플러그인 재설치' , '좌표도구 플러그인 업데이트(재설치)가 필요합니다.')  
    #         self.unload()
    #     # self.toggle()

# 도움말===================================================================================================================================================================
    def help(self, *args):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"  
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화========================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        try:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        except:
            pass

    # 메뉴삭제
        self.menu.deleteLater()

        # [추가됨] 툴바 삭제 (인증 실패 시 빈 툴바가 남는 것 방지)
        try:
            del self.toolbar
        except:
            pass


        # 보간점, 각도 마크 삭제
        self.vertex.setChecked(False)
        self.vertexdisplay()

        self.angle.setChecked(False)
        self.angledisplay()

        self.turn.setChecked(False)
        self.turndisplay()

        self.remove_Marker()
        self.remove_Angle()
        self.remove_Turn()

        # 레이어 우클릭 목록 삭제
        self.iface.removeCustomActionForLayerType(self.duplicate_action)
        self.iface.removeCustomActionForLayerType(self.duplicateAll_action)
        self.iface.removeCustomActionForLayerType(self.layermerge)
        self.iface.removeCustomActionForLayerType(self.folderPath)
        self.iface.removeCustomActionForLayerType(self.keyfield)
            
    # 화면 정리
        try:
            self.Delete_Marker()
        except:
            pass
        # 경탐 삭제
        try:
            self.dlgPathSearch.delete()
        except:
            pass
        # 검색 삭제
        try:
            self.dlgSearch.RemoveAll()
        except:
            pass

        try:
            self.canvas.selectionChanged.disconnect(self.select_toggle)
        except:
            pass
        try:
            self.canvas.extentsChanged.disconnect(self.on_extent_changed)
        except:
            pass
        try:
            self.mapCompareLink.close()
        except:
            pass
        try:
            # 언로드 시 동기화 상태를 OFF 로 남겨 다음 세션이 켜진 채 시작되지 않게 함
            QSettings().setValue(MAPCOMPARE_SETTINGS_KEY, MC_OFF)
        except:
            pass
        try:
            QSettings().setValue(MAPCOMPARE_COPYMOVE_KEY, False)
        except:
            pass
        try:
            self.canvas.xyCoordinates.disconnect(self._refresh_center_cross)
        except:
            pass
        try:
            if getattr(self, 'centerCross', None) is not None:
                self.canvas.scene().removeItem(self.centerCross)
                self.centerCross = None
        except:
            pass
        try:
            self.canvas.contextMenuAboutToShow.disconnect(self.show_context_menu)
        except:
            pass
        try:
            self.canvas.selectionChanged.disconnect(self.vertexdisplay)
        except:
            pass
        try:
            self.canvas.selectionChanged.disconnect(self.angledisplay)
        except:
            pass

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.set)

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.moveIndex)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.shpfileopen)
        self.iface.removeToolBarIcon(self.besindex)
        self.iface.removeToolBarIcon(self.grsindex)
        self.iface.removeToolBarIcon(self.wgsindex)
        self.iface.removeToolBarIcon(self.parindex)
        self.iface.removeToolBarIcon(self.ctpshp)
        self.iface.removeToolBarIcon(self.sigshp)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.memo)
        self.iface.removeToolBarIcon(self.simple_filter)
        self.iface.removeToolBarIcon(self.selectStatistics)
        self.iface.removeToolBarIcon(self.fieldUniqueStatistics)
        self.iface.removeToolBarIcon(self.Jenksfind)
        self.iface.removeToolBarIcon(self.layermerge)
        self.iface.removeToolBarIcon(self.folderPath)
        self.iface.removeToolBarIcon(self.vertex)
        self.iface.removeToolBarIcon(self.angle)
        self.iface.removeToolBarIcon(self.turn)
        self.iface.removeToolBarIcon(self.duplicate)
        self.iface.removeToolBarIcon(self.duplicate1)
        self.iface.removeToolBarIcon(self.duplicateAll)
        self.iface.removeToolBarIcon(self.duplicateAll1)
        self.iface.removeToolBarIcon(self.action_back)
        self.iface.removeToolBarIcon(self.action_forward)
        self.iface.removeToolBarIcon(self.select_back)
        self.iface.removeToolBarIcon(self.select_forward)
        self.iface.removeToolBarIcon(self.keyfield)

        try:
            del self.toolbar
        except:
            pass

        try:
            del self.zoom_toolbar
        except:
            pass

        self.history = []
        self.current_index = -1
        self.action_back.setEnabled(False)
        self.action_forward.setEnabled(False)
        # 필드계산기 표현식 삭제
        from .Coordinate_Tool_FieldCalculator import UnloadLatLonFunctions
        UnloadLatLonFunctions()

        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None

        self.iface.mainWindow().removeDockWidget(self.dlgmemowidget)
        self.dlgmemowidget = None
        self.dlgmemo = None

        self.iface.mainWindow().removeDockWidget(self.simplefilterwidget)
        self.simplefilterwidget = None
        self.simplefilter = None

        self.iface.mainWindow().removeDockWidget(self.Statisticswidget)
        self.Statisticswidget = None
        self.Statistics = None

        self.iface.mainWindow().removeDockWidget(self.fieldStatistics_Widget)
        self.fieldStatistics_Widget = None
        self.fieldStatistics = None

        self.iface.mainWindow().removeDockWidget(self.Jenks_Widget)
        self.Jenks_Widget = None
        self.Jenks = None

        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.moveIndex)
        self.iface.unregisterMainWindowAction(self.shpfileopen)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.simple_filter)
        self.iface.unregisterMainWindowAction(self.memo)
        self.iface.unregisterMainWindowAction(self.vertex)
        self.iface.unregisterMainWindowAction(self.angle)
        self.iface.unregisterMainWindowAction(self.turn)
        self.iface.unregisterMainWindowAction(self.fs)
        # self.iface.unregisterMainWindowAction(self.coconut)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        mac_dir = os.path.join(os.path.dirname(self.plugin_dir), 'coordinate_tool_mac')

        if os.path.exists(mac_dir):
            shutil.rmtree(mac_dir)

# 좌표 캡쳐 실행==============================================================================================================================================================
    def capture(self, *args):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행=============================================================================================================================================================
    def mediaCenter(self, *args):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 주소 복사 실행================================================================================================================================================================
    def address(self, *args):
        # 마커 표시 삭제
        self.copy.setDefaultAction(self.mapaddress)
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 좌표 이동 실행===============================================================================================================================================================
    def mapMove(self, idx, movemap, *args):
        clipText = self.clipboard.text().strip()
        SeqOrder=int(self.QSettings.value('ComboBox' + str(idx+2), 0))
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project' + str(idx+2),'USER:100000'))
        try:
            lon, lat = self.Function.setval(setCRS,clipText) # 복사된 좌표 X, Y 좌표 변환
            self.movemap.setDefaultAction(movemap)
            self.Function.moveto(setCRS, lon, lat, SeqOrder)
            self.canvas.refresh()
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()
        except:
            pass

# 도엽이동 실행===================================================================================================================================================================
    def Move(self, *args):
        self.movemap.setDefaultAction(self.moveIndex)
        self.Delete()
        self.canvas.refresh()
        self.indexMove.show()
        
# 검색창 실행===================================================================================================================================================================
    def searchtool(self, *args):
        self.movemap.setDefaultAction(self.search)
        self.dlgSearch.lineEdit.setFocus()

# 툴바 기본값 변경 =================================================================================================================================================================
    def DefaultAction(self, toolbar, Action, *args):
        toolbar.setDefaultAction(Action)

# 웹지도 실행==================================================================================================================================================================
    def ShowOn(self, *args):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()


    def pivot_table_run(self, *args):
        self.DefaultAction(self.attribute, self.pivot_table)
        if self.GroupStats is None:
            # Create the dialog and keep reference
            self.GroupStats = CoordinateToolGroupStats()

        mapLayers = QgsProject.instance().mapLayers()        # Load layers dictionary from the project
        layerList = []
        for id in mapLayers.keys():                                   # Loading layer names into the window
            if mapLayers[id].type() == QgsMapLayer.VectorLayer:
                layerList.append((mapLayers[id].name(), id))

        if len(layerList) == 0:
            QMessageBox.information(None,
                                    QCoreApplication.translate('GroupStats', 'Information'),
                                    QCoreApplication.translate('GroupStats', '벡터 레이어를 찾을 수 없습니다'))
            return
        self.GroupStats.iface = self.iface
        self.GroupStats.setLayers(layerList)
        
        # show the dialog
        self.GroupStats.show()


    def TaskManager_run(self, *args):
        self.DefaultAction(self.attribute, self.Assigner)
        if self.TaskManager is None:
            self.TaskManager = CoordinateToolTaskManager()

        mapLayers = QgsProject.instance().mapLayers()        # Load layers dictionary from the project
        layerList = []
        for id in mapLayers.keys():                                   # Loading layer names into the window
            if mapLayers[id].type() == QgsMapLayer.VectorLayer:
                layerList.append((mapLayers[id].name(), id))

        if len(layerList) == 0:
            QMessageBox.information(None,
                                    QCoreApplication.translate('GroupStats', 'Information'),
                                    QCoreApplication.translate('GroupStats', '벡터 레이어를 찾을 수 없습니다'))
            return
        self.TaskManager.iface = self.iface
        self.TaskManager.setLayers(layerList)
        

        self.TaskManager.show()


# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self, *args):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        if self.Converter is None:
            self.Converter = CoordinateToolConverter(self.iface, self.iface.mainWindow())
            self.Converter = CoordinateToolConverter(self.iface, self.iface.mainWindow())
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================
    def Geometrywidget(self, *args):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        if self.Geometry is None:
            self.Geometry = CoordinateToolGeometry(self.iface, self.iface.mainWindow())
        self.Geometry.show() 

# 파일열기 =======================================================================================================================================================================
    def fileopen(self, *args):
        self.indexshp.setDefaultAction(self.shpfileopen)
        self.Delete()
        self.shpBookmark.getOpenFile()

# 쉐입인덱스 불러오기 ============================================================================================================================================================
    def shpIndex(self, idx, Action, cmtName, fileName, leLabefield, symbolfield, lineWidth, *args):
        self.Delete()
        self.indexshp.setDefaultAction(Action)
        layers = QgsProject.instance().mapLayersByName(cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
        # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
            layer.triggerRepaint()   
        else:
        # 인덱스 레이어가 없다면 레이어 추가
            filepath = os.path.join(self.plugin_dir,'shp',fileName)

        # shp 파일이 있다면
            if os.path.isfile(filepath):
            # 서버의 파일과 수정된 시간을 비교하여 파일 업로드 결정
                from datetime import datetime
                from io import BytesIO

            # 로컬파일 시간 가져오기
                modification_time = os.path.getmtime(filepath)
                getctime_time  = datetime.fromtimestamp(int(modification_time))

                file_zip = fileName.split('.')[0] + '.zip'
                raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip

            # 압축 파일 다운로드하지 않고 압축 파일 내부의 시간 정보 확인
                response = requests.get(raw_url, verify=False)
                if response.status_code == 200:
                    with zipfile.ZipFile(BytesIO(response.content)) as shp_zip:
                        try:
                            zipinfo = shp_zip.getinfo(fileName)
                            zipinfo_time = datetime(*zipinfo.date_time)
                            print("압축 파일 내부의 시간:", zipinfo_time)
                        except KeyError:
                            print("해당 파일이 압축 파일 내에 존재하지 않습니다.")
                else:
                    print("파일 다운로드에 실패했습니다. HTTP 상태 코드:", response.status_code)

            # 시간 비교 서버의 파일이 최신이라면 압축해제
                if zipinfo_time > getctime_time:
                    self.indexdownload(fileName)

                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

            else:
                print("파일이 존재하지 않습니다.")
            # shp 파일 다운로드
                self.indexdownload(fileName)
            # 대기
                time.sleep(1)
            # shp 파일 가져오기
                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

    def shpimport(self, idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth, *args):

        existing_layer = QgsVectorLayer(filepath, cmtName, "ogr")
        # QgsProject.instance().addMapLayer(existing_layer)
        # 기존 레이어의 CRS 가져오기
        crs = existing_layer.crs().authid()
        memory_layer = QgsVectorLayer(f"Polygon?crs={crs}", cmtName, "memory")

        # 기존 레이어의 피처를 가상 메모리 레이어로 복사합니다.
        memory_layer_data_provider = memory_layer.dataProvider()
        memory_layer.startEditing()
        memory_layer_data_provider.addAttributes(existing_layer.fields().toList())
        memory_layer.updateFields()

        # 기존 레이어의 피처 한 번에 복사
        features = list(existing_layer.getFeatures())
        memory_layer_data_provider.addFeatures(features)

        # # 기존 레이어의 피처 복사
        # for feature in existing_layer.getFeatures():
        #     memory_layer_data_provider.addFeatures([feature])
        
        memory_layer.commitChanges()
        
        # 레이어를 QGIS 프로젝트에 추가합니다.
        QgsProject.instance().addMapLayer(memory_layer)

        if idx in (1,2,3):
            filepath = str('/shp/' + fileName)
            memory_layer.loadNamedStyle(os.path.join(self.plugin_dir, 'style', "index.qml"))
        else:
            self.setsymbol(memory_layer,leLabefield, symbolfield, lineWidth)
        memory_layer.triggerRepaint()   

    def indexdownload(self, fileName):
        file_zip = fileName.split('.')[0] + '.zip'
    # 저장경로지정
        destination_path = os.path.join(self.plugin_dir, file_zip)
    # 폴더 생성
        extracted_folder = os.path.join(self.plugin_dir,'shp')
        if not os.path.exists(extracted_folder):
            os.makedirs(extracted_folder)
    # 파일 다운로드
        raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip
        response = requests.get(raw_url, verify=False)
        with open(destination_path, 'wb') as file:
            file.write(response.content)
    # 추출할 디렉토리로 압축 해제
        with zipfile.ZipFile(destination_path, 'r') as zip_ref:
            zip_ref.extractall(self.plugin_dir + '/shp')
    # 압축파일 삭제
        if os.path.exists(destination_path):  # 파일이 존재하는지 확인합니다.
            os.remove(destination_path)  # 파일을 삭제합니다.

# 심볼 설정 =================================================================================================================================================================  
    def setsymbol(self,layer,leLabefield, symbolfield, lineWidth, *args): 

        fni = layer.dataProvider().fields().indexFromName(symbolfield)
        unique_values = layer.uniqueValues(fni)

        # fill categories
        categories = []
        for unique_value in unique_values:
            # initialize the default symbol for this geometry type
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())

            # configure a symbol layer
            layer_style = {}
            # layer_style['joinstyle'] = 'bevel'
            layer_style['style'] = 'no'
            layer_style['color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_width'] = lineWidth
            symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)

            # replace default symbol layer with the configured one
            if symbol_layer is not None:
                symbol.changeSymbolLayer(0, symbol_layer)

            # create renderer object
            category = QgsRendererCategory(unique_value, symbol, str(unique_value))
            # entry for the list of category items
            categories.append(category)

        # create renderer object
        renderer = QgsCategorizedSymbolRenderer(symbolfield, categories)

        # assign the created renderer to the layer
        if renderer is not None:
            layer.setRenderer(renderer)

        layer.triggerRepaint()

        #라벨 스타일 설정
        layer_settings  = QgsPalLayerSettings()

        text_format = QgsTextFormat() # 텍스트 포멧 정의
        text_format.setFont(QFont("맑은 고딕")) # 폰트
        text_format.setSize(9) # 크기
        # text_format.setColor(QColor(255, 0, 255, 255)) # 컬러
        
        # 폰트 버퍼 설정
        # buffer_settings = QgsTextBufferSettings()
        # buffer_settings.setEnabled(True) # 버퍼 활성화
        # buffer_settings.setSize(1) # 버퍼 사이즈
        # buffer_settings.setColor(QColor("white")) # 버퍼 컬러
        # text_format.setBuffer(buffer_settings) # 폰트에 버퍼 셋팅
        
        layer_settings.setFormat(text_format) #라벨 스타일에 폰트 셋팅

        layer_settings.fieldName = leLabefield
        # layer_settings.placement = 2
        
        layer_settings.enabled = True
    
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        # 스타일 새로고침
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        # 단일 심볼 스타일 설정
        # 심볼설정
        # soldcol = QColor(0, 0, 0, 0) # 채우기색
        # linecol = QColor(103, 153, 141, 255) # 테두리색 R / G / B / 투명도
        # linecol = QColor(random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256), 255) # 테두리색 R / G / B / 투명도
        # lineWidth = 0.3 # 테두리 너비
        # layer.renderer().symbol().setColor(soldcol) # 채우기색
        # layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 (R , G , B , 투명도) QColor(255, 0, 255, 255)
        # layer.renderer().symbol().symbolLayer(0).setStrokeWidth(lineWidth) # 테두리 너비
        # layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine

# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self, *args):
        self.indexshp.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()

# 메모 패널 실행=====================================================================================================================================================================
    def notepad(self, *args):
        self._addin.setDefaultAction(self.memo)

    def show_mdbToShp(self, *args):
        self._addin.setDefaultAction(self._mdbToShp)
        self.Delete()
        self.mdbToShp.show()

# 설정창 실행===================================================================================================================================================================
    def setting(self, *args):
        self.Delete()
        self.dlg.show()

# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self, t, *args):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시======================================================================================================================================================================
    def Draw_Marker(self,point,idx, *args):
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)

        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self, *args):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()

# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self, *args): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)
        
    def vertexdisplay(self, *args):
        self.time_start = time.perf_counter()
        if self.vertex_run_chk:
            layer = self.iface.activeLayer()
            if not layer or not isinstance(layer, (QgsVectorLayer)):
                return
            featuresCount = layer.selectedFeatureCount()
            # 선택 객체가 1개 이상 또는 20개 이하 일때만 보간점 표시함
            if featuresCount >= 1 and featuresCount <= 20:
                selected_features = layer.selectedFeatures()
                # 기존 마커 삭제e
                self.remove_Marker()
                # 리스트 초기화
                selected_objects =[]
                # 프로젝트와 레이어 좌표계 가져오기
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                layer_crs=layer.crs()
                transform = QgsCoordinateTransform(layer_crs,canvasCRS, QgsProject.instance())

                # 설정값 로드
                size = int(self.QSettings.value('spinBox', 10))
                txt_color = QColor(self.QSettings.value('markerColorButton_5', '#ff0000')).name()
                back_color = QColor(self.QSettings.value('markerColorButton_6', '#ff0000')).name()
                has_bg = int(self.QSettings.value('background_checkBox', 0)) != 0
                bg_style = f"background-color: {back_color};" if has_bg else ""

                marker_size = "0" if layer.isEditable() else "0.6"
                marker_symbol = QgsMarkerSymbol.createSimple({"name": "rectangle", "color": "red", "outline_style": "no", "size": marker_size})

                fontDefault = QFont('맑은 고딕')
                fontDefault.setBold(True)
                
                # 선택한 피처의 꼭지점 좌표 출력
                for feature in selected_features:
                    geometry = feature.geometry()
                    wkbType = geometry.wkbType()
                    if geometry:
                        if geometry.wkbType() in (QgsWkbTypes.Point, QgsWkbTypes.PointZM,
                                                  QgsWkbTypes.MultiPoint, QgsWkbTypes.MultiPointZM):
                            pass
                        else:
                            # 라인스트링, 멀티라인스트링, 다각형, 멀티다각형인 경우 처리
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                vertexs = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                multi_lines = geometry.asMultiPolyline()
                                vertexs = [vertex for lines in multi_lines for vertex in lines]
                            elif wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.PolygonZM:
                                rings = geometry.asPolygon()
                                vertexs = [vertex for ring in rings for vertex in ring[:-1]]
                            elif wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.MultiPolygonZM:
                                multi_Polygons = geometry.asMultiPolygon()
                                vertexs = [vertex for Polygons in multi_Polygons for Polygon in Polygons for vertex in Polygon[:-1]]

                            for i, vertex in enumerate(vertexs):
                                txtProjectPoint = transform.transform(vertex.x(), vertex.y())
                                selected_objects.append([txtProjectPoint, i])

                # QgsTextAnnotation을 담을 리스트를 생성합니다.
                text_annotations = []   

                for Vertex, idx in selected_objects:
                    # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                    html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{idx}</span>'
                    text_document = QTextDocument()
                    text_document.setHtml(html_text)
                    text_document.setDefaultFont(fontDefault)

                    # QgsTextAnnotation 생성 및 설정
                    text_annotation = QgsTextAnnotation(self.canvas)
                    text_annotation.setDocument(text_document)

                    # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                    text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0,0))
                    text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,0))
                    # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                    # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                    text_annotation.setMapPosition(Vertex)
                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                    text_annotation.setMarkerSymbol(marker_symbol)
                    # text_annotation의 크기를 조절
                    text_annotation.setFrameSize(text_document.size())  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                    # QgsTextAnnotation을 리스트에 추가합니다.
                    text_annotations.append(text_annotation)

                # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                self.MarkerSymbol.extend(annotation_items)
                self.canvas.refresh()
            else:
                # 선택한 객체가 없다면
                self.remove_Marker()
                selected_objects = []
                text_annotations = []        
        else:
            self.remove_Marker()    

    def angledisplay(self, *args):
        if self.angle_run_chk:
            self.time_start = time.perf_counter()
            layer = self.iface.activeLayer()
            if not layer or not isinstance(layer, (QgsVectorLayer)):
                return

            featuresCount = layer.selectedFeatureCount()
            if featuresCount > 0:
                # 기존 마커 삭제
                self.remove_Angle()
                selected_features = layer.selectedFeatures()

                if len(selected_features) != 1:
                    self.iface.messageBar().clearWidgets()
                    # self.iface.messageBar().pushMessage(f'진입링크는 하나만 선택해야 합니다', level=Qgis.Info, duration=3)
                else:
                    self.selected_feature = selected_features[0]
                    # 선택한 링크의 양끝점 좌표를 가져옵니다.
                    geometry = self.selected_feature.geometry()
                    if geometry != None:
                        parts = geometry.asGeometryCollection()
                        # if not geometry.isMultipart():
                        if len(parts) != 1:
                            self.iface.messageBar().pushMessage(f'멀티파츠 객체입니다.', level=Qgis.Info, duration=3)
                            return

                        wkbType = geometry.wkbType()
                        if geometry:
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                geometry_points = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                geometry_points = geometry.asMultiPolyline()[0]
                            else:   # wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.Point or wkbType == QgsWkbTypes.MultiPoint:
                                return
                        self.start_point0 = geometry_points[0]
                        self.start_point1 = geometry_points[1]
                        self.end_point0 = geometry_points[-1]
                        self.end_point1 = geometry_points[-2]

                        # 프로젝트와 레이어 좌표계 가져오기
                        map_crs = self.canvas.mapSettings().destinationCrs()  # 화면 좌표계
                        layer_crs = layer.crs()  # 레이어 좌표계
                        transform = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())

                        # 화면 경계를 레이어 좌표계로 변환
                        extent = self.canvas.extent()  # 화면 경계
                        transformed_extent = transform.transformBoundingBox(extent)

                        # [속도개선] 공간필터에 더해 기하만 요청(속성 skip)하여 피처 로딩을 가볍게 함
                        request = QgsFeatureRequest().setFilterRect(transformed_extent)
                        request.setFlags(QgsFeatureRequest.NoGeometry)  # 아래에서 재설정하므로 주의
                        request = QgsFeatureRequest().setFilterRect(transformed_extent)
                        request.setSubsetOfAttributes([])  # 속성 로딩 생략 → 로딩 속도 향상

                        # 화면에 보이는 피처만 가져오기
                        visible_features = layer.getFeatures(request)

                        # ─────────────────────────────────────────────────────────────
                        # [속도개선 핵심] 기존 touches() 전체순회 제거.
                        #  - touches()는 정밀 기하연산으로 화면 내 링크 수가 많으면 병목.
                        #  - 어차피 하단 로직이 '시/종점 좌표 일치'로 인접을 재판별하므로
                        #    여기서 미리 '선택링크의 시점/종점 == 후보링크의 시점/종점' 후보만
                        #    수집하면 결과 동일 + 속도 대폭 향상.
                        # ─────────────────────────────────────────────────────────────
                        sel_endpoints = (self.start_point0, self.end_point0)
                        selected_id = self.selected_feature.id()
                        adjacent_features = []
                        for feature in visible_features:
                            if feature.id() == selected_id:  # 자기 자신 제외
                                continue
                            fg = feature.geometry()
                            if fg is None or fg.isEmpty():
                                continue
                            # 후보 링크의 시/종점만 추출 (touches 없이 꼭짓점 비교)
                            if fg.isMultipart():
                                pl = fg.asMultiPolyline()
                                if not pl:
                                    continue
                                pts = pl[0]
                            else:
                                pts = fg.asPolyline()
                            if len(pts) < 2:
                                continue
                            # 선택링크 시/종점과 후보링크 시/종점이 하나라도 일치하면 인접 후보
                            if pts[0] in sel_endpoints or pts[-1] in sel_endpoints:
                                adjacent_features.append(feature)

                    if len(adjacent_features) == 0:
                        return

                    # 프로젝트와 레이어 좌표계 가져오기 (텍스트 표시 위치 변환용)
                    map_crs = self.canvas.mapSettings().destinationCrs()  # 화면 좌표계
                    layer_crs = layer.crs()  # 레이어 좌표계
                    transform = QgsCoordinateTransform(layer_crs, map_crs, QgsProject.instance())

                    # ─────────────────────────────────────────────────────────────
                    # [각도오류 수정 v2] 레이어 좌표계 종류와 무관하게
                    #  '각도가 정확한 평면좌표계(EPSG:5179)'로 항상 변환 후 각도 계산.
                    #  - 기존 isGeographic() 분기는 웹메르카토르(3857) 같은
                    #    '투영좌표계지만 각도가 왜곡되는 경우'를 놓쳐서 오류가 남음.
                    #  - 이미지2에서 5179 변환 시 정상 확인됨 → 5179를 기준으로 고정.
                    #  ※ 인접 판정 == 비교는 여전히 원본좌표 사용(변환 안 함).
                    # ─────────────────────────────────────────────────────────────
                    angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
                    if layer_crs == angle_crs:
                        angle_transform = None  # 이미 5179면 변환 불필요
                    else:
                        angle_transform = QgsCoordinateTransform(layer_crs, angle_crs, QgsProject.instance())

                    # 설정값 로드
                    size = int(self.QSettings.value('spinBox_2', 10))
                    txt_color = QColor(self.QSettings.value('markerColorButton_7', '#ff0000')).name()
                    back_color = QColor(self.QSettings.value('markerColorButton_8', '#ff0000')).name()
                    has_bg = int(self.QSettings.value('background_checkBox_2', 0)) != 0
                    bg_style = f"background-color: {back_color};" if has_bg else ""

                    marker_symbol = QgsMarkerSymbol.createSimple({"name":"rectangle", "color":"red","outline_color": "0,0,0,255","outline_style": "no", "size":"0"}) #"name":"rectangle", 'size_unit': 'MapUnit', 'outline_style': 'solid',

                    fontDefault = QFont('맑은 고딕')
                    fontDefault.setBold(True)

                    # 인접링크 리스트 생성
                    adjacent_links = []
                    for feature in adjacent_features:
                        if feature.id() == self.selected_feature.id():
                            continue  # 선택한 링크 자체는 제외합니다.
                        adjacent_geometry = feature.geometry()
                        if adjacent_geometry != None:
                            parts = adjacent_geometry.asGeometryCollection()

                            for adjacent_geometry in parts:

                                wkbType = adjacent_geometry.wkbType()
                                # 링크싀
                                if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asPolyline()
                                elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asMultiPolyline()[0]
                                # 꼭지점 좌표 변환
                                adjacent_start_point0 = adjacent_geometry_points[0]
                                adjacent_start_point1 = adjacent_geometry_points[1]
                                adjacent_end_point0 = adjacent_geometry_points[-1]
                                adjacent_end_point1 = adjacent_geometry_points[-2]
                                length = adjacent_geometry.length()

                                # 디스플레이 좌표
                                third_point = adjacent_geometry.interpolate(length * 0.5).asPoint()
                                # 인접 위치 판별( 시점, 종점 )  ※ 원본좌표로 비교(변환 시 부동소수점 오차로 == 실패)
                                # 시점과 시점 인접
                                if self.start_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 시점과 종점 인접
                                elif self.start_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                                # 종점과 시점 인접
                                elif self.end_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 종점과 종점 인접
                                elif self.end_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])

                            # 결과값 리스트
                            angles_result = []
                            # 선택한 링크와 인접한 링크의 각도를 계산합니다.
                            for adjacent_link, start_point0, start_point1, end_point0, end_point1, txtPoint in adjacent_links:

                                # [각도오류 수정] atan2 직전에 평면좌표로 변환(지리좌표계일 때만)
                                if angle_transform:
                                    sp0 = angle_transform.transform(start_point0)
                                    sp1 = angle_transform.transform(start_point1)
                                    ep0 = angle_transform.transform(end_point0)
                                    ep1 = angle_transform.transform(end_point1)
                                else:
                                    sp0, sp1, ep0, ep1 = start_point0, start_point1, end_point0, end_point1

                                angle = math.atan2(sp1.x() - sp0.x(), sp1.y() - sp0.y())
                                selected_feature_angle = math.degrees(angle) if angle > 0 else (math.degrees(angle) + 180) + 180

                                angle = math.atan2(ep1.x() - ep0.x(), ep1.y() - ep0.y())
                                adjacent_feature_angle = math.degrees(angle) if angle > 0 else (math.degrees(angle) + 180) + 180

                                abs_angle = round(abs((selected_feature_angle - adjacent_feature_angle) % 360), 1)
                                angle_value = abs_angle - 360 if abs_angle > 180 else abs_angle

                                angle_value = "%g" % round(abs_angle if abs_angle < 0 else 180 - abs_angle, 1)

                                # 좌표를 프로젝트 좌표로 변환 (텍스트 표시 위치)
                                txtProjectPoint = transform.transform(txtPoint.x(), txtPoint.y())
                                angles_result.append([txtProjectPoint, angle_value])

                            # QgsTextAnnotation을 담을 리스트를 생성합니다.
                            text_annotations = []
                            for point, angle in angles_result:
                                # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                                html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{str(angle)}</span>'
                                text_document = QTextDocument()
                                text_document.setHtml(html_text)
                                text_document.setDefaultFont(fontDefault)

                                # QgsTextAnnotation 생성 및 설정
                                text_annotation = QgsTextAnnotation(self.canvas)
                                text_annotation.setDocument(text_document)

                                # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                                text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0, 0))
                                text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0, 0))
                                # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                                # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                                text_annotation.setMapPosition(point)
                                if layer.isEditable():
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                                else:
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(-(text_document.size().width()), - (text_document.size().height())))

                                text_annotation.setMarkerSymbol(marker_symbol)
                                # text_annotation의 크기를 조절
                                text_annotation.setFrameSize(QSizeF(text_document.size().width()+2, text_document.size().height()))  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                                # QgsTextAnnotation을 리스트에 추가합니다.
                                text_annotations.append(text_annotation)

                    # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                    annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                    self.AngleSymbol.extend(annotation_items)
                    self.canvas.refresh()
            else:
                self.remove_Angle()
                angles_result = []
                text_annotations = []
        else:
            self.remove_Angle()

    def vertex_run(self, *args):
        if self.vertex.isChecked():
            self.canvas.selectionChanged.connect(self.vertexdisplay)
            self.vertex_run_chk = True
            self.vertexdisplay()
        else:
            self.canvas.selectionChanged.disconnect(self.vertexdisplay)
            self.remove_Marker()
            self.vertex_run_chk = False

    def angle_run(self, *args):
        if self.angle.isChecked():
            self.canvas.selectionChanged.connect(self.angledisplay)
            self.angle_run_chk = True
        else:
            self.canvas.selectionChanged.disconnect(self.angledisplay)
            self.remove_Angle()
            self.angle_run_chk = False

    # ═══════════════════════════════════════════════════════════════
    # 회전정보 색상 표시 기능
    #   판별 규칙(진입 i → 진출 j, t_code/d_code 값):
    #     비보호좌회전=노랑 : t=3 & d=0
    #     불가       =빨강  : t=2 & d=0
    #     좌회전     =파랑  : d=1
    #     직진       =초록  : d=3
    #     우회전     =주황  : d=2
    #   좌표키 매칭 허용오차 SNAP_TOL=1.0m (Turn_Code_Validate_Algorithm과 동일)
    # ═══════════════════════════════════════════════════════════════
    TURN_SNAP_TOL = 1.0                    # 노드-끝점 접속 허용오차(m, EPSG:5179)
    TURN_GRID = 1.0                        # 좌표 딕셔너리 격자 크기(m)
    TURN_COLORS = {'left': "#40DCFF", 'straight': "#800040",
                   'right': "#64FF40", 'unprotected': '#FFD740',
                   'blocked': '#FF4040'}

    @staticmethod
    def _turn_code_str(v):
        """t/d_code 원문 → 8자리 보정 (Turn_Code_Validate_Algorithm.code_str 이식)"""
        s = str(v if v is not None else '').strip()
        if s.endswith('.0'):
            s = s[:-2]
        return s.zfill(8) if s.isdigit() else s

    @staticmethod
    def _turn_digit(s, j):
        """오른쪽에서 j번째 자리 (Turn_Code_Validate_Algorithm.digit 이식)"""
        return int(s[len(s) - j]) if len(s) >= j and s[len(s) - j].isdigit() else None

    @staticmethod
    def _turn_norm(v):
        """Link_Id 비교용 정규화 (Turn_Code_Validate_Algorithm.norm 이식)"""
        if v is None:
            return ''
        if isinstance(v, str) and not v.strip().lstrip('-').isdigit():
            return v.strip()
        try:
            return str(int(float(v)))
        except (TypeError, ValueError):
            return str(v).strip()

    def _grid_key(self, x, y):
        """좌표를 격자 키로 (부동소수점 == 실패 방지)"""
        g = self.TURN_GRID
        return (round(x / g), round(y / g))

    # ─────────────────────────────────────────────────────────────
    # [캐싱 방식 - 현재 미사용, 킵]
    #   130만 노드 전체 순회가 느려서 즉시조회 방식으로 전환.
    #   되살리려면 아래 주석 해제 + turn_run/turndisplay의 캐시 분기 복원.
    # ─────────────────────────────────────────────────────────────
    # def load_turn_nodes(self, path):
    #     """노드파일을 열어 교차로 노드(Node_Attr∈{1,9})만 격자좌표 딕셔너리로 캐싱."""
    #     layer = QgsVectorLayer(path, 'turn_nodes', 'ogr')
    #     if not layer.isValid():
    #         self.iface.messageBar().pushMessage('회전정보', '노드파일을 열 수 없습니다.',
    #                                             level=Qgis.Warning, duration=4)
    #         return None
    #     fields = layer.fields()
    #     need = ['Node_Attr', 'Num_Link'] + [f'Link_Id{j}' for j in range(1, 9)] \
    #            + [f't_code{i}' for i in range(8)] + [f'd_code{i}' for i in range(8)]
    #     for fn in need:
    #         if fields.lookupField(fn) == -1:
    #             self.iface.messageBar().pushMessage(
    #                 '회전정보', f"노드파일에 '{fn}' 필드가 없습니다.",
    #                 level=Qgis.Warning, duration=5)
    #             return None
    #     angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
    #     node_crs = layer.crs()
    #     node_tr = (None if node_crs == angle_crs
    #                else QgsCoordinateTransform(node_crs, angle_crs, QgsProject.instance()))
    #     cache = {}
    #     cnt = 0
    #     for nf in layer.getFeatures():
    #         try:
    #             attr = int(float(nf['Node_Attr']))
    #         except (TypeError, ValueError):
    #             continue
    #         if attr not in (1, 9):
    #             continue
    #         if not nf.hasGeometry():
    #             continue
    #         g = nf.geometry()
    #         if node_tr is not None:
    #             g = QgsGeometry(g)
    #             g.transform(node_tr)
    #         pt = g.asPoint()
    #         try:
    #             nlink = int(float(nf['Num_Link']))
    #         except (TypeError, ValueError):
    #             nlink = 0
    #         rec = {'x': pt.x(), 'y': pt.y(), 'n': nlink}
    #         for j in range(1, 9):
    #             rec[f'L{j}'] = self._turn_norm(nf[f'Link_Id{j}'])
    #         for i in range(8):
    #             rec[f't{i}'] = self._turn_code_str(nf[f't_code{i}'])
    #             rec[f'd{i}'] = self._turn_code_str(nf[f'd_code{i}'])
    #         cache.setdefault(self._grid_key(pt.x(), pt.y()), []).append(rec)
    #         cnt += 1
    #     self.iface.messageBar().pushMessage('회전정보', f'교차로 노드 {cnt}건 로드 완료',
    #                                         level=Qgis.Info, duration=3)
    #     return cache
    #
    # def _find_node_at(self, x, y):
    #     """격자 좌표 주변에서 실제 SNAP_TOL 이내 노드 1건 반환 (없으면 None)"""
    #     if not self.turn_node_cache:
    #         return None
    #     gx, gy = self._grid_key(x, y)
    #     best, best_d = None, self.TURN_SNAP_TOL ** 2
    #     for dx in (-1, 0, 1):
    #         for dy in (-1, 0, 1):
    #             for rec in self.turn_node_cache.get((gx + dx, gy + dy), []):
    #                 d = (rec['x'] - x) ** 2 + (rec['y'] - y) ** 2
    #                 if d <= best_d:
    #                     best, best_d = rec, d
    #     return best

    def open_turn_layer(self, path):
        """[즉시조회 방식] 노드파일을 1회 오픈해 레이어 참조 반환(순회 안 함).
           필드 존재만 검증. 실제 노드 조회는 클릭 시 공간필터로 수행."""
        layer = QgsVectorLayer(path, 'turn_nodes', 'ogr')
        if not layer.isValid():
            self.iface.messageBar().pushMessage('회전정보', '노드파일을 열 수 없습니다.',
                                                level=Qgis.Warning, duration=4)
            return None
        fields = layer.fields()
        need = ['Node_Attr', 'Num_Link'] + [f'Link_Id{j}' for j in range(1, 9)] \
               + [f't_code{i}' for i in range(8)] + [f'd_code{i}' for i in range(8)]
        for fn in need:
            if fields.lookupField(fn) == -1:
                self.iface.messageBar().pushMessage(
                    '회전정보', f"노드파일에 '{fn}' 필드가 없습니다.",
                    level=Qgis.Warning, duration=5)
                return None
        return layer

    def _query_node_at(self, x5179, y5179):
        """[즉시조회] 노드 레이어에서 (x,y)(EPSG:5179 기준) 주변 SNAP_TOL 이내
           교차로 노드 1건을 공간필터로 찾아 rec(dict) 반환. 없으면 None.
           130만 전체가 아니라 주변 소수만 읽으므로 클릭당 부하가 작음."""
        layer = self.turn_node_layer
        if layer is None:
            return None
        # 노드 레이어 좌표계로 검색 사각형을 만든다(5179 → 노드CRS 역변환)
        angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
        node_crs = layer.crs()
        to_node = (None if node_crs == angle_crs
                   else QgsCoordinateTransform(angle_crs, node_crs, QgsProject.instance()))
        to_5179 = (None if node_crs == angle_crs
                   else QgsCoordinateTransform(node_crs, angle_crs, QgsProject.instance()))
        # 검색점을 노드CRS로 변환한 뒤, SNAP_TOL(m)만큼 여유를 둔 사각형 조회
        pt_node = (to_node.transform(QgsPointXY(x5179, y5179))
                   if to_node else QgsPointXY(x5179, y5179))
        tol = self.TURN_SNAP_TOL * 2      # 여유(좌표계 왜곡 대비)
        rect = QgsRectangle(pt_node.x() - tol, pt_node.y() - tol,
                            pt_node.x() + tol, pt_node.y() + tol)
        request = QgsFeatureRequest().setFilterRect(rect)
        best, best_d = None, self.TURN_SNAP_TOL ** 2
        for nf in layer.getFeatures(request):
            try:
                attr = int(float(nf['Node_Attr']))
            except (TypeError, ValueError):
                continue
            if attr not in (1, 2, 3, 9):        # 교차로 노드만
                continue
            if not nf.hasGeometry():
                continue
            g = nf.geometry()
            if to_5179 is not None:
                g = QgsGeometry(g)
                g.transform(to_5179)
            p = g.asPoint()
            d = (p.x() - x5179) ** 2 + (p.y() - y5179) ** 2
            if d <= best_d:
                try:
                    nlink = int(float(nf['Num_Link']))
                except (TypeError, ValueError):
                    nlink = 0
                rec = {'n': nlink}
                for j in range(1, 9):
                    rec[f'L{j}'] = self._turn_norm(nf[f'Link_Id{j}'])
                for i in range(8):
                    rec[f't{i}'] = self._turn_code_str(nf[f't_code{i}'])
                    rec[f'd{i}'] = self._turn_code_str(nf[f'd_code{i}'])
                best, best_d = rec, d
        return best

    def _turn_color(self, rec, entry_lid, exit_lid):
        """노드 rec에서 진입 링크(entry_lid) → 진출 링크(exit_lid)의 회전색 반환.
           순번 규칙: t_code{i-1}/d_code{i-1}의 오른쪽 j번째 자리 = Link_Id{j}.
           i=진입 링크 순번, j=진출 링크 순번."""
        n = rec['n']
        # 진입/진출 링크의 순번(i, j) 찾기
        i = j = None
        for k in range(1, min(n, 8) + 1):
            if rec[f'L{k}'] == entry_lid:
                i = k
            if rec[f'L{k}'] == exit_lid:
                j = k
        if i is None or j is None:
            return None
        t = self._turn_digit(rec[f't{i-1}'], j)
        d = self._turn_digit(rec[f'd{i-1}'], j)
        # 판별 순서: d=0 특수(비보호좌회전/불가) → 좌/직/우
        if t == 3 and d == 0:
            return self.TURN_COLORS['unprotected']
        if t == 2 and d == 0:
            return self.TURN_COLORS['blocked']
        if d == 1:
            return self.TURN_COLORS['left']
        if d == 3:
            return self.TURN_COLORS['straight']
        if d == 2:
            return self.TURN_COLORS['right']
        return None

    def turn_run(self, *args):
        if self.turn.isChecked():
            # 노드 경로 확보: 저장된 경로가 없으면 파일 선택
            path = self.QSettings.value('turn_node_path', '')
            if not path or not os.path.exists(path):
                path, _ = QFileDialog.getOpenFileName(
                    self.iface.mainWindow(), '회전정보 노드파일 선택', '',
                    'Vector (*.shp *.gpkg);;All files (*.*)')
                if not path:
                    self.turn.setChecked(False)
                    return
                self.QSettings.setValue('turn_node_path', path)
            # [즉시조회] 레이어를 1회만 오픈(전체 순회 없음). 경로가 바뀌면 재오픈.
            if self.turn_node_layer is None or self.turn_node_path != path:
                layer = self.open_turn_layer(path)
                if layer is None:
                    self.turn.setChecked(False)
                    return
                self.turn_node_layer = layer
                self.turn_node_path = path
            self.canvas.selectionChanged.connect(self.turndisplay)
            self.turn_run_chk = True
            self.turndisplay()
        else:
            self.canvas.selectionChanged.disconnect(self.turndisplay)
            self.remove_Turn()
            self.turn_run_chk = False

    def turndisplay(self, *args):
        if not self.turn_run_chk:
            self.remove_Turn()
            return
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            return
        # 활성 레이어가 라인이 아니면(노드=점 등) 조용히 무시
        if layer.geometryType() != QgsWkbTypes.LineGeometry:
            self.remove_Turn()
            return
        if layer.selectedFeatureCount() != 1:
            self.remove_Turn()
            return

        self.remove_Turn()
        selected_feature = layer.selectedFeatures()[0]
        geometry = selected_feature.geometry()
        if geometry is None or geometry.isEmpty():
            return
        parts = geometry.asGeometryCollection()
        if len(parts) != 1:
            return
        pts = (geometry.asMultiPolyline()[0] if geometry.isMultipart()
               else geometry.asPolyline())
        if len(pts) < 2:
            return
        sel_start = pts[0]
        sel_end = pts[-1]

        # 시/종점 토글: 같은 링크 재클릭 시 기준노드 전환
        fid = selected_feature.id()
        if fid == self.turn_last_fid:
            self.turn_use_end = not self.turn_use_end
        else:
            self.turn_use_end = False
        self.turn_last_fid = fid
        base_point = sel_end if self.turn_use_end else sel_start

        # 좌표계 준비: 링크 원본 → EPSG:5179(노드 캐시와 동일)
        map_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs = layer.crs()
        angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
        to_5179 = (None if layer_crs == angle_crs
                   else QgsCoordinateTransform(layer_crs, angle_crs, QgsProject.instance()))

        # 기준노드 좌표(5179)로 노드레이어 즉시조회(공간필터)
        bp5179 = to_5179.transform(base_point) if to_5179 else base_point
        node_rec = self._query_node_at(bp5179.x(), bp5179.y())
        if node_rec is None:
            # self.iface.messageBar().pushMessage(
            #     '회전정보', '기준노드를 노드파일에서 찾지 못했습니다.',
            #     level=Qgis.Info, duration=2)
            return

        # 선택 링크의 Link_Id(진입) — 활성 레이어에서 읽음
        entry_lid = self._turn_norm(selected_feature['Link_Id']) \
            if layer.fields().lookupField('Link_Id') != -1 else None
        if not entry_lid:
            self.iface.messageBar().pushMessage(
                '회전정보', "선택 링크에 'Link_Id' 필드가 없습니다.",
                level=Qgis.Warning, duration=3)
            return

        # 기준노드에 접하는 인접 링크 수집 (화면 내 공간필터)
        transform_back = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())
        extent = transform_back.transformBoundingBox(self.canvas.extent())
        request = QgsFeatureRequest().setFilterRect(extent)

        results = []   # [(진출링크 지오메트리(원본좌표), 색상)]
        for feat in layer.getFeatures(request):
            if feat.id() == fid:
                continue
            fg = feat.geometry()
            if fg is None or fg.isEmpty():
                continue
            fpts = (fg.asMultiPolyline()[0] if fg.isMultipart() else fg.asPolyline())
            if len(fpts) < 2:
                continue
            # 이 인접 링크가 기준노드(base_point)에 접하는가
            if fpts[0] == base_point:
                touch = True
            elif fpts[-1] == base_point:
                touch = True
            else:
                touch = False
            if not touch:
                continue
            exit_lid = self._turn_norm(feat['Link_Id']) \
                if layer.fields().lookupField('Link_Id') != -1 else None
            if not exit_lid:
                continue
            color = self._turn_color(node_rec, entry_lid, exit_lid)
            if color is None:
                continue
            results.append((QgsGeometry(fg), color))

        # 진출링크 형상을 굵은 색선(RubberBand)으로 표시
        for geom, color in results:
            rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            rb.setToGeometry(geom, layer)     # layer 지정 시 좌표계 자동 변환
            rb.setColor(QColor(color))
            rb.setWidth(4)
            self.TurnSymbol.append(rb)
        self.canvas.refresh()

    def remove_Turn(self, *args):
        if len(self.TurnSymbol) > 0:
            for rb in self.TurnSymbol:
                self.canvas.scene().removeItem(rb)
        self.TurnSymbol = []
        self.canvas.refresh()

    def duplicate_run(self, style, idx = 0, *args):
        # 프로그래스바 추가??
        # self._addin.setDefaultAction(self.duplicate)
        # self.layer_set = set()
        layer = self.iface.activeLayer()
        if idx == 0:
            try:
                features = layer.selectedFeatures()
                new_name = f'__{layer.name()}_선택복사'
            except:
                return
        else:
            features = list(layer.getFeatures())
            new_name = f'__{layer.name()}_레이어복사'

        # self.layer_set.add(layer)
        # for layer in self.layer_set:
        wkb_type = layer.wkbType()
        layer_crs = layer.sourceCrs()
        fields = QgsFields(layer.fields())
        new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
        dp = new_layer.dataProvider()
        dp.addAttributes(fields)
        new_layer.updateFields()

        if style:
            # 스타일을 임시 XML 파일에 저장
            temp_style_file = os.path.join(self.plugin_dir, 'style', 'temp_style.qml')
            layer.saveNamedStyle(temp_style_file)
            # 새 레이어에 스타일 XML 적용
            new_layer.loadNamedStyle(temp_style_file)

            # new_layer.setRenderer(layer.renderer().clone())
            # # 라벨 설정 복사
            # if layer.labeling():
            #     new_layer.setLabeling(layer.labeling().clone())
            #     new_layer.setLabelsEnabled(layer.labelsEnabled())

        QgsProject.instance().addMapLayer(new_layer)
        new_layer.startEditing()

        # for feature in selected_features:
        #     # 속성 값 가져오기
        #     attributes = feature.attributes()
        #     f = QgsFeature()
        #     f.setGeometry(feature.geometry())  # 올바른 방법: QgsGeometry 객체를 전달
        #     f.setAttributes(attributes) # 새로운 QgsFeature에 속성 설정
        #     new_layer.dataProvider().addFeatures([f])

        dp.addFeatures(features)

        new_layer.updateExtents()
        self.canvas.refresh()

    def addKeyfield(self, *args):
        layer = self.iface.activeLayer()
        self.checked_fields = []
        self.keyName = ''
        if layer.type() == QgsMapLayerType.VectorLayer:
            ok_button = self.addKey.buttonBox.button(QDialogButtonBox.Ok)
            close_button = self.addKey.buttonBox.button(QDialogButtonBox.Close)
            model = self.addKey.mComboBox.model()
            checkBox = self.addKey.checkBox
            # 기존에 연결된 슬롯이 있으면 끊어준다
            try:
                ok_button.clicked.disconnect(self.createKey)
                close_button.clicked.disconnect(self.addKey.close)
                model.itemChanged.disconnect(self.onItemChanged)
                checkBox.stateChanged.disconnect(self.chkBox)
            except TypeError:
                # 연결된 게 없으면 무시
                pass
            ok_button.clicked.connect(self.createKey)
            checkBox.stateChanged.connect(self.chkBox)
            self.addKey.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.addKey.close)

            self.addKey.lineEdit.setText('')
            self.addKey.mFieldExpressionWidget.setExpression("")
            self.addKey.mFieldExpressionWidget.setLayer(layer)
            self.addKey.mComboBox.clear()
            for fld in layer.fields():
                self.addKey.mComboBox.addItem(fld.name())
            # 모델의 dataChanged 시그널에 연결
            model = self.addKey.mComboBox.model()
            model.itemChanged.connect(self.onItemChanged)
            self.addKey.progressBar.setValue(0)
            self.addKey.show()

    def chkBox(self, *args):
        if self.addKey.checkBox.isChecked():
            self.addKey.lineEdit.setEnabled(True)
        else:
            self.addKey.lineEdit.setEnabled(False)
            self.addKey.lineEdit.setText(self.keyName)

    def onItemChanged(self, item, *args):
        field = item.text()
        if item.checkState() == Qt.Checked:
            # 새로 체크된 필드는 리스트 뒤에 추가
            if field not in self.checked_fields:
                self.checked_fields.append(field)
        else:
            # 해제된 필드는 리스트에서 제거
            if field in self.checked_fields:
                self.checked_fields.remove(field)
        # 현재 리스트 순서대로 expression 생성
        # 예: "field1" || ' ' || "field2" || ' ' || "field3"
        parts = [f'"{f}"' for f in self.checked_fields]
        expr = " || '_' || ".join(parts) if parts else ""
        names = [f'{f[0]}' for f in self.checked_fields]
        name = "".join(names) if names else " "
        self.keyName = f'{name}_ID'
        if not self.addKey.checkBox.isChecked():
            self.addKey.lineEdit.setText(self.keyName)
        # 식 위젯에 반영
        # (QgsFieldExpressionWidget에는 setExpression 메서드가 있습니다)
        self.addKey.mFieldExpressionWidget.setExpression(expr)

    def createKey(self, *args):
        layer = self.iface.activeLayer()
        total = layer.featureCount()
        if not layer or layer.type() != QgsMapLayerType.VectorLayer:
            return
        name = self.addKey.lineEdit.text()
        fname = "KeyField" if name is None else name
        # 1) 표현식 준비
        expr_str = self.addKey.mFieldExpressionWidget.expression()
        expr = QgsExpression(expr_str)
        ctx  = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

        # 2) KeyField 필드 추가
        if not layer.isEditable():
            layer.startEditing()

        if layer.providerType() == "postgres":
            field = QgsField(fname, QVariant.String, "varchar", 255)
        else:
            field = QgsField(fname, QVariant.String)

        dp = layer.dataProvider()
        dp.addAttributes([field])
        layer.updateFields()
        idx = layer.fields().indexFromName(fname)

        # 3) 모든 피처의 계산값을 dict에 저장
        value_map = {}
        for i, feat in enumerate(layer.getFeatures()):
            ctx.setFeature(feat)
            val = expr.evaluate(ctx)
            if expr.hasEvalError():
                val = ""
            value_map[feat.id()] = { idx: val }
            self.addKey.progressBar.setValue(int(100*(i+1)/max(1,total)))
            
        # 4) 한 번의 호출로 모든 피처 업데이트
        dp.changeAttributeValues(value_map)
        # layer.commitChanges()
        layer.triggerRepaint()
        self.addKey.close()

    def layermerge_run(self, *args):
        self.iface.messageBar().clearWidgets()
        selected_layers = [layer for layer in QgsProject.instance().mapLayers().values() if layer in self.iface.layerTreeView().selectedLayers()]
        if len(selected_layers) < 2:
            self.iface.messageBar().pushMessage(f'병합할 레이어가 두 개 이상 선택되어야 합니다.', level=Qgis.Critical, duration=3)
        else:
            # 각 레이어에 "layer_name" 가상 필드 추가
            for layer in selected_layers:
                layer_name = layer.name()  # 현재 레이어 이름
                layer_path = layer.source() # 현재 레이어 경로

                # 가상 필드 추가
                layer.addExpressionField(
                    f"'{layer_name}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_name", QVariant.String),  # 필드명과 유형 설정
                )

                layer.addExpressionField(
                    f"'{layer_path}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_path", QVariant.String),  # 필드명과 유형 설정
                )

            # 병합 처리 실행
            try:
                result = processing.run("native:mergevectorlayers", {
                    "LAYERS": selected_layers,
                    "CRS": selected_layers[0].crs(),
                    "OUTPUT": "memory:"  # 결과를 메모리 레이어로 저장
                })
                # 결과 레이어 이름 지정 및 추가
                merged_layer = result["OUTPUT"]
                merged_layer.setName("병합한 레이어")  # 여기서 이름을 설정

                # 편집 모드 시작
                merged_layer.startEditing()
                for field_name in ["layer", "path"]:  # 제거할 필드 목록
                    idx = merged_layer.fields().indexOf(field_name)
                    if idx != -1:
                        merged_layer.deleteAttribute(idx)
                
                # 편집 모드 종료 및 변경사항 저장
                merged_layer.commitChanges()

                # 병합 레이어 추가
                QgsProject.instance().addMapLayer(merged_layer)

                for layer in selected_layers:
                    for field_name in ["layer_name", "layer_path"]:  # 제거할 필드 목록
                        idx = layer.fields().indexOf(field_name)
                        if idx != -1:
                            layer.deleteAttribute(idx)

                self.iface.messageBar().pushMessage(f'레이어 병합', level=Qgis.Info, duration=5)
            except Exception as e:
                self.iface.messageBar().pushMessage(f'레이어 병합 오류 : {e}', level=Qgis.Critical, duration=5)
                pass

    def folderOpen(self, *args):
        self.iface.messageBar().clearWidgets()
        # 활성화된 레이어 가져오기
        layer = self.iface.activeLayer()
        
        # 레이어가 없는 경우
        if not layer:
            return

        # 임시 레이어인지 확인
        if layer.isTemporary():
            self.iface.messageBar().pushMessage(f'임시 레이어는 경로를 열 수 없습니다.', level=Qgis.Warning, duration=5)
            return

        # 레이어의 소스 경로 가져오기
        layer_source = layer.source().split('|')[0]

        # 로컬 파일 경로가 아닌 경우
        if not os.path.isfile(layer_source):
            self.iface.messageBar().pushMessage(f'이 레이어는 로컬 파일이 아닙니다.', level=Qgis.Warning, duration=5)
            return

        # 탐색기에서 경로 열기
        folder_path = os.path.dirname(layer_source)
        os.startfile(folder_path)  # Windows에서 탐색기를 엽니다.

    def remove_Marker(self, *args):
        if len(self.MarkerSymbol) > 0:
            for mark in self.MarkerSymbol:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol = []
        self.canvas.refresh()  

    def remove_Angle(self, *args):
        if len(self.AngleSymbol) > 0:
            for mark in self.AngleSymbol:
                self.canvas.scene().removeItem(mark)
        self.AngleSymbol = []
        self.canvas.refresh() 