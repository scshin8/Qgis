'''
***************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

***************************************************************************

* 최초개발시작 2022.5.14
* 좌표복사 추가(개별툴)
* 좌표이동 추가(개별툴)
* 좌표복사, 이동 개별툴에서 하나로 통합
* 복사 및 이동 좌표계 설정가능하도록 수정
* 웹지도 열기 추가(다음,네이버)
* 도엽이동 및 경위도 이동 추가
* API이용한 주소복사 및 이동 추가(카카오,네이버,브이월드)
* 좌표정보 보기 기능 추가
* 주변POI검색기능 추가(Ruoto)
* 키워드 검색 기능 추가(카카오, Ruoto)
* 경로탑색기능 추가(Ruoto,네이버)
* SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 좌표변환 기능 추가
* 필드계산기 함수 추가
* MMS좌표복사 기능 추가
* 도형계산기 기능 추가
* speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가
* pyautogui 설치 기능 추가
* 검색기능 추가, 협력사 인덱스 추가, 도움말링크 추가(플러그인 메뉴얼)

***************************************************************************
'''

from qgis.core import (QgsApplication,
                       QgsCoordinateReferenceSystem, 
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer, 
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling)

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QFileInfo,
                          QSettings,
                          QTranslator, 
                          QCoreApplication)

from qgis.gui import (QgsDockWidget,
                      QgsRubberBand,
                      QgsVertexMarker)

from PyQt5.QtGui import (QColor,
                         QIcon,
                         QFont)

from qgis.PyQt.QtWidgets import QMenu

from PyQt5.QtWidgets import (QApplication,                              
                             QFileDialog, 
                             QAction, 
                             QToolButton)

import os.path
from .CoordinateFunctions import InitLatLonFunctions, UnloadLatLonFunctions
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_info import CoordinateToolinfo
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Funtion import Coordinate_funtion
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converte import CoordinateToolConverte
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
from .Coordinate_Tool_Searchlayer import LayerSearchDialog
import subprocess
import webbrowser

class CoordinateTool:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.crossRb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard = QApplication.clipboard()
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None  
        self.MediaCenterTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.searchDialog = None
        self.Delete_Marker_timer = QTimer()
        self.Markers=[]
        self.plugin_dir = os.path.dirname(__file__)
        
        self.locale = QSettings()
        # locale_path = os.path.join(self.plugin_dir,'i18n','CoordinateTool_{}.qm'.format(self.locale))
        
        # 함수
        self.Funtion = Coordinate_funtion(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 좌표변환
        self.Converter = CoordinateToolConverte(self,self.iface)
        # 도형계산기
        self.Geometry = CoordinateToolGeometry(self,self.iface)
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        
        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("QGIS 이동,검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("QGIS 이동,검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()
        
        # 좌표변환창 위젯 설정
        self.dlgconversion = CoordinateToolinfo(self,self.iface)
        self.dlgconversionwidget = QgsDockWidget("QGIS 좌표정보" , self.iface.mainWindow() )
        self.dlgconversionwidget.setObjectName("QGIS 좌표정보")
        self.dlgconversionwidget.setWidget(self.dlgconversion)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgconversionwidget )
        self.dlgconversionwidget.hide()
        
        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("QGIS 경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("QGIS 경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        self.actions = []
        self.menu = self.tr(u'&좌표도구')

        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)

        # Initialize the plugin path directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        try:
            locale = QSettings().value("locale/userLocale", "en", type=str)[0:2]
        except Exception:
            locale = "en"
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'searchLayers_{}.qm'.format(locale))
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)



    def tr(self, message):
        return QCoreApplication.translate('CoordinateTool', message)


    def initGui(self):

        InitLatLonFunctions()
        
        #==================================================================================
        
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("복사")
        
        Menu = QMenu()
        Menu.setObjectName('copymenu')
         
        icon = QIcon(os.path.dirname(__file__) + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)
        self.copy1 = Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 
        self.Coordinatecapture.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        self.copy4 = Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 
        self.MediaCenter.setEnabled(False)
        
        self.toolbar.addWidget( self.copy)
 
        icon = QIcon(os.path.dirname(__file__) + '/icons/capture.png')
        self.copycopy = QAction(icon, '복사', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.copycopy)
 
        #==================================================================================

        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")
        
        Menu = QMenu()
        Menu.setObjectName('movemenu')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(self.move1)
        self.movemap.addAction(self.movemap1)
        self.movemap.setDefaultAction(self.movemap1)
        self.movemenu1 = Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        self.movemap1.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(self.move2)
        self.movemap.addAction(self.movemap2)
        self.movemenu2 = Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        self.movemap2.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(self.move3)
        self.movemap.addAction(self.movemap3)
        self.movemenu3 = Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        self.movemap3.setEnabled(False)
        
        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.movemove)
        
        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        self.ShowOnmap.setEnabled(False)
        
        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소복사", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소복사')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.toolbar.addAction(self.mapaddress)
        self.iface.addPluginToMenu("좌표도구", self.mapaddress)
        self.mapaddress.setEnabled(False)
        
        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/search.png')
        self.search = QAction(icon, "이동,검색", self.iface.mainWindow())
        self.search.setObjectName('이동,검색')
        # self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.toolbar.addAction(self.search)
        self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.iface.addPluginToMenu("좌표도구", self.search)
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)
        self.search.setEnabled(False)
        
        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/information.png')
        self.conversion = QAction(icon, "좌표정보", self.iface.mainWindow())
        self.conversion.setObjectName('좌표정보')
        # self.conversion.triggered.connect(self.conversionwidget)
        self.conversion.setCheckable(True)
        self.toolbar.addAction(self.conversion)
        self.iface.registerMainWindowAction(self.conversion,'Shift+I')
        self.iface.addPluginToMenu("좌표도구", self.conversion)
        self.dlgconversionwidget.setToggleVisibilityAction(self.conversion)
        self.conversion.setEnabled(False)
        
        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        # self.path_search.triggered.connect(self.PathSearchwidget)
        self.path_search.setCheckable(True)
        self.toolbar.addAction(self.path_search)
        self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.iface.addPluginToMenu("좌표도구", self.path_search)
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)
        self.path_search.setEnabled(False)
        
        #==================================================================================
        
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")
        
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        self.geo1=Menu.addAction(self.coordinateConverter)
        self.coordinateConverter.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        self.geo2=Menu.addAction(self.coordinateGeometry)
        self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.geo)
        
        #==================================================================================
        
        self.indexshp = QToolButton(self.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")
        
        Menu = QMenu()
        Menu.setObjectName('쉐입파일')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/folder.png')
        self.shpfileopen = QAction(icon, "파일열기", self.iface.mainWindow())
        self.shpfileopen.setObjectName('파일열기')
        self.shpfileopen.triggered.connect(self.fileopen)
        self.shpfileopen.setCheckable(True)
        self.indexshp.addAction(self.shpfileopen)
        self.shp1=Menu.addAction(self.shpfileopen)
        self.indexshp.setDefaultAction(self.shpfileopen)
        self.iface.registerMainWindowAction(self.shpfileopen,'Shift+O')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(self.besselindex)
        self.indexshp.addAction(self.besindex)
        self.shp2=Menu.addAction(self.besindex)
        
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "WGS84인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('WGS84인덱스')
        self.grsindex.triggered.connect(self.GRSindex)
        self.indexshp.addAction(self.grsindex)
        self.shp3=Menu.addAction(self.grsindex)

        icon = QIcon(os.path.dirname(__file__) + '/icons/협력사.png')
        self.partnerindex = QAction(icon, "협력사", self.iface.mainWindow())
        self.partnerindex.setObjectName('협력사')
        self.partnerindex.triggered.connect(self.Partnerindex)
        self.indexshp.addAction(self.partnerindex)
        self.shp3=Menu.addAction(self.partnerindex)

        icon = QIcon(os.path.dirname(__file__) + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(self.ctp)
        self.indexshp.addAction(self.ctpshp)
        self.shp4=Menu.addAction(self.ctpshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(self.sig)
        self.indexshp.addAction(self.sigshp)
        self.shp5=Menu.addAction(self.sigshp)
        
        # icon = QIcon(os.path.dirname(__file__) + '/icons/emd.png')
        # self.emdshp = QAction(icon, "읍면동행정계", self.iface.mainWindow())
        # self.emdshp.setObjectName('읍면동행정계')
        # self.emdshp.triggered.connect(self.emd)
        # self.indexshp.addAction(self.emdshp)
        # self.shp6=Menu.addAction(self.emdshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self.indexshp.addAction(self.Bookmark)
        self.shp7=Menu.addAction(self.Bookmark)
        self.toolbar.addWidget( self.indexshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/folder.png')
        self.shp = QAction(icon, '쉐입파일', self.iface.mainWindow())
        self.shp.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.shp)

        #==================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/searchLayers.png')
        self.searchAction = QAction(icon, "검색", self.iface.mainWindow())
        self.searchAction.setObjectName('검색')
        self.searchAction.triggered.connect(self.showSearchDialog)
        self.toolbar.addAction(self.searchAction)
        self.iface.addPluginToMenu("좌표도구", self.searchAction)
        self.iface.registerMainWindowAction(self.searchAction,'F4')

        #==================================================================================

        icon = QIcon(os.path.dirname(__file__) + '/icons/setting.png')
        self.set = QAction(icon, "설정", self.iface.mainWindow())
        self.set.setObjectName('설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')


        # Help
        icon = QIcon(os.path.dirname(__file__) + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        self.iface.addPluginToMenu('좌표도구', self.helpAction)

        self.toggle()

    def help(self):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화===================================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        # 화면 정리
        self.Delete_Marker()
        self.dlgPathSearch.delete()
        self.dlgSearch.RemoveAll()
        
        # 메뉴삭제
        self.iface.removePluginMenu('좌표도구', self.Coordinatecapture)
        self.iface.removePluginMenu('좌표도구', self.ShowOnmap)
        self.iface.removePluginMenu('좌표도구', self.MediaCenter)
        self.iface.removePluginMenu('좌표도구', self.mapaddress)
        self.iface.removePluginMenu('좌표도구', self.search)
        self.iface.removePluginMenu('좌표도구', self.conversion)
        self.iface.removePluginMenu('좌표도구', self.path_search)
        self.iface.removePluginMenu('좌표도구', self.movemove)
        self.iface.removePluginMenu('좌표도구', self.copycopy)
        self.iface.removePluginMenu('좌표도구', self.shp)
        # self.iface.removePluginMenu('좌표도구', self.layermove)
        self.iface.removePluginMenu('좌표도구', self.geo)
        self.iface.removePluginMenu('좌표도구', self.set)
        self.iface.removePluginMenu('좌표도구', self.searchAction)

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        # self.iface.removeToolBarIcon(self.CoordinateSpeedFs)
        # self.iface.removeToolBarIcon(self.CoordinateCoconut)
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.conversion)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.shpfileopen)
        self.iface.removeToolBarIcon(self.besindex)
        self.iface.removeToolBarIcon(self.grsindex)
        self.iface.removeToolBarIcon(self.ctpshp)
        self.iface.removeToolBarIcon(self.sigshp)
        # self.iface.removeToolBarIcon(self.emdshp)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.set)
        self.iface.removeToolBarIcon(self.searchAction)
        del self.toolbar
        
        
        # 필드계산기 표현식 삭제
        UnloadLatLonFunctions()
        
        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgconversionwidget)
        self.dlgconversionwidget = None
        self.dlgconversion = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None
        
        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        # self.iface.unregisterMainWindowAction(self.CoordinateSpeedFs)
        # self.iface.unregisterMainWindowAction(self.CoordinateCoconut)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.shpfileopen)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.conversion)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.searchAction)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

    def showSearchDialog(self):
        if self.searchDialog is None:
            # All the work is done in the LayerSearchDialog
            self.searchDialog = LayerSearchDialog(self.iface, self.iface.mainWindow())
        self.searchDialog.show()

    def toggle(self):
        layer = self.canvas.currentLayer()
        if layer :
            try:
                layer.editingStarted.disconnect(self.toggle)
            except:
                pass
            try:
                layer.editingStopped.disconnect(self.toggle)
            except:
                pass

            enabled_flag = True

            if layer and layer.type() == layer.VectorLayer:
                self.searchAction.setEnabled(True)
            else:
                self.searchAction.setEnabled(False)

            enabled_flag = True
        else:
            self.searchAction.setEnabled(False)
            enabled_flag = False

        self.Coordinatecapture.setEnabled(enabled_flag)
        # self.CoordinateSpeedFs.setEnabled(enabled_flag)
        # self.CoordinateCoconut.setEnabled(enabled_flag)
        self.MediaCenter.setEnabled(enabled_flag)
        self.movemap1.setEnabled(enabled_flag)
        self.movemap2.setEnabled(enabled_flag)
        self.movemap3.setEnabled(enabled_flag)
        self.ShowOnmap.setEnabled(enabled_flag)
        self.mapaddress.setEnabled(enabled_flag)
        self.search.setEnabled(enabled_flag)
        self.conversion.setEnabled(enabled_flag)
        self.path_search.setEnabled(enabled_flag)
        self.coordinateConverter.setEnabled(enabled_flag)
        self.coordinateGeometry.setEnabled(enabled_flag)

# 좌표 캡쳐 실행=========================================================================================================================================
    def capture(self):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행============================================================================================================================================
    def mediaCenter(self):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionPan().trigger() 
        
        
# 웹지도 실행============================================================================================================================================
    def ShowOn(self):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            print('ShowOn end')
            self.iface.actionPan().trigger()
            
# 주소 캡쳐 실행=========================================================================================================================================
    def address(self):
        # 마커 표시 삭제
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionPan().trigger()
            
# 좌표 이동 구문 ========================================================================================================================================
    # 좌표이동1 실행
    def move1(self):
        Order=int(self.locale.value('locale/coordinate_tool/ComboBox3', 0))
        text = self.clipboard.text().strip()
        setCRS = QgsCoordinateReferenceSystem(self.locale.value('locale/coordinate_tool/Project3','USER:100000'))
        try:
            lon, lat = self.Funtion.setval(setCRS,text)
            self.move4(setCRS, lon, lat, Order,self.movemap1)
        except:
            print('move1 좌표확인')
    # 좌표이동2 실행
    def move2(self):
        Order=int(self.locale.value('locale/coordinate_tool/ComboBox4', 0))
        text = self.clipboard.text().strip()
        setCRS = QgsCoordinateReferenceSystem(self.locale.value('locale/coordinate_tool/Project4','USER:100001'))
        try:
            lon, lat = self.Funtion.setval(setCRS,text)
            self.move4(setCRS, lon, lat, Order,self.movemap2)
        except:
            print('move2 좌표확인')
    # 좌표이동3 실행
    def move3(self):
        Order=int(self.locale.value('locale/coordinate_tool/ComboBox5', 0))
        text = self.clipboard.text().strip()
        setCRS = QgsCoordinateReferenceSystem(self.locale.value('locale/coordinate_tool/Project5','USER:100001'))
        try:
            lon, lat = self.Funtion.setval(setCRS,text)
            self.move4(setCRS, lon, lat, Order,self.movemap3)
        except:
            print('move3 좌표확인')
            
    def move4(self,setCRS, lon, lat, Order,movemap):
        self.Delete()
        self.movemap.setDefaultAction(movemap)
        self.Funtion.moveto(setCRS, lon, lat, Order)
        self.canvas.refresh()
        self.iface.actionPan().trigger()
        
# 검색창 실행=================================================================================================================================================================
    def searchtool(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgSearchwidget.show()
      
# 좌표변환정보 실행=================================================================================================================================================================
    def conversionwidget(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgconversionwidget.show()
        
# 경로탐색 실행 =================================================================================================================================================================
    def PathSearchwidget(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgPathSearchwidget.show()
        
# 베셀 인덱스 =================================================================================================================================================================  
    def besselindex(self):
        self.Delete()
        # self.indexshp.setDefaultAction(self.besindex)
        self.cmtName = "Bessel_Index"
        
        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/index/Bessel_Index.shp', self.cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)

            soldcol = QColor(0, 0, 0, 0) # 채우기색
            linecol = QColor(205, 133, 51, 255) # 테두리색 R / G / B / 투명도
            lineWidth = 0.3 # 테두리 너비
            
            self.setsymbol(layer, "MAP_ID", soldcol, linecol, lineWidth)
            layer.triggerRepaint()
            
# GRS 인덱스 =================================================================================================================================================================  
    def GRSindex(self):  
        self.Delete()
        # self.indexshp.setDefaultAction(self.grsindex)
        self.cmtName = "WGS84_Index"
        
        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/index/WGS84_Index.shp', self.cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)
            
            # 심볼설정
            soldcol = QColor(0, 0, 0, 0) # 채우기색
            linecol = QColor(77, 175, 74, 255) # 테두리색 R / G / B / 투명도
            lineWidth = 0.3 # 테두리 너비
            
            self.setsymbol(layer,"MAP_ID", soldcol, linecol, lineWidth)
            layer.triggerRepaint()

# 협력사 인덱스 =================================================================================================================================================================  
    def Partnerindex(self):  
        self.Delete()
        # self.indexshp.setDefaultAction(self.grsindex)
        self.cmtName = "협력사"
        
        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/index/협력사.shp', self.cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)
            
            # 심볼설정
            soldcol = QColor(0, 0, 0, 0) # 채우기색
            linecol = QColor(70, 130, 180, 255) # 테두리색 R / G / B / 투명도
            lineWidth = 0.3 # 테두리 너비
            
            self.setsymbol(layer,"협력사", soldcol, linecol, lineWidth)
            layer.triggerRepaint()

# 시도행정계 =================================================================================================================================================================  
    def ctp(self):  
        self.Delete()
        # self.indexshp.setDefaultAction(self.ctpshp)
        self.cmtName = "시도행정계"
        
        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/district/ctp.shp', self.cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)
            
            # 심볼설정
            soldcol = QColor(0, 0, 0, 0) # 채우기색
            linecol = QColor(77, 105, 141, 255) # 테두리색 R / G / B / 투명도
            lineWidth = 0.8 # 테두리 너비
            
            self.setsymbol(layer,"CTP_KOR_NM", soldcol, linecol, lineWidth)
            layer.triggerRepaint()
            
# 시군구행정계 =================================================================================================================================================================  
    def sig(self):  
        self.Delete()
        # self.indexshp.setDefaultAction(self.sigshp)
        self.cmtName = "시군구행정계"
        
        layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/district/sig.shp', self.cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)
            
            # 심볼설정
            soldcol = QColor(0, 0, 0, 0) # 채우기색
            linecol = QColor(103, 153, 141, 255) # 테두리색 R / G / B / 투명도
            lineWidth = 0.4 # 테두리 너비
            
            self.setsymbol(layer,"SIG_KOR_NM", soldcol, linecol, lineWidth)
            layer.triggerRepaint()   
            
# 읍면동행정계 =================================================================================================================================================================  
    # def emd(self):  
    #     self.Delete()
    #     # self.indexshp.setDefaultAction(self.emdshp)
    #     self.cmtName = "읍면동행정계"
        
    #     layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
    #     if layers:
    #         # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
    #         layer = layers[0]  
    #     else:
    #          # 인덱스 레이어가 없다면 레이어 추가
    #         layer = QgsVectorLayer(os.path.dirname(__file__) + '/shp/district/emd.shp', self.cmtName, "ogr")
    #         QgsProject.instance().addMapLayer(layer)
            
    #         # 심볼설정
    #         soldcol = QColor(0, 0, 0, 0) # 채우기색
    #         linecol = QColor(140, 120, 150, 255) # 테두리색 R / G / B / 투명도
    #         lineWidth = 0.2 # 테두리 너비
            
    #         self.setsymbol(layer,"EMD_KOR_NM", soldcol, linecol, lineWidth)
    #         layer.triggerRepaint()       
            
# 심볼 설정 =================================================================================================================================================================  
    def setsymbol(self,layer,fieldName,soldcol,linecol,lineWidth): 
        # 심볼 스타일 설정
        layer.renderer().symbol().setColor(soldcol) # 채우기색
        layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 R / G / B / 투명도
        layer.renderer().symbol().symbolLayer(0).setStrokeWidth(lineWidth) # 테두리 너비
        if self.cmtName == "읍면동행정계":
            # 라인 스타일
            layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine
        
        #라벨 스타일 설정
        layer_settings  = QgsPalLayerSettings()
        text_format = QgsTextFormat()
        text_format.setFont(QFont("맑은 고딕", 9))
        text_format.setSize(9)
        # text_format.setColor(QColor(255, 0, 255, 255))
        
        # buffer_settings = QgsTextBufferSettings()
        # buffer_settings.setEnabled(True)
        # buffer_settings.setSize(1)
        # buffer_settings.setColor(QColor("white"))
        # text_format.setBuffer(buffer_settings)
        
        layer_settings.setFormat(text_format)

        layer_settings.fieldName = fieldName
        # layer_settings.placement = 2
        
        layer_settings.enabled = True
    
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        # 스타일 새로고침
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())
        
# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None
        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)
        
# 파일열기 ================================================================================================================================================================= 
    def fileopen(self):
        self.shpfileopen.setChecked(True)
        # self.indexshp.setDefaultAction(self.shpfileopen)
        self.Delete()
        filepath=self.locale.value('locale/coordinate_tool/filepath', '')
        files = QFileDialog.getOpenFileNames(self.iface.mainWindow(), 'Open file',filepath, 'Shapefiles (*.shp);;Excelfiles (*.xls *.xlsx);;All File(*)')[0]
        for file in files:
            
            filename = QFileInfo(str(file)).fileName()
            filepath = QFileInfo(str(file)).path()
            self.locale.setValue('locale/coordinate_tool/filepath', filepath)
            self.shpBookmark.fileopen(file)
        self.shpfileopen.setChecked(False)
# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self):
        # self.indexshp.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()
        # print(filename)
        
# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================= 
    def Geometrywidget(self):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        self.Geometry.show() 
        
# 설정창 실행=================================================================================================================================================================
    def setting(self):
        self.Delete()
        self.dlg.show()
        
# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self,t):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시=================================================================================================================================================================
    def Draw_Marker(self,point,idx):
        # 마커 표시 삭제
        
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)
            
        # self.Delete_Marker()
        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()