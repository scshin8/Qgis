'''
***************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

***************************************************************************

* 최초개발시작 2022.5.14
* 좌표복사 추가(개별툴)
* 좌표이동 추가(개별툴)
* 좌표복사, 이동 개별툴에서 하나로 통합
* 복사 및 이동 좌표계 설정가능하도록 수정
* 웹지도 열기 추가(다음,네이버)
* 도엽이동 및 경위도 이동 추가
* API이용한 주소복사 및 이동 추가(카카오,네이버,브이월드)
* 좌표정보 보기 기능 추가
* 주변POI검색기능 추가(Ruoto)
* 키워드 검색 기능 추가(카카오, Ruoto)
* 경로탑색기능 추가(Ruoto,네이버)
* SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 좌표변환 기능 추가 22-11-12
* 필드계산기 함수 추가
* MMS좌표복사 기능 추가
* 도형계산기 기능 추가
* speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가 23-01-30
* pip module "pyautogui" 설치 기능 추가 23-02-05
* 경로탐색 검색기능 개선(카카오 추가), 경로탐색 속도 개선 23-02-05
* pip module 자동 설치 추가  23-02-07
* coconut 이동 bessel,GRS 선택 추가 23-02-10
* 구글 경로 탐색 개선 : 경유지 검색 개선, 구글탭 추가, 경로 폴리라인 표출 개선 23-02-20
* 구글 좌표 주변 검색 추가, 웹지도 열기 코드 개선 23-03-09
* 경로 탐색 개선 23-03-12
* 검색기능 추가, 협력사 인덱스 추가, 도움말링크 추가(플러그인 메뉴얼) 23-09-02
* 대권역 속성값 수정, API Key 암호화, 중복 코드 수정 23-09-10
* 행정계 SHP 교체 (군위군 대구광역시 편입) 23-09-11


***************************************************************************
'''

from qgis.core import (QgsCoordinateReferenceSystem, 
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer, 
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling,
                       QgsSymbol,
                       QgsSimpleFillSymbolLayer,
                       QgsRendererCategory,
                       QgsCategorizedSymbolRenderer)

from PyQt5.QtCore import (QTimer,
                          QPoint,
                          Qt,
                          QFileInfo,
                          QSettings,
                          QCoreApplication)

from qgis.gui import (QgsDockWidget,
                      QgsRubberBand,
                      QgsVertexMarker,
                      QgsMapCanvas)

from PyQt5.QtGui import (QColor,
                         QIcon,
                         QFont)

from qgis.PyQt.QtWidgets import (QMenu,
                                 QMessageBox,
                                 QCheckBox)

from PyQt5.QtWidgets import (QApplication,                              
                             QFileDialog, 
                             QAction, 
                             QToolButton)

from qgis.utils import (unloadPlugin, 
                        loadPlugin, 
                        startPlugin)
import os.path
from .CoordinateFunctions import InitLatLonFunctions, UnloadLatLonFunctions
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_info import CoordinateToolinfo
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Funtion import Coordinate_funtion
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converte import CoordinateToolConverte
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_Memo import CoordinateToolMemo
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
from .Coordinate_Tool_Searchlayer import LayerSearchDialog
import subprocess
import webbrowser
import random,datetime
class CoordinateTool:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.crossRb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard = QApplication.clipboard()
        # 좌표도구 툴바 설정
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')

        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None  
        self.MediaCenterTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.searchDialog = None
        self.Delete_Marker_timer = QTimer()
        self.Markers=[]
        self.plugin_dir = os.path.dirname(__file__)
        self.Plugin='coordinate_tool'
        self.QSettings = QSettings()
        # locale_path = os.path.join(self.plugin_dir,'i18n','CoordinateTool_{}.qm'.format(self.QSettings))

        # 기존 셋팅값 삭제
        self.Settingsdelete()
        # 함수
        self.Funtion = Coordinate_funtion(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 좌표변환
        self.Converter = CoordinateToolConverte(self.iface, self.iface.mainWindow())
        # 도형계산기
        self.Geometry = CoordinateToolGeometry(self.iface, self.iface.mainWindow())
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        
        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("QGIS 이동,검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("QGIS 이동,검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()
        
        # 좌표변환창 위젯 설정
        self.dlgconversion = CoordinateToolinfo(self,self.iface)
        self.dlgconversionwidget = QgsDockWidget("QGIS 좌표정보" , self.iface.mainWindow() )
        self.dlgconversionwidget.setObjectName("QGIS 좌표정보")
        self.dlgconversionwidget.setWidget(self.dlgconversion)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgconversionwidget )
        self.dlgconversionwidget.hide()
        
        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("QGIS 경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("QGIS 경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        # 메모장 위젯 설정
        self.dlgmemo = CoordinateToolMemo(self,self.iface)
        self.dlgmemowidget = QgsDockWidget("QGIS 메모장" , self.iface.mainWindow() )
        self.dlgmemowidget.setObjectName("QGIS 메모장")
        self.dlgmemowidget.setWidget(self.dlgmemo)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgmemowidget )
        self.dlgmemowidget.hide()

        self.actions = []
        self.menu = '&좌표도구'

        # QgsMapCanvas 인스턴스 생성
        self.mapcanvas = QgsMapCanvas()

        # self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)

        # # Initialize the plugin path directory
        # self.plugin_dir = os.path.dirname(__file__)

        # # initialize locale
        # try:
        #     locale = QSettings().value("locale/userLocale", "en", type=str)[0:2]
        # except Exception:
        #     locale = "en"
        # locale_path = os.path.join(
        #     self.plugin_dir,
        #     'i18n',
        #     'searchLayers_{}.qm'.format(locale))
        # if os.path.exists(locale_path):
        #     self.translator = QTranslator()
        #     self.translator.load(locale_path)
        #     QCoreApplication.installTranslator(self.translator)
    def unload(self):
        unloadPlugin(self.Plugin)

    def initGui(self):

        # 필드계산기 함수 추가
        InitLatLonFunctions()
        
        #==================================================================================
        # 툴바에 드롭다운 목록 생성
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("복사")
        # 메뉴에 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('copymenu')

        #===========================================================================================================================
        # 좌표 복사
        icon = QIcon(os.path.dirname(__file__) + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)
        self.copy1 = Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 
        # self.Coordinatecapture.setEnabled(False)

        # 미디어센터 좌표 이동
        icon = QIcon(os.path.dirname(__file__) + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        self.copy4 = Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 
        # self.MediaCenter.setEnabled(False)

        # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.copy)

        # 메뉴에 드롭다운 목록 추가
        icon = QIcon(os.path.dirname(__file__) + '/icons/capture.png')
        self.copycopy = QAction(icon, '좌표복사', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.copycopy)
 
        #===========================================================================================================================

        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")
        
        Menu = QMenu()
        Menu.setObjectName('movemenu')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(lambda : self.mapMove(1,self.movemap1))
        self.movemap.addAction(self.movemap1)
        self.movemap.setDefaultAction(self.movemap1)
        self.movemenu1 = Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        # self.movemap1.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(lambda : self.mapMove(2,self.movemap2))
        self.movemap.addAction(self.movemap2)
        self.movemenu2 = Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        # self.movemap2.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(lambda : self.mapMove(3,self.movemap3))
        self.movemap.addAction(self.movemap3)
        self.movemenu3 = Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        # self.movemap3.setEnabled(False)
        
        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.movemove)
        
        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        # self.ShowOnmap.setEnabled(False)
        
        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소복사", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소복사')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.toolbar.addAction(self.mapaddress)
        self.iface.addPluginToMenu("좌표도구", self.mapaddress)
        # self.mapaddress.setEnabled(False)
        
        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/search.png')
        self.search = QAction(icon, "이동,검색", self.iface.mainWindow())
        self.search.setObjectName('이동,검색')
        # self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.toolbar.addAction(self.search)
        self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.iface.addPluginToMenu("좌표도구", self.search)
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)
        # self.search.setEnabled(False)
        
        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/information.png')
        self.conversion = QAction(icon, "좌표정보", self.iface.mainWindow())
        self.conversion.setObjectName('좌표정보')
        # self.conversion.triggered.connect(self.conversionwidget)
        self.conversion.setCheckable(True)
        self.toolbar.addAction(self.conversion)
        self.iface.registerMainWindowAction(self.conversion,'Shift+I')
        self.iface.addPluginToMenu("좌표도구", self.conversion)
        self.dlgconversionwidget.setToggleVisibilityAction(self.conversion)
        # self.conversion.setEnabled(False)
        
        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        # self.path_search.triggered.connect(self.PathSearchwidget)
        self.path_search.setCheckable(True)
        self.toolbar.addAction(self.path_search)
        self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.iface.addPluginToMenu("좌표도구", self.path_search)
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)
        # self.path_search.setEnabled(False)
        
        #===========================================================================================================================
        
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")
        
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        # self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        self.geo1=Menu.addAction(self.coordinateConverter)
        # self.coordinateConverter.setEnabled(False)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        # self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        self.geo2=Menu.addAction(self.coordinateGeometry)
        # self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.geo)
        
        #===========================================================================================================================
        
        self.indexshp = QToolButton(self.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")
        
        Menu = QMenu()
        Menu.setObjectName('쉐입파일')
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(lambda : self.shpIndex(1, self.besindex, "Bessel_Index", "Bessel_Index.shp",  "MAP_ID", "협력사", 0.3 ))
        self.indexshp.addAction(self.besindex)
        self.indexshp.setDefaultAction(self.besindex)
        self.shp1=Menu.addAction(self.besindex)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "GRS인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('GRS인덱스')
        self.grsindex.triggered.connect(lambda : self.shpIndex(2, self.grsindex, "GRS_Index", "GRS_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex)
        self.shp2=Menu.addAction(self.grsindex)

        icon = QIcon(os.path.dirname(__file__) + '/icons/wgsindex.png')
        self.wgsindex = QAction(icon, "WGS인덱스", self.iface.mainWindow())
        self.wgsindex.setObjectName('WGS인덱스')
        self.wgsindex.triggered.connect(lambda : self.shpIndex(3, self.wgsindex, "WGS84_Index", "WGS84_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex)
        self.shp3=Menu.addAction(self.wgsindex)

        icon = QIcon(os.path.dirname(__file__) + '/icons/partnerindex.png')
        self.parindex = QAction(icon, "협력사인덱스", self.iface.mainWindow())
        self.parindex.setObjectName('협력사인덱스')
        self.parindex.triggered.connect(lambda : self.shpIndex(4, self.parindex, "협력사_Index", "Partner_Index.shp","협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex)
        self.shp4=Menu.addAction(self.parindex)

        icon = QIcon(os.path.dirname(__file__) + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(lambda : self.shpIndex(5, self.ctpshp, "시도행정계", "ctp.shp", "CTP_KOR_NM", "CTP_KOR_NM", 0.6))
        self.indexshp.addAction(self.ctpshp)
        self.shp5=Menu.addAction(self.ctpshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(lambda : self.shpIndex(6, self.sigshp, "시군구행정계", "sig.shp", "SIG_KOR_NM", "CTP_KOR_NM", 0.3))
        self.indexshp.addAction(self.sigshp)
        self.shp6=Menu.addAction(self.sigshp)
        
        # icon = QIcon(os.path.dirname(__file__) + '/icons/emd.png')
        # self.emdshp = QAction(icon, "읍면동행정계", self.iface.mainWindow())
        # self.emdshp.setObjectName('읍면동행정계')
        # self.emdshp.triggered.connect(lambda : self.shpIndex(7))
        # self.indexshp.addAction(self.emdshp)
        # self.shp6=Menu.addAction(self.emdshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/folder.png')
        self.shpfileopen = QAction(icon, "파일열기", self.iface.mainWindow())
        self.shpfileopen.setObjectName('파일열기')
        self.shpfileopen.triggered.connect(self.fileopen)
        # self.shpfileopen.setCheckable(True)
        self.indexshp.addAction(self.shpfileopen)
        self.shp7=Menu.addAction(self.shpfileopen)
        self.iface.registerMainWindowAction(self.shpfileopen,'Shift+O')

        icon = QIcon(os.path.dirname(__file__) + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self.indexshp.addAction(self.Bookmark)
        self.shp8=Menu.addAction(self.Bookmark)
        self.toolbar.addWidget( self.indexshp)
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/folder.png')
        self.shp = QAction(icon, '쉐입파일', self.iface.mainWindow())
        self.shp.setMenu(Menu)
        self.iface.addPluginToMenu("좌표도구" , self.shp)

        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/searchLayers.png')
        self.searchAction = QAction(icon, "검색", self.iface.mainWindow())
        self.searchAction.setObjectName('검색')
        self.searchAction.triggered.connect(self.showSearchDialog)
        self.toolbar.addAction(self.searchAction)
        self.iface.addPluginToMenu("좌표도구", self.searchAction)
        self.iface.registerMainWindowAction(self.searchAction,'F4')

        #===========================================================================================================================
        
        icon = QIcon(os.path.dirname(__file__) + '/icons/memo.png')
        self.memo = QAction(icon, "메모장", self.iface.mainWindow())
        self.memo.setObjectName('메모장')
        # self.searchAction.triggered.connect(self.notepad)
        self.memo.setCheckable(True)
        self.toolbar.addAction(self.memo)
        self.iface.addPluginToMenu("좌표도구", self.memo)
        self.dlgmemowidget.setToggleVisibilityAction(self.memo)
        # self.iface.registerMainWindowAction(self.searchAction,'F4')


        #===========================================================================================================================

        icon = QIcon(os.path.dirname(__file__) + '/icons/setting.png')
        self.set = QAction(icon, "좌표도구설정", self.iface.mainWindow())
        self.set.setObjectName('좌표도구설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')

        #===========================================================================================================================

        # Help
        icon = QIcon(os.path.dirname(__file__) + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        self.iface.addPluginToMenu('좌표도구', self.helpAction)



        today = datetime.date.today()
        yyyy = today.year
        if yyyy > 2023:
            QMessageBox.information(self.iface.mainWindow(), '플러그인 재설치' , '좌표도구 플러그인 업데이트(재설치)가 필요합니다.')  
            self.unload()


        # self.toggle()


    # 체크박스 상태 변경 시 호출될 슬롯 FS 화면 메칭 코드 아직 개발중
    def checkboxStateChanged(self, state):
        if state == 2:  # 체크됨
            self.iface.messageBar().pushMessage("체크박스", "옵션 1이 선택되었습니다.", level=5)
        else:  # 체크 해제됨
            self.iface.messageBar().pushMessage("체크박스", "옵션 1이 해제되었습니다.", level=5)


        pass
# 도움말===================================================================================================================================================================
    def help(self):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"  
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화========================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        # 메뉴삭제
        self.iface.removePluginMenu('좌표도구', self.Coordinatecapture)
        self.iface.removePluginMenu('좌표도구', self.ShowOnmap)
        self.iface.removePluginMenu('좌표도구', self.MediaCenter)
        self.iface.removePluginMenu('좌표도구', self.mapaddress)
        self.iface.removePluginMenu('좌표도구', self.search)
        self.iface.removePluginMenu('좌표도구', self.conversion)
        self.iface.removePluginMenu('좌표도구', self.path_search)
        self.iface.removePluginMenu('좌표도구', self.movemove)
        self.iface.removePluginMenu('좌표도구', self.copycopy)
        self.iface.removePluginMenu('좌표도구', self.shp)
        # self.iface.removePluginMenu('좌표도구', self.layermove)
        self.iface.removePluginMenu('좌표도구', self.geo)
        self.iface.removePluginMenu('좌표도구', self.set)
        self.iface.removePluginMenu('좌표도구', self.searchAction)
        self.iface.removePluginMenu('좌표도구', self.memo)
        self.iface.removePluginMenu('좌표도구', self.helpAction)

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        # self.iface.removeToolBarIcon(self.CoordinateSpeedFs)
        # self.iface.removeToolBarIcon(self.CoordinateCoconut)
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.conversion)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.shpfileopen)
        self.iface.removeToolBarIcon(self.besindex)
        self.iface.removeToolBarIcon(self.grsindex)
        self.iface.removeToolBarIcon(self.wgsindex)
        self.iface.removeToolBarIcon(self.parindex)
        self.iface.removeToolBarIcon(self.ctpshp)
        self.iface.removeToolBarIcon(self.sigshp)
        # self.iface.removeToolBarIcon(self.emdshp)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.memo)
        self.iface.removeToolBarIcon(self.set)
        self.iface.removeToolBarIcon(self.searchAction)
        try:
            del self.toolbar
        except:
            pass

        # 필드계산기 표현식 삭제
        UnloadLatLonFunctions()
        
        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgconversionwidget)
        self.dlgconversionwidget = None
        self.dlgconversion = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None

        self.iface.mainWindow().removeDockWidget(self.dlgmemowidget)
        self.dlgmemowidget = None
        self.dlgmemo = None

        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        # self.iface.unregisterMainWindowAction(self.CoordinateSpeedFs)
        # self.iface.unregisterMainWindowAction(self.CoordinateCoconut)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.shpfileopen)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.conversion)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.searchAction)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        # 화면 정리
        try:
            self.Delete_Marker()
            self.dlgPathSearch.delete()
            self.dlgSearch.RemoveAll()
        except:
            pass

# 레이어 선택 토글 함수 =====================================================================================================================================================
    # def toggle(self):
    #     layer = self.canvas.currentLayer()
    #     if layer :
    #         try:
    #             layer.editingStarted.disconnect(self.toggle)
    #         except:
    #             pass
    #         try:
    #             layer.editingStopped.disconnect(self.toggle)
    #         except:
    #             pass

    #         enabled_flag = True

    #         if layer and layer.type() == layer.VectorLayer:
    #             self.searchAction.setEnabled(True)
    #         else:
    #             self.searchAction.setEnabled(False)

    #         enabled_flag = True
    #     else:
    #         self.searchAction.setEnabled(False)
    #         enabled_flag = False

    #     self.Coordinatecapture.setEnabled(enabled_flag)
    #     # self.CoordinateSpeedFs.setEnabled(enabled_flag)
    #     # self.CoordinateCoconut.setEnabled(enabled_flag)
    #     self.MediaCenter.setEnabled(enabled_flag)
    #     self.movemap1.setEnabled(enabled_flag)
    #     self.movemap2.setEnabled(enabled_flag)
    #     self.movemap3.setEnabled(enabled_flag)
    #     self.ShowOnmap.setEnabled(enabled_flag)
    #     self.mapaddress.setEnabled(enabled_flag)
    #     self.search.setEnabled(enabled_flag)
    #     self.conversion.setEnabled(enabled_flag)
    #     self.path_search.setEnabled(enabled_flag)
    #     self.coordinateConverter.setEnabled(enabled_flag)
    #     self.coordinateGeometry.setEnabled(enabled_flag)

# 좌표 캡쳐 실행==============================================================================================================================================================
    def capture(self):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행=============================================================================================================================================================
    def mediaCenter(self):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionPan().trigger() 

# 좌표 이동 실행===============================================================================================================================================================
    def mapMove(self, idx, movemap):
        clipText = self.clipboard.text().strip()
        SeqOrder=int(self.QSettings.value('coordinate_tool/ComboBox' + str(idx+2), 0))
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('coordinate_tool/Project' + str(idx+2),'USER:100000'))
        try:
            lon, lat = self.Funtion.setval(setCRS,clipText) # 복사된 좌표 X, Y 좌표 변환
            self.movemap.setDefaultAction(movemap)
            self.Funtion.moveto(setCRS, lon, lat, SeqOrder)
            self.canvas.refresh()
            self.iface.actionPan().trigger()
        except:
            pass

# 웹지도 실행==================================================================================================================================================================
    def ShowOn(self):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            self.iface.actionPan().trigger()
            
# 주소 캡쳐 실행================================================================================================================================================================
    def address(self):
        # 마커 표시 삭제
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionPan().trigger()
        
# 검색창 실행===================================================================================================================================================================
    def searchtool(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgSearchwidget.show()
      
# 좌표변환정보 실행==============================================================================================================================================================
    def conversionwidget(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgconversionwidget.show()
        
# 경로탐색 실행 =================================================================================================================================================================
    def PathSearchwidget(self):
        # 마커 표시 삭제
        self.Delete()
        self.dlgPathSearchwidget.show()
        
# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================
    def Geometrywidget(self):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        self.Geometry.show() 

# 쉐입인덱스 불러오기 ============================================================================================================================================================
    def shpIndex(self, idx, Action, cmtName, fileName, leLabefield, symbolfield, lineWidth):
        self.Delete()
        self.indexshp.setDefaultAction(Action)
        layers = QgsProject.instance().mapLayersByName(cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
            # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
        else:
             # 인덱스 레이어가 없다면 레이어 추가
            filepath = str('/shp/' + fileName)
            layer = QgsVectorLayer(os.path.dirname(__file__) + filepath, cmtName, "ogr")
            QgsProject.instance().addMapLayer(layer)
        
            self.setsymbol(layer,leLabefield, symbolfield, lineWidth)
            layer.triggerRepaint()   

# 심볼 설정 =================================================================================================================================================================  
    def setsymbol(self,layer,leLabefield, symbolfield, lineWidth): 

        fni = layer.dataProvider().fields().indexFromName(symbolfield)
        unique_values = layer.uniqueValues(fni)

        # fill categories
        categories = []
        for unique_value in unique_values:
            # initialize the default symbol for this geometry type
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())

            # configure a symbol layer
            layer_style = {}
            # layer_style['joinstyle'] = 'bevel'
            layer_style['style'] = 'no'
            layer_style['color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_width'] = lineWidth
            symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)

            # replace default symbol layer with the configured one
            if symbol_layer is not None:
                symbol.changeSymbolLayer(0, symbol_layer)

            # create renderer object
            category = QgsRendererCategory(unique_value, symbol, str(unique_value))
            # entry for the list of category items
            categories.append(category)

        # create renderer object
        renderer = QgsCategorizedSymbolRenderer(symbolfield, categories)

        # assign the created renderer to the layer
        if renderer is not None:
            layer.setRenderer(renderer)

        layer.triggerRepaint()

        #라벨 스타일 설정
        layer_settings  = QgsPalLayerSettings()

        text_format = QgsTextFormat() # 텍스트 포멧 정의
        text_format.setFont(QFont("맑은 고딕")) # 폰트
        text_format.setSize(9) # 크기
        # text_format.setColor(QColor(255, 0, 255, 255)) # 컬러
        
        # 폰트 버퍼 설정
        # buffer_settings = QgsTextBufferSettings()
        # buffer_settings.setEnabled(True) # 버퍼 활성화
        # buffer_settings.setSize(1) # 버퍼 사이즈
        # buffer_settings.setColor(QColor("white")) # 버퍼 컬러
        # text_format.setBuffer(buffer_settings) # 폰트에 버퍼 셋팅
        
        layer_settings.setFormat(text_format) #라벨 스타일에 폰트 셋팅

        layer_settings.fieldName = leLabefield
        # layer_settings.placement = 2
        
        layer_settings.enabled = True
    
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        # 스타일 새로고침
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        # 단일 심볼 스타일 설정
        # 심볼설정
        # soldcol = QColor(0, 0, 0, 0) # 채우기색
        # linecol = QColor(103, 153, 141, 255) # 테두리색 R / G / B / 투명도
        # linecol = QColor(random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256), 255) # 테두리색 R / G / B / 투명도
        # lineWidth = 0.3 # 테두리 너비
        # layer.renderer().symbol().setColor(soldcol) # 채우기색
        # layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 (R , G , B , 투명도) QColor(255, 0, 255, 255)
        # layer.renderer().symbol().symbolLayer(0).setStrokeWidth(lineWidth) # 테두리 너비
        # layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine

# 파일열기 =======================================================================================================================================================================
    def fileopen(self):
        self.indexshp.setDefaultAction(self.shpfileopen)
        self.Delete()
        self.shpBookmark.getOpenFile()

# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self):
        self.indexshp.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()

# 검색 실행=====================================================================================================================================================================
    def showSearchDialog(self):
        if self.searchDialog is None:
            # All the work is done in the LayerSearchDialog
            self.searchDialog = LayerSearchDialog(self.iface, self.iface.mainWindow())
        self.searchDialog.show()

# 설정창 실행===================================================================================================================================================================
    def setting(self):
        self.Delete()
        self.dlg.show()

# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self,t):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시======================================================================================================================================================================
    def Draw_Marker(self,point,idx):
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)

        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()

# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None
        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)

    def Settingsdelete(self): 
        self.QSettings.remove('/locale/coordinate_tool')
        self.QSettings.setValue('coordinate_tool/REST_API_KEY', '')
        self.QSettings.setValue('coordinate_tool/client_id', '')
        self.QSettings.setValue('coordinate_tool/client_secret', '')
        self.QSettings.setValue('coordinate_tool/Vworld_APIkey', '')
        self.QSettings.setValue('coordinate_tool/Juso_APIkey', '')
        self.QSettings.setValue('coordinate_tool/Juso_APIkey_2', '')
        self.QSettings.setValue('coordinate_tool/google_apiKey','')