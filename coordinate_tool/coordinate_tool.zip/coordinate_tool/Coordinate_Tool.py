'''
***************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

***************************************************************************

* 2022.05.14 - 최초개발시작 
* 2022.05.16 - 좌표이동(개별툴)
* 2022.05.18 - 좌표복사(개별툴)
* 2022.07.06 - 좌표복사, 이동 개별툴에서 하나로 통합
* 2022.07.25 - API이용한 주소보기 및 이동 추가(카카오,네이버,브이월드)
             - 복사 및 이동 좌표계 설정가능하도록 수정
             - 웹지도 열기 추가(다음,네이버)
             - 도엽이동 및 경위도 이동 추가
             - 좌표정보 보기 기능 추가
* 2022.09.22 - 키워드 검색 기능 추가(카카오, Ruoto)
             - 주변POI검색기능 추가(Ruoto)
* 2022.10.13 - 경로탑색기능 추가 Ruoto
* 2022.11.07 - 경로탑색기능 추가 네이버
             - SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 2022.11.12 - 좌표변환 기능 추가
             - 필드계산기 함수 추가
             - MMS좌표복사 기능 추가
             - 도형계산기 기능 추가
* 2023.01.30 - speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가
* 2023.02.05 - pip module "pyautogui" 설치 기능 추가
             - 경로탐색 검색기능 개선(카카오 추가), 경로탐색 속도 개선
* 2023.02.07 - pip module 자동 설치 추가
* 2023.02.10 - Coconut 이동 시 Bessel 및 GRS 선택 기능 추가 - 삭제 2024.12.17
* 2023.02.20 - 구글 경로 탐색 기능 개선 (경유지 검색 개선, 구글 탭 추가, 폴리라인 표출 최적화)
* 2023.03.09 - 구글 좌표 주변 검색 기능 추가 및 웹지도 열기 코드 개선
* 2023.03.12 - 경로 탐색 개선
* 2023.09.02 - 검색기능 추가, 협력사 인덱스 추가, 도움말 링크 추가(플러그인 메뉴얼)
* 2023.09.10 - 대권역 속성값 수정, API Key 암호화, 중복 코드 수정
* 2023.09.11 - 행정계 SHP 교체 (군위군 대구광역시 편입)
* 2023.09.17 - 메모장 패널 추가
* 2023.09.18 - 좌표도구 메뉴바 수정
* 2023.09.19 - 메모장 패널 수정(위치 이동, 탭제목 수정기능 추가)
* 2023.09.20 - 웹지도(로드뷰) 방향 설정 추가
* 2023.09.25 - 검색 및 이동 패널 분리, 좌표 복사 시 마우스 위치 정보 표시 기능 추가
* 2023.10.12 - 보간점 표시, 링크 각도 표시 기능 추가 
* 2023.10.12 - 선택한 객체 레이어 복사 기능 추가 
* 2023.10.22 - 링크 각도 표시 기능의 멀티파트 오류 수정
* 2023.11.22 - 속성필터 기능 추가
* 2023.11.26 - 속성 필터 통계값 표시 기능 추가
* 2023.12.01 - 속성 필터 위젯을 도킹 패널 형태로 개선
* 2023.12.10 - 속성 필터에서 통계 패널을 분리 및 필터 속성값 조정
* 2024.01.02 - 인증키 수정
* 2024.01.28 - 좌표변화기, 도형계산기 프로그래스바 추가
* 2024.02.28 - Ruoto 경로 탐색 오류 수정 (경유지 탐색 기능 개선 예정) - 개선 완료 2025.01.16
* 2024.03.06 - 구글스트릿뷰 수정, 속성필터 수정
* 2024.03.29 - 주변POI 카테고리 검색 추가
* 2024.04.14 - 현재위치 검색 추가
* 2024.05.23 - Vworld API key 수정
* 2024.06.03 - 필드계산기 함수 수정
* 2024.06.05 - 카카오, 루토 검색 코드 수정
* 2024.06.18 - 인덱스SHP 가상레이어 가져오기로 수정
* 2024.06.18 - 인덱스SHP 스타일 수정
* 2024.07.11 - MDB To SHP 플러그인 추가
* 2024.10.09 - 보간점 표시 심볼 수정
* 2024.10.12 - 설정 값이 레지스트리에 저장되도록 개선, API 인증키 수정
* 2024.10.15 - 좌표변환기 코드 수정
* 2024.10.16 - 도형계산기 코드 수정
* 2024.10.30 - 선택 레이어 병합 추가
* 2024.11.02 - 선택 레이어 파일 경로 열기 기능 추가 및 SHP 파일 다운로드 방식 개선
* 2024.12.07 - 좌표복사, 메모장, 좌표변환기, 도형계산기 일부 코드 수정
* 2024.12.11 - MDB To SHP UI 변경 및 코드 수정
* 2024.12.15 - 각도 표시 코드 수정 및 라벨 설정 추가
* 2024.12.17 - MacOS 설치 오류 수정 및 Coconut 좌표 이동 기능 최적화
* 2024.12.30 - 선택 객체 복사 시 동일 스타일 유지 기능 추가
* 2025.01.16 - 루토 경유지 경탐 수정
* 2025.01.20 - xyz 타일맵 불러오기 추가 경로:[ 설정 -> 플러그인 설정 -> 타일맵 추가 클릭 ]
             - QGIS 설정 초기화 추가
* 2025.02.14 - 선택 객체 복사 시 객체만 복사 또는 레이어 스타일까지 복사 여부 선택 가능
* 2025.02.17 - 툴박스 알고리즘 추가
             - Qfield Log레이어 생성, 경로의 하위 폴더 리스트 추출
* 2025.02.27 - MDB To SHP 다중 파일 일괄 추출 기능 추가
* 2025.04.12 - 화면 이동 히스토리 저장 추가
* 2025.05.08 - Qfield Log레이어 생성 코드 수정
* 2025.05.11 - 툴박스 알고리즘 추가 - 유도선 변경 추출
* 2025.05.13 - 툴박스 알고리즘 추가 - WKT 변환기("wkt_geom"필드 활용)
* 2025.05.15 - 툴박스 알고리즘 추가 - 조사등록shp 병합
* 2025.05.16 - 툴박스 알고리즘 추가 - Qfield 조사링크 추출
* 2025.05.22 - 툴박스 알고리즘 추가 - Qfield 전기차 실사건
* 2025.05.27 - 메모장 백업 기능 추가(현재 탭의 내용 깃허브 메모장에 저장 및 가져오기)
* 2025.06.08 - 툴박스 알고리즘 추가 - SHP 파일 저장 및 ZIP 압축
* 2025.06.13 - 툴박스 알고리즘 추가 - 조사등록shp 병합 코드 수정
* 2025.06.24 - 툴박스 알고리즘 추가 - GPS로그 궤적 보정 추가
* 2025-06-29 - 속성통계 코드 수정(버전3.40 이상에서 오류 수정)
             - 툴박스 알고리즘 추가 - 키로 속성 결합(VLOOKUP)
* 2025-07-02 - 키값 생성 코드 추가(레이어 우클릭 메뉴)
		     - 레이어(전체)복사 기능 추가(레이어 우클릭 메뉴)
		     - 툴박스 알고리즘 수정 - SHP 파일 저장 및 ZIP 압축 코드 수정 (BES, GRS 단계 분리)
* 2025-07-06 - 범주 별 통계 기능 추가
             - 검색 패널 코드 수정
             - 도형계산기, 좌표변환기 처리 속도 개선
* 2025-07-10 - 네이버 거리뷰 차단으로 수정함
             - GPS로그 궤적 보정 코드 수정 및 오류 수정
* 2025-07-28 - 객체선택 히스토리 저장 추가
             - 네이버 거리뷰 위치 이격 수정
* 2025-08-01 - 시도, 시군구 행정계 SHP 수정
             - Vworld API key 수정
             - 메모장 백업 기능 제외
* 2025-08-08 - 루토 API key 수정
             - 우클릭 메뉴 신규 추가 (설정 > 플러그인 설정 > 우클릭 메뉴)
* 2025-08-14 - 좌표변환기 코드 수정
* 2025-08-22 - 도형계산기 코드 수정
* 2025-08-28 - SpeedFs, coconut 바로가기 추가
             - MDB To SHP 좌표값 X, Y 오류 수정
* 2025-09-25 - NAVER MAPS API 유료화로 관련된 코드 수정
* 2025-10-14 - 툴박스 알고리즘 수정 - 유도선 변경 추출:  예외항목-미구축대상 추가
* 2025-11-28 - 툴박스 알고리즘 수정 - 폴더 내 SHP파일 수집: 자동 증가 필드 추가
             - 도형계산기 코드수정
             - 루토 경탐 코드 수정
* 2025-12-11 - MDB To SHP 코드 수정
* 2025-12-24 - 등급분류(경계선 찾기) 기능 추가
* 2026-01-12 - 일부 코드 수정
* 2026-03-13 - 인덱스 권역, 협력사 수정
* 2026-03-25 - 26년 권역을 기본인덱스로 설정하고 25년 인덱스도 볼러올수있도록 추가(3~4개월내 삭제 예정)

***************************************************************************
'''

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsApplication,
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling,
                       QgsSymbol,
                       QgsSimpleFillSymbolLayer,
                       QgsRendererCategory,
                       QgsCategorizedSymbolRenderer,
                       QgsMapLayer,
                       QgsMarkerSymbol,
                       QgsCoordinateTransform,
                       QgsTextAnnotation,
                       QgsFeatureRequest,
                       QgsExpressionContextUtils,
                       QgsExpressionContext,
                       Qgis,
                       QgsFields,QgsPointXY,
                       QgsMapLayerType,
                       QgsExpression,
                       QgsField)

from qgis.PyQt.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF,
                          QVariant)

from qgis.gui import (QgsDockWidget,
                      QgsRubberBand,
                      QgsVertexMarker,
                      QgsMapCanvasAnnotationItem)

from qgis.PyQt.QtGui import (QColor,
                            QCursor,
                            QIcon,
                            QFont,
                            QTextDocument)

from qgis.PyQt.QtWidgets import (QMenu,
                                QApplication,
                                QDialogButtonBox,
                                QAction,QFrame,
                                QToolButton,
                                QMessageBox)

from qgis.utils import unloadPlugin, loadPlugin, startPlugin

from . import Coordinate_Tool_data
from .Coordinate_Tool_FieldCalculator import InitLatLonFunctions, UnloadLatLonFunctions
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Move import CoordinateToolMove
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_info import CoordinateToolinfo
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Function import Coordinate_function
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converter import CoordinateToolConverter
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_Memo import CoordinateToolMemo
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
# from .Coordinate_Tool_Searchlayer import LayerSearchDialog
from .Coordinate_Tool_Simple_filter import simple_filterDialog
from .Coordinate_Tool_Statistics import StatisticsDialog
from .Coordinate_Tool_fieldStatistics import fieldStatisticsDialog
from .Coordinate_Tool_Jenks import JenksDialog

from .Coordinate_Tool_mdbToShp import CoordinateToolmdbToShp
from .Coordinate_Tool_Algorithm import Coordinate_Tool_Algorithm
from .Coordinate_Tool_Keyfield import CoordinateToolKeyfield

import os, sys, os.path, requests, webbrowser, random, datetime, time, math, subprocess, zipfile, processing, shutil, platform

full_version = Qgis.QGIS_VERSION
QGIS_VERSION = f"QGIS {full_version.split('-')[0]}"  # '3.40.6'
python_path = f"C:/Program Files/{QGIS_VERSION}/bin/python.exe"
try:
    import pyperclip
except:
    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'pyperclip'])
    else:
        subprocess.check_call(['python','-m', 'pip', 'install', 'pyperclip'])
    import pyperclip

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

class CoordinateTool:
    def __init__(self, iface):
        self.iface      = iface
        self.canvas     = iface.mapCanvas()
        self.crossRb    = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard  = QApplication.clipboard()

    # 좌표도구 툴바 설정
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')
        self.toolbar.setToolTip('좌표도구 툴바')

    # 영역 툴바 설정정
        self.zoom_toolbar = self.iface.addToolBar('영역이동 툴바')
        self.zoom_toolbar.setObjectName('Coordinate_Tool_zoom_toolbar')
        self.zoom_toolbar.setToolTip('영역이동 툴바')

    # 좌표도구 메뉴바 설정
        self.menu = QMenu( "좌표도구(&T)", self.iface.mainWindow().menuBar() )
        self.menu = QMenu(self.iface.mainWindow())
        self.menu.setObjectName("'Coordinate_Tool_menu")
        self.menu.setTitle("좌표도구 (&T)")

        self.copytoMMSmapTool   = None
        self.copytoSpeedFsTool  = None
        self.copytoCoconutTool  = None  
        self.MediaCenterTool    = None
        self.ShowOnMapTool      = None
        self.mapaddressTool     = None
        self.searchDialog       = None
        self.simplefilterDialog = None
        self.Converter          = None
        self.Geometry           = None

        self.Markers            = []
        self.MarkerSymbol       = []
        self.AngleSymbol        = []

        self.vertex_run_chk     = False
        self.angle_run_chk      = False
        self.chk = True
        self.Delete_Marker_timer = QTimer()

        # 플러그인 로컬 경로
        self.plugin_dir = os.path.dirname(__file__)
        # 플러그인 설정
        self.Plugin='coordinate_tool'
        # 변수값 저장 설정
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        # 함수
        self.Function = Coordinate_function(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 이동
        self.indexMove = CoordinateToolMove(self, self.iface, self.iface.mainWindow())
        # mdb쉐입생성
        self.mdbToShp = CoordinateToolmdbToShp(self.iface, self.iface.mainWindow())
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        # 키필드 생성
        self.addKey = CoordinateToolKeyfield(self, self.iface, self.iface.mainWindow())

        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()
        
        # 좌표변환창 위젯 설정
        self.dlgconversion = CoordinateToolinfo(self,self.iface)
        self.dlgconversionwidget = QgsDockWidget("좌표정보" , self.iface.mainWindow() )
        self.dlgconversionwidget.setObjectName("좌표정보")
        self.dlgconversionwidget.setWidget(self.dlgconversion)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgconversionwidget )
        self.dlgconversionwidget.hide()
        
        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        # 메모장 위젯 설정
        self.dlgmemo = CoordinateToolMemo(self,self.iface)
        self.dlgmemowidget = QgsDockWidget("메모장" , self.iface.mainWindow() )
        self.dlgmemowidget.setObjectName("메모장")
        self.dlgmemowidget.setWidget(self.dlgmemo)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgmemowidget )
        self.dlgmemowidget.hide()

        # 필터 위젯 설정
        self.simplefilter = simple_filterDialog(self,self.iface)
        self.simplefilterwidget = QgsDockWidget("속성필터" , self.iface.mainWindow() )
        self.simplefilterwidget.setObjectName("속성필터")
        self.simplefilterwidget.setWidget(self.simplefilter)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.simplefilterwidget )
        self.simplefilterwidget.hide()

        # 통계 위젯 설정
        self.Statistics = StatisticsDialog(self,self.iface)
        self.Statisticswidget = QgsDockWidget("속성통계" , self.iface.mainWindow() )
        self.Statisticswidget.setObjectName("속성통계")
        self.Statisticswidget.setWidget(self.Statistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Statisticswidget )
        self.Statisticswidget.hide()

        # 범주 별 통계 위젯 설정
        self.fieldStatistics = fieldStatisticsDialog(self,self.iface)
        self.fieldStatistics_Widget = QgsDockWidget("범주 별 통계" , self.iface.mainWindow() )
        self.fieldStatistics_Widget.setObjectName("범주 별 통계")
        self.fieldStatistics_Widget.setWidget(self.fieldStatistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.fieldStatistics_Widget )
        self.fieldStatistics_Widget.hide()

        # 범주 별 통계 위젯 설정
        self.Jenks = JenksDialog(self,self.iface)
        self.Jenks_Widget = QgsDockWidget("등급 분류" , self.iface.mainWindow() )
        self.Jenks_Widget.setObjectName("등급 분류")
        self.Jenks_Widget.setWidget(self.Jenks)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Jenks_Widget )
        self.Jenks_Widget.hide()


        self.provider = Coordinate_Tool_Algorithm()

        # 영역 히스토리 리스트
        self.history = None
        self.history = []
        self._block = False  # 자동 루프 방지

        # ✅ 초기 상태 저장
        initial_extent = self.canvas.extent()
        initial_crs = self.canvas.mapSettings().destinationCrs()
        self.history.append((initial_extent, initial_crs))
        self.current_index = -1

        self.canvas.extentsChanged.connect(self.on_extent_changed)

        self.select_history = None
        self.select_history = []    # (layer, fids) 튜플을 담을 리스트
        self.select_index = -1      # 현재 히스토리 인덱스
        self._block1 = False        # re_select 수행 시 select_toggle 진입 방지 플래그
        # self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.select_toggle)

        self.setup_context_menu()

    # # 1. 활성 레이어가 변경될 때를 감시
    #     self.iface.layerTreeView().currentLayerChanged.connect(self.on_layer_changed)
        
    #     # 초기 실행 시 현재 레이어 연결
    #     self.current_connected_layer = None
    #     self.on_layer_changed(self.iface.activeLayer())


    # def on_layer_changed(self, layer):
    #     """활성 레이어가 바뀌면, 이전 레이어의 연결을 끊고 새 레이어에 연결"""
    #     # 이전 레이어 연결 해제 (중복 기록 방지)
    #     if self.current_connected_layer:
    #         try:
    #             self.current_connected_layer.selectionChanged.disconnect(self.select_toggle_wrapper)
    #         except:
    #             pass

    #     # 새 레이어 연결
    #     if layer and isinstance(layer, QgsVectorLayer):
    #         self.current_connected_layer = layer
    #         # 람다나 래퍼를 써서 layer 인자를 함께 넘겨줍니다.
    #         layer.selectionChanged.connect(lambda fids_ids, removed, cleared: self.select_toggle(layer))

    def setup_context_menu(self):
        try:
            self.canvas.contextMenuAboutToShow.connect(self.show_context_menu, type=Qt.UniqueConnection)
        except Exception as e:
            print('show_context_menu Error: ' + e)
            pass
        
    def show_context_menu(self, menu, point):
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, (QgsVectorLayer, QgsRasterLayer)):
            return

        menuchk = False
        # QgsMapTool에 정의된 메서드 사용
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(point.x(), point.y())
        menu.setToolTipsVisible(True)
        menu.addSeparator()

        if self.dlg.checkBox_Capture.checkState() == 2:
            point_capture = QMenu("좌표복사", menu)
            icon = QIcon(self.plugin_dir + '/icons/capture.png')
            point_capture.menuAction().setIcon(icon)
            menu.addMenu(point_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture = QAction("Bessel (FS)", self.iface.mainWindow())
            # bes_capture.setStatusTip("EPSG:4162 (Bessel)")
            bes_capture. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4162, 'Bessel_Fs'))
            point_capture.addAction(bes_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture_MMS = QAction("Bessel (MMS)", self.iface.mainWindow())
            bes_capture_MMS. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4162, 'Bessel_MMS'))
            point_capture.addAction(bes_capture_MMS)

            point_capture.addSeparator()

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture = QAction("GRS (FS)", self.iface.mainWindow())
            grs_capture. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4326, 'GRS_Fs'))
            point_capture.addAction(grs_capture)

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture_MMS = QAction("GRS (MMS)", self.iface.mainWindow())
            grs_capture_MMS. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4326, 'GRS_MMS'))
            point_capture.addAction(grs_capture_MMS)
            menuchk = True

        if self.dlg.checkBox_RoadView.checkState() == 2:
            # ShowOnMap = QMenu("로드뷰", menu)
            # icon = QIcon(self.plugin_dir + '/icons/roadview.png')
            # ShowOnMap.menuAction().setIcon(icon)
            # menu.addMenu(ShowOnMap)

            icon = QIcon(self.plugin_dir + '/icons/naver.png')
            naver_map = QAction(icon, "NAVER_거리뷰", self.iface.mainWindow())
            naver_map. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4326, 'NAVER'))
            # ShowOnMap.addAction(naver_map)
            menu.addAction(naver_map)

            icon = QIcon(self.plugin_dir + '/icons/kakao.png')
            kakao_map = QAction(icon, "KAKAO_로드뷰", self.iface.mainWindow())
            kakao_map. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4326, 'KAKAO'))
            # ShowOnMap.addAction(kakao_map)
            menu.addAction(kakao_map)
            menu.addSeparator()
            menuchk = True
        if self.dlg.checkBox_address.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
            address_action = QAction(icon, "주소 보기", self.iface.mainWindow())
            address_action. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4326, 'address'))
            menu.addAction(address_action)
            menuchk = True
        if self.dlg.checkBox_SpeedFS.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/fs.png')
            fs_action = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
            fs_action. triggered. connect(lambda : self.rClick_capture(map_pt, epsg4162, 'SpeedFS'))
            menu.addAction(fs_action)
            menuchk = True
        if self.dlg.checkBox_Zoom.checkState() == 2:
            menu.addSeparator()
            icon = QIcon(self.plugin_dir + '/icons/move1.png')
            map_action1 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project3','USER:100000')).description()})", self.iface.mainWindow())
            map_action1. triggered. connect(lambda : self.mapMove(1,self.movemap1))
            menu.addAction(map_action1)

            icon = QIcon(self.plugin_dir + '/icons/move2.png')
            map_action2 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project4','USER:100001')).description()})", self.iface.mainWindow())
            map_action2. triggered. connect(lambda : self.mapMove(2,self.movemap2))
            menu.addAction(map_action2)

            icon = QIcon(self.plugin_dir + '/icons/move3.png')
            map_action3 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project5','USER:100001')).description()})", self.iface.mainWindow())
            map_action3. triggered. connect(lambda : self.mapMove(3,self.movemap3))
            menu.addAction(map_action3)
            menuchk = True

        if menuchk:
            TARGETS = {"좌표 복사"}
            # 1) 기본 메뉴 중 "좌표 복사" 액션 제거
            for act in list(menu.actions()):
                sub = act.menu()                      # 서브메뉴면 QMenu, 아니면 None
                title = (sub.title() if sub else act.text() or "").replace("&", "")
                if title in TARGETS:
                    menu.removeAction(act)

    def chk_timer(self):
        self.chk = True

    def rClick_capture(self, map_pt, crs, msg):
        if self.copytoMMSmapTool is None:
            self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
        if self.ShowOnMapTool is None:
            self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
        clipboard_point = None
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        # 좌표값 분리
        Lon = format(map_pt[0])
        Lat = format(map_pt[1])
        # 좌표 변환
        transform   = QgsCoordinateTransform(canvasCRS, crs, QgsProject.instance())
        trans_point = transform.transform(float(Lon), float(Lat))
        point_fs    = self.Function.fscoordinate(trans_point)

        if msg == 'Bessel_Fs' or msg == 'GRS_Fs':
            # 좌표 클립보드 저장
            self.clipboard.setText(point_fs)
            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs
            self.Draw_Marker(map_pt, 1)

        elif msg == 'Bessel_MMS' or msg == 'GRS_MMS':
            fsLon = round(float(trans_point[0]*360000),3)
            fsLat = round(float(trans_point[1]*360000),3)
            fsmms = '('+str(fsLon)+','+str(fsLat)+')'

            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + fsmms
            msg = f"{msg} copied to the clipboard"
            clipboard_point = fsmms
            self.Draw_Marker(map_pt, 1)

        elif msg == 'SpeedFS':
            msg = None
            if self.chk:
                fsLon = float(trans_point[0]*360000)
                fsLat = float(trans_point[1]*360000)
                fsmms = '('+str(fsLon)+','+str(fsLat)+')'
                pyperclip.copy(fsmms)
                msg = self.copytoMMSmapTool.SpeedFS(fsmms)

                self.chk = False
                self.timer = QTimer()
                # self.timer.setSingleShot(True)
                self.timer.start(1500)
                self.timer.timeout.connect(self.chk_timer)
                self.Draw_Marker(map_pt, 1)
                
            if msg is None:
                self.chk = True
                self.timer.setSingleShot(False)
                return

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'address':

            ctp, sig, roadaddress, jibunaddress = self.Function.Routojoso(trans_point)

            QMessageBox.information(self.iface.mainWindow(), 'Routo' , f'# 도로명주소\n{roadaddress}\n\n# 지번주소\n{jibunaddress}')

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + roadaddress
            msg = f"{msg} copied to the clipboard"
            clipboard_point = roadaddress
            self.Draw_Marker(map_pt, 1)

        elif msg == 'NAVER':
            na = Coordinate_Tool_data.MAP_PROVIDERS[0][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[0][1]

            to5179  = QgsCoordinateTransform(epsg4326, epsg5179, QgsProject.instance())
            toWGS84 = QgsCoordinateTransform(epsg5179, epsg4326, QgsProject.instance())

            pt_5179  = to5179.transform(trans_point)
            mapZoom = 18

            dx, dy = self.ShowOnMapTool.getshift(mapZoom)

            shifted_5179 = QgsPointXY(pt_5179.x() - dx, pt_5179.y() + dy)
            shifted_wgs84 = toWGS84.transform(shifted_5179)
            lon = shifted_wgs84.x()
            lat = shifted_wgs84.y()
            ms = ms.replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat)) # ms.replace('{id}'
            ms = ms.replace('{zoom}', str(mapZoom))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'KAKAO':
            na = Coordinate_Tool_data.MAP_PROVIDERS[6][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[6][1]
            lon, lat, id = self.ShowOnMapTool.kakaoURL(map_pt,canvasCRS)
            ms = ms.replace('{id}', str(id)).replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        self.clipboard.setText(clipboard_point)
        # 기존 메세지창 삭제
        self.iface.messageBar().clearWidgets()
        # 좌표복사 메세지 표출
        self.iface.messageBar().pushMessage(f"{msg}", level=Qgis.Info, duration=5)
        msg = None
        self.Delete_Marker_Shot(3000)

    def on_extent_changed(self):
        if self._block:
            return
        else:
            extent = self.canvas.extent()
            crs = self.canvas.mapSettings().destinationCrs()
            # 현재 인덱스 이후 히스토리는 삭제 (redo 불가능 상태)
            self.history = self.history[:self.current_index+1]
            self.history.append((extent, crs))
            self.current_index = len(self.history)-1
            self.update_buttons()

    # 영역 뒤로가기
    def go_back(self):
        if self.current_index > 0:
            self._block = True
            self.current_index -= 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()
    # 영역 앞으로가기
    def go_forward(self):
        if self.current_index < len(self.history) - 1:
            self._block = True
            self.current_index += 1
            self.restore_extent(self.history[self.current_index])
            self._block = False
            self.update_buttons()

    def restore_extent(self, extent_crs_tuple):
        extent, saved_crs = extent_crs_tuple
        current_crs = self.canvas.mapSettings().destinationCrs()
        if saved_crs != current_crs:
            # 좌표계 변환
            transform = QgsCoordinateTransform(
                saved_crs,
                current_crs,
                QgsProject.instance().transformContext()
            )
            extent = transform.transformBoundingBox(extent)

        self.canvas.setExtent(extent)
        self.canvas.refresh()

    def update_buttons(self):
        if hasattr(self, 'action_back'):
            self.action_back.setEnabled(self.current_index > 0)
        if hasattr(self, 'action_forward'):
            self.action_forward.setEnabled(self.current_index < len(self.history) - 1)

    # def _selected_feature_point(self, layer):
    #     feat = next(layer.getSelectedFeatures(), None)
    #     if not feat:
    #         return None
    #     g = feat.geometry()
    #     if g.isEmpty():
    #         return None
    #     # 지오메트리 타입별 대표점 추출
    #     if layer.geometryType() == QgsWkbTypes.PointGeometry:
    #         if QgsWkbTypes.isMultiType(layer.wkbType()):
    #             pts = g.asMultiPoint()
    #             if not pts:
    #                 return None
    #             pt = pts[0]
    #         else:
    #             pt = g.asPoint()
    #     else:
    #         # 선/폴리곤은 내부 포인트(centroid 대신 pointOnSurface 권장)
    #         pt = g.pointOnSurface().asPoint()
    #     return pt


    def select_toggle(self, layer):
        if self._block1:
            return
        
        if not layer or layer.selectedFeatureCount() == 0:
            self.select_index = len(self.select_history)
            return
        
        layer_id = layer.id()
        fids = layer.selectedFeatureIds()

        # if self.Autofs.isChecked():
        #     # 1) 선택 피처의 대표 포인트 얻기
        #     pt = self._selected_feature_point(layer)
        #     if not pt:
        #         self.iface.messageBar().pushWarning('선택한 객체에서 좌표를 찾을 수 없습니다.')
        #         return
        #     # 2) 레이어 CRS → 캔버스 CRS로 변환 (rClick_capture가 캔버스 좌표를 받는 경우)
        #     canvas_crs = self.canvas.mapSettings().destinationCrs()
        #     tr_to_canvas = QgsCoordinateTransform(layer.crs(), canvas_crs, QgsProject.instance())
        #     map_pt = tr_to_canvas.transform(pt)
        #     self.rClick_capture(map_pt, epsg4162, 'SpeedFS')


        fids = layer.selectedFeatureIds()
        self.select_history = self.select_history[:self.select_index + 1]
        self.select_history.append((layer_id, fids))
        self.select_index = len(self.select_history)-1
        self.update_buttons1()
        
    def clean_select_history(self):
        """삭제된 레이어 기록을 제거하고 select_index 를 정상화."""
        project = QgsProject.instance()
        # 유효한(아직 로드된) 레코드만 남기기
        new_hist = [
            (lid, fids)
            for (lid, fids) in self.select_history
            if project.mapLayer(lid)
        ]
        self.select_history = new_hist

        if not new_hist:
            self.select_index = -1
        else:
            # 인덱스가 히스토리 길이를 초과하지 않도록
            self.select_index = min(self.select_index, len(new_hist) - 1)

        self.update_buttons1()

    def re_select(self, select_tuple):
        layer_id, fids = select_tuple
        project = QgsProject.instance()

        layer = project.mapLayer(layer_id)
        if not layer:
            # 레이어가 이미 삭제된 경우
            self.clean_select_history()
            return

        # 2) 원래 레이어의 모든 선택 해제
        layer.removeSelection()
        # 3) 기록된 ID로 재선택
        layer.selectByIds(fids)
        # 간단히: 선택된 피처로 바로 줌(레이어 CRS→캔버스 CRS 자동 처리)
        self.canvas.zoomToSelected(layer)
        self.canvas.refresh()

    def go_select_back(self):
        if self.select_index > 0:
            self._block1 = True
            self.select_index -= 1
            self.re_select(self.select_history[self.select_index])
            self._block1 = False
            self.update_buttons1()

    def go_select_forward(self):
        if self.select_index < len(self.select_history) - 1:
            self._block1 = True
            self.select_index += 1
            self.re_select(self.select_history[self.select_index])
            self._block1 = False
            self.update_buttons1()

    def update_buttons1(self):
        if hasattr(self, 'select_back'):
            self.select_back.setEnabled(self.select_index > 0)
        if hasattr(self, 'select_forward'):
            self.select_forward.setEnabled(self.select_index < len(self.select_history) - 1)
    
    def unload(self):
        unloadPlugin(self.Plugin)

    # def CanvasSelectionChanged(self):
    #     layer = self.canvas.currentLayer()
    #     if layer.selectedFeatureCount() > 1:
    #         self.canvas.xyCoordinates.disconnect()
    #     elif layer.selectedFeatureCount() == 0:
    #         self.canvas.xyCoordinates.connect(self.CanvasMoveConnect)

    # def CanvasMoveConnect(self, point):
    #     try:
    #         originalPoint = point
    #         canvasCRS = self.canvas.mapSettings().destinationCrs()
    #         transform = QgsCoordinateTransform(canvasCRS,epsg4162, QgsProject.instance())
    #         BESPoint = transform.transform(originalPoint)
    #         bes = self.Function.fscoordinate(BESPoint)
    #         # maid8Lv = self.Function.mapid_8Lv(BESPoint)
    #         map, company, team, ctp, sig = self.Function.mapidinfo(bes)
    #         self.iface.statusBarIface().showMessage("{} / {} / {} / {} / {} / {}".format(company, team, ctp, sig, map, bes))
    #     except:
    #         self.iface.statusBarIface().showMessage("canvasMoveEvent : Error")
        
    def current_map_point(self):
        # 1) 화면(글로벌) 좌표 → 2) 캔버스 좌표 → 3) 지도 좌표
        global_pt = QCursor.pos()
        canvas_pt = self.canvas.mapFromGlobal(global_pt)          # QPoint
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(
            canvas_pt.x(), canvas_pt.y()
        )
        return map_pt  # QgsPointXY

    def initGui(self):

        # 필드계산기 함수 추가
        InitLatLonFunctions()
        
        # # 메뉴바 생성
        # self.menu = '&좌표도구'

        QgsApplication.processingRegistry().addProvider(self.provider)
# ===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("복사")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('copymenu')

        # 좌표 복사
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)
        Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 

        # 미디어센터 좌표 이동
        icon = QIcon(self.plugin_dir + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 

        # 주소확인
        icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소보기", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소보기')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.copy.addAction(self.mapaddress)
        Menu.addAction(self.mapaddress)

        # 좌표 정보
        icon = QIcon(self.plugin_dir + '/icons/information.png')
        self.conversion = QAction(icon, "좌표정보", self.iface.mainWindow())
        self.conversion.setObjectName('좌표정보')
        self.conversion.triggered.connect(self.conversionwidget)
        self.conversion.setCheckable(True)
        self.copy.addAction(self.conversion)
        Menu.addAction(self.conversion)
        # self.iface.registerMainWindowAction(self.conversion,'Shift+I')
        self.dlgconversionwidget.setToggleVisibilityAction(self.conversion)

        icon = QIcon(self.plugin_dir + '/icons/fs.png')
        self.fs = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
        self.fs.setObjectName('SpeedFs_이동')
        self.fs.triggered.connect(lambda : self.rClick_capture(self.current_map_point(), epsg4162, 'SpeedFS'))
        # self.fs.setCheckable(True)
        # self.copy.addAction(self.fs)
        Menu.addAction(self.fs)
        self.iface.registerMainWindowAction(self.fs,'H')

        icon = QIcon(self.plugin_dir + '/icons/coconut.png')
        self.coconut = QAction(icon, "coconut_이동", self.iface.mainWindow())
        self.coconut.setObjectName('coconut_이동')
        self.coconut.triggered.connect(lambda : self.rClick_capture(self.current_map_point(), epsg4162, 'coconut'))
        # self.fs.setCheckable(True)
        # self.copy.addAction(self.coconut)
        Menu.addAction(self.coconut)
        self.iface.registerMainWindowAction(self.coconut,'Y')

        # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.copy)

        # 메뉴에 드롭다운 목록 추가
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.copycopy = QAction(icon, '좌표,주소,미디어센터', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)

        # 플러그인 메뉴에 추가
        # self.iface.addPluginToMenu("좌표도구" , self.copycopy)

        self.menu.addAction(self.copycopy)

#===============================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('movemenu')

    # 웹검색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/search.png')
        self.search = QAction(icon, "검색", self.iface.mainWindow())
        self.search.setObjectName('검색')
        self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.movemap.addAction(self.search)
        self.movemap.setDefaultAction(self.search)
        Menu.addAction(self.search)
        # self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)

    # 좌표이동 1
        icon = QIcon(self.plugin_dir + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(lambda : self.mapMove(1,self.movemap1))
        self.movemap.addAction(self.movemap1)
        # self.movemap.setDefaultAction(self.movemap1)
        Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        # self.movemap1.setEnabled(False)

    # 좌표이동 2
        icon = QIcon(self.plugin_dir + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(lambda : self.mapMove(2,self.movemap2))
        self.movemap.addAction(self.movemap2)
        Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        # self.movemap2.setEnabled(False)

    # 좌표이동 3
        icon = QIcon(self.plugin_dir + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(lambda : self.mapMove(3,self.movemap3))
        self.movemap.addAction(self.movemap3)
        Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        # self.movemap3.setEnabled(False)

    # 도엽, 주소, 경위도 이동
        icon = QIcon(self.plugin_dir + '/icons/indexMove.png')
        self.moveIndex = QAction(icon, "도엽이동", self.iface.mainWindow())
        self.moveIndex.setObjectName('도엽이동')
        # self.coordinateConverter.setCheckable(True)
        self.moveIndex.triggered.connect(self.Move)
        self.movemap.addAction(self.moveIndex)
        Menu.addAction(self.moveIndex)
        self.iface.registerMainWindowAction(self.moveIndex,'Alt+F')

    # 경로탐색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        self.path_search.triggered.connect(lambda : self.DefaultAction(self.movemap, self.path_search))
        self.path_search.setCheckable(True)
        self.movemap.addAction(self.path_search)
        Menu.addAction(self.path_search)
        # self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)

        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(self.plugin_dir + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)

        self.menu.addAction(self.movemove)

#===========================================================================================================================
    # 웹지도 열기
        icon = QIcon(self.plugin_dir + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        # self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        # self.ShowOnmap.setEnabled(False)
        self.menu.addAction(self.ShowOnmap)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.attribute = QToolButton(self.toolbar)
        self.attribute.setPopupMode(QToolButton.MenuButtonPopup)
        self.attribute.setObjectName("속성통계필터")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('속성통계필터')
        
    # 유일값통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics1.png')
        self.fieldUniqueStatistics = QAction(icon, "범주별통계", self.iface.mainWindow())
        self.fieldUniqueStatistics.setObjectName('범주별통계')
        self.fieldUniqueStatistics.triggered.connect(lambda : self.DefaultAction(self.attribute, self.fieldUniqueStatistics))
        self.fieldUniqueStatistics.setCheckable(True)
        self.attribute.addAction(self.fieldUniqueStatistics)
        self.attribute.setDefaultAction(self.fieldUniqueStatistics)
        self.fieldStatistics_Widget.setToggleVisibilityAction(self.fieldUniqueStatistics)
        Menu.addAction(self.fieldUniqueStatistics)

    # Jenks(자연구간) 경계값 찾기 등급분류
        icon = QIcon(self.plugin_dir + '/icons/Jenks.png')
        self.Jenksfind = QAction(icon, "등급분류", self.iface.mainWindow())
        self.Jenksfind.setObjectName('등급분류')
        self.Jenksfind.triggered.connect(lambda : self.DefaultAction(self.attribute, self.Jenksfind))
        self.Jenksfind.setCheckable(True)
        self.attribute.addAction(self.Jenksfind)
        self.Jenks_Widget.setToggleVisibilityAction(self.Jenksfind)
        Menu.addAction(self.Jenksfind)

    # 속성필터 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/filter.png')
        self.simple_filter = QAction(icon, "속성필터", self.iface.mainWindow())
        self.simple_filter.setObjectName('속성필터')
        self.simple_filter.triggered.connect(lambda : self.DefaultAction(self.attribute, self.simple_filter))
        self.simple_filter.setCheckable(True)
        self.attribute.addAction(self.simple_filter)
        self.simplefilterwidget.setToggleVisibilityAction(self.simple_filter)
        Menu.addAction(self.simple_filter)

    # 속성통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.selectStatistics = QAction(icon, "속성통계", self.iface.mainWindow())
        self.selectStatistics.setObjectName('속성통계')
        self.selectStatistics.triggered.connect(lambda : self.DefaultAction(self.attribute, self.selectStatistics))
        self.selectStatistics.setCheckable(True)
        self.attribute.addAction(self.selectStatistics)
        self.Statisticswidget.setToggleVisibilityAction(self.selectStatistics)
        Menu.addAction(self.selectStatistics)

        self.toolbar.addWidget( self.attribute)

        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.attr = QAction(icon, '속성통계필터', self.iface.mainWindow())
        self.attr.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.attr)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
    # 좌표변환 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        # self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        Menu.addAction(self.coordinateConverter)
        # self.coordinateConverter.setEnabled(False)

    # 도형계산 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        # self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        Menu.addAction(self.coordinateGeometry)
        # self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.geo)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.indexshp = QToolButton(self.toolbar)
        self.indexshp.setPopupMode(QToolButton.MenuButtonPopup)
        self.indexshp.setObjectName("쉐입파일")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('쉐입파일')

    # 베셀인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/besindex.png')
        self.besindex = QAction(icon, "BES인덱스", self.iface.mainWindow())
        self.besindex.setObjectName('BES인덱스')
        self.besindex.triggered.connect(lambda : self.shpIndex(1, self.besindex, "Bessel_Index", "Bessel_Index.shp",  "MAP_ID", "협력사", 0.3 ))
        self.indexshp.addAction(self.besindex)
        self.indexshp.setDefaultAction(self.besindex)
        Menu.addAction(self.besindex)

    # GRS인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/grsindex.png')
        self.grsindex = QAction(icon, "GRS인덱스", self.iface.mainWindow())
        self.grsindex.setObjectName('GRS인덱스')
        self.grsindex.triggered.connect(lambda : self.shpIndex(2, self.grsindex, "GRS_Index", "GRS_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex)
        Menu.addAction(self.grsindex)

    # WGS84인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/wgsindex.png')
        self.wgsindex = QAction(icon, "WGS인덱스", self.iface.mainWindow())
        self.wgsindex.setObjectName('WGS인덱스')
        self.wgsindex.triggered.connect(lambda : self.shpIndex(3, self.wgsindex, "WGS84_Index", "WGS84_Index.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex)
        Menu.addAction(self.wgsindex)

    # 협력사 구문 인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/partnerindex.png')
        self.parindex = QAction(icon, "협력사인덱스", self.iface.mainWindow())
        self.parindex.setObjectName('협력사인덱스')
        self.parindex.triggered.connect(lambda : self.shpIndex(4, self.parindex, "협력사_Index", "Partner_Index.shp","협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex)
        Menu.addAction(self.parindex)

    # 25베셀인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/besindex.png')
        self.besindex_25 = QAction(icon, "25_BES인덱스", self.iface.mainWindow())
        self.besindex_25.setObjectName('BES인덱스')
        self.besindex_25.triggered.connect(lambda : self.shpIndex(1, self.besindex_25, "Bessel_Index_25", "Bessel_Index_25.shp",  "MAP_ID", "협력사", 0.3 ))
        self.indexshp.addAction(self.besindex_25)
        self.indexshp.setDefaultAction(self.besindex_25)
        Menu.addAction(self.besindex_25)

    # 25GRS인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/grsindex.png')
        self.grsindex_25 = QAction(icon, "25_GRS인덱스", self.iface.mainWindow())
        self.grsindex_25.setObjectName('GRS인덱스')
        self.grsindex_25.triggered.connect(lambda : self.shpIndex(2, self.grsindex_25, "GRS_Index_25", "GRS_Index_25.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.grsindex_25)
        Menu.addAction(self.grsindex_25)

    # 25WGS84인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/wgsindex.png')
        self.wgsindex_25 = QAction(icon, "25_WGS인덱스", self.iface.mainWindow())
        self.wgsindex_25.setObjectName('WGS인덱스')
        self.wgsindex_25.triggered.connect(lambda : self.shpIndex(3, self.wgsindex_25, "WGS84_Index_25", "WGS84_Index_25.shp", "MAP_ID", "협력사", 0.3))
        self.indexshp.addAction(self.wgsindex_25)
        Menu.addAction(self.wgsindex_25)

    # 25협력사 구문 인덱스 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/partnerindex.png')
        self.parindex_25 = QAction(icon, "25_협력사인덱스", self.iface.mainWindow())
        self.parindex_25.setObjectName('협력사인덱스')
        self.parindex_25.triggered.connect(lambda : self.shpIndex(4, self.parindex_25, "협력사_Index_25", "Partner_Index_25.shp","협력사", "협력사", 0.6))
        self.indexshp.addAction(self.parindex_25)
        Menu.addAction(self.parindex_25)

    # 시도행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/ctp.png')
        self.ctpshp = QAction(icon, "시도행정계", self.iface.mainWindow())
        self.ctpshp.setObjectName('시도행정계')
        self.ctpshp.triggered.connect(lambda : self.shpIndex(5, self.ctpshp, "시도행정계", "ctp.shp", "CTP_KOR_NM", "CTP_KOR_NM", 0.6))
        self.indexshp.addAction(self.ctpshp)
        Menu.addAction(self.ctpshp)

    # 시군구행정계 쉐입 열기
        icon = QIcon(self.plugin_dir + '/icons/sig.png')
        self.sigshp = QAction(icon, "시군구행정계", self.iface.mainWindow())
        self.sigshp.setObjectName('시군구행정계')
        self.sigshp.triggered.connect(lambda : self.shpIndex(6, self.sigshp, "시군구행정계", "sig.shp", "SIG_KOR_NM", "CTP_KOR_NM", 0.3))
        self.indexshp.addAction(self.sigshp)
        Menu.addAction(self.sigshp)

    # 읍명동 행정계 쉐입 열기
        # icon = QIcon(self.plugin_dir + '/icons/emd.png')
        # self.emdshp = QAction(icon, "읍면동행정계", self.iface.mainWindow())
        # self.emdshp.setObjectName('읍면동행정계')
        # self.emdshp.triggered.connect(lambda : self.shpIndex(7))
        # self.indexshp.addAction(self.emdshp)
        # Menu.addAction(self.emdshp)

    # 파일열기 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.shpfileopen = QAction(icon, "파일열기", self.iface.mainWindow())
        self.shpfileopen.setObjectName('파일열기')
        self.shpfileopen.triggered.connect(self.fileopen)
        # self.shpfileopen.setCheckable(True)
        self.indexshp.addAction(self.shpfileopen)
        # self.indexshp.setDefaultAction(self.shpfileopen)
        Menu.addAction(self.shpfileopen)
        # self.iface.registerMainWindowAction(self.shpfileopen,'Shift+O')

    # 북마크 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self.indexshp.addAction(self.Bookmark)
        Menu.addAction(self.Bookmark)

        self.toolbar.addWidget( self.indexshp)
        
        icon = QIcon(self.plugin_dir + '/icons/shp.png')
        self.shp = QAction(icon, '쉐입파일', self.iface.mainWindow())
        self.shp.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.shp)

        self.menu.addAction(self.shp)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self._addin = QToolButton(self.toolbar)
        self._addin.setPopupMode(QToolButton.MenuButtonPopup)
        self._addin.setObjectName("추가기능")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('추가기능')

    # 메모 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/memo.png')
        self.memo = QAction(icon, "메모장", self.iface.mainWindow())
        self.memo.setObjectName('메모장')
        self.memo.triggered.connect(self.notepad)
        self.memo.setCheckable(True)
        self._addin.addAction(self.memo)
        self._addin.setDefaultAction(self.memo)
        # self.iface.addPluginToMenu("좌표도구", self.memo)
        self.dlgmemowidget.setToggleVisibilityAction(self.memo)
        # self.iface.registerMainWindowAction(self.memo,'F2')
        Menu.addAction(self.memo)

    # mdb to shp
        icon = QIcon(self.plugin_dir + '/icons/mdbToShp.png')
        self._mdbToShp = QAction(icon, "MDB쉐입생성", self.iface.mainWindow())
        self._mdbToShp.setObjectName('MDB쉐입생성')
        self._mdbToShp.triggered.connect(self.show_mdbToShp)
        self._addin.addAction(self._mdbToShp)
        # self.iface.registerMainWindowAction(self.searchAction,'F4')
        Menu.addAction(self._mdbToShp)

    # 속성검색 위젯 열기
        # icon = QIcon(self.plugin_dir + '/icons/searchLayers.png')
        # self.searchAction = QAction(icon, "속성검색", self.iface.mainWindow())
        # self.searchAction.setObjectName('속성검색')
        # self.searchAction.triggered.connect(self.showSearchDialog)
        # self._addin.addAction(self.searchAction)
        # # self.iface.registerMainWindowAction(self.searchAction,'F4')
        # self.shp2=Menu.addAction(self.searchAction)

        # 1. 메뉴 생성
        self.duplicate_menu = QMenu("선택객체복사", self.iface.mainWindow())
        self.duplicate_menu.setObjectName('선택객체복사메뉴')
        group_icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate_menu.menuAction().setIcon(group_icon)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate1.png')
        self.duplicate = QAction(icon, "선택객체복사(스타일X)", self.iface.mainWindow())
        self.duplicate.setObjectName('선택객체복사')
        self.duplicate.triggered.connect(lambda : self.duplicate_run(False))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicate, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicate)

    # 선택객체복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate1 = QAction(icon, "선택객체복사(스타일O)", self.iface.mainWindow())
        self.duplicate1.setObjectName('선택객체복사')
        self.duplicate1.triggered.connect(lambda : self.duplicate_run(True))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicate1, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicate1)

        # 3. 하위 액션을 메뉴에 추가
        self.duplicate_menu.addAction(self.duplicate)
        self.duplicate_menu.addAction(self.duplicate1)

        self.duplicate_action = self.duplicate_menu.menuAction()  # QAction 획득
        # 4. 생성한 메뉴를 레이어 우클릭 메뉴에 추가
        self.iface.addCustomActionForLayerType(self.duplicate_action, None, QgsMapLayer.VectorLayer, True)

        # 1. 메뉴 생성
        self.duplicateAll_menu = QMenu("레이어복사", self.iface.mainWindow())
        self.duplicateAll_menu.setObjectName('레이어복사메뉴')
        group_icon = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll_menu.menuAction().setIcon(group_icon)
    # 레이어전체 복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicateALL1.png')
        self.duplicateAll = QAction(icon, "레이어복사(스타일X)", self.iface.mainWindow())
        self.duplicateAll.setObjectName('레이어복사')
        self.duplicateAll.triggered.connect(lambda : self.duplicate_run(False, 1))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicateAll, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicateAll)

    # 레이어전체 복사 실행
        icon = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll1 = QAction(icon, "레이어복사(스타일O)", self.iface.mainWindow())
        self.duplicateAll1.setObjectName('레이어복사')
        self.duplicateAll1.triggered.connect(lambda : self.duplicate_run(True, 1))
        # self._addin.addAction(self.duplicate)
        # self.iface.addCustomActionForLayerType(self.duplicateAll1, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.duplicateAll1)

        # 3. 하위 액션을 메뉴에 추가
        self.duplicateAll_menu.addAction(self.duplicateAll)
        self.duplicateAll_menu.addAction(self.duplicateAll1)
        
        self.duplicateAll_action = self.duplicateAll_menu.menuAction()  # QAction 획득
        # 4. 생성한 메뉴를 레이어 우클릭 메뉴에 추가
        self.iface.addCustomActionForLayerType(self.duplicateAll_action, None, QgsMapLayer.VectorLayer, True)

    # 키 필드 생성
        icon = QIcon(self.plugin_dir + '/icons/key.png')
        self.keyfield = QAction(icon, "Key 필드 생성", self.iface.mainWindow())
        self.keyfield.setObjectName('Key 필드 생성')
        self.keyfield.triggered.connect(self.addKeyfield)
        # self._addin.addAction(self.layermerge)
        self.iface.addCustomActionForLayerType(self.keyfield, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.keyfield)

    # 선택레이어병합 실행
        icon = QIcon(self.plugin_dir + '/icons/merge.png')
        self.layermerge = QAction(icon, "선택레이어병합", self.iface.mainWindow())
        self.layermerge.setObjectName('선택레이어병합')
        self.layermerge.triggered.connect(self.layermerge_run)
        # self._addin.addAction(self.layermerge)
        self.iface.addCustomActionForLayerType(self.layermerge, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.layermerge)

    # 선택레이어경로 열기
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.folderPath = QAction(icon, "레이어경로열기", self.iface.mainWindow())
        self.folderPath.setObjectName('레이어경로열기')
        self.folderPath.triggered.connect(self.folderOpen)
        # self._addin.addAction(self.folderPath)
        self.iface.addCustomActionForLayerType(self.folderPath, None, QgsMapLayer.VectorLayer, True)
        Menu.addAction(self.folderPath)

    # 선택객체 각도 표기
        icon = QIcon(self.plugin_dir + '/icons/angle.png')
        self.angle = QAction(icon, "각도 표시", self.iface.mainWindow())
        self.angle.setObjectName('각도 표시')
        self.angle.setCheckable(True)
        self.angle.triggered.connect(self.angle_run)
        self.iface.registerMainWindowAction(self.angle,'Shift+A')
        self.menu.addAction(self.angle)

    # 선택객체 보간점 표시
        icon = QIcon(self.plugin_dir + '/icons/vertex.png')
        self.vertex = QAction(icon, "보간점 표시", self.iface.mainWindow())
        self.vertex.setObjectName('보간점 표시')
        self.vertex.setCheckable(True)
        self.vertex.triggered.connect(self.vertex_run)
        self.iface.registerMainWindowAction(self.vertex,'Shift+B')
        self.menu.addAction(self.vertex)

        self.toolbar.addWidget( self._addin)

        icon = QIcon(self.plugin_dir + '/icons/go_back.png')
        self.action_back = QAction(icon, "뒤로 가기", self.iface.mainWindow())
        self.action_back.setObjectName('뒤로 가기')
        self.action_back.setEnabled(False)
        self.action_back.triggered.connect(self.go_back)
        self.zoom_toolbar.addAction(self.action_back)

        icon = QIcon(self.plugin_dir + '/icons/go_forward.png')
        self.action_forward = QAction(icon, "앞으로 가기", self.iface.mainWindow())
        self.action_forward.setObjectName('앞으로 가기')
        self.action_forward.setEnabled(False)
        self.action_forward.triggered.connect(self.go_forward)
        self.zoom_toolbar.addAction(self.action_forward)

        # 세로바 생성
        vertical_line = QFrame(self.iface.mainWindow())
        vertical_line.setFixedWidth(5)
        vertical_line.setFrameShape(QFrame.VLine)
        vertical_line.setFrameShadow(QFrame.Sunken)
        self.zoom_toolbar.addWidget(vertical_line)

        icon = QIcon(self.plugin_dir + '/icons/select_back.png')
        self.select_back = QAction(icon, "선택 되돌리기", self.iface.mainWindow())
        self.select_back.setObjectName('선택 되돌리기')
        self.select_back.setEnabled(False)
        self.select_back.triggered.connect(self.go_select_back)
        self.zoom_toolbar.addAction(self.select_back)

        icon = QIcon(self.plugin_dir + '/icons/select_forward.png')
        self.select_forward = QAction(icon, "선택 다시하기", self.iface.mainWindow())
        self.select_forward.setObjectName('선택 다시하기')
        self.select_forward.setEnabled(False)
        self.select_forward.triggered.connect(self.go_select_forward)
        self.zoom_toolbar.addAction(self.select_forward)

        icon = QIcon(self.plugin_dir + '/icons/addin.png')
        self.__addin = QAction(icon, '추가기능', self.iface.mainWindow())
        self.__addin.setMenu(Menu)

        self.menu.addAction(self.__addin)

#===========================================================================================================================
    # 좌표도구 설정창
        icon = QIcon(self.plugin_dir + '/icons/setting.png')
        self.set = QAction(icon, "좌표도구설정", self.iface.mainWindow())
        self.set.setObjectName('좌표도구설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        # self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')

        self.menu.addAction(self.set)

#===========================================================================================================================
    # Help
        icon = QIcon(self.plugin_dir + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        # self.iface.addPluginToMenu('좌표도구', self.helpAction)

        self.menu.addAction(self.helpAction)

#===========================================================================================================================
    # 상단 메뉴바에 좌표변환 메뉴 추가 
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

#===========================================================================================================================
    # # 플러그인 확인
    #     today = datetime.date.today()
    #     yyyy = today.year
    #     # 인증 MyPlugin
    #     if yyyy > 2024:
    #         QMessageBox.information(self.iface.mainWindow(), '플러그인 재설치' , '좌표도구 플러그인 업데이트(재설치)가 필요합니다.')  
    #         self.unload()
    #     # self.toggle()

# 도움말===================================================================================================================================================================
    def help(self):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"  
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화========================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        try:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        except:
            pass

    # 메뉴삭제
        self.menu.deleteLater()

    # 보간점, 각도 마크 삭제
        self.vertex.setChecked(False)
        self.vertexdisplay()
        self.angle.setChecked(False)
        self.angledisplay()

        self.remove_Marker()
        self.remove_Angle()

    # 화면 정리
        try:
            self.Delete_Marker()
        except:
            pass
        # 경탐 삭제
        try:
            self.dlgPathSearch.delete()
        except:
            pass
        # 검색 삭제
        try:
            self.dlgSearch.RemoveAll()
        except:
            pass

        try:
            self.canvas.selectionChanged.disconnect(self.select_toggle)
        except:
            pass
        try:
            self.canvas.extentsChanged.disconnect(self.on_extent_changed)
        except:
            pass
        try:
            self.canvas.contextMenuAboutToShow.disconnect(self.show_context_menu)
        except:
            pass
        try:
            self.canvas.selectionChanged.disconnect(self.vertexdisplay)
        except:
            pass
        try:
            self.canvas.selectionChanged.disconnect(self.angledisplay)
        except:
            pass

        # 툴바 삭제s
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.moveIndex)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.conversion)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.shpfileopen)
        self.iface.removeToolBarIcon(self.besindex)
        self.iface.removeToolBarIcon(self.grsindex)
        self.iface.removeToolBarIcon(self.wgsindex)
        self.iface.removeToolBarIcon(self.parindex)
        self.iface.removeToolBarIcon(self.ctpshp)
        self.iface.removeToolBarIcon(self.sigshp)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.memo)
        self.iface.removeToolBarIcon(self.set)
        self.iface.removeToolBarIcon(self.simple_filter)
        self.iface.removeToolBarIcon(self.selectStatistics)
        self.iface.removeToolBarIcon(self.fieldUniqueStatistics)
        self.iface.removeToolBarIcon(self.Jenksfind)
        self.iface.removeToolBarIcon(self.layermerge)
        self.iface.removeToolBarIcon(self.folderPath)
        self.iface.removeToolBarIcon(self.vertex)
        self.iface.removeToolBarIcon(self.angle)
        self.iface.removeToolBarIcon(self.duplicate)
        self.iface.removeToolBarIcon(self.duplicate1)
        self.iface.removeToolBarIcon(self.duplicateAll)
        self.iface.removeToolBarIcon(self.duplicateAll1)
        self.iface.removeToolBarIcon(self.action_back)
        self.iface.removeToolBarIcon(self.action_forward)
        self.iface.removeToolBarIcon(self.select_back)
        self.iface.removeToolBarIcon(self.select_forward)
        self.iface.removeToolBarIcon(self.keyfield)

        try:
            del self.toolbar
        except:
            pass

        try:
            del self.zoom_toolbar
        except:
            pass

        self.history = []
        self.current_index = -1
        self.action_back.setEnabled(False)
        self.action_forward.setEnabled(False)

        # 필드계산기 표현식 삭제
        UnloadLatLonFunctions()

        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgconversionwidget)
        self.dlgconversionwidget = None
        self.dlgconversion = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None

        self.iface.mainWindow().removeDockWidget(self.dlgmemowidget)
        self.dlgmemowidget = None
        self.dlgmemo = None

        self.iface.mainWindow().removeDockWidget(self.simplefilterwidget)
        self.simplefilterwidget = None
        self.simplefilter = None

        self.iface.mainWindow().removeDockWidget(self.Statisticswidget)
        self.Statisticswidget = None
        self.Statistics = None

        self.iface.mainWindow().removeDockWidget(self.fieldStatistics_Widget)
        self.fieldStatistics_Widget = None
        self.fieldStatistics = None

        self.iface.mainWindow().removeDockWidget(self.Jenks_Widget)
        self.Jenks_Widget = None
        self.Jenks = None

        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.moveIndex)
        self.iface.unregisterMainWindowAction(self.shpfileopen)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.conversion)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.simple_filter)
        self.iface.unregisterMainWindowAction(self.memo)
        self.iface.unregisterMainWindowAction(self.vertex)
        self.iface.unregisterMainWindowAction(self.angle)
        self.iface.unregisterMainWindowAction(self.fs)
        self.iface.unregisterMainWindowAction(self.coconut)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        # 화면 위치변경 이벤트 해제
        # self.canvas.xyCoordinates.disconnect(self.handleCanvasMove)

        # 레이어 우클릭 목록 삭제
        self.iface.removeCustomActionForLayerType(self.duplicate_action)
        self.iface.removeCustomActionForLayerType(self.duplicateAll_action)
        self.iface.removeCustomActionForLayerType(self.layermerge)
        self.iface.removeCustomActionForLayerType(self.folderPath)
        self.iface.removeCustomActionForLayerType(self.keyfield)
        mac_dir = os.path.join(os.path.dirname(self.plugin_dir), 'coordinate_tool_mac')

        if os.path.exists(mac_dir):
            shutil.rmtree(mac_dir)

# 레이어 선택 토글 함수 =====================================================================================================================================================
    # def toggle(self):
    #     layer = self.canvas.currentLayer()
    #     if layer :
    #         try:
    #             layer.editingStarted.disconnect(self.toggle)
    #         except:
    #             pass
    #         try:
    #             layer.editingStopped.disconnect(self.toggle)
    #         except:
    #             pass

    #         enabled_flag = True

    #         if layer and layer.type() == layer.VectorLayer:
    #             self.searchAction.setEnabled(True)
    #         else:
    #             self.searchAction.setEnabled(False)

    #         enabled_flag = True
    #     else:
    #         self.searchAction.setEnabled(False)
    #         enabled_flag = False

    #     self.Coordinatecapture.setEnabled(enabled_flag)
    #     # self.CoordinateSpeedFs.setEnabled(enabled_flag)
    #     # self.CoordinateCoconut.setEnabled(enabled_flag)
    #     self.MediaCenter.setEnabled(enabled_flag)
    #     self.movemap1.setEnabled(enabled_flag)
    #     self.movemap2.setEnabled(enabled_flag)
    #     self.movemap3.setEnabled(enabled_flag)
    #     self.ShowOnmap.setEnabled(enabled_flag)
    #     self.mapaddress.setEnabled(enabled_flag)
    #     self.search.setEnabled(enabled_flag)
    #     self.conversion.setEnabled(enabled_flag)
    #     self.path_search.setEnabled(enabled_flag)
    #     self.coordinateConverter.setEnabled(enabled_flag)
    #     self.coordinateGeometry.setEnabled(enabled_flag)

# 좌표 캡쳐 실행==============================================================================================================================================================
    def capture(self):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행=============================================================================================================================================================
    def mediaCenter(self):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 주소 복사 실행================================================================================================================================================================
    def address(self):
        # 마커 표시 삭제
        self.copy.setDefaultAction(self.mapaddress)
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 좌표 정보 확인=============================================================================================================================================================
    def conversionwidget(self):
        self.copy.setDefaultAction(self.conversion)

# 좌표 이동 실행===============================================================================================================================================================
    def mapMove(self, idx, movemap):
        clipText = self.clipboard.text().strip()
        SeqOrder=int(self.QSettings.value('ComboBox' + str(idx+2), 0))
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project' + str(idx+2),'USER:100000'))
        try:
            lon, lat = self.Function.setval(setCRS,clipText) # 복사된 좌표 X, Y 좌표 변환
            self.movemap.setDefaultAction(movemap)
            self.Function.moveto(setCRS, lon, lat, SeqOrder)
            self.canvas.refresh()
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()
        except:
            pass

# 도엽이동 실행===================================================================================================================================================================
    def Move(self):
        self.movemap.setDefaultAction(self.moveIndex)
        self.Delete()
        self.canvas.refresh()
        self.indexMove.show()
        
# 검색창 실행===================================================================================================================================================================
    def searchtool(self):
        self.movemap.setDefaultAction(self.search)
        self.dlgSearch.lineEdit.setFocus()
# 툴바 기본값 변경 =================================================================================================================================================================
    def DefaultAction(self, toolbar, Action):
        toolbar.setDefaultAction(Action)

# 웹지도 실행==================================================================================================================================================================
    def ShowOn(self):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        if self.Converter is None:
            self.Converter = CoordinateToolConverter(self.iface, self.iface.mainWindow())
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================
    def Geometrywidget(self):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        if self.Geometry is None:
            self.Geometry = CoordinateToolGeometry(self.iface, self.iface.mainWindow())
        self.Geometry.show() 

# 파일열기 =======================================================================================================================================================================
    def fileopen(self):
        self.indexshp.setDefaultAction(self.shpfileopen)
        self.Delete()
        self.shpBookmark.getOpenFile()

# 쉐입인덱스 불러오기 ============================================================================================================================================================
    def shpIndex(self, idx, Action, cmtName, fileName, leLabefield, symbolfield, lineWidth):
        self.Delete()
        self.indexshp.setDefaultAction(Action)
        layers = QgsProject.instance().mapLayersByName(cmtName) # 레이어 목록중 코멘트 레이어 탐색
        if layers:
        # 인덱스 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
            layer = layers[0]  
            layer.triggerRepaint()   
        else:
        # 인덱스 레이어가 없다면 레이어 추가
            filepath = os.path.join(self.plugin_dir,'shp',fileName)

        # shp 파일이 있다면
            if os.path.isfile(filepath):
            # 서버의 파일과 수정된 시간을 비교하여 파일 업로드 결정
                from datetime import datetime
                from io import BytesIO

            # 로컬파일 시간 가져오기
                modification_time = os.path.getmtime(filepath)
                getctime_time  = datetime.fromtimestamp(int(modification_time))

                file_zip = fileName.split('.')[0] + '.zip'
                raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip

            # 압축 파일 다운로드하지 않고 압축 파일 내부의 시간 정보 확인
                response = requests.get(raw_url, verify=False)
                if response.status_code == 200:
                    with zipfile.ZipFile(BytesIO(response.content)) as shp_zip:
                        try:
                            zipinfo = shp_zip.getinfo(fileName)
                            zipinfo_time = datetime(*zipinfo.date_time)
                            print("압축 파일 내부의 시간:", zipinfo_time)
                        except KeyError:
                            print("해당 파일이 압축 파일 내에 존재하지 않습니다.")
                else:
                    print("파일 다운로드에 실패했습니다. HTTP 상태 코드:", response.status_code)

            # 시간 비교 서버의 파일이 최신이라면 압축해제
                if zipinfo_time > getctime_time:
                    self.indexdownload(fileName)

                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

            else:
                print("파일이 존재하지 않습니다.")
            # shp 파일 다운로드
                self.indexdownload(fileName)
            # 대기
                time.sleep(1)
            # shp 파일 가져오기
                self.shpimport(idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth)

    def shpimport(self, idx, filepath, fileName, cmtName, leLabefield, symbolfield, lineWidth):

        existing_layer = QgsVectorLayer(filepath, cmtName, "ogr")
        # QgsProject.instance().addMapLayer(existing_layer)
        # 기존 레이어의 CRS 가져오기
        crs = existing_layer.crs().authid()
        memory_layer = QgsVectorLayer(f"Polygon?crs={crs}", cmtName, "memory")

        # 기존 레이어의 피처를 가상 메모리 레이어로 복사합니다.
        memory_layer_data_provider = memory_layer.dataProvider()
        memory_layer.startEditing()
        memory_layer_data_provider.addAttributes(existing_layer.fields().toList())
        memory_layer.updateFields()

        # 기존 레이어의 피처 한 번에 복사
        features = list(existing_layer.getFeatures())
        memory_layer_data_provider.addFeatures(features)

        # # 기존 레이어의 피처 복사
        # for feature in existing_layer.getFeatures():
        #     memory_layer_data_provider.addFeatures([feature])
        
        memory_layer.commitChanges()
        
        # 레이어를 QGIS 프로젝트에 추가합니다.
        QgsProject.instance().addMapLayer(memory_layer)

        if idx in (1,2,3):
            filepath = str('/shp/' + fileName)
            memory_layer.loadNamedStyle(os.path.join(self.plugin_dir, 'style', "index.qml"))
        else:
            self.setsymbol(memory_layer,leLabefield, symbolfield, lineWidth)
        memory_layer.triggerRepaint()   

    def indexdownload(self, fileName):
        file_zip = fileName.split('.')[0] + '.zip'
    # 저장경로지정
        destination_path = os.path.join(self.plugin_dir, file_zip)
    # 폴더 생성
        extracted_folder = os.path.join(self.plugin_dir,'shp')
        if not os.path.exists(extracted_folder):
            os.makedirs(extracted_folder)
    # 파일 다운로드
        raw_url = 'https://scshin8.github.io/Qgis/shpfile/' + file_zip
        response = requests.get(raw_url, verify=False)
        with open(destination_path, 'wb') as file:
            file.write(response.content)
    # 추출할 디렉토리로 압축 해제
        with zipfile.ZipFile(destination_path, 'r') as zip_ref:
            zip_ref.extractall(self.plugin_dir + '/shp')
    # 압축파일 삭제
        if os.path.exists(destination_path):  # 파일이 존재하는지 확인합니다.
            os.remove(destination_path)  # 파일을 삭제합니다.

# 심볼 설정 =================================================================================================================================================================  
    def setsymbol(self,layer,leLabefield, symbolfield, lineWidth): 

        fni = layer.dataProvider().fields().indexFromName(symbolfield)
        unique_values = layer.uniqueValues(fni)

        # fill categories
        categories = []
        for unique_value in unique_values:
            # initialize the default symbol for this geometry type
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())

            # configure a symbol layer
            layer_style = {}
            # layer_style['joinstyle'] = 'bevel'
            layer_style['style'] = 'no'
            layer_style['color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_color'] = '%d, %d, %d' % (random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256))
            layer_style['outline_width'] = lineWidth
            symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)

            # replace default symbol layer with the configured one
            if symbol_layer is not None:
                symbol.changeSymbolLayer(0, symbol_layer)

            # create renderer object
            category = QgsRendererCategory(unique_value, symbol, str(unique_value))
            # entry for the list of category items
            categories.append(category)

        # create renderer object
        renderer = QgsCategorizedSymbolRenderer(symbolfield, categories)

        # assign the created renderer to the layer
        if renderer is not None:
            layer.setRenderer(renderer)

        layer.triggerRepaint()

        #라벨 스타일 설정
        layer_settings  = QgsPalLayerSettings()

        text_format = QgsTextFormat() # 텍스트 포멧 정의
        text_format.setFont(QFont("맑은 고딕")) # 폰트
        text_format.setSize(9) # 크기
        # text_format.setColor(QColor(255, 0, 255, 255)) # 컬러
        
        # 폰트 버퍼 설정
        # buffer_settings = QgsTextBufferSettings()
        # buffer_settings.setEnabled(True) # 버퍼 활성화
        # buffer_settings.setSize(1) # 버퍼 사이즈
        # buffer_settings.setColor(QColor("white")) # 버퍼 컬러
        # text_format.setBuffer(buffer_settings) # 폰트에 버퍼 셋팅
        
        layer_settings.setFormat(text_format) #라벨 스타일에 폰트 셋팅

        layer_settings.fieldName = leLabefield
        # layer_settings.placement = 2
        
        layer_settings.enabled = True
    
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        # 스타일 새로고침
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        # 단일 심볼 스타일 설정
        # 심볼설정
        # soldcol = QColor(0, 0, 0, 0) # 채우기색
        # linecol = QColor(103, 153, 141, 255) # 테두리색 R / G / B / 투명도
        # linecol = QColor(random.randrange(0, 256), random.randrange(0, 256), random.randrange(0, 256), 255) # 테두리색 R / G / B / 투명도
        # lineWidth = 0.3 # 테두리 너비
        # layer.renderer().symbol().setColor(soldcol) # 채우기색
        # layer.renderer().symbol().symbolLayer(0).setStrokeColor(linecol) # 테두리색 (R , G , B , 투명도) QColor(255, 0, 255, 255)
        # layer.renderer().symbol().symbolLayer(0).setStrokeWidth(lineWidth) # 테두리 너비
        # layer.renderer().symbol().symbolLayer(0).setStrokeStyle(Qt.PenStyle(Qt.DotLine)) # Qt. Solid Line, NoPen, DotLine, DashLine, DashDotLine, DashDotDotLine

# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self):
        self.indexshp.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()

# 메모 패널 실행=====================================================================================================================================================================
    def notepad(self):
        self._addin.setDefaultAction(self.memo)

    def show_mdbToShp(self):
        self._addin.setDefaultAction(self._mdbToShp)
        self.Delete()
        self.mdbToShp.show()

# 검색 실행=====================================================================================================================================================================
    # def showSearchDialog(self):
    #     self._addin.setDefaultAction(self.searchAction)
    #     if self.searchDialog is None:
    #         # All the work is done in the LayerSearchDialog
    #         self.searchDialog = LayerSearchDialog(self.iface, self.iface.mainWindow())
    #         # self._addin.setDefaultAction(self.searchAction)
    #     self.searchDialog.show()

# 설정창 실행===================================================================================================================================================================
    def setting(self):
        self.Delete()
        self.dlg.show()

# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self,t):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시======================================================================================================================================================================
    def Draw_Marker(self,point,idx):
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)

        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()

# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None
        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)
        
    def vertexdisplay(self):
        self.time_start = time.perf_counter()
        if self.vertex_run_chk:
            layer = self.iface.activeLayer()
            if not layer or not isinstance(layer, (QgsVectorLayer)):
                return
            featuresCount = layer.selectedFeatureCount()
            # 선택 객체가 1개 이상 또는 20개 이하 일때만 보간점 표시함
            if featuresCount >= 1 and featuresCount <= 20:
                selected_features = layer.selectedFeatures()
                # 기존 마커 삭제e
                self.remove_Marker()
                # 리스트 초기화
                selected_objects =[]
                # 프로젝트와 레이어 좌표계 가져오기
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                layer_crs=layer.crs()
                transform = QgsCoordinateTransform(layer_crs,canvasCRS, QgsProject.instance())

                # 설정값 로드
                size = int(self.QSettings.value('spinBox', 10))
                txt_color = QColor(self.QSettings.value('markerColorButton_5', '#ff0000')).name()
                back_color = QColor(self.QSettings.value('markerColorButton_6', '#ff0000')).name()
                has_bg = int(self.QSettings.value('background_checkBox', 0)) != 0
                bg_style = f"background-color: {back_color};" if has_bg else ""

                marker_size = "0" if layer.isEditable() else "0.6"
                marker_symbol = QgsMarkerSymbol.createSimple({"name": "rectangle", "color": "red", "outline_style": "no", "size": marker_size})

                fontDefault = QFont('맑은 고딕')
                fontDefault.setBold(True)
                
                # 선택한 피처의 꼭지점 좌표 출력
                for feature in selected_features:
                    geometry = feature.geometry()
                    wkbType = geometry.wkbType()
                    if geometry:
                        if geometry.wkbType() in (QgsWkbTypes.Point, QgsWkbTypes.PointZM,
                                                  QgsWkbTypes.MultiPoint, QgsWkbTypes.MultiPointZM):
                            pass
                        else:
                            # 라인스트링, 멀티라인스트링, 다각형, 멀티다각형인 경우 처리
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                vertexs = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                multi_lines = geometry.asMultiPolyline()
                                vertexs = [vertex for lines in multi_lines for vertex in lines]
                            elif wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.PolygonZM:
                                rings = geometry.asPolygon()
                                vertexs = [vertex for ring in rings for vertex in ring[:-1]]
                            elif wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.MultiPolygonZM:
                                multi_Polygons = geometry.asMultiPolygon()
                                vertexs = [vertex for Polygons in multi_Polygons for Polygon in Polygons for vertex in Polygon[:-1]]

                            for i, vertex in enumerate(vertexs):
                                txtProjectPoint = transform.transform(vertex.x(), vertex.y())
                                selected_objects.append([txtProjectPoint, i])

                # QgsTextAnnotation을 담을 리스트를 생성합니다.
                text_annotations = []   

                for Vertex, idx in selected_objects:
                    # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                    html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{idx}</span>'
                    text_document = QTextDocument()
                    text_document.setHtml(html_text)
                    text_document.setDefaultFont(fontDefault)

                    # QgsTextAnnotation 생성 및 설정
                    text_annotation = QgsTextAnnotation(self.canvas)
                    text_annotation.setDocument(text_document)

                    # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                    text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0,0))
                    text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,0))
                    # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                    # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                    text_annotation.setMapPosition(Vertex)
                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                    text_annotation.setMarkerSymbol(marker_symbol)
                    # text_annotation의 크기를 조절
                    text_annotation.setFrameSize(text_document.size())  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                    # QgsTextAnnotation을 리스트에 추가합니다.
                    text_annotations.append(text_annotation)

                # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                self.MarkerSymbol.extend(annotation_items)
                self.canvas.refresh()
            else:
                # 선택한 객체가 없다면
                self.remove_Marker()
                selected_objects = []
                text_annotations = []        
        else:
            self.remove_Marker()    
        # print(time.perf_counter() - self.time_start)

    def angledisplay(self):
        if self.angle_run_chk:
            self.time_start = time.perf_counter()
            layer = self.iface.activeLayer()
            if not layer or not isinstance(layer, (QgsVectorLayer)):
                return
            
            featuresCount = layer.selectedFeatureCount()
            if featuresCount > 0:
                # 기존 마커 삭제
                self.remove_Angle()
                selected_features =layer.selectedFeatures()

                if len(selected_features) != 1:
                    self.iface.messageBar().clearWidgets()
                    # self.iface.messageBar().pushMessage(f'진입링크는 하나만 선택해야 합니다', level=Qgis.Info, duration=3)
                else:
                    self.selected_feature = selected_features[0]
                    # 선택한 링크의 양끝점 좌표를 가져옵니다.
                    geometry = self.selected_feature.geometry()
                    if geometry != None:
                        parts = geometry.asGeometryCollection()
                        # if not geometry.isMultipart():
                        if len(parts) != 1:
                            self.iface.messageBar().pushMessage(f'멀티파츠 객체입니다.', level=Qgis.Info, duration=3)  
                            return

                        wkbType = geometry.wkbType()
                        if geometry:
                            if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                geometry_points = geometry.asPolyline()
                            elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                geometry_points = geometry.asMultiPolyline()[0]
                            else:   # wkbType == QgsWkbTypes.Polygon or wkbType == QgsWkbTypes.MultiPolygon or wkbType == QgsWkbTypes.Point or wkbType == QgsWkbTypes.MultiPoint:
                                return
                        self.start_point0 = geometry_points[0]
                        self.start_point1 = geometry_points[1]
                        self.end_point0 = geometry_points[-1]
                        self.end_point1 = geometry_points[-2]

                        # 프로젝트와 레이어 좌표계 가져오기
                        map_crs = self.canvas.mapSettings().destinationCrs()  # 화면 좌표계
                        layer_crs = layer.crs()  # 레이어 좌표계
                        transform = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())

                        # 화면 경계를 레이어 좌표계로 변환
                        extent = self.canvas.extent()  # 화면 경계
                        transformed_extent = transform.transformBoundingBox(extent)

                        request = QgsFeatureRequest().setFilterRect(transformed_extent)

                        # 화면에 보이는 피처만 가져오기
                        visible_features = layer.getFeatures(request)
                        visible_features_list = list(visible_features)
                        # 화면 내 인접 피처 찾기
                        adjacent_features = []
                        for feature in visible_features_list:
                            if feature.id() != self.selected_feature.id():  # 자기 자신 제외
                                if geometry.touches(feature.geometry()):  # 지오메트리가 인접한지 확인
                                    adjacent_features.append(feature)

                    if len(adjacent_features) == 0:
                        return

                    # 프로젝트와 레이어 좌표계 가져오기
                    map_crs = self.canvas.mapSettings().destinationCrs()  # 화면 좌표계
                    layer_crs = layer.crs()  # 레이어 좌표계
                    transform = QgsCoordinateTransform(layer_crs, map_crs, QgsProject.instance())
                    
                    # 설정값 로드
                    size = int(self.QSettings.value('spinBox_2', 10))
                    txt_color = QColor(self.QSettings.value('markerColorButton_7', '#ff0000')).name()
                    back_color = QColor(self.QSettings.value('markerColorButton_8', '#ff0000')).name()
                    has_bg = int(self.QSettings.value('background_checkBox_2', 0)) != 0
                    bg_style = f"background-color: {back_color};" if has_bg else ""
                    
                    marker_symbol = QgsMarkerSymbol.createSimple({"name":"rectangle", "color":"red","outline_color": "0,0,0,255","outline_style": "no", "size":"0"}) #"name":"rectangle", 'size_unit': 'MapUnit', 'outline_style': 'solid',
                    
                    fontDefault = QFont('맑은 고딕')
                    fontDefault.setBold(True)

                    # 인접링크 리스트 생성
                    adjacent_links = []
                    for feature in adjacent_features:
                        if feature.id() == self.selected_feature.id():
                            continue  # 선택한 링크 자체는 제외합니다.
                        adjacent_geometry = feature.geometry()
                        if adjacent_geometry != None:
                            parts = adjacent_geometry.asGeometryCollection()
                            # if len(parts) == 1:
                            #     wkbType = adjacent_geometry.wkbType()
                            #     # 링크싀
                            #     if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                            #         adjacent_geometry_points = adjacent_geometry.asPolyline()
                            #         adjacent_points_len = len(adjacent_geometry_points)
                            #     elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                            #         adjacent_geometry_points = adjacent_geometry.asMultiPolyline()[0]
                            #         adjacent_points_len = len(adjacent_geometry_points)
                            #     # 꼭지점 좌표 변환
                            #     adjacent_start_point0 = adjacent_geometry_points[0]
                            #     adjacent_start_point1 = adjacent_geometry_points[1]
                            #     adjacent_end_point0 = adjacent_geometry_points[-1]
                            #     adjacent_end_point1 = adjacent_geometry_points[-2]
                            #     length = adjacent_geometry.length()

                            #     # 인접 위치 판별( 시점, 종점 )
                                
                            #     # 디스플레이 좌표
                            #     third_point = adjacent_geometry.interpolate(length * 0.5).asPoint()
                            #     # 시점과 시점 인접
                            #     if self.start_point0 == adjacent_start_point0:
                            #         # 길이의 1/2 지점 좌표 계산
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.2).asPoint() # 0.2
                            #         # else:
                            #         #     third_point = adjacent_start_point1
                            #         adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                            #     # 시점과 종점 인접
                            #     elif self.start_point0 == adjacent_end_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.8).asPoint() # 0.8
                            #         # else:
                            #         #     third_point = adjacent_end_point1
                            #         adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                            #     # 종점과 시점 인접
                            #     elif self.end_point0 == adjacent_start_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.2).asPoint() # 0.2
                            #         # else:
                            #         #     third_point = adjacent_start_point1
                            #         adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                            #     # 종점과 종점 인접
                            #     elif self.end_point0 == adjacent_end_point0:
                            #         # if adjacent_points_len == 2:
                            #         #     third_point = adjacent_geometry.interpolate(length * 0.8).asPoint() # 0.8
                            #         # else:
                            #         #     third_point = adjacent_end_point1
                            #         adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                            # else:
                            for adjacent_geometry in parts:

                                wkbType = adjacent_geometry.wkbType()
                                # 링크싀
                                if wkbType == QgsWkbTypes.LineString or wkbType == QgsWkbTypes.LineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asPolyline()
                                elif wkbType == QgsWkbTypes.MultiLineString or wkbType == QgsWkbTypes.MultiLineStringZM:
                                    adjacent_geometry_points = adjacent_geometry.asMultiPolyline()[0]
                                # 꼭지점 좌표 변환
                                adjacent_start_point0 = adjacent_geometry_points[0]
                                adjacent_start_point1 = adjacent_geometry_points[1]
                                adjacent_end_point0 = adjacent_geometry_points[-1]
                                adjacent_end_point1 = adjacent_geometry_points[-2]
                                length = adjacent_geometry.length()

                                # 디스플레이 좌표
                                third_point = adjacent_geometry.interpolate(length * 0.5).asPoint()
                                # 인접 위치 판별( 시점, 종점 )
                                # 시점과 시점 인접
                                if self.start_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 시점과 종점 인접
                                elif self.start_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.start_point0, self.start_point1, adjacent_end_point0, adjacent_end_point1, third_point])
                                # 종점과 시점 인접
                                elif self.end_point0 == adjacent_start_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_start_point0, adjacent_start_point1, third_point])
                                # 종점과 종점 인접
                                elif self.end_point0 == adjacent_end_point0:
                                    adjacent_links.append([feature, self.end_point0, self.end_point1, adjacent_end_point0, adjacent_end_point1, third_point])

                            # 결과값 리스트
                            angles_result = []
                            # 선택한 링크와 인접한 링크의 각도를 계산합니다.
                            for adjacent_link, start_point0, start_point1, end_point0, end_point1,txtPoint in adjacent_links:

                                angle = math.atan2(start_point1.x() - start_point0.x(), start_point1.y() - start_point0.y())
                                selected_feature_angle = math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180

                                angle = math.atan2(end_point1.x() - end_point0.x(), end_point1.y() - end_point0.y())
                                adjacent_feature_angle = math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180

                                abs_angle = round(abs((selected_feature_angle-adjacent_feature_angle) % 360),1)
                                angle_value  = abs_angle -360 if abs_angle > 180 else abs_angle

                                angle_value  = "%g" %round(abs_angle if abs_angle < 0 else 180 - abs_angle, 1)

                                # 좌표를 프로젝트 좌표로 변환 
                                txtProjectPoint = transform.transform(txtPoint.x(), txtPoint.y())
                                angles_result.append([txtProjectPoint,angle_value])

                            # QgsTextAnnotation을 담을 리스트를 생성합니다.
                            text_annotations = []   
                            for point, angle in angles_result:
                                # 원하는 텍스트를 문자열로 변환하여 QTextDocument 생성
                                html_text = f'<span style="font-size: {size}pt; color: {txt_color}; {bg_style}">{str(angle)}</span>'
                                text_document = QTextDocument()
                                text_document.setHtml(html_text)
                                text_document.setDefaultFont(fontDefault)

                                # QgsTextAnnotation 생성 및 설정
                                text_annotation = QgsTextAnnotation(self.canvas)
                                text_annotation.setDocument(text_document)

                                # 심볼의 색상, 테두리 색상, 테두리 너비 설정하여 프레임 없는 심볼로 만듭니다.
                                text_annotation.fillSymbol().symbolLayer(0).setColor(QColor(0, 0, 0,0))
                                text_annotation.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,0))
                                # text_annotation.fillSymbol().symbolLayer(0).setStrokeWidth(0)

                                # 맵 위치, 프레임 오프셋, 마커 심볼 설정
                                text_annotation.setMapPosition(point)
                                if layer.isEditable():
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(0, 0))
                                else:
                                    text_annotation.setFrameOffsetFromReferencePoint(QPointF(-(text_document.size().width()/2), - (text_document.size().height()/2)))

                                text_annotation.setMarkerSymbol(marker_symbol)
                                # text_annotation의 크기를 조절
                                text_annotation.setFrameSize(QSizeF(text_document.size().width(),text_document.size().height()))  # 원하는 크기로 조절 (예: 가로 50, 세로 25)

                                # QgsTextAnnotation을 리스트에 추가합니다.
                                text_annotations.append(text_annotation)

                    # 리스트에 있는 모든 QgsTextAnnotation을 한 번에 맵에 추가합니다.
                    annotation_items = [QgsMapCanvasAnnotationItem(text_annotation, self.canvas) for text_annotation in text_annotations]
                    self.AngleSymbol.extend(annotation_items)
                    self.canvas.refresh()  
            else:
                self.remove_Angle()
                angles_result = []
                text_annotations = []
        else:
            self.remove_Angle()

    def vertex_run(self):
        if self.vertex.isChecked():
            self.canvas.selectionChanged.connect(self.vertexdisplay)
            self.vertex_run_chk = True
            self.vertexdisplay()
        else:
            self.canvas.selectionChanged.disconnect(self.vertexdisplay)
            self.remove_Marker()
            self.vertex_run_chk = False

    def angle_run(self):
        if self.angle.isChecked():
            self.canvas.selectionChanged.connect(self.angledisplay)
            self.angle_run_chk = True
        else:
            self.canvas.selectionChanged.disconnect(self.angledisplay)
            self.remove_Angle()
            self.angle_run_chk = False

    def duplicate_run(self, style, idx = 0):
        # 프로그래스바 추가??
        # self._addin.setDefaultAction(self.duplicate)
        # self.layer_set = set()
        layer = self.iface.activeLayer()
        if idx == 0:
            try:
                features = layer.selectedFeatures()
                new_name = f'__{layer.name()}_선택복사'
            except:
                return
        else:
            features = list(layer.getFeatures())
            new_name = f'__{layer.name()}_레이어복사'

        # self.layer_set.add(layer)
        # for layer in self.layer_set:
        wkb_type = layer.wkbType()
        layer_crs = layer.sourceCrs()
        fields = QgsFields(layer.fields())
        new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
        dp = new_layer.dataProvider()
        dp.addAttributes(fields)
        new_layer.updateFields()

        if style:
            # 스타일을 임시 XML 파일에 저장
            temp_style_file = os.path.join(self.plugin_dir, 'style', 'temp_style.qml')
            layer.saveNamedStyle(temp_style_file)
            # 새 레이어에 스타일 XML 적용
            new_layer.loadNamedStyle(temp_style_file)

            # new_layer.setRenderer(layer.renderer().clone())
            # # 라벨 설정 복사
            # if layer.labeling():
            #     new_layer.setLabeling(layer.labeling().clone())
            #     new_layer.setLabelsEnabled(layer.labelsEnabled())

        QgsProject.instance().addMapLayer(new_layer)
        new_layer.startEditing()

        # for feature in selected_features:
        #     # 속성 값 가져오기
        #     attributes = feature.attributes()
        #     f = QgsFeature()
        #     f.setGeometry(feature.geometry())  # 올바른 방법: QgsGeometry 객체를 전달
        #     f.setAttributes(attributes) # 새로운 QgsFeature에 속성 설정
        #     new_layer.dataProvider().addFeatures([f])
        dp.addFeatures(features)

        new_layer.updateExtents()
        self.canvas.refresh()

    def addKeyfield(self):
        layer = self.iface.activeLayer()
        self.checked_fields = []
        self.keyName = ''
        if layer.type() == QgsMapLayerType.VectorLayer:
            ok_button = self.addKey.buttonBox.button(QDialogButtonBox.Ok)
            close_button = self.addKey.buttonBox.button(QDialogButtonBox.Close)
            model = self.addKey.mComboBox.model()
            checkBox = self.addKey.checkBox
            # 기존에 연결된 슬롯이 있으면 끊어준다
            try:
                ok_button.clicked.disconnect(self.createKey)
                close_button.clicked.disconnect(self.addKey.close)
                model.itemChanged.disconnect(self.onItemChanged)
                checkBox.stateChanged.disconnect(self.chkBox)
            except TypeError:
                # 연결된 게 없으면 무시
                pass
            ok_button.clicked.connect(self.createKey)
            checkBox.stateChanged.connect(self.chkBox)
            self.addKey.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.addKey.close)

            self.addKey.lineEdit.setText('')
            self.addKey.mFieldExpressionWidget.setExpression("")
            self.addKey.mFieldExpressionWidget.setLayer(layer)
            self.addKey.mComboBox.clear()
            for fld in layer.fields():
                self.addKey.mComboBox.addItem(fld.name())
            # 모델의 dataChanged 시그널에 연결
            model = self.addKey.mComboBox.model()
            model.itemChanged.connect(self.onItemChanged)
            self.addKey.progressBar.setValue(0)
            self.addKey.show()
    def chkBox(self):
        if self.addKey.checkBox.isChecked():
            self.addKey.lineEdit.setEnabled(True)
        else:
            self.addKey.lineEdit.setEnabled(False)
            self.addKey.lineEdit.setText(self.keyName)

    def onItemChanged(self, item):
        field = item.text()
        if item.checkState() == Qt.Checked:
            # 새로 체크된 필드는 리스트 뒤에 추가
            if field not in self.checked_fields:
                self.checked_fields.append(field)
        else:
            # 해제된 필드는 리스트에서 제거
            if field in self.checked_fields:
                self.checked_fields.remove(field)
        # 현재 리스트 순서대로 expression 생성
        # 예: "field1" || ' ' || "field2" || ' ' || "field3"
        parts = [f'"{f}"' for f in self.checked_fields]
        expr = " || '_' || ".join(parts) if parts else ""
        names = [f'{f[0]}' for f in self.checked_fields]
        name = "".join(names) if names else " "
        self.keyName = f'{name}_ID'
        if not self.addKey.checkBox.isChecked():
            self.addKey.lineEdit.setText(self.keyName)
        # 식 위젯에 반영
        # (QgsFieldExpressionWidget에는 setExpression 메서드가 있습니다)
        self.addKey.mFieldExpressionWidget.setExpression(expr)

    def createKey(self):
        layer = self.iface.activeLayer()
        total = layer.featureCount()
        if not layer or layer.type() != QgsMapLayerType.VectorLayer:
            return
        name = self.addKey.lineEdit.text()
        fname = "KeyField" if name is None else name
        # 1) 표현식 준비
        expr_str = self.addKey.mFieldExpressionWidget.expression()
        expr = QgsExpression(expr_str)
        ctx  = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

        # 2) KeyField 필드 추가
        if not layer.isEditable():
            layer.startEditing()
        dp = layer.dataProvider()
        dp.addAttributes([QgsField(fname, QVariant.String, "", 50)])
        layer.updateFields()
        idx = layer.fields().indexFromName(fname)

        # 3) 모든 피처의 계산값을 dict에 저장
        value_map = {}
        for i, feat in enumerate(layer.getFeatures()):
            ctx.setFeature(feat)
            val = expr.evaluate(ctx)
            if expr.hasEvalError():
                val = ""
            value_map[feat.id()] = { idx: val }
            self.addKey.progressBar.setValue(int(100*(i+1)/max(1,total)))
            
        # 4) 한 번의 호출로 모든 피처 업데이트
        dp.changeAttributeValues(value_map)
        # layer.commitChanges()
        layer.triggerRepaint()
        self.addKey.close()

    def layermerge_run(self):
        self.iface.messageBar().clearWidgets()
        selected_layers = [layer for layer in QgsProject.instance().mapLayers().values() if layer in self.iface.layerTreeView().selectedLayers()]
        if len(selected_layers) < 2:
            self.iface.messageBar().pushMessage(f'병합할 레이어가 두 개 이상 선택되어야 합니다.', level=Qgis.Critical, duration=3)
        else:
            # 각 레이어에 "layer_name" 가상 필드 추가
            for layer in selected_layers:
                layer_name = layer.name()  # 현재 레이어 이름
                layer_path = layer.source() # 현재 레이어 경로

                # 가상 필드 추가
                layer.addExpressionField(
                    f"'{layer_name}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_name", QVariant.String),  # 필드명과 유형 설정
                )

                layer.addExpressionField(
                    f"'{layer_path}'",  # 필드 값으로 레이어 이름 설정
                    QgsField("layer_path", QVariant.String),  # 필드명과 유형 설정
                )

            # 병합 처리 실행
            try:
                result = processing.run("native:mergevectorlayers", {
                    "LAYERS": selected_layers,
                    "CRS": selected_layers[0].crs(),
                    "OUTPUT": "memory:"  # 결과를 메모리 레이어로 저장
                })
                # 결과 레이어 이름 지정 및 추가
                merged_layer = result["OUTPUT"]
                merged_layer.setName("병합한 레이어")  # 여기서 이름을 설정

                # 편집 모드 시작
                merged_layer.startEditing()
                for field_name in ["layer", "path"]:  # 제거할 필드 목록
                    idx = merged_layer.fields().indexOf(field_name)
                    if idx != -1:
                        merged_layer.deleteAttribute(idx)
                
                # 편집 모드 종료 및 변경사항 저장
                merged_layer.commitChanges()

                # 병합 레이어 추가
                QgsProject.instance().addMapLayer(merged_layer)

                for layer in selected_layers:
                    for field_name in ["layer_name", "layer_path"]:  # 제거할 필드 목록
                        idx = layer.fields().indexOf(field_name)
                        if idx != -1:
                            layer.deleteAttribute(idx)

                self.iface.messageBar().pushMessage(f'레이어 병합', level=Qgis.Info, duration=5)
            except Exception as e:
                self.iface.messageBar().pushMessage(f'레이어 병합 오류 : {e}', level=Qgis.Critical, duration=5)
                pass

    def folderOpen(self):
        self.iface.messageBar().clearWidgets()
        # 활성화된 레이어 가져오기
        layer = self.iface.activeLayer()
        
        # 레이어가 없는 경우
        if not layer:
            return

        # 임시 레이어인지 확인
        if layer.isTemporary():
            self.iface.messageBar().pushMessage(f'임시 레이어는 경로를 열 수 없습니다.', level=Qgis.Warning, duration=5)
            return

        # 레이어의 소스 경로 가져오기
        layer_source = layer.source().split('|')[0]

        # 로컬 파일 경로가 아닌 경우
        if not os.path.isfile(layer_source):
            self.iface.messageBar().pushMessage(f'이 레이어는 로컬 파일이 아닙니다.', level=Qgis.Warning, duration=5)
            return

        # 탐색기에서 경로 열기
        folder_path = os.path.dirname(layer_source)
        os.startfile(folder_path)  # Windows에서 탐색기를 엽니다.

    def remove_Marker(self):
        if len(self.MarkerSymbol) > 0:
            for mark in self.MarkerSymbol:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol = []
        self.canvas.refresh()  
        # items = self.canvas.scene().items()
        # items_to_remove = []
        # for item in items:
        #     if isinstance(item, QgsMapCanvasItem):
        #         if isinstance(item, QgsMapCanvasAnnotationItem):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QTextDocument):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QgsMarkerSymbol):
        #             items_to_remove.append(item)
        #         elif isinstance(item, QgsTextAnnotation):
        #             items_to_remove.append(item)

        # # 찾은 아이템을 캔버스에서 제거
        # for item in items_to_remove:
        #     self.canvas.scene().removeItem(item)
        # self.canvas.refresh()  

    def remove_Angle(self):
        if len(self.AngleSymbol) > 0:
            for mark in self.AngleSymbol:
                self.canvas.scene().removeItem(mark)
        self.AngleSymbol = []
        self.canvas.refresh() 