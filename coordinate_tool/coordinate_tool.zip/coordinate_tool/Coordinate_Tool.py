'''
*****************************************************************************************************

QGSI 좌표복사 이동 및 좌표변환 기능 탑재

*****************************************************************************************************

* 2022.05.14 - 최초개발시작 
* 2022.05.16 - 좌표이동(개별툴)
* 2022.05.18 - 좌표복사(개별툴)
* 2022.07.06 - 좌표복사, 이동 개별툴에서 하나로 통합
* 2022.07.25 - API이용한 주소보기 및 이동 추가(카카오,네이버,브이월드)
             - 복사 및 이동 좌표계 설정가능하도록 수정
             - 웹지도 열기 추가(다음,네이버)
             - 도엽이동 및 경위도 이동 추가
             - 좌표정보 보기 기능 추가
* 2022.09.22 - 키워드 검색 기능 추가(카카오, Ruoto)
             - 주변POI검색기능 추가(Ruoto)
* 2022.10.13 - 경로탑색기능 추가 Ruoto
* 2022.11.07 - 경로탑색기능 추가 네이버
             - SHP파일 오픈 탐색기 기능 추가 및 도엽인덱스,행정계자료 기본값으로 추가
* 2022.11.12 - 좌표변환 기능 추가
             - 필드계산기 함수 추가
             - MMS좌표복사 기능 추가
             - 도형계산기 기능 추가
* 2023.01.30 - speedfs 이동, coconut 이동 , 미디어센터 이동 기능 추가
* 2023.02.05 - pip module "pyautogui" 설치 기능 추가
             - 경로탐색 검색기능 개선(카카오 추가), 경로탐색 속도 개선
* 2023.02.07 - pip module 자동 설치 추가
* 2023.02.10 - Coconut 이동 시 Bessel 및 GRS 선택 기능 추가 - 삭제 2024.12.17
* 2023.02.20 - 구글 경로 탐색 기능 개선 (경유지 검색 개선, 구글 탭 추가, 폴리라인 표출 최적화)
* 2023.03.09 - 구글 좌표 주변 검색 기능 추가 및 웹지도 열기 코드 개선
* 2023.03.12 - 경로 탐색 개선
* 2023.09.02 - 검색기능 추가, 협력사 인덱스 추가, 도움말 링크 추가(플러그인 메뉴얼)
* 2023.09.10 - 대권역 속성값 수정, API Key 암호화, 중복 코드 수정
* 2023.09.11 - 행정계 SHP 교체 (군위군 대구광역시 편입)
* 2023.09.17 - 메모장 패널 추가
* 2023.09.18 - 좌표도구 메뉴바 수정
* 2023.09.19 - 메모장 패널 수정(위치 이동, 탭제목 수정기능 추가)
* 2023.09.20 - 웹지도(로드뷰) 방향 설정 추가
* 2023.09.25 - 검색 및 이동 패널 분리, 좌표 복사 시 마우스 위치 정보 표시 기능 추가
* 2023.10.12 - 보간점 표시, 링크 각도 표시 기능 추가 
* 2023.10.12 - 선택한 객체 레이어 복사 기능 추가 
* 2023.10.22 - 링크 각도 표시 기능의 멀티파트 오류 수정
* 2023.11.22 - 속성필터 기능 추가
* 2023.11.26 - 속성 필터 통계값 표시 기능 추가
* 2023.12.01 - 속성 필터 위젯을 도킹 패널 형태로 개선
* 2023.12.10 - 속성 필터에서 통계 패널을 분리 및 필터 속성값 조정
* 2024.01.02 - 인증키 수정
* 2024.01.28 - 좌표변화기, 도형계산기 프로그래스바 추가
* 2024.02.28 - Ruoto 경로 탐색 오류 수정 (경유지 탐색 기능 개선 예정) - 개선 완료 2025.01.16
* 2024.03.06 - 구글스트릿뷰 수정, 속성필터 수정
* 2024.03.29 - 주변POI 카테고리 검색 추가
* 2024.04.14 - 현재위치 검색 추가
* 2024.05.23 - Vworld API key 수정
* 2024.06.03 - 필드계산기 함수 수정
* 2024.06.05 - 카카오, 루토 검색 코드 수정
* 2024.06.18 - 인덱스SHP 가상레이어 가져오기로 수정
* 2024.06.18 - 인덱스SHP 스타일 수정
* 2024.07.11 - MDB To SHP 플러그인 추가
* 2024.10.09 - 보간점 표시 심볼 수정
* 2024.10.12 - 설정 값이 레지스트리에 저장되도록 개선, API 인증키 수정
* 2024.10.15 - 좌표변환기 코드 수정
* 2024.10.16 - 도형계산기 코드 수정
* 2024.10.30 - 선택 레이어 병합 추가
* 2024.11.02 - 선택 레이어 파일 경로 열기 기능 추가 및 SHP 파일 다운로드 방식 개선
* 2024.12.07 - 좌표복사, 메모장, 좌표변환기, 도형계산기 일부 코드 수정
* 2024.12.11 - MDB To SHP UI 변경 및 코드 수정
* 2024.12.15 - 각도 표시 코드 수정 및 라벨 설정 추가
* 2024.12.17 - MacOS 설치 오류 수정 및 Coconut 좌표 이동 기능 최적화
* 2024.12.30 - 선택 객체 복사 시 동일 스타일 유지 기능 추가
* 2025.01.16 - 루토 경유지 경탐 수정
* 2025.01.20 - xyz 타일맵 불러오기 추가 경로:[ 설정 -> 플러그인 설정 -> 타일맵 추가 클릭 ]
             - QGIS 설정 초기화 추가
* 2025.02.14 - 선택 객체 복사 시 객체만 복사 또는 레이어 스타일까지 복사 여부 선택 가능
* 2025.02.17 - 툴박스 알고리즘 추가
             - Qfield Log레이어 생성, 경로의 하위 폴더 리스트 추출
* 2025.02.27 - MDB To SHP 다중 파일 일괄 추출 기능 추가
* 2025.04.12 - 화면 이동 히스토리 저장 추가
* 2025.05.08 - Qfield Log레이어 생성 코드 수정
* 2025.05.11 - 툴박스 알고리즘 추가 - 영상인식 유도선 변경 추출
* 2025.05.13 - 툴박스 알고리즘 추가 - WKT 변환기("wkt_geom"필드 활용)
* 2025.05.15 - 툴박스 알고리즘 추가 - 조사등록shp 병합
* 2025.05.16 - 툴박스 알고리즘 추가 - Qfield 조사링크 추출
* 2025.05.22 - 툴박스 알고리즘 추가 - Qfield 전기차 실사건
* 2025.05.27 - 메모장 백업 기능 추가(현재 탭의 내용 깃허브 메모장에 저장 및 가져오기)
* 2025.06.08 - 툴박스 알고리즘 추가 - SHP 파일 저장 및 ZIP 압축
* 2025.06.13 - 툴박스 알고리즘 추가 - 조사등록shp 병합 코드 수정
* 2025.06.24 - 툴박스 알고리즘 추가 - GPS로그 궤적 보정 추가
* 2025-06-29 - 속성통계 코드 수정(버전3.40 이상에서 오류 수정)
             - 툴박스 알고리즘 추가 - 키로 속성 결합(VLOOKUP)
* 2025-07-02 - 키값 생성 코드 추가(레이어 우클릭 메뉴)
		     - 레이어(전체)복사 기능 추가(레이어 우클릭 메뉴)
		     - 툴박스 알고리즘 수정 - SHP 파일 저장 및 ZIP 압축 코드 수정 (BES, GRS 단계 분리)
* 2025-07-06 - 범주 별 통계 기능 추가
             - 검색 패널 코드 수정
             - 도형계산기, 좌표변환기 처리 속도 개선
* 2025-07-10 - 네이버 거리뷰 차단으로 수정함
             - GPS로그 궤적 보정 코드 수정 및 오류 수정
* 2025-07-28 - 객체선택 히스토리 저장 추가
             - 네이버 거리뷰 위치 이격 수정
* 2025-08-01 - 시도, 시군구 행정계 SHP 수정
             - Vworld API key 수정
             - 메모장 백업 기능 제외
* 2025-08-08 - 루토 API key 수정
             - 우클릭 메뉴 신규 추가 (설정 > 플러그인 설정 > 우클릭 메뉴)
* 2025-08-14 - 좌표변환기 코드 수정
* 2025-08-22 - 도형계산기 코드 수정
* 2025-08-28 - SpeedFs, coconut 바로가기 추가
             - MDB To SHP 좌표값 X, Y 오류 수정
* 2025-09-25 - NAVER MAPS API 유료화로 관련된 코드 수정
* 2025-10-14 - 툴박스 알고리즘 수정 - 유도선 변경 추출:  예외항목-미구축대상 추가
* 2025-11-28 - 툴박스 알고리즘 수정 - 폴더 내 SHP파일 수집: 자동 증가 필드 추가
             - 도형계산기 코드수정
             - 루토 경탐 코드 수정
* 2025-12-11 - MDB To SHP 코드 수정
* 2025-12-24 - 등급분류(경계선 찾기) 기능 추가
* 2026-01-12 - 일부 코드 수정
* 2026-03-13 - 인덱스 권역, 협력사 수정
* 2026-03-25 - 26년 권역을 기본인덱스로 설정하고 25년 인덱스도 볼러올수있도록 추가(3~4개월내 삭제 예정)
* 2026-03-30 - 키값 생성 코드 수정 _ 피알이 postgreSQL서버에 있어도 필드 생성 되도록 수정
* 2026-04-03 - 피벗 테이블 기능 추가 - "GroupStats" 플러그인 이식
* 2026-04-04 - 네이버 거리뷰 수정
* 2026-04-09 - 피벗 테이블 코드 수정
* 2026-04-12 - 작업 관리자 추가(작업자 관리 및 분배 완료 취합관리)
* 2026-05-06 - 툴박스 알고리즘 추가 - 영상인식 표지판 추출
* 2026-05-19 - cython 컴파일 변환
             - 네이버 거리뷰, 주소보기 코드 수정
* 2026-05-20 - 플러그인 인증 기능 강화
             - 검색, 주변POI검색 코드 수정
* 2026-06-01 - MDB To SHP 필드 속성 필터 기능 추가(선택한 값만 SHP변환)
* 2026-06-08 - 플러그인 인증 기능 강화
* 2026-06-21 - 영상인식 추출 코드 에러 수정
* 2026-07-14 - 플러그인 인증 코드 수정, 검색 코드 수정
* 2026-07-23 - 각도표시 코드 수정, 링크 회전정보 표시 추가
* 2026-08-10 - 지도비교웹 연동 기능 추가
* 2026-08-13 - MMS좌표계 설정 추가, 플러그인 인증코드 삭제, 지도비교웹 연동 기능 추가
* 2026-09-14 - 회전정보 표시 수정 - ※ 회전정보 캐시 파일 있어야 표시가능!! 
             - 각 기능별 코드 분리 작업 완료
             - 지도비교웹 연동 기능 분리( 별도 플러그인"Map Compare Sync"으로 분리)

*****************************************************************************************************
'''

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsApplication,
                       QgsWkbTypes, 
                       QgsProject, 
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsPalLayerSettings, 
                       QgsTextFormat, 
                       QgsVectorLayerSimpleLabeling,
                       QgsSymbol,
                       QgsSimpleFillSymbolLayer,
                       QgsRendererCategory,
                       QgsCategorizedSymbolRenderer,
                       QgsMapLayer,
                       QgsCoordinateTransform,
                       Qgis)

from qgis.PyQt.QtCore import (QTimer,
                            Qt,
                            QSettings,
                            QCoreApplication)

from qgis.gui import (QgsDockWidget,
                    QgsRubberBand,
                    QgsVertexMarker)

from qgis.PyQt.QtGui import (QCursor,
                            QIcon,
                            QFont)

from qgis.PyQt.QtWidgets import (QMenu,
                                QApplication,
                                QAction,
                                QToolButton,
                                QMessageBox)

from qgis.utils import unloadPlugin, loadPlugin, startPlugin
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit

import os, sys, os.path, uuid, requests, webbrowser, random, datetime, time, math, subprocess, zipfile, processing, shutil, platform, socket
import hashlib, base64  # [추가됨] MAC 주소 해시 처리 모듈
from datetime import date  # [추가됨] 오늘 날짜 확인 모듈

from . import Coordinate_Tool_data
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
from .Coordinate_Tool_Move import CoordinateToolMove
from .Coordinate_Tool_Reverse_Geocoding import CoordinateTool_ReverseGeocoding
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Setting import CoordinateToolSetting
from .Coordinate_Tool_Path_Search import CoordinateToolPathSearch
from .Coordinate_Tool_Function import Coordinate_function
from .Coordinate_Tool_Bookmark import CoordinateToolBookmark
from .Coordinate_Tool_Converter import CoordinateToolConverter
from .Coordinate_Tool_Geometry import CoordinateToolGeometry
from .Coordinate_Tool_Memo import CoordinateToolMemo
from .Coordinate_Tool_capture import CoordinateToolcapture, CoordinateToolMediaCenter
from .Coordinate_Tool_Simple_filter import simple_filterDialog
from .Coordinate_Tool_Statistics import StatisticsDialog
from .Coordinate_Tool_fieldStatistics import fieldStatisticsDialog
from .Coordinate_Tool_Jenks import JenksDialog
from .Coordinate_Tool_GroupStats import CoordinateToolGroupStats
from .Coordinate_Tool_TaskManager import CoordinateToolTaskManager
from .Coordinate_Tool_turn import CoordinateToolTurn
from .Coordinate_Tool_angle import CoordinateToolAngle
from .Coordinate_Tool_vertex import CoordinateToolVertex
from .Coordinate_Tool_mdbToShp import CoordinateToolmdbToShp
from .Coordinate_Tool_Algorithm import Coordinate_Tool_Algorithm
from .Coordinate_Tool_Keyfield import CoordinateToolKeyfield
from .Coordinate_Tool_history import CoordinateToolHistory
from .Coordinate_Tool_LayerAction import CoordinateToolLayerAction
from .Coordinate_Tool_ShpLoader import CoordinateToolShpLoader

# ===============================================================================================================================

full_version = Qgis.QGIS_VERSION
QGIS_VERSION = f"QGIS {full_version.split('-')[0]}"  # '3.40.6'
python_path = f"C:/Program Files/{QGIS_VERSION}/bin/python.exe"
try:
    import pyperclip
except:
    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'pyperclip'])
    else:
        subprocess.check_call(['python','-m', 'pip', 'install', 'pyperclip'])
    import pyperclip

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

class CoordinateTool:
    def __init__(self, iface):
        self.iface      = iface

        # 변수값 저장 설정
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.canvas     = iface.mapCanvas()
        self.crossRb    = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.clipboard  = QApplication.clipboard()

    # 좌표도구 메뉴바 설정
        self.menu = QMenu( "좌표도구(&T)", self.iface.mainWindow().menuBar() )
        self.menu.setObjectName("'Coordinate_Tool_menu")

    # 좌표도구 툴바 설정
        self.toolbar = self.iface.addToolBar('좌표도구 툴바')
        self.toolbar.setObjectName('Coordinate_Tool_toolbar')
        self.toolbar.setToolTip('좌표도구 툴바')

        # 우클릭 메뉴
        self.setup_context_menu()

        self.copytoMMSmapTool   = None
        self.copytoSpeedFsTool  = None
        self.copytoCoconutTool  = None  
        self.MediaCenterTool    = None
        self.ShowOnMapTool      = None
        self.mapaddressTool     = None
        self.searchDialog       = None
        self.simplefilterDialog = None
        self.Converter          = None
        self.Geometry           = None
        self.GroupStats         = None
        self.TaskManager        = None
        
        self.Markers            = []
        self.chk = True
        self.Delete_Marker_timer = QTimer()

        # 플러그인 로컬 경로
        self.plugin_dir = os.path.dirname(__file__)
        # 플러그인 설정
        self.Plugin='coordinate_tool'

        # 함수
        self.Function = Coordinate_function(self,self.iface)
        # 파일 오픈
        self.shpBookmark = CoordinateToolBookmark(self,self.iface)
        # 이동
        self.indexMove = CoordinateToolMove(self, self.iface, self.iface.mainWindow())
        # mdb쉐입생성
        self.mdbToShp = CoordinateToolmdbToShp(self.iface, self.iface.mainWindow())
        # 설정
        self.dlg = CoordinateToolSetting(self,self.iface)
        # 키필드 생성
        self.addKey = CoordinateToolKeyfield(self, self.iface, self.iface.mainWindow())
        # 회전정보 모듈 초기화
        self.turnTool = CoordinateToolTurn(self, self.iface)
        # 각도표시 모듈 초기화
        self.angleTool = CoordinateToolAngle(self, self.iface)
        # 보간점 모듈 초기화
        self.vertexTool = CoordinateToolVertex(self, self.iface)
        # 알고리즘 모듈 초기화
        self.provider = Coordinate_Tool_Algorithm()
        # 히스토리 모듈 초기화 (화면 영역 + 객체 선택 히스토리 및 툴바 자동 생성)
        self.historyTool = CoordinateToolHistory(self, self.iface, self.plugin_dir)
        # 레이어 액션 모듈 초기화 (선택객체복사, 레이어복사, 선택레이어병합 우클릭 메뉴 등록)
        self.layerActionTool = CoordinateToolLayerAction(self, self.iface, self.plugin_dir)
        # SHP 파일 로더 모듈 초기화 (인덱스 및 행정계 쉐입 파일 로드)
        self.shpLoader = CoordinateToolShpLoader(self, self.iface, self.plugin_dir)

        # 검색창 위젯 설정
        self.dlgSearch = CoordinateToolSearch(self,iface)
        self.dlgSearchwidget = QgsDockWidget("검색" , self.iface.mainWindow() )
        self.dlgSearchwidget.setObjectName("검색")
        self.dlgSearchwidget.setWidget(self.dlgSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgSearchwidget )
        self.dlgSearchwidget.hide()

        # 차량경탐 위젯 설정
        self.dlgPathSearch = CoordinateToolPathSearch(self,self.iface)
        self.dlgPathSearchwidget = QgsDockWidget("경로탐색" , self.iface.mainWindow() )
        self.dlgPathSearchwidget.setObjectName("경로탐색")
        self.dlgPathSearchwidget.setWidget(self.dlgPathSearch)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgPathSearchwidget )
        self.dlgPathSearchwidget.hide()

        # 메모장 위젯 설정
        self.dlgmemo = CoordinateToolMemo(self,self.iface)
        self.dlgmemowidget = QgsDockWidget("메모장" , self.iface.mainWindow() )
        self.dlgmemowidget.setObjectName("메모장")
        self.dlgmemowidget.setWidget(self.dlgmemo)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.dlgmemowidget )
        self.dlgmemowidget.hide()

        # 필터 위젯 설정
        self.simplefilter = simple_filterDialog(self,self.iface)
        self.simplefilterwidget = QgsDockWidget("속성필터" , self.iface.mainWindow() )
        self.simplefilterwidget.setObjectName("속성필터")
        self.simplefilterwidget.setWidget(self.simplefilter)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.simplefilterwidget )
        self.simplefilterwidget.hide()

        # 통계 위젯 설정
        self.Statistics = StatisticsDialog(self,self.iface)
        self.Statisticswidget = QgsDockWidget("속성통계" , self.iface.mainWindow() )
        self.Statisticswidget.setObjectName("속성통계")
        self.Statisticswidget.setWidget(self.Statistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Statisticswidget )
        self.Statisticswidget.hide()

        # 범주 별 통계 위젯 설정
        self.fieldStatistics = fieldStatisticsDialog(self,self.iface)
        self.fieldStatistics_Widget = QgsDockWidget("범주 별 통계" , self.iface.mainWindow() )
        self.fieldStatistics_Widget.setObjectName("범주 별 통계")
        self.fieldStatistics_Widget.setWidget(self.fieldStatistics)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.fieldStatistics_Widget )
        self.fieldStatistics_Widget.hide()

        # 범주 별 통계 위젯 설정
        self.Jenks = JenksDialog(self,self.iface)
        self.Jenks_Widget = QgsDockWidget("등급 분류" , self.iface.mainWindow() )
        self.Jenks_Widget.setObjectName("등급 분류")
        self.Jenks_Widget.setWidget(self.Jenks)
        self.iface.addDockWidget( Qt.RightDockWidgetArea, self.Jenks_Widget )
        self.Jenks_Widget.hide()

    def setup_context_menu(self, *args):
        try:
            self.canvas.contextMenuAboutToShow.connect(self.show_context_menu, type=Qt.UniqueConnection)
        except Exception as e:
            print('show_context_menu Error: ' + e)
            pass
        
    def show_context_menu(self, menu, point, *args):
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, (QgsVectorLayer, QgsRasterLayer)):
            return

        menuchk = False
        # QgsMapTool에 정의된 메서드 사용
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(point.x(), point.y())
        menu.setToolTipsVisible(True)
        menu.addSeparator()

        if self.dlg.checkBox_Capture.checkState() == 2:
            point_capture = QMenu("좌표복사", menu)
            icon = QIcon(self.plugin_dir + '/icons/capture.png')
            point_capture.menuAction().setIcon(icon)
            menu.addMenu(point_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture = QAction("Bessel (FS)", self.iface.mainWindow())
            # bes_capture.setStatusTip("EPSG:4162 (Bessel)")
            bes_capture. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'Bessel_Fs'))
            point_capture.addAction(bes_capture)

            # icon = QIcon(self.plugin_dir + '/icons/bes.png')
            bes_capture_MMS = QAction("Bessel (MMS)", self.iface.mainWindow())
            bes_capture_MMS. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'Bessel_MMS'))
            point_capture.addAction(bes_capture_MMS)

            point_capture.addSeparator()

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture = QAction("GRS (FS)", self.iface.mainWindow())
            grs_capture. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'GRS_Fs'))
            point_capture.addAction(grs_capture)

            # icon = QIcon(self.plugin_dir + '/icons/grs.png')
            grs_capture_MMS = QAction("GRS (MMS)", self.iface.mainWindow())
            grs_capture_MMS. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'GRS_MMS'))
            point_capture.addAction(grs_capture_MMS)
            menuchk = True

        if self.dlg.checkBox_RoadView.checkState() == 2:
            # ShowOnMap = QMenu("로드뷰", menu)
            # icon = QIcon(self.plugin_dir + '/icons/roadview.png')
            # ShowOnMap.menuAction().setIcon(icon)
            # menu.addMenu(ShowOnMap)

            icon = QIcon(self.plugin_dir + '/icons/naver.png')
            naver_map = QAction(icon, "NAVER_거리뷰", self.iface.mainWindow())
            naver_map. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'NAVER'))
            # ShowOnMap.addAction(naver_map)
            menu.addAction(naver_map)

            icon = QIcon(self.plugin_dir + '/icons/kakao.png')
            kakao_map = QAction(icon, "KAKAO_로드뷰", self.iface.mainWindow())
            kakao_map. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'KAKAO'))
            # ShowOnMap.addAction(kakao_map)
            menu.addAction(kakao_map)
            menu.addSeparator()
            menuchk = True
        if self.dlg.checkBox_address.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
            address_action = QAction(icon, "주소 보기", self.iface.mainWindow())
            address_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4326, 'address'))
            menu.addAction(address_action)
            menuchk = True
        if self.dlg.checkBox_SpeedFS.checkState() == 2:
            icon = QIcon(self.plugin_dir + '/icons/fs.png')
            fs_action = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
            fs_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'SpeedFS'))
            menu.addAction(fs_action)
            menuchk = True

        # if self.dlg.checkBox_coconut.checkState() == 2:
            # icon = QIcon(self.plugin_dir + '/icons/coconut.png')
            # coco_action = QAction(icon, "coconut_이동", self.iface.mainWindow())
            # coco_action. triggered. connect(lambda *args: self.rClick_capture(map_pt, epsg4162, 'coconut'))
            # menu.addAction(coco_action)
            # menuchk = True

        if self.dlg.checkBox_Zoom.checkState() == 2:
            menu.addSeparator()
            icon = QIcon(self.plugin_dir + '/icons/move1.png')
            map_action1 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project3','USER:100000')).description()})", self.iface.mainWindow())
            map_action1. triggered. connect(lambda *args: self.mapMove(1,self.movemap1))
            menu.addAction(map_action1)

            icon = QIcon(self.plugin_dir + '/icons/move2.png')
            map_action2 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project4','USER:100001')).description()})", self.iface.mainWindow())
            map_action2. triggered. connect(lambda *args: self.mapMove(2,self.movemap2))
            menu.addAction(map_action2)

            icon = QIcon(self.plugin_dir + '/icons/move3.png')
            map_action3 = QAction(icon, f"좌표이동({QgsCoordinateReferenceSystem(self.QSettings.value('Project5','USER:100001')).description()})", self.iface.mainWindow())
            map_action3. triggered. connect(lambda *args: self.mapMove(3,self.movemap3))
            menu.addAction(map_action3)
            menuchk = True

        if menuchk:
            TARGETS = {"좌표 복사"}
            # 1) 기본 메뉴 중 "좌표 복사" 액션 제거
            for act in list(menu.actions()):
                sub = act.menu()                      # 서브메뉴면 QMenu, 아니면 None
                title = (sub.title() if sub else act.text() or "").replace("&", "")
                if title in TARGETS:
                    menu.removeAction(act)

    def chk_timer(self, *args):
        self.chk = True

    def rClick_capture(self, map_pt, crs, msg, *args):
        if self.copytoMMSmapTool is None:
            self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
        if self.ShowOnMapTool is None:
            self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
        clipboard_point = None
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        # 좌표값 분리
        Lon = format(map_pt[0])
        Lat = format(map_pt[1])
        # 좌표 변환
        transform   = QgsCoordinateTransform(canvasCRS, crs, QgsProject.instance())
        trans_point = transform.transform(float(Lon), float(Lat))
        point_fs    = self.Function.fscoordinate(trans_point)

        if msg == 'Bessel_Fs' or msg == 'GRS_Fs':
            # 좌표 클립보드 저장
            self.clipboard.setText(point_fs)
            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs
            self.Draw_Marker(map_pt, 1)

        elif msg == 'Bessel_MMS' or msg == 'GRS_MMS':
            fsLon = round(float(trans_point[0]*360000),3)
            fsLat = round(float(trans_point[1]*360000),3)
            fsmms = '('+str(fsLon)+','+str(fsLat)+')'

            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + fsmms
            msg = f"{msg} copied to the clipboard"
            clipboard_point = fsmms
            self.Draw_Marker(map_pt, 1)

        elif msg == 'SpeedFS':
            msg = None
            if self.chk:
                fsLon = float(trans_point[0]*360000)
                fsLat = float(trans_point[1]*360000)
                fsmms = '('+str(fsLon)+','+str(fsLat)+')'
                pyperclip.copy(fsmms)
                msg = self.copytoMMSmapTool.SpeedFS(fsmms)

                self.chk = False
                self.timer = QTimer()
                # self.timer.setSingleShot(True)
                self.timer.start(1500)
                self.timer.timeout.connect(self.chk_timer)
                self.Draw_Marker(map_pt, 1)
                
            if msg is None:
                self.chk = True
                self.timer.setSingleShot(False)
                return

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'coconut':
            point_fs = None
            msg, point_fs = self.copytoMMSmapTool.coconut(canvasCRS, map_pt)

            if msg is None:
                return
            
            # 화면에 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'address':

            ctp, sig, roadaddress, jibunaddress = self.Function.Routojoso(trans_point)

            QMessageBox.information(self.iface.mainWindow(), 'Routo' , f'# 도로명주소\n{roadaddress}\n\n# 지번주소\n{jibunaddress}')

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + roadaddress
            msg = f"{msg} copied to the clipboard"
            clipboard_point = roadaddress
            self.Draw_Marker(map_pt, 1)

        elif msg == 'NAVER':
            na = Coordinate_Tool_data.MAP_PROVIDERS[0][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[0][1]
            mapZoom = 18

            lon, lat, id = self.ShowOnMapTool.naver_panoid(map_pt, canvasCRS)

            ms = ms.replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat)).replace('{id}', str(id)) # ms.replace('{id}'
            ms = ms.replace('{zoom}', str(mapZoom))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        elif msg == 'KAKAO':
            na = Coordinate_Tool_data.MAP_PROVIDERS[6][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[6][1]
            lon, lat, id = self.ShowOnMapTool.kakaoURL(map_pt,canvasCRS)
            ms = ms.replace('{id}', str(id)).replace('{angle}', str(0)).replace('{lon}', str(lon)).replace('{lat}', str(lat))
            self.ShowOnMapTool.webbrowserOpen(na, ms, lat, lon)

            # 표출한 메세지 작성
            msg = str(msg)+' : ' + point_fs
            msg = f"{msg} copied to the clipboard"
            clipboard_point = point_fs

        self.clipboard.setText(clipboard_point)
        # 기존 메세지창 삭제
        self.iface.messageBar().clearWidgets()
        # 좌표복사 메세지 표출
        self.iface.messageBar().pushMessage(f"{msg}", level=Qgis.Info, duration=5)
        msg = None
        self.Delete_Marker_Shot(3000)

    def unload(self, *args):
        unloadPlugin(self.Plugin)

    def current_map_point(self, *args):
        # 1) 화면(글로벌) 좌표 → 2) 캔버스 좌표 → 3) 지도 좌표
        global_pt = QCursor.pos()
        canvas_pt = self.canvas.mapFromGlobal(global_pt)          # QPoint
        map_pt = self.canvas.getCoordinateTransform().toMapCoordinates(
            canvas_pt.x(), canvas_pt.y()
        )
        return map_pt  # QgsPointXY

    def initGui(self):

        # # ---------------------------------------------------------
        # # [추가됨] 인증 실패 시 플러그인 UI를 전혀 생성하지 않고 완전 차단
        # #   - 기본 기능(좌표복사 등)도 로드되지 않도록 입구에서 차단
        # # ---------------------------------------------------------
        # if not self.is_licensed:
        #     return

        # 필드계산기 함수 추가
        from .Coordinate_Tool_FieldCalculator import InitLatLonFunctions
        InitLatLonFunctions()
        # 툴박스 알고리즘 추가
        QgsApplication.processingRegistry().addProvider(self.provider)


        # 툴바 드롭다운 목록 생성
        self.copy = QToolButton(self.toolbar)
        self.copy.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.copy.setObjectName("좌표복사")

# ===========================================================================================================================

        # 메뉴 목록 생성
        Menu = QMenu()
        Menu.setObjectName('copymenu')

        # 좌표 복사
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.Coordinatecapture = QAction(icon, "좌표복사", self.iface.mainWindow())
        self.Coordinatecapture.setObjectName('좌표복사')
        self.Coordinatecapture.triggered.connect(self.capture)
        self.Coordinatecapture.setCheckable(True)
        Menu.addAction(self.Coordinatecapture)
        self.iface.registerMainWindowAction(self.Coordinatecapture, "C") 

        self.copy.addAction(self.Coordinatecapture)
        self.copy.setDefaultAction(self.Coordinatecapture)


        # 미디어센터 좌표 이동
        icon = QIcon(self.plugin_dir + '/icons/mediaCenter.png')
        self.MediaCenter = QAction(icon, "미디어센터", self.iface.mainWindow())
        self.MediaCenter.setObjectName('미디어센터')
        self.MediaCenter.triggered.connect(self.mediaCenter)
        self.MediaCenter.setCheckable(True)
        self.copy.addAction(self.MediaCenter)
        Menu.addAction(self.MediaCenter)
        self.iface.registerMainWindowAction(self.MediaCenter, "M") 

        # 주소확인
        icon = QIcon(self.plugin_dir + '/icons/address_capture.png')
        self.mapaddress = QAction(icon, "주소보기", self.iface.mainWindow())
        self.mapaddress.setObjectName('주소보기')
        self.mapaddress.triggered.connect(self.address)
        self.mapaddress.setCheckable(True)
        self.copy.addAction(self.mapaddress)
        Menu.addAction(self.mapaddress)

        icon = QIcon(self.plugin_dir + '/icons/fs.png')
        self.fs = QAction(icon, "SpeedFs_이동", self.iface.mainWindow())
        self.fs.setObjectName('SpeedFs_이동')
        self.fs.triggered.connect(lambda *args: self.rClick_capture(self.current_map_point(), epsg4162, 'SpeedFS'))
        # self.fs.setCheckable(True)
        # self.copy.addAction(self.fs)
        Menu.addAction(self.fs)
        self.iface.registerMainWindowAction(self.fs,'H')

        # icon = QIcon(self.plugin_dir + '/icons/coconut.png')
        # self.coconut = QAction(icon, "coconut_이동", self.iface.mainWindow())
        # self.coconut.setObjectName('coconut_이동')
        # self.coconut.triggered.connect(lambda *args: self.rClick_capture(self.current_map_point(), epsg4162, 'coconut'))
        # # self.fs.setCheckable(True)
        # # self.copy.addAction(self.coconut)
        # Menu.addAction(self.coconut)
        # self.iface.registerMainWindowAction(self.coconut,'Y')

    # 툴바에 드롭다운 목록 추가
        self.toolbar.addWidget( self.copy)
        # 메뉴에 드롭다운 목록 추가
        icon = QIcon(self.plugin_dir + '/icons/capture.png')
        self.copycopy = QAction(icon, '좌표,주소,미디어센터', self.iface.mainWindow())
        self.copycopy.setMenu(Menu)
        self.menu.addAction(self.copycopy)

#===============================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.movemap = QToolButton(self.toolbar)
        self.movemap.setPopupMode(QToolButton.MenuButtonPopup) # MenuButtonPopup/옆에 메뉴버튼 생성 InstantPopup/누르는 즉시 팝업 DelayedPopup/클릭후 시간 지나면 팝업
        self.movemap.setObjectName("좌표이동")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('movemenu')

        # 웹검색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/search.png')
        self.search = QAction(icon, "검색", self.iface.mainWindow())
        self.search.setObjectName('검색')
        self.search.triggered.connect(self.searchtool)
        self.search.setCheckable(True)
        self.movemap.addAction(self.search)
        self.movemap.setDefaultAction(self.search)
        Menu.addAction(self.search)
        # self.iface.registerMainWindowAction(self.search,'Shift+K')
        self.dlgSearchwidget.setToggleVisibilityAction(self.search)

    # 좌표이동 1
        icon = QIcon(self.plugin_dir + '/icons/move1.png')
        self.movemap1 = QAction(icon, "좌표이동1", self.iface.mainWindow())
        self.movemap1.setObjectName('좌표이동1')
        self.movemap1.triggered.connect(lambda *args: self.mapMove(1,self.movemap1))
        self.movemap.addAction(self.movemap1)
        # self.movemap.setDefaultAction(self.movemap1)
        Menu.addAction(self.movemap1)
        self.iface.registerMainWindowAction(self.movemap1,'B')
        # self.movemap1.setEnabled(False)

    # 좌표이동 2
        icon = QIcon(self.plugin_dir + '/icons/move2.png')
        self.movemap2 = QAction(icon, "좌표이동2", self.iface.mainWindow())
        self.movemap2.setObjectName('좌표이동2')
        self.movemap2.triggered.connect(lambda *args: self.mapMove(2,self.movemap2))
        self.movemap.addAction(self.movemap2)
        Menu.addAction(self.movemap2)
        self.iface.registerMainWindowAction(self.movemap2,'G')
        # self.movemap2.setEnabled(False)

    # 좌표이동 3
        icon = QIcon(self.plugin_dir + '/icons/move3.png')
        self.movemap3 = QAction(icon, "좌표이동3", self.iface.mainWindow())
        self.movemap3.setObjectName('좌표이동3')
        self.movemap3.triggered.connect(lambda *args: self.mapMove(3,self.movemap3))
        self.movemap.addAction(self.movemap3)
        Menu.addAction(self.movemap3)
        self.iface.registerMainWindowAction(self.movemap3,'V')
        # self.movemap3.setEnabled(False)

    # 도엽, 주소, 경위도 이동
        icon = QIcon(self.plugin_dir + '/icons/indexMove.png')
        self.moveIndex = QAction(icon, "도엽이동", self.iface.mainWindow())
        self.moveIndex.setObjectName('도엽이동')
        # self.coordinateConverter.setCheckable(True)
        self.moveIndex.triggered.connect(self.Move)
        self.movemap.addAction(self.moveIndex)
        Menu.addAction(self.moveIndex)
        self.iface.registerMainWindowAction(self.moveIndex,'Alt+F')

    # 경로탐색 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/path_search.png')
        self.path_search = QAction(icon, "경로탐색", self.iface.mainWindow())
        self.path_search.setObjectName('경로탐색')
        self.path_search.triggered.connect(lambda *args: self.DefaultAction(self.movemap, self.path_search))
        self.path_search.setCheckable(True)
        self.movemap.addAction(self.path_search)
        Menu.addAction(self.path_search)
        # self.iface.registerMainWindowAction(self.path_search,'Shift+P')
        self.dlgPathSearchwidget.setToggleVisibilityAction(self.path_search)

        self.toolbar.addWidget( self.movemap)
        
        icon = QIcon(self.plugin_dir + '/icons/move.png')
        self.movemove = QAction(icon, '좌표이동', self.iface.mainWindow())
        self.movemove.setMenu(Menu)

        self.menu.addAction(self.movemove)

#===========================================================================================================================
    # 웹지도 열기
        icon = QIcon(self.plugin_dir + '/icons/ShowOnMap.png')
        self.ShowOnmap = QAction(icon, "웹지도 열기", self.iface.mainWindow())
        self.ShowOnmap.setObjectName('웹지도 열기')
        self.ShowOnmap.triggered.connect(self.ShowOn)
        self.ShowOnmap.setCheckable(True)
        self.toolbar.addAction(self.ShowOnmap)
        # self.iface.addPluginToMenu("좌표도구", self.ShowOnmap)
        self.iface.registerMainWindowAction(self.ShowOnmap, "T") 
        # self.ShowOnmap.setEnabled(False)
        self.menu.addAction(self.ShowOnmap)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.attribute = QToolButton(self.toolbar)
        self.attribute.setPopupMode(QToolButton.MenuButtonPopup)
        self.attribute.setObjectName("속성통계필터")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('속성통계필터')

    # 피벗테이블
        icon = QIcon(self.plugin_dir + '/icons/GroupStats.png')
        self.pivot_table = QAction(icon, "피벗테이블", self.iface.mainWindow())
        self.pivot_table.setObjectName('피벗테이블')
        self.pivot_table.triggered.connect(self.pivot_table_run)
        self.attribute.setDefaultAction(self.pivot_table)
        Menu.addAction(self.pivot_table)

    # 피벗테이블
        icon = QIcon(self.plugin_dir + '/icons/tesk.png')
        self.Assigner = QAction(icon, "작업관리자", self.iface.mainWindow())
        self.Assigner.setObjectName('작업관리자')
        self.Assigner.triggered.connect(self.TaskManager_run)
        self.attribute.addAction(self.Assigner)
        Menu.addAction(self.Assigner)

    # 유일값통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics1.png')
        self.fieldUniqueStatistics = QAction(icon, "범주별통계", self.iface.mainWindow())
        self.fieldUniqueStatistics.setObjectName('범주별통계')
        self.fieldUniqueStatistics.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.fieldUniqueStatistics))
        self.fieldUniqueStatistics.setCheckable(True)
        self.attribute.addAction(self.fieldUniqueStatistics)
        # self.attribute.setDefaultAction(self.fieldUniqueStatistics)
        self.fieldStatistics_Widget.setToggleVisibilityAction(self.fieldUniqueStatistics)
        Menu.addAction(self.fieldUniqueStatistics)

    # Jenks(자연구간) 경계값 찾기 등급분류
        icon = QIcon(self.plugin_dir + '/icons/Jenks.png')
        self.Jenksfind = QAction(icon, "등급분류", self.iface.mainWindow())
        self.Jenksfind.setObjectName('등급분류')
        self.Jenksfind.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.Jenksfind))
        self.Jenksfind.setCheckable(True)
        self.attribute.addAction(self.Jenksfind)
        self.Jenks_Widget.setToggleVisibilityAction(self.Jenksfind)
        Menu.addAction(self.Jenksfind)

    # 속성필터 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/filter.png')
        self.simple_filter = QAction(icon, "속성필터", self.iface.mainWindow())
        self.simple_filter.setObjectName('속성필터')
        self.simple_filter.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.simple_filter))
        self.simple_filter.setCheckable(True)
        self.attribute.addAction(self.simple_filter)
        self.simplefilterwidget.setToggleVisibilityAction(self.simple_filter)
        Menu.addAction(self.simple_filter)

    # 속성통계 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.selectStatistics = QAction(icon, "속성통계", self.iface.mainWindow())
        self.selectStatistics.setObjectName('속성통계')
        self.selectStatistics.triggered.connect(lambda *args: self.DefaultAction(self.attribute, self.selectStatistics))
        self.selectStatistics.setCheckable(True)
        self.attribute.addAction(self.selectStatistics)
        self.Statisticswidget.setToggleVisibilityAction(self.selectStatistics)
        Menu.addAction(self.selectStatistics)

        self.toolbar.addWidget( self.attribute)

        icon = QIcon(self.plugin_dir + '/icons/Statistics.png')
        self.attr = QAction(icon, '속성통계필터', self.iface.mainWindow())
        self.attr.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)

        self.menu.addAction(self.attr)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self.geocal = QToolButton(self.toolbar)
        self.geocal.setPopupMode(QToolButton.MenuButtonPopup)
        self.geocal.setObjectName("좌표도형계산기")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('좌표도형계산기')
        
    # 좌표변환 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.coordinateConverter = QAction(icon, "좌표변환기", self.iface.mainWindow())
        self.coordinateConverter.setObjectName('좌표변환기')
        # self.coordinateConverter.setCheckable(True)
        self.coordinateConverter.triggered.connect(self.Converterwidget)
        self.geocal.addAction(self.coordinateConverter)
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.iface.registerMainWindowAction(self.coordinateConverter,'Ctrl+Shift+Q')
        Menu.addAction(self.coordinateConverter)
        # self.coordinateConverter.setEnabled(False)

    # 도형계산 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/geometry.png')
        self.coordinateGeometry = QAction(icon, "도형계산기", self.iface.mainWindow())
        self.coordinateGeometry.setObjectName('도형계산기')
        # self.coordinateGeometry.setCheckable(True)
        self.coordinateGeometry.triggered.connect(self.Geometrywidget)
        self.geocal.addAction(self.coordinateGeometry)
        self.iface.registerMainWindowAction(self.coordinateGeometry,'Ctrl+Shift+G')
        Menu.addAction(self.coordinateGeometry)
        # self.coordinateGeometry.setEnabled(False)
        
        self.toolbar.addWidget( self.geocal)
        
        icon = QIcon(self.plugin_dir + '/icons/transform.png')
        self.geo = QAction(icon, '좌표도형계산기', self.iface.mainWindow())
        self.geo.setMenu(Menu)
        # self.iface.addPluginToMenu("좌표도구" , self.geo)
        self.menu.addAction(self.geo)

#===========================================================================================================================
# [추가] 쉐입파일 툴바 및 메뉴를 이 위치(도형계산기 뒤, 추가기능 앞)에 추가!
        self.toolbar.addWidget(self.shpLoader.indexshp)
        self.menu.addAction(self.shpLoader.shp_action)

#===========================================================================================================================
    # 툴바 드롭다운 목록 생성
        self._addin = QToolButton(self.toolbar)
        self._addin.setPopupMode(QToolButton.MenuButtonPopup)
        self._addin.setObjectName("추가기능")

    # 메뉴 드롭다운 목록 생성
        Menu = QMenu()
        Menu.setObjectName('추가기능')

    # 메모 패널 열기
        icon = QIcon(self.plugin_dir + '/icons/memo.png')
        self.memo = QAction(icon, "메모장", self.iface.mainWindow())
        self.memo.setObjectName('메모장')
        self.memo.triggered.connect(self.notepad)
        self.memo.setCheckable(True)
        self._addin.addAction(self.memo)
        self._addin.setDefaultAction(self.memo)
        self.dlgmemowidget.setToggleVisibilityAction(self.memo)
        Menu.addAction(self.memo)

    # mdb to shp
        icon = QIcon(self.plugin_dir + '/icons/mdbToShp.png')
        self._mdbToShp = QAction(icon, "MDB쉐입생성", self.iface.mainWindow())
        self._mdbToShp.setObjectName('MDB쉐입생성')
        self._mdbToShp.triggered.connect(self.show_mdbToShp)
        self._addin.addAction(self._mdbToShp)
        Menu.addAction(self._mdbToShp)

    # 북마크 위젯 열기
        icon = QIcon(self.plugin_dir + '/icons/Bookmark.png')
        self.Bookmark = QAction(icon, "북마크", self.iface.mainWindow())
        self.Bookmark.setObjectName('북마크')
        self.Bookmark.triggered.connect(self.Bookmarkshp)
        self._addin.addAction(self.Bookmark)
        Menu.addAction(self.Bookmark)

    # 선택객체 각도 표기
        icon = QIcon(self.plugin_dir + '/icons/angle.png')
        self.angle = QAction(icon, "각도 표시", self.iface.mainWindow())
        self.angle.setObjectName('각도 표시')
        self.angle.setCheckable(True)
        self.angle.triggered.connect(self.angleTool.angle_run)  # self.angle_run -> self.angleTool.angle_run
        self.iface.registerMainWindowAction(self.angle,'Shift+A')
        self.menu.addAction(self.angle)

    # 선택객체 회전정보 색상 표시
        icon = QIcon(self.plugin_dir + '/icons/turn.png')
        self.turn = QAction(icon, "회전정보 표시", self.iface.mainWindow())
        self.turn.setObjectName('회전정보 표시')
        self.turn.setCheckable(True)
        self.turn.triggered.connect(self.turnTool.turn_run)  # self.turn_run -> self.turnTool.turn_run
        self.iface.registerMainWindowAction(self.turn,'Shift+T')
        self.menu.addAction(self.turn)

    # 선택객체 보간점 표시
        icon = QIcon(self.plugin_dir + '/icons/vertex.png')
        self.vertex = QAction(icon, "보간점 표시", self.iface.mainWindow())
        self.vertex.setObjectName('보간점 표시')
        self.vertex.setCheckable(True)
        self.vertex.triggered.connect(self.vertexTool.vertex_run)  # self.vertex_run -> self.vertexTool.vertex_run
        self.iface.registerMainWindowAction(self.vertex,'Shift+B')
        self.menu.addAction(self.vertex)

        self.toolbar.addWidget( self._addin)

        icon = QIcon(self.plugin_dir + '/icons/addin.png')
        self.__addin = QAction(icon, '추가기능', self.iface.mainWindow())
        self.__addin.setMenu(Menu)

        self.menu.addAction(self.__addin)

#===========================================================================================================================
    # 좌표도구 설정창
        icon = QIcon(self.plugin_dir + '/icons/setting.png')
        self.set = QAction(icon, "좌표도구설정", self.iface.mainWindow())
        self.set.setObjectName('좌표도구설정')
        self.set.triggered.connect(self.setting)
        self.set.setCheckable(True)
        self.toolbar.addAction(self.set)
        # self.iface.addPluginToMenu("좌표도구", self.set)
        self.iface.registerMainWindowAction(self.set,'F9')

        self.menu.addAction(self.set)

#===========================================================================================================================
    # Help
        icon = QIcon(self.plugin_dir + '/icons/help.png')
        self.helpAction = QAction(icon, "도움말", self.iface.mainWindow())
        self.helpAction.setObjectName('도움말')
        self.helpAction.triggered.connect(self.help)
        # self.iface.addPluginToMenu('좌표도구', self.helpAction)

        self.menu.addAction(self.helpAction)

#===========================================================================================================================
    # 상단 메뉴바에 좌표변환 메뉴 추가 
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)

#===========================================================================================================================
    # # 플러그인 확인
    #     today = datetime.date.today()
    #     yyyy = today.year
    #     # 인증 MyPlugin
    #     if yyyy > 2024:
    #         QMessageBox.information(self.iface.mainWindow(), '플러그인 재설치' , '좌표도구 플러그인 업데이트(재설치)가 필요합니다.')  
    #         self.unload()
    #     # self.toggle()

# 도움말===================================================================================================================================================================
    def help(self, *args):
        '''Display a help page'''
        url = "https://thirsty-gondola-5e1.notion.site/Coordinate-Tool-Plugin-927c0a92055648d9995529c1c5bb4243"  
        webbrowser.open(url, new=2)
        
# 플러그인 비할성화========================================================================================================================================================
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        try:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        except:
            pass

    # 메뉴삭제
        self.menu.deleteLater()

        # [추가됨] 툴바 삭제 (인증 실패 시 빈 툴바가 남는 것 방지)
        try:
            del self.toolbar
        except:
            pass

        # 히스토리 모듈 자원 해제
        if hasattr(self, 'historyTool') and self.historyTool:
            self.historyTool.unload()

        # 레이어 액션 모듈 자원 해제
        if hasattr(self, 'layerActionTool') and self.layerActionTool:
            self.layerActionTool.unload()
        # SHP 로더 모듈 자원 해제
        if hasattr(self, 'shpLoader') and self.shpLoader:
            self.shpLoader.unload()

        # 보간점, 각도, 회전정보 마크 삭제
        self.vertex.setChecked(False)
        self.vertexTool.vertexdisplay()
        self.vertexTool.remove_Marker()

        self.angle.setChecked(False)
        self.angleTool.angledisplay()
        self.angleTool.remove_Angle()

        self.turn.setChecked(False)
        self.turnTool.turndisplay()
        self.turnTool.remove_Turn()

    # 화면 정리
        try:
            self.Delete_Marker()
        except:
            pass
        # 경탐 삭제
        try:
            self.dlgPathSearch.delete()
        except:
            pass
        # 검색 삭제
        try:
            self.dlgSearch.RemoveAll()
        except:
            pass

        try:
            self.canvas.contextMenuAboutToShow.disconnect(self.show_context_menu)
        except:
            pass

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.Coordinatecapture)
        self.iface.removeToolBarIcon(self.movemap1)
        self.iface.removeToolBarIcon(self.movemap2)
        self.iface.removeToolBarIcon(self.movemap3)
        self.iface.removeToolBarIcon(self.set)

        # 툴바 삭제
        self.iface.removeToolBarIcon(self.ShowOnmap)
        self.iface.removeToolBarIcon(self.MediaCenter)
        self.iface.removeToolBarIcon(self.mapaddress)
        self.iface.removeToolBarIcon(self.moveIndex)
        self.iface.removeToolBarIcon(self.search)
        self.iface.removeToolBarIcon(self.coordinateConverter)
        self.iface.removeToolBarIcon(self.coordinateGeometry)
        self.iface.removeToolBarIcon(self.path_search)
        self.iface.removeToolBarIcon(self.Bookmark)
        self.iface.removeToolBarIcon(self.memo)
        self.iface.removeToolBarIcon(self.simple_filter)
        self.iface.removeToolBarIcon(self.selectStatistics)
        self.iface.removeToolBarIcon(self.fieldUniqueStatistics)
        self.iface.removeToolBarIcon(self.Jenksfind)
        self.iface.removeToolBarIcon(self.vertex)
        self.iface.removeToolBarIcon(self.angle)
        self.iface.removeToolBarIcon(self.turn)

        try:
            del self.toolbar
        except:
            pass

        # 필드계산기 표현식 삭제
        from .Coordinate_Tool_FieldCalculator import UnloadLatLonFunctions
        UnloadLatLonFunctions()

        # 도크 위젯 삭제
        self.iface.mainWindow().removeDockWidget(self.dlgSearchwidget)
        self.dlgSearchwidget = None
        self.dlgSearch = None
        
        self.iface.mainWindow().removeDockWidget(self.dlgPathSearchwidget)
        self.dlgPathSearchwidget = None
        self.dlgPathSearch = None

        self.iface.mainWindow().removeDockWidget(self.dlgmemowidget)
        self.dlgmemowidget = None
        self.dlgmemo = None

        self.iface.mainWindow().removeDockWidget(self.simplefilterwidget)
        self.simplefilterwidget = None
        self.simplefilter = None

        self.iface.mainWindow().removeDockWidget(self.Statisticswidget)
        self.Statisticswidget = None
        self.Statistics = None

        self.iface.mainWindow().removeDockWidget(self.fieldStatistics_Widget)
        self.fieldStatistics_Widget = None
        self.fieldStatistics = None

        self.iface.mainWindow().removeDockWidget(self.Jenks_Widget)
        self.Jenks_Widget = None
        self.Jenks = None

        # 단축키 삭제
        self.iface.unregisterMainWindowAction(self.Coordinatecapture)
        self.iface.unregisterMainWindowAction(self.movemap1)
        self.iface.unregisterMainWindowAction(self.movemap2)
        self.iface.unregisterMainWindowAction(self.movemap3)
        self.iface.unregisterMainWindowAction(self.set)
        self.iface.unregisterMainWindowAction(self.ShowOnmap)
        self.iface.unregisterMainWindowAction(self.MediaCenter)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.moveIndex)
        self.iface.unregisterMainWindowAction(self.search)
        self.iface.unregisterMainWindowAction(self.path_search)
        self.iface.unregisterMainWindowAction(self.coordinateConverter)
        self.iface.unregisterMainWindowAction(self.coordinateGeometry)
        self.iface.unregisterMainWindowAction(self.simple_filter)
        self.iface.unregisterMainWindowAction(self.memo)
        self.iface.unregisterMainWindowAction(self.vertex)
        self.iface.unregisterMainWindowAction(self.angle)
        self.iface.unregisterMainWindowAction(self.turn)
        self.iface.unregisterMainWindowAction(self.fs)
        # self.iface.unregisterMainWindowAction(self.coconut)

        # 변수값 초기화
        self.copytoMMSmapTool = None
        self.copytoSpeedFsTool = None
        self.copytoCoconutTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        mac_dir = os.path.join(os.path.dirname(self.plugin_dir), 'coordinate_tool_mac')

        if os.path.exists(mac_dir):
            shutil.rmtree(mac_dir)

# 좌표 캡쳐 실행==============================================================================================================================================================
    def capture(self, *args):
        self.copy.setDefaultAction(self.Coordinatecapture)
        if self.Coordinatecapture.isChecked():
            if self.copytoMMSmapTool is None:
                self.copytoMMSmapTool = CoordinateToolcapture(self,self.iface)
            self.copytoMMSmapTool.setAction(self.Coordinatecapture)
            self.canvas.setMapTool(self.copytoMMSmapTool)
        else:
            self.Coordinatecapture.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

            # actionVertexToolActiveLayer # 보간점 수정 현재 레이어
            # actionVertexTool # 보간점 수정 모든 레이어
            # actionSelectRadius # 반경 선택
            # actionSelectPolygon # 폴리곤 선택
            # actionSelectFreehand # 직접 그려선택
            # actionSelectRectangle # 객체선택
            # actionSelect # Select - 객체선택
            # actionPan # pan - 지도이동
            # actionAddFeature # 신규 객체 추가  
            
# 미디어센터 실행=============================================================================================================================================================
    def mediaCenter(self, *args):
        self.copy.setDefaultAction(self.MediaCenter)
        if self.MediaCenter.isChecked():
            if self.MediaCenterTool is None:
                self.MediaCenterTool = CoordinateToolMediaCenter(self,self.iface)
            self.MediaCenterTool.setAction(self.MediaCenter)
            self.canvas.setMapTool(self.MediaCenterTool)
        else:
            self.MediaCenter.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 주소 복사 실행================================================================================================================================================================
    def address(self, *args):
        # 마커 표시 삭제
        self.copy.setDefaultAction(self.mapaddress)
        self.Delete_Marker()
        if self.mapaddress.isChecked():
            if self.mapaddressTool is None:
                self.mapaddressTool = CoordinateTool_ReverseGeocoding(self,self.iface)
            self.mapaddressTool.setAction(self.mapaddress)
            self.canvas.setMapTool(self.mapaddressTool)
        else:
            self.mapaddress.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 좌표 이동 실행===============================================================================================================================================================
    def mapMove(self, idx, movemap, *args):
        clipText = self.clipboard.text().strip()
        SeqOrder=int(self.QSettings.value('ComboBox' + str(idx+2), 0))
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project' + str(idx+2),'USER:100000'))
        try:
            lon, lat = self.Function.setval(setCRS,clipText) # 복사된 좌표 X, Y 좌표 변환
            self.movemap.setDefaultAction(movemap)
            self.Function.moveto(setCRS, lon, lat, SeqOrder)
            self.canvas.refresh()
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()
        except:
            pass

# 도엽이동 실행===================================================================================================================================================================
    def Move(self, *args):
        self.movemap.setDefaultAction(self.moveIndex)
        self.Delete()
        self.canvas.refresh()
        self.indexMove.show()
        
# 검색창 실행===================================================================================================================================================================
    def searchtool(self, *args):
        self.movemap.setDefaultAction(self.search)
        self.dlgSearch.lineEdit.setFocus()

# 툴바 기본값 변경 =================================================================================================================================================================
    def DefaultAction(self, toolbar, Action, *args):
        toolbar.setDefaultAction(Action)

# 웹지도 실행==================================================================================================================================================================
    def ShowOn(self, *args):
        if self.ShowOnmap.isChecked():
            if self.ShowOnMapTool is None:
                self.ShowOnMapTool = CoordinateToolShowOnMap(self,self.iface)
            self.ShowOnMapTool.setAction(self.ShowOnmap)
            self.canvas.setMapTool(self.ShowOnMapTool)
        else:
            self.ShowOnmap.setChecked(False)
            self.iface.actionSelect().trigger()
            # self.iface.actionPan().trigger()

# 피벗테이블 실행==================================================================================================================================================================
    def pivot_table_run(self, *args):
        self.DefaultAction(self.attribute, self.pivot_table)
        if self.GroupStats is None:
            # Create the dialog and keep reference
            self.GroupStats = CoordinateToolGroupStats()

        mapLayers = QgsProject.instance().mapLayers()        # Load layers dictionary from the project
        layerList = []
        for id in mapLayers.keys():                                   # Loading layer names into the window
            if mapLayers[id].type() == QgsMapLayer.VectorLayer:
                layerList.append((mapLayers[id].name(), id))

        if len(layerList) == 0:
            QMessageBox.information(None,
                                    QCoreApplication.translate('GroupStats', 'Information'),
                                    QCoreApplication.translate('GroupStats', '벡터 레이어를 찾을 수 없습니다'))
            return
        self.GroupStats.iface = self.iface
        self.GroupStats.setLayers(layerList)
        
        # show the dialog
        self.GroupStats.show()

# 작업관리자 실행==================================================================================================================================================================
    def TaskManager_run(self, *args):
        self.DefaultAction(self.attribute, self.Assigner)
        if self.TaskManager is None:
            self.TaskManager = CoordinateToolTaskManager()

        mapLayers = QgsProject.instance().mapLayers()        # Load layers dictionary from the project
        layerList = []
        for id in mapLayers.keys():                                   # Loading layer names into the window
            if mapLayers[id].type() == QgsMapLayer.VectorLayer:
                layerList.append((mapLayers[id].name(), id))

        if len(layerList) == 0:
            QMessageBox.information(None,
                                    QCoreApplication.translate('GroupStats', 'Information'),
                                    QCoreApplication.translate('GroupStats', '벡터 레이어를 찾을 수 없습니다'))
            return
        self.TaskManager.iface = self.iface
        self.TaskManager.setLayers(layerList)
        self.TaskManager.show()

# 좌표변환 설정 ================================================================================================================================================================= 
    def Converterwidget(self, *args):
        self.geocal.setDefaultAction(self.coordinateConverter)
        self.Delete()
        if self.Converter is None:
            self.Converter = CoordinateToolConverter(self.iface, self.iface.mainWindow())
        self.Converter.show()
        
# 도형계산기 설정 ================================================================================================================================================================
    def Geometrywidget(self, *args):
        self.geocal.setDefaultAction(self.coordinateGeometry)
        self.Delete()
        if self.Geometry is None:
            self.Geometry = CoordinateToolGeometry(self.iface, self.iface.mainWindow())
        self.Geometry.show() 

# 즐겨찾기 설정 ================================================================================================================================================================= 
    def Bookmarkshp(self, *args):
        self._addin.setDefaultAction(self.Bookmark)
        self.Delete()
        self.shpBookmark.show()
        # filename = QFileDialog.getOpenFileName()

# 메모 패널 실행=====================================================================================================================================================================
    def notepad(self, *args):
        self._addin.setDefaultAction(self.memo)

    def show_mdbToShp(self, *args):
        self._addin.setDefaultAction(self._mdbToShp)
        self.Delete()
        self.mdbToShp.show()

# 설정창 실행===================================================================================================================================================================
    def setting(self, *args):
        self.Delete()
        self.dlg.show()

# 마커 삭제 설정=================================================================================================================================================================
    def Delete_Marker_Shot(self, t, *args):
        self.Delete_Marker_timer = QTimer()
        # self.timer.setSingleShot(True)
        self.Delete_Marker_timer.start(t)
        self.Delete_Marker_timer.timeout.connect(self.Delete_Marker)

# 마커 표시======================================================================================================================================================================
    def Draw_Marker(self,point,idx, *args):
        color = (self.dlg.mkColorButton_0 if idx == 0 else 
                 self.dlg.mkColorButton_1 if idx == 1 else 
                 self.dlg.mkColorButton_2 if idx == 2 else 
                 self.dlg.mkColorButton_3 if idx == 3 else 
                 self.dlg.mkColorButton_4 if idx == 4 else 
                 self.dlg.mkColorButton_1)

        # 마크삭제 중단
        self.Delete_Marker_timer.setSingleShot(False)
        
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setPenWidth(2)
        m.setIconSize(15)
        m.setIconType(QgsVertexMarker.ICON_CROSS)
        self.Markers.append(m)
        
# 마커 삭제=================================================================================================================================================================
    def Delete_Marker(self, *args):
        # global Markers
        if len(self.Markers)>0:
            for mark in self.Markers:
                self.canvas.scene().removeItem(mark)
            self.Markers = []
            self.canvas.refresh()

# 마커삭제 및 기능 끄기 ================================================================================================================================================================= 
    def Delete(self, *args): 
        # 마커 표시 삭제 
        self.Delete_Marker()
        # 다른 기능들 끄기
        self.copytoMMSmapTool = None
        self.ShowOnMapTool = None
        self.mapaddressTool = None
        self.MediaCenterTool = None

        self.ShowOnmap.setChecked(False)
        self.mapaddress.setChecked(False)
        self.Coordinatecapture.setChecked(False)
        self.mapaddress.setChecked(False)
