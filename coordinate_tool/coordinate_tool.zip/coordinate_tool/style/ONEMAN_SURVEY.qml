import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme
import QtQuick.Layouts
import "qrc:/qml" as QFieldItems

Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var positionSource: iface.findItemByObjectName("positionSource")
  property var dashBoard: iface.findItemByObjectName("dashBoard")
  property var layerTree: iface.findItemByObjectName("dashBoard").layerTree
  property var mapCanvas: iface.mapCanvas()
  property var mapSettings: iface.mapCanvas().mapSettings

  property bool isTrackingActive: false  // 트래킹 활성화 상태
  property bool followPostion: true    // true 면 gps궤적 쫒아가기, false면 gps궤적 follow stop
  property real lastScale: 0

  // property int visible_seq: ExpressionContextUtils.layerScope(dashBoard.activeLayer).variable("visible_seq");
  // property int visible_end: ExpressionContextUtils.layerScope(dashBoard.activeLayer).variable("visible_end");

  property var user: ''
  property var remark: ''

  // 좌표계설정
  property var crs4326: CoordinateReferenceSystemUtils.fromDescription("EPSG:4326")
  property var crs4301: CoordinateReferenceSystemUtils.fromDescription("EPSG:4301")
  property var crs4162: CoordinateReferenceSystemUtils.fromDescription("EPSG:4162")
  property var crs5719: CoordinateReferenceSystemUtils.fromDescription("EPSG:5719")
  property var crs3857: CoordinateReferenceSystemUtils.fromDescription("EPSG:3857")

  // MAPID
  property var mapId: ({
    0: ["4440", "4440", "4430", "4340", "4330", "3440", "3430", "3340", "3330"],
    1: ["4440", "4440", "4430", "4340", "4330", "3440", "3430", "3340", "3330"],
    2: ["4410", "4410", "4420", "4310", "4320", "3410", "3420", "3310", "3320"],
    3: ["4140", "4140", "4130", "4240", "4230", "3140", "3130", "3240", "3230"],
    4: ["4110", "4110", "4120", "4210", "4220", "3110", "3120", "3210", "3220"],
    5: ["1440", "1440", "1430", "1340", "1330", "2440", "2430", "2340", "2330"],
    6: ["1410", "1410", "1420", "1310", "1320", "2410", "2420", "2310", "2320"],
    7: ["1140", "1140", "1130", "1240", "1230", "2140", "2130", "2240", "2230"],
    8: ["1110", "1110", "1120", "1210", "1220", "2110", "2120", "2210", "2220"]
  })

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(button0) // 더미 버튼
    iface.addItemToPluginsToolbar(startTrackingButton)  // 시작 버튼
    iface.addItemToPluginsToolbar(button1) // 더미 버튼
    iface.addItemToPluginsToolbar(stopTrackingButton) // 종료 버튼
    iface.addItemToPluginsToolbar(button2) // 더미 버튼
    iface.addItemToPluginsToolbar(followGpsButton) // 락 버튼
    iface.addItemToPluginsToolbar(button3) // 더미 버튼
    iface.addItemToPluginsToolbar(pluginButton) // 다이얼로그 버튼
  }

  Connections {
    target: mapSettings
    onExtentChanged: {
      let mapCenter = mapSettings.center
      let results = parseMapid(mapCenter);
      let mapid = results.mapid
      let mapid8 = results.mapid8

      let gpsPosition = positionSource.projectedPosition
      let scale = mapSettings.scale // 현재 화면 축척(스케일)
      
      if (lastScale === scale) {  // 화면 확대, 축소시 'GPS 따라가기 중단' 방지
        if (mapCenter && gpsPosition && scale) {
          let distance = Math.floor(Math.sqrt((
            Math.pow(mapCenter.x - gpsPosition.x, 2) +
            Math.pow(mapCenter.y - gpsPosition.y, 2)) * 0.66)
          )

          // 화면 축척에 따라 거리 임계값 동적 조정 1
          // let threshold = Math.min(900, Math.max(10, scale * 0.003)); // 최소 20m ~ 최대 600m

          // 화면 축척에 따라 거리 임계값 동적 조정 2
          let threshold1 = scale * 0.02

          if (distance > threshold1) { 

            foreverTimer.stop()
            followPostion = false
            mainWindow.displayToast(qsTr("GPS 따라가기 중단\nMapID: %1")
            .arg(mapid8)
            )
          }
        }
      } else {

        lastScale = scale
      }
    }
  }

  QfToolButton {
    id: button0
    visible: true
    enabled: false
    opacity: 0
    width: 5
    height: 5 //10
  }

  // 트래킹 시작 버튼
  QfToolButton {
    id: startTrackingButton
    visible: true
    enabled: !plugin.isTrackingActive
    bgcolor: !plugin.isTrackingActive ? "green" : "rgba(128, 128, 128, 0.5)"
    iconSource: Theme.getThemeVectorIcon("ic_track_changes_black_24dp")
    iconColor: "white"
    round: true

    Text {
      text: qsTr("Start")
      anchors.centerIn: parent
      color: !plugin.isTrackingActive ? "white" : "rgba(128, 128, 128, 0.5)"
      font.bold: true
    }

    onClicked: {
      if (plugin.isTrackingActive) return

      if (!positionSource) {
        mainWindow.displayToast(qsTr("Position source not found."))
        return
      }
      if (!dashBoard.activeLayer || dashBoard.activeLayer.geometryType() != Qgis.GeometryType.Point) {
        mainWindow.displayToast(qsTr("Tracking requires an active GPS point layer."))
        return
      }

      start()
      plugin.isTrackingActive = true      
    }
  }

  QfToolButton {
    id: button1
    visible: true
    enabled: false
    opacity: 0
    width: 5
    height: 5 // 30
  }

  // 트래킹 중지 버튼
  QfToolButton {
    id: stopTrackingButton
    visible: true
    enabled: plugin.isTrackingActive
    bgcolor: plugin.isTrackingActive ? "red" : "rgba(128, 128, 128, 0.1)"
    iconSource: Theme.getThemeVectorIcon("ic_stop_black_24dp")
    iconColor: "white"
    round: true

    Text {
      text: qsTr("Stop")
      anchors.centerIn: parent
      color: plugin.isTrackingActive ? "white" : "rgba(128, 128, 128, 0.5)"
      font.bold: true
    }

    onClicked: {
      if (!plugin.isTrackingActive) return
      stop()
      plugin.isTrackingActive = false
    }
  }

  QfToolButton {
    id: button2
    visible: true
    enabled: false
    opacity: 0
    width: 5
    height: 5 //30
  }

  // GPS 따라가기 버튼
  QfToolButton {
    id: followGpsButton
    visible: true
    bgcolor: followPostion ? "green": "gray" // 사용자가 지도를 움직이면 회색
    iconSource: Theme.getThemeVectorIcon("ic_my_location_black_24dp")
    iconColor: "white"
    round: true

    Text {
      text: qsTr("lock")
      anchors.centerIn: parent
      color: "white"
      font.bold: true
    }

    onClicked: {
      foreverTimer.start() // 화면 중심 따라가기 다시 활성화
      followPostion = true // 사용자 인터랙션 해제
      moveCenter()
      mainWindow.displayToast(qsTr("GPS 따라가기 활성화"))
    }
  }
  
  QfToolButton {
    id: button3
    visible: true
    enabled: false
    opacity: 0
    width: 5
    height: 5 //130
  }

  QfToolButton {
    id: pluginButton
    bgcolor: !plugin.isTrackingActive ? Theme.darkGraySemiOpaque : Theme.gray
    round: true

    Text {
      anchors.centerIn: parent
      text: "Dialog"
      color: !plugin.isTrackingActive ? Theme.light : Theme.gray
      font.bold: true
    }

    onClicked: {
      dialog.open();
    }
  }

  // Määritellään dialogikomponentti
  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    // 다이얼로그 제목 설정
    // title: "조사 등록"
    // visible: false
    // modal: true
    // focus: true
    // font: Theme.defaultFont

    // 다이얼로그 위치 설정
    x: (parent.width - width) / 2
    y: (parent.height - height) / 4

    //다이얼로그 크기 설정
    width: Math.max(200,Math.min(400, parent.width / 1.5))
    // height: Math.max(300, Math.min(500, parent.height / 2))

    standardButtons: Dialog.Close // | Dialog.Save // 저장 및 닫기 버튼 추가

    // Save
    onAccepted:{
        saveData(); // 데이터 저장 함수 호출
    }

    // Close
    onRejected:{

    }

    ColumnLayout {
      spacing: 10

      // Label {
      //     text: "• 조사등록"
      //     font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
      //     font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
      //     font.bold: true       // 굵게 (선택 사항)
      //     color: "black"          // 색상 변경 테스트
      //     Layout.fillWidth: true
      //     Layout.preferredHeight: 20
      //     // font: Theme.defaultFont
      //     // color: Theme.mainTextColor
      // }

      // RowLayout {
      //   Layout.fillWidth: true
      //   Layout.preferredHeight: 30
      //   // Label {
      //   //   text: "Input 1:"
      //   //   font: Theme.defaultFont
      //   //   color: Theme.mainTextColor
      //   //   Layout.fillWidth: true
      //   // }

      //   Label {
      //     id: inputLabel1
      //     text: "SEQ:"
      //     font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
      //     font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
      //     font.bold: false       // 굵게 (선택 사항)
      //     color: "black"          // 색상 변경 테스트
      //     Layout.fillWidth: true
      //   }

      //   // lisätään teksikenttä, johon käyttäjä
      //   // voi kirjoittaa tekstiä
      //   QfTextField {
      //     id: inputText1
      //     text: visible_seq

      //     // Layout.fillWidth: true
      //     Layout.preferredWidth: dialog.width - inputLabel1.width - 60
      //     // Layout.preferredHeight: 40

      //     horizontalAlignment: TextInput.AlignHCenter

      //     font: Theme.defaultFont

      //     enabled: true
      //     visible: true
      //   }

      //   // QfToolButton {
      //   //   id: inputTextButton1

      //   //   bgcolor: Theme.darkGraySemiOpaque
      //   //   round: true
      //   //   width: 50
      //   //   height: 30

      //   //   Text {
      //   //     anchors.centerIn: parent
      //   //     text: "저장"
      //   //     color: Theme.light
      //   //     font.bold: true
      //   //   }

      //   //   onClicked: {
      //   //     // näytetään tekstikentän teksti
      //   //     mainWindow.displayToast(inputText1.text);
      //   //   }
      //   // }
      // }

      // RowLayout {
      //   Layout.fillWidth: true
      //   Layout.preferredHeight: 30

      //   Label {
      //     id: inputLabel2
      //     text: "특이사항:"
      //     font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
      //     font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
      //     font.bold: false       // 굵게 (선택 사항)
      //     color: "black"          // 색상 변경 테스트
      //     Layout.fillWidth: true
      //   }

      //   QfTextField {
      //     id: inputText2
      //     text: remark

      //     // Layout.fillWidth: true
      //     Layout.preferredWidth: dialog.width - inputLabel1.width - 60
      //     // Layout.preferredHeight: 40// font.height + 20

      //     horizontalAlignment: TextInput.AlignHCenter

      //     font: Theme.defaultFont

      //     enabled: true
      //     visible: true
      //   }
      //   // QfToolButton {
      //   //   id: inputTextButton2

      //   //   bgcolor: Theme.darkGraySemiOpaque
      //   //   round: true
      //   //   width: 50
      //   //   height: 30

      //   //   Text {
      //   //     anchors.centerIn: parent
      //   //     text: "저장"
      //   //     color: Theme.light
      //   //     font.bold: true
      //   //   }

      //   //   onClicked: {
      //   //     // näytetään tekstikentän teksti
      //   //     mainWindow.displayToast(inputText2.text);
      //   //   }
      //   // }
      // }

      // RowLayout {
      //   Layout.fillWidth: true
      //   Layout.preferredHeight: 30

      //   Label {
      //     id: inputLabel3
      //     text: "작성자:"
      //     font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
      //     font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
      //     font.bold: false       // 굵게 (선택 사항)
      //     color: "black"          // 색상 변경 테스트
      //     Layout.fillWidth: true
      //   }

      //   QfTextField {
      //     id: inputText3
      //     text: user

      //     // Layout.fillWidth: true
      //     Layout.preferredWidth: dialog.width - inputLabel1.width - 60
      //     // Layout.preferredHeight: 40// font.height + 20

      //     horizontalAlignment: TextInput.AlignHCenter

      //     font: Theme.defaultFont

      //     enabled: true
      //     visible: true
      //   }
      //   // QfToolButton {
      //   //   id: inputTextButton3

      //   //   bgcolor: Theme.darkGraySemiOpaque
      //   //   round: true
      //   //   width: 50
      //   //   height: 30

      //   //   Text {
      //   //     anchors.centerIn: parent
      //   //     text: "저장"
      //   //     color: Theme.light
      //   //     font.bold: true
      //   //   }

      //   //   onClicked: {
      //   //     // näytetään tekstikentän teksti
      //   //     mainWindow.displayToast(inputText3.text);
      //   //   }
      //   // }
      // }

      // // 현재 레이어 목록 가져오기
      // // RowLayout {
      // //   Layout.fillWidth: true

      // //   Label {
      // //     text: "List layers"
      // //     font: Theme.defaultFont
      // //     color: Theme.mainTextColor

      // //     Layout.fillWidth: true
      // //   }

      // //   QfToolButton {
      // //     id: listLayersButton

      // //     bgcolor: Theme.darkGraySemiOpaque
      // //     round: true

      // //     Text {
      // //       anchors.centerIn: parent
      // //       text: "List"
      // //       color: Theme.light
      // //     }

      // //     onClicked: {
      // //       let list = "Layers:";

      // //       // iteroidaan layerTree-olion rivejä
      // //       for (let i = 0; i < layerTree.rowCount(); i++) {
      // //         let index = layerTree.index(i, 0);
      // //         // haetaan tason nimi
      // //         let name = layerTree.data(index, FlatLayerTreeModel.Name);
      // //         list = list.concat("\n", name);
      // //       }

      // //       mainWindow.displayToast(list);
      // //     }
      // //   }
      // // }

      // // 빈줄 추가
      // Label {
      //   text: ""
      //   font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
      //   font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
      //   font.bold: true       // 굵게 (선택 사항)
      //   color: "black"          // 색상 변경 테스트
      //   Layout.fillWidth: true
      //   Layout.preferredHeight: 40
      //   // font: Theme.defaultFont
      //   // color: Theme.mainTextColor
      // }

      // 라벨 추가
      Label {
        text: "• 좌표.도엽 이동"
        font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
        font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
        font.bold: true       // 굵게 (선택 사항)
        color: "black"          // 색상 변경 테스트
        Layout.fillWidth: true
        Layout.preferredHeight: 20
        // font: Theme.defaultFont
        // color: Theme.mainTextColor
      }

      RowLayout {
        Layout.fillWidth: true
        Layout.preferredHeight: 30

        Label {
          id: inputLabel1
          text: "MapID:"
          font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
          font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
          font.bold: false       // 굵게 (선택 사항)
          color: "black"          // 색상 변경 테스트
          Layout.fillWidth: true
        }

        QfTextField {
          id: mapid
          text: ""

          // Layout.fillWidth: true
          Layout.preferredWidth: dialog.width - inputLabel1.width - moveButton1.width - 60
          // Layout.preferredHeight: font.height + 20

          horizontalAlignment: TextInput.AlignHCenter

          font: Theme.defaultFont

          enabled: true
          visible: true

          inputMethodHints: Qt.ImhFormattedNumbersOnly
        }

        QfToolButton {
          id: moveButton1

          bgcolor: Theme.darkGraySemiOpaque
          round: true
          width: 50
          height: 30

          Text {
            anchors.centerIn: parent
            text: "이동"
            color: Theme.light
            font.bold: true       // 굵게 (선택 사항)
          }

          onClicked: {
            let MapID = mapid.text.trim(); // 입력값을 문자열로 가져오고 공백 제거
            if (MapID.length >= 4) {
              // MapID가 숫자로만 이루어져 있는지 확인
              if (!/^\d{4}$/.test(MapID)) {
                  mainWindow.displayToast(qsTr("MapID는 숫자 4자리여야 합니다."));
                  return;
              }

              MapID = MapID.substring(0, 4); // JavaScript에서 문자열의 첫 4자리만 가져오기
              let map1 = parseInt(MapID[0], 10);
              let map2 = parseInt(MapID[1], 10);
              let map3 = parseInt(MapID[2], 10);
              let map4 = parseInt(MapID[3], 10);

              // 도엽 중앙 좌표값 추출
              let x = (43897500 + (map1 * 360000) + (45000 * map3)) / 360000;
              let y = (11625000 + (map2 * 240000) + (30000 * map4)) / 360000;

              let point = GeometryUtils.point(x, y);

              // 최종적으로 프로젝트 좌표계로 변환 도엽중심좌표(베셀) >>  화면좌표계
              let reprojected_point = GeometryUtils.reprojectPoint(point, crs4162, mapSettings.destinationCrs);

              // 도엽중심으로 이동
              mapSettings.setCenter(reprojected_point);

              // 입력값 삭제
              mapid.text = "";

              // 다이얼로그 닫기
              dialog.close();

            } else {
              mainWindow.displayToast(qsTr("MapID가 없습니다."))
            }
          }
        }
      }

      RowLayout {
        Layout.fillWidth: true
        Layout.preferredHeight: 30

        Label {
          text: "Bessel:"
          font.family: "Arial"  // 특정 폰트 패밀리 설정 (선택 사항)
          font.pixelSize: 16    // 폰트 크기 (픽셀 단위)
          font.bold: false       // 굵게 (선택 사항)
          color: "black"          // 색상 변경 테스트
          Layout.fillWidth: true
        }

        QfTextField {
          id: xyField
          text: ""

          // Layout.fillWidth: true
          Layout.preferredWidth: dialog.width - inputLabel1.width - moveButton2.width - 60
          // Layout.preferredHeight: font.height + 20

          horizontalAlignment: TextInput.AlignHCenter

          font: Theme.defaultFont

          enabled: true
          visible: true
        }

        QfToolButton {
          id: moveButton2

          bgcolor: Theme.darkGraySemiOpaque
          round: true
          width: 50
          height: 30

          Text {
            anchors.centerIn: parent
            text: "이동"
            color: Theme.light
            font.bold: true    // 굵게 (선택 사항)
          }

          onClicked: {
            let text = xyField.text.trim();
            let result = parseCoordinates(text);

            if (result === null) {
              return;
            }
            let point = GeometryUtils.point(result.lon, result.lat);

            // 최종적으로 프로젝트 좌표계로 변환 도엽중심좌표(베셀) >>  화면좌표계
            let reprojected_point = GeometryUtils.reprojectPoint(point, crs4162, mapSettings.destinationCrs);
            
            // 좌표로 이동
            mapSettings.setCenter(reprojected_point);

            // 입력값 삭제
            xyField.text = "";

            // 다이얼로그 닫기
            dialog.close();
          }
        }
      }
    }
  }

  Timer {
    id: foreverTimer
    interval: 1000 // 1초 간격
    repeat: true
    running: true // QField 시작 시 자동으로 실행
    onTriggered: {
      if (positionSource.active && followPostion) { // 사용자가 지도를 움직이나?
        moveCenter()
      }
    }
  }

  // 트래킹 시작
  function start() {
    pluginButton.enabled = false

    // visible_seq = visible_seq + 1
    ExpressionContextUtils.setLayerVariable(dashBoard.activeLayer, "visible_flag", '1' );
    // ExpressionContextUtils.setLayerVariable(dashBoard.activeLayer, "visible_seq", visible_seq );
    mainWindow.displayToast(qsTr("조사 시작"))
    // mainWindow.displayToast(qsTr("시작\nROUTE_SEQ:%1")
    // .arg(visible_seq)
    // );
  }

  // 트래킹 종료
  function stop() {
    pluginButton.enabled = true
    ExpressionContextUtils.setLayerVariable(dashBoard.activeLayer, "visible_flag", '0' );
    mainWindow.displayToast(qsTr("조사 종료"))
  }

  // 화면 중심 이동
  function moveCenter() {
    let position = positionSource.projectedPosition
    if(position){
      mapSettings.setCenter(position, true)
    }
  }

  function saveData() {
    visible_seq = parseInt(inputText1.text.trim());
    remark = inputText2.text.trim();
    user = inputText3.text.trim();
    mainWindow.displayToast(qsTr("데이터가 저장되었습니다.\nSEQ:%1\n특이사항:%2\n작성자:%3")
    .arg(visible_seq)
    .arg(remark)
    .arg(user)
    );

    // 다이얼로그 닫기
    dialog.close();
  }

  function parseMapid(mapCenter) {

    // 현재 좌표값을 Bessel 좌표로 변환
    let reprojected_point = GeometryUtils.reprojectPoint(mapCenter, mapSettings.destinationCrs, crs4301);

    // bessel 좌표로 도엽번호 추출
    let lon = parseInt(reprojected_point.x * 360000);
    let lat = parseInt(reprojected_point.y * 360000);

    // mapid 계산
    let map1 = parseInt(((Math.round((lon - 44617500) / 45000) - 1) / 8) + 2).toString();
    let map2 = parseInt(((Math.round((lat - 11865000) / 30000) - 1) / 8) + 1).toString();
    let map3 = parseInt((Math.round((lon - 44617500) / 45000) + 8) -
                (Math.ceil(Math.round((lon - 44617500) / 45000) / 8) * 8)).toString();
    let map4 = parseInt((Math.round((lat - 11865000) / 30000) + 8) -
                (Math.ceil(Math.round((lat - 11865000) / 30000) / 8) * 8)).toString();
    // 최종 mapid 생성
    let mapid = map1 + map2 + map3 + map4;
    
    var row = parseInt((Math.abs((lat-11880000)-(parseInt((lat-11880000)/30000)*30000))+30000)/3750)-7
    var col = parseInt((Math.abs((lon-44640000)-(parseInt((lon-44640000)/45000)*45000))+45000)/5625)-7
    
    let mapid_Info = mapId[row];
    var mapid8;  // 미리 선언

    if (mapid_Info !== undefined) {
      let idx = mapid_Info[col];
      mapid8 = mapid + idx;
    } else {
      mapid8 = mapid + '0000';
    }
    return {mapid: mapid, mapid8: mapid8}
  }

  function parseCoordinates(text) {
    // 텍스트가 비어 있거나 null인 경우 처리
    if (!text || text.trim() === '') {
        mainWindow.displayToast(qsTr("입력값이 비어 있습니다."));
        return null; // 유효하지 않으면 null 반환
    }

    // MMS 좌표 괄호 포함
    if (text[0] === '(' && text[text.length - 1] === ')') {
        try {
            text = text.slice(1, -1).trim(); // 괄호 제거
            let coords = text.split(',');
            if (coords.length !== 2) {
                mainWindow.displayToast(qsTr("MMS 좌표 형식이 잘못되었습니다."));
                return null;
            }
            let lon = parseFloat(coords[0].trim()) / 360000;
            let lat = parseFloat(coords[1].trim()) / 360000;
            if (isNaN(lon) || isNaN(lat)) {
                mainWindow.displayToast(qsTr("좌표 값이 잘못되었습니다."));
                return null;
            }
            return { lon: lon, lat: lat };

        } catch (e) {
            mainWindow.displayToast(qsTr("MMS 좌표 처리 중 오류가 발생했습니다."));
            return null;
        }

    // FS 좌표
    } else if (text[4] === '(' && text[11] === ')') {
        try {
            text = text.slice(13,-1).trim(); // 괄호 제거
            let coords = text.split('/');
            if (coords.length !== 2) {
                mainWindow.displayToast(qsTr("FS 좌표 형식이 잘못되었습니다."));
                return null;
            }
            let lon = coords[0].trim();
            let lat = coords[1].trim();

            let lonParts = lon.split('.');
            let latParts = lat.split('.');

            if (lonParts.length !== 4 || latParts.length !== 4) {
                mainWindow.displayToast(qsTr("FS 좌표 값이 잘못되었습니다."));
                return null;
            }

            let lon2 = lonParts[2] + '.' + lonParts[3];
            lon2 = parseFloat(lon2) / 60;
            let lon1 = ((parseInt(lonParts[1]) + lon2) / 60).toFixed(8);
            lon = parseInt(lonParts[0]) + parseFloat(lon1);

            let lat2 = latParts[2] + '.' + latParts[3];
            lat2 = parseFloat(lat2) / 60;
            let lat1 = ((parseInt(latParts[1]) + lat2) / 60).toFixed(8);
            lat = parseInt(latParts[0]) + parseFloat(lat1);
            return { lon: lon, lat: lat };

        } catch (e) {
            mainWindow.displayToast(qsTr("FS 좌표 처리 중 오류가 발생했습니다."));
            return null;
        }

    // MMS 좌표 괄호 미포함
    } else if (text[0] === '4' || text[0] === '1') {

        try {
            let lon, lat;
            if (text.indexOf(',') > 0) {
                let coords = text.split(',');
                if (coords.length !== 2) {
                    mainWindow.displayToast(qsTr("MMS 좌표 형식이 잘못되었습니다."));
                    return null;
                }
                lon = coords[0];
                lat = coords[1];
            } else if (text.indexOf(' ') > 0) {
                let coords = text.split(' ');
                lon = coords[0];
                lat = coords[1];
            } else if (text.indexOf('\t') > 0) {
                let coords = text.split('\t');
                lon = coords[0];
                lat = coords[1];
            } else if (text.indexOf('/') > 0) {
                let coords = text.split('/');
                lon = coords[0];
                lat = coords[1];
            } else {
                mainWindow.displayToast(qsTr("잘못된 MMS 좌표 형식입니다."));
                return null;
            }

            lon = parseFloat(lon) / 360000;
            lat = parseFloat(lat) / 360000;

            if (isNaN(lon) || isNaN(lat)) {
                mainWindow.displayToast(qsTr("좌표 값이 잘못되었습니다."));
                return null;
            }

            return { lon: lon, lat: lat };

        } catch (e) {
            mainWindow.displayToast(qsTr("MMS 좌표 처리 중 오류가 발생했습니다."));
            return null;
        }

    } else {
        mainWindow.displayToast(qsTr("지원되지 않는 좌표 형식입니다."));
        return null;
    }
  }
}