<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" maxScale="0" styleCategories="AllStyleCategories" labelsEnabled="0" simplifyLocal="1" simplifyAlgorithm="0" readOnly="0" simplifyDrawingTol="1" minScale="100000000" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="1" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" accumulate="0" endField="" durationUnit="min" mode="0" startField="" durationField="" enabled="0" limitMode="0" startExpression="" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation type="IndividualFeatures" extrusion="0" symbology="Line" zoffset="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" binding="Centroid" extrusionEnabled="0" clamping="Terrain" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" alpha="1" force_rhr="0" frame_rate="10" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="232,113,141,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" alpha="1" force_rhr="0" frame_rate="10" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="232,113,141,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="166,81,101,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" alpha="1" force_rhr="0" frame_rate="10" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="232,113,141,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="166,81,101,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="RuleRenderer" forceraster="0" referencescale="-1" symbollevels="0" enableorderby="0">
    <rules key="{66c84acc-ff51-408c-9644-e860c72d1fb8}">
      <rule filter="&quot;일정분배&quot; = '본사'" symbol="0" label="본사" key="{76e33188-7f88-41e7-b689-d2e2ddb8357b}"/>
      <rule filter="&quot;일정분배&quot; = '광주'" symbol="1" label="광주" key="{41b72307-817b-4aa6-ab2d-418827e3dc5e}"/>
      <rule filter="&quot;일정분배&quot; = '대구'" symbol="2" label="대구" key="{2578ae42-b9da-465d-84af-9a8ee068a7bb}"/>
      <rule filter="&quot;협력사&quot; = '매스코' and   &quot;일반도로_sum&quot;  is not null" checkstate="0" symbol="3" label="매스코" key="{b7335562-b909-4244-b38f-1de30a2ee2ad}"/>
      <rule filter="&quot;협력사&quot; = '웨이즈원'" checkstate="0" symbol="4" label="웨이즈원" key="{7474f0b9-e6d4-46f9-a071-8c2417e6d79c}"/>
      <rule filter="&quot;협력사&quot; = '티아이랩'" checkstate="0" symbol="5" label="티아이랩" key="{cdd75ffa-81a9-4fef-b7e4-340d8126c2af}"/>
    </rules>
    <symbols>
      <symbol type="fill" alpha="0.4" force_rhr="0" frame_rate="10" name="0" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="GradientFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="66,150,63,255" name="color"/>
            <Option type="QString" value="0,0,255,255" name="color1"/>
            <Option type="QString" value="0,255,0,255" name="color2"/>
            <Option type="QString" value="0" name="color_type"/>
            <Option type="QString" value="0" name="coordinate_mode"/>
            <Option type="QString" value="ccw" name="direction"/>
            <Option type="QString" value="0" name="discrete"/>
            <Option type="QString" value="102,230,97,255" name="gradient_color2"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="gradient" name="rampType"/>
            <Option type="QString" value="0.5,0" name="reference_point1"/>
            <Option type="QString" value="0" name="reference_point1_iscentroid"/>
            <Option type="QString" value="0.5,1" name="reference_point2"/>
            <Option type="QString" value="0" name="reference_point2_iscentroid"/>
            <Option type="QString" value="rgb" name="spec"/>
            <Option type="QString" value="0" name="spread"/>
            <Option type="QString" value="0" name="type"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="77,175,74,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="56,128,54,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" alpha="0.4" force_rhr="0" frame_rate="10" name="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="GradientFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="194,94,0,255" name="color"/>
            <Option type="QString" value="0,0,255,255" name="color1"/>
            <Option type="QString" value="0,255,0,255" name="color2"/>
            <Option type="QString" value="0" name="color_type"/>
            <Option type="QString" value="0" name="coordinate_mode"/>
            <Option type="QString" value="ccw" name="direction"/>
            <Option type="QString" value="0" name="discrete"/>
            <Option type="QString" value="255,163,0,255" name="gradient_color2"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="gradient" name="rampType"/>
            <Option type="QString" value="0.5,0" name="reference_point1"/>
            <Option type="QString" value="0" name="reference_point1_iscentroid"/>
            <Option type="QString" value="0.5,1" name="reference_point2"/>
            <Option type="QString" value="0" name="reference_point2_iscentroid"/>
            <Option type="QString" value="rgb" name="spec"/>
            <Option type="QString" value="0" name="spread"/>
            <Option type="QString" value="0" name="type"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="255,127,0,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="128,62,0,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="1.8515" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="ccw" name="direction"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="rgb" name="spec"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="ccw" name="direction"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="rgb" name="spec"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" alpha="0.4" force_rhr="0" frame_rate="10" name="2" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="GradientFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="93,48,100,255" name="color"/>
            <Option type="QString" value="0,0,255,255" name="color1"/>
            <Option type="QString" value="0,255,0,255" name="color2"/>
            <Option type="QString" value="0" name="color_type"/>
            <Option type="QString" value="0" name="coordinate_mode"/>
            <Option type="QString" value="ccw" name="direction"/>
            <Option type="QString" value="0" name="discrete"/>
            <Option type="QString" value="170,87,183,255" name="gradient_color2"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="gradient" name="rampType"/>
            <Option type="QString" value="0.5,0" name="reference_point1"/>
            <Option type="QString" value="0" name="reference_point1_iscentroid"/>
            <Option type="QString" value="0.5,1" name="reference_point2"/>
            <Option type="QString" value="0" name="reference_point2_iscentroid"/>
            <Option type="QString" value="rgb" name="spec"/>
            <Option type="QString" value="0" name="spread"/>
            <Option type="QString" value="0" name="type"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="152,78,163,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="119,61,128,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" alpha="1" force_rhr="0" frame_rate="10" name="3" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="1" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="147,165,218,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0,156,125,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.3" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" alpha="0.5" force_rhr="0" frame_rate="10" name="4" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="61,163,191,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="152,152,152,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.1" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" alpha="0.5" force_rhr="0" frame_rate="10" name="5" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="61,163,191,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="152,152,152,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.1" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="no" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option type="QString" value="offline" name="QFieldSync/action"/>
      <Option type="QString" value="{}" name="QFieldSync/attachment_naming"/>
      <Option type="QString" value="" name="QFieldSync/attribute_editing_locked_expression"/>
      <Option type="QString" value="offline" name="QFieldSync/cloud_action"/>
      <Option type="QString" value="" name="QFieldSync/feature_addition_locked_expression"/>
      <Option type="QString" value="" name="QFieldSync/feature_deletion_locked_expression"/>
      <Option type="QString" value="" name="QFieldSync/geometry_editing_locked_expression"/>
      <Option type="QString" value="{}" name="QFieldSync/photo_naming"/>
      <Option type="QString" value="{}" name="QFieldSync/relationship_maximum_visible"/>
      <Option type="int" value="30" name="QFieldSync/tracking_distance_requirement_minimum_meters"/>
      <Option type="int" value="1" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters"/>
      <Option type="int" value="0" name="QFieldSync/tracking_measurement_type"/>
      <Option type="int" value="30" name="QFieldSync/tracking_time_requirement_interval_seconds"/>
      <Option type="int" value="0" name="QFieldSync/value_map_button_interface_threshold"/>
      <Option type="int" value="0" name="embeddedWidgets/count"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory minimumSize="0" opacity="1" diagramOrientation="Up" backgroundColor="#ffffff" spacing="5" enabled="0" barWidth="5" penColor="#000000" lineSizeType="MM" sizeType="MM" maxScaleDenominator="1e+08" sizeScale="3x:0,0,0,0,0,0" scaleBasedVisibility="0" showAxis="1" scaleDependency="Area" labelPlacementMethod="XHeight" spacingUnit="MM" width="15" penWidth="0" minScaleDenominator="0" penAlpha="255" spacingUnitScale="3x:0,0,0,0,0,0" direction="0" height="15" rotationOffset="270" lineSizeScale="3x:0,0,0,0,0,0" backgroundAlpha="255">
      <fontProperties strikethrough="0" bold="0" description="Gulim,9,-1,5,50,0,0,0,0,0" underline="0" style="" italic="0"/>
      <attribute field="" label="" colorOpacity="1" color="#000000"/>
      <axisSymbol>
        <symbol type="line" alpha="1" force_rhr="0" frame_rate="10" name="" clip_to_extent="1" is_animated="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" pass="0" class="SimpleLine" enabled="1">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" zIndex="0" obstacle="0" priority="0" dist="0" linePlacementFlags="18" placement="1">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" value="0" name="allowedGapsBuffer"/>
        <Option type="bool" value="false" name="allowedGapsEnabled"/>
        <Option type="QString" value="" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="map_id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="map_id_str">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="sig_cd">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="sig_eng_nm">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="sig_kor_nm">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ctprvn_cd">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ctp_eng_nm">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ctp_kor_nm">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="구분">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="대권역">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="소권역">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="21년">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="22년">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="담당">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="협력사">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="일정분배">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="자전도">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="일반도로">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="고속~도시">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="국도~주2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="고속~국도,자전도">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="지방도~주2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="map_id" name=""/>
    <alias index="1" field="map_id_str" name=""/>
    <alias index="2" field="sig_cd" name=""/>
    <alias index="3" field="sig_eng_nm" name=""/>
    <alias index="4" field="sig_kor_nm" name=""/>
    <alias index="5" field="ctprvn_cd" name=""/>
    <alias index="6" field="ctp_eng_nm" name=""/>
    <alias index="7" field="ctp_kor_nm" name=""/>
    <alias index="8" field="구분" name=""/>
    <alias index="9" field="대권역" name=""/>
    <alias index="10" field="소권역" name=""/>
    <alias index="11" field="21년" name=""/>
    <alias index="12" field="22년" name=""/>
    <alias index="13" field="담당" name=""/>
    <alias index="14" field="협력사" name=""/>
    <alias index="15" field="일정분배" name=""/>
    <alias index="16" field="자전도" name=""/>
    <alias index="17" field="일반도로" name=""/>
    <alias index="18" field="고속~도시" name=""/>
    <alias index="19" field="국도~주2" name=""/>
    <alias index="20" field="고속~국도,자전도" name=""/>
    <alias index="21" field="지방도~주2" name=""/>
  </aliases>
  <defaults>
    <default field="map_id" applyOnUpdate="0" expression=""/>
    <default field="map_id_str" applyOnUpdate="0" expression=""/>
    <default field="sig_cd" applyOnUpdate="0" expression=""/>
    <default field="sig_eng_nm" applyOnUpdate="0" expression=""/>
    <default field="sig_kor_nm" applyOnUpdate="0" expression=""/>
    <default field="ctprvn_cd" applyOnUpdate="0" expression=""/>
    <default field="ctp_eng_nm" applyOnUpdate="0" expression=""/>
    <default field="ctp_kor_nm" applyOnUpdate="0" expression=""/>
    <default field="구분" applyOnUpdate="0" expression=""/>
    <default field="대권역" applyOnUpdate="0" expression=""/>
    <default field="소권역" applyOnUpdate="0" expression=""/>
    <default field="21년" applyOnUpdate="0" expression=""/>
    <default field="22년" applyOnUpdate="0" expression=""/>
    <default field="담당" applyOnUpdate="0" expression=""/>
    <default field="협력사" applyOnUpdate="0" expression=""/>
    <default field="일정분배" applyOnUpdate="0" expression=""/>
    <default field="자전도" applyOnUpdate="0" expression=""/>
    <default field="일반도로" applyOnUpdate="0" expression=""/>
    <default field="고속~도시" applyOnUpdate="0" expression=""/>
    <default field="국도~주2" applyOnUpdate="0" expression=""/>
    <default field="고속~국도,자전도" applyOnUpdate="0" expression=""/>
    <default field="지방도~주2" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint constraints="0" unique_strength="0" field="map_id" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="map_id_str" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="sig_cd" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="sig_eng_nm" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="sig_kor_nm" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="ctprvn_cd" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="ctp_eng_nm" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="ctp_kor_nm" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="구분" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="대권역" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="소권역" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="21년" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="22년" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="담당" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="협력사" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="일정분배" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="자전도" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="일반도로" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="고속~도시" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="국도~주2" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="고속~국도,자전도" notnull_strength="0" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="지방도~주2" notnull_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" field="map_id" exp=""/>
    <constraint desc="" field="map_id_str" exp=""/>
    <constraint desc="" field="sig_cd" exp=""/>
    <constraint desc="" field="sig_eng_nm" exp=""/>
    <constraint desc="" field="sig_kor_nm" exp=""/>
    <constraint desc="" field="ctprvn_cd" exp=""/>
    <constraint desc="" field="ctp_eng_nm" exp=""/>
    <constraint desc="" field="ctp_kor_nm" exp=""/>
    <constraint desc="" field="구분" exp=""/>
    <constraint desc="" field="대권역" exp=""/>
    <constraint desc="" field="소권역" exp=""/>
    <constraint desc="" field="21년" exp=""/>
    <constraint desc="" field="22년" exp=""/>
    <constraint desc="" field="담당" exp=""/>
    <constraint desc="" field="협력사" exp=""/>
    <constraint desc="" field="일정분배" exp=""/>
    <constraint desc="" field="자전도" exp=""/>
    <constraint desc="" field="일반도로" exp=""/>
    <constraint desc="" field="고속~도시" exp=""/>
    <constraint desc="" field="국도~주2" exp=""/>
    <constraint desc="" field="고속~국도,자전도" exp=""/>
    <constraint desc="" field="지방도~주2" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column type="field" hidden="0" width="-1" name="id_0"/>
      <column type="field" hidden="0" width="-1" name="id"/>
      <column type="field" hidden="0" width="-1" name="map_id"/>
      <column type="field" hidden="0" width="-1" name="map_id_str"/>
      <column type="field" hidden="0" width="-1" name="sig_cd"/>
      <column type="field" hidden="0" width="-1" name="sig_eng_nm"/>
      <column type="field" hidden="0" width="-1" name="sig_kor_nm"/>
      <column type="field" hidden="0" width="-1" name="ctprvn_cd"/>
      <column type="field" hidden="0" width="-1" name="ctp_eng_nm"/>
      <column type="field" hidden="0" width="-1" name="ctp_kor_nm"/>
      <column type="field" hidden="0" width="-1" name="구분"/>
      <column type="field" hidden="0" width="-1" name="대권역"/>
      <column type="field" hidden="0" width="-1" name="소권역"/>
      <column type="field" hidden="0" width="-1" name="21년"/>
      <column type="field" hidden="0" width="-1" name="22년"/>
      <column type="field" hidden="0" width="-1" name="담당"/>
      <column type="field" hidden="0" width="-1" name="협력사"/>
      <column type="field" hidden="0" width="-1" name="일정분배"/>
      <column type="field" hidden="0" width="-1" name="자전도"/>
      <column type="field" hidden="0" width="-1" name="일반도로"/>
      <column type="field" hidden="0" width="-1" name="고속~도시"/>
      <column type="field" hidden="0" width="-1" name="국도~주2"/>
      <column type="field" hidden="0" width="-1" name="고속~국도,자전도"/>
      <column type="field" hidden="0" width="-1" name="지방도~주2"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="21년"/>
    <field editable="1" name="22년"/>
    <field editable="1" name="ctp_eng_nm"/>
    <field editable="1" name="ctp_kor_nm"/>
    <field editable="1" name="ctprvn_cd"/>
    <field editable="1" name="id"/>
    <field editable="1" name="id_0"/>
    <field editable="1" name="map_id"/>
    <field editable="1" name="map_id_str"/>
    <field editable="1" name="sig_cd"/>
    <field editable="1" name="sig_eng_nm"/>
    <field editable="1" name="sig_kor_nm"/>
    <field editable="1" name="고속~국도,자전도"/>
    <field editable="1" name="고속~도시"/>
    <field editable="1" name="구분"/>
    <field editable="1" name="국도~주2"/>
    <field editable="1" name="담당"/>
    <field editable="1" name="대권역"/>
    <field editable="1" name="소권역"/>
    <field editable="0" name="소요일 — 지방도~주요2_sum"/>
    <field editable="1" name="일반도로"/>
    <field editable="1" name="일정분배"/>
    <field editable="1" name="자전도"/>
    <field editable="1" name="지방도~주2"/>
    <field editable="1" name="협력사"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="21년"/>
    <field labelOnTop="0" name="22년"/>
    <field labelOnTop="0" name="ctp_eng_nm"/>
    <field labelOnTop="0" name="ctp_kor_nm"/>
    <field labelOnTop="0" name="ctprvn_cd"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="id_0"/>
    <field labelOnTop="0" name="map_id"/>
    <field labelOnTop="0" name="map_id_str"/>
    <field labelOnTop="0" name="sig_cd"/>
    <field labelOnTop="0" name="sig_eng_nm"/>
    <field labelOnTop="0" name="sig_kor_nm"/>
    <field labelOnTop="0" name="고속~국도,자전도"/>
    <field labelOnTop="0" name="고속~도시"/>
    <field labelOnTop="0" name="구분"/>
    <field labelOnTop="0" name="국도~주2"/>
    <field labelOnTop="0" name="담당"/>
    <field labelOnTop="0" name="대권역"/>
    <field labelOnTop="0" name="소권역"/>
    <field labelOnTop="0" name="소요일 — 지방도~주요2_sum"/>
    <field labelOnTop="0" name="일반도로"/>
    <field labelOnTop="0" name="일정분배"/>
    <field labelOnTop="0" name="자전도"/>
    <field labelOnTop="0" name="지방도~주2"/>
    <field labelOnTop="0" name="협력사"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="21년"/>
    <field reuseLastValue="0" name="22년"/>
    <field reuseLastValue="0" name="ctp_eng_nm"/>
    <field reuseLastValue="0" name="ctp_kor_nm"/>
    <field reuseLastValue="0" name="ctprvn_cd"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="id_0"/>
    <field reuseLastValue="0" name="map_id"/>
    <field reuseLastValue="0" name="map_id_str"/>
    <field reuseLastValue="0" name="sig_cd"/>
    <field reuseLastValue="0" name="sig_eng_nm"/>
    <field reuseLastValue="0" name="sig_kor_nm"/>
    <field reuseLastValue="0" name="고속~국도,자전도"/>
    <field reuseLastValue="0" name="고속~도시"/>
    <field reuseLastValue="0" name="구분"/>
    <field reuseLastValue="0" name="국도~주2"/>
    <field reuseLastValue="0" name="담당"/>
    <field reuseLastValue="0" name="대권역"/>
    <field reuseLastValue="0" name="소권역"/>
    <field reuseLastValue="0" name="소요일 — 지방도~주요2_sum"/>
    <field reuseLastValue="0" name="일반도로"/>
    <field reuseLastValue="0" name="일정분배"/>
    <field reuseLastValue="0" name="자전도"/>
    <field reuseLastValue="0" name="지방도~주2"/>
    <field reuseLastValue="0" name="협력사"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"map_id_str"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
