<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" labelsEnabled="0" styleCategories="AllStyleCategories" simplifyDrawingHints="1" version="3.28.15-Firenze" simplifyMaxScale="1" simplifyLocal="1" symbologyReferenceScale="-1" minScale="100000000" simplifyDrawingTol="1" maxScale="0" simplifyAlgorithm="0" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" accumulate="0" startExpression="" enabled="0" fixedDuration="0" mode="0" durationUnit="min" startField="" durationField="" limitMode="0" endField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" zoffset="0" zscale="1" clamping="Terrain" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1" binding="Centroid" type="IndividualFeatures" extrusionEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="213,180,60,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="fill" clip_to_extent="1" name="" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="213,180,60,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="152,129,43,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="marker" clip_to_extent="1" name="" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="213,180,60,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="152,129,43,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="RuleRenderer" symbollevels="0">
    <rules key="{1cafb2ca-959f-463a-a6eb-4878d22a2cb1}">
      <rule key="{3e2ebe01-a9f3-4bf7-ad94-31a63c0eed33}" filter=" &quot;ROADKIND&quot; IN (1, 2, 3, 4, 5, 6, 7)" label="정기">
        <rule key="{ee022d12-da54-48c0-9125-a578279683d4}" filter="&quot;조사담당&quot; = '광주'" symbol="0" label="광주"/>
        <rule key="{977b4f16-fb6c-4ee0-a2e9-7dc13aed146f}" filter="&quot;조사담당&quot; = '대구'" symbol="1" label="대구"/>
        <rule key="{0d3c0608-c777-41d6-8d45-a22d1a4872f8}" filter="&quot;조사담당&quot; = '본사'" symbol="2" label="본사"/>
        <rule key="{7d27a02e-afb1-41ea-b68e-196e366edfec}" filter="&quot;조사담당&quot; = '원주'" symbol="3" label="원주"/>
      </rule>
      <rule key="{85154df6-4d7a-4977-b926-f34780c3bd46}" filter=" &quot;ROADKIND&quot; IN (8, 9)" label="솔맵">
        <rule key="{a34fdfb2-7c7e-403c-96a6-f3ceccd40bbc}" filter="&quot;조사담당&quot; = '광주'" symbol="4" label="광주"/>
        <rule key="{dfb3a6ec-b223-4d97-b929-3354f3a3f9ef}" filter="&quot;조사담당&quot; = '대구'" symbol="5" label="대구"/>
        <rule key="{1e0bccfc-4a71-40d2-b6a5-29306f7f2155}" filter="&quot;조사담당&quot; = '본사'" symbol="6" label="본사"/>
        <rule key="{d4206bd5-aa45-4bd6-8617-7d077328df3b}" filter="&quot;조사담당&quot; = '원주'" symbol="7" label="원주"/>
      </rule>
    </rules>
    <symbols>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="183,135,230,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="14,161,230,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="2" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="108,230,120,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="3" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="230,217,72,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="4" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="93,45,141,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="5" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="50,104,127,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="6" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="44,124,52,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="7" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="133,127,57,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style multilineHeight="1" textOrientation="horizontal" fontWordSpacing="0" fontWeight="50" forcedItalic="0" fontSizeUnit="Point" textColor="50,50,50,255" useSubstitutions="0" fontStrikeout="0" fontSize="10" allowHtml="0" blendMode="0" fieldName="조사구분" legendString="Aa" namedStyle="Italic" forcedBold="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" multilineHeightUnit="Percentage" fontItalic="1" fontUnderline="0" fontFamily="Gulim" fontLetterSpacing="0" fontKerning="1" previewBkgrdColor="255,255,255,255" textOpacity="1" capitalization="0" isExpression="0">
        <families/>
        <text-buffer bufferOpacity="1" bufferSizeUnits="MM" bufferNoFill="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferSize="1" bufferColor="250,250,250,255" bufferDraw="0" bufferBlendMode="0"/>
        <text-mask maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskedSymbolLayers="" maskJoinStyle="128" maskSize="0" maskSizeUnits="MM" maskEnabled="0"/>
        <background shapeOpacity="1" shapeRadiiY="0" shapeType="0" shapeOffsetX="0" shapeJoinStyle="64" shapeOffsetY="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0" shapeSizeUnit="Point" shapeBlendMode="0" shapeSizeX="0" shapeSVGFile="" shapeOffsetUnit="Point" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeFillColor="255,255,255,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeBorderWidthUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeSizeY="0" shapeDraw="0" shapeRotationType="0" shapeSizeType="0" shapeBorderColor="128,128,128,255">
          <symbol is_animated="0" force_rhr="0" frame_rate="10" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
              <Option type="Map">
                <Option value="0" type="QString" name="angle"/>
                <Option value="square" type="QString" name="cap_style"/>
                <Option value="225,89,137,255" type="QString" name="color"/>
                <Option value="1" type="QString" name="horizontal_anchor_point"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="circle" type="QString" name="name"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="35,35,35,255" type="QString" name="outline_color"/>
                <Option value="solid" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
                <Option value="MM" type="QString" name="outline_width_unit"/>
                <Option value="diameter" type="QString" name="scale_method"/>
                <Option value="2" type="QString" name="size"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
                <Option value="MM" type="QString" name="size_unit"/>
                <Option value="1" type="QString" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol is_animated="0" force_rhr="0" frame_rate="10" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleFill" enabled="1">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
                <Option value="255,255,255,255" type="QString" name="color"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="128,128,128,255" type="QString" name="outline_color"/>
                <Option value="no" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="Point" type="QString" name="outline_width_unit"/>
                <Option value="solid" type="QString" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetUnit="MM" shadowScale="100" shadowRadiusAlphaOnly="0" shadowDraw="0" shadowRadius="1.5" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0.69999999999999996" shadowBlendMode="6" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowOffsetAngle="135" shadowColor="0,0,0,255" shadowUnder="0"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" decimals="3" plussign="0" reverseDirectionSymbol="0" addDirectionSymbol="0" formatNumbers="0" wrapChar="" autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0"/>
      <placement labelOffsetMapUnitScale="3x:0,0,0,0,0,0" rotationAngle="0" fitInPolygonOnly="0" allowDegraded="0" geometryGenerator="" placement="4" quadOffset="4" lineAnchorClipping="0" layerType="LineGeometry" repeatDistanceUnits="MM" yOffset="0" lineAnchorType="0" xOffset="0" rotationUnit="AngleDegrees" dist="0" offsetType="0" overlapHandling="PreventOverlap" distUnits="MM" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" centroidInside="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" centroidWhole="0" priority="5" preserveRotation="1" overrunDistance="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" repeatDistance="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="FollowPlacement" geometryGeneratorEnabled="0" placementFlags="10" lineAnchorPercent="0.5" maxCurvedCharAngleIn="25" polygonPlacementFlags="2" geometryGeneratorType="PointGeometry"/>
      <rendering scaleMax="0" maxNumLabels="2000" fontMaxPixelSize="10000" zIndex="0" obstacle="1" upsidedownLabels="0" limitNumLabels="0" unplacedVisibility="0" drawLabels="1" labelPerPart="0" minFeatureSize="0" obstacleType="1" scaleVisibility="0" mergeLines="0" fontLimitPixelSize="0" scaleMin="0" obstacleFactor="1" fontMinPixelSize="3"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" type="QString" name="anchorPoint"/>
          <Option value="0" type="int" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
          <Option value="false" type="bool" name="drawToAllParts"/>
          <Option value="0" type="QString" name="enabled"/>
          <Option value="point_on_exterior" type="QString" name="labelAnchorPoint"/>
          <Option value="&lt;symbol is_animated=&quot;0&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option value=&quot;square&quot; type=&quot;QString&quot; name=&quot;capstyle&quot;/>&lt;Option value=&quot;5;2&quot; type=&quot;QString&quot; name=&quot;customdash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;customdash_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option value=&quot;bevel&quot; type=&quot;QString&quot; name=&quot;joinstyle&quot;/>&lt;Option value=&quot;60,60,60,255&quot; type=&quot;QString&quot; name=&quot;line_color&quot;/>&lt;Option value=&quot;solid&quot; type=&quot;QString&quot; name=&quot;line_style&quot;/>&lt;Option value=&quot;0.3&quot; type=&quot;QString&quot; name=&quot;line_width&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;line_width_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;ring_filter&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;use_custom_dash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString" name="lineSymbol"/>
          <Option value="0" type="double" name="minLength"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="minLengthMapUnitScale"/>
          <Option value="MM" type="QString" name="minLengthUnit"/>
          <Option value="0" type="double" name="offsetFromAnchor"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromAnchorMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromAnchorUnit"/>
          <Option value="0" type="double" name="offsetFromLabel"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromLabelMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="copy" type="QString" name="QFieldSync/action"/>
      <Option value="{}" type="QString" name="QFieldSync/attachment_naming"/>
      <Option value="" type="QString" name="QFieldSync/attribute_editing_locked_expression"/>
      <Option value="offline" type="QString" name="QFieldSync/cloud_action"/>
      <Option value="" type="QString" name="QFieldSync/feature_addition_locked_expression"/>
      <Option value="" type="QString" name="QFieldSync/feature_deletion_locked_expression"/>
      <Option value="" type="QString" name="QFieldSync/geometry_editing_locked_expression"/>
      <Option value="{}" type="QString" name="QFieldSync/photo_naming"/>
      <Option value="{}" type="QString" name="QFieldSync/relationship_maximum_visible"/>
      <Option value="30" type="int" name="QFieldSync/tracking_distance_requirement_minimum_meters"/>
      <Option value="1" type="int" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters"/>
      <Option value="0" type="int" name="QFieldSync/tracking_measurement_type"/>
      <Option value="30" type="int" name="QFieldSync/tracking_time_requirement_interval_seconds"/>
      <Option value="0" type="int" name="QFieldSync/value_map_button_interface_threshold"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option value="&quot;ROAD_NAME&quot;" type="QString"/>
      </Option>
      <Option value="0" type="int" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory minimumSize="0" diagramOrientation="Up" minScaleDenominator="0" direction="0" penAlpha="255" spacing="5" showAxis="1" rotationOffset="270" height="15" backgroundColor="#ffffff" enabled="0" barWidth="5" maxScaleDenominator="1e+08" lineSizeScale="3x:0,0,0,0,0,0" penWidth="0" scaleDependency="Area" width="15" backgroundAlpha="255" spacingUnit="MM" lineSizeType="MM" opacity="1" labelPlacementMethod="XHeight" spacingUnitScale="3x:0,0,0,0,0,0" scaleBasedVisibility="0" penColor="#000000" sizeScale="3x:0,0,0,0,0,0" sizeType="MM">
      <fontProperties style="" strikethrough="0" description="Gulim,9,-1,5,50,0,0,0,0,0" underline="0" italic="0" bold="0"/>
      <attribute field="" colorOpacity="1" label="" color="#000000"/>
      <axisSymbol>
        <symbol is_animated="0" force_rhr="0" frame_rate="10" type="line" clip_to_extent="1" name="" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" pass="0" class="SimpleLine" enabled="1">
            <Option type="Map">
              <Option value="0" type="QString" name="align_dash_pattern"/>
              <Option value="square" type="QString" name="capstyle"/>
              <Option value="5;2" type="QString" name="customdash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
              <Option value="MM" type="QString" name="customdash_unit"/>
              <Option value="0" type="QString" name="dash_pattern_offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
              <Option value="0" type="QString" name="draw_inside_polygon"/>
              <Option value="bevel" type="QString" name="joinstyle"/>
              <Option value="35,35,35,255" type="QString" name="line_color"/>
              <Option value="solid" type="QString" name="line_style"/>
              <Option value="0.26" type="QString" name="line_width"/>
              <Option value="MM" type="QString" name="line_width_unit"/>
              <Option value="0" type="QString" name="offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="offset_unit"/>
              <Option value="0" type="QString" name="ring_filter"/>
              <Option value="0" type="QString" name="trim_distance_end"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_end_unit"/>
              <Option value="0" type="QString" name="trim_distance_start"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_start_unit"/>
              <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
              <Option value="0" type="QString" name="use_custom_dash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" obstacle="0" showAll="1" linePlacementFlags="18" dist="0" placement="2" zIndex="0">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="LINK_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LINK_MAP_I">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ROADKIND">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LINK_KIND_">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ONEWAY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LANENUM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="D_NUM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="로그명">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="조사담당">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="차수">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LEN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ML_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="조사완료">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ROAD_KIND">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LINK_ADD_I">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LANE_NUM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="담당">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="소요일">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="도로번?">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="도로명">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="도로번호">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="LINK_ID" index="0" name=""/>
    <alias field="LINK_MAP_I" index="1" name=""/>
    <alias field="ROADKIND" index="2" name=""/>
    <alias field="LINK_KIND_" index="3" name=""/>
    <alias field="ONEWAY" index="4" name=""/>
    <alias field="LANENUM" index="5" name=""/>
    <alias field="D_NUM" index="6" name=""/>
    <alias field="로그명" index="7" name=""/>
    <alias field="조사담당" index="8" name=""/>
    <alias field="차수" index="9" name=""/>
    <alias field="LEN" index="10" name=""/>
    <alias field="ML_ID" index="11" name=""/>
    <alias field="조사완료" index="12" name=""/>
    <alias field="ROAD_KIND" index="13" name=""/>
    <alias field="LINK_ADD_I" index="14" name=""/>
    <alias field="LANE_NUM" index="15" name=""/>
    <alias field="담당" index="16" name=""/>
    <alias field="소요일" index="17" name=""/>
    <alias field="도로번?" index="18" name=""/>
    <alias field="도로명" index="19" name=""/>
    <alias field="도로번호" index="20" name=""/>
  </aliases>
  <defaults>
    <default field="LINK_ID" expression="" applyOnUpdate="0"/>
    <default field="LINK_MAP_I" expression="" applyOnUpdate="0"/>
    <default field="ROADKIND" expression="" applyOnUpdate="0"/>
    <default field="LINK_KIND_" expression="" applyOnUpdate="0"/>
    <default field="ONEWAY" expression="" applyOnUpdate="0"/>
    <default field="LANENUM" expression="" applyOnUpdate="0"/>
    <default field="D_NUM" expression="" applyOnUpdate="0"/>
    <default field="로그명" expression="" applyOnUpdate="0"/>
    <default field="조사담당" expression="" applyOnUpdate="0"/>
    <default field="차수" expression="" applyOnUpdate="0"/>
    <default field="LEN" expression="" applyOnUpdate="0"/>
    <default field="ML_ID" expression="" applyOnUpdate="0"/>
    <default field="조사완료" expression="" applyOnUpdate="0"/>
    <default field="ROAD_KIND" expression="" applyOnUpdate="0"/>
    <default field="LINK_ADD_I" expression="" applyOnUpdate="0"/>
    <default field="LANE_NUM" expression="" applyOnUpdate="0"/>
    <default field="담당" expression="" applyOnUpdate="0"/>
    <default field="소요일" expression="" applyOnUpdate="0"/>
    <default field="도로번?" expression="" applyOnUpdate="0"/>
    <default field="도로명" expression="" applyOnUpdate="0"/>
    <default field="도로번호" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="LINK_ID" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LINK_MAP_I" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ROADKIND" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LINK_KIND_" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ONEWAY" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LANENUM" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="D_NUM" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="로그명" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="조사담당" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="차수" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LEN" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ML_ID" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="조사완료" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ROAD_KIND" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LINK_ADD_I" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LANE_NUM" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="담당" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="소요일" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="도로번?" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="도로명" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="도로번호" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="LINK_ID" exp="" desc=""/>
    <constraint field="LINK_MAP_I" exp="" desc=""/>
    <constraint field="ROADKIND" exp="" desc=""/>
    <constraint field="LINK_KIND_" exp="" desc=""/>
    <constraint field="ONEWAY" exp="" desc=""/>
    <constraint field="LANENUM" exp="" desc=""/>
    <constraint field="D_NUM" exp="" desc=""/>
    <constraint field="로그명" exp="" desc=""/>
    <constraint field="조사담당" exp="" desc=""/>
    <constraint field="차수" exp="" desc=""/>
    <constraint field="LEN" exp="" desc=""/>
    <constraint field="ML_ID" exp="" desc=""/>
    <constraint field="조사완료" exp="" desc=""/>
    <constraint field="ROAD_KIND" exp="" desc=""/>
    <constraint field="LINK_ADD_I" exp="" desc=""/>
    <constraint field="LANE_NUM" exp="" desc=""/>
    <constraint field="담당" exp="" desc=""/>
    <constraint field="소요일" exp="" desc=""/>
    <constraint field="도로번?" exp="" desc=""/>
    <constraint field="도로명" exp="" desc=""/>
    <constraint field="도로번호" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns>
      <column hidden="0" width="-1" type="field" name="LINK_ID"/>
      <column hidden="0" width="-1" type="field" name="LINK_MAP_I"/>
      <column hidden="0" width="-1" type="field" name="ROADKIND"/>
      <column hidden="0" width="-1" type="field" name="LINK_KIND_"/>
      <column hidden="0" width="-1" type="field" name="ONEWAY"/>
      <column hidden="0" width="-1" type="field" name="LANENUM"/>
      <column hidden="0" width="-1" type="field" name="D_NUM"/>
      <column hidden="0" width="-1" type="field" name="ROAD_KIND"/>
      <column hidden="0" width="-1" type="field" name="LINK_ADD_I"/>
      <column hidden="0" width="-1" type="field" name="LANE_NUM"/>
      <column hidden="0" width="-1" type="field" name="담당"/>
      <column hidden="0" width="-1" type="field" name="ML_ID"/>
      <column hidden="0" width="-1" type="field" name="소요일"/>
      <column hidden="0" width="-1" type="field" name="로그명"/>
      <column hidden="0" width="-1" type="field" name="조사담당"/>
      <column hidden="0" width="-1" type="field" name="차수"/>
      <column hidden="0" width="-1" type="field" name="LEN"/>
      <column hidden="0" width="-1" type="field" name="조사완료"/>
      <column hidden="0" width="-1" type="field" name="도로번?"/>
      <column hidden="0" width="-1" type="field" name="도로명"/>
      <column hidden="0" width="-1" type="field" name="도로번호"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="?곗옣K"/>
    <field editable="1" name="?꾨즺"/>
    <field editable="1" name="?꾨즺?"/>
    <field editable="1" name="?대떦"/>
    <field editable="1" name="?뚯슂?"/>
    <field editable="1" name="?묐젰?"/>
    <field editable="1" name="?쇱젙"/>
    <field editable="1" name="?좎럡?Э"/>
    <field editable="1" name="?좎럥?Ｏ"/>
    <field editable="1" name="?좎럥占쏙"/>
    <field editable="1" name="?좎럩?섓"/>
    <field editable="1" name="?좎럩伊숋"/>
    <field editable="1" name="CENTER_LAT"/>
    <field editable="1" name="CENTER_LON"/>
    <field editable="1" name="CHECK"/>
    <field editable="1" name="COMMENT"/>
    <field editable="1" name="DATE"/>
    <field editable="1" name="D_NUM"/>
    <field editable="1" name="HAE_?꾨"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="LANENUM"/>
    <field editable="1" name="LANE_NUM"/>
    <field editable="1" name="LAYER_NAME"/>
    <field editable="1" name="LAYER_PATH"/>
    <field editable="1" name="LEN"/>
    <field editable="1" name="LENGTH"/>
    <field editable="1" name="LENGTH_GRS"/>
    <field editable="1" name="LEN_"/>
    <field editable="1" name="LEN_KM"/>
    <field editable="1" name="LINK_ADD_I"/>
    <field editable="1" name="LINK_ID"/>
    <field editable="1" name="LINK_ID_2"/>
    <field editable="1" name="LINK_KIND"/>
    <field editable="1" name="LINK_KIND_"/>
    <field editable="1" name="LINK_MAP_I"/>
    <field editable="1" name="MAP_ID"/>
    <field editable="1" name="ML_ID"/>
    <field editable="1" name="ONEWAY"/>
    <field editable="1" name="POINT"/>
    <field editable="1" name="ROADKIND"/>
    <field editable="1" name="ROAD_KIND"/>
    <field editable="1" name="ROAD_KIND_"/>
    <field editable="1" name="ROAD_NAME"/>
    <field editable="1" name="ROAD_NO"/>
    <field editable="1" name="TIME"/>
    <field editable="1" name="UPDATE_DAT"/>
    <field editable="1" name="UPDATE_USE"/>
    <field editable="1" name="占쎄쑬利"/>
    <field editable="1" name="占쎄퓭爰_1"/>
    <field editable="1" name="占쎄퓭爰귨"/>
    <field editable="1" name="占쎈??"/>
    <field editable="1" name="占쎈슣?귨"/>
    <field editable="1" name="占쎌눘?"/>
    <field editable="1" name="占쎌쥙?_1"/>
    <field editable="1" name="占쎌쥙?_2"/>
    <field editable="1" name="占쎌쥙?_3"/>
    <field editable="1" name="占쎌쥙?_4"/>
    <field editable="1" name="占쎌쥙?_5"/>
    <field editable="1" name="占쎌쥙?_6"/>
    <field editable="1" name="占쎌쥙?_7"/>
    <field editable="1" name="占쎌쥙?Ε"/>
    <field editable="1" name="占쎌쥙?Ο"/>
    <field editable="1" name="占쎌쥙?∽"/>
    <field editable="1" name="占쎌쥙?⑼"/>
    <field editable="1" name="占쎌쥙?⒳"/>
    <field editable="1" name="議곗궗?"/>
    <field editable="1" name="遺꾨같"/>
    <field editable="1" name="구분_"/>
    <field editable="1" name="담당"/>
    <field editable="1" name="대권역"/>
    <field editable="1" name="도로명"/>
    <field editable="1" name="도로번?"/>
    <field editable="1" name="도로번호"/>
    <field editable="1" name="로그명"/>
    <field editable="1" name="로그명_"/>
    <field editable="1" name="링크분류"/>
    <field editable="1" name="링크종별"/>
    <field editable="1" name="분류"/>
    <field editable="1" name="소권역"/>
    <field editable="1" name="소요일"/>
    <field editable="1" name="솔맵조사"/>
    <field editable="1" name="완료"/>
    <field editable="1" name="완료_"/>
    <field editable="1" name="완료일정"/>
    <field editable="1" name="일정"/>
    <field editable="1" name="자동차전용"/>
    <field editable="1" name="조사구분"/>
    <field editable="1" name="조사담당"/>
    <field editable="1" name="조사담당_"/>
    <field editable="1" name="조사완료"/>
    <field editable="1" name="차수"/>
    <field editable="1" name="차수_"/>
    <field editable="1" name="협력사"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="?곗옣K"/>
    <field labelOnTop="0" name="?꾨즺"/>
    <field labelOnTop="0" name="?꾨즺?"/>
    <field labelOnTop="0" name="?대떦"/>
    <field labelOnTop="0" name="?뚯슂?"/>
    <field labelOnTop="0" name="?묐젰?"/>
    <field labelOnTop="0" name="?쇱젙"/>
    <field labelOnTop="0" name="?좎럡?Э"/>
    <field labelOnTop="0" name="?좎럥?Ｏ"/>
    <field labelOnTop="0" name="?좎럥占쏙"/>
    <field labelOnTop="0" name="?좎럩?섓"/>
    <field labelOnTop="0" name="?좎럩伊숋"/>
    <field labelOnTop="0" name="CENTER_LAT"/>
    <field labelOnTop="0" name="CENTER_LON"/>
    <field labelOnTop="0" name="CHECK"/>
    <field labelOnTop="0" name="COMMENT"/>
    <field labelOnTop="0" name="DATE"/>
    <field labelOnTop="0" name="D_NUM"/>
    <field labelOnTop="0" name="HAE_?꾨"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="LANENUM"/>
    <field labelOnTop="0" name="LANE_NUM"/>
    <field labelOnTop="0" name="LAYER_NAME"/>
    <field labelOnTop="0" name="LAYER_PATH"/>
    <field labelOnTop="0" name="LEN"/>
    <field labelOnTop="0" name="LENGTH"/>
    <field labelOnTop="0" name="LENGTH_GRS"/>
    <field labelOnTop="0" name="LEN_"/>
    <field labelOnTop="0" name="LEN_KM"/>
    <field labelOnTop="0" name="LINK_ADD_I"/>
    <field labelOnTop="0" name="LINK_ID"/>
    <field labelOnTop="0" name="LINK_ID_2"/>
    <field labelOnTop="0" name="LINK_KIND"/>
    <field labelOnTop="0" name="LINK_KIND_"/>
    <field labelOnTop="0" name="LINK_MAP_I"/>
    <field labelOnTop="0" name="MAP_ID"/>
    <field labelOnTop="0" name="ML_ID"/>
    <field labelOnTop="0" name="ONEWAY"/>
    <field labelOnTop="0" name="POINT"/>
    <field labelOnTop="0" name="ROADKIND"/>
    <field labelOnTop="0" name="ROAD_KIND"/>
    <field labelOnTop="0" name="ROAD_KIND_"/>
    <field labelOnTop="0" name="ROAD_NAME"/>
    <field labelOnTop="0" name="ROAD_NO"/>
    <field labelOnTop="0" name="TIME"/>
    <field labelOnTop="0" name="UPDATE_DAT"/>
    <field labelOnTop="0" name="UPDATE_USE"/>
    <field labelOnTop="0" name="占쎄쑬利"/>
    <field labelOnTop="0" name="占쎄퓭爰_1"/>
    <field labelOnTop="0" name="占쎄퓭爰귨"/>
    <field labelOnTop="0" name="占쎈??"/>
    <field labelOnTop="0" name="占쎈슣?귨"/>
    <field labelOnTop="0" name="占쎌눘?"/>
    <field labelOnTop="0" name="占쎌쥙?_1"/>
    <field labelOnTop="0" name="占쎌쥙?_2"/>
    <field labelOnTop="0" name="占쎌쥙?_3"/>
    <field labelOnTop="0" name="占쎌쥙?_4"/>
    <field labelOnTop="0" name="占쎌쥙?_5"/>
    <field labelOnTop="0" name="占쎌쥙?_6"/>
    <field labelOnTop="0" name="占쎌쥙?_7"/>
    <field labelOnTop="0" name="占쎌쥙?Ε"/>
    <field labelOnTop="0" name="占쎌쥙?Ο"/>
    <field labelOnTop="0" name="占쎌쥙?∽"/>
    <field labelOnTop="0" name="占쎌쥙?⑼"/>
    <field labelOnTop="0" name="占쎌쥙?⒳"/>
    <field labelOnTop="0" name="議곗궗?"/>
    <field labelOnTop="0" name="遺꾨같"/>
    <field labelOnTop="0" name="구분_"/>
    <field labelOnTop="0" name="담당"/>
    <field labelOnTop="0" name="대권역"/>
    <field labelOnTop="0" name="도로명"/>
    <field labelOnTop="0" name="도로번?"/>
    <field labelOnTop="0" name="도로번호"/>
    <field labelOnTop="0" name="로그명"/>
    <field labelOnTop="0" name="로그명_"/>
    <field labelOnTop="0" name="링크분류"/>
    <field labelOnTop="0" name="링크종별"/>
    <field labelOnTop="0" name="분류"/>
    <field labelOnTop="0" name="소권역"/>
    <field labelOnTop="0" name="소요일"/>
    <field labelOnTop="0" name="솔맵조사"/>
    <field labelOnTop="0" name="완료"/>
    <field labelOnTop="0" name="완료_"/>
    <field labelOnTop="0" name="완료일정"/>
    <field labelOnTop="0" name="일정"/>
    <field labelOnTop="0" name="자동차전용"/>
    <field labelOnTop="0" name="조사구분"/>
    <field labelOnTop="0" name="조사담당"/>
    <field labelOnTop="0" name="조사담당_"/>
    <field labelOnTop="0" name="조사완료"/>
    <field labelOnTop="0" name="차수"/>
    <field labelOnTop="0" name="차수_"/>
    <field labelOnTop="0" name="협력사"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="?곗옣K"/>
    <field reuseLastValue="0" name="?꾨즺"/>
    <field reuseLastValue="0" name="?꾨즺?"/>
    <field reuseLastValue="0" name="?대떦"/>
    <field reuseLastValue="0" name="?뚯슂?"/>
    <field reuseLastValue="0" name="?묐젰?"/>
    <field reuseLastValue="0" name="?쇱젙"/>
    <field reuseLastValue="0" name="?좎럡?Э"/>
    <field reuseLastValue="0" name="?좎럥?Ｏ"/>
    <field reuseLastValue="0" name="?좎럥占쏙"/>
    <field reuseLastValue="0" name="?좎럩?섓"/>
    <field reuseLastValue="0" name="?좎럩伊숋"/>
    <field reuseLastValue="0" name="CENTER_LAT"/>
    <field reuseLastValue="0" name="CENTER_LON"/>
    <field reuseLastValue="0" name="CHECK"/>
    <field reuseLastValue="0" name="COMMENT"/>
    <field reuseLastValue="0" name="DATE"/>
    <field reuseLastValue="0" name="D_NUM"/>
    <field reuseLastValue="0" name="HAE_?꾨"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="LANENUM"/>
    <field reuseLastValue="0" name="LANE_NUM"/>
    <field reuseLastValue="0" name="LAYER_NAME"/>
    <field reuseLastValue="0" name="LAYER_PATH"/>
    <field reuseLastValue="0" name="LEN"/>
    <field reuseLastValue="0" name="LENGTH"/>
    <field reuseLastValue="0" name="LENGTH_GRS"/>
    <field reuseLastValue="0" name="LEN_"/>
    <field reuseLastValue="0" name="LEN_KM"/>
    <field reuseLastValue="0" name="LINK_ADD_I"/>
    <field reuseLastValue="0" name="LINK_ID"/>
    <field reuseLastValue="0" name="LINK_ID_2"/>
    <field reuseLastValue="0" name="LINK_KIND"/>
    <field reuseLastValue="0" name="LINK_KIND_"/>
    <field reuseLastValue="0" name="LINK_MAP_I"/>
    <field reuseLastValue="0" name="MAP_ID"/>
    <field reuseLastValue="0" name="ML_ID"/>
    <field reuseLastValue="0" name="ONEWAY"/>
    <field reuseLastValue="0" name="POINT"/>
    <field reuseLastValue="0" name="ROADKIND"/>
    <field reuseLastValue="0" name="ROAD_KIND"/>
    <field reuseLastValue="0" name="ROAD_KIND_"/>
    <field reuseLastValue="0" name="ROAD_NAME"/>
    <field reuseLastValue="0" name="ROAD_NO"/>
    <field reuseLastValue="0" name="TIME"/>
    <field reuseLastValue="0" name="UPDATE_DAT"/>
    <field reuseLastValue="0" name="UPDATE_USE"/>
    <field reuseLastValue="0" name="占쎄쑬利"/>
    <field reuseLastValue="0" name="占쎄퓭爰_1"/>
    <field reuseLastValue="0" name="占쎄퓭爰귨"/>
    <field reuseLastValue="0" name="占쎈??"/>
    <field reuseLastValue="0" name="占쎈슣?귨"/>
    <field reuseLastValue="0" name="占쎌눘?"/>
    <field reuseLastValue="0" name="占쎌쥙?_1"/>
    <field reuseLastValue="0" name="占쎌쥙?_2"/>
    <field reuseLastValue="0" name="占쎌쥙?_3"/>
    <field reuseLastValue="0" name="占쎌쥙?_4"/>
    <field reuseLastValue="0" name="占쎌쥙?_5"/>
    <field reuseLastValue="0" name="占쎌쥙?_6"/>
    <field reuseLastValue="0" name="占쎌쥙?_7"/>
    <field reuseLastValue="0" name="占쎌쥙?Ε"/>
    <field reuseLastValue="0" name="占쎌쥙?Ο"/>
    <field reuseLastValue="0" name="占쎌쥙?∽"/>
    <field reuseLastValue="0" name="占쎌쥙?⑼"/>
    <field reuseLastValue="0" name="占쎌쥙?⒳"/>
    <field reuseLastValue="0" name="議곗궗?"/>
    <field reuseLastValue="0" name="遺꾨같"/>
    <field reuseLastValue="0" name="구분_"/>
    <field reuseLastValue="0" name="담당"/>
    <field reuseLastValue="0" name="대권역"/>
    <field reuseLastValue="0" name="도로명"/>
    <field reuseLastValue="0" name="도로번?"/>
    <field reuseLastValue="0" name="도로번호"/>
    <field reuseLastValue="0" name="로그명"/>
    <field reuseLastValue="0" name="로그명_"/>
    <field reuseLastValue="0" name="링크분류"/>
    <field reuseLastValue="0" name="링크종별"/>
    <field reuseLastValue="0" name="분류"/>
    <field reuseLastValue="0" name="소권역"/>
    <field reuseLastValue="0" name="소요일"/>
    <field reuseLastValue="0" name="솔맵조사"/>
    <field reuseLastValue="0" name="완료"/>
    <field reuseLastValue="0" name="완료_"/>
    <field reuseLastValue="0" name="완료일정"/>
    <field reuseLastValue="0" name="일정"/>
    <field reuseLastValue="0" name="자동차전용"/>
    <field reuseLastValue="0" name="조사구분"/>
    <field reuseLastValue="0" name="조사담당"/>
    <field reuseLastValue="0" name="조사담당_"/>
    <field reuseLastValue="0" name="조사완료"/>
    <field reuseLastValue="0" name="차수"/>
    <field reuseLastValue="0" name="차수_"/>
    <field reuseLastValue="0" name="협력사"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"ROAD_NAME"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
