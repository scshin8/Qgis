<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" readOnly="0" hasScaleBasedVisibilityFlag="0" maxScale="0" minScale="100000000" autoRefreshMode="Disabled" autoRefreshTime="0" simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" simplifyAlgorithm="0" simplifyMaxScale="1" version="3.44.11-Solothurn" styleCategories="AllStyleCategories" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" mode="0" enabled="0" endField="" accumulate="0" startExpression="" endExpression="" durationUnit="min" durationField="LINK_ID" startField="" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation respectLayerSymbol="1" binding="Centroid" zscale="1" symbology="Line" extrusionEnabled="0" clamping="Terrain" type="IndividualFeatures" customToleranceEnabled="0" zoffset="0" showMarkerSymbolInSurfacePlots="0" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{1e08fa3b-d595-4720-9ac3-510e1644130f}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="" type="fill" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill" id="{af235b96-61c4-41b9-ba8b-3e6750bec4d8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="152,129,43,255,rgb:0.5960784,0.5058824,0.1686275,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="" type="marker" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleMarker" id="{8de7f889-ac66-4ae2-bec7-53bf0ff03905}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="152,129,43,255,rgb:0.5960784,0.5058824,0.1686275,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" symbollevels="0" attr="&quot;조사담당&quot;" type="categorizedSymbol" referencescale="-1" enableorderby="0">
    <categories>
      <category render="true" uuid="" value="광주" type="string" label="광주" symbol="0"/>
      <category render="true" uuid="" value="대구" type="string" label="대구" symbol="1"/>
      <category render="true" uuid="" value="본사" type="string" label="본사" symbol="2"/>
      <category render="true" uuid="" value="원주" type="string" label="원주" symbol="3"/>
    </categories>
    <symbols>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="0" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{23436eea-8c51-4d75-a548-e93af1357e60}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="183,135,230,255,rgb:0.7176471,0.5294118,0.9019608,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="1" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{2e2582e4-62f7-48cf-bcd1-dc6b5fe3ae3a}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="14,161,230,255,rgb:0.054902,0.6313725,0.9019608,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="2" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{e8a58d31-656a-4ff9-8c10-605e3967c0a0}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="108,230,120,255,rgb:0.4235294,0.9019608,0.4705882,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="3" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{37880a80-c4da-4f59-bcab-2f96b509d76b}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="230,217,72,255,rgb:0.9019608,0.8509804,0.2823529,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol force_rhr="0" is_animated="0" frame_rate="10" name="" type="line" alpha="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{bb18e5a3-9666-498c-9742-2e9f165f821d}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.26" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontStrikeout="0" fontSizeUnit="Point" namedStyle="Italic" fontWeight="50" legendString="Aa" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSize="10" stretchFactor="100" isExpression="0" forcedBold="0" fontUnderline="0" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" fontKerning="1" multilineHeight="1" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" textOpacity="1" tabStopDistance="80" fontFamily="Gulim" fieldName="조사구분" fontItalic="1" textOrientation="horizontal" tabStopDistanceUnit="Point" useSubstitutions="0" blendMode="0" allowHtml="0" capitalization="0" multilineHeightUnit="Percentage" fontWordSpacing="0" fontLetterSpacing="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1">
        <families/>
        <text-buffer bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferDraw="0" bufferJoinStyle="128" bufferSize="1" bufferOpacity="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferNoFill="1" bufferBlendMode="0"/>
        <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128" maskOpacity="1" maskSizeUnits="MM" maskedSymbolLayers="" maskType="0" maskSize2="1.5" maskEnabled="0" maskSize="1.5"/>
        <background shapeOffsetY="0" shapeBorderWidthUnit="Point" shapeSizeY="0" shapeBorderWidth="0" shapeBlendMode="0" shapeOffsetUnit="Point" shapeRadiiY="0" shapeSVGFile="" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeRotationType="0" shapeRotation="0" shapeRadiiUnit="Point" shapeJoinStyle="64" shapeType="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeSizeX="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="Point" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeOffsetX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0">
          <symbol force_rhr="0" is_animated="0" frame_rate="10" name="markerSymbol" type="marker" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleMarker" id="">
              <Option type="Map">
                <Option value="0" name="angle" type="QString"/>
                <Option value="square" name="cap_style" type="QString"/>
                <Option value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1" name="color" type="QString"/>
                <Option value="1" name="horizontal_anchor_point" type="QString"/>
                <Option value="bevel" name="joinstyle" type="QString"/>
                <Option value="circle" name="name" type="QString"/>
                <Option value="0,0" name="offset" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" type="QString"/>
                <Option value="solid" name="outline_style" type="QString"/>
                <Option value="0" name="outline_width" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                <Option value="MM" name="outline_width_unit" type="QString"/>
                <Option value="diameter" name="scale_method" type="QString"/>
                <Option value="2" name="size" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                <Option value="MM" name="size_unit" type="QString"/>
                <Option value="1" name="vertical_anchor_point" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol force_rhr="0" is_animated="0" frame_rate="10" name="fillSymbol" type="fill" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleFill" id="">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                <Option value="255,255,255,255,rgb:1,1,1,1" name="color" type="QString"/>
                <Option value="bevel" name="joinstyle" type="QString"/>
                <Option value="0,0" name="offset" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" name="outline_color" type="QString"/>
                <Option value="no" name="outline_style" type="QString"/>
                <Option value="0" name="outline_width" type="QString"/>
                <Option value="Point" name="outline_width_unit" type="QString"/>
                <Option value="solid" name="style" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowDraw="0" shadowOffsetDist="1" shadowScale="100" shadowRadiusAlphaOnly="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowRadiusUnit="MM" shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOpacity="0.69999999999999996" shadowOffsetAngle="135"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" multilineAlign="0" rightDirectionSymbol=">" plussign="0" useMaxLineLengthForAutoWrap="1" reverseDirectionSymbol="0" leftDirectionSymbol="&lt;" decimals="3" placeDirectionSymbol="0" formatNumbers="0" wrapChar="" addDirectionSymbol="0"/>
      <placement overlapHandling="PreventOverlap" dist="0" offsetType="0" lineAnchorClipping="0" repeatDistanceUnits="MM" lineAnchorPercent="0.5" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" rotationAngle="0" geometryGeneratorEnabled="0" geometryGenerator="" overrunDistance="0" yOffset="0" distUnits="MM" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" centroidWhole="0" fitInPolygonOnly="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" repeatDistance="0" quadOffset="4" lineAnchorTextPoint="FollowPlacement" priority="5" offsetUnits="MM" allowDegraded="0" overrunDistanceUnit="MM" preserveRotation="1" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" geometryGeneratorType="PointGeometry" polygonPlacementFlags="2" prioritization="PreferCloser" placement="4" distMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" maximumDistance="0" rotationUnit="AngleDegrees" maximumDistanceUnit="MM" lineAnchorType="0" placementFlags="10" centroidInside="0" maxCurvedCharAngleIn="25"/>
      <rendering fontMaxPixelSize="10000" obstacle="1" mergeLines="0" obstacleType="1" scaleVisibility="0" fontMinPixelSize="3" drawLabels="1" unplacedVisibility="0" fontLimitPixelSize="0" obstacleFactor="1" scaleMin="0" scaleMax="0" zIndex="0" maxNumLabels="2000" labelPerPart="0" upsidedownLabels="0" minFeatureSize="0" limitNumLabels="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" name="name" type="QString"/>
          <Option name="properties"/>
          <Option value="collection" name="type" type="QString"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
          <Option value="0" name="blendMode" type="int"/>
          <Option name="ddProperties" type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
          <Option value="false" name="drawToAllParts" type="bool"/>
          <Option value="0" name="enabled" type="QString"/>
          <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
          <Option value="&lt;symbol force_rhr=&quot;0&quot; is_animated=&quot;0&quot; frame_rate=&quot;10&quot; name=&quot;symbol&quot; type=&quot;line&quot; alpha=&quot;1&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer pass=&quot;0&quot; locked=&quot;0&quot; enabled=&quot;1&quot; class=&quot;SimpleLine&quot; id=&quot;{96992d54-ad94-4f81-924d-4a06b0276959}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
          <Option value="0" name="minLength" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
          <Option value="MM" name="minLengthUnit" type="QString"/>
          <Option value="0" name="offsetFromAnchor" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
          <Option value="0" name="offsetFromLabel" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="copy" name="QFieldSync/action" type="QString"/>
      <Option value="{}" name="QFieldSync/attachment_naming" type="QString"/>
      <Option name="QFieldSync/attribute_editing_locked_expression" type="invalid"/>
      <Option value="offline" name="QFieldSync/cloud_action" type="QString"/>
      <Option name="QFieldSync/feature_addition_locked_expression" type="invalid"/>
      <Option name="QFieldSync/feature_deletion_locked_expression" type="invalid"/>
      <Option name="QFieldSync/geometry_editing_locked_expression" type="invalid"/>
      <Option value="{}" name="QFieldSync/photo_naming" type="QString"/>
      <Option value="{}" name="QFieldSync/relationship_maximum_visible" type="QString"/>
      <Option value="30" name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int"/>
      <Option value="1" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="int"/>
      <Option value="0" name="QFieldSync/tracking_measurement_type" type="int"/>
      <Option value="30" name="QFieldSync/tracking_time_requirement_interval_seconds" type="int"/>
      <Option value="0" name="QFieldSync/value_map_button_interface_threshold" type="int"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option value="&quot;ROAD_NAME&quot;" type="QString"/>
      </Option>
      <Option value="0" name="embeddedWidgets/count" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <LinearlyInterpolatedDiagramRenderer upperHeight="5" diagramType="Histogram" lowerWidth="0" lowerValue="0" lowerHeight="0" classificationAttributeExpression="" upperValue="0" attributeLegend="1" upperWidth="5">
    <DiagramCategory rotationOffset="270" scaleDependency="Area" enabled="0" backgroundColor="#ffffff" height="15" maxScaleDenominator="1e+08" backgroundAlpha="255" labelPlacementMethod="XHeight" spacingUnitScale="3x:0,0,0,0,0,0" width="15" penAlpha="255" barWidth="5" stackedDiagramSpacing="0" sizeScale="3x:0,0,0,0,0,0" penColor="#000000" sizeType="MM" lineSizeType="MM" penWidth="0" spacing="5" stackedDiagramSpacingUnit="MM" direction="0" opacity="1" showAxis="1" lineSizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" scaleBasedVisibility="0" minScaleDenominator="0" spacingUnit="MM" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" stackedDiagramMode="Horizontal" minimumSize="0">
      <fontProperties style="" bold="0" strikethrough="0" description="Gulim,9,-1,5,50,0,0,0,0,0" italic="0" underline="0"/>
      <attribute colorOpacity="1" color="#000000" label="" field=""/>
      <axisSymbol>
        <symbol force_rhr="0" is_animated="0" frame_rate="10" name="" type="line" alpha="1" clip_to_extent="1">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" locked="0" enabled="1" class="SimpleLine" id="{4334ffc6-4db2-46e5-a02e-71be708dffa2}">
            <Option type="Map">
              <Option value="0" name="align_dash_pattern" type="QString"/>
              <Option value="square" name="capstyle" type="QString"/>
              <Option value="5;2" name="customdash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
              <Option value="MM" name="customdash_unit" type="QString"/>
              <Option value="0" name="dash_pattern_offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
              <Option value="0" name="draw_inside_polygon" type="QString"/>
              <Option value="bevel" name="joinstyle" type="QString"/>
              <Option value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="line_color" type="QString"/>
              <Option value="solid" name="line_style" type="QString"/>
              <Option value="0.26" name="line_width" type="QString"/>
              <Option value="MM" name="line_width_unit" type="QString"/>
              <Option value="0" name="offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="offset_unit" type="QString"/>
              <Option value="0" name="ring_filter" type="QString"/>
              <Option value="0" name="trim_distance_end" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_end_unit" type="QString"/>
              <Option value="0" name="trim_distance_start" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_start_unit" type="QString"/>
              <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
              <Option value="0" name="use_custom_dash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </LinearlyInterpolatedDiagramRenderer>
  <DiagramLayerSettings linePlacementFlags="18" obstacle="0" dist="0" zIndex="0" priority="0" showAll="1" placement="2">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="LINK_ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LINK_MAP_I" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ROADKIND" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LINK_KIND_" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ONEWAY" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LANENUM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="D_NUM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="로그명" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="조사담당" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="차수" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LEN" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ML_ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="조사완료" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LENGTH_GRS" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LENGTH_KM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ROAD_KIND" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LANE_NUM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="WIDTH" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ROAD_NO" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PAVEMENT" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MIN_SPEED_" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MAX_SPEED_" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAR_LIMIT" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="WEIGHT_LIM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="HIEGHT_LIM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LINK_ADD_I" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MANAGE_COD" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ROAD_NAME" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LINK_STATU" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="협력사" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="부가정?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="자전도" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="대권역" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="소권역" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="담당" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="신규담?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="도엽등?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="수도권?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="HAE조사?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="조사거?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="일조사" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="소요일" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="조사일?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="조사완?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="단방일?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="단방소?" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="비고" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="LINK_ID"/>
    <alias name="" index="1" field="LINK_MAP_I"/>
    <alias name="" index="2" field="ROADKIND"/>
    <alias name="" index="3" field="LINK_KIND_"/>
    <alias name="" index="4" field="ONEWAY"/>
    <alias name="" index="5" field="LANENUM"/>
    <alias name="" index="6" field="D_NUM"/>
    <alias name="" index="7" field="로그명"/>
    <alias name="" index="8" field="조사담당"/>
    <alias name="" index="9" field="차수"/>
    <alias name="" index="10" field="LEN"/>
    <alias name="" index="11" field="ML_ID"/>
    <alias name="" index="12" field="조사완료"/>
    <alias name="" index="13" field="FID"/>
    <alias name="" index="14" field="ID"/>
    <alias name="" index="15" field="LENGTH_GRS"/>
    <alias name="" index="16" field="LENGTH_KM"/>
    <alias name="" index="17" field="ROAD_KIND"/>
    <alias name="" index="18" field="LANE_NUM"/>
    <alias name="" index="19" field="WIDTH"/>
    <alias name="" index="20" field="ROAD_NO"/>
    <alias name="" index="21" field="PAVEMENT"/>
    <alias name="" index="22" field="MIN_SPEED_"/>
    <alias name="" index="23" field="MAX_SPEED_"/>
    <alias name="" index="24" field="CAR_LIMIT"/>
    <alias name="" index="25" field="WEIGHT_LIM"/>
    <alias name="" index="26" field="HIEGHT_LIM"/>
    <alias name="" index="27" field="LINK_ADD_I"/>
    <alias name="" index="28" field="MANAGE_COD"/>
    <alias name="" index="29" field="ROAD_NAME"/>
    <alias name="" index="30" field="LINK_STATU"/>
    <alias name="" index="31" field="협력사"/>
    <alias name="" index="32" field="부가정?"/>
    <alias name="" index="33" field="자전도"/>
    <alias name="" index="34" field="대권역"/>
    <alias name="" index="35" field="소권역"/>
    <alias name="" index="36" field="담당"/>
    <alias name="" index="37" field="신규담?"/>
    <alias name="" index="38" field="도엽등?"/>
    <alias name="" index="39" field="수도권?"/>
    <alias name="" index="40" field="HAE조사?"/>
    <alias name="" index="41" field="조사거?"/>
    <alias name="" index="42" field="일조사"/>
    <alias name="" index="43" field="소요일"/>
    <alias name="" index="44" field="조사일?"/>
    <alias name="" index="45" field="조사완?"/>
    <alias name="" index="46" field="단방일?"/>
    <alias name="" index="47" field="단방소?"/>
    <alias name="" index="48" field="비고"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="LINK_ID"/>
    <default applyOnUpdate="0" expression="" field="LINK_MAP_I"/>
    <default applyOnUpdate="0" expression="" field="ROADKIND"/>
    <default applyOnUpdate="0" expression="" field="LINK_KIND_"/>
    <default applyOnUpdate="0" expression="" field="ONEWAY"/>
    <default applyOnUpdate="0" expression="" field="LANENUM"/>
    <default applyOnUpdate="0" expression="" field="D_NUM"/>
    <default applyOnUpdate="0" expression="" field="로그명"/>
    <default applyOnUpdate="0" expression="" field="조사담당"/>
    <default applyOnUpdate="0" expression="" field="차수"/>
    <default applyOnUpdate="0" expression="" field="LEN"/>
    <default applyOnUpdate="0" expression="" field="ML_ID"/>
    <default applyOnUpdate="0" expression="" field="조사완료"/>
    <default applyOnUpdate="0" expression="" field="FID"/>
    <default applyOnUpdate="0" expression="" field="ID"/>
    <default applyOnUpdate="0" expression="" field="LENGTH_GRS"/>
    <default applyOnUpdate="0" expression="" field="LENGTH_KM"/>
    <default applyOnUpdate="0" expression="" field="ROAD_KIND"/>
    <default applyOnUpdate="0" expression="" field="LANE_NUM"/>
    <default applyOnUpdate="0" expression="" field="WIDTH"/>
    <default applyOnUpdate="0" expression="" field="ROAD_NO"/>
    <default applyOnUpdate="0" expression="" field="PAVEMENT"/>
    <default applyOnUpdate="0" expression="" field="MIN_SPEED_"/>
    <default applyOnUpdate="0" expression="" field="MAX_SPEED_"/>
    <default applyOnUpdate="0" expression="" field="CAR_LIMIT"/>
    <default applyOnUpdate="0" expression="" field="WEIGHT_LIM"/>
    <default applyOnUpdate="0" expression="" field="HIEGHT_LIM"/>
    <default applyOnUpdate="0" expression="" field="LINK_ADD_I"/>
    <default applyOnUpdate="0" expression="" field="MANAGE_COD"/>
    <default applyOnUpdate="0" expression="" field="ROAD_NAME"/>
    <default applyOnUpdate="0" expression="" field="LINK_STATU"/>
    <default applyOnUpdate="0" expression="" field="협력사"/>
    <default applyOnUpdate="0" expression="" field="부가정?"/>
    <default applyOnUpdate="0" expression="" field="자전도"/>
    <default applyOnUpdate="0" expression="" field="대권역"/>
    <default applyOnUpdate="0" expression="" field="소권역"/>
    <default applyOnUpdate="0" expression="" field="담당"/>
    <default applyOnUpdate="0" expression="" field="신규담?"/>
    <default applyOnUpdate="0" expression="" field="도엽등?"/>
    <default applyOnUpdate="0" expression="" field="수도권?"/>
    <default applyOnUpdate="0" expression="" field="HAE조사?"/>
    <default applyOnUpdate="0" expression="" field="조사거?"/>
    <default applyOnUpdate="0" expression="" field="일조사"/>
    <default applyOnUpdate="0" expression="" field="소요일"/>
    <default applyOnUpdate="0" expression="" field="조사일?"/>
    <default applyOnUpdate="0" expression="" field="조사완?"/>
    <default applyOnUpdate="0" expression="" field="단방일?"/>
    <default applyOnUpdate="0" expression="" field="단방소?"/>
    <default applyOnUpdate="0" expression="" field="비고"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LINK_ID"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LINK_MAP_I"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ROADKIND"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LINK_KIND_"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ONEWAY"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LANENUM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="D_NUM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="로그명"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="조사담당"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="차수"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LEN"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ML_ID"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="조사완료"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="FID"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ID"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LENGTH_GRS"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LENGTH_KM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ROAD_KIND"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LANE_NUM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="WIDTH"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ROAD_NO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="PAVEMENT"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MIN_SPEED_"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MAX_SPEED_"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="CAR_LIMIT"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="WEIGHT_LIM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="HIEGHT_LIM"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LINK_ADD_I"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MANAGE_COD"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="ROAD_NAME"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="LINK_STATU"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="협력사"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="부가정?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="자전도"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="대권역"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="소권역"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="담당"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="신규담?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="도엽등?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="수도권?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="HAE조사?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="조사거?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="일조사"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="소요일"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="조사일?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="조사완?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="단방일?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="단방소?"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="비고"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="LINK_ID"/>
    <constraint exp="" desc="" field="LINK_MAP_I"/>
    <constraint exp="" desc="" field="ROADKIND"/>
    <constraint exp="" desc="" field="LINK_KIND_"/>
    <constraint exp="" desc="" field="ONEWAY"/>
    <constraint exp="" desc="" field="LANENUM"/>
    <constraint exp="" desc="" field="D_NUM"/>
    <constraint exp="" desc="" field="로그명"/>
    <constraint exp="" desc="" field="조사담당"/>
    <constraint exp="" desc="" field="차수"/>
    <constraint exp="" desc="" field="LEN"/>
    <constraint exp="" desc="" field="ML_ID"/>
    <constraint exp="" desc="" field="조사완료"/>
    <constraint exp="" desc="" field="FID"/>
    <constraint exp="" desc="" field="ID"/>
    <constraint exp="" desc="" field="LENGTH_GRS"/>
    <constraint exp="" desc="" field="LENGTH_KM"/>
    <constraint exp="" desc="" field="ROAD_KIND"/>
    <constraint exp="" desc="" field="LANE_NUM"/>
    <constraint exp="" desc="" field="WIDTH"/>
    <constraint exp="" desc="" field="ROAD_NO"/>
    <constraint exp="" desc="" field="PAVEMENT"/>
    <constraint exp="" desc="" field="MIN_SPEED_"/>
    <constraint exp="" desc="" field="MAX_SPEED_"/>
    <constraint exp="" desc="" field="CAR_LIMIT"/>
    <constraint exp="" desc="" field="WEIGHT_LIM"/>
    <constraint exp="" desc="" field="HIEGHT_LIM"/>
    <constraint exp="" desc="" field="LINK_ADD_I"/>
    <constraint exp="" desc="" field="MANAGE_COD"/>
    <constraint exp="" desc="" field="ROAD_NAME"/>
    <constraint exp="" desc="" field="LINK_STATU"/>
    <constraint exp="" desc="" field="협력사"/>
    <constraint exp="" desc="" field="부가정?"/>
    <constraint exp="" desc="" field="자전도"/>
    <constraint exp="" desc="" field="대권역"/>
    <constraint exp="" desc="" field="소권역"/>
    <constraint exp="" desc="" field="담당"/>
    <constraint exp="" desc="" field="신규담?"/>
    <constraint exp="" desc="" field="도엽등?"/>
    <constraint exp="" desc="" field="수도권?"/>
    <constraint exp="" desc="" field="HAE조사?"/>
    <constraint exp="" desc="" field="조사거?"/>
    <constraint exp="" desc="" field="일조사"/>
    <constraint exp="" desc="" field="소요일"/>
    <constraint exp="" desc="" field="조사일?"/>
    <constraint exp="" desc="" field="조사완?"/>
    <constraint exp="" desc="" field="단방일?"/>
    <constraint exp="" desc="" field="단방소?"/>
    <constraint exp="" desc="" field="비고"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column name="LINK_ID" type="field" hidden="0" width="-1"/>
      <column name="LINK_MAP_I" type="field" hidden="0" width="-1"/>
      <column name="ROADKIND" type="field" hidden="0" width="-1"/>
      <column name="LINK_KIND_" type="field" hidden="0" width="-1"/>
      <column name="ONEWAY" type="field" hidden="0" width="-1"/>
      <column name="LANENUM" type="field" hidden="0" width="-1"/>
      <column name="D_NUM" type="field" hidden="0" width="-1"/>
      <column name="ROAD_KIND" type="field" hidden="0" width="-1"/>
      <column name="LINK_ADD_I" type="field" hidden="0" width="-1"/>
      <column name="LANE_NUM" type="field" hidden="0" width="-1"/>
      <column name="담당" type="field" hidden="0" width="-1"/>
      <column name="ML_ID" type="field" hidden="0" width="-1"/>
      <column name="소요일" type="field" hidden="0" width="-1"/>
      <column name="로그명" type="field" hidden="0" width="-1"/>
      <column name="조사담당" type="field" hidden="0" width="-1"/>
      <column name="차수" type="field" hidden="0" width="-1"/>
      <column name="LEN" type="field" hidden="0" width="-1"/>
      <column name="조사완료" type="field" hidden="0" width="-1"/>
      <column name="FID" type="field" hidden="0" width="-1"/>
      <column name="ID" type="field" hidden="0" width="-1"/>
      <column name="LENGTH_GRS" type="field" hidden="0" width="-1"/>
      <column name="LENGTH_KM" type="field" hidden="0" width="-1"/>
      <column name="WIDTH" type="field" hidden="0" width="-1"/>
      <column name="ROAD_NO" type="field" hidden="0" width="-1"/>
      <column name="PAVEMENT" type="field" hidden="0" width="-1"/>
      <column name="MIN_SPEED_" type="field" hidden="0" width="-1"/>
      <column name="MAX_SPEED_" type="field" hidden="0" width="-1"/>
      <column name="CAR_LIMIT" type="field" hidden="0" width="-1"/>
      <column name="WEIGHT_LIM" type="field" hidden="0" width="-1"/>
      <column name="HIEGHT_LIM" type="field" hidden="0" width="-1"/>
      <column name="MANAGE_COD" type="field" hidden="0" width="-1"/>
      <column name="ROAD_NAME" type="field" hidden="0" width="-1"/>
      <column name="LINK_STATU" type="field" hidden="0" width="-1"/>
      <column name="협력사" type="field" hidden="0" width="-1"/>
      <column name="부가정?" type="field" hidden="0" width="-1"/>
      <column name="자전도" type="field" hidden="0" width="-1"/>
      <column name="대권역" type="field" hidden="0" width="-1"/>
      <column name="소권역" type="field" hidden="0" width="-1"/>
      <column name="신규담?" type="field" hidden="0" width="-1"/>
      <column name="도엽등?" type="field" hidden="0" width="-1"/>
      <column name="수도권?" type="field" hidden="0" width="-1"/>
      <column name="HAE조사?" type="field" hidden="0" width="-1"/>
      <column name="조사거?" type="field" hidden="0" width="-1"/>
      <column name="일조사" type="field" hidden="0" width="-1"/>
      <column name="조사일?" type="field" hidden="0" width="-1"/>
      <column name="조사완?" type="field" hidden="0" width="-1"/>
      <column name="단방일?" type="field" hidden="0" width="-1"/>
      <column name="단방소?" type="field" hidden="0" width="-1"/>
      <column name="비고" type="field" hidden="0" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="?곗옣K" editable="1"/>
    <field name="?꾨즺" editable="1"/>
    <field name="?꾨즺?" editable="1"/>
    <field name="?대떦" editable="1"/>
    <field name="?뚯슂?" editable="1"/>
    <field name="?묐젰?" editable="1"/>
    <field name="?쇱젙" editable="1"/>
    <field name="?좎럡?Э" editable="1"/>
    <field name="?좎럥?Ｏ" editable="1"/>
    <field name="?좎럥占쏙" editable="1"/>
    <field name="?좎럩?섓" editable="1"/>
    <field name="?좎럩伊숋" editable="1"/>
    <field name="CAR_LIMIT" editable="1"/>
    <field name="CENTER_LAT" editable="1"/>
    <field name="CENTER_LON" editable="1"/>
    <field name="CHECK" editable="1"/>
    <field name="COMMENT" editable="1"/>
    <field name="DATE" editable="1"/>
    <field name="D_NUM" editable="1"/>
    <field name="FID" editable="1"/>
    <field name="HAE_?꾨" editable="1"/>
    <field name="HAE조사?" editable="1"/>
    <field name="HIEGHT_LIM" editable="1"/>
    <field name="ID" editable="1"/>
    <field name="LANENUM" editable="1"/>
    <field name="LANE_NUM" editable="1"/>
    <field name="LAYER_NAME" editable="1"/>
    <field name="LAYER_PATH" editable="1"/>
    <field name="LEN" editable="1"/>
    <field name="LENGTH" editable="1"/>
    <field name="LENGTH_GRS" editable="1"/>
    <field name="LENGTH_KM" editable="1"/>
    <field name="LEN_" editable="1"/>
    <field name="LEN_KM" editable="1"/>
    <field name="LINK_ADD_I" editable="1"/>
    <field name="LINK_ID" editable="1"/>
    <field name="LINK_ID_2" editable="1"/>
    <field name="LINK_KIND" editable="1"/>
    <field name="LINK_KIND_" editable="1"/>
    <field name="LINK_MAP_I" editable="1"/>
    <field name="LINK_STATU" editable="1"/>
    <field name="MANAGE_COD" editable="1"/>
    <field name="MAP_ID" editable="1"/>
    <field name="MAX_SPEED_" editable="1"/>
    <field name="MIN_SPEED_" editable="1"/>
    <field name="ML_ID" editable="1"/>
    <field name="ONEWAY" editable="1"/>
    <field name="PAVEMENT" editable="1"/>
    <field name="POINT" editable="1"/>
    <field name="ROADKIND" editable="1"/>
    <field name="ROAD_KIND" editable="1"/>
    <field name="ROAD_KIND_" editable="1"/>
    <field name="ROAD_NAME" editable="1"/>
    <field name="ROAD_NO" editable="1"/>
    <field name="TIME" editable="1"/>
    <field name="UPDATE_DAT" editable="1"/>
    <field name="UPDATE_USE" editable="1"/>
    <field name="WEIGHT_LIM" editable="1"/>
    <field name="WIDTH" editable="1"/>
    <field name="占쎄쑬利" editable="1"/>
    <field name="占쎄퓭爰_1" editable="1"/>
    <field name="占쎄퓭爰귨" editable="1"/>
    <field name="占쎈??" editable="1"/>
    <field name="占쎈슣?귨" editable="1"/>
    <field name="占쎌눘?" editable="1"/>
    <field name="占쎌쥙?_1" editable="1"/>
    <field name="占쎌쥙?_2" editable="1"/>
    <field name="占쎌쥙?_3" editable="1"/>
    <field name="占쎌쥙?_4" editable="1"/>
    <field name="占쎌쥙?_5" editable="1"/>
    <field name="占쎌쥙?_6" editable="1"/>
    <field name="占쎌쥙?_7" editable="1"/>
    <field name="占쎌쥙?Ε" editable="1"/>
    <field name="占쎌쥙?Ο" editable="1"/>
    <field name="占쎌쥙?∽" editable="1"/>
    <field name="占쎌쥙?⑼" editable="1"/>
    <field name="占쎌쥙?⒳" editable="1"/>
    <field name="議곗궗?" editable="1"/>
    <field name="遺꾨같" editable="1"/>
    <field name="구분_" editable="1"/>
    <field name="단방소?" editable="1"/>
    <field name="단방일?" editable="1"/>
    <field name="담당" editable="1"/>
    <field name="대권역" editable="1"/>
    <field name="도로명" editable="1"/>
    <field name="도로번?" editable="1"/>
    <field name="도로번호" editable="1"/>
    <field name="도엽등?" editable="1"/>
    <field name="로그명" editable="1"/>
    <field name="로그명_" editable="1"/>
    <field name="링크분류" editable="1"/>
    <field name="링크종별" editable="1"/>
    <field name="부가정?" editable="1"/>
    <field name="분류" editable="1"/>
    <field name="비고" editable="1"/>
    <field name="소권역" editable="1"/>
    <field name="소요일" editable="1"/>
    <field name="솔맵조사" editable="1"/>
    <field name="수도권?" editable="1"/>
    <field name="신규담?" editable="1"/>
    <field name="완료" editable="1"/>
    <field name="완료_" editable="1"/>
    <field name="완료일정" editable="1"/>
    <field name="일정" editable="1"/>
    <field name="일조사" editable="1"/>
    <field name="자동차전용" editable="1"/>
    <field name="자전도" editable="1"/>
    <field name="조사거?" editable="1"/>
    <field name="조사구분" editable="1"/>
    <field name="조사담당" editable="1"/>
    <field name="조사담당_" editable="1"/>
    <field name="조사완?" editable="1"/>
    <field name="조사완료" editable="1"/>
    <field name="조사일?" editable="1"/>
    <field name="차수" editable="1"/>
    <field name="차수_" editable="1"/>
    <field name="협력사" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="?곗옣K"/>
    <field labelOnTop="0" name="?꾨즺"/>
    <field labelOnTop="0" name="?꾨즺?"/>
    <field labelOnTop="0" name="?대떦"/>
    <field labelOnTop="0" name="?뚯슂?"/>
    <field labelOnTop="0" name="?묐젰?"/>
    <field labelOnTop="0" name="?쇱젙"/>
    <field labelOnTop="0" name="?좎럡?Э"/>
    <field labelOnTop="0" name="?좎럥?Ｏ"/>
    <field labelOnTop="0" name="?좎럥占쏙"/>
    <field labelOnTop="0" name="?좎럩?섓"/>
    <field labelOnTop="0" name="?좎럩伊숋"/>
    <field labelOnTop="0" name="CAR_LIMIT"/>
    <field labelOnTop="0" name="CENTER_LAT"/>
    <field labelOnTop="0" name="CENTER_LON"/>
    <field labelOnTop="0" name="CHECK"/>
    <field labelOnTop="0" name="COMMENT"/>
    <field labelOnTop="0" name="DATE"/>
    <field labelOnTop="0" name="D_NUM"/>
    <field labelOnTop="0" name="FID"/>
    <field labelOnTop="0" name="HAE_?꾨"/>
    <field labelOnTop="0" name="HAE조사?"/>
    <field labelOnTop="0" name="HIEGHT_LIM"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="LANENUM"/>
    <field labelOnTop="0" name="LANE_NUM"/>
    <field labelOnTop="0" name="LAYER_NAME"/>
    <field labelOnTop="0" name="LAYER_PATH"/>
    <field labelOnTop="0" name="LEN"/>
    <field labelOnTop="0" name="LENGTH"/>
    <field labelOnTop="0" name="LENGTH_GRS"/>
    <field labelOnTop="0" name="LENGTH_KM"/>
    <field labelOnTop="0" name="LEN_"/>
    <field labelOnTop="0" name="LEN_KM"/>
    <field labelOnTop="0" name="LINK_ADD_I"/>
    <field labelOnTop="0" name="LINK_ID"/>
    <field labelOnTop="0" name="LINK_ID_2"/>
    <field labelOnTop="0" name="LINK_KIND"/>
    <field labelOnTop="0" name="LINK_KIND_"/>
    <field labelOnTop="0" name="LINK_MAP_I"/>
    <field labelOnTop="0" name="LINK_STATU"/>
    <field labelOnTop="0" name="MANAGE_COD"/>
    <field labelOnTop="0" name="MAP_ID"/>
    <field labelOnTop="0" name="MAX_SPEED_"/>
    <field labelOnTop="0" name="MIN_SPEED_"/>
    <field labelOnTop="0" name="ML_ID"/>
    <field labelOnTop="0" name="ONEWAY"/>
    <field labelOnTop="0" name="PAVEMENT"/>
    <field labelOnTop="0" name="POINT"/>
    <field labelOnTop="0" name="ROADKIND"/>
    <field labelOnTop="0" name="ROAD_KIND"/>
    <field labelOnTop="0" name="ROAD_KIND_"/>
    <field labelOnTop="0" name="ROAD_NAME"/>
    <field labelOnTop="0" name="ROAD_NO"/>
    <field labelOnTop="0" name="TIME"/>
    <field labelOnTop="0" name="UPDATE_DAT"/>
    <field labelOnTop="0" name="UPDATE_USE"/>
    <field labelOnTop="0" name="WEIGHT_LIM"/>
    <field labelOnTop="0" name="WIDTH"/>
    <field labelOnTop="0" name="占쎄쑬利"/>
    <field labelOnTop="0" name="占쎄퓭爰_1"/>
    <field labelOnTop="0" name="占쎄퓭爰귨"/>
    <field labelOnTop="0" name="占쎈??"/>
    <field labelOnTop="0" name="占쎈슣?귨"/>
    <field labelOnTop="0" name="占쎌눘?"/>
    <field labelOnTop="0" name="占쎌쥙?_1"/>
    <field labelOnTop="0" name="占쎌쥙?_2"/>
    <field labelOnTop="0" name="占쎌쥙?_3"/>
    <field labelOnTop="0" name="占쎌쥙?_4"/>
    <field labelOnTop="0" name="占쎌쥙?_5"/>
    <field labelOnTop="0" name="占쎌쥙?_6"/>
    <field labelOnTop="0" name="占쎌쥙?_7"/>
    <field labelOnTop="0" name="占쎌쥙?Ε"/>
    <field labelOnTop="0" name="占쎌쥙?Ο"/>
    <field labelOnTop="0" name="占쎌쥙?∽"/>
    <field labelOnTop="0" name="占쎌쥙?⑼"/>
    <field labelOnTop="0" name="占쎌쥙?⒳"/>
    <field labelOnTop="0" name="議곗궗?"/>
    <field labelOnTop="0" name="遺꾨같"/>
    <field labelOnTop="0" name="구분_"/>
    <field labelOnTop="0" name="단방소?"/>
    <field labelOnTop="0" name="단방일?"/>
    <field labelOnTop="0" name="담당"/>
    <field labelOnTop="0" name="대권역"/>
    <field labelOnTop="0" name="도로명"/>
    <field labelOnTop="0" name="도로번?"/>
    <field labelOnTop="0" name="도로번호"/>
    <field labelOnTop="0" name="도엽등?"/>
    <field labelOnTop="0" name="로그명"/>
    <field labelOnTop="0" name="로그명_"/>
    <field labelOnTop="0" name="링크분류"/>
    <field labelOnTop="0" name="링크종별"/>
    <field labelOnTop="0" name="부가정?"/>
    <field labelOnTop="0" name="분류"/>
    <field labelOnTop="0" name="비고"/>
    <field labelOnTop="0" name="소권역"/>
    <field labelOnTop="0" name="소요일"/>
    <field labelOnTop="0" name="솔맵조사"/>
    <field labelOnTop="0" name="수도권?"/>
    <field labelOnTop="0" name="신규담?"/>
    <field labelOnTop="0" name="완료"/>
    <field labelOnTop="0" name="완료_"/>
    <field labelOnTop="0" name="완료일정"/>
    <field labelOnTop="0" name="일정"/>
    <field labelOnTop="0" name="일조사"/>
    <field labelOnTop="0" name="자동차전용"/>
    <field labelOnTop="0" name="자전도"/>
    <field labelOnTop="0" name="조사거?"/>
    <field labelOnTop="0" name="조사구분"/>
    <field labelOnTop="0" name="조사담당"/>
    <field labelOnTop="0" name="조사담당_"/>
    <field labelOnTop="0" name="조사완?"/>
    <field labelOnTop="0" name="조사완료"/>
    <field labelOnTop="0" name="조사일?"/>
    <field labelOnTop="0" name="차수"/>
    <field labelOnTop="0" name="차수_"/>
    <field labelOnTop="0" name="협력사"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="?곗옣K"/>
    <field reuseLastValue="0" name="?꾨즺"/>
    <field reuseLastValue="0" name="?꾨즺?"/>
    <field reuseLastValue="0" name="?대떦"/>
    <field reuseLastValue="0" name="?뚯슂?"/>
    <field reuseLastValue="0" name="?묐젰?"/>
    <field reuseLastValue="0" name="?쇱젙"/>
    <field reuseLastValue="0" name="?좎럡?Э"/>
    <field reuseLastValue="0" name="?좎럥?Ｏ"/>
    <field reuseLastValue="0" name="?좎럥占쏙"/>
    <field reuseLastValue="0" name="?좎럩?섓"/>
    <field reuseLastValue="0" name="?좎럩伊숋"/>
    <field reuseLastValue="0" name="CAR_LIMIT"/>
    <field reuseLastValue="0" name="CENTER_LAT"/>
    <field reuseLastValue="0" name="CENTER_LON"/>
    <field reuseLastValue="0" name="CHECK"/>
    <field reuseLastValue="0" name="COMMENT"/>
    <field reuseLastValue="0" name="DATE"/>
    <field reuseLastValue="0" name="D_NUM"/>
    <field reuseLastValue="0" name="FID"/>
    <field reuseLastValue="0" name="HAE_?꾨"/>
    <field reuseLastValue="0" name="HAE조사?"/>
    <field reuseLastValue="0" name="HIEGHT_LIM"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="LANENUM"/>
    <field reuseLastValue="0" name="LANE_NUM"/>
    <field reuseLastValue="0" name="LAYER_NAME"/>
    <field reuseLastValue="0" name="LAYER_PATH"/>
    <field reuseLastValue="0" name="LEN"/>
    <field reuseLastValue="0" name="LENGTH"/>
    <field reuseLastValue="0" name="LENGTH_GRS"/>
    <field reuseLastValue="0" name="LENGTH_KM"/>
    <field reuseLastValue="0" name="LEN_"/>
    <field reuseLastValue="0" name="LEN_KM"/>
    <field reuseLastValue="0" name="LINK_ADD_I"/>
    <field reuseLastValue="0" name="LINK_ID"/>
    <field reuseLastValue="0" name="LINK_ID_2"/>
    <field reuseLastValue="0" name="LINK_KIND"/>
    <field reuseLastValue="0" name="LINK_KIND_"/>
    <field reuseLastValue="0" name="LINK_MAP_I"/>
    <field reuseLastValue="0" name="LINK_STATU"/>
    <field reuseLastValue="0" name="MANAGE_COD"/>
    <field reuseLastValue="0" name="MAP_ID"/>
    <field reuseLastValue="0" name="MAX_SPEED_"/>
    <field reuseLastValue="0" name="MIN_SPEED_"/>
    <field reuseLastValue="0" name="ML_ID"/>
    <field reuseLastValue="0" name="ONEWAY"/>
    <field reuseLastValue="0" name="PAVEMENT"/>
    <field reuseLastValue="0" name="POINT"/>
    <field reuseLastValue="0" name="ROADKIND"/>
    <field reuseLastValue="0" name="ROAD_KIND"/>
    <field reuseLastValue="0" name="ROAD_KIND_"/>
    <field reuseLastValue="0" name="ROAD_NAME"/>
    <field reuseLastValue="0" name="ROAD_NO"/>
    <field reuseLastValue="0" name="TIME"/>
    <field reuseLastValue="0" name="UPDATE_DAT"/>
    <field reuseLastValue="0" name="UPDATE_USE"/>
    <field reuseLastValue="0" name="WEIGHT_LIM"/>
    <field reuseLastValue="0" name="WIDTH"/>
    <field reuseLastValue="0" name="占쎄쑬利"/>
    <field reuseLastValue="0" name="占쎄퓭爰_1"/>
    <field reuseLastValue="0" name="占쎄퓭爰귨"/>
    <field reuseLastValue="0" name="占쎈??"/>
    <field reuseLastValue="0" name="占쎈슣?귨"/>
    <field reuseLastValue="0" name="占쎌눘?"/>
    <field reuseLastValue="0" name="占쎌쥙?_1"/>
    <field reuseLastValue="0" name="占쎌쥙?_2"/>
    <field reuseLastValue="0" name="占쎌쥙?_3"/>
    <field reuseLastValue="0" name="占쎌쥙?_4"/>
    <field reuseLastValue="0" name="占쎌쥙?_5"/>
    <field reuseLastValue="0" name="占쎌쥙?_6"/>
    <field reuseLastValue="0" name="占쎌쥙?_7"/>
    <field reuseLastValue="0" name="占쎌쥙?Ε"/>
    <field reuseLastValue="0" name="占쎌쥙?Ο"/>
    <field reuseLastValue="0" name="占쎌쥙?∽"/>
    <field reuseLastValue="0" name="占쎌쥙?⑼"/>
    <field reuseLastValue="0" name="占쎌쥙?⒳"/>
    <field reuseLastValue="0" name="議곗궗?"/>
    <field reuseLastValue="0" name="遺꾨같"/>
    <field reuseLastValue="0" name="구분_"/>
    <field reuseLastValue="0" name="단방소?"/>
    <field reuseLastValue="0" name="단방일?"/>
    <field reuseLastValue="0" name="담당"/>
    <field reuseLastValue="0" name="대권역"/>
    <field reuseLastValue="0" name="도로명"/>
    <field reuseLastValue="0" name="도로번?"/>
    <field reuseLastValue="0" name="도로번호"/>
    <field reuseLastValue="0" name="도엽등?"/>
    <field reuseLastValue="0" name="로그명"/>
    <field reuseLastValue="0" name="로그명_"/>
    <field reuseLastValue="0" name="링크분류"/>
    <field reuseLastValue="0" name="링크종별"/>
    <field reuseLastValue="0" name="부가정?"/>
    <field reuseLastValue="0" name="분류"/>
    <field reuseLastValue="0" name="비고"/>
    <field reuseLastValue="0" name="소권역"/>
    <field reuseLastValue="0" name="소요일"/>
    <field reuseLastValue="0" name="솔맵조사"/>
    <field reuseLastValue="0" name="수도권?"/>
    <field reuseLastValue="0" name="신규담?"/>
    <field reuseLastValue="0" name="완료"/>
    <field reuseLastValue="0" name="완료_"/>
    <field reuseLastValue="0" name="완료일정"/>
    <field reuseLastValue="0" name="일정"/>
    <field reuseLastValue="0" name="일조사"/>
    <field reuseLastValue="0" name="자동차전용"/>
    <field reuseLastValue="0" name="자전도"/>
    <field reuseLastValue="0" name="조사거?"/>
    <field reuseLastValue="0" name="조사구분"/>
    <field reuseLastValue="0" name="조사담당"/>
    <field reuseLastValue="0" name="조사담당_"/>
    <field reuseLastValue="0" name="조사완?"/>
    <field reuseLastValue="0" name="조사완료"/>
    <field reuseLastValue="0" name="조사일?"/>
    <field reuseLastValue="0" name="차수"/>
    <field reuseLastValue="0" name="차수_"/>
    <field reuseLastValue="0" name="협력사"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"ROAD_NAME"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
