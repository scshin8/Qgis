import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from .toolBox_Algorithm import CreateGPSLayerAlgorithm
# from .toolBox_Algorithm import CopyAttributesByLocationAlgorithm
from .toolBox_Algorithm import ListSubfoldersAlgorithm
from .toolBox_Algorithm import ListAllFoldersAlgorithm



class MyToolBoxProvider(QgsProcessingProvider):

    def unload(self):
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        self.addAlgorithm(CreateGPSLayerAlgorithm())
        # self.addAlgorithm(CopyAttributesByLocationAlgorithm())
        self.addAlgorithm(ListSubfoldersAlgorithm())
        self.addAlgorithm(ListAllFoldersAlgorithm())

    def icon(self):
        return QIcon(os.path.dirname(__file__) + '/icons/MyToolBox.png')

    def id(self):
        return 'MyToolBox'

    def name(self):
        return '좌표도구_툴박스'

    def longName(self):
        return self.name()
