import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .toolBox_Algorithm.CreateGPSLayerAlgorithm import CreateGPSLayerAlgorithm  # Qfield 로그 생성
from .toolBox_Algorithm.CreateSurveyLinkAlgorithm import CreateSurveyLinkAlgorithm # Qfield 조사링크 추출
from .toolBox_Algorithm.EVsurveyAlgorithm import EVsurveyAlgorithm # Qfield  수시 전기차

# from .toolBox_Algorithm import CopyAttributesByLocationAlgorithm
from .toolBox_Algorithm.ListfoldersAlgorithm import ListSubfoldersAlgorithm # 하위 폴더 리스트
from .toolBox_Algorithm.ListfoldersAlgorithm import ListAllFoldersAlgorithm # 하위 전체 폴더 리스트

from .toolBox_Algorithm.GuidedLine_Extraction import GuidedLine_Extraction # 영상인식 유도선 추출
from .toolBox_Algorithm.create_shp_from_wkt import create_shp_from_wkt # Excel_To_Shp
from .toolBox_Algorithm.servey_shp_merge import servey_shp_merge # 조사등록 shp 병합


class MyToolBoxProvider(QgsProcessingProvider):

    def unload(self):
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        self.addAlgorithm(create_shp_from_wkt())
        self.addAlgorithm(servey_shp_merge())
        self.addAlgorithm(EVsurveyAlgorithm())
        self.addAlgorithm(CreateGPSLayerAlgorithm())
        self.addAlgorithm(CreateSurveyLinkAlgorithm())
        self.addAlgorithm(GuidedLine_Extraction())

        # self.addAlgorithm(CopyAttributesByLocationAlgorithm())
        self.addAlgorithm(ListSubfoldersAlgorithm())
        self.addAlgorithm(ListAllFoldersAlgorithm())

    def icon(self):
        return QIcon(os.path.dirname(__file__) + '/icons/MyToolBox.png')

    def id(self):
        return 'MyToolBox'

    def name(self):
        return '좌표도구_툴박스'

    def longName(self):
        return self.name()
