import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from .toolBox_Algorithm import CreateGPSLayerAlgorithm
from .toolBox_Algorithm import CreateSurveyLinkAlgorithm
# from .toolBox_Algorithm import CopyAttributesByLocationAlgorithm
from .toolBox_Algorithm import ListSubfoldersAlgorithm
from .toolBox_Algorithm import ListAllFoldersAlgorithm
from .toolBox_Algorithm import GuidedLine_Extraction
from .toolBox_Algorithm import create_shp_from_wkt
from .toolBox_Algorithm import servey_shp_merge

class MyToolBoxProvider(QgsProcessingProvider):

    def unload(self):
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        self.addAlgorithm(create_shp_from_wkt())
        self.addAlgorithm(servey_shp_merge())
        self.addAlgorithm(CreateGPSLayerAlgorithm())
        self.addAlgorithm(CreateSurveyLinkAlgorithm())
        self.addAlgorithm(GuidedLine_Extraction())

        # self.addAlgorithm(CopyAttributesByLocationAlgorithm())
        self.addAlgorithm(ListSubfoldersAlgorithm())
        self.addAlgorithm(ListAllFoldersAlgorithm())

    def icon(self):
        return QIcon(os.path.dirname(__file__) + '/icons/MyToolBox.png')

    def id(self):
        return 'MyToolBox'

    def name(self):
        return '좌표도구_툴박스'

    def longName(self):
        return self.name()
