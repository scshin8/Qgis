import re
from qgis.core import (QgsCoordinateTransformContext,
                       QgsExpression, 
                       QgsCoordinateReferenceSystem, 
                       QgsCoordinateTransform, 
                       QgsProject, 
                       QgsWkbTypes,
                       QgsPointXY, 
                       QgsGeometry)

from qgis.utils import (qgsfunction, 
                        iface)

# from qgis.gui import *
# import traceback

from . import Coordinate_Tool_data
mapids=Coordinate_Tool_data.MAP_ID
import math, requests

group_name = 'CoordinateTool (좌표변환)'
epsg4326 = QgsCoordinateReferenceSystem("EPSG:4326")
epsg4162 = QgsCoordinateReferenceSystem("EPSG:4162")
epsg5179 = QgsCoordinateReferenceSystem("EPSG:5179")

def InitLatLonFunctions():
    QgsExpression.registerFunction(LonLat2Fs)
    QgsExpression.registerFunction(Fs2LonLat)
    QgsExpression.registerFunction(Fs2Lon)
    QgsExpression.registerFunction(Fs2Lat)
    QgsExpression.registerFunction(Fs2Mms)
    QgsExpression.registerFunction(LineString_StrPoint_X)
    QgsExpression.registerFunction(LineString_StrPoint_Y)
    QgsExpression.registerFunction(LineString_MidPoint_X)
    QgsExpression.registerFunction(LineString_MidPoint_Y)
    QgsExpression.registerFunction(LineString_EndPoint_X)
    QgsExpression.registerFunction(LineString_EndPoint_Y)
    QgsExpression.registerFunction(협력사)
    QgsExpression.registerFunction(담당)
    QgsExpression.registerFunction(대권역)
    QgsExpression.registerFunction(소권역)
    QgsExpression.registerFunction(Bessel)
    QgsExpression.registerFunction(BesLonLat)
    QgsExpression.registerFunction(BesLon)
    QgsExpression.registerFunction(BesLat)
    QgsExpression.registerFunction(Wgs)
    QgsExpression.registerFunction(WgsLonLat)
    QgsExpression.registerFunction(WgsLon)
    QgsExpression.registerFunction(WgsLat)
    QgsExpression.registerFunction(Wgs84Lon)
    QgsExpression.registerFunction(Wgs84Lat)
    QgsExpression.registerFunction(MapID)
    QgsExpression.registerFunction(MapID8Lv)
    # QgsExpression.registerFunction(Wgs2Bes)
    # QgsExpression.registerFunction(Bes2Wgs)
    # QgsExpression.registerFunction(Centroid_X)
    # QgsExpression.registerFunction(Centroid_Y)
    # QgsExpression.registerFunction(LonLat2Mapid)
    # QgsExpression.registerFunction(fsconversion)
    
def UnloadLatLonFunctions():
    QgsExpression.unregisterFunction('LonLat2Fs')
    QgsExpression.unregisterFunction('Fs2LonLat')
    QgsExpression.unregisterFunction('Fs2Lon')
    QgsExpression.unregisterFunction('Fs2Lat')
    QgsExpression.unregisterFunction('Fs2Mms')
    QgsExpression.unregisterFunction('LineString_StrPoint_X')
    QgsExpression.unregisterFunction('LineString_StrPoint_Y')
    QgsExpression.unregisterFunction('LineString_MidPoint_X')
    QgsExpression.unregisterFunction('LineString_MidPoint_Y')
    QgsExpression.unregisterFunction('LineString_EndPoint_X')
    QgsExpression.unregisterFunction('LineString_EndPoint_Y')
    QgsExpression.unregisterFunction('협력사')
    QgsExpression.unregisterFunction('담당')
    QgsExpression.unregisterFunction('대권역')
    QgsExpression.unregisterFunction('소권역')
    QgsExpression.unregisterFunction('Bessel')
    QgsExpression.unregisterFunction('BesLonLat')
    QgsExpression.unregisterFunction('BesLon')
    QgsExpression.unregisterFunction('BesLat')
    QgsExpression.unregisterFunction('Wgs')
    QgsExpression.unregisterFunction('WgsLonLat')
    QgsExpression.unregisterFunction('WgsLon')
    QgsExpression.unregisterFunction('WgsLat')
    QgsExpression.unregisterFunction('Lon')
    QgsExpression.unregisterFunction('Lat')
    QgsExpression.unregisterFunction('MapID')
    QgsExpression.unregisterFunction('MapID8Lv')
    # QgsExpression.unregisterFunction('Wgs2Bes')
    # QgsExpression.unregisterFunction('Bes2Wgs')
    # QgsExpression.unregisterFunction('Centroid_X')
    # QgsExpression.unregisterFunction('Centroid_Y')
    # QgsExpression.unregisterFunction('LonLat2Mapid')
    # QgsExpression.unregisterFunction('fsconversion')
    
    
    

def geomTransform(lay_crs,geom):
    Geom = geom.geometry()
    Transform = QgsCoordinateTransform(lay_crs, epsg5179, QgsCoordinateTransformContext())
    Geom.transform(Transform)
    return Geom
  
def transform(pnt,laycrs,cuscrs):
    cuscrs = QgsCoordinateReferenceSystem(cuscrs)
    laycrs = QgsCoordinateReferenceSystem(laycrs)
    transform = QgsCoordinateTransform(laycrs, cuscrs, QgsProject.instance())
    cuspnt = transform.transform(pnt.x(), pnt.y())
    return cuspnt

def bestowgstransform(x, y):
    transform = QgsCoordinateTransform(epsg4162, epsg4326, QgsProject.instance())
    gpt = transform.transform(x, y)
    return gpt.x(), gpt.y()

def wgstobestransform(x, y):
    transform = QgsCoordinateTransform(epsg4326, epsg4162, QgsProject.instance())
    bpt = transform.transform(x, y)
    return bpt.x(), bpt.y()

def map_id(Lon,Lat):
    map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
    map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
    map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
    map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
    mapid = map1 + map2 + map3 + map4
    
    row = int((abs((Lat-11880000)-(int((Lat-11880000)/30000)*30000))+30000)/3750)-7
    cou = int((abs((Lon-44640000)-(int((Lon-44640000)/45000)*45000))+45000)/5625)-7

    mapid_Info = mapids.get(str(row))
    
    idx = mapid_Info[cou]

    mapid8 = mapid + idx
    
    return mapid, mapid8


def mapidchk(values):
    vallen=len(values)
    try:
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입
        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계
        if vallen == 1:
            geom=values[0]
            try:
                if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                    layer = iface.activeLayer() # 선택레이어
                    layer_crs = layer.crs().authid() # 레이어 좌표계
                    
                    if geom.type() == 0 or geom.type() == 2:
                        geompnt=geom.centroid()
                        geompntxy = geompnt.asPoint() # vertexAt(0)
                        
                    elif geom.type() == 1: # 라인
                        distance=geom.length()/2
                        geompnt = geom.interpolate(distance)
                        geompntxy = geompnt.asPoint() # vertexAt(0)

                    geompntxy = transform(geompntxy,layer_crs,"EPSG:4162")
                    
                    x=geompntxy[0]
                    y=geompntxy[1]
                    Lon = float(x*360000)
                    Lat = float(y*360000)
                    mapid, mapid8 = map_id(Lon,Lat)
            except:
                if values[0][4]=='(' and values[0][11]==')':    # FS 좌표
                    text=str(values[0])
                    text= text[12:]
                    text=text.strip().strip('()')
                    text=text.split('/')
                    Lon=text[0].strip()
                    Lat=text[1].strip()
                    Lon=Lon.split('.')
                    Lat=Lat.split('.')
                    
                    Lon2=Lon[2]+'.'+Lon[3]
                    Lon2=float(Lon2)/60
                    Lon1=round((int(Lon[1])+Lon2)/60,8)
                    Lon=(int(Lon[0])+Lon1)*360000
  
                    Lat2=Lat[2]+'.'+Lat[3]
                    Lat2=float(Lat2)/60
                    Lat1=round((int(Lat[1])+Lat2)/60,8)
                    Lat=(int(Lat[0])+Lat1)*360000 

                    mapid, mapid8 = map_id(Lon,Lat)
                    
                elif values[0][0]=='(' and values[0][-1]==')':    # MMS 좌표
                    text=str(values[0])
                    text=text.strip('()')
                    text=text.split(',')
                    x=float(text[0].strip())
                    y=float(text[1].strip())
                    if x > 40000000 and y < 20000000 :
                        Lon = x
                        Lat = y
                    else:
                        Lon = y
                        Lat = x
                    mapid, mapid8 = map_id(Lon,Lat)
                    
                elif values[0][0]=='4' or values[0][0]=='1':      # MMS 좌표 괄호 미포함
                    if values[0].find(',')>0:
                        Lon=values[0].split(',')[0]
                        Lat=values[0].split(',')[1]
                    elif values[0].find(' ')>0:
                        Lon=values[0].split(' ')[0]
                        Lat=values[0].split(' ')[1]
                    elif values[0].find('	')>0:
                        Lon=values[0].split('	')[0]
                        Lat=values[0].split('	')[1]
                    elif values[0].find('/')>0:
                        Lon=values[0].split('/')[0]
                        Lat=values[0].split('/')[1]
                    elif values[0].find('_')>0:
                        Lon=values[0].split('_')[0]
                        Lat=values[0].split('_')[1]
                    elif values[0].find('|')>0:
                        Lon=values[0].split('|')[0]
                        Lat=values[0].split('|')[1]
                    mapid, mapid8 = map_id(Lon,Lat)
                else:
                    mapid=str(values[0])[:4]
                    mapid8 = mapid + '0000'
                    
        elif vallen == 2:
            geom=values[0]
            try:
                if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                    layer = iface.activeLayer() # 선택레이어
                    layer_crs = layer.crs().authid() # 레이어 좌표계
                    
                    if geom.type() == 0 or geom.type() == 2:
                        geompnt=geom.centroid()
                        geompntxy = geompnt.asPoint() # vertexAt(0)
                        
                    elif geom.type() == 1: # 라인
                        distance=geom.length()/2
                        geompnt = geom.interpolate(distance)
                        geompntxy = geompnt.asPoint() # vertexAt(0)

                    geompntxy = transform(geompntxy,values[1],"EPSG:4162")
                    
                    x=geompntxy[0]
                    y=geompntxy[1]
                    Lon = float(x*360000)
                    Lat = float(y*360000)
                    mapid, mapid8 = map_id(Lon,Lat)
            except:

                x = float(values[0])
                y = float(values[1])
                
                if x > 40000000 and y < 20000000 :
                    Lon = x
                    Lat = y
                else:
                    Lat = y
                    Lat = x
                
            mapid, mapid8 = map_id(Lon,Lat)
        return mapid , mapid8
    except:
        return None, None
    
def fscoordinate(geompntxy):
    x=geompntxy[0]
    y=geompntxy[1]
    if  x > 40000000:
        Lon = geompntxy[0]
        Lat=geompntxy[1]
        x = float(Lon/360000)
        y = float(Lat/360000)
    else:
        Lon = float(x*360000)
        Lat = float(y*360000)
    
    map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
    map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
    map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
    map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
    mapid = map1 + map2 + map3 + map4
    LonD = int(x)
    LonM = int(((x)-LonD)*60)
    LonS = f'{round(((((x)-LonD)*60)-LonM)*60,2):.2f}'
    LatD = int(y)
    LatM = int(((y)-LatD)*60)
    LatS = f'{round(((((y)-LatD)*60)-LatM)*60,2):.2f}'
    fs = mapid + '(000000)(' + str(LonD) +'.'+ str(LonM) +'.'+ str(LonS) +'/'+ str(LatD) +'.'+ str(LatM) +'.'+ str(LatS) + ')' 
    return fs

# @qgsfunction(-1, group=group_name)
# def fsconversion(values, feature, parent):
#     """
#     """
#     vallen = len(values)
    
#     if vallen > 1:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return

#     try: 
#         # 사용자정의 좌표계라면 FS 좌표 인지. MMS 좌표인지 구분이 필요
#         text=values[0]
#         if text[0]=='(' and text[-1]==')':      # MMS 좌표 괄호 포함
#             text=text.strip('()')
#             text=text.split(',')
#             lon=text[0].strip()
#             lat=text[1].strip()

#         elif text[4]=='(' and text[11]==')':    # FS 좌표
#             text=text[12:].strip('()') # .replace('/', ',')
#             text=text.split('/')
#             lon=text[0].strip()
#             lat=text[1].strip()
#             lon=lon.split('.')
#             lat=lat.split('.')

#             lon2=lon[2]+'.'+lon[3]
#             lon2=float(lon2)/60
#             lon1=round((int(lon[1])+lon2)/60,8)
#             lon=(int(lon[0])+lon1)*360000

#             lat2=lat[2]+'.'+lat[3]
#             lat2=float(lat2)/60
#             lat1=round((int(lat[1])+lat2)/60,8)
#             lat=(int(lat[0])+lat1)*360000 

#         elif text[0]=='4' or text[0]=='1':      # MMS 좌표 괄호 미포함
#             if text.find(',')>0:
#                 lon=text.split(',')[0]
#                 lat=text.split(',')[1]
#             elif text.find(' ')>0:
#                 lon=text.split(' ')[0]
#                 lat=text.split(' ')[1]
#             elif text.find('	')>0:
#                 lon=text.split('	')[0]
#                 lat=text.split('	')[1]
#             elif text.find('/')>0:
#                 lon=text.split('/')[0]
#                 lat=text.split('/')[1]

#         # 해당 조건에 맞지 않는 좌표값은 프로그램 중단
#         else:
#             print('좌표확인')
#             # if self.marker is not None:
#             #     self.canvas.scene().removeItem(self.marker)
#             #     self.marker = None
#         fsconversion = str(str(lon) + ',' + str(lat))
        
#     except Exception:
#         parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
#         return
#     return fsconversion


@qgsfunction(-1, group=group_name)
def MapID8Lv(values, feature, parent):
    """
    도형의 중앙점좌표, 입력좌표를 기준으로 8Lv MAPID를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>MapID8Lv</b> ( <i> $geometry </i> )</li>
    <li><b>MapID8Lv</b> ( <i> '좌표' </i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>좌표</i>  &rarr; Fs좌표, MMS좌표 </p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>MapID8Lv</b> ( $geometry ) &rarr; '57161340' </li>
      <li><b>MapID8Lv</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '57161340' </li>
      <li><b>MapID8Lv</b> ( '(45735376.093135 , 13487184.37282)' ) &rarr; '57161340' </li>
      <li><b>MapID8Lv</b> ( '45735376.093135' , '13487184.37282' ) &rarr; '57161340' </li>

    </ul>
    """
    vallen = len(values)
    
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return

    try: 
         
        mapid, mapid8 = mapidchk(values)
        mapid = mapid + '0000'
        
    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return mapid8

@qgsfunction(-1, group=group_name)
def MapID(values, feature, parent):
    """
    도형의 중앙점좌표, 입력좌표를 기준으로 MAPID를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>MapID</b> ( <i> $geometry </i> )</li>
    <li><b>MapID</b> ( <i> '좌표' </i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>좌표</i>  &rarr; Fs좌표, MMS좌표 </p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>MapID</b> ( $geometry ) &rarr; '57160000' </li>
      <li><b>MapID</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '57160000' </li>
      <li><b>MapID</b> ( '(45735376.093135 , 13487184.37282)' ) &rarr; '57160000' </li>
      <li><b>MapID</b> ( '45735376.093135' , '13487184.37282' ) &rarr; '57160000' </li>

    </ul>
    """
    vallen = len(values)
    
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return

    try: 
         
        mapid, mapid8 = mapidchk(values)
        mapid = mapid + '0000'
        
    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return mapid

@qgsfunction(-1, group=group_name)
def Bessel(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 베셀 좌표를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>Bessel</b> ( <i>$geometry</i> )</li>

    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>Bessel</b> ( $geometry ) &rarr; '5725(000000)(127.7.52.94/37.24.57.44)' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계
        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
            
        Bessel = fscoordinate(geompntxy)
      
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return Bessel

@qgsfunction(-1, group=group_name)
def BesLonLat(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 베셀 경위도를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>BesLonLat</b> ( <i>$geometry</i> )</li>

    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>BesLonLat</b> ( $geometry ) &rarr; '46429751.52423266,12657082.412135508' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
        
        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        BesLonLat = str(str(Lon) + ',' + str(Lat))
      
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return BesLonLat

@qgsfunction(-1, group=group_name)
def BesLon(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 베셀 경도를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>BesLon</b> ( <i>$geometry</i> )</li>

    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>BesLon</b> ( $geometry ) &rarr; '46429751.52423266' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
            
        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        BesLon = Lon
      
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return BesLon

@qgsfunction(-1, group=group_name)
def BesLat(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 베셀 위도를 반환 합니다.

    <h4>구문</h4>
    
    <li><b>BesLat</b> ( <i>$geometry</i> )</li>

    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>BesLat</b> ( $geometry ) &rarr; '12657082.412135508' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")

        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        BesLat = Lat
      
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return BesLat

@qgsfunction(-1, group=group_name)
def Wgs(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 WGS 좌표를 반환 합니다.

    <h4>구문</h4>

    <li><b>Wgs</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>Wgs</b> ( $geometry ) &rarr; '5725(000000)(127.7.52.94/37.24.57.44)' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        wgs = fscoordinate(geompntxy)
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return wgs

@qgsfunction(-1, group=group_name)
def WgsLonLat(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 WGS 경위도를 반환 합니다.

    <h4>구문</h4>

    <li><b>WgsLonLat</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>WgsLonLat</b> ( $geometry ) &rarr; '46428940.397607744,12658192.147760725' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        WgsLonLat = str(str(Lon) + ',' + str(Lat))
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return WgsLonLat

@qgsfunction(-1, group=group_name)
def WgsLon(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 WGS 경도를 반환 합니다.

    <h4>구문</h4>

    <li><b>WgsLon</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>WgsLon</b> ( $geometry ) &rarr; '46428940.397607744' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        WgsLon = Lon
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return WgsLon

@qgsfunction(-1, group=group_name)
def WgsLat(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 WGS 위도를 반환 합니다.

    <h4>구문</h4>

    <li><b>WgsLat</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>WgsLat</b> ( $geometry ) &rarr; '12658192.147760725' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom=values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        x=geompntxy[0]
        y=geompntxy[1]
        Lon = float(x*360000)
        Lat = float(y*360000)
        
        WgsLat = Lat
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return WgsLat

@qgsfunction(-1, group=group_name)
def Wgs84Lon(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 Wgs84 경도를 반환 합니다.

    <h4>구문</h4>

    <li><b>Wgs84Lon</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>Wgs84Lon</b> ( $geometry ) &rarr; '128.96927888224374' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        x = geompntxy[0]
        y = geompntxy[1]

        Wgs84Lon = x
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return Wgs84Lon

@qgsfunction(-1, group=group_name)
def Wgs84Lat(values, feature, parent):
    """
    도형의 중앙점 좌표를 기준으로 Wgs84 위도를 반환 합니다.

    <h4>구문</h4>

    <li><b>Wgs84Lat</b> ( <i>$geometry</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>Wgs84Lat</b> ( $geometry ) &rarr; '35.1616448548909' </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        if geom.type() == 0 or geom.type() == 2:
            geompnt=geom.centroid()
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)

        geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4326")
        
        x = geompntxy[0]
        y = geompntxy[1]

        Wgs84Lat = y
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return Wgs84Lat

@qgsfunction(-1, group=group_name)
def LineString_MidPoint_X(values, feature, parent):
    """
    라인도형의 중간점 X값를 반환합니다.

    <h4>구문</h4>
    
    <li><b>LineString_MidPoint_X</b> ( <i>$geometry</i>)</li>
    <li><b>LineString_MidPoint_X</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_MidPoint_X</b> ( $geometry ) &rarr; 45709238.35 </li>
      <li><b>LineString_MidPoint_X</b> ( $geometry , 'EPSG:4326' ) &rarr; 126.9701065288479 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        # if feature.geometry().type() == 0: # 포인트
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance = geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))

        midpointx = geompntxy.x()
            
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return midpointx

@qgsfunction(-1, group=group_name)
def LineString_MidPoint_Y(values, feature, parent):
    """
    라인도형의 중간점 Y값를 반환합니다.

    <h4>구문</h4>
    <li><b>LineString_MidPoint_Y</b> ( <i>$geometry</i> )</li>
    <li><b>LineString_MidPoint_Y</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_MidPoint_Y</b> ( $geometry ) &rarr; 12689733.38 </li>
      <li><b>LineString_MidPoint_Y</b> ( $geometry , 'EPSG:4326' ) &rarr; 35.24925941172941 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        # if feature.geometry().type() == 0: # 포인트
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            distance=geom.length()/2
            geompnt = geom.interpolate(distance)
            geompntxy = geompnt.asPoint() # vertexAt(0)
            
        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
        midpointy = geompntxy.y()
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return midpointy

@qgsfunction(-1, group=group_name)
def LineString_StrPoint_X(values, feature, parent):
    """
    라인도형의 시점의 X값를 반환합니다.

    <h4>구문</h4>
    
    <li><b>LineString_StrPoint_X</b> ( <i>$geometry</i> )</li>
    <li><b>LineString_StrPoint_X</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_StrPoint_X</b> ( $geometry ) &rarr; 45709101.56 </li>
      <li><b>LineString_StrPoint_X</b> ( $geometry , 'EPSG:4326' ) &rarr; 126.96972656250003 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        # if feature.geometry().type() == 0: # 포인트
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            geompntxy = geom.vertexAt(0)

        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))

        strpointx = str(geompntxy.x())
        
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return strpointx

@qgsfunction(-1, group=group_name)
def LineString_StrPoint_Y(values, feature, parent):
    """
    라인도형의 시점의 Y값를 반환합니다.

    <h4>구문</h4>
    
    <li><b>LineString_StrPoint_Y</b> ( <i>$geometry</i> )</li>
    <li><b>LineString_StrPoint_Y</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_StrPoint_Y</b> ( $geometry ) &rarr; 12689445.19 </li>
      <li><b>LineString_StrPoint_Y</b> ( $geometry , 'EPSG:4326' ) &rarr; 35.24845886230469 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        geom = values[0]
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        # if feature.geometry().type() == 0: # 포인트
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if geom.type() == 1: # 라인
            geompntxy = geom.vertexAt(0)
            
        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
        strpointy = geompntxy.y()
            
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return strpointy

@qgsfunction(-1, group=group_name)
def LineString_EndPoint_X(values, feature, parent):
    """
    라인도형의 종점의 X값를 반환합니다.

    <h4>구문</h4>
    
    <li><b>LineString_EndPoint_X</b> ( <i>$geometry</i> )</li>
    <li><b>LineString_EndPoint_X</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_EndPoint_X</b> ( $geometry ) &rarr; 45709411.92 </li>
      <li><b>LineString_EndPoint_X</b> ( $geometry , 'EPSG:4326' ) &rarr; 126.97058868408206 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType())
        # print(layer_wkb_type)
        # # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계
        # # if feature.geometry().type() == 0: # 포인트
        # #     geompnt=feature.geometry().centroid()
        # #     geompntxy = geompnt.asPoint() # vertexAt(0)
        
        if values[0].type() == 1: # 라인
            if values[0].isMultipart(): # new part for multipolylines 
                geom = values[0].asMultiPolyline()
                geompntxy = geom[-1][-1]
                
            else:
                geom = values[0].asPolyline()
                geompntxy = geom[-1]

        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
        endpointx = geompntxy.x()
            
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return endpointx

@qgsfunction(-1, group=group_name)
def LineString_EndPoint_Y(values, feature, parent):
    """
    라인도형의 종점의 Y값를 반환합니다.

    <h4>구문</h4>
    
    <li><b>LineString_EndPoint_Y</b> ( <i>$geometry</i>)</li>
    <li><b>LineString_EndPoint_Y</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LineString_EndPoint_Y</b> ( $geometry ) &rarr; 12689733.38 </li>
      <li><b>LineString_EndPoint_Y</b> ( $geometry , 'EPSG:4326' ) &rarr; 35.24925941172941 </li>

    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        layer = iface.activeLayer() # 선택레이어
        layer_crs = layer.crs().authid() # 레이어 좌표계
        
        # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

        # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

        # if feature.geometry().type() == 0: # 포인트
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if values[0].type() == 1: # 라인
            if values[0].isMultipart(): # new part for multipolylines 
                geom = values[0].asMultiPolyline()
                geompntxy = geom[-1][-1]
                
            else:
                geom = values[0].asPolyline()
                geompntxy = geom[-1]
            
        # if feature.geometry().type() == 2:  # 폴리곤
        #     geompnt=feature.geometry().centroid()
        #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
        if vallen == 2: 
            geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
        endpointy = geompntxy.y()
            
    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return endpointy

# @qgsfunction(-1, group=group_name)
# def Centroid_X(values, feature, parent):
#     """
#     폴리곤, 노드의 중앙포인트의 X값를 반환합니다.

#     <h4>구문</h4>
    
#     <li><b>Centroid_X</b> ( <i>$geometry</i> )</li>
#     <li><b>Centroid_X</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
#     <h4>인수</h4>
    
#     <p><i>$geometry</i>  &rarr;  도형</p>
#     <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

#     <h4>예제</h4>
#     <ul>
    
#       <li><b>Centroid_X</b> ( $geometry ) &rarr; 45709101.56 </li>
#       <li><b>Centroid_X</b> ( $geometry , 'EPSG:4326' ) &rarr; 126.96972656250003 </li>

#     </ul>
#     """
#     vallen = len(values)
#     if vallen > 2:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return
#     try:
#         layer = iface.activeLayer() # 선택레이어
#         layer_crs = layer.crs() # 레이어 좌표계
#         # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

#         # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계
        
#         # if feature.geometry().type() == 2:  # 폴리곤
#         geompnt=values[0].centroid()
#         geompntxy = geompnt.asPoint() # vertexAt(0)
            
#         if vallen == 2: 
#             geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
#         Centroidx = geompntxy.x()
            
#     except Exception:
#         parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
#         return parent
#     return Centroidx

# @qgsfunction(-1, group=group_name)
# def Centroid_Y(values, feature, parent):
#     """
#     폴리곤, 노드의 중앙포인트의 X값를 반환합니다.

#     <h4>구문</h4>
    
#     <li><b>Centroid_Y</b> ( <i>$geometry</i> )</li>
#     <li><b>Centroid_Y</b> ( <i>$geometry , 변경 좌표계</i> )</li>
    
#     <h4>인수</h4>
    
#     <p><i>$geometry</i>  &rarr;  도형</p>
#     <p><i>변경 좌표계</i>  &rarr;  변경대상 좌표계</p>

#     <h4>예제</h4>
#     <ul>
    
#       <li><b>Centroid_Y</b> ( $geometry ) &rarr; 12689733.38 </li>
#       <li><b>Centroid_Y</b> ( $geometry , 'EPSG:4326' ) &rarr; 35.24925941172941 </li>

#     </ul>
#     """
#     vallen = len(values)
#     if vallen > 2:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return
#     try:
#         layer = iface.activeLayer() # 선택레이어
#         layer_crs = layer.crs() # 레이어 좌표계
#         # layer_wkb_type = QgsWkbTypes.displayString(layer.wkbType()) # 레이어 타입

#         # Canvas_crs=iface.mapCanvas().mapSettings().destinationCrs().authid() #.description() # 프로젝트 좌표계

#         # if feature.geometry().type() == 0: # 포인트
#         #     geompnt=feature.geometry().centroid()
#         #     geompntxy = geompnt.asPoint() # vertexAt(0)
            
#         # if feature.geometry().type() == 1: # 라인
#         #     geom=feature.geometry()
#         #     # distance=geom.length()/2
#         #     geompntxy = geom.vertexAt(0)
#         #     print(geom.wkbType())
        
#         # if feature.geometry().type() == 2:  # 폴리곤
#         geompnt=values[0].centroid()
#         geompntxy = geompnt.asPoint() # vertexAt(0)
            
#         if vallen == 2: 
#             geompntxy = transform(geompntxy,layer_crs,str(values[1]))
            
#         Centroidy = geompntxy.y()
            
#     except Exception:
#         parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
#         return parent
#     return Centroidy

# @qgsfunction(-1, group=group_name)
# def Bes2Wgs(values, feature, parent):
#     """
#     <b>Bessel</b>좌표를 <b>WGS</b> 좌표로 변환

#     <h4>구문</h4>
    
#     <li><b>Bes2Wgs</b> ( <i>Lon , Lat</i> )</li>
#     <li><b>Bes2Wgs</b> ( <i>SpeedFS</i> )</li>
    
#     <h4>인수</h4>
    
#     <p><i>Lon, Lat</i>  &rarr;  mms 경도,위도 좌표</p>
#     <p><i>Fs좌표</i>  &rarr;  4785(000000)(126.58.20.95/37.23.34.9)</p>

#     <h4>예제</h4>
#     <ul>
#       <li><b>Bes2Wgs</b> ( '45710850.35,13460476.03' ) &rarr; '45710095.01,13461489.98' </li>
#       <li><b>Bes2Wgs</b> ( '(45710850.35,13460476.03)' ) &rarr; '(45710095.01,13461489.98)' </li>
#       <li><b>Bes2Wgs</b> ( '4785(000000)(126.58.28.50/37.23.24.76)' ) &rarr; '4785(000000)(126.58.20.95/37.23.34.90)' </li>

#     </ul>
#     """
#     vallen = len(values)
#     if vallen != 1:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return
#     try:
#         text=str(values[0])
#         if text[0]=='(' and text[-1]==')':      # MMS 좌표 괄호 포함
#             text=text.strip('()')
#             text=text.split(',')
#             lon=text[0].strip()
#             lat=text[1].strip()
#             lon=float(lon)/360000
#             lat=float(lat)/360000
#             lon, lat = bestowgstransform(lon, lat)
#             lon=lon*360000
#             lat=lat*360000
#             val = str('('+str(lon) + ',' + str(lat)+')')

#         elif text[4]=='(' and text[11]==')':    # FS 좌표
#             text=text.strip()
#             text=text[12:].strip('()') # .replace('/', ',')
#             text=text.split('/')
#             lon=text[0].strip()
#             lat=text[1].strip()
#             lon=lon.split('.')
#             lat=lat.split('.')

#             lon2=lon[2]+'.'+lon[3]
#             lon2=float(lon2)/60
#             lon1=(int(lon[1])+lon2)/60
#             lon=(int(lon[0])+lon1)

#             lat2=lat[2]+'.'+lat[3]
#             lat2=float(lat2)/60
#             lat1=(int(lat[1])+lat2)/60
#             lat=(int(lat[0])+lat1)
#             x, y = bestowgstransform(lon, lat)
#             Lon = float(x*360000)
#             Lat = float(y*360000)
#             map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
#             map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
#             map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
#             map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
#             mapid = map1 + map2 + map3 + map4
#             LonD=int(x)
#             LonM=int(((x)-LonD)*60)
#             LonS=round(((((x)-LonD)*60)-LonM)*60,2)
#             LonS=format(LonS, ".2f")
#             LatD=int(y)
#             LatM=int(((y)-LatD)*60)
#             LatS=round(((((y)-LatD)*60)-LatM)*60,2)
#             LatS=format(LatS, ".2f")
#             val = mapid + '(000000)(' + str(LonD) +'.'+ str(LonM) +'.'+ str(LonS) +'/'+ str(LatD) +'.'+ str(LatM) +'.'+ str(LatS) + ')' 
            
#         elif text[0]=='4' or text[0]=='1':      # MMS 좌표 괄호 미포함
#             if text.find(',')>0:
#                 lon=text.split(',')[0]
#                 lat=text.split(',')[1]
#             elif text.find(' ')>0:
#                 lon=text.split(' ')[0]
#                 lat=text.split(' ')[1]
#             elif text.find('	')>0:
#                 lon=text.split('	')[0]
#                 lat=text.split('	')[1]
#             elif text.find('/')>0:
#                 lon=text.split('/')[0]
#                 lat=text.split('/')[1]
#             lon=float(lon)/360000
#             lat=float(lat)/360000
#             lon, lat = bestowgstransform(lon, lat)
#             lon=lon*360000
#             lat=lat*360000
#             val = str(str(lon) + ',' + str(lat))

#     except Exception:
#         parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
#         return parent
#     return val

# @qgsfunction(-1, group=group_name)
# def Wgs2Bes(values, feature, parent):
#     """
#     <b>WGS</b>좌표를 <b>Bessel</b> 좌표로 변환

#     <h4>구문</h4>
    
#     <li><b>Wgs2Bes</b> ( <i>Lon , Lat</i> )</li>
#     <li><b>Wgs2Bes</b> ( <i>SpeedFS</i> )</li>
    
#     <h4>인수</h4>
    
#     <p><i>Lon, Lat</i>  &rarr;  mms 경도,위도 좌표</p>
#     <p><i>Fs좌표</i>  &rarr;  4785(000000)(126.58.20.95/37.23.34.9)</p>

#     <h4>예제</h4>
#     <ul>
#       <li><b>Wgs2Bes</b> ( '45710095,13461490' ) &rarr; '45710850.35,13460476.03' </li>
#       <li><b>Wgs2Bes</b> ( '(45710095,13461490)' ) &rarr; '(45710850.35,13460476.03)' </li>
#       <li><b>Wgs2Bes</b> ( '4785(000000)(126.58.20.95/37.23.34.90)' ) &rarr; '4785(000000)(126.58.28.50/37.23.24.76)' </li>

#     </ul>
#     """
#     vallen = len(values)
#     if vallen != 1:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return
#     try:
#         text=str(values[0])
#         if text[0]=='(' and text[-1]==')':      # MMS 좌표 괄호 포함
#             text=text.strip('()')
#             text=text.split(',')
#             lon=text[0].strip()
#             lat=text[1].strip()
#             lon=float(lon)/360000
#             lat=float(lat)/360000
#             lon, lat = wgstobestransform(lon, lat)
#             lon=lon*360000
#             lat=lat*360000
#             val = str('('+str(lon) + ',' + str(lat)+')')

#         elif text[4]=='(' and text[11]==')':    # FS 좌표
#             text=text.strip()
#             text=text[12:].strip('()') # .replace('/', ',')
#             text=text.split('/')
#             lon=text[0].strip()
#             lat=text[1].strip()
#             lon=lon.split('.')
#             lat=lat.split('.')

#             lon2=lon[2]+'.'+lon[3]
#             lon2=float(lon2)/60
#             lon1=(int(lon[1])+lon2)/60
#             lon=(int(lon[0])+lon1)

#             lat2=lat[2]+'.'+lat[3]
#             lat2=float(lat2)/60
#             lat1=(int(lat[1])+lat2)/60
#             lat=(int(lat[0])+lat1)
#             x, y = wgstobestransform(lon, lat)
#             Lon = float(x*360000)
#             Lat = float(y*360000)
#             map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
#             map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
#             map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
#             map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
#             mapid = map1 + map2 + map3 + map4
#             LonD=int(x)
#             LonM=int(((x)-LonD)*60)
#             LonS=round(((((x)-LonD)*60)-LonM)*60,2)
#             LonS=format(LonS, ".2f")
#             LatD=int(y)
#             LatM=int(((y)-LatD)*60)
#             LatS=round(((((y)-LatD)*60)-LatM)*60,2)
#             LatS=format(LatS, ".2f")
#             val = mapid + '(000000)(' + str(LonD) +'.'+ str(LonM) +'.'+ str(LonS) +'/'+ str(LatD) +'.'+ str(LatM) +'.'+ str(LatS) + ')' 
            
#         elif text[0]=='4' or text[0]=='1':      # MMS 좌표 괄호 미포함
#             if text.find(',')>0:
#                 lon=text.split(',')[0]
#                 lat=text.split(',')[1]
#             elif text.find(' ')>0:
#                 lon=text.split(' ')[0]
#                 lat=text.split(' ')[1]
#             elif text.find('	')>0:
#                 lon=text.split('	')[0]
#                 lat=text.split('	')[1]
#             elif text.find('/')>0:
#                 lon=text.split('/')[0]
#                 lat=text.split('/')[1]
#             lon=float(lon)/360000
#             lat=float(lat)/360000
#             lon, lat = wgstobestransform(lon, lat)
#             lon=lon*360000
#             lat=lat*360000
#             val = str(str(lon) + ',' + str(lat))

#     except Exception:
#         parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
#         return parent
#     return val

@qgsfunction(-1, group=group_name)
def LonLat2Fs(values, feature, parent):
    """
    <b>mms경위도</b> 좌표을 <b>Fs</b> 좌표로 변환

    <h4>구문</h4>
    
    <li><b>LonLat2Fs</b> ( <i>Lon, Lat</i> )</li>

    <h4>인수</h4>
    
    <p><i>Lon</i>  &rarr;  mms경도 좌표</p>
    <p><i>Lat</i>  &rarr;  mms위도 좌표</p>

    <h4>예제</h4>
    <ul>
    
      <li><b>LonLat2Fs</b> ( 45735376.093135 , 13487184.37282 ) &rarr; '5716(000000)(127.2.33.76/37.27.51.84)' </li>
      
    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        geompntxy=[]
        if vallen==2:
            x = float(values[0])
            y = float(values[1])
            if x > 40000000 and y < 20000000 :
                Lon = x
                Lat = y
            else:
                Lon = y
                Lat = x
                
        elif vallen == 1:
            text=str(values[0])
            text=text.strip('()')
            text=text.split(',')
            x=float(text[0].strip())
            y=float(text[1].strip())
            if x > 40000000 and y < 20000000 :
                Lon = x
                Lat = y
            else:
                Lon = y
                Lat = x
                
        geompntxy.append(Lon)
        geompntxy.append(Lat)
        fs=fscoordinate(geompntxy)

    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return fs

# @qgsfunction(-1, group=group_name)
# def LonLat2Mapid(values, feature, parent):
#     """
#     <b>mms경위도</b> 좌표을 <b>Mapid</b> 로 변환

#     <h4>구문</h4>
    
#     <li><b>LonLat2Mapid</b> ( <i>Lon, Lat</i> )</li>

#     <h4>인수</h4>
    
#     <p><i>Lon</i>  &rarr;  mms경도 좌표</p>
#     <p><i>Lat</i>  &rarr;  mms위도 좌표</p>

#     <h4>예제</h4>
#     <ul>
    
#       <li><b>LonLat2Mapid</b> ( 45735376.093135 , 13487184.37282 ) &rarr; '57160000' </li>
      
#     </ul>
#     """
#     vallen = len(values)
#     if vallen > 2:
#         parent.setEvalErrorString("Error: 잘못된 인수 ")
#         return
#     try:
#         if vallen==2:
#             x = float(values[0])
#             y = float(values[1])
#             if x > 40000000 and y < 20000000 :
#                 Lon = x
#                 Lat = y
#             else:
#                 Lat = y
#                 Lat = x
                
#         elif vallen == 1:
#             text=str(values[0])
#             text=text.strip('()')
#             text=text.split(',')
#             x=float(text[0].strip())
#             y=float(text[1].strip())
#             if x > 40000000 and y < 20000000 :
#                 Lon = x
#                 Lat = y
#             else:
#                 Lon = y
#                 Lat = x
#         map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
#         map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
#         map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
#         map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
#         mapid = map1 + map2 + map3 + map4
        
#         mapid = mapid + '0000'
        
#     except Exception:
#         parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
#         return parent
#     return mapid

@qgsfunction(-1, group=group_name)
def Fs2LonLat(values, feature, parent):
    """
    <b>Fs</b> 좌표를 <b>mms경위도</b> 좌표로 변환

    <h4>구문</h4>
    
    <li><b>Fs2LonLat</b> ( <i>Fs좌표</i> )</li>

    <h4>인수</h4>
    
    <p><i>Fs좌표</i>  &rarr;  '5716(000000)(127.2.33.76/37.27.51.84)'</p>

    <h4>예제</h4>
    <ul>

    <li><b>Fs2LonLat</b> ( '5716(000000)(127.2.33.76/37.27.51.84)' ) &rarr; '45735375.9996,13487184.0' </li>

    </ul>
    """
    vallen = len(values)
    if vallen != 1:
        parent.setEvalErrorString(values,"Error: 잘못된 인수 ")
        return
    try:
        text=str(values[0]).strip()
        text=text[12:].strip('()') # .replace('/', ',')
        text=text.split('/')
        lon=text[0].strip()
        lat=text[1].strip()
        lon=lon.split('.')
        lat=lat.split('.')

        lon2=lon[2]+'.'+lon[3]
        lon2=float(lon2)/60
        lon1=round((int(lon[1])+lon2)/60,8)
        lon=(int(lon[0])+lon1)*360000

        lat2=lat[2]+'.'+lat[3]
        lat2=float(lat2)/60
        lat1=round((int(lat[1])+lat2)/60,8)
        lat=(int(lat[0])+lat1)*360000 
        lonlat = str(str(lon) + ',' + str(lat))

    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return lonlat

@qgsfunction(-1, group=group_name)
def Fs2Lon(values, feature, parent):
    """
    <b>Fs</b> 좌표를 <b>mms경도</b> 좌표로 변환

    <h4>구문</h4>
    
    <li><b>Fs2Lon</b> ( <i>Fs좌표</i> )</li>

    <h4>인수</h4>
    
    <p><i>Fs좌표</i>  &rarr;  '5716(000000)(127.2.33.76/37.27.51.84)'</p>

    <h4>예제</h4>
    <ul>

    <li><b>Fs2Lon</b> ( '5716(000000)(127.2.33.76/37.27.51.84)' ) &rarr; '45735375.9996' </li>

    </ul>
    """
    vallen = len(values)
    if vallen != 1:
        parent.setEvalErrorString(values,"Error: 잘못된 인수 ")
        return
    try:
        text=str(values[0]).strip()
        text=text[12:].strip('()') # .replace('/', ',')
        text=text.split('/')
        lon=text[0].strip()
        # lat=text[1].strip()
        lon=lon.split('.')
        # lat=lat.split('.')

        lon2=lon[2]+'.'+lon[3]
        lon2=float(lon2)/60
        lon1=round((int(lon[1])+lon2)/60,8)
        lon=(int(lon[0])+lon1)*360000

        # lat2=lat[2]+'.'+lat[3]
        # lat2=float(lat2)/60
        # lat1=round((int(lat[1])+lat2)/60,8)
        # lat=(int(lat[0])+lat1)*360000 
        # lonlat = str(str(lon) + ',' + str(lat))

    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return lon

@qgsfunction(-1, group=group_name)
def Fs2Lat(values, feature, parent):
    """
    <b>Fs</b> 좌표를 <b>mms위도</b> 좌표로 변환

    <h4>구문</h4>
    
    <li><b>Fs2Lat</b> ( <i>Fs좌표</i> )</li>

    <h4>인수</h4>
    
    <p><i>Fs좌표</i>  &rarr;  '5716(000000)(127.2.33.76/37.27.51.84)'</p>

    <h4>예제</h4>
    <ul>

    <li><b>Fs2Lat</b> ( '5716(000000)(127.2.33.76/37.27.51.84)' ) &rarr; '13487184' </li>

    </ul>
    """
    vallen = len(values)
    if vallen != 1:
        parent.setEvalErrorString(values,"Error: 잘못된 인수 ")
        return
    try:
        text=str(values[0]).strip()
        text=text[12:].strip('()') # .replace('/', ',')
        text=text.split('/')
        # lon=text[0].strip()
        lat=text[1].strip()
        # lon=lon.split('.')
        lat=lat.split('.')

        # lon2=lon[2]+'.'+lon[3]
        # lon2=float(lon2)/60
        # lon1=round((int(lon[1])+lon2)/60,8)
        # lon=(int(lon[0])+lon1)*360000

        lat2=lat[2]+'.'+lat[3]
        lat2=float(lat2)/60
        lat1=round((int(lat[1])+lat2)/60,8)
        lat=(int(lat[0])+lat1)*360000 
        # lonlat = str(str(lon) + ',' + str(lat))

    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return lat

@qgsfunction(-1, group=group_name)
def Fs2Mms(values, feature, parent):
    """
    <b>Fs</b> 좌표를 <b>mms경위도</b> 좌표로 변환(괄호포함)

    <h4>구문</h4>
    
    <li><b>Fs2Mms</b> ( <i>Fs좌표</i> )</li>

    <h4>인수</h4>
    
    <p><i>Fs좌표</i>  &rarr;  '5716(000000)(127.2.33.76/37.27.51.84)'</p>

    <h4>예제</h4>
    <ul>

    <li><b>Fs2Mms</b> ( '5716(000000)(127.2.33.76/37.27.51.84)' ) &rarr; '(45735375.9996,13487184.0)' </li>

    </ul>
    """
    vallen = len(values)
    if vallen != 1:
        parent.setEvalErrorString(values,"Error: 잘못된 인수 ")
        return
    try:
        text=str(values[0]).strip()
        text=text[12:].strip('()') # .replace('/', ',')
        text=text.split('/')
        lon=text[0].strip()
        lat=text[1].strip()
        lon=lon.split('.')
        lat=lat.split('.')

        lon2=lon[2]+'.'+lon[3]
        lon2=float(lon2)/60
        lon1=round((int(lon[1])+lon2)/60,8)
        lon=(int(lon[0])+lon1)*360000

        lat2=lat[2]+'.'+lat[3]
        lat2=float(lat2)/60
        lat1=round((int(lat[1])+lat2)/60,8)
        lat=(int(lat[0])+lat1)*360000 
        mms = str('('+str(lon) + ',' + str(lat)+')')

    except Exception:
        parent.setEvalErrorString(" 'Error: invalid latitude, longitude, or parameters'")
        return parent
    return mms

@qgsfunction(-1, group=group_name)
# def MMStoFS(values, feature, parent):
def 협력사(values, feature, parent):
    """
    도형의 중앙점 좌표 또는 필드의 좌표값이나 Mapid를 협력사로 변환
    
    <h4>구문</h4>
    
    <li><b>협력사</b> ( <i> $geometry </i> )</li>
    <li><b>협력사</b> ( <i> 'Fs좌표' </i> )</li>
    <li><b>협력사</b> ( <i> 'MapID' </i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>Fs좌표</i>  &rarr; Fs좌표 </p>
    <p><i>MapID</i>  &rarr; '5716' 또는 '57160000' </p>
    
    <h4>예제</h4>
    <ul>
    
      <li><b>협력사</b> ( $geometry ) &rarr; '매스코' </li>
      <li><b>협력사</b> ( '57160000' ) &rarr; '매스코' </li>
      <li><b>협력사</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '매스코' </li>
      
    </ul>
    """
    vallen = len(values)

    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    
    try:
        geom=values[0]
        try:
            if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                layer = iface.activeLayer() # 선택레이어
                layer_crs = layer.crs().authid() # 레이어 좌표계
                
                if geom.type() == 0 or geom.type() == 2:
                    geompnt=geom.centroid()
                    geompntxy = geompnt.asPoint() # vertexAt(0)
                    
                elif geom.type() == 1: # 라인
                    distance=geom.length()/2
                    geompnt = geom.interpolate(distance)
                    geompntxy = geompnt.asPoint() # vertexAt(0)
                    
                geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
                
                x=geompntxy[0]
                y=geompntxy[1]
                Lon = float(x*360000)
                Lat = float(y*360000)

                map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
                map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
                map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
                map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
                mapid = map1 + map2 + map3 + map4
                
        except:
    
            mapid=str(values[0])[:4]
    
        mapid_Info=mapids.get(str(mapid))
            
        if mapid_Info != None:
            partner = mapid_Info[0]
        else:
            partner = None

    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return partner


@qgsfunction(-1, group=group_name)
# def MMStoFS(values, feature, parent):
def 담당(values, feature, parent):
    """
    좌표 또는 Mapid 를 담당 팀으로 변환
    
    <h4>구문</h4>
    
    <li><b>담당</b> ( <i>$geometry </i> )</li>
    <li><b>담당</b> ( <i> 'Fs좌표' </i> )</li>
    <li><b>담당</b> ( <i> 'MapID' </i>  )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>Fs좌표</i>  &rarr; Fs좌표 </p>
    <p><i>MapID</i>  &rarr; '5716' 또는 '57160000' </p>

    <h4>예제</h4>
    <ul>
    
      <li><b>담당</b> ( $geometry ) &rarr; '본사' </li>
      <li><b>담당</b> ( '57160000' ) &rarr; '본사' </li>
      <li><b>담당</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '본사' </li>
      
    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        geom=values[0]
        try:
            if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                layer = iface.activeLayer() # 선택레이어
                layer_crs = layer.crs().authid() # 레이어 좌표계
                
                if geom.type() == 0 or geom.type() == 2:
                    geompnt=geom.centroid()
                    geompntxy = geompnt.asPoint() # vertexAt(0)
                    
                elif geom.type() == 1: # 라인
                    distance=geom.length()/2
                    geompnt = geom.interpolate(distance)
                    geompntxy = geompnt.asPoint() # vertexAt(0)

                geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
                
                x=geompntxy[0]
                y=geompntxy[1]
                Lon = float(x*360000)
                Lat = float(y*360000)

                map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
                map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
                map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
                map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
                mapid = map1 + map2 + map3 + map4
                
        except:
    
            mapid=str(values[0])[:4]
        
        mapid_Info=mapids.get(str(mapid))
        
        if mapid_Info != None:
            team = mapid_Info[1]
        else:
            team = None

    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return team

@qgsfunction(-1, group=group_name)
# def MMStoFS(values, feature, parent):
def 대권역(values, feature, parent):
    """
    좌표 또는 Mapid 를 대권역으로 변환
    
    <h4>구문</h4>
    
    <li><b>대권역</b> ( <i> $geometry </i> )</li>
    <li><b>대권역</b> ( <i> 'Fs좌표' </i> )</li>
    <li><b>대권역</b> ( <i> 'MapID' </i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>Fs좌표</i>  &rarr; Fs좌표 </p>
    <p><i>MapID</i>  &rarr; '5716' 또는 '57160000' </p>

    <h4>예제</h4>
    <ul>
    
      <li><b>대권역</b> ( $geometry ) &rarr; '서울특별시' </li>
      <li><b>대권역</b> ( '57160000' ) &rarr; '서울특별시' </li>
      <li><b>대권역</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '서울특별시' </li>
      
    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        geom=values[0]
        try:
            if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                layer = iface.activeLayer() # 선택레이어
                layer_crs = layer.crs().authid() # 레이어 좌표계
                
                if geom.type() == 0 or geom.type() == 2:
                    geompnt=geom.centroid()
                    geompntxy = geompnt.asPoint() # vertexAt(0)
                    
                elif geom.type() == 1: # 라인
                    distance=geom.length()/2
                    geompnt = geom.interpolate(distance)
                    geompntxy = geompnt.asPoint() # vertexAt(0)

                geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
                
                x=geompntxy[0]
                y=geompntxy[1]
                Lon = float(x*360000)
                Lat = float(y*360000)

                map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
                map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
                map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
                map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
                mapid = map1 + map2 + map3 + map4
                
        except:
    
            mapid=str(values[0])[:4]
        
        mapid_Info=mapids.get(str(mapid))
        
        if mapid_Info != None:
            largearea = mapid_Info[2]
        else:
           largearea = None

    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return largearea

@qgsfunction(-1, group=group_name)
# def MMStoFS(values, feature, parent):
def 소권역(values, feature, parent):
    """
    좌표 또는 Mapid 를 소권역으로 변환
    
    <h4>구문</h4>
    
    <li><b>소권역</b> ( <i> $geometry </i> )</p>
    <li><b>소권역</b> ( <i> 'Fs좌표' </i> )</li>
    <li><b>소권역</b> ( <i> 'MapID' </i> )</li>
    
    <h4>인수</h4>
    
    <p><i>$geometry</i>  &rarr;  도형</p>
    <p><i>Fs좌표</i>  &rarr; Fs좌표 </p>
    <p><i>MapID</i>  &rarr; '5716' 또는 '57160000' </p>

    <h4>예제</h4>
    <ul>
    
      <li><b>소권역</b> ( $geometry ) &rarr; '서초구' </li>
      <li><b>소권역</b> ( '57160000' ) &rarr; '서초구' </li>
      <li><b>소권역</b> ( '5716(000000)(127.2.33.76/37.27.51.84' ) &rarr; '서초구' </li>
      
    </ul>
    """
    vallen = len(values)
    if vallen > 2:
        parent.setEvalErrorString("Error: 잘못된 인수 ")
        return
    try:
        geom=values[0]
        try:
            if geom.type() == 0 or geom.type() == 1 or geom.type() == 2:
                layer = iface.activeLayer() # 선택레이어
                layer_crs = layer.crs().authid() # 레이어 좌표계
                
                if geom.type() == 0 or geom.type() == 2:
                    geompnt=geom.centroid()
                    geompntxy = geompnt.asPoint() # vertexAt(0)
                    
                elif geom.type() == 1: # 라인
                    distance=geom.length()/2
                    geompnt = geom.interpolate(distance)
                    geompntxy = geompnt.asPoint() # vertexAt(0)

                geompntxy = transform(geompntxy,layer_crs if vallen == 1 else values[1] ,"EPSG:4162")
                
                x=geompntxy[0]
                y=geompntxy[1]
                Lon = float(x*360000)
                Lat = float(y*360000)

                map1 = str(int(((int(round(((Lon - 44617500) / 45000), 0)) - 1) / 8) + 2))
                map2 = str(int(((int(round(((Lat - 11865000) / 30000), 0)) - 1) / 8) + 1))
                map3 = str(int((int(round(((Lon - 44617500) / 45000), 0)) + 8) - (math.ceil(int(round(((Lon - 44617500) / 45000), 0)) / 8) * 8)))
                map4 = str(int((int(round(((Lat - 11865000) / 30000), 0)) + 8) - (math.ceil(int(round(((Lat - 11865000) / 30000), 0)) / 8) * 8)))
                mapid = map1 + map2 + map3 + map4
                
        except:
    
            mapid=str(values[0])[:4]
        
        mapid_Info=mapids.get(str(mapid))
            
        if mapid_Info != None:
            smallarea = mapid_Info[3]
        else:
           smallarea = None

    except Exception:
        parent.setEvalErrorString("Error: invalid latitude, longitude, or parameters")
        return
    return smallarea