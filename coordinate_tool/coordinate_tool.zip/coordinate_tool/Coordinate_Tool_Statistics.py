# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
#  속성통계 (선택 객체의 필드/식 합계·개수)
#  v1.1 (2026-11-05)
#   - 통계 블록 2개 → 최대 4개 (groupBox_1~4), 추가/삭제/초기화 버튼
#     (toolButton_add / toolButton_del / toolButton_re)
#   - UI 위젯명 변경 대응 : mFieldExpressionWidget → mFieldExpressionWidget_1
#   - 시그널 정리 : layerChanged/fieldChanged는 __init__에서 1회만 연결
#       (기존 showEvent마다 lambda 재연결 → 중복 호출, hideEvent의 lambda 해제는 항상 실패)
#   - 선택변경 감지 : canvas.selectionChanged → 각 레이어의 selectionChanged
#       (다른 레이어 선택 시 불필요한 호출 제거, 해제가 확실함)
#   - 선택 해제 / 식 삭제 / 잘못된 식일 때 이전 결과가 남던 문제 수정
#   - 필드 1개짜리 식만 지원하던 제한 제거 ($length, "a"+"b" 등 식 전체 지원)
#   - 집계 enum 버전 분기 수정 (Qgis.Aggregate 존재 여부로 판단)
#   - QSettings에 레이어 객체 대신 레이어 ID 저장
# ----------------------------------------------------------------------

import os
from qgis.PyQt import QtWidgets
from qgis.PyQt.uic import loadUiType
from qgis.core import QgsMapLayerType, Qgis, QgsAggregateCalculator, QgsApplication
from qgis.PyQt.QtCore import QVariant, QSettings

VERSION = Qgis.QGIS_VERSION_INT

# v1.1: 집계 enum 선택
#   기존: VERSION >= 34000 이면 Qgis.Aggregate, 아니면 정수코드 전달
#   변경: Qgis.Aggregate 가 있으면 사용, 없으면(구버전) QgsAggregateCalculator 의 enum 사용
AggEnum = getattr(Qgis, 'Aggregate', QgsAggregateCalculator)

# 코드 → 함수명 매핑 (이름 = Qgis.Aggregate 멤버명)
#   항목을 늘리면 _compute_aggregates() 결과 dict에 자동으로 들어간다
agg_map = {
    0: "Count", 5: "Sum"
}

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Statistics.ui'))

class StatisticsDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(StatisticsDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chk = False

        # v1.1: 통계 블록 관리 값 (블록 번호 n = 1 ~ MaxCnt)
        self.MaxCnt = 4          # 최대 통계 블록 수
        self.RowCnt = 1          # 현재 화면에 보이는 블록 수
        self.blk_layer = {}      # n → selectionChanged 를 연결해 둔 레이어
        self.blk_slot  = {}      # n → 연결에 쓴 함수 (해제할 때 같은 객체가 필요)
        self.blk_cache = {}      # n → (식, 선택 fid) 직전 계산 키

        for n in range(1, self.MaxCnt+1):
            self.blk_layer[n] = None
            self.blk_cache[n] = None
            self.blk_slot[n]  = lambda *a, n=n: self.onExpressionChanged(n)

            combo = self.layerCombo(n)
            combo.setAllowEmptyLayer(True)
            combo.setCurrentIndex(0)
            # n=n 기본인자 : 반복문 변수 늦은 바인딩 방지
            combo.layerChanged.connect(lambda *a, n=n: self.LayerChange(n))
            self.exprWidget(n).fieldChanged.connect(lambda *a, n=n: self.onExpressionChanged(n))

        # v1.1: 블록 추가 / 삭제 / 초기화 버튼 (QGIS 내장 테마 아이콘)
        self.toolButton_add.setIcon(QgsApplication.getThemeIcon('/symbologyAdd.svg'))
        self.toolButton_del.setIcon(QgsApplication.getThemeIcon('/symbologyRemove.svg'))
        self.toolButton_re.setIcon(QgsApplication.getThemeIcon('/mActionRefresh.svg'))
        self.toolButton_add.clicked.connect(self.addRow)
        self.toolButton_del.clicked.connect(self.delRow)
        self.toolButton_re.clicked.connect(self.resetRows)

        self.del_result()
        self.showRows(1)                     # 처음에는 통계1만 표시
        self.chk = True

    # ==================================================================
    #  v1.1 : 블록 n 의 위젯 찾기
    #    lineEdit 번호 규칙 : 합계 = 2n-1, 개수 = 2n
    # ==================================================================
    def layerCombo(self, n):
        return getattr(self, 'mMapLayerComboBox_%d' % n)

    def exprWidget(self, n):
        return getattr(self, 'mFieldExpressionWidget_%d' % n)

    def sumEdit(self, n):
        return getattr(self, 'lineEdit_%d' % (2*n-1))

    def cntEdit(self, n):
        return getattr(self, 'lineEdit_%d' % (2*n))

    def del_result(self, n=None):
        """v1.1: 결과칸과 계산 캐시를 비운다. n=None 이면 전체
           (기존 idx 규칙 0/2/1 → 블록 번호 1~4 / None)"""
        nums = range(1, self.MaxCnt+1) if n is None else [n]
        for k in nums:
            self.blk_cache[k] = None
            self.sumEdit(k).setText('')
            self.cntEdit(k).setText('')

    # ==================================================================
    #  v1.1 : 블록 표시 / 추가 / 삭제 / 초기화
    # ==================================================================
    def showRows(self, cnt):
        """통계 1~cnt 블록만 보이고 나머지는 숨긴다."""
        self.RowCnt = max(1, min(cnt, self.MaxCnt))
        for n in range(1, self.MaxCnt+1):
            getattr(self, 'groupBox_%d' % n).setVisible(n <= self.RowCnt)
        self.toolButton_add.setEnabled(self.RowCnt < self.MaxCnt)
        self.toolButton_del.setEnabled(self.RowCnt > 1)

    def clearBlock(self, n):
        """블록 n 을 빈 상태로 (레이어 해제, 식 비움, 시그널 해제, 결과 비움)"""
        chk = self.chk
        self.chk = False                     # layerChanged → LayerChange 중복 실행 방지
        self.layerCombo(n).setCurrentIndex(0)
        self.exprWidget(n).setLayer(None)
        self.exprWidget(n).setExpression("")
        self.connectLayer(n, None)
        self.del_result(n)
        self.chk = chk

    def addRow(self, *args):
        """다음 블록을 하나 표시 (2 → 3 → 4)"""
        if self.RowCnt < self.MaxCnt:
            self.showRows(self.RowCnt + 1)

    def delRow(self, *args):
        """마지막 블록을 비우고 숨김 (4 → 3 → 2, 통계1은 유지)"""
        if self.RowCnt > 1:
            self.clearBlock(self.RowCnt)
            self.showRows(self.RowCnt - 1)

    def resetRows(self, *args):
        """초기화 : 모든 블록을 비우고 통계1만 표시"""
        for n in range(1, self.MaxCnt+1):
            self.clearBlock(n)
        self.showRows(1)

    def connectLayer(self, n, layer):
        """v1.1: 블록 n 의 선택변경 감지 대상을 layer 로 교체 (None 이면 해제만)
           기존 canvas.selectionChanged 는 모든 레이어 선택에 반응하고,
           캔버스에 표시되지 않은 레이어는 감지하지 못할 수 있어 레이어 시그널로 변경"""
        old = self.blk_layer[n]
        if old is not None:
            try:
                old.selectionChanged.disconnect(self.blk_slot[n])
            except (TypeError, RuntimeError):
                pass                         # 이미 해제됨 / 레이어가 삭제됨
        self.blk_layer[n] = layer
        if layer is not None:
            layer.selectionChanged.connect(self.blk_slot[n])

    def format_number(self, num):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)

    @staticmethod
    def _is_null(v):
        """v1.1: None / QVariant NULL 판정 (Qt5는 NULL이 QVariant, Qt6는 None)"""
        return v is None or (isinstance(v, QVariant) and v.isNull())

    def _compute_aggregates(self, layer, expr_str, fids):
        """선택 FID 범위에서 agg_map 의 집계를 계산해 {이름: 값} 으로 반환
           v1.1: 필드 타입으로 미리 거르지 않고 계산 성공(ok) 여부로 판단
                 → 식 전체($length, "a"+"b" 등) 지원, 문자열 합계는 자동 제외"""
        calc = QgsAggregateCalculator(layer)
        calc.setFidsFilter(fids)

        results = {}
        for code, name in agg_map.items():
            val, ok = calc.calculate(getattr(AggEnum, name), expr_str)
            if ok:
                results[name] = val
        return results

    def onExpressionChanged(self, n, *args):
        """v1.1: 블록 n 의 결과 갱신 (기존 onExpressionChanged_1/2 + _generic 통합)"""
        layer = self.blk_layer[n]
        expw = self.exprWidget(n)
        if layer is None:
            self.del_result(n)
            return

        expr_str = expw.expression()
        fids = layer.selectedFeatureIds()
        # v1.1: 식 없음 / 잘못된 식 / 선택 없음 → 이전 결과가 남지 않도록 비움
        if not expr_str or not expw.isValidExpression() or not fids:
            self.del_result(n)
            return

        # 같은 식·같은 선택이면 다시 계산하지 않음
        key = (expr_str, fids)
        if key == self.blk_cache[n]:
            return
        self.blk_cache[n] = key

        results = self._compute_aggregates(layer, expr_str, fids)
        sum_val = results.get("Sum")
        cnt_val = results.get("Count")

        # 결과 반올림·형변환 (계산 불가 항목은 빈칸)
        self.sumEdit(n).setText(
            '' if self._is_null(sum_val) else f"{self.detect_rounding_place(sum_val)}")
        self.cntEdit(n).setText(
            '' if self._is_null(cnt_val) else f"{int(cnt_val)}")

    def detect_rounding_place(self, num):
        if num:
            str_num = f"{num:.16f}"  # 충분한 자리수 확보
            decimals = str_num.split(".")[1]
            if '999999' in decimals:
                idx = decimals.find('999999')
                # 연속되는 9 앞자리까지가 정확한 자리
                return round( num, idx)
            elif '000000' in decimals:
                idx = decimals.find('000000')
                if idx == 0:
                    return int(num)
                else:  
                    return round( num, idx)
        return num

    def hideEvent(self, event):
        # v1.1: 숨겨지면 레이어 선택변경 감지만 해제
        #   (기존: lambda disconnect 가 항상 실패 → 아래 줄들이 실행되지 않음)
        for n in range(1, self.MaxCnt+1):
            self.connectLayer(n, None)
        super().hideEvent(event)

    def showEvent(self, event):
        # v1.1: 다시 표시되면 각 블록을 빈 상태로 (기존 동작 유지)
        #   기존: 표시될 때마다 layerChanged 에 lambda 를 새로 연결 → 중복 실행 누적
        for n in range(1, self.MaxCnt+1):
            self.clearBlock(n)
        super().showEvent(event)

    def LayerChange(self, n):
        """v1.1: 블록 n 의 레이어 변경 (기존 idx 0/2 분기 → 블록 번호 1~4 공통 처리)"""
        if self.chk:
            combo = self.layerCombo(n)
            expw = self.exprWidget(n)
            layer = combo.currentLayer()
            if combo.currentIndex() > 0 and layer is not None and layer.type() == QgsMapLayerType.VectorLayer:
                expw.setLayer(layer)
                expw.setExpression("")
                self.connectLayer(n, layer)
                # v1.1: 레이어 객체 대신 레이어 ID 저장 (객체는 설정 파일에 저장 불가)
                self.QSettings.setValue('mMapLayerComboBox_%d' % n, layer.id())
            else:
                expw.setLayer(None)
                expw.setExpression("")
                self.connectLayer(n, None)
            self.del_result(n)