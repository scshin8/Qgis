# -*- coding: utf-8 -*-

import os, statistics
from qgis.PyQt import QtWidgets
from qgis.PyQt.uic import loadUiType
from qgis.core import QgsMapLayerType, QgsWkbTypes, QgsExpression, QgsAggregateCalculator, QgsFeatureRequest, QgsExpressionContext, QgsExpressionContextUtils
from PyQt5.QtCore import QSettings
from qgis.PyQt.QtCore import QVariant
from PyQt5.QtWidgets import (QApplication, 
                             QPushButton, 
                             QComboBox,
                             QTableWidgetItem, 
                             QLineEdit)

# 코드 → 함수명 매핑
# agg_map = {
#     0: "Count", 1: "CountDistinct", 2: "CountNulls",
#     3: "Min", 4: "Max", 5: "Sum", 6: "Mean", 7: "Median",
#     8: "StDev", 9: "StDevSample", 10: "Range",
#     11: "Minority", 12: "Majority", 13: "FirstQuartile",
#     14: "ThirdQuartile", 15: "InterQuartileRange",
#     16: "StringMinLength", 17: "StringMaxLength",
#     18: "StringConcatenate", 19: "GeometryCollect",
#     20: "ArrayAggregate", 21: "StringConcatUnique",
#     22: "StringAvgLength"
# }

# 코드 → 함수명 매핑
agg_map = {
    0: "Count", 5: "Sum"
}
# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Statistics.ui'))

class StatisticsDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(StatisticsDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chk = False

        self.mMapLayerComboBox_1.layerChanged.connect(lambda : self.LayerChange(0))
        self.mMapLayerComboBox_1.setAllowEmptyLayer(True)
        self.mMapLayerComboBox_1.setCurrentIndex(0)

        self.mMapLayerComboBox_2.layerChanged.connect(lambda : self.LayerChange(2))
        self.mMapLayerComboBox_2.setAllowEmptyLayer(True)
        self.mMapLayerComboBox_2.setCurrentIndex(0)
        self.del_result(1)
        # self.canvas.selectionChanged.connect(self.statisticsView2)
        self.chk = True

    def del_result(self, idx):
        if idx == 0:
            self._last_expr_1 = None
            self._last_fids_1 = None
            self.lineEdit_1.setText('')
            self.lineEdit_2.setText('') 
        elif idx == 2:
            self._last_expr_2 = None
            self._last_fids_2 = None
            self.lineEdit_3.setText('')
            self.lineEdit_4.setText('')
        elif idx == 1:
            self._last_expr_1 = None
            self._last_fids_1 = None
            self.lineEdit_1.setText('')
            self.lineEdit_2.setText('') 
            self._last_expr_2 = None
            self._last_fids_2 = None
            self.lineEdit_3.setText('')
            self.lineEdit_4.setText('')

    def format_number(self, num):
        # 소수점 첫째 자리가 0인지 확인
        if int(num * 10) % 10 == 0:
            return int(num)
        else:
            return num
    
    def onExpressionChanged_1(self):

        layer1 = self.mMapLayerComboBox_1.currentLayer()
        if not layer1:
            self.del_result(0)
            return
        # 선택된 FID 리스트로 subset 문자열 생성
        fids1 = layer1.selectedFeatureIds()
        calc1 = QgsAggregateCalculator(layer1)

        if fids1:
            calc1 = QgsAggregateCalculator(layer1)
            calc1.setFidsFilter(fids1)
        else:
            self.del_result(0)
            return
        
        expr_str1 = self.mFieldExpressionWidget.expression()
        # **이미 처리한 식이면 건너뛰기**
        if expr_str1 == self._last_expr_1 and fids1 == self._last_fids_1:
            return
        
        self._last_expr_1 = expr_str1
        self._last_fids_1 = fids1

        expr1 = QgsExpression(expr_str1)
        cols1 = expr1.referencedColumns()
        if not cols1:
            self.del_result(0)
            return

        field_name1  = list(cols1)[0]  # 선택된 필드 정보
        field_type1 = layer1.fields().field(field_name1).type() # QVariant 타입 코드

        # 숫자형 / 문자열형 / 날짜시간형 여부
        is_numeric = field_type1 in (QVariant.Int, QVariant.LongLong, QVariant.Double)
        is_string  = field_type1 == QVariant.String
        is_date    = field_type1 in (QVariant.Date, QVariant.DateTime, QVariant.Time)

        results1 = {}
        for code, name in agg_map.items():
            # 타입별 허용 여부 판단
            if code in (5,6,7,8,9,13,14,15) and not is_numeric:
                results1[name] = ('', False)
                continue
            if code in (16, 17, 18, 21, 22) and not is_string:
                results1[name] = ('', False)
                continue
            if code == 19:
                # 지오메트리 전용
                if not layer1.geometryType() in (QgsWkbTypes.PointGeometry,
                                                QgsWkbTypes.LineGeometry,
                                                QgsWkbTypes.PolygonGeometry):
                    results1[name] = ('', False)
                    continue
            # 날짜시간 전용 추가 체크는 필요 없으며, Min/Max/Range가 날짜에서 동작
            if name == "StringAvgLength":
                results1["StringAvgLength"] = calc1.calculate(6, f'length({expr_str1})')
            else:
                val = calc1.calculate(code, expr_str1)
                results1[name] = val

        # 전체 결과 출력
        # for name, val in results.items():
        #     print(f"{name:20s} → {val}")

        self.lineEdit_1.setText(f"{self.detect_rounding_place(results1['Sum'][0])}")
        self.lineEdit_2.setText(f"{int(results1['Count'][0])}") 

    def onExpressionChanged_2(self):
        
        layer2 = self.mMapLayerComboBox_2.currentLayer()
        if not layer2:
            self.del_result(2)
            return
        # 선택된 FID 리스트로 subset 문자열 생성
        fids2 = layer2.selectedFeatureIds()
        calc2 = QgsAggregateCalculator(layer2)

        if fids2:
            calc2 = QgsAggregateCalculator(layer2)
            calc2.setFidsFilter(fids2)
        else:
            self.del_result(2)
            return
        
        expr_str2 = self.mFieldExpressionWidget_2.expression()
        # **이미 처리한 식이면 건너뛰기**
        if expr_str2 == self._last_expr_2 and fids2 == self._last_fids_2:
            return
        
        self._last_expr_2 = expr_str2
        self._last_fids_2 = fids2

        expr2 = QgsExpression(expr_str2)
        cols2 = expr2.referencedColumns()
        if not cols2:
            self.del_result(2)
            return

        field_name2  = list(cols2)[0]  # 선택된 필드 정보
        field_type2 = layer2.fields().field(field_name2).type() # QVariant 타입 코드

        # 숫자형 / 문자열형 / 날짜시간형 여부
        is_numeric = field_type2 in (QVariant.Int, QVariant.LongLong, QVariant.Double)
        is_string  = field_type2 == QVariant.String
        is_date    = field_type2 in (QVariant.Date, QVariant.DateTime, QVariant.Time)

        results2 = {}
        for code, name in agg_map.items():
            # 타입별 허용 여부 판단
            if code in (5,6,7,8,9,13,14,15) and not is_numeric:
                results2[name] = ('', False)
                continue
            if code in (16, 17, 18, 21, 22) and not is_string:
                results2[name] = ('', False)
                continue
            if code == 19:
                # 지오메트리 전용
                if not layer2.geometryType() in (QgsWkbTypes.PointGeometry,
                                                QgsWkbTypes.LineGeometry,
                                                QgsWkbTypes.PolygonGeometry):
                    results2[name] = ('', False)
                    continue
            # 날짜시간 전용 추가 체크는 필요 없으며, Min/Max/Range가 날짜에서 동작
            if name == "StringAvgLength":
                results2["StringAvgLength"] = calc2.calculate(6, f'length({expr_str2})')
            else:
                val = calc2.calculate(code, expr_str2)
                results2[name] = val

        # 전체 결과 출력
        # for name, val in results.items():
        #     print(f"{name:20s} → {val}")

        self.lineEdit_3.setText(f"{self.detect_rounding_place(results2['Sum'][0])}")
        self.lineEdit_4.setText(f"{int(results2['Count'][0])}") 

    def detect_rounding_place(self, num):
        if num:
            str_num = f"{num:.16f}"  # 충분한 자리수 확보
            decimals = str_num.split(".")[1]
            if '999999' in decimals:
                idx = decimals.find('999999')
                # 연속되는 9 앞자리까지가 정확한 자리
                return round( num, idx)
            elif '000000' in decimals:
                idx = decimals.find('000000')
                if idx == 0:
                    return int(num)
                else:  
                    return round( num, idx)
        return num
    
    def hideEvent(self, event):
        try:
            self.mMapLayerComboBox_1.layerChanged.disconnect(lambda : self.LayerChange(0))
            self.mMapLayerComboBox_2.layerChanged.disconnect(lambda : self.LayerChange(2))
            self.canvas.selectionChanged.disconnect(self.onExpressionChanged_1)
            self.canvas.selectionChanged.disconnect(self.onExpressionChanged_2)
            print('selectionChanged 시그널이 정상적으로 해제되었습니다.')
        except TypeError:
            # 이미 disconnect되었거나 연결되지 않았을 때 예외 처리
            print('selectionChanged 시그널이 이미 해제되었습니다.')
        super().hideEvent(event)

    # 위젯이 다시 표시될 때 연결을 재설정하려면 showEvent도 정의할 수 있습니다.
    def showEvent(self, event):
        try:
            self.mMapLayerComboBox_1.layerChanged.connect(lambda : self.LayerChange(0))
            self.mMapLayerComboBox_2.layerChanged.connect(lambda : self.LayerChange(2))
            self.mMapLayerComboBox_1.setCurrentIndex(0)
            self.mMapLayerComboBox_2.setCurrentIndex(0)
            self.mFieldExpressionWidget.setLayer(None)
            self.mFieldExpressionWidget.setExpression("")
            self.mFieldExpressionWidget_2.setLayer(None)
            self.mFieldExpressionWidget_2.setExpression("")
            print('selectionChanged 시그널이 정상적으로 연결되었습니다.')
        except TypeError:
            print('selectionChanged 시그널이 이미 연결되었습니다.')
        super().showEvent(event)

    def LayerChange(self, idx):
        if self.chk:
            if idx == 0:
                try:
                    self.mFieldExpressionWidget.fieldChanged.disconnect(self.onExpressionChanged_1)
                    self.canvas.selectionChanged.disconnect(self.onExpressionChanged_1)

                except TypeError:
                    pass  # 이미 연결 해제된 경우

                layer = self.mMapLayerComboBox_1.currentLayer()
                if self.mMapLayerComboBox_1.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                    self.mFieldExpressionWidget.setLayer(layer)
                    self.mFieldExpressionWidget.setExpression("")
                    self.mFieldExpressionWidget.fieldChanged.connect(self.onExpressionChanged_1)
                    self.canvas.selectionChanged.connect(self.onExpressionChanged_1)
                    self.QSettings.setValue('mMapLayerComboBox_1', layer)
                    self._last_expr_1 = None
                    self._last_fids_1 = None
                    self.del_result(0)

                elif self.mMapLayerComboBox_1.currentIndex() == 0:
                    self.mFieldExpressionWidget.setLayer(None)
                    self.mFieldExpressionWidget.setExpression("")

            elif idx == 2:
                try:
                    self.mFieldExpressionWidget.fieldChanged.disconnect(self.onExpressionChanged_2)
                    self.canvas.selectionChanged.disconnect(self.onExpressionChanged_2)

                except TypeError:
                    pass  # 이미 연결 해제된 경우

                layer = self.mMapLayerComboBox_2.currentLayer()
                if self.mMapLayerComboBox_2.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                    self.mFieldExpressionWidget_2.setLayer(layer)
                    self.mFieldExpressionWidget_2.setExpression("")
                    self.mFieldExpressionWidget_2.fieldChanged.connect(self.onExpressionChanged_2)
                    self.canvas.selectionChanged.connect(self.onExpressionChanged_2)
                    self.QSettings.setValue('mMapLayerComboBox_2', layer)
                    self._last_expr_2 = None
                    self._last_fids_2 = None
                    self.del_result(2)
                    
                elif self.mMapLayerComboBox_2.currentIndex() == 0:
                    self.mFieldExpressionWidget_2.setLayer(None)
                    self.mFieldExpressionWidget_2.setExpression("")

    # def statistic(self, features, index):
    #     field_values = []  # 선택된 필드의 값을 저장할 리스트
    #     field_count = len(features)
    #     for feature in features:
    #         field_value = feature.attributes()[index]  # 선택한 필드의 값 가져오기
    #     # 값이 숫자일 경우에만 리스트에 추가
    #         if isinstance(field_value, (int, float, str)):
    #             field_values.append(field_value)  # 값을 리스트에 추가

    # # 선택한 필드의 속성 통계 계산
    #     field_min = min(field_values) if field_values else None
    #     field_max = max(field_values) if field_values else None
    #     # field_count = len(field_values)

    # # 합계 및 평균은 숫자에 대해서만 계산됩니다.
    #     field_sum = round(sum(val for val in field_values if isinstance(val, (int, float))),3) if field_values else None
    #     field_mean = round(field_sum / field_count,3) if field_sum is not None and field_count > 0 else None  # 평균 계산

    # # 표준편차는 데이터가 2개 이상인 경우에만 계산
    #     if len(field_values) >= 2:
    #         numeric_values = [val for val in field_values if isinstance(val, (int, float))]
    #         if len(numeric_values) >= 2:
    #             field_std_dev = statistics.stdev(numeric_values)
    #         else:
    #             field_std_dev = None
    #     else:
    #         field_std_dev = None

    #     # field_std_dev = statistics.stdev(val for val in field_values if isinstance(val, (int, float))) if len(field_values) >= 2 else None

    # # 선택한 필드의 속성 통계 출력
    #     return field_sum, field_count, field_mean, field_min, field_max, field_std_dev

    # def statisticsView1(self):
    #     if self.chk:
    #         if self.mMapLayerComboBox_1.currentIndex() > 0:
    #             Layer = self.canvas.currentLayer()
    #             layer = self.mMapLayerComboBox_1.currentLayer()
    #             if Layer == layer:
    #                 selected_features = layer.selectedFeatures()  # 레이어의 모든 객체 가져오기
    #                 # selected_field_index = self.mFieldComboBox_1.currentIndex() # 여기서 0은 필드 인덱스를 나타내며, 원하는 필드의 인덱스로 변경 가능

    #                 if selected_features==[]:
    #                 # 통계값 삭제
    #                     self.lineEdit_1.clear()
    #                     self.lineEdit_2.clear()
    #                     return

    #                 field_sum, field_count, field_mean, field_min, field_max, field_std_dev = self.statistic(selected_features, selected_field_index)

    #             # 선택한 필드의 속성 통계 출력
    #                 self.lineEdit_1.setText(f"{field_sum}")
    #                 self.lineEdit_2.setText(f"{field_count}")
    #                 # self.lineEdit_3.setText(f"{field_mean}")
    #                 # self.lineEdit_4.setText(f"{min}")
    #                 # self.lineEdit_5.setText(f"{max}")
    #                 # self.lineEdit_6.setText(f"{std_dev}")

    #                 # print(f"속성 통계 - 필드 '{layer.fields()[selected_field_index].name()}':")
    #                 # print(f"최솟값: {field_min}")
    #                 # print(f"최댓값: {field_max}")
    #                 # print(f"합계: {field_sum}")
    #                 # print(f"개수: {field_count}")
    #                 # print(f"평균: {field_mean}")
    #                 # print(f"표준편차: {field_std_dev}")
    #             else:
    #                 pass
    #         else:
    #             pass
    #     else:
    #         pass
        
    # def statisticsView2(self):
    #     if self.chk:
    #         if self.mMapLayerComboBox_2.currentIndex() > 0:
    #             Layer = self.canvas.currentLayer()
    #             layer = self.mMapLayerComboBox_2.currentLayer()
    #             if Layer == layer:
    #                 selected_features = layer.selectedFeatures()  # 레이어의 모든 객체 가져오기
    #                 selected_field_index = self.mFieldComboBox_2.currentIndex() # 여기서 0은 필드 인덱스를 나타내며, 원하는 필드의 인덱스로 변경 가능

    #                 if selected_features==[]:
    #                 # 통계값 삭제
    #                     self.lineEdit_3.clear()
    #                     self.lineEdit_4.clear()
    #                     return

    #                 field_sum, field_count, field_mean, field_min, field_max, field_std_dev = self.statistic(selected_features, selected_field_index)

    #             # 선택한 필드의 속성 통계 출력
    #                 self.lineEdit_3.setText(f"{field_sum}")
    #                 self.lineEdit_4.setText(f"{field_count}")
    #                 # self.lineEdit_3.setText(f"{mean}")
    #                 # self.lineEdit_4.setText(f"{min}")
    #                 # self.lineEdit_5.setText(f"{max}")
    #                 # self.lineEdit_6.setText(f"{std_dev}")

    #                 # print(f"속성 통계 - 필드 '{layer.fields()[selected_field_index].name()}':")
    #                 # print(f"최솟값: {field_min}")
    #                 # print(f"최댓값: {field_max}")
    #                 # print(f"합계: {field_sum}")
    #                 # print(f"개수: {field_count}")
    #                 # print(f"평균: {field_mean}")
    #                 # print(f"표준편차: {field_std_dev}")
    #             else:
    #                 pass
    #         else:
    #             pass
    #     else:
    #         pass