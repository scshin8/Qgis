# -*- coding: utf-8 -*-

import os
from qgis.PyQt import QtWidgets
from qgis.PyQt.uic import loadUiType
from qgis.core import QgsMapLayerType, Qgis, QgsExpression, QgsAggregateCalculator
from qgis.PyQt.QtCore import QVariant, QSettings

VERSION = Qgis.QGIS_VERSION_INT

# 코드 → 함수명 매핑
agg_map = {
    0: "Count", 5: "Sum"
}

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Statistics.ui'))

class StatisticsDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(StatisticsDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chk = False

        self.mMapLayerComboBox_1.layerChanged.connect(lambda : self.LayerChange(0))
        self.mMapLayerComboBox_1.setAllowEmptyLayer(True)
        self.mMapLayerComboBox_1.setCurrentIndex(0)

        self.mMapLayerComboBox_2.layerChanged.connect(lambda : self.LayerChange(2))
        self.mMapLayerComboBox_2.setAllowEmptyLayer(True)
        self.mMapLayerComboBox_2.setCurrentIndex(0)
        self.del_result(1)
        # self.canvas.selectionChanged.connect(self.statisticsView2)
        self.chk = True

    def del_result(self, idx):
        if idx == 0:
            self._last_expr_1 = None
            self._last_fids_1 = None
            self.lineEdit_1.setText('')
            self.lineEdit_2.setText('') 
        elif idx == 2:
            self._last_expr_2 = None
            self._last_fids_2 = None
            self.lineEdit_3.setText('')
            self.lineEdit_4.setText('')
        elif idx == 1:
            self._last_expr_1 = None
            self._last_fids_1 = None
            self.lineEdit_1.setText('')
            self.lineEdit_2.setText('') 
            self._last_expr_2 = None
            self._last_fids_2 = None
            self.lineEdit_3.setText('')
            self.lineEdit_4.setText('')

    def format_number(self, num):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)
        
    def _compute_aggregates(self, layer, expr_str, last_expr_attr, last_fids_attr):
        """공통: layer, expr_str, 선택 FID, 캐시 체크, aggregate 계산 후 (sum, count) 반환"""
        fids = layer.selectedFeatureIds()
        # FID 없으면 None 리턴
        if not fids:
            return None, None

        # 캐시된 값과 같으면 다시 계산 안 함
        last_expr = getattr(self, last_expr_attr, None)
        last_fids = getattr(self, last_fids_attr, None)
        if expr_str == last_expr and fids == last_fids:
            return None, None

        # 캐시 갱신
        setattr(self, last_expr_attr, expr_str)
        setattr(self, last_fids_attr, fids)

        # 식 분석
        expr = QgsExpression(expr_str)
        cols = expr.referencedColumns()
        if not cols:
            return None, None

        field_name = list(cols)[0]
        field_type = layer.fields().field(field_name).type()

        is_numeric = field_type in (QVariant.Int, QVariant.LongLong, QVariant.Double)
        is_string  = field_type == QVariant.String

        calc = QgsAggregateCalculator(layer)
        calc.setFidsFilter(fids)

        results = {}

        for code, name in agg_map.items():
            if VERSION >= 34000:
                agg_enum = getattr(Qgis.Aggregate, name)
            else:
                agg_enum = code

            # 타입 체크: 숫자형 전용 연산인 경우
            if code in (5,6,7,8,9,13,14,15) and not is_numeric:
                continue

            # 문자열 전용 연산인 경우
            if code in (16,17,18,21,22) and not is_string:
                continue

            # 지오메트리 전용 연산(예: code==19) 등 필요시 추가 체크…

            # 실제 계산
            if name == "StringAvgLength":
                results[name] = calc.calculate(agg_enum, f'length({expr_str})')[0]
            else:
                results[name] = calc.calculate(agg_enum, expr_str)[0]

        # Sum 과 Count 반환 (없으면 None)
        return results.get("Sum"), results.get("Count")

    def _onExpressionChanged_generic(self,
            layerCombo, exprWidget,
            last_expr_attr, last_fids_attr,
            lineEdit_sum, lineEdit_count, delNum, *args):
        layer = layerCombo.currentLayer()
        if not layer:
            self.del_result(delNum)
            return

        expr_str = exprWidget.expression()

        sum_val, cnt_val = self._compute_aggregates(
            layer, expr_str,
            last_expr_attr, last_fids_attr
        )

        if sum_val is None and cnt_val is None:
            # self.del_result(delNum)
            return

        # 결과 반올림·형변환
        self.__dict__[lineEdit_sum].setText(
            f"{self.detect_rounding_place('' if sum_val is None else sum_val)}"
        )
        self.__dict__[lineEdit_count].setText(
            f"{int(cnt_val)}"
        )

    def onExpressionChanged_1(self, *args):
        self._onExpressionChanged_generic(
            layerCombo=self.mMapLayerComboBox_1,
            exprWidget=self.mFieldExpressionWidget,
            last_expr_attr='_last_expr_1',
            last_fids_attr='_last_fids_1',
            lineEdit_sum='lineEdit_1',
            lineEdit_count='lineEdit_2',
            delNum = 0
        )

    def onExpressionChanged_2(self, *args):
        self._onExpressionChanged_generic(
            layerCombo=self.mMapLayerComboBox_2,
            exprWidget=self.mFieldExpressionWidget_2,
            last_expr_attr='_last_expr_2',
            last_fids_attr='_last_fids_2',
            lineEdit_sum='lineEdit_3',
            lineEdit_count='lineEdit_4',
            delNum = 2
        )

    def detect_rounding_place(self, num):
        if num:
            str_num = f"{num:.16f}"  # 충분한 자리수 확보
            decimals = str_num.split(".")[1]
            if '999999' in decimals:
                idx = decimals.find('999999')
                # 연속되는 9 앞자리까지가 정확한 자리
                return round( num, idx)
            elif '000000' in decimals:
                idx = decimals.find('000000')
                if idx == 0:
                    return int(num)
                else:  
                    return round( num, idx)
        return num
    
    def hideEvent(self, event):
        try:
            self.mMapLayerComboBox_1.layerChanged.disconnect(lambda : self.LayerChange(0))
            self.mMapLayerComboBox_2.layerChanged.disconnect(lambda : self.LayerChange(2))
            self.canvas.selectionChanged.disconnect(self.onExpressionChanged_1)
            self.canvas.selectionChanged.disconnect(self.onExpressionChanged_2)
            print('selectionChanged 시그널이 정상적으로 해제되었습니다.')
        except TypeError:
            # 이미 disconnect되었거나 연결되지 않았을 때 예외 처리
            print('selectionChanged 시그널이 이미 해제되었습니다.')
        super().hideEvent(event)

    # 위젯이 다시 표시될 때 연결을 재설정하려면 showEvent도 정의할 수 있습니다.
    def showEvent(self, event):
        try:
            
            self.mMapLayerComboBox_1.layerChanged.connect(lambda : self.LayerChange(0))
            self.mMapLayerComboBox_2.layerChanged.connect(lambda : self.LayerChange(2))
            self.mMapLayerComboBox_1.setCurrentIndex(0)
            self.mMapLayerComboBox_2.setCurrentIndex(0)
            self.mFieldExpressionWidget.setLayer(None)
            self.mFieldExpressionWidget.setExpression("")
            self.mFieldExpressionWidget_2.setLayer(None)
            self.mFieldExpressionWidget_2.setExpression("")
            print('selectionChanged 시그널이 정상적으로 연결되었습니다.')
        except TypeError:
            print('selectionChanged 시그널이 이미 연결되었습니다.')
        super().showEvent(event)

    def LayerChange(self, idx):
        if self.chk:
            if idx == 0:
                try:
                    self.mFieldExpressionWidget.fieldChanged.disconnect(self.onExpressionChanged_1)
                    self.canvas.selectionChanged.disconnect(self.onExpressionChanged_1)

                except TypeError:
                    pass  # 이미 연결 해제된 경우

                layer = self.mMapLayerComboBox_1.currentLayer()
                if self.mMapLayerComboBox_1.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                    self.mFieldExpressionWidget.setLayer(layer)
                    self.mFieldExpressionWidget.setExpression("")
                    self.mFieldExpressionWidget.fieldChanged.connect(self.onExpressionChanged_1)
                    self.canvas.selectionChanged.connect(self.onExpressionChanged_1)
                    self.QSettings.setValue('mMapLayerComboBox_1', layer)
                    self._last_expr_1 = None
                    self._last_fids_1 = None
                    self.del_result(0)

                elif self.mMapLayerComboBox_1.currentIndex() == 0:
                    self.mFieldExpressionWidget.setLayer(None)
                    self.mFieldExpressionWidget.setExpression("")

            elif idx == 2:
                try:
                    self.mFieldExpressionWidget_2.fieldChanged.disconnect(self.onExpressionChanged_2)
                    self.canvas.selectionChanged.disconnect(self.onExpressionChanged_2)

                except TypeError:
                    pass  # 이미 연결 해제된 경우

                layer = self.mMapLayerComboBox_2.currentLayer()
                if self.mMapLayerComboBox_2.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                    self.mFieldExpressionWidget_2.setLayer(layer)
                    self.mFieldExpressionWidget_2.setExpression("")
                    self.mFieldExpressionWidget_2.fieldChanged.connect(self.onExpressionChanged_2)
                    self.canvas.selectionChanged.connect(self.onExpressionChanged_2)
                    self.QSettings.setValue('mMapLayerComboBox_2', layer)
                    self._last_expr_2 = None
                    self._last_fids_2 = None
                    self.del_result(2)
                    
                elif self.mMapLayerComboBox_2.currentIndex() == 0:
                    self.mFieldExpressionWidget_2.setLayer(None)
                    self.mFieldExpressionWidget_2.setExpression("")