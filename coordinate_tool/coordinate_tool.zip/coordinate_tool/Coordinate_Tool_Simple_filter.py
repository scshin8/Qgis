# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
#  속성필터(다중 조건 AND/OR)
#  v1.1 (2026-11-04) selectRun 조건-연산자 짝 맞춤, currentField(), 값 이스케이프
#  v1.2 (2026-11-04) 조건 4개로 확장, 조건 줄 추가/삭제/초기화 버튼
#                    (toolButton_add / toolButton_del / toolButton_re)
#                    성능 개선(selectedFeatureCount, selectByIds),
#                    문자열/날짜 판정을 실제 타입으로, closeEvent 정리
# ----------------------------------------------------------------------

import os, re
from qgis.PyQt import (QtWidgets, 
                        QtCore)
from qgis.PyQt.uic import loadUiType
from qgis.PyQt.QtWidgets import (QComboBox,
                                QCompleter)
from qgis.core import (QgsMapLayerType, 
                        QgsVectorLayer, 
                        QgsProject, 
                        QgsCoordinateTransform, 
                        QgsFields, QgsWkbTypes, 
                        QgsFeature, 
                        QgsRectangle, 
                        QgsPointXY,
                        QgsFeatureRequest,
                        QgsExpression,      # v1.1 추가: 필드명/값 이스케이프
                        QgsApplication,     # v1.2 추가: 추가/삭제/초기화 버튼 아이콘
                        Qgis)

from qgis.PyQt.QtCore import Qt, QVariant   # v1.2: QVariant 추가(필드 타입 판정)
from qgis.PyQt.QtGui import QIcon

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_simple_filter.ui'))

class simple_filterDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(simple_filterDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        Layer = self.canvas.currentLayer()
        self.Fieldidx = 4          # v1.2: 최대 조건 개수 3 → 4
        self.RowCnt = 1            # v1.2: 현재 화면에 보이는 조건 줄 개수
        self.chk = False
        self.showRows(1)           # v1.2: 처음에는 조건 1만 표시
        self.Reset()
        self.mMapLayerComboBox.layerChanged.connect(self.LayerChange)
        self.mMapLayerComboBox.setAllowEmptyLayer(True)

        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()
        else:
            self.mMapLayerComboBox.setCurrentIndex(0)

        self.pushButton_Run.clicked.connect(self.selectRun)
        self.pushButton_zoom.clicked.connect(self.zoom)
        self.pushButton_move.clicked.connect(self.move)
        self.pushButton_copy.clicked.connect(self.copy)

        # v1.2: 조건별 위젯 연결을 1~Fieldidx 반복문으로 변경 (조건 4 추가 대응)
        #   lambda의 n=num 기본인자: 반복문 변수 늦은 바인딩 방지(모두 마지막 번호가 되는 문제)
        delete_icon = QIcon(os.path.dirname(__file__) + "/icons/delete.png")
        for num in range(1, self.Fieldidx+1):
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            FieldComboBox.installEventFilter(self)
            ValueComboBox.installEventFilter(self)
            FieldComboBox.fieldChanged.connect(lambda *a, n=num: self.FieldComboBox(n))

            # ClearButton = self.findChild(QtWidgets.QToolButton,'toolButton_'+str(num))
            # ClearButton.setIcon(delete_icon)
            # ClearButton.clicked.connect(lambda *a, n=num: self.valclear(n))

        # v1.2: AND/OR 변경 시 FieldComboBox() 호출 연결 제거
        #   (호출되면 값/연산자 콤보가 초기화되고 uniqueValues()를 다시 읽음.
        #    AND/OR 값은 selectRun()에서 실행 시점에 읽으므로 연결이 필요 없음)
        # self.ComboBox_AndOr_2.currentIndexChanged.connect(lambda : self.FieldComboBox(2))
        # self.ComboBox_AndOr_3.currentIndexChanged.connect(lambda : self.FieldComboBox(3))

        # v1.2: 조건 줄 추가 / 삭제 / 초기화 버튼 (QGIS 내장 테마 아이콘 사용)
        self.toolButton_add.setIcon(QgsApplication.getThemeIcon('/symbologyAdd.svg'))
        self.toolButton_del.setIcon(QgsApplication.getThemeIcon('/symbologyRemove.svg'))
        self.toolButton_re.setIcon(QgsApplication.getThemeIcon('/mActionRefresh.svg'))
        self.toolButton_add.clicked.connect(self.addRow)
        self.toolButton_del.clicked.connect(self.delRow)
        self.toolButton_re.clicked.connect(self.resetRows)

        self.chk = True

    # ==================================================================
    #  v1.2 추가 : 조건 줄 표시 / 추가 / 삭제 / 초기화
    # ==================================================================
    def rowWidgets(self, num):
        """조건 num 줄을 구성하는 위젯 목록 (번호라벨, AND/OR, 필드, 연산자, 값, ×버튼)"""
        names = ['label_'+str(num), 'mFieldComboBox_'+str(num), 'comboBox_sb_'+str(num),
                 'comboBox_val_'+str(num)] # , 'toolButton_'+str(num)
        if num > 1:
            names.append('ComboBox_AndOr_'+str(num))
        return [self.findChild(QtWidgets.QWidget, name) for name in names]

    def clearRow(self, num):
        """조건 num 줄의 입력값을 비운다. (숨기기 전에 호출 → 숨은 줄이 조건에 섞이지 않음)"""
        chk = self.chk
        self.chk = False                       # fieldChanged 연쇄 호출 방지
        self.findChild(QComboBox,'mFieldComboBox_'+str(num)).setCurrentIndex(0)
        self.findChild(QComboBox,'comboBox_val_'+str(num)).clear()
        self.findChild(QComboBox,'comboBox_sb_'+str(num)).clear()
        if num > 1:
            self.findChild(QComboBox,'ComboBox_AndOr_'+str(num)).setCurrentIndex(0)
        self.chk = chk

    def showRows(self, cnt):
        """조건 1~cnt 줄만 보이고 나머지는 숨긴다."""
        self.RowCnt = max(1, min(cnt, self.Fieldidx))
        for num in range(1, self.Fieldidx+1):
            for w in self.rowWidgets(num):
                w.setVisible(num <= self.RowCnt)
        self.toolButton_add.setEnabled(self.RowCnt < self.Fieldidx)
        self.toolButton_del.setEnabled(self.RowCnt > 1)

    def addRow(self, *args):
        """다음 조건 줄을 하나 표시 (2 → 3 → 4 순서)"""
        if self.RowCnt < self.Fieldidx:
            self.showRows(self.RowCnt + 1)

    def delRow(self, *args):
        """마지막 조건 줄을 비우고 숨김 (4 → 3 → 2 순서, 조건 1은 유지)"""
        if self.RowCnt > 1:
            self.clearRow(self.RowCnt)
            self.showRows(self.RowCnt - 1)

    def resetRows(self, *args):
        """초기화 : 모든 조건을 비우고 조건 1만 표시 (레이어는 유지)"""
        for num in range(1, self.Fieldidx+1):
            self.clearRow(num)
        self.showRows(1)

    def valclear(self, num):
        # self.lineEdit.clear()
        self.chk=False
        layer = self.mMapLayerComboBox.currentLayer()
        if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:

            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            if ValueComboBox.currentText()!='':
                ValueComboBox.setCurrentIndex(0)
            else:
                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
                FieldComboBox.setCurrentIndex(0)
                SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))
                SymbolComboBox.clear()
        self.chk=True

    def eventFilter(self, obj, event):
        # v1.2: 값 콤보 목록을 Fieldidx 기준으로 생성 (조건 4 포함)
        val_boxes = [self.findChild(QComboBox,'comboBox_val_'+str(n)) for n in range(1, self.Fieldidx+1)]
        if event.type() == QtCore.QEvent.KeyPress and obj in val_boxes:
            if event.key() == QtCore.Qt.Key_Return or event.key() == QtCore.Qt.Key_Enter:
                self.selectRun()
                return True

        return super().eventFilter(obj, event)

    def closeEvent(self, event):
        # v1.2: 존재하지 않는 self.statisticsView disconnect 제거 (항상 예외 → 아무것도 안 하던 코드)
        #   self.chk = False 도 실제로는 실행된 적이 없어 제거 (넣으면 창 재사용 시 버튼이 동작 안 함)
        super().closeEvent(event)

    def LayerChanged(self):
        # self.lineEdit.clear()
        Layer = self.canvas.currentLayer()
        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()
        else:
            self.mMapLayerComboBox.setCurrentIndex(0)

    def LayerChange(self, *args):
        if self.chk:
            # self.lineEdit.clear()
            layer = self.mMapLayerComboBox.currentLayer()
            if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                for num in range(1,self.Fieldidx+1):
                    FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
                    FieldComboBox.setLayer(layer)
                    FieldComboBox.setAllowEmptyFieldName(True)
                    FieldComboBox.setCurrentIndex(0)
                    ValueComboBox=self.findChild(QComboBox,'comboBox_val_'+str(num))
                    ValueComboBox.clear()
                    SymbolComboBox=self.findChild(QComboBox,'comboBox_sb_'+str(num))
                    SymbolComboBox.clear()
                    if num > 1:
                        AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                        AndOrComboBox.setCurrentIndex(0)
                    #     AndOrComboBox.clear()
                self.showRows(1)               # v1.2: 레이어 변경 시 조건 1만 표시

            elif self.mMapLayerComboBox.currentIndex() == 0:
                self.Reset()

    def FieldComboBox(self,num):
        if self.chk:
            self.chk=False
            # self.lineEdit.clear()
            layer = self.mMapLayerComboBox.currentLayer()
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))

            if FieldComboBox.currentIndex() > 0:
                ValueComboBox.clear()
                SymbolComboBox.clear()
                # v1.2: currentText()(별칭일 수 있음) → currentField()(실제 필드명)
                #       typeName() 문자열 비교 → field.type() 실제 타입 비교
                Field_txt = FieldComboBox.currentField()
                field = layer.fields().field(Field_txt)
                ftype = field.type()

                if ftype == QVariant.String:
                    SymbolComboBox.addItems(['같음(=)','같지않음(<>)','포함(LIKE)','포함하지 않음(NOT LIKE)'])
                else:
                    SymbolComboBox.addItems(['같음(=)','같지않음(<>)','초과(>)','미만(<)','이상(>=)','이하(<=)'])

                unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))

                # v1.2: DateTime 필드 추가 (기존엔 str(QDateTime)이 그대로 들어가 사용 불가)
                if ftype in (QVariant.Date, QVariant.DateTime):
                    date_fmt = "yyyy-MM-dd" if ftype == QVariant.Date else "yyyy-MM-dd HH:mm:ss"
                    def convert_to_datetime(date_str):
                        # v1.2: 디버그용 print 제거
                        if date_str == None:
                            return 'NULL'
                        elif date_str.isNull():
                            return 'NULL'
                        else:
                            date_str = date_str.toString(date_fmt)
                            return date_str

                    unique_values_datetime = [convert_to_datetime(str_date) for str_date in unique_values]
                    ValueComboBox.addItems([""])
                    ValueComboBox.addItems(sorted(unique_values_datetime))
                else:
                    # unique_values_str = list(map(str, unique_values))
                    unique_values_str = []
                    for value in unique_values:
                        if isinstance(value, float):
                            value_str = str(value)
                            if value.is_integer():  # 소수점 아래 값이 0이면
                                value_str = str(int(value))  # 정수로 변환하여 문자열로 만듦
                        else:
                            value_str = str(value)
                        unique_values_str.append(value_str)

                    ValueComboBox.addItems([""])
                    num_prefix_re = re.compile(r'^(\d+)(.*)$')  # 앞에서부터 숫자만 쭉 + 나머지 전부
                    
                    def sort_key(x):
                        # 0) None, NULL, 빈 문자열 등 처리
                        if x is None:
                            return (2, float('inf'), '')
                        s = str(x).strip()

                        if s == '' or s.upper() == 'NULL':
                            return (2, float('inf'), '')

                        # 1) 맨 앞 숫자 부분 + 나머지 자동 분리
                        m = num_prefix_re.match(s)
                        if m:
                            num = int(m.group(1))   # 앞의 숫자 덩어리
                            tail = m.group(2)       # 그 뒤의 모든 문자열 (구분자 포함)
                            # 숫자 기준 오름차순, 같은 숫자 안에서는 tail 기준으로 정렬
                            return (1, num, tail)

                        # 2) 숫자로 시작하지 않는 문자열 (예: "group") 은 따로 그룹
                        #    여기서는 헤더처럼 맨 앞에 오도록 (0, ...) 으로 설정
                        return (0, 0, s)        # (그룹 1, 문자열)

                    sorted_unique_values_str = sorted(unique_values_str, key=sort_key)
                    ValueComboBox.addItems(sorted_unique_values_str)

                # QVariant 값을 Python 문자열로 변환
                if ftype in (QVariant.Date, QVariant.DateTime):   # v1.2
                    unique_values = unique_values_datetime
                else:
                    unique_values = [str(val) for val in unique_values]
                # QCompleter를 생성하고 QComboBox에 설정
                completer = QCompleter(unique_values)
                completer.setFilterMode(Qt.MatchContains)  # 중간 일치 검색 모드 설정
                # completer.setFilterMode(Qt.MatchStartsWith)  # 시작 부분 일치 모드 설정
                # completer.setFilterMode(Qt.MatchEndsWith)  # 끝 부분 일치 모드 설정
                # completer.setFilterMode(Qt.MatchExactly)  # 정확한 일치 모드 설정
                # completer.setFilterMode(Qt.MatchWildcard)  # 와일드카드 일치 모드 설정 문자(* 및 ?)를 사용하여 일치하는 항목을 필터링
                ValueComboBox.setCompleter(completer)

            else:
                ValueComboBox.clear()
                SymbolComboBox.clear()
                for n in range(num+1, self.Fieldidx+1):
                    FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(n))
                    FieldComboBox.setCurrentIndex(0)
                    # FieldComboBox.setEnabled(False)
                    ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(n))
                    ValueComboBox.clear()
                    # ValueComboBox.setEnabled(False)
                    SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(n))
                    SymbolComboBox.clear()
            self.chk=True

    def ValComboBox(self,num):
        if self.chk:
            if num == 1:
                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num+1))
                Fieldindex = FieldComboBox.currentIndex()
                if Fieldindex > 0:
                    self.FieldComboBox(num+1)
            elif num == 2:
                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num+1))
                Fieldindex = FieldComboBox.currentIndex()
                if Fieldindex > 0:
                    self.FieldComboBox(num+1)

    def selectRun(self, *args):
        layer = self.mMapLayerComboBox.currentLayer()
        selectIndex = self.comboBox_filter.currentIndex()
        expression = None

        # 하나 이상의 조건이 있어야함
        if self.mFieldComboBox_1.currentIndex() == 0 or str(self.comboBox_val_1.currentText()) == '':
            return

        # ── v1.1 (2026-11-04) 조건 조립 수정 ─────────────────────────────
        #  - 각 조건과 그 '앞의' AND/OR을 한 쌍으로 저장
        #    → 중간 조건이 비어도 연산자가 앞으로 밀리지 않음
        #  - 필드명: currentText()(별칭일 수 있음) → currentField()(실제 필드명)
        #  - 필드명/값: QgsExpression.quoted* 로 이스케이프 (작은따옴표 포함 값 대응)
        conds = []   # [(AND/OR, 조건식), ...]  첫 조건의 연산자는 사용 안 함
        for num in range(1, self.RowCnt+1):        # v1.2: 화면에 보이는 줄만 사용
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            field_name = FieldComboBox.currentField()
            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            value = ValueComboBox.currentText()
            if field_name == '' or value == '':
                continue                                   # 빈 조건은 연산자째 제외

            ftype = layer.fields().field(field_name).type()   # v1.2: 실제 타입으로 판정
            SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))
            Symbol_Index = SymbolComboBox.currentIndex()
            if Symbol_Index < 0:
                continue                                   # 연산자 목록이 비어 있음
            Symbol_list = ['=','<>','ILIKE','NOT ILIKE'] if ftype == QVariant.String else ['=','<>','>','<','>=','<=']
            Symbol = Symbol_list[Symbol_Index]

            col = QgsExpression.quotedColumnRef(field_name)
            # v1.2: DateTime은 목록과 같은 형식의 문자열로 바꿔 비교
            #   ('yyyy-MM-dd HH:mm:ss'는 문자열 대소 비교 = 시간 순서)
            if ftype == QVariant.DateTime and value != 'NULL':
                col = f"format_date({col}, 'yyyy-MM-dd HH:mm:ss')"
            if value == 'NULL':
                if Symbol == '=':
                    expr = f'{col} IS NULL'
                elif Symbol == '<>':
                    expr = f'{col} IS NOT NULL'
                else:
                    return
            elif Symbol == 'ILIKE' or Symbol == 'NOT ILIKE':
                expr = f'{col} {Symbol} {QgsExpression.quotedString("%" + value + "%")}'
            else:
                expr = f'{col} {Symbol} {QgsExpression.quotedString(value)}'

            AndOr = 'AND'
            if num > 1:
                AndOr = self.findChild(QComboBox,'ComboBox_AndOr_'+str(num)).currentText()
            conds.append((AndOr, expr))

        if not conds:
            return

        # 기존 규칙 유지: OR로 이어진 조건끼리 먼저 괄호로 묶고, 묶음끼리는 AND
        #   A AND B OR C → A AND (B OR C) / A OR B AND C → (A OR B) AND C
        #   (Fieldidx를 늘려도 그대로 동작)
        groups = [[conds[0][1]]]
        for AndOr, expr in conds[1:]:
            if AndOr == 'OR':
                groups[-1].append(expr)
            else:
                groups.append([expr])
        expression = ' AND '.join(
            '(' + ' OR '.join(g) + ')' if len(g) > 1 else g[0] for g in groups)
        # ── v1.1 끝 ──────────────────────────────────────────────────────

        print('expression')
        print(expression)
        # 새 선택
        if selectIndex == 0:
            # 객체 선택 해제
            layer.removeSelection()
            layer.selectByExpression(expression, QgsVectorLayer.SetSelection)
        # 추가 선택
        elif selectIndex == 1:
            layer.selectByExpression(expression, QgsVectorLayer.AddToSelection)
        # 선택 제거
        elif selectIndex == 2:
            layer.selectByExpression(expression, QgsVectorLayer.RemoveFromSelection)
        # 선택내 선택
        elif selectIndex == 3:
            layer.selectByExpression(expression, QgsVectorLayer.IntersectSelection)

        # 화면에서 선택
        elif selectIndex == 4:
            # 레이어의 좌표계를 가져옵니다.
            layer_crs = layer.crs()
            # 현재 화면의 좌표계를 가져옵니다.
            canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            # 좌표 변환 객체를 생성합니다.
            transform = QgsCoordinateTransform(canvas_crs, layer_crs, QgsProject.instance())
            # 현재 화면의 범위를 가져옵니다.
            extent = self.iface.mapCanvas().extent()
            # 화면 좌표계를 레이어 좌표계로 변환합니다.
            extent = transform.transform(extent)
            # 현재 캔버스 화면에 보이는 객체 중에서 속성값이 일치하는 객체를 선택합니다.
            request = QgsFeatureRequest().setFilterExpression(expression).setFilterRect(extent)
            # v1.2: 객체마다 select() 호출(매번 선택변경 시그널) → id를 모아 한 번에 선택
            ids = [feature.id() for feature in layer.getFeatures(request)]
            layer.selectByIds(ids, QgsVectorLayer.SetSelection)

        # 선택된 객체들을 하이라이트
        layer.triggerRepaint()

        # v1.2: selectedFeatures()(도형까지 전부 읽음) → selectedFeatureCount()(개수만)
        sel_cnt = layer.selectedFeatureCount()

        self.label_count.setText(f"선택객체 : {sel_cnt}")

        if self.checkBox_zoom.isChecked():
            self.zoom()
        self.chk = False
        self.iface.setActiveLayer(layer)
        # 메세지 표출
        self.iface.messageBar().pushMessage(f"선택된 객체가 {sel_cnt}개 입니다.", level=Qgis.Info, duration=5)
        self.chk = True

    def Reset(self):
        self.mMapLayerComboBox.setCurrentIndex(0)
        self.comboBox_filter.setCurrentIndex(0)
        for num in range(1, self.Fieldidx+1):
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            FieldComboBox.setLayer(None)
            # FieldComboBox.setEnabled(False)
            ValueComboBox=self.findChild(QComboBox,'comboBox_val_'+str(num))
            ValueComboBox.clear()
            # ValueComboBox.setEnabled(False)
            SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))
            SymbolComboBox.clear()
            # SymbolComboBox.setEnabled(False)
            if num > 1:
                AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                AndOrComboBox.setCurrentIndex(0)
                # AndOrComboBox.clear()
                # AndOrComboBox.setEnabled(False)
        self.showRows(1)                       # v1.2: 조건 1만 표시
        Layer = self.canvas.currentLayer()
        self.mMapLayerComboBox.setAllowEmptyLayer(True)
        if self.chk == False and Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()

    def copy(self, *args):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                self.layer_set = set()
                layer = self.mMapLayerComboBox.currentLayer()
                selected_features = layer.selectedFeatures()

                if selected_features==[]:
                    return

                self.layer_set.add(layer)
                for layer in self.layer_set:
                    new_name = '###'+layer.name()
                    wkb_type = layer.wkbType()
                    layer_crs = layer.sourceCrs()
                    fields = QgsFields(layer.fields())
                    new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
                    dp = new_layer.dataProvider()
                    dp.addAttributes(fields)
                new_layer.updateFields()
                QgsProject.instance().addMapLayer(new_layer)
                # v1.2: startEditing() 제거 (dataProvider로 직접 넣으므로 불필요, 편집모드로 남던 문제)

                new_feats = []
                for feature in selected_features:
                    # 속성 값 가져오기
                    attributes = feature.attributes()
                    f = QgsFeature()
                    f.setGeometry(feature.geometry())  # 올바른 방법: QgsGeometry 객체를 전달
                    f.setAttributes(attributes) # 새로운 QgsFeature에 속성 설정
                    new_feats.append(f)
                # v1.2: 객체마다 addFeatures() → 한 번에 추가
                new_layer.dataProvider().addFeatures(new_feats)

                new_layer.updateExtents()
                self.canvas.refresh()

    def move(self, *args):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                layer = self.mMapLayerComboBox.currentLayer()
                if layer.selectedFeatureCount() == 0:   # v1.2: 개수만 확인
                    return
                # 선택객체 박스 영역 가져오기
                selection_bbox_project_crs = self.selection_box()
                # 바운딩 박스의 중심 좌표 계산
                center_x = (selection_bbox_project_crs.xMinimum() + selection_bbox_project_crs.xMaximum()) / 2
                center_y = (selection_bbox_project_crs.yMinimum() + selection_bbox_project_crs.yMaximum()) / 2

                # 맵 캔버스를 중심점들의 평균값으로 이동
                self.canvas.setCenter(QgsPointXY(center_x, center_y))
                self.canvas.refresh()

    def zoom(self, *args):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                layer = self.mMapLayerComboBox.currentLayer()
                if layer.selectedFeatureCount() == 0:   # v1.2: 개수만 확인
                    return
                # 선택객체 박스 영역 가져오기
                selection_bbox_project_crs = self.selection_box()
                # bounding box를 각 방향으로 2.5%씩 확장 (v1.2: 주석 수정)
                width = selection_bbox_project_crs.width()
                height = selection_bbox_project_crs.height()
                delta_x = width * 0.025
                delta_y = height * 0.025
                
                # 새로운 확장된 QgsRectangle 생성
                expanded_bbox = QgsRectangle( selection_bbox_project_crs.xMinimum() - delta_x,
                                            selection_bbox_project_crs.yMinimum() - delta_y,
                                            selection_bbox_project_crs.xMaximum() + delta_x,
                                            selection_bbox_project_crs.yMaximum() + delta_y )

                # 화면을 선택된 객체들의 영역으로 이동 및 확대
                self.canvas.setExtent(expanded_bbox)
                self.canvas.refresh()

    def selection_box(self):
        layer = self.mMapLayerComboBox.currentLayer()
        project_crs = QgsProject.instance().crs()
        # 선택객체가 없다면 중단
        if layer.selectedFeatureCount() == 0:   # v1.2: 개수만 확인
            return
        # 선택된 객체들의 영역 결정
        selection_bbox = layer.boundingBoxOfSelected()
        # 좌표 변환 - 레이어 좌표계에서 현재 프로젝트 좌표계로
        xform = QgsCoordinateTransform(layer.crs(), project_crs, QgsProject.instance())
        selection_bbox_project_crs = xform.transformBoundingBox(selection_bbox)
        return selection_bbox_project_crs