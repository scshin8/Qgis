# -*- coding: utf-8 -*-

import os, statistics
from qgis.PyQt import (QtWidgets, 
                        QtCore)
from qgis.PyQt.uic import loadUiType
from qgis.PyQt.QtWidgets import (QComboBox,
                                QDialogButtonBox, 
                                QCompleter)

from qgis.core import (QgsMapLayerType, 
                        QgsVectorLayer, 
                        QgsProject, 
                        QgsCoordinateTransform, 
                        QgsFields, QgsWkbTypes, 
                        QgsFeature, 
                        QgsRectangle, 
                        QgsPointXY,
                        QgsFeatureRequest,
                        QgsExpression,
                        Qgis)

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_simple_filter.ui'))

class simple_filterDialog(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        """Constructor."""
        super(simple_filterDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        Layer = self.canvas.currentLayer()
        self.Fieldidx = 3
        self.chk = False
        self.Reset()
        self.mMapLayerComboBox.layerChanged.connect(self.LayerChange)
        self.mMapLayerComboBox.setAllowEmptyLayer(True)

        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()
        else:
            self.mMapLayerComboBox.setCurrentIndex(0)

        self.pushButton_Run.clicked.connect(self.selectRun)
        self.pushButton_zoom.clicked.connect(self.zoom)
        self.pushButton_move.clicked.connect(self.move)
        self.pushButton_copy.clicked.connect(self.copy)

        self.mFieldComboBox_1.installEventFilter(self)
        self.mFieldComboBox_2.installEventFilter(self)
        self.mFieldComboBox_3.installEventFilter(self)
        # self.mFieldComboBox_4.installEventFilter(self)

        self.comboBox_val_1.installEventFilter(self)
        self.comboBox_val_2.installEventFilter(self)
        self.comboBox_val_3.installEventFilter(self)
        # self.comboBox_val_4.installEventFilter(self)

        self.toolButton_1.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_1.clicked.connect(lambda : self.valclear(1))
        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_2.clicked.connect(lambda : self.valclear(2))
        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_3.clicked.connect(lambda : self.valclear(3))
        # self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        # self.toolButton_4.clicked.connect(lambda : self.valclear(4))

        # self.buttonBox.button(QDialogButtonBox.Reset).clicked.connect(self.Reset)

        self.mFieldComboBox_1.fieldChanged.connect(lambda : self.FieldComboBox(1))
        self.mFieldComboBox_2.fieldChanged.connect(lambda : self.FieldComboBox(2))
        self.mFieldComboBox_3.fieldChanged.connect(lambda : self.FieldComboBox(3))
        # self.mFieldComboBox_4.fieldChanged.connect(lambda : self.FieldComboBox(4))

        self.comboBox_val_1.currentIndexChanged.connect(lambda : self.ValComboBox(1))
        self.comboBox_val_2.currentIndexChanged.connect(lambda : self.ValComboBox(2))
        self.comboBox_val_3.currentIndexChanged.connect(lambda : self.ValComboBox(3))
        # self.comboBox_val_4.currentIndexChanged.connect(lambda : self.ValComboBox(4))

        self.ComboBox_AndOr_2.currentIndexChanged.connect(lambda : self.FieldComboBox(2))
        self.ComboBox_AndOr_3.currentIndexChanged.connect(lambda : self.FieldComboBox(3))

        self.chk = True

    def valclear(self, num):
        # self.lineEdit.clear()
        self.chk=False
        layer = self.mMapLayerComboBox.currentLayer()
        if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:

            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            if ValueComboBox.currentText()!='':
                ValueComboBox.setCurrentIndex(0)
            else:
                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
                FieldComboBox.setCurrentIndex(0)
                SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))
                SymbolComboBox.clear()
                
            # if num > 1:
            #     AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
            #     AndOrComboBox.setCurrentIndex(0)
            #     # AndOrComboBox.setEnabled(False)
            # for n in range(num+1,self.Fieldidx+1):
            #     FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(n))
            #     FieldComboBox.setCurrentIndex(0)
            #     # FieldComboBox.setEnabled(False)

            #     ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(n))
            #     ValueComboBox.clear()
            #     # ValueComboBox.setEnabled(False)
            #     SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(n))
            #     SymbolComboBox.clear()
            #     # SymbolComboBox.setEnabled(False)
            #     if n > 1:
            #         AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(n))
            #         AndOrComboBox.setCurrentIndex(0)
            #         # AndOrComboBox.clear()
            #         # AndOrComboBox.setEnabled(False)

        self.chk=True

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.KeyPress and obj in [self.comboBox_val_1, self.comboBox_val_2, self.comboBox_val_3]:
            if event.key() == QtCore.Qt.Key_Return or event.key() == QtCore.Qt.Key_Enter:
                self.selectRun()
                return True

        return super().eventFilter(obj, event)

    def closeEvent(self, event):
        try:
            self.canvas.selectionChanged.disconnect(self.statisticsView)
            self.chk = False
        except:
            pass

    def LayerChanged(self):
        # self.lineEdit.clear()
        Layer = self.canvas.currentLayer()
        if Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()
        else:
            self.mMapLayerComboBox.setCurrentIndex(0)

    def LayerChange(self):
        if self.chk:
            # self.lineEdit.clear()
            layer = self.mMapLayerComboBox.currentLayer()
            if self.mMapLayerComboBox.currentIndex() > 0 and layer.type() == QgsMapLayerType.VectorLayer:
                for num in range(1,self.Fieldidx+1):
                    FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
                    FieldComboBox.setLayer(layer)
                    FieldComboBox.setAllowEmptyFieldName(True)
                    FieldComboBox.setCurrentIndex(0)
                    ValueComboBox=self.findChild(QComboBox,'comboBox_val_'+str(num))
                    ValueComboBox.clear()
                    SymbolComboBox=self.findChild(QComboBox,'comboBox_sb_'+str(num))
                    SymbolComboBox.clear()
                    # if num == 1:
                    #     FieldComboBox.setEnabled(True)
                    #     ValueComboBox.setEnabled(True)
                    #     SymbolComboBox.setEnabled(True)
                    if num > 1:
                        AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                        AndOrComboBox.setCurrentIndex(0)
                    #     AndOrComboBox.clear()

            elif self.mMapLayerComboBox.currentIndex() == 0:
                self.Reset()

    def FieldComboBox(self,num):
        if self.chk:
            self.chk=False
            # self.lineEdit.clear()
            layer = self.mMapLayerComboBox.currentLayer()
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(num))
            SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))

            if FieldComboBox.currentIndex() > 0:
                ValueComboBox.clear()
                SymbolComboBox.clear()
                Field_txt = FieldComboBox.currentText()
                Field_idx = FieldComboBox.currentIndex()-1
                ftype = layer.fields()[Field_idx].typeName()
                if ftype == 'String':
                    SymbolComboBox.addItems(['같음(=)','같지않음(<>)','포함(LIKE)','포함하지 않음(NOT LIKE)'])
                else:
                    SymbolComboBox.addItems(['같음(=)','같지않음(<>)','초과(>)','미만(<)','이상(>=)','이하(<=)'])

                # 선택한 필드의 유일한 값 찾기
                if num == 1:
                    unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))

                elif num == 2:
                    # 결과를 저장할 딕셔너리 초기화
                    unique_values = {}
                    FieldComboBoxA = self.findChild(QComboBox,'mFieldComboBox_'+str(num-1))
                    Field_txtA = FieldComboBoxA.currentText()
                    Field_idxA = FieldComboBoxA.currentIndex()
                    ValueComboBoxA = self.findChild(QComboBox,'comboBox_val_'+str(num-1))
                    Value_txtA = ValueComboBoxA.currentText()
                    Value_idxA = ValueComboBoxA.currentIndex()
                    AndOrComboBox2 = self.findChild(QComboBox,'ComboBox_AndOr_'+str(2))
                    AndOridx2 = AndOrComboBox2.currentIndex()

                    if AndOridx2 == 1 or Value_idxA == 0:
                        unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))

                    else:
                        if AndOridx2 == 1 and Field_txt == Field_txtA:
                            unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))

                        else:
                            # A필드의 값에 해당하는 피처만 필터링
                            expression = QgsExpression(f'"{Field_txtA}" = \'{Value_txtA}\'')
                            request = QgsFeatureRequest(expression)
                            features = layer.getFeatures(request)

                            # B필드의 값을 가져와서 고유한 값 찾기
                            values_B = set(feature[Field_txt] for feature in features)
                            unique_values[Field_txt] = list(values_B)
                            unique_values = unique_values[Field_txt]

                elif num == 3:
                    # 결과를 저장할 딕셔너리 초기화
                    unique_values = {}

                    FieldComboBoxA = self.findChild(QComboBox,'mFieldComboBox_'+str(num-2))
                    Field_txtA = FieldComboBoxA.currentText()
                    ValueComboBoxA = self.findChild(QComboBox,'comboBox_val_'+str(num-2))
                    Value_txtA = ValueComboBoxA.currentText()

                    AndOrComboBox2 = self.findChild(QComboBox,'ComboBox_AndOr_'+str(2))
                    AndOr2 = AndOrComboBox2.currentText()

                    FieldComboBoxB = self.findChild(QComboBox,'mFieldComboBox_'+str(num-1))
                    Field_txtB = FieldComboBoxB.currentText()
                    ValueComboBoxB = self.findChild(QComboBox,'comboBox_val_'+str(num-1))
                    Value_txtB = ValueComboBoxB.currentText()
                    Value_idxB = ValueComboBoxB.currentIndex()

                    AndOrComboBox3 = self.findChild(QComboBox,'ComboBox_AndOr_'+str(3))
                    AndOridx3 = AndOrComboBox3.currentIndex()

                    if AndOridx3 == 1 or Value_idxB == 0:
                        unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))
                    else:
                        if AndOridx3 == 1 and Field_txt == Field_txtB:
                            unique_values = layer.uniqueValues(layer.fields().indexFromName(Field_txt))
                        else:
                            # A필드와 B필드의 값에 해당하는 피처만 필터링
                            expression = QgsExpression(f'"{Field_txtA}" = \'{Value_txtA}\' {AndOr2} "{Field_txtB}" = \'{Value_txtB}\'')
                            print(expression)
                            request = QgsFeatureRequest(expression)
                            features = layer.getFeatures(request)

                            # C필드의 값을 가져와서 고유한 값 찾기
                            values_C = set(feature[Field_txt] for feature in features)
                            unique_values[Field_txt] = list(values_C)
                            unique_values = unique_values[Field_txt]

                if ftype == 'Date' or ftype == 'date':
                    def convert_to_datetime(date_str):
                        print(date_str)
                        if date_str == None:
                            return 'NULL'
                        elif date_str.isNull():
                            return 'NULL'
                        else:
                            date_str = date_str.toString("yyyy-MM-dd")
                            return date_str

                    unique_values_datetime = [convert_to_datetime(str_date) for str_date in unique_values]
                    ValueComboBox.addItems([""])
                    ValueComboBox.addItems(sorted(unique_values_datetime))
                else:
                    # unique_values_str = list(map(str, unique_values))
                    unique_values_str = []
                    for value in unique_values:
                        if isinstance(value, float):
                            value_str = str(value)
                            if value.is_integer():  # 소수점 아래 값이 0이면
                                value_str = str(int(value))  # 정수로 변환하여 문자열로 만듦
                        else:
                            value_str = str(value)
                        unique_values_str.append(value_str)

                    ValueComboBox.addItems([""])
                    # ValueComboBox.addItems(sorted(unique_values_str))
                    sorted_unique_values_str = sorted(unique_values_str, key=lambda x: int(x) if x.isdigit() else x)
                    ValueComboBox.addItems(sorted_unique_values_str)

                # QVariant 값을 Python 문자열로 변환
                if ftype == 'DATE':
                    unique_values = unique_values_datetime
                else:
                    unique_values = [str(val) for val in unique_values]
                # QCompleter를 생성하고 QComboBox에 설정
                completer = QCompleter(unique_values)
                completer.setFilterMode(Qt.MatchContains)  # 중간 일치 검색 모드 설정
                # completer.setFilterMode(Qt.MatchStartsWith)  # 시작 부분 일치 모드 설정
                # completer.setFilterMode(Qt.MatchEndsWith)  # 끝 부분 일치 모드 설정
                # completer.setFilterMode(Qt.MatchExactly)  # 정확한 일치 모드 설정
                # completer.setFilterMode(Qt.MatchWildcard)  # 와일드카드 일치 모드 설정 문자(* 및 ?)를 사용하여 일치하는 항목을 필터링
                ValueComboBox.setCompleter(completer)

            else:
                ValueComboBox.clear()
                SymbolComboBox.clear()
                # if num > 1:
                #     AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                #     AndOrComboBox.setCurrentIndex(0)
                #     AndOrComboBox.clear()
                    # AndOrComboBox.setEnabled(False)
                for n in range(num+1, self.Fieldidx+1):
                    FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(n))
                    FieldComboBox.setCurrentIndex(0)
                    # FieldComboBox.setEnabled(False)
                    ValueComboBox = self.findChild(QComboBox,'comboBox_val_'+str(n))
                    ValueComboBox.clear()
                    # ValueComboBox.setEnabled(False)
                    SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(n))
                    SymbolComboBox.clear()
                    # SymbolComboBox.setEnabled(False)
                    # if n > 1:
                    #     AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(n))
                    #     AndOrComboBox.setCurrentIndex(0)
                    #     AndOrComboBox.clear()
                        # AndOrComboBox.setEnabled(False)

            self.chk=True

    def ValComboBox(self,num):
        if self.chk:
            if num == 1:
                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num+1))
                Fieldindex = FieldComboBox.currentIndex()
                if Fieldindex > 0:
                    self.FieldComboBox(num+1)
            elif num == 2:
                # AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                # AndOrComboBox.setCurrentIndex(1)
                # AndOrComboBox.setEnabled(True)
                # if AndOrComboBox.count() == 0:
                #     AndOrComboBox.addItems(['AND','OR'])

                FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num+1))
                Fieldindex = FieldComboBox.currentIndex()
                if Fieldindex > 0:
                    self.FieldComboBox(num+1)

    def selectRun(self):
        layer = self.mMapLayerComboBox.currentLayer()
        selectIndex = self.comboBox_filter.currentIndex()
        expression = None

        # 하나 이상의 조건이 있어야함
        if self.mFieldComboBox_1.currentIndex() == 0 or str(self.comboBox_val_1.currentText()) == '':
            return
        fields = []
        values = [] 
        Symbols = []
        AndOrs = []
        for num in range(1, self.Fieldidx+1):
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            field_name = FieldComboBox.currentText()
            fields.append(field_name)
            Field_idx = FieldComboBox.currentIndex()-1
            ftype = layer.fields()[Field_idx].typeName()

            ValueComboBox=self.findChild(QComboBox,'comboBox_val_'+str(num))
            selected_value = ValueComboBox.currentText()
            values.append(selected_value)

            SymbolComboBox=self.findChild(QComboBox,'comboBox_sb_'+str(num))
            Symbol_Index = SymbolComboBox.currentIndex()
            Symbol_list = ['=','<>','ILIKE','NOT ILIKE'] if ftype == 'String' else ['=','<>','>','<','>=','<=']
            Symbol = Symbol_list[Symbol_Index]
            Symbols.append(Symbol)

            if num > 1:
                AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                AndOr = AndOrComboBox.currentText()
                AndOrs.append(AndOr)

        expres = []
        for field, Symbol, value in zip(fields, Symbols, values):
            if field != '' and value != '':
                if value == 'NULL':
                    if Symbol == '=':
                        expres.append(f'"{field}" IS NULL')
                    elif Symbol == '<>':
                        expres.append(f'"{field}" IS NOT NULL')
                    else:
                        return
                else:
                    if Symbol == 'ILIKE' or Symbol =='NOT ILIKE':
                        expres.append(f'"{field}" {Symbol} \'%{value}%\'')
                    else:
                        expres.append(f'"{field}" {Symbol} \'{value}\'')

        # print(expres)
        # print(AndOrs)
        AndOridx=0
        AndOr1 = 0
        AndOr2 = 0
        # AndOr3 = 0
        if AndOrs[0]=='OR':
            AndOr1 = 1
        if AndOrs[1]=='OR':
            AndOr2 = 2
        # if AndOrs[2]=='OR':
        #     AndOr3 = 4
        AndOridx = AndOr1+AndOr2

        if len(expres) == 1:
            expression = expres[0]

        elif len(expres) == 2:
            expression = (expres[0] + ' ' + AndOrs[0] + ' ' + expres[1])

        elif len(expres) == 3:
            expression = ('(' if AndOridx == 2 else ''
            ) + expres[0] + ' ' + AndOrs[0] + ' ' + (
                '(' if AndOridx == 1 else ''   
            ) +  expres[1] + (
                ')' if AndOridx == 2 else '' 
            ) + ' ' + AndOrs[1] + ' ' + expres[2] + (
                ')' if AndOridx == 1 else ''
            )

        # elif len(expres) == 4:
        #     expression = (
        #         '(' if AndOridx in [1, 3, 5] else ''
        #     ) + expres[0] + AndOrs[0] + (
        #         '(' if AndOridx in [2, 6] else ''
        #     ) + expres[1] + (
        #         ')' if AndOridx in [1, 5] else ''
        #     ) + AndOrs[1] + (
        #         '(' if AndOridx in [4, 5] else ''
        #     ) + expres[2] + (
        #         ')' if AndOridx in [2, 3] else ''
        #     ) + AndOrs[2] + expres[3] + (
        #         ')' if AndOridx in [4, 5, 6] else ''
        #     )

        # self.lineEdit.setText(expression)
        print('expression')
        print(expression)
        # 새 선택
        if selectIndex == 0:
            # 객체 선택 해제
            layer.removeSelection()
            layer.selectByExpression(expression, QgsVectorLayer.SetSelection)
        # 추가 선택
        elif selectIndex == 1:
            layer.selectByExpression(expression, QgsVectorLayer.AddToSelection)
        # 선택 제거
        elif selectIndex == 2:
            layer.selectByExpression(expression, QgsVectorLayer.RemoveFromSelection)
        # 선택내 선택
        elif selectIndex == 3:
            layer.selectByExpression(expression, QgsVectorLayer.IntersectSelection)

        # 화면에서 선택
        elif selectIndex == 4:
            layer.removeSelection()
            # 레이어의 좌표계를 가져옵니다.
            layer_crs = layer.crs()
            # 현재 화면의 좌표계를 가져옵니다.
            canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            # 좌표 변환 객체를 생성합니다.
            transform = QgsCoordinateTransform(canvas_crs, layer_crs, QgsProject.instance())
            # 현재 화면의 범위를 가져옵니다.
            extent = self.iface.mapCanvas().extent()
            # 화면 좌표계를 레이어 좌표계로 변환합니다.
            extent = transform.transform(extent)
            # 현재 캔버스 화면에 보이는 객체 중에서 속성값이 일치하는 객체를 선택합니다.
            request = QgsFeatureRequest().setFilterExpression(expression).setFilterRect(extent)
            features = layer.getFeatures(request)
            for feature in features:
                layer.select(feature.id())

        # 선택된 객체들을 하이라이트
        layer.triggerRepaint()

        # 선택된 객체들에 대한 특정 필드의 속성 통계 계산
        selected_features = layer.selectedFeatures()  # 레이어의 모든 객체 가져오기

        self.label_count.setText(f"선택객체 : {len(selected_features)}")

        if self.checkBox_zoom.isChecked():
            self.zoom()
        self.chk = False
        self.iface.setActiveLayer(layer)
        # 메세지 표출
        self.iface.messageBar().pushMessage(f"선택된 객체가 {len(selected_features)}개 입니다.", level=Qgis.Info, duration=5)
        self.chk = True

    def Reset(self):
        self.mMapLayerComboBox.setCurrentIndex(0)
        self.comboBox_filter.setCurrentIndex(0)
        for num in range(1, self.Fieldidx+1):
            FieldComboBox = self.findChild(QComboBox,'mFieldComboBox_'+str(num))
            FieldComboBox.setLayer(None)
            # FieldComboBox.setEnabled(False)
            ValueComboBox=self.findChild(QComboBox,'comboBox_val_'+str(num))
            ValueComboBox.clear()
            # ValueComboBox.setEnabled(False)
            SymbolComboBox = self.findChild(QComboBox,'comboBox_sb_'+str(num))
            SymbolComboBox.clear()
            # SymbolComboBox.setEnabled(False)
            if num > 1:
                AndOrComboBox=self.findChild(QComboBox,'ComboBox_AndOr_'+str(num))
                AndOrComboBox.setCurrentIndex(0)
                # AndOrComboBox.clear()
                # AndOrComboBox.setEnabled(False)
        Layer = self.canvas.currentLayer()
        self.mMapLayerComboBox.setAllowEmptyLayer(True)
        if self.chk == False and Layer  != None and Layer.type() == QgsMapLayerType.VectorLayer:
            self.chk = True
            self.mMapLayerComboBox.setLayer(Layer)
            self.LayerChange()

    def copy(self):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                self.layer_set = set()
                layer = self.mMapLayerComboBox.currentLayer()
                selected_features = layer.selectedFeatures()

                if selected_features==[]:
                    return

                self.layer_set.add(layer)
                for layer in self.layer_set:
                    new_name = '###'+layer.name()
                    wkb_type = layer.wkbType()
                    layer_crs = layer.sourceCrs()
                    fields = QgsFields(layer.fields())
                    new_layer = QgsVectorLayer("{}?crs={}".format(QgsWkbTypes.displayString(wkb_type), layer_crs.authid()), new_name, "memory")
                    dp = new_layer.dataProvider()
                    dp.addAttributes(fields)
                new_layer.updateFields()
                QgsProject.instance().addMapLayer(new_layer)
                new_layer.startEditing()

                for feature in selected_features:
                    # 속성 값 가져오기
                    attributes = feature.attributes()
                    f = QgsFeature()
                    f.setGeometry(feature.geometry())  # 올바른 방법: QgsGeometry 객체를 전달
                    f.setAttributes(attributes) # 새로운 QgsFeature에 속성 설정
                    new_layer.dataProvider().addFeatures([f])

                new_layer.updateExtents()
                self.canvas.refresh()

    def move(self):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                layer = self.mMapLayerComboBox.currentLayer()
                selected_features = layer.selectedFeatures()
                if selected_features==[]:
                    return
                # 선택객체 박스 영역 가져오기
                selection_bbox_project_crs = self.selection_box()
                # 바운딩 박스의 중심 좌표 계산
                center_x = (selection_bbox_project_crs.xMinimum() + selection_bbox_project_crs.xMaximum()) / 2
                center_y = (selection_bbox_project_crs.yMinimum() + selection_bbox_project_crs.yMaximum()) / 2

                # 맵 캔버스를 중심점들의 평균값으로 이동
                self.canvas.setCenter(QgsPointXY(center_x, center_y))
                self.canvas.refresh()

    def zoom(self):
        if self.chk:
            if self.mMapLayerComboBox.currentIndex() > 0:
                layer = self.mMapLayerComboBox.currentLayer()
                selected_features = layer.selectedFeatures()
                if selected_features==[]:
                    return
                # 선택객체 박스 영역 가져오기
                selection_bbox_project_crs = self.selection_box()
                # bounding box 크기를 10% 확장
                width = selection_bbox_project_crs.width()
                height = selection_bbox_project_crs.height()
                delta_x = width * 0.025  # 5%의 0.025
                delta_y = height * 0.025  # 5%의 0.025
                
                # 새로운 확장된 QgsRectangle 생성
                expanded_bbox = QgsRectangle( selection_bbox_project_crs.xMinimum() - delta_x,
                                            selection_bbox_project_crs.yMinimum() - delta_y,
                                            selection_bbox_project_crs.xMaximum() + delta_x,
                                            selection_bbox_project_crs.yMaximum() + delta_y )

                # 화면을 선택된 객체들의 영역으로 이동 및 확대
                self.canvas.setExtent(expanded_bbox)
                self.canvas.refresh()

    def selection_box(self):
        layer = self.mMapLayerComboBox.currentLayer()
        project_crs = QgsProject.instance().crs()
        # 선택된 객체들 가져오기
        selected_features = layer.selectedFeatures()
        # 선택객체가 없다면 중단
        if selected_features==[]:
            return
        # 선택된 객체들의 영역 결정
        selection_bbox = layer.boundingBoxOfSelected()
        # 좌표 변환 - 레이어 좌표계에서 현재 프로젝트 좌표계로
        xform = QgsCoordinateTransform(layer.crs(), project_crs, QgsProject.instance())
        selection_bbox_project_crs = xform.transformBoundingBox(selection_bbox)
        return selection_bbox_project_crs