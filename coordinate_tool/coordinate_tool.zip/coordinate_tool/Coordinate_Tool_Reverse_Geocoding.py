from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,
                       Qgis)

from PyQt5.QtCore import(QSettings,
                         QTimer,
                         Qt)

from qgis.gui import QgsMapToolEmitPoint

from PyQt5.QtGui import QKeySequence

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from .Coordinate_Tool_Funtion import Coordinate_funtion

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

class CoordinateTool_ReverseGeocoding(QgsMapToolEmitPoint):

    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.CTool = CTool
        self.canvas = iface.mapCanvas()
        self.QSettings=QSettings()
        self.Funtion = Coordinate_funtion(self,iface)
        
    def activate(self):
        self.canvas.setCursor(Qt.CrossCursor)

    def deactivate(self):
        self.CTool.Delete_Marker_Shot(1000)
        action = self.action()
        if action:
            action.setChecked(False)
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, event):     
        button = event.button()
        point = self.toMapCoordinates(self.canvas.mouseLastXY())
        self.CTool.Draw_Marker(point,4)
        Lon = format(point[0])
        Lat = format(point[1])
        epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(canvasCRS,epsg4326, QgsProject.instance())
        idx = int(self.QSettings.value('coordinate_tool/AddressSearchComboBox', 0))
        point = transform.transform(float(Lon), float(Lat))
        try:
            if idx == 0:
                ctp, sig, roadaddress, jibunaddress = self.Funtion.kakaojoso(point)
                txt = 'kakao'
            elif idx == 1:
                ctp, sig, roadaddress, jibunaddress = self.Funtion.naverjoso(point)
                txt = 'Naver'
            elif idx == 2:
                ctp, sig, roadaddress, jibunaddress = self.Funtion.vworldjoso(point)
                txt = 'Vworld'
            else:
                ctp, sig, roadaddress, jibunaddress = self.Funtion.Routojoso(point)
                txt = 'Routo'
                
            if button == Qt.LeftButton: address = roadaddress 
            if button == Qt.RightButton: address = jibunaddress  
                
            grs = self.Funtion.fscoordinate(point)
            map, company, team, ctp, sig = self.Funtion.mapidinfo(grs)
            self.iface.statusBarIface().showMessage(f"{company} / {team} / {ctp} / {sig} / {map} / {grs}")
            
            if address is not None:
                if int(self.QSettings.value('coordinate_tool/addressMsgBox', Qt.Checked)) == 2:
                    QMessageBox.information(self.iface.mainWindow(), txt , str(address))  
                else:
                    self.iface.messageBar().pushMessage( txt + f"주소 : ' {address} ' 클립보드에 복사 완료", level=Qgis.Info, duration=5)
                # QMessageBox.information(self.iface.mainWindow(), "Kakao", str(finalAddress))  
                self.clipboard=QApplication.clipboard()
                self.clipboard.setText(address)
            
        except Exception:
            self.iface.statusBarIface().showMessage("")
            
        self.CTool.Delete_Marker_Shot(2000)