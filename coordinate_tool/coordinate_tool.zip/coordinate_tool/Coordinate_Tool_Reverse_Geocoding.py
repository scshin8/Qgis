from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject,
                       Qgis)
from qgis.PyQt.QtCore import(QSettings,Qt)
from qgis.gui import QgsMapToolEmitPoint
from qgis.PyQt.QtGui import QKeySequence
from qgis.PyQt.QtWidgets import QMessageBox, QApplication

from .Coordinate_Tool_Function import Coordinate_function

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

class CoordinateTool_ReverseGeocoding(QgsMapToolEmitPoint):

    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.CTool = CTool
        self.canvas = iface.mapCanvas()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.Function = Coordinate_function(self,iface)
        
    def activate(self):
        self.canvas.setCursor(Qt.CrossCursor)

    def deactivate(self):
        self.CTool.Delete_Marker_Shot(1000)
        action = self.action()
        if action:
            action.setChecked(False)
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, event):     
        button = event.button()
        point = self.toMapCoordinates(self.canvas.mouseLastXY())
        self.CTool.Draw_Marker(point,4)
        Lon = format(point[0])
        Lat = format(point[1])
        epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(canvasCRS,epsg4326, QgsProject.instance())
        idx = int(self.QSettings.value('AddressSearchComboBox', 0))
        point = transform.transform(float(Lon), float(Lat))
        try:
            if idx == 0:
                ctp, sig, roadaddress, jibunaddress = self.Function.kakaojoso(point)
                txt = 'kakao'
            elif idx == 1:
                ctp, sig, roadaddress, jibunaddress = self.Function.vworldjoso(point)
                txt = 'Vworld'
            elif idx == 2:
                ctp, sig, roadaddress, jibunaddress = self.Function.Routojoso(point)
                txt = 'Routo'
            else:
                ctp, sig, roadaddress, jibunaddress = self.Function.naverjoso(point)
                txt = 'Naver'

            if button == Qt.LeftButton: address = roadaddress 
            if button == Qt.RightButton: address = jibunaddress  
                
            grs = self.Function.fscoordinate(point)
            map, company, team, ctp, sig = self.Function.mapidinfo(grs)
            self.iface.statusBarIface().showMessage(f"{company} / {team} / {ctp} / {sig} / {map} / {grs}")
            
            if address is not None:
                if int(self.QSettings.value('addressMsgBox', Qt.Checked)) == 2:
                    QMessageBox.information(self.iface.mainWindow(), txt , str(address))  
                else:
                    self.iface.messageBar().pushMessage( txt + f"주소 : ' {address} ' 클립보드에 복사 완료", level=Qgis.Info, duration=5)
                # QMessageBox.information(self.iface.mainWindow(), "Kakao", str(finalAddress))  
                self.clipboard=QApplication.clipboard()
                self.clipboard.setText(address)
            
        except Exception:
            self.iface.statusBarIface().showMessage("")
            
        self.CTool.Delete_Marker_Shot(2000)