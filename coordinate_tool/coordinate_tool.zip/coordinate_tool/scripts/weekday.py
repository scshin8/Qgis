from qgis.core import qgsfunction
from qgis.PyQt.QtCore import QDate, QDateTime
from datetime import datetime, timedelta
import math

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def weekday(value, feature, parent):
    # 1) value가 QDateTime인지 QDate인지 검사
    if isinstance(value, QDateTime):
        qdt = value
    elif isinstance(value, QDate):
        qdt = QDateTime(value)
    else:
        return None  # 날짜 타입이 아닌 경우 NULL 출력
        
    # 4) 요일 인덱스: QDate.dayOfWeek() ➔ 1=월요일, …, 7=일요일
    weekday_index = qdt.date().dayOfWeek() - 1
    
    # 5) 주의 시작(월요일) 날짜 
    start_of_week = qdt.addDays(-weekday_index)
    
    # 5) 월
    month  = start_of_week.date().month()
    
    # 6) 그 날짜(day)를 7로 나누어 주차 계산
    week_num = math.ceil(start_of_week.date().day() / 7)
    # 7) 결과 문자열 반환
    default_week_value = f"{month}{week_num}"
        
    return default_week_value
