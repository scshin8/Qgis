from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=['Pass_Info'])
def Pass_Info(value, feature, parent):
    value = int(value)
    bin_str = format(value, '016b')
    # 이진 문자열에서 '1'인 비트의 위치(1부터 시작)
    positions = [i+1 for i, bit in enumerate(bin_str) if bit == '1']

    return ','.join(str(p) for p in positions)
