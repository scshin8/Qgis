from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def cateTokind(value, feature, parent):
    mapping = {
    '1': 1,
    '2': 2,
    '3': 4,
    '4': 8,
    '5': 16,
    '6': 32,
    '7': 64,
    '8': 128,
    '3,10': 516,
    '1,12': 2049,
    '3,12': 2052,
    '4,12': 2056,
    '6,12': 2080,
    '7,12': 2112,
    '3,13': 4100,
    '6,13': 4128,
    '16': 32768,
    '10,16': 33280,
    '12,16': 34816,
    '13,16': 36864,
    '16,15': 49152
    }
    try:
        return mapping.get(value, None)
    except ValueError:
        return False
