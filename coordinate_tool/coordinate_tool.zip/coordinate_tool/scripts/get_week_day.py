from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def get_week_day(bit1, feature, parent):
    """
    비트 연산을 통해 각 비트에 해당하는 요일을 확인합니다.
    <h2>Example usage:</h2>
    <ul>
      <li>get_week_day(3) -> '월화' </li>
      <li>get_week_day(127) -> '월화수목금토일' </li>
    </ul>
    """
    week_days = ["월", "화", "수", "목", "금", "토", "일", "공휴"]
    result = ""
    bit1 = int(bit1)
    if bit1 & 1:
        result += week_days[0]
    if bit1 & 2:
        result += week_days[1]
    if bit1 & 4:
        result += week_days[2]
    if bit1 & 8:
        result += week_days[3]
    if bit1 & 16:
        result += week_days[4]
    if bit1 & 32:
        result += week_days[5]
    if bit1 & 64:
        result += week_days[6]
    if bit1 & 128:
        result += week_days[7]

    return result
