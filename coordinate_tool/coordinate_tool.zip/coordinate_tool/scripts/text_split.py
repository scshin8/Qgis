from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def text_split(split_field, split_txt, numbre, feature, parent):

    Value = None
    try:
        Value = str(split_field).split(split_txt)[numbre]
        
        return Value
        
    except ValueError:
        return False
