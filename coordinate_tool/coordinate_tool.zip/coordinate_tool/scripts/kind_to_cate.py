from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def kindTocate(value, feature, parent):
    reverse_mapping = {
    1: '1',
    2: '2',
    4: '3',
    8: '4',
    16: '5',
    32: '6',
    64: '7',
    128: '8',
    516: '3,10',
    2049: '1,12',
    2052: '3,12',
    2056: '4,12',
    2080: '6,12',
    2112: '7,12',
    4100: '3,13',
    4128: '6,13',
    32768: '16',
    33280: '10,16',
    34816: '12,16',
    36864: '13,16',
    49152: '16,15'
    }
    try:
        return reverse_mapping.get(value, None)
    except ValueError:
        return False
