from qgis.core import *
from qgis.gui import *

startGroup = 1
endGroup = 1000
startValue = None
endValue = None
lastvalue = None

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def log_flag(value, feature, parent):
    global startGroup, endGroup, startValue, endValue, lastvalue   # 전역 변수 선언
    
    if lastvalue is None:
        lastvalue = value
        if value == '0':
            endValue = 0
            return endGroup
        else:
            startValue = 0
            return startGroup

    elif lastvalue == value:
        return endGroup if value == '0' else startGroup
        
    elif lastvalue != value:
        lastvalue = value
        if value == '0':
            if endValue is None:
                endValue = 0
            else:
                endGroup += 1
                
            return endGroup
        else:
            if startValue is None:
                startValue = 0
            else:
                startValue = 0
                startGroup += 1
                
            return startGroup
