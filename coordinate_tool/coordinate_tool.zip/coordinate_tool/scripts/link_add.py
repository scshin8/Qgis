from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def link_add(number, feature, parent):

    link_add = ['중앙버스전용차로', '측면버스전용차로','자동차전용차로(본선)','자동차전용차로(연결도로)','가변차로','','',
                '고속화도로','분기후합류도로','자동차전용차로(연결도로)','고속/도시고속좌측합류도로']
    
    Value = None
    
    try:
        for i in range(11):
            # Convert the input values to integers
            number = int(number)
            print(number)
            power = int(i)
            if (number & (1 << power)) != 0:
                print(power)
                if Value == None:
                    Value = link_add[i]
                else:
                    Value = f'{Value},{link_add[i]}'
        return Value
        
    except ValueError:
        return False
