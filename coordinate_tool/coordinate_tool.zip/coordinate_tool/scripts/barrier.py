from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def barrier(value, feature, parent):
    mapping = {
    '16': '벽분리대',
    '32': '봉분리대',
    '48': '화단분리대',
    '64': '안전지대분리대',
    '80': '금속분리대',
    '240': '기타분리대',
    }
    try:
        return mapping.get(value, None)
    except ValueError:
        return False
