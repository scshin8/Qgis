from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject,
                       QgsWkbTypes,
                       QgsPointXY,
                       Qgis)

from PyQt5.QtCore import (QSettings,
                          QTimer, 
                          Qt,QUrl)

from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand

from PyQt5 import QtCore

from PyQt5.QtGui import QKeySequence

from qgis.PyQt.QtWidgets import QMessageBox
import webbrowser , requests , json, math, re 
from . import Coordinate_Tool_data

class CoordinateToolShowOnMap(QgsMapToolEmitPoint):

    CRS = {
        'wgs84': QgsCoordinateReferenceSystem('EPSG:4326'),
        '5181': QgsCoordinateReferenceSystem('EPSG:5181'),
        '3857': QgsCoordinateReferenceSystem('EPSG:3857'),
        '5179': QgsCoordinateReferenceSystem('EPSG:5179')
    }

    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.CTool = CTool
        self.canvas = iface.mapCanvas()
        self.externalBasemapCnt = len(Coordinate_Tool_data.MAP_PROVIDERS)
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.point_band = QgsRubberBand(iface.mapCanvas(),QgsWkbTypes.PointGeometry )
        self.line_band = QgsRubberBand(iface.mapCanvas(),QgsWkbTypes.LineGeometry )
        self.premuto= False
        self.linea=False
        self.start_pt=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)
        self.end_pt=iface.mapCanvas().getCoordinateTransform().toMapCoordinates(0, 0)

    def activate(self):
        '''When activated set the cursor to a crosshair.'''
        self.canvas.setCursor(Qt.CrossCursor)
        # self.snapcolor = QgsSettings().value( "/qgis/digitizing/snap_color" , QColor( Qt.magenta ) )

    def deactivate(self):
        self.CTool.Delete_Marker_Shot(1000)
        self.clear_rubber()
        action = self.action()
        if action:
            action.setChecked(False)
        return None
    
    def clear_rubber(self):
        self.point_band.reset()
        self.line_band.reset()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.clear_rubber()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, event):
        self.clear_rubber()
        
        x = event.pos().x()
        y = event.pos().y()
        self.pt=self.toMapCoordinates(self.canvas.mouseLastXY())

        if not self.premuto: 
            self.premuto=True
            self.point_band=QgsRubberBand(self.iface.mapCanvas(),QgsWkbTypes.PointGeometry )
            self.point_band.setColor ( QtCore.Qt.red )
            self.start_pt = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
            self.point_band.addPoint(self.start_pt)

    def canvasMoveEvent(self, event):
        x = event.pos().x()
        y = event.pos().y()
        self.button = event.button()

        if self.premuto: 
            if not self.linea:
                self.line_band.setColor ( QtCore.Qt.red )
                self.end_pt = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
                self.line_band.addPoint(self.start_pt)  
                self.line_band.addPoint(self.end_pt)
                self.linea=True
            else:
                if self.linea: 
                    self.end_pt = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
                    self.line_band.reset(QgsWkbTypes.LineGeometry)
                    self.line_band.addPoint(self.start_pt)  
                    self.line_band.addPoint(self.end_pt)

    def _to_wgs84(self, point, src_crs):
        transformer = QgsCoordinateTransform(src_crs, self.CRS['wgs84'], QgsProject.instance())
        p = transformer.transform(point)
        return p.x(), p.y(), p
    
    def _compute_angle(self, p0, p1):
        rad = math.atan2(p1.x() - p0.x(), p1.y() - p0.y())
        deg = math.degrees(rad)
        return (int(deg) + 360) % 360
    
    def canvasReleaseEvent(self, event):
        self.clear_rubber()

        self.button = event.button()

        self.mapProviderLeft = int(self.QSettings.value('MapProvider', 0))
        self.mapProviderRight = int(self.QSettings.value('MapProviderRight', 0))
        self.userMapProviders = self.QSettings.value('UserMapProviders', 0)

        canvasCRS = self.canvas.mapSettings().destinationCrs()
        lon, lat, p = self._to_wgs84(self.start_pt, canvasCRS)
        angle = self._compute_angle(self.start_pt, self.end_pt)

        self.premuto=False
        self.linea=False

        if self.button == Qt.RightButton:
            mapProvider = self.mapProviderRight
            placemark=int(self.QSettings.value('checkBox_placemark_2', Qt.Checked))
            self.CTool.Draw_Marker(self.pt,3)
            self.mapZoom=int(self.QSettings.value('zoomSpinBox_2', 15))
        elif self.button == Qt.LeftButton:
            mapProvider = self.mapProviderLeft
            placemark=int(self.QSettings.value('checkBox_placemark_1', Qt.Checked))
            self.CTool.Draw_Marker(self.pt,2)
            self.mapZoom=int(self.QSettings.value('zoomSpinBox_1', 15))

        if mapProvider >= self.externalBasemapCnt:
            # These are the optional user basemaps
            ms = self.userMapProviders[mapProvider - self.externalBasemapCnt][1]
            na = self.userMapProviders[mapProvider - self.externalBasemapCnt][0]
            
            ms = ms.replace('{lon}', str(lon)).replace('{lat}', str(lat))
        else:
            # 템플릿 가져오기
            na = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][0]
            ms = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][2 if placemark == 2 else 1]

            # 미리 상수로 묶어두면 가독성↑
            KAKAO_ROADVIEWS = {'카카오 로드뷰(일반)', '카카오 로드뷰(위성)', '카카오 로드뷰(Hybrid)'}
            KAKAO_MAPS     = {'카카오 일반', '카카오 위성', '카카오 Hybrid'}
            NAVER_VIEWS    = {'네이버 거리뷰(일반)', '네이버 거리뷰(위성)', '네이버 거리뷰(Hybrid)'}
            GOOGLE_VIEW    = 'Google Street View'

            if na in NAVER_VIEWS:
                # lon, lat, id, tilt = self.naverURL(self.pt,canvasCRS)

                to5179 = QgsCoordinateTransform(self.CRS['wgs84'], self.CRS['5179'], QgsProject.instance())
                toWGS84 = QgsCoordinateTransform(self.CRS['5179'], self.CRS['wgs84'], QgsProject.instance())

                pt_5179  = to5179.transform(p)
                
                dx, dy = self.getshift(self.mapZoom)
                
                shifted_5179 = QgsPointXY(pt_5179.x() - dx, pt_5179.y() + dy)
                shifted_wgs84 = toWGS84.transform(shifted_5179)
                lon = shifted_wgs84.x()
                lat = shifted_wgs84.y()

                ms = ms.replace('{angle}', str(angle)).replace('{lon}', str(lon)).replace('{lat}', str(lat)) # ms.replace('{id}'

            elif na in KAKAO_ROADVIEWS or na in KAKAO_MAPS:
                lon, lat, id = self.kakaoURL(self.pt,canvasCRS)
                if na in KAKAO_MAPS:
                    ms = ms.replace('{lon}', str(lon)).replace('{lat}', str(lat))
                else:
                    ms = ms.replace('{id}', str(id)).replace('{angle}', str(angle)).replace('{lon}', str(lon)).replace('{lat}', str(lat))
            elif na in GOOGLE_VIEW:
                ms = ms.replace('{lon}', str(lon)).replace('{lat}', str(lat)).replace('{angle}', str(angle))
            else:
                ms = ms.replace('{lon}', str(lon)).replace('{lat}', str(lat))
            
        # if int(self.QSettings.value('checkBox_placemark', Qt.Checked))==2:
            # ms = ms.replace('{zoom}', str(self.mapZoom))
        if na in KAKAO_MAPS:
            ms = ms.replace('{zoom}',str(abs(self.mapZoom-19)))
        else:
            ms = ms.replace('{zoom}', str(self.mapZoom))

        self.webbrowserOpen(na, ms, lat, lon)

        self.clear_rubber()

    def getshift(self, mapZoom):
        shift_by_zoom = {
            15: [340, 60],
            16: [170, 30],
            17: [85, 15],
            18: [42, 7],
            19: [21, 3],
            20: [10, 0]
        }
        dxy = shift_by_zoom.get(mapZoom, 0)
        try:
            dx = list(dxy)[0]
            dy = list(dxy)[1]
        except:
            dx = 0
            dy = 0
        return dx, dy

    def webbrowserOpen(self, na, ms, lat, lon):

        url = QUrl(ms).toString()
        try:
            webbrowser.open(url, new = 0, autoraise=True)#, autoraise = False )
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushMessage("", "Viewing Coordinate %f , %f in external map" % (lat, lon), level=Qgis.Info, duration=5)
            self.CTool.Delete_Marker_Shot(2000)
            QTimer.singleShot(1000, self.remove)

        except Exception as e:
            print("show Error : ", e)
            QMessageBox.critical(self.iface.mainWindow(), "Error", na + "불러오기 실패")

    def _transform_point(self, pt, src_crs, dest_crs):
        tr = QgsCoordinateTransform(src_crs, dest_crs, QgsProject.instance())
        x, y = (pt.x(), pt.y()) if hasattr(pt, 'x') else pt
        return tr.transform(x, y)

    def kakaoURL(self, pt, canvasCRS):
        pt5181 = self._transform_point(pt, canvasCRS, self.CRS['5181'])
        lat = pt5181.y()
        lon = pt5181.x()
        url = f'https://rv.map.kakao.com/roadview-search/v2/nodes?PX={float(lon)}&PY={float(lat)}&RAD=35&PAGE_SIZE=50&INPUT=wtm&TYPE=w&SERVICE=glpano'
        response = requests.get(url=url, verify=False)
        text = json.loads(response.text)
        data = text['street_view']['streetList'][0]
        id = data['id']
        lon=data['wcongx']
        lat=data['wcongy']
        return lon, lat, id
            
    def naverURL(self, pt, canvasCRS):
        pt4326 = self._transform_point(pt, canvasCRS, self.CRS['wgs84'])
        lon = pt4326.x()
        lat = pt4326.y()
        url = f'https://m.map.naver.com/viewer/panorama.naver?lng={float(lon)}&lat={float(lat)}'
        response = requests.post(url, verify=False)

        if response.status_code == 200:
            try:
                text= response.text
                idx = text.find('"panorama"') + 12
                end_idx = text[idx:].find("}")
                pano = text[idx:idx + end_idx + 1]
                pr = json.loads(pano)
                pt3857 = self._transform_point((lon, lat), self.CRS['wgs84'], self.CRS['3857'])
                lat = float(pt3857.y())
                lon = float(pt3857.x())
                id = pr["id"]
                tilt =pr['tilt']
                return lon, lat, id, tilt
            except Exception as e:
                print("naverURL Error : ", e)
                pass
        else:
            # QMessageBox.critical(self.iface.mainWindow(), "Error", "네이버 거리뷰 불러오기 실패")
            self.deactivate()
            return None
            
    def remove(self):
        self.iface.actionPan().trigger()