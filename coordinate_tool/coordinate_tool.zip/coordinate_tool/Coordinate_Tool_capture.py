from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject,
                       Qgis,
                       QgsPointXY)

from PyQt5.QtCore import (QTimer,
                          QSettings,
                          Qt)

from qgis.gui import QgsMapToolEmitPoint

from PyQt5.QtGui import QKeySequence

from PyQt5.QtWidgets import QApplication

from qgis.PyQt.QtWidgets import QMessageBox

from qgis.utils import (unloadPlugin, 
                        loadPlugin, 
                        startPlugin)

from .Coordinate_Tool_Function import Coordinate_function
from .Coordinate_Tool_ShowOnMap import CoordinateToolShowOnMap
import time
import subprocess
import sys
import platform

VERSION = Qgis.QGIS_VERSION_INT
full_version = Qgis.QGIS_VERSION
QGIS_VERSION = f"QGIS {full_version.split('-')[0]}"  # '3.40.6'
# python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
python_path = f"C:/Program Files/{QGIS_VERSION}/bin/python.exe"
try:
    import pyautogui
except:

    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'PyAutoGUI'])
    else:
        try:
            subprocess.check_call(['python', '-m', 'pip', 'install', 'pyautogui'])
        except subprocess.CalledProcessError as e:
            print("pip 설치 실패. 코드:", e.returncode)
    import pyautogui

try:
    import pyperclip
except:
    # 운영 체제가 Mac인지 확인
    if platform.system() == "Darwin":  # Darwin은 macOS를 의미
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in python_path:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'pyperclip'])
    else:
        subprocess.check_call(['python','-m', 'pip', 'install', 'pyperclip'])
    import pyperclip

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')

class CoordinateToolcapture(QgsMapToolEmitPoint):
    # captureStopped = pyqtSignal()
    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface      = iface
        self.canvas     = iface.mapCanvas()
        self.CTool      = CTool
        self.Function   = Coordinate_function(self,iface)
        self.ShowOnMap  = CoordinateToolShowOnMap(self,iface)
        self.clipboard  = QApplication.clipboard()
        self.QSettings  = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def activate(self):
        self.canvas.setCursor(Qt.CrossCursor)

    def deactivate(self):
        self.CTool.Delete_Marker_Shot(3000)
        action = self.action()
        if action:
            action.setChecked(False)
        return None
    
# 좌표 캡쳐중 키 이벤트 구문
    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.iface.actionPan().trigger()
            
    def canvasMoveEvent(self, e):
        if self.CTool.Coordinatecapture.isChecked():
            try:
                originalPoint = QgsPointXY(self.canvas.getCoordinateTransform().toMapCoordinates(e.x(), e.y()))
                canvasCRS = self.canvas.mapSettings().destinationCrs()
                transform = QgsCoordinateTransform(canvasCRS,epsg4162, QgsProject.instance())
                BESPoint = transform.transform(originalPoint)
                bes = self.Function.fscoordinate(BESPoint)
                maid8Lv = self.Function.mapid_8Lv(BESPoint)
                map, company, team, ctp, sig = self.Function.mapidinfo(bes)
                self.iface.statusBarIface().showMessage("{} / {} / {} / {} / {} / {} / {}".format(company, team, ctp, sig, map, maid8Lv, bes))
            except:
                self.iface.statusBarIface().showMessage("canvasMoveEvent : Error")

# 좌표 캡쳐 이벤트 구문
    def canvasPressEvent(self, event):
        button = event.button()

        if event.modifiers() & Qt.ControlModifier: # Qt.AltModifier:  Qt.ShiftModifier
            CTRLPressed = True
        else:
            CTRLPressed = None
        if event.modifiers() & Qt.AltModifier: # Qt.AltModifier:
            AltPressed = True
        else:
            AltPressed = None

        # 좌표값 point변수로 저장
        point = self.toMapCoordinates(self.canvas.mouseLastXY())
        # 프로젝트(화면) 좌표계 확인
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        position=pyautogui.position()

    # speedfs 좌표이동
        if CTRLPressed  and not AltPressed:
            if  button == Qt.LeftButton:
                try:
                    Lon = point[0]
                    Lat = point[1]

                    transform = QgsCoordinateTransform(canvasCRS,epsg4162, QgsProject.instance())

                    point = transform.transform(float(Lon), float(Lat))
                    fsLon = float(point[0]*360000)
                    fsLat = float(point[1]*360000)
                    fsmms = '('+str(fsLon)+','+str(fsLat)+')'

                    pyperclip.copy(fsmms)

                    self.SpeedFS(fsmms)

                except Exception as e:
                    QMessageBox.critical(self.iface.mainWindow(), "Error", str(e))
                    print('canvasPressEvent : Error - ', e)
                    self.iface.actionPan().trigger()
        # coconut 좌표이동
            if  button == Qt.RightButton:
                try:
                    msg, speedfs = self.coconut(canvasCRS, point)
                except Exception as e:
                    QMessageBox.critical(self.iface.mainWindow(), "Error", str(e))
                    print('canvasPressEvent : Error - ', e)
                    self.iface.actionPan().trigger()

        elif button == Qt.LeftButton or button == Qt.RightButton:
            # 좌클릭
            if button == Qt.LeftButton:
                # if CTRLPressed:  # Qt::AltModifier , Qt::ShiftModifier
                #     self.ShowOnMap.show(button,point,canvasCRS)
                Order=int(self.QSettings.value('ComboBox1', 0))
                mms=int(self.QSettings.value('checkBox_MMS_1', Qt.Checked))
                Fs=int(self.QSettings.value('checkBox_Fs_1', Qt.Checked))
                setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project1','USER:100000'))
                self.CTool.Draw_Marker(point,0)
            # 우클릭
            elif button == Qt.RightButton:
                # if CTRLPressed:  # Qt::AltModifier , Qt::ShiftModifier
                #     self.ShowOnMap.show(button,point,canvasCRS)
                Order=int(self.QSettings.value('ComboBox2', 0))
                mms=int(self.QSettings.value('checkBox_MMS_2', Qt.Checked))
                Fs=int(self.QSettings.value('checkBox_Fs_2', Qt.Checked))
                setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('Project2','USER:100001'))
                self.CTool.Draw_Marker(point,1)
        
            # 좌표값 분리
            Lon = format(point[0])
            Lat = format(point[1])
            # 설정 좌표계 식별코드 확인
            setCRSid = setCRS.authid() # description()_좌표계이름  authid()_좌표계 식별코드
            setCRSdescription = setCRS.description() # description()_좌표계이름  authid()_좌표계 식별코드
            # 좌표변환 설정 : 프로젝트(화면) 좌표계에서 캡쳐 설정된 좌표계로 변환
            transform = QgsCoordinateTransform(canvasCRS,setCRS, QgsProject.instance())
            # 좌표값 변환 하여 x,y 로 저장
            point = transform.transform(float(Lon), float(Lat))
            # 설정 좌표계가 사용자저의 좌표계라면
            if 100000 <= int(setCRSid.split(':')[1]):
                # FS조표로 저장 체크값 확인
                # 체크가 있다면
                if Fs == 2:
                    msg = self.Function.fscoordinate(point)
                    speedfs = msg
                # 체크가 없다면
                else:
                    Lon = float(point[0])
                    Lat = float(point[1])
                    # mms 체크가 있다면
                    if mms == 2:
                        msg = '('+str(int(Lon))+','+str(int(Lat))+')'
                        mms = msg
                    # mms 체크가 없다면
                    else:
                        msg = str(Lon) + ',' + str(Lat)
            # 사용자정의 좌표계가 아니라면
            else:
                if Fs == 2:
                    msg = self.Function.fscoordinate(point)
                    speedfs = msg
                else:
                    if mms == 2:
                        Lon=int(float(point[0])*360000)
                        Lat=int(float(point[1])*360000)

                        msg = '('+str(Lon)+','+str(Lat)+')'  
                        mms = msg              
                    else:
                        Lon=point[0]
                        Lat=point[1]
                        # XY값 반전 여부 확인
                        if Order == 0:
                            msg = str(Lon)+','+str(Lat)
                        elif Order == 1:
                            msg = str(Lat)+','+str(Lon)
                            
            # 클립보드에 추출된 좌표값 저장
            self.clipboard.setText(msg)
            # 화면에 표출한 메세지 작성
            msg=str(setCRSdescription)+' : ' + msg
            # 기존 메세지창 삭제
            self.iface.messageBar().clearWidgets()
            # 좌표복사 메세지 표출
            self.iface.messageBar().pushMessage(f"{msg} copied to the clipboard", level=Qgis.Info, duration=5)

        self.CTool.Delete_Marker_Shot(3000)

    def coconut(self, canvasCRS, point):
        Lon = point[0]
        Lat = point[1]
        msg = None
        speedfs = None
        for win in pyautogui.getAllWindows():
            if  win.title.startswith('운영 DB') or win.title.startswith('운영DB'):
                if win.title.find('BESSEL') > -1:
                    coconuttransform = QgsCoordinateTransform(canvasCRS, epsg4162, QgsProject.instance())
                    msg = 'Bessel'
                else:
                    coconuttransform = QgsCoordinateTransform(canvasCRS, epsg4326, QgsProject.instance())
                    msg = 'GRS'
                point = coconuttransform.transform(float(Lon), float(Lat))
                speedfs = self.Function.fscoordinate(point)
                pyperclip.copy(speedfs)

                if win.isMinimized == True:
                    win.restore()
                win.activate()
                time.sleep(0.05)
                pyautogui.hotkey('Ctrl', 'v')
                time.sleep(0.05)
                # 기존 메세지창 삭제
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'coconut : {speedfs} copied to the clipboard', level=Qgis.Info, duration=5)
                break
        return msg, speedfs
    
    def SpeedFS(self, fsmms):
        msg = None
        for win in pyautogui.getAllWindows():
            if  win.title.startswith('SpeedFS'):
                if win.isMinimized == True:
                    win.restore()
                win.activate() 
                time.sleep(0.05)

                pyautogui.hotkey('Ctrl','Shift' ,'v')

                #     left=(win.right-win.left)/2
                #     top=(win.bottom-win.top)/2
                #     pyautogui.rightClick(win.left+left,win.top+top)
                #     pyautogui.press('down', presses = 9)
                #     pyautogui.press('enter')
                #     pyautogui.moveTo(position) 

                time.sleep(0.05)
                # self.clipboard.setText(speedfs)
                # 기존 메세지창 삭제
                self.iface.messageBar().clearWidgets()
                self.iface.messageBar().pushMessage(f'SpeedFS : {fsmms} copied to the clipboard', level=Qgis.Info, duration=5)
                msg = 'SpeedFS'
                break
        return msg

    def Delete_Marker(self):
        pass
        
    def Draw_Marker(self,point,idx):
        pass
        
class CoordinateToolMediaCenter(QgsMapToolEmitPoint):
    # captureStopped = pyqtSignal()
    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool = CTool
        self.Function = Coordinate_function(self,iface)
        self.clipboard=QApplication.clipboard()
        
    def activate(self):
        self.canvas.setCursor(Qt.CrossCursor)

    def deactivate(self):
        self.CTool.Delete_Marker()
        action = self.action()
        if action:
            action.setChecked(False)
        return None
    
# 좌표 캡쳐중 키 이벤트 구문
    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.iface.actionPan().trigger()

# 좌표 캡쳐 이벤트 구문
    def canvasPressEvent(self, event):
        button = event.button()

        # 좌표값 point변수로 저장
        point = self.toMapCoordinates(self.canvas.mouseLastXY())
        # 프로젝트(화면) 좌표계 확인
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        
        try:
            # 좌클릭
            if button == Qt.LeftButton:
                self.CTool.Draw_Marker(point,0)
                # 좌표값 분리
                Lon = format(point[0])
                Lat = format(point[1])
                position=pyautogui.position() 
                transform = QgsCoordinateTransform(canvasCRS,epsg4162, QgsProject.instance())
                point = transform.transform(float(Lon), float(Lat))
                speedfs = self.Function.fscoordinate(point)
                # 클립보드에 추출된 좌표값 저장
                pyperclip.copy(speedfs)
                fore = pyautogui.getActiveWindow()
                chk = 0
                for win in pyautogui.getAllWindows():
                    if  "Masco.MediaCenter" in win.title or "RemoteGrabber" in win.title:
                        if win.isMinimized == True:
                            win.restore()
                            time.sleep(0.2)
                        win.activate()
                        time.sleep(0.2)
                        # pyautogui.moveTo(win.left+280,win.top+140)
                        pyautogui.click(win.left+280,win.top+140)
                        pyautogui.moveTo(position) 
                        
                        pyautogui.keyDown('shift')
                        pyautogui.press('tab')
                        pyautogui.keyUp('shift')
                        
                        # pyautogui.click(win.left+280,win.top+170)
                        pyautogui.hotkey('Ctrl', 'v')
                        # pyperclip.paste() 

                        pyautogui.keyDown('Shift')
                        pyautogui.press('tab', presses = 7)
                        pyautogui.keyUp('Shift')
                        pyautogui.press('enter')
                        
                        # pyautogui.moveTo(win.left+900,win.top+130)
                        # pyautogui.click()
                        # pyautogui.click(win.left+900,win.top+130)

                        # # 기존 메세지창 삭제
                        self.iface.messageBar().clearWidgets()
                        # # 좌표복사 메세지 표출
                        self.iface.messageBar().pushMessage(f'Masco MediaCenter :  {speedfs} copied to the clipboard', level=Qgis.Info, duration=5)
                        chk = 1
                        # fore.activate()
                        break   
                    
            if chk==0:
                # import os, subprocess
                # os.startfile("D:/OneDrive - Masco/01_개인용/프로그램/MN/Mediacenter/Masco.MediaCenter.Client.Launcher.exe")

                # for win in pyautogui.getAllWindows():
                #     print( win.title )
                #     if  "Program Manager" in win.title or "Masco.MediaCenter" in win.title:
                #         if win.isMinimized == True:
                #             win.restore()
                #             time.sleep(0.2)
                #         win.activate()
                #         time.sleep(0.5)
                #         pyautogui.press('tab', presses = 2)
                #         time.sleep(0.1)
                #         pyautogui.typewrite('0001', interval=0.1)
                #         time.sleep(0.1)
                #         pyautogui.press('enter')

                # time.sleep(1)

                # for win in pyautogui.getAllWindows():
                #     if  "Masco.MediaCenter" in win.title or "RemoteGrabber" in win.title:
                #         if win.isMinimized == True:
                #             win.restore()
                #             time.sleep(0.2)
                #         win.maximize()
                #         time.sleep(0.2)

                #         # pyautogui.moveTo(win.left+280,win.top+140)
                #         pyautogui.click(win.left+280,win.top+140)
                #         pyautogui.moveTo(position) 
                        
                #         pyautogui.keyDown('shift')
                #         pyautogui.press('tab')
                #         pyautogui.keyUp('shift')
                        
                #         # pyautogui.click(win.left+280,win.top+170)
                #         pyautogui.hotkey('Ctrl', 'v')
                #         # pyperclip.paste() 

                #         pyautogui.keyDown('Shift')
                #         pyautogui.press('tab', presses = 7)
                #         pyautogui.keyUp('Shift')
                #         pyautogui.press('enter')
                        
                #         # pyautogui.moveTo(win.left+900,win.top+130)
                #         # pyautogui.click()
                #         # pyautogui.click(win.left+900,win.top+130)

                #         # # 기존 메세지창 삭제
                #         self.iface.messageBar().clearWidgets()
                #         # # 좌표복사 메세지 표출
                #         self.iface.messageBar().pushMessage(f'Masco MediaCenter :  {speedfs} copied to the clipboard', level=Qgis.Info, duration=5)
                #         chk = 1
                #         # fore.activate()
                #         break   
                
                self.iface.messageBar().pushMessage(f'MediaCenter Not activated', level=Qgis.Warning, duration=5)
            
            QTimer.singleShot(100, self.remove)
            self.CTool.Delete_Marker_Shot(2000)
            
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Error", str(e))
            print('MediaCenter : Error - ', str(e))
            self.iface.actionPan().trigger()
            
    def Delete_Marker(self):
        pass
        
    def Draw_Marker(self,point,idx):
        pass
    def remove(self):
        self.iface.actionPan().trigger()