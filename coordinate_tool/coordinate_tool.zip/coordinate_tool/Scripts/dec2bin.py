from qgis.core import *
from qgis.gui import *

@qgsfunction(args='auto', group='Custom', referenced_columns=[])
def dec2bin(value1, feature, parent):
    """
    십진수를 이진수로 변환한 다음 숫자 1의 개수를 반환 합니다.
    <h2>Example usage:</h2>
    <ul>
      <li>my_sum(10) -> 이진수(1010) -> 2</li>
    </ul>
    """
    return list(bin(value1)[2:]).count('1')
