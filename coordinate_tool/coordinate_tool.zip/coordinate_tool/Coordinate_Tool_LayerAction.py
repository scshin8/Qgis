# -*- coding: utf-8 -*-
import os
import processing
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsFields,
    QgsMapLayer,
    QgsField,
    Qgis,
    QgsMapLayerType,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils
)
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMenu, QAction, QDialogButtonBox


class CoordinateToolLayerAction:
    def __init__(self, main_tool, iface, plugin_dir):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = plugin_dir

        self.init_actions()

    def init_actions(self):
        """레이어 우클릭 컨텍스트 메뉴 액션 생성 및 등록"""
        # ─────────────────────────────────────────────────────────────
        # 1. 선택 객체 복사 서브메뉴
        # ─────────────────────────────────────────────────────────────
        self.duplicate_menu = QMenu("선택객체복사", self.iface.mainWindow())
        self.duplicate_menu.setObjectName('선택객체복사메뉴')
        group_icon = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate_menu.menuAction().setIcon(group_icon)

        # 선택객체복사(스타일X)
        icon_no_style = QIcon(self.plugin_dir + '/icons/duplicate1.png')
        self.duplicate = QAction(icon_no_style, "선택객체복사(스타일X)", self.iface.mainWindow())
        self.duplicate.setObjectName('선택객체복사_스타일X')
        self.duplicate.triggered.connect(lambda *args: self.duplicate_run(False, 0))
        self.duplicate_menu.addAction(self.duplicate)

        # 선택객체복사(스타일O)
        icon_style = QIcon(self.plugin_dir + '/icons/duplicate.png')
        self.duplicate1 = QAction(icon_style, "선택객체복사(스타일O)", self.iface.mainWindow())
        self.duplicate1.setObjectName('선택객체복사_스타일O')
        self.duplicate1.triggered.connect(lambda *args: self.duplicate_run(True, 0))
        self.duplicate_menu.addAction(self.duplicate1)

        self.duplicate_action = self.duplicate_menu.menuAction()
        self.iface.addCustomActionForLayerType(self.duplicate_action, None, QgsMapLayer.VectorLayer, True)

        # ─────────────────────────────────────────────────────────────
        # 2. 레이어 전체 복사 서브메뉴
        # ─────────────────────────────────────────────────────────────
        self.duplicateAll_menu = QMenu("레이어복사", self.iface.mainWindow())
        self.duplicateAll_menu.setObjectName('레이어복사메뉴')
        group_icon_all = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll_menu.menuAction().setIcon(group_icon_all)

        # 레이어복사(스타일X)
        icon_all_no_style = QIcon(self.plugin_dir + '/icons/duplicateALL1.png')
        self.duplicateAll = QAction(icon_all_no_style, "레이어복사(스타일X)", self.iface.mainWindow())
        self.duplicateAll.setObjectName('레이어복사_스타일X')
        self.duplicateAll.triggered.connect(lambda *args: self.duplicate_run(False, 1))
        self.duplicateAll_menu.addAction(self.duplicateAll)

        # 레이어복사(스타일O)
        icon_all_style = QIcon(self.plugin_dir + '/icons/duplicateALL.png')
        self.duplicateAll1 = QAction(icon_all_style, "레이어복사(스타일O)", self.iface.mainWindow())
        self.duplicateAll1.setObjectName('레이어복사_스타일O')
        self.duplicateAll1.triggered.connect(lambda *args: self.duplicate_run(True, 1))
        self.duplicateAll_menu.addAction(self.duplicateAll1)

        self.duplicateAll_action = self.duplicateAll_menu.menuAction()
        self.iface.addCustomActionForLayerType(self.duplicateAll_action, None, QgsMapLayer.VectorLayer, True)

        # ─────────────────────────────────────────────────────────────
        # 3. 선택 레이어 병합
        # ─────────────────────────────────────────────────────────────
        icon_merge = QIcon(self.plugin_dir + '/icons/merge.png')
        self.layermerge = QAction(icon_merge, "선택레이어병합", self.iface.mainWindow())
        self.layermerge.setObjectName('선택레이어병합')
        self.layermerge.triggered.connect(self.layermerge_run)
        self.iface.addCustomActionForLayerType(self.layermerge, None, QgsMapLayer.VectorLayer, True)

        # ─────────────────────────────────────────────────────────────
        # 4. 키 필드 생성
        # ─────────────────────────────────────────────────────────────
        icon = QIcon(self.plugin_dir + '/icons/key.png')
        self.keyfield = QAction(icon, "Key 필드 생성", self.iface.mainWindow())
        self.keyfield.setObjectName('Key 필드 생성')
        self.keyfield.triggered.connect(self.addKeyfield)
        self.iface.addCustomActionForLayerType(self.keyfield, None, QgsMapLayer.VectorLayer, True)

        # ─────────────────────────────────────────────────────────────
        # 5. 선택레이어경로 열기
        # ─────────────────────────────────────────────────────────────
        icon = QIcon(self.plugin_dir + '/icons/folder.png')
        self.folderPath = QAction(icon, "레이어경로열기", self.iface.mainWindow())
        self.folderPath.setObjectName('레이어경로열기')
        self.folderPath.triggered.connect(self.folderOpen)
        self.iface.addCustomActionForLayerType(self.folderPath, None, QgsMapLayer.VectorLayer, True)


    def duplicate_run(self, style, idx=0, *args):
        """객체 또는 레이어 복사 실행 (idx: 0=선택객체, 1=레이어전체)"""
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            return

        if idx == 0:
            try:
                features = layer.selectedFeatures()
                if not features:
                    return
                new_name = f'__{layer.name()}_선택복사'
            except Exception:
                return
        else:
            features = list(layer.getFeatures())
            new_name = f'__{layer.name()}_레이어복사'

        wkb_type = layer.wkbType()
        layer_crs = layer.sourceCrs()
        fields = QgsFields(layer.fields())
        new_layer = QgsVectorLayer(f"{QgsWkbTypes.displayString(wkb_type)}?crs={layer_crs.authid()}", new_name, "memory")
        dp = new_layer.dataProvider()
        dp.addAttributes(fields)
        new_layer.updateFields()

        if style:
            temp_style_file = os.path.join(self.plugin_dir, 'style', 'temp_style.qml')
            layer.saveNamedStyle(temp_style_file)
            new_layer.loadNamedStyle(temp_style_file)

        QgsProject.instance().addMapLayer(new_layer)
        new_layer.startEditing()
        dp.addFeatures(features)
        new_layer.updateExtents()
        self.canvas.refresh()

    def layermerge_run(self, *args):
        """선택 레이어 병합 실행"""
        self.iface.messageBar().clearWidgets()
        selected_layers = [
            layer for layer in QgsProject.instance().mapLayers().values() 
            if layer in self.iface.layerTreeView().selectedLayers()
        ]
        
        if len(selected_layers) < 2:
            self.iface.messageBar().pushMessage('병합할 레이어가 두 개 이상 선택되어야 합니다.', level=Qgis.Critical, duration=3)
            return

        # 각 레이어에 가상 필드 추가
        for layer in selected_layers:
            layer_name = layer.name()
            layer_path = layer.source()

            layer.addExpressionField(
                f"'{layer_name}'",
                QgsField("layer_name", QVariant.String)
            )
            layer.addExpressionField(
                f"'{layer_path}'",
                QgsField("layer_path", QVariant.String)
            )

        try:
            result = processing.run("native:mergevectorlayers", {
                "LAYERS": selected_layers,
                "CRS": selected_layers[0].crs(),
                "OUTPUT": "memory:"
            })
            merged_layer = result["OUTPUT"]
            merged_layer.setName("병합한 레이어")

            merged_layer.startEditing()
            for field_name in ["layer", "path"]:
                idx = merged_layer.fields().indexOf(field_name)
                if idx != -1:
                    merged_layer.deleteAttribute(idx)
            merged_layer.commitChanges()

            QgsProject.instance().addMapLayer(merged_layer)

            # 원본 레이어의 임시 가상 필드 정리
            for layer in selected_layers:
                for field_name in ["layer_name", "layer_path"]:
                    idx = layer.fields().indexOf(field_name)
                    if idx != -1:
                        layer.deleteAttribute(idx)

            self.iface.messageBar().pushMessage('레이어 병합 완료', level=Qgis.Info, duration=5)
        except Exception as e:
            self.iface.messageBar().pushMessage(f'레이어 병합 오류 : {e}', level=Qgis.Critical, duration=5)

    def addKeyfield(self, *args):
        layer = self.iface.activeLayer()
        self.checked_fields = []
        self.keyName = ''
        if layer and layer.type() == QgsMapLayerType.VectorLayer:
            # self.main.addKey 로 접근
            addKey_dlg = self.main.addKey
            ok_button = addKey_dlg.buttonBox.button(QDialogButtonBox.Ok)
            close_button = addKey_dlg.buttonBox.button(QDialogButtonBox.Close)
            model = addKey_dlg.mComboBox.model()
            checkBox = addKey_dlg.checkBox
            
            try:
                ok_button.clicked.disconnect(self.createKey)
                close_button.clicked.disconnect(addKey_dlg.close)
                model.itemChanged.disconnect(self.onItemChanged)
                checkBox.stateChanged.disconnect(self.chkBox)
            except TypeError:
                pass

            ok_button.clicked.connect(self.createKey)
            checkBox.stateChanged.connect(self.chkBox)
            close_button.clicked.connect(addKey_dlg.close)

            addKey_dlg.lineEdit.setText('')
            addKey_dlg.mFieldExpressionWidget.setExpression("")
            addKey_dlg.mFieldExpressionWidget.setLayer(layer)
            addKey_dlg.mComboBox.clear()
            for fld in layer.fields():
                addKey_dlg.mComboBox.addItem(fld.name())
            
            model = addKey_dlg.mComboBox.model()
            model.itemChanged.connect(self.onItemChanged)
            addKey_dlg.progressBar.setValue(0)
            addKey_dlg.show()

    def chkBox(self, *args):
        addKey_dlg = self.main.addKey
        if addKey_dlg.checkBox.isChecked():
            addKey_dlg.lineEdit.setEnabled(True)
        else:
            addKey_dlg.lineEdit.setEnabled(False)
            addKey_dlg.lineEdit.setText(self.keyName)

    def onItemChanged(self, item, *args):
        addKey_dlg = self.main.addKey
        field = item.text()
        if item.checkState() == Qt.Checked:
            if field not in self.checked_fields:
                self.checked_fields.append(field)
        else:
            if field in self.checked_fields:
                self.checked_fields.remove(field)
        
        parts = [f'"{f}"' for f in self.checked_fields]
        expr = " || '_' || ".join(parts) if parts else ""
        names = [f'{f[0]}' for f in self.checked_fields]
        name = "".join(names) if names else " "
        self.keyName = f'{name}_ID'
        if not addKey_dlg.checkBox.isChecked():
            addKey_dlg.lineEdit.setText(self.keyName)
        
        addKey_dlg.mFieldExpressionWidget.setExpression(expr)

    def createKey(self, *args):
        addKey_dlg = self.main.addKey
        layer = self.iface.activeLayer()
        if not layer or layer.type() != QgsMapLayerType.VectorLayer:
            return
        total = layer.featureCount()
        name = addKey_dlg.lineEdit.text()
        fname = "KeyField" if not name else name
        
        expr_str = addKey_dlg.mFieldExpressionWidget.expression()
        expr = QgsExpression(expr_str)
        ctx  = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

        if not layer.isEditable():
            layer.startEditing()

        if layer.providerType() == "postgres":
            field = QgsField(fname, QVariant.String, "varchar", 255)
        else:
            field = QgsField(fname, QVariant.String)

        dp = layer.dataProvider()
        dp.addAttributes([field])
        layer.updateFields()
        idx = layer.fields().indexFromName(fname)

        value_map = {}
        for i, feat in enumerate(layer.getFeatures()):
            ctx.setFeature(feat)
            val = expr.evaluate(ctx)
            if expr.hasEvalError():
                val = ""
            value_map[feat.id()] = { idx: val }
            addKey_dlg.progressBar.setValue(int(100 * (i + 1) / max(1, total)))
            
        dp.changeAttributeValues(value_map)
        layer.triggerRepaint()
        addKey_dlg.close()

    def folderOpen(self, *args):
        self.iface.messageBar().clearWidgets()
        # 활성화된 레이어 가져오기
        layer = self.iface.activeLayer()
        
        # 레이어가 없는 경우
        if not layer:
            return

        # 임시 레이어인지 확인
        if layer.isTemporary():
            self.iface.messageBar().pushMessage(f'임시 레이어는 경로를 열 수 없습니다.', level=Qgis.Warning, duration=5)
            return

        # 레이어의 소스 경로 가져오기
        layer_source = layer.source().split('|')[0]

        # 로컬 파일 경로가 아닌 경우
        if not os.path.isfile(layer_source):
            self.iface.messageBar().pushMessage(f'이 레이어는 로컬 파일이 아닙니다.', level=Qgis.Warning, duration=5)
            return

        # 탐색기에서 경로 열기
        folder_path = os.path.dirname(layer_source)
        os.startfile(folder_path)  # Windows에서 탐색기를 엽니다.

    def unload(self):
        """우클릭 메뉴에서 액션 제거"""
        try:
            self.iface.removeCustomActionForLayerType(self.duplicate_action)
            self.iface.removeCustomActionForLayerType(self.duplicateAll_action)
            self.iface.removeCustomActionForLayerType(self.layermerge)
            self.iface.removeCustomActionForLayerType(self.keyfield)
            self.iface.removeCustomActionForLayerType(self.folderPath)

        except Exception:
            pass