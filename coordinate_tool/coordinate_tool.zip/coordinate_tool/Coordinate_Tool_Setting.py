from qgis.PyQt import uic, QtWidgets

from qgis.core import Qgis,QgsCoordinateReferenceSystem

from PyQt5.QtCore import QSettings, Qt

from PyQt5.QtGui import QColor

from PyQt5.QtWidgets import QDialogButtonBox

from qgis.PyQt.QtWidgets import QMessageBox

from qgis.utils import (unloadPlugin, 
                        loadPlugin, 
                        startPlugin)
import os
import subprocess

from . import Coordinate_Tool_data

VERSION = Qgis.QGIS_VERSION_INT

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Setting.ui'))

class CoordinateToolSetting(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self,CTool,iface, parent=None):
        
        super(CoordinateToolSetting, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        # self.QSettings = QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chkk = 0
        self.Plugin='coordinate_tool'

        # pyautogui 추가시 해당 함수 진행
        self.add_pipModule_pushButton.clicked.connect(self.addpipModule)

        self.del_pipModule_pushButton.clicked.connect(self.delpipModule)

        # api key 초기화
        # self.Key_Reset_pushButton.clicked.connect(self.apikeyey_Reset)
        
        # 좌표계 설정 저장
        self.button_box.button(QDialogButtonBox.Save).clicked.connect(self.save)
        # 좌표계 수정시 해당 함수 진행
        self.mQgsProjectionSelectionWidget.crsChanged.connect(self.setEnabled)
        self.mQgsProjectionSelectionWidget_2.crsChanged.connect(self.setEnabled1)
        self.mQgsProjectionSelectionWidget_3.crsChanged.connect(self.setEnabled2)
        self.mQgsProjectionSelectionWidget_4.crsChanged.connect(self.setEnabled3)
        self.mQgsProjectionSelectionWidget_5.crsChanged.connect(self.setEnabled4)
        # 외부맵 링크 추가시 해당 함수 진행
        self.addProviderButton.clicked.connect(self.addUserProvider)
        # 외부맵 링크 삭제시 해당 함수 진행
        self.deleteProviderButton.clicked.connect(self.deleteUserProvider)
        
        self.mapProviderComboBox.currentIndexChanged.connect(lambda : self.mapComboBox(self.mapProviderComboBox,self.label_2, self.checkBox_placemark_1))
        self.mapProviderRComboBox.currentIndexChanged.connect(lambda : self.mapComboBox(self.mapProviderRComboBox,self.label_3, self.checkBox_placemark_2))
        
        self.checkBox_placemark_1.stateChanged.connect(lambda : self.mapComboBox(self.mapProviderComboBox,self.label_2, self.checkBox_placemark_1))
        self.checkBox_placemark_2.stateChanged.connect(lambda : self.mapComboBox(self.mapProviderRComboBox,self.label_3, self.checkBox_placemark_2))
        # 외부맵 링크 목록 수정시 해당 함수 진행
        self.userMapProviderComboBox.currentIndexChanged.connect(self.userMapComboBox)
        # 설정창 언어 변경시 해당 함수 진행
        # self.Language_comboBox.currentIndexChanged.connect(self.Language)

        # 외부맵 링크 목록이 없다면 리스트 재설정
        self.userMapProviders = self.QSettings.value('UserMapProviders', 0)
        if not isinstance(self.userMapProviders, list):
            self.userMapProviders = []

        self.checkBox_MMS_1.stateChanged.connect(self.checkBoxMMS1)
        self.checkBox_MMS_2.stateChanged.connect(self.checkBoxMMS2)
        
        self.checkBox_Fs_1.stateChanged.connect(self.checkBoxFs1)
        self.checkBox_Fs_2.stateChanged.connect(self.checkBoxFs2)
        # 마크컬러 설정
        
        self.setting()
    
    def closeEvent(self,e):
        self.CTool.set.setChecked(False)
        
    def showEvent(self,e):
        self.CTool.set.setChecked(True)
        
    def setting(self):
        # 플러그인 인증키
        # self.lineEdit_pluginKey.setText(self.QSettings.value('lineEdit_pluginKey', ''))

        # 복사 좌표계
        self.mQgsProjectionSelectionWidget.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project1','USER:100000')))
        self.mQgsProjectionSelectionWidget_2.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project2','USER:100001')))
        self.coordOrderComboBox.setCurrentIndex(int(self.QSettings.value('ComboBox1', 0)))
        self.coordOrderComboBox_2.setCurrentIndex(int(self.QSettings.value('ComboBox2', 0)))
        self.checkBox_Fs_1.setCheckState(int(self.QSettings.value('checkBox_Fs_1', Qt.Checked))) #Qt.Unchecked
        self.checkBox_MMS_1.setCheckState(int(self.QSettings.value('checkBox_MMS_1', Qt.Unchecked))) #Qt.Unchecked
        self.checkBox_Fs_2.setCheckState(int(self.QSettings.value('checkBox_Fs_2', Qt.Checked))) #Qt.Unchecked
        self.checkBox_MMS_2.setCheckState(int(self.QSettings.value('checkBox_MMS_2', Qt.Unchecked))) #Qt.Unchecked
        self.coconut_ComboBox.setCurrentIndex(int(self.QSettings.value('coconut_ComboBox', 0)))

        # 이동 좌표계
        self.mQgsProjectionSelectionWidget_3.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project3','USER:100000')))
        self.mQgsProjectionSelectionWidget_4.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project4','USER:100001')))
        self.mQgsProjectionSelectionWidget_5.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project5','USER:100001')))
        self.coordOrderComboBox_3.setCurrentIndex(int(self.QSettings.value('ComboBox3', 0)))
        self.coordOrderComboBox_4.setCurrentIndex(int(self.QSettings.value('ComboBox4', 0)))
        self.coordOrderComboBox_5.setCurrentIndex(int(self.QSettings.value('ComboBox5', 0)))
        self.GridcheckBox.setCheckState(int(self.QSettings.value('GridcheckBox', Qt.Checked))) #Qt.Unchecked
        
        # 웹지도 설정
        self.mapProviderComboBox.setCurrentIndex(int(self.QSettings.value('MapProvider', 0)))
        self.label_2.setText(self.QSettings.value('label_2', ''))
        self.mapProviderRComboBox.setCurrentIndex(int(self.QSettings.value('MapProviderRight', 0)))
        self.label_3.setText(self.QSettings.value('label_3', ''))
        self.mapProvider = int(self.QSettings.value('MapProvider', 0))
        self.mapProviderRight = int(self.QSettings.value('MapProviderRight', 0))
        self.checkBox_placemark_1.setCheckState(int(self.QSettings.value('checkBox_placemark_1', Qt.Checked)))
        self.checkBox_placemark_2.setCheckState(int(self.QSettings.value('checkBox_placemark_2', Qt.Checked)))
        # 지도 확대 값
        self.zoomSpinBox_1.setValue(int(self.QSettings.value('zoomSpinBox_1', 16)))
        self.zoomSpinBox_2.setValue(int(self.QSettings.value('zoomSpinBox_2', 16)))
        # 추가 웹지도 URL
        self.userMapProviderComboBox.setCurrentIndex(int(self.QSettings.value('userMapProvider', 0)))

        # 주소검색
        self.AddressSearchComboBox.setCurrentIndex(int(self.QSettings.value('AddressSearchComboBox', 0)))
        self.addressMsgBox.setCheckState(int(self.QSettings.value('addressMsgBox', Qt.Checked))) #Qt.Unchecked
    
        # 외부맵 리스트 리셋
        names = []
        for item in self.userMapProviders:
            names.append(item[0])
        self.userMapProviderComboBox.clear()
        self.userMapProviderComboBox.addItems(names)
        self.updateMapProviderComboBoxes()

        self.userProviderNameLineEdit.clear()
        self.userProviderUrlLineEdit.clear()
        # self.userProviderUrlLineEdit_2.clear();
        
        # 마크컬러 설정
        self.mkColorButton_0 = QColor(self.QSettings.value('markerColorButton_0', '#ff0000'))
        self.mkColorButton_0.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_0', 255)))
        self.markerColorButton_0.setColor(self.mkColorButton_0)
        
        self.mkColorButton_1 = QColor(self.QSettings.value('markerColorButton_1', '#ff0000'))
        self.mkColorButton_1.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_1', 255)))
        self.markerColorButton_1.setColor(self.mkColorButton_1)
        
        self.mkColorButton_2 = QColor(self.QSettings.value('markerColorButton_2', '#ff0000'))
        self.mkColorButton_2.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_2', 255)))
        self.markerColorButton_2.setColor(self.mkColorButton_2)
        
        self.mkColorButton_3 = QColor(self.QSettings.value('markerColorButton_3', '#ff0000'))
        self.mkColorButton_3.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_3', 255)))
        self.markerColorButton_3.setColor(self.mkColorButton_3)
        
        self.mkColorButton_4 = QColor(self.QSettings.value('markerColorButton_3', '#ff0000'))
        self.mkColorButton_4.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_4', 255)))
        self.markerColorButton_3.setColor(self.mkColorButton_4)
        
        self.GColorButton_1 = QColor(self.QSettings.value('GridColorButton_1', '#ff00ff'))
        self.GColorButton_1.setAlpha(int(self.QSettings.value('GridColorButtonOpacity_1', 255)))
        self.GridColorButton_1.setColor(self.GColorButton_1)


        
# 설정값 저장=================================================================================================================================================================
    def save(self):
        # 좌표 복사 설정
        self.QSettings.setValue('Project1', self.mQgsProjectionSelectionWidget.crs().authid())
        self.QSettings.setValue('Project2', self.mQgsProjectionSelectionWidget_2.crs().authid())
        self.QSettings.setValue('checkBox_Fs_1', self.checkBox_Fs_1.checkState())
        self.QSettings.setValue('checkBox_MMS_1', self.checkBox_MMS_1.checkState())
        self.QSettings.setValue('checkBox_Fs_2', self.checkBox_Fs_2.checkState())
        self.QSettings.setValue('checkBox_MMS_2', self.checkBox_MMS_2.checkState())
        self.QSettings.setValue('ComboBox1', int(self.coordOrderComboBox.currentIndex()))
        self.QSettings.setValue('ComboBox2', int(self.coordOrderComboBox_2.currentIndex()))
        self.QSettings.setValue('markerColorButton_0',self.markerColorButton_0.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_0', self.markerColorButton_0.color().alpha())
        self.QSettings.setValue('markerColorButton_1',self.markerColorButton_1.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_1', self.markerColorButton_1.color().alpha())
        self.QSettings.setValue('coconut_ComboBox', int(self.coconut_ComboBox.currentIndex()))

        # 좌표 이동 설정
        self.QSettings.setValue('Project3', self.mQgsProjectionSelectionWidget_3.crs().authid())
        self.QSettings.setValue('Project4', self.mQgsProjectionSelectionWidget_4.crs().authid())
        self.QSettings.setValue('Project5', self.mQgsProjectionSelectionWidget_5.crs().authid())
        self.QSettings.setValue('ComboBox3', int(self.coordOrderComboBox_3.currentIndex()))
        self.QSettings.setValue('ComboBox4', int(self.coordOrderComboBox_4.currentIndex()))
        self.QSettings.setValue('ComboBox5', int(self.coordOrderComboBox_5.currentIndex()))
        self.QSettings.setValue('GridColorButton_1',self.GridColorButton_1.color().name())
        self.QSettings.setValue('GridColorButtonOpacity_1',self.GridColorButton_1.color().alpha())
        self.QSettings.setValue('GridcheckBox', self.GridcheckBox.checkState())
        # 웹지도 설정
        self.QSettings.setValue('MapProvider', int(self.mapProviderComboBox.currentIndex()))
        self.QSettings.setValue('label_2',self.label_2.text())
        self.QSettings.setValue('MapProviderRight', int(self.mapProviderRComboBox.currentIndex()))
        self.QSettings.setValue('label_3',self.label_3.text())
        self.QSettings.setValue('checkBox_placemark_1', self.checkBox_placemark_1.checkState())
        self.QSettings.setValue('checkBox_placemark_2', self.checkBox_placemark_2.checkState())
        self.QSettings.setValue('zoomSpinBox_1', int(self.zoomSpinBox_1.value()))
        self.QSettings.setValue('zoomSpinBox_2', int(self.zoomSpinBox_2.value()))
        self.QSettings.setValue('markerColorButton_2',self.markerColorButton_2.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_2', self.markerColorButton_2.color().alpha())
        self.QSettings.setValue('markerColorButton_3',self.markerColorButton_3.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_3', self.markerColorButton_3.color().alpha())

        # 주소 설정
        self.QSettings.setValue('AddressSearchComboBox', int(self.AddressSearchComboBox.currentIndex()))
        self.QSettings.setValue('addressMsgBox', self.addressMsgBox.checkState())
        self.QSettings.setValue('markerColorButton_4',self.markerColorButton_4.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_4', self.markerColorButton_4.color().alpha())
        
        # 인증키 값 설정(API키 복호화 암호)
        if self.lineEdit_pluginKey.text() != '':
            self.QSettings.setValue('lineEdit_pluginKey', self.lineEdit_pluginKey.text())
        self.lineEdit_pluginKey.setText('')
        
        # 마크컬러 설정
        self.mkColorButton_0 = QColor(self.QSettings.value('markerColorButton_0', '#ff0000'))
        self.mkColorButton_0.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_0', 255)))
        
        self.mkColorButton_1 = QColor(self.QSettings.value('markerColorButton_1', '#ff0000'))
        self.mkColorButton_1.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_1', 255)))

        self.mkColorButton_2 = QColor(self.QSettings.value('markerColorButton_2', '#ff0000'))
        self.mkColorButton_2.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_2', 255)))

        self.mkColorButton_3 = QColor(self.QSettings.value('markerColorButton_3', '#ff0000'))
        self.mkColorButton_3.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_3', 255)))
        
        self.mkColorButton_4 = QColor(self.QSettings.value('markerColorButton_4', '#ff0000'))
        self.mkColorButton_4.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_4', 255)))
        
        self.GColorButton_1 = QColor(self.QSettings.value('GridColorButton_1', '#ff00ff'))
        self.GColorButton_1.setAlpha(int(self.QSettings.value('GridColorButtonOpacity_1', 255)))
        
        self.close()
        
    # 외부맵 추가시 해당 함수 실행
    def addUserProvider(self):
        name = self.userProviderNameLineEdit.text().strip()
        url = self.userProviderUrlLineEdit.text().strip()
        if name and url:
            self.userMapProviders.append([name, url])
            if self.userMapProviders:
                self.QSettings.setValue('UserMapProviders', self.userMapProviders)
            else:
                self.QSettings.setValue('UserMapProviders', 0)
            names = []
            for item in self.userMapProviders:
                names.append(item[0])
            self.userMapProviderComboBox.clear()
            self.userProviderNameLineEdit.clear()
            self.userProviderUrlLineEdit.clear()
            self.userMapProviderComboBox.addItems(names)
            self.updateMapProviderComboBoxes()
    # 외부맵 삭제시 해당 함수 실행  
    def deleteUserProvider(self):
        if self.userMapProviderComboBox.count() > 0:
            index = self.userMapProviderComboBox.currentIndex()
            if index >= 0:
                del self.userMapProviders[index]
            if self.userMapProviders:
                self.QSettings.setValue('UserMapProviders', self.userMapProviders)
            else:
                self.QSettings.setValue('UserMapProviders', 0)
            names = []
            for item in self.userMapProviders:
                names.append(item[0])
            self.userMapProviderComboBox.clear()
            # self.userProviderNameLineEdit.clear()
            # self.userProviderUrlLineEdit.clear()
            self.userProviderUrlLineEdit_2.clear()
            self.userMapProviderComboBox.addItems(names)
            # Since we deleted an entry just reset the selected map to
            # be the first one - Open Street Map
            # self.mapProvider = 0
            # self.mapProviderRight = 0
            self.updateMapProviderComboBoxes()
    # 외부맵 추가,삭제 후 외부맵 리스트 재정렬  
    def updateMapProviderComboBoxes(self):
            # Update the selected map provider lists
            curindex = self.mapProvider
            self.mapProviderComboBox.clear()
            self.mapProviderComboBox.addItems(self.mapProviderNames())
            if curindex >= len(self.mapProviderNames()):
                curindex = 0
            self.mapProviderComboBox.setCurrentIndex(curindex)

            curindex = self.mapProviderRight
            self.mapProviderRComboBox.clear()
            self.mapProviderRComboBox.addItems(self.mapProviderNames())
            if curindex >= len(self.mapProviderNames()):
                curindex = 0
            self.mapProviderRComboBox.setCurrentIndex(curindex)
    # 기본 외부맵 리스트
    def mapProviderNames(self):
        plist = []
        for x in Coordinate_Tool_data.MAP_PROVIDERS:
            plist.append(x[0])
        # plist.append('Google Earth (If Installed)')
        for entry in self.userMapProviders:
            plist.append(entry[0])
        return plist
    
    def checkBoxMMS1(self):
        if self.chkk == 0:
            if self.checkBox_MMS_1.isChecked():
                self.coordOrderComboBox.setCurrentIndex(0)
                self.coordOrderComboBox.setEnabled(False)
                self.checkBox_Fs_1.setChecked(False)
            else:
                self.checkBox_Fs_1.setChecked(True)
        
    def checkBoxMMS2(self):
        if self.chkk == 0:
            if self.checkBox_MMS_2.isChecked():
                self.coordOrderComboBox_2.setCurrentIndex(0)
                self.coordOrderComboBox_2.setEnabled(False)
                self.checkBox_Fs_2.setChecked(False)
            else:
                self.checkBox_Fs_2.setChecked(True)
                
    def checkBoxFs1(self):
        if self.chkk == 0:
            if self.checkBox_Fs_1.isChecked():
                self.coordOrderComboBox.setCurrentIndex(0)
                self.coordOrderComboBox.setEnabled(False)
                self.checkBox_MMS_1.setChecked(False)
            else:
                self.checkBox_MMS_1.setChecked(True)
            
    def checkBoxFs2(self):
        if self.chkk == 0:
            if self.checkBox_Fs_2.isChecked():
                self.checkBox_MMS_2.setChecked(False)
                self.coordOrderComboBox_2.setCurrentIndex(0)
                self.coordOrderComboBox_2.setEnabled(False)
            else:
                self.checkBox_MMS_2.setChecked(True)

# 복사 좌표계 수정시 해당 함수 실행=================================================================================================================================================================   
    # 좌클릭 복사 좌표계
    def setEnabled(self):
        crs=int(self.mQgsProjectionSelectionWidget.crs().authid().split(':')[1])
        self.chkk=1
        if int(crs)<int(100000):
            self.coordOrderComboBox.setEnabled(True)
            self.checkBox_Fs_1.setChecked(False)
            self.checkBox_MMS_1.setChecked(False)
            self.checkBox_Fs_1.setEnabled(False)
            self.checkBox_MMS_1.setEnabled(False)
        else:
            self.coordOrderComboBox.setEnabled(False)
            self.coordOrderComboBox.setCurrentIndex(0)
            self.checkBox_Fs_1.setEnabled(True)
            self.checkBox_MMS_1.setEnabled(True)
            self.checkBox_Fs_1.setChecked(True)
        self.chkk=0
    # 우클릭 복사 좌표계
    def setEnabled1(self):
        self.chkk=1
        crs=int(self.mQgsProjectionSelectionWidget_2.crs().authid().split(':')[1])
        if int(crs)<int(100000):
            self.coordOrderComboBox_2.setEnabled(True)
            self.checkBox_Fs_2.setChecked(False)
            self.checkBox_MMS_2.setChecked(False)
            self.checkBox_Fs_2.setEnabled(False)
            self.checkBox_MMS_2.setEnabled(False)
        else:
            self.coordOrderComboBox_2.setEnabled(False)
            self.coordOrderComboBox_2.setCurrentIndex(0)
            self.checkBox_Fs_2.setEnabled(True)
            self.checkBox_MMS_2.setEnabled(True)
            self.checkBox_Fs_2.setChecked(True)
        self.chkk=0
# 이동 좌표계 수정시 해당 함수 실행=================================================================================================================================================================   
    # 이동1 좌표계
    def setEnabled2(self):
        crs=int(self.mQgsProjectionSelectionWidget_3.crs().authid().split(':')[1])
        self.coordOrderComboBox_3.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_3.setCurrentIndex(0)
    # 이동2 좌표계
    def setEnabled3(self):
        crs=int(self.mQgsProjectionSelectionWidget_4.crs().authid().split(':')[1])
        self.coordOrderComboBox_4.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_4.setCurrentIndex(0)
    # 이동3 좌표계
    def setEnabled4(self):
        crs=int(self.mQgsProjectionSelectionWidget_5.crs().authid().split(':')[1])
        self.coordOrderComboBox_5.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_5.setCurrentIndex(0)
        
    def mapComboBox(self,objact,label,checkBox):
        map = int(objact.currentIndex())
        if checkBox.isChecked():
            ms = Coordinate_Tool_data.MAP_PROVIDERS[map][2]
        else:
            ms = Coordinate_Tool_data.MAP_PROVIDERS[map][1]
        label.setText(ms)
        
    # def checkBoxplacemark(self,objact,label,checkBox):
    #     map = int(objact.currentIndex())
    #     if checkBox.isChecked():
    #         ms = Coordinate_Tool_data.MAP_PROVIDERS[map][2]
    #     else:
    #         ms = Coordinate_Tool_data.MAP_PROVIDERS[map][1]
    #     label.setText(ms)
        
    # 추가 외부맵 콤보박스 수정시 
    def userMapComboBox(self):
        idx=int(self.userMapProviderComboBox.currentIndex())
        if idx >= 0:
            self.userProviderUrlLineEdit_2.setText(str(self.userMapProviders[idx][1]))
    def delpipModule(self):
        try:
            # pip 삭제 콜
            subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pyautogui','-y'])
            # self.QSettings.setValue('pyautogui_'+str(VERSION), 0)
            subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pyperclip','-y'])
            # self.QSettings.setValue('pyperclip_'+str(VERSION), 0)
            subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'polyline','-y'])
            # self.QSettings.setValue('polyline_'+str(VERSION), 0)
            subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pycryptodome ','-y'])
            # self.QSettings.setValue('pycryptodome _'+str(VERSION), 0)

            unloadPlugin(self.Plugin)
            loadPlugin(self.Plugin)
            startPlugin(self.Plugin)
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "모듈 삭제 실패 관리자에게 문의 바람")

    def addpipModule(self):
        try:
            # pip 설치 콜
            subprocess.check_call(['python', '-m', 'pip', 'install', 'pyautogui'])
            # self.QSettings.setValue('pyautogui_'+str(VERSION), 1)
            subprocess.check_call(['python', '-m', 'pip', 'install', 'pyperclip'])
            # self.QSettings.setValue('pyperclip_'+str(VERSION), 1)
            subprocess.check_call(['python','-m', 'pip', 'install', 'polyline'])
            # self.QSettings.setValue('polyline_'+str(VERSION), 1)
            subprocess.check_call(['python','-m', 'pip', 'install', 'pycryptodome'])
            # self.QSettings.setValue('pycryptodome_'+str(VERSION), 1)
            
            unloadPlugin(self.Plugin)
            loadPlugin(self.Plugin)
            startPlugin(self.Plugin)
        except:
            QMessageBox.critical(self.iface.mainWindow(), "Error", "모듈 설치 실패 관리자에게 문의 바람")


