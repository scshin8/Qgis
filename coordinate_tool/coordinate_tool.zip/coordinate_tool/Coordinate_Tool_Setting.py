from qgis.PyQt import uic, QtWidgets

from qgis.core import Qgis,QgsCoordinateReferenceSystem, QgsProject, QgsSettings

from PyQt5.QtCore import QSettings, Qt, QCoreApplication

from PyQt5.QtGui import QColor

from PyQt5.QtWidgets import QDialogButtonBox

from qgis.PyQt.QtWidgets import QMessageBox

from qgis.utils import (unloadPlugin, 
                        loadPlugin, 
                        startPlugin)

import os, subprocess, shutil, requests, zipfile, sys
from datetime import datetime

from . import Coordinate_Tool_data

VERSION = Qgis.QGIS_VERSION_INT

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Setting.ui'))

class CoordinateToolSetting(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self,CTool,iface, parent=None):
        
        super(CoordinateToolSetting, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        # self.QSettings = QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.chkk = 0
        self.Plugin='coordinate_tool'

        # pip 추가시 해당 함수 진행
        # self.add_pipModule_pushButton.clicked.connect(self.addpipModule)
        # self.del_pipModule_pushButton.clicked.connect(self.delpipModule)

        # api key 초기화
        # self.Key_Reset_pushButton.clicked.connect(self.apikeyey_Reset)
        
        # 좌표계 설정 저장
        self.button_box.button(QDialogButtonBox.Save).clicked.connect(self.save)
        # 좌표계 수정시 해당 함수 진행
        self.mQgsProjectionSelectionWidget.crsChanged.connect(self.setEnabled)
        self.mQgsProjectionSelectionWidget_2.crsChanged.connect(self.setEnabled1)
        self.mQgsProjectionSelectionWidget_3.crsChanged.connect(self.setEnabled2)
        self.mQgsProjectionSelectionWidget_4.crsChanged.connect(self.setEnabled3)
        self.mQgsProjectionSelectionWidget_5.crsChanged.connect(self.setEnabled4)
        # 외부맵 링크 추가시 해당 함수 진행
        self.addProviderButton.clicked.connect(self.addUserProvider)
        # 외부맵 링크 삭제시 해당 함수 진행
        self.deleteProviderButton.clicked.connect(self.deleteUserProvider)
        
        self.mapProviderComboBox.currentIndexChanged.connect(lambda : self.mapComboBox(self.mapProviderComboBox,self.label_2, self.checkBox_placemark_1))
        self.mapProviderRComboBox.currentIndexChanged.connect(lambda : self.mapComboBox(self.mapProviderRComboBox,self.label_3, self.checkBox_placemark_2))
        
        self.checkBox_placemark_1.stateChanged.connect(lambda : self.mapComboBox(self.mapProviderComboBox,self.label_2, self.checkBox_placemark_1))
        self.checkBox_placemark_2.stateChanged.connect(lambda : self.mapComboBox(self.mapProviderRComboBox,self.label_3, self.checkBox_placemark_2))
        # 외부맵 링크 목록 수정시 해당 함수 진행
        self.userMapProviderComboBox.currentIndexChanged.connect(self.userMapComboBox)
        # 설정창 언어 변경시 해당 함수 진행
        # self.Language_comboBox.currentIndexChanged.connect(self.Language)

        # 외부맵 링크 목록이 없다면 리스트 재설정
        self.userMapProviders = self.QSettings.value('UserMapProviders', 0)
        if not isinstance(self.userMapProviders, list):
            self.userMapProviders = []

        self.checkBox_MMS_1.stateChanged.connect(self.checkBoxMMS1)
        self.checkBox_MMS_2.stateChanged.connect(self.checkBoxMMS2)
        
        self.checkBox_Fs_1.stateChanged.connect(self.checkBoxFs1)
        self.checkBox_Fs_2.stateChanged.connect(self.checkBoxFs2)

        self.background_checkBox.stateChanged.connect(self.background)

        self.background_checkBox_2.stateChanged.connect(self.background)

        self.add_xyzTiles_pushButton.clicked.connect(self.addxyzTiles)
        self.set_pushButton.clicked.connect(self.setting1)

        # 마크컬러 설정
        self.setting()

    def setting1(self):
        val = QMessageBox.question(None,
                                'QGIS 설정 초기화',
                                '사용자 정의 좌표계와 단축키 및 QGIS 설정이 초기화됩니다.\n\n계속하시겠습니까?',
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)

        if val == QMessageBox.Yes:

            # 초기화 파일 셋팅
            current_directory = os.path.abspath(os.path.join(__file__, "../../../.."))
            resetFile_dir = current_directory

            backupFile_url = 'https://scshin8.github.io/Qgis/coordinate_tool/resetFile.zip'

            # 저장경로지정
            destination_path = os.path.join(resetFile_dir, 'resetFile.zip')

            # 파일 다운로드
            response = requests.get(backupFile_url, verify=False)

            with open(destination_path, 'wb') as file:
                file.write(response.content)

            # 추출할 디렉토리로 압축 해제
            with zipfile.ZipFile(destination_path, 'r') as zip_ref:

                target_path = os.path.join(resetFile_dir, "Open Sans")
                if os.path.exists(target_path):
                    if os.path.isfile(target_path):
                        os.remove(target_path)
                    elif os.path.isdir(target_path):
                        shutil.rmtree(target_path)

                zip_ref.extractall(resetFile_dir)
                
            # 압축파일 삭제
            if os.path.exists(destination_path):  # 파일이 존재하는지 확인합니다.
                os.remove(destination_path)  # 파일을 삭제합니다.
            dtNow = datetime.now()
            self.QSettings.setValue('resetDate', dtNow)

            # QGIS3_file = os.path.join(current_directory, 'resetFile', 'QGIS3.ini')
            # output_file = os.path.join(current_directory, 'QGIS', 'QGIS3.ini')
            # shutil.copy(QGIS3_file, output_file)
            # qgis_file = os.path.join(current_directory, 'resetFile', 'qgis.db')
            # output_file = os.path.join(current_directory, 'qgis.db')
            # shutil.copy(qgis_file, output_file)

            QMessageBox.information(self.iface.mainWindow(), 'QGIS 설정 초기화' , '사용자 정의 좌표계와 단축키 및 QGIS 설정을 초기화 하였습니다.\n\nQGIS를 재실행 합니다.')
            # QGIS 강제 재실행
            qgis_executable = sys.executable  # 현재 실행 중인 파이썬 인터프리터의 경로 (QGIS 실행 파일)
            subprocess.Popen(qgis_executable)  # 새로운 QGIS 인스턴스 실행
            QCoreApplication.quit()  # 현재 QGIS 인스턴스 종료

    def addxyzTiles(self):
        # 'connections-xyz' 아래에 저장된 모든 키 가져오기
        all_keys = QSettings().allKeys()
        Settings = QSettings()
        for key in all_keys:
            # 기존 타일맵 삭제
            if key.startswith("qgis/connections-xyz/") and key.endswith("/url"):
                print(key)
                print(Settings.value(key))
                # 연결 이름 추출
                connection_name = key.split('/')[2]
                if 'Play' in connection_name or 'Routo ' in connection_name or 'VWorld' in connection_name:
                    QgsSettings().remove("qgis/%s/%s" % ("connections-xyz", connection_name))

        # Update GUI
        self.iface.reloadConnections()

        # Sources
        sources = []
        sources.append(["connections-xyz","Google Maps","","","","https://mt1.google.com/vt/lyrs=m&hl=ko&x={x}&y={y}&z={z}","","19","0","0"])
        sources.append(["connections-xyz","Google Satellite", "", "", "", "https://mt1.google.com/vt/lyrs=s&hl=ko&x={x}&y={y}&z={z}", "", "19", "0","0"])
        # sources.append(["connections-xyz","Google Terrain", "", "", "", "https://mt1.google.com/vt/lyrs=t&x={x}&y={y}&z={z}", "", "19", "0"])
        sources.append(["connections-xyz","Google Hybrid", "", "", "", "https://mt1.google.com/vt/lyrs=y&hl=ko&x={x}&y={y}&z={z}", "", "19", "0","0"])

        # sources.append(["connections-xyz","Google Satellite Hybrid", "", "", "", "https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}", "", "19", "0"])
        # sources.append(["connections-xyz","Esri Boundaries Places", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", "", "20", "0"])
        # sources.append(["connections-xyz","Esri Gray (dark)", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}", "", "16", "0"])
        # sources.append(["connections-xyz","Esri Gray (light)", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}", "", "16", "0"])
        # sources.append(["connections-xyz","Esri Hillshade", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}", "", "12", "0"])
        # sources.append(["connections-xyz","Esri National Geographic", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}", "", "12", "0"])
        # sources.append(["connections-xyz","Esri Navigation Charts", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/Specialty/World_Navigation_Charts/MapServer/tile/{z}/{y}/{x}", "", "12", "0"])
        # sources.append(["connections-xyz","Esri Ocean", "", "", "Requires ArcGIS Onlinesubscription", "https://services.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}", "", "10", "0"])
        # sources.append(["connections-xyz","Esri Physical Map", "", "", "Requires ArcGIS Onlinesubscription", "https://services.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/{z}/{y}/{x}", "", "10", "0"])
        # sources.append(["connections-xyz","Esri Satellite", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", "", "17", "0"])
        # sources.append(["connections-xyz","Esri Shaded Relief", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer/tile/{z}/{y}/{x}", "", "17", "0"])
        # sources.append(["connections-xyz","Esri Standard", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", "", "17", "0"])
        # sources.append(["connections-xyz","Esri Terrain", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}", "", "13", "0"])
        # sources.append(["connections-xyz","Esri Transportation", "", "", "Requires ArcGIS Onlinesubscription", "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}", "", "20", "0"])
        # sources.append(["connections-xyz","Esri Topo World", "", "", "Requires ArcGIS Onlinesubscription", "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", "", "20", "0"])
        # sources.append(["connections-xyz","OpenStreetMap Standard", "", "", "OpenStreetMap contributors, under ODbL", "http://tile.openstreetmap.org/{z}/{x}/{y}.png", "", "19", "0"])
        # sources.append(["connections-xyz","OpenStreetMap H.O.T.", "", "", "OpenStreetMap contributors, under ODbL", "http://tile.openstreetmap.fr/hot/%7Bz%7D/%7Bx%7D/%7By%7D.png", "", "19", "0"])
        # sources.append(["connections-xyz","OpenTopoMap", "", "", "Kartendaten: © OpenStreetMap-Mitwirkende, SRTM | Kartendarstellung: © OpenTopoMap (CC-BY-SA)", "https://tile.opentopomap.org/{z}/{x}/{y}.png", "", "17", "1"])
        # sources.append(["connections-xyz","Strava All", "", "", "OpenStreetMap contributors, under ODbL", "https://heatmap-external-b.strava.com/tiles/all/bluered/{z}/{x}/{y}.png", "", "15", "0"])
        # sources.append(["connections-xyz","Strava Run", "", "", "OpenStreetMap contributors, under ODbL", "https://heatmap-external-b.strava.com/tiles/run/bluered/{z}/{x}/{y}.png?v=19", "", "15", "0"])
        # sources.append(["connections-xyz","CartoDb Dark Matter", "", "", "Map tiles by CartoDB, under CC BY 3.0. Data by OpenStreetMap, under ODbL.", "http://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png", "", "20", "0"])
        # sources.append(["connections-xyz","CartoDb Dark Matter (No Labels)", "", "", "Map tiles by CartoDB, under CC BY 3.0. Data by OpenStreetMap, under ODbL.", "http://basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png", "", "20", "0"])
        # sources.append(["connections-xyz","CartoDb Positron", "", "", "Map tiles by CartoDB, under CC BY 3.0. Data by OpenStreetMap, under ODbL.", "http://basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png", "", "20", "0"])
        # sources.append(["connections-xyz","CartoDb Positron (No Labels)", "", "", "Map tiles by CartoDB, under CC BY 3.0. Data by OpenStreetMap, under ODbL.", "http://basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png", "", "20", "0"])
        # sources.append(["connections-xyz","Bing VirtualEarth", "", "", "", "http://ecn.t3.tiles.virtualearth.net/tiles/a{q}.jpeg?g=1", "", "19", "1"])
        # sources.append(["connections-xyz","Mapzen Global Terrain", "", "", "", "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png", "", "15", "0"])
        
        # https://tile.routo.com/v1/sdk/style/basic
        # https://tile.routo.com/v1/sdk/style/black
        sources.append(["connections-xyz","Routomap Basic", "", "", "", "https://tiles.routo.com/tile/roadmap_image_basic/v1/{z}/{x}/{y}.webp", "", "19", "0", "0"])
        sources.append(["connections-xyz","Routomap Black", "", "", "", "https://d38u66kunyqk40.cloudfront.net/webgis_tile01/Tile/BLACK/v2/{z}/{x}/{y}.png", "", "19", "0", "0"])
        sources.append(["connections-xyz","Routomap Black", "", "", "", "https://d38u66kunyqk40.cloudfront.net/webgis_tile01/Tile/BLACK/v2/{z}/{x}/{y}.png", "", "19", "0", "0"])
        sources.append(["connections-xyz","Routomap Satellite", "", "", "", "https://d38u66kunyqk40.cloudfront.net/webgis_tile01/Tile/SKY/v4/{z}/{x}/{y}.jpeg", "", "19", "0", "0"])
        
        # 루토맵 구버전 #
        # sources.append(["connections-xyz","Routomap Basic", "", "", "", "https://d38u66kunyqk40.cloudfront.net/webgis_tile01/TileNew/Milk/v2/{z}/{x}/{y}.webp", "", "19", "0"])
        
        # Vworld 타일맵 #
        sources.append(["connections-xyz","VWorld Hybrid", "", "", "", "https://xdworld.vworld.kr/2d/Hybrid/service/{z}/{x}/{y}.png", "", "19", "0", "0"])
        sources.append(["connections-xyz","VWorld Base", "", "", "", "https://xdworld.vworld.kr/2d/Base/service/{z}/{x}/{y}.png", "", "19", "0", "0"])
        sources.append(["connections-xyz","VWorld Satellite", "", "", "", "https://xdworld.vworld.kr/2d/Satellite/service/{z}/{x}/{y}.jpeg", "", "19", "0", "0"])
        
        # Add sources to browser
        for source in sources:
            connectionType = source[0]
            connectionName = source[1]
            QSettings().setValue("qgis/%s/%s/authcfg" % (connectionType, connectionName), source[2])
            QSettings().setValue("qgis/%s/%s/password" % (connectionType, connectionName), source[3])
            QSettings().setValue("qgis/%s/%s/referer" % (connectionType, connectionName), source[4])
            QSettings().setValue("qgis/%s/%s/url" % (connectionType, connectionName), source[5])
            QSettings().setValue("qgis/%s/%s/username" % (connectionType, connectionName), source[6])
            QSettings().setValue("qgis/%s/%s/zmax" % (connectionType, connectionName), source[7])
            QSettings().setValue("qgis/%s/%s/zmin" % (connectionType, connectionName), source[8])
            QSettings().setValue("qgis/%s/%s/tilePixelRatio" % (connectionType, connectionName), source[9])

        # Update GUI
        self.iface.reloadConnections()

        QMessageBox.information(self.iface.mainWindow(), '타일맵 추가' , '타일맵이 추가 되었습니다.')

    def closeEvent(self,e):
        self.CTool.set.setChecked(False)
        
    def showEvent(self,e):
        self.CTool.set.setChecked(True)
        
    def setting(self):
        # 플러그인 인증키
        # self.lineEdit_pluginKey.setText(self.QSettings.value('lineEdit_pluginKey', ''))

        # 복사 좌표계
        self.mQgsProjectionSelectionWidget.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project1','USER:100000')))
        self.mQgsProjectionSelectionWidget_2.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project2','USER:100001')))
        self.coordOrderComboBox.setCurrentIndex(int(self.QSettings.value('ComboBox1', 0)))
        self.coordOrderComboBox_2.setCurrentIndex(int(self.QSettings.value('ComboBox2', 0)))
        self.checkBox_Fs_1.setCheckState(int(self.QSettings.value('checkBox_Fs_1', Qt.Checked))) #Qt.Unchecked
        self.checkBox_MMS_1.setCheckState(int(self.QSettings.value('checkBox_MMS_1', Qt.Unchecked))) #Qt.Unchecked
        self.checkBox_Fs_2.setCheckState(int(self.QSettings.value('checkBox_Fs_2', Qt.Checked))) #Qt.Unchecked
        self.checkBox_MMS_2.setCheckState(int(self.QSettings.value('checkBox_MMS_2', Qt.Unchecked))) #Qt.Unchecked
        # self.coconut_ComboBox.setCurrentIndex(int(self.QSettings.value('coconut_ComboBox', 0)))

        # 이동 좌표계
        self.mQgsProjectionSelectionWidget_3.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project3','USER:100000')))
        self.mQgsProjectionSelectionWidget_4.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project4','USER:100001')))
        self.mQgsProjectionSelectionWidget_5.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('Project5','USER:100001')))
        self.coordOrderComboBox_3.setCurrentIndex(int(self.QSettings.value('ComboBox3', 0)))
        self.coordOrderComboBox_4.setCurrentIndex(int(self.QSettings.value('ComboBox4', 0)))
        self.coordOrderComboBox_5.setCurrentIndex(int(self.QSettings.value('ComboBox5', 0)))
        self.GridcheckBox.setCheckState(int(self.QSettings.value('GridcheckBox', Qt.Checked))) #Qt.Unchecked
        
        # 웹지도 설정
        self.mapProviderComboBox.setCurrentIndex(int(self.QSettings.value('MapProvider', 0)))
        self.label_2.setText(self.QSettings.value('label_2', ''))
        self.mapProviderRComboBox.setCurrentIndex(int(self.QSettings.value('MapProviderRight', 0)))
        self.label_3.setText(self.QSettings.value('label_3', ''))
        self.mapProvider = int(self.QSettings.value('MapProvider', 0))
        self.mapProviderRight = int(self.QSettings.value('MapProviderRight', 0))
        self.checkBox_placemark_1.setCheckState(int(self.QSettings.value('checkBox_placemark_1', Qt.Checked)))
        self.checkBox_placemark_2.setCheckState(int(self.QSettings.value('checkBox_placemark_2', Qt.Checked)))
        # 지도 확대 값
        self.zoomSpinBox_1.setValue(int(self.QSettings.value('zoomSpinBox_1', 16)))
        self.zoomSpinBox_2.setValue(int(self.QSettings.value('zoomSpinBox_2', 16)))
        # 추가 웹지도 URL
        self.userMapProviderComboBox.setCurrentIndex(int(self.QSettings.value('userMapProvider', 0)))

        self.checkBox_Capture.setCheckState(int(self.QSettings.value('checkBox_Capture', Qt.Checked)))
        self.checkBox_Zoom.setCheckState(int(self.QSettings.value('checkBox_Zoom', Qt.Checked)))
        self.checkBox_RoadView.setCheckState(int(self.QSettings.value('checkBox_RoadView', Qt.Checked)))
        self.checkBox_SpeedFS.setCheckState(int(self.QSettings.value('checkBox_SpeedFS', Qt.Checked)))
        self.checkBox_address.setCheckState(int(self.QSettings.value('checkBox_address', Qt.Checked)))

        # 주소검색
        self.AddressSearchComboBox.setCurrentIndex(int(self.QSettings.value('AddressSearchComboBox', 0)))
        self.addressMsgBox.setCheckState(int(self.QSettings.value('addressMsgBox', Qt.Checked))) #Qt.Unchecked
    
        # 외부맵 리스트 리셋
        names = []
        for item in self.userMapProviders:
            names.append(item[0])
        self.userMapProviderComboBox.clear()
        self.userMapProviderComboBox.addItems(names)
        self.updateMapProviderComboBoxes()

        self.userProviderNameLineEdit.clear()
        self.userProviderUrlLineEdit.clear()
        # self.userProviderUrlLineEdit_2.clear();
        
        # 마크컬러 설정
        self.mkColorButton_0 = QColor(self.QSettings.value('markerColorButton_0', '#ff0000'))
        self.mkColorButton_0.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_0', 255)))
        self.markerColorButton_0.setColor(self.mkColorButton_0)
        
        self.mkColorButton_1 = QColor(self.QSettings.value('markerColorButton_1', '#ff0000'))
        self.mkColorButton_1.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_1', 255)))
        self.markerColorButton_1.setColor(self.mkColorButton_1)
        
        self.mkColorButton_2 = QColor(self.QSettings.value('markerColorButton_2', '#ff0000'))
        self.mkColorButton_2.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_2', 255)))
        self.markerColorButton_2.setColor(self.mkColorButton_2)
        
        self.mkColorButton_3 = QColor(self.QSettings.value('markerColorButton_3', '#ff0000'))
        self.mkColorButton_3.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_3', 255)))
        self.markerColorButton_3.setColor(self.mkColorButton_3)
        
        self.mkColorButton_4 = QColor(self.QSettings.value('markerColorButton_4', '#ff0000'))
        self.mkColorButton_4.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_4', 255)))
        self.markerColorButton_4.setColor(self.mkColorButton_4)
        
        self.mkColorButton_5 = QColor(self.QSettings.value('markerColorButton_5', '#ff0000'))
        self.markerColorButton_5.setColor(self.mkColorButton_5)

        self.mkColorButton_6 = QColor(self.QSettings.value('markerColorButton_6', '#ffffff'))
        self.markerColorButton_6.setColor(self.mkColorButton_6)

        self.mkColorButton_7 = QColor(self.QSettings.value('markerColorButton_7', '#00ff00'))
        self.markerColorButton_7.setColor(self.mkColorButton_7)

        self.mkColorButton_8 = QColor(self.QSettings.value('markerColorButton_8', '#ffffff'))
        self.markerColorButton_8.setColor(self.mkColorButton_8)

        self.spinBox.setValue(int(self.QSettings.value('spinBox', 10)))
        self.background_checkBox.setCheckState(int(self.QSettings.value('background_checkBox', Qt.Unchecked))) #Qt.Unchecked

        self.spinBox_2.setValue(int(self.QSettings.value('spinBox_2', 10)))
        self.background_checkBox_2.setCheckState(int(self.QSettings.value('background_checkBox_2', Qt.Unchecked))) #Qt.Unchecked

        self.GColorButton_1 = QColor(self.QSettings.value('GridColorButton_1', '#ff00ff'))
        self.GColorButton_1.setAlpha(int(self.QSettings.value('GridColorButtonOpacity_1', 255)))
        self.GridColorButton_1.setColor(self.GColorButton_1)


# 설정값 저장=================================================================================================================================================================
    def save(self):
        # 좌표 복사 설정
        self.QSettings.setValue('Project1', self.mQgsProjectionSelectionWidget.crs().authid())
        self.QSettings.setValue('Project2', self.mQgsProjectionSelectionWidget_2.crs().authid())
        self.QSettings.setValue('checkBox_Fs_1', self.checkBox_Fs_1.checkState())
        self.QSettings.setValue('checkBox_MMS_1', self.checkBox_MMS_1.checkState())
        self.QSettings.setValue('checkBox_Fs_2', self.checkBox_Fs_2.checkState())
        self.QSettings.setValue('checkBox_MMS_2', self.checkBox_MMS_2.checkState())
        self.QSettings.setValue('ComboBox1', int(self.coordOrderComboBox.currentIndex()))
        self.QSettings.setValue('ComboBox2', int(self.coordOrderComboBox_2.currentIndex()))
        self.QSettings.setValue('markerColorButton_0',self.markerColorButton_0.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_0', self.markerColorButton_0.color().alpha())
        self.QSettings.setValue('markerColorButton_1',self.markerColorButton_1.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_1', self.markerColorButton_1.color().alpha())
        # self.QSettings.setValue('coconut_ComboBox', int(self.coconut_ComboBox.currentIndex()))

        # 좌표 이동 설정
        self.QSettings.setValue('Project3', self.mQgsProjectionSelectionWidget_3.crs().authid())
        self.QSettings.setValue('Project4', self.mQgsProjectionSelectionWidget_4.crs().authid())
        self.QSettings.setValue('Project5', self.mQgsProjectionSelectionWidget_5.crs().authid())
        self.QSettings.setValue('ComboBox3', int(self.coordOrderComboBox_3.currentIndex()))
        self.QSettings.setValue('ComboBox4', int(self.coordOrderComboBox_4.currentIndex()))
        self.QSettings.setValue('ComboBox5', int(self.coordOrderComboBox_5.currentIndex()))
        self.QSettings.setValue('GridColorButton_1',self.GridColorButton_1.color().name())
        self.QSettings.setValue('GridColorButtonOpacity_1',self.GridColorButton_1.color().alpha())
        self.QSettings.setValue('GridcheckBox', self.GridcheckBox.checkState())
        # 웹지도 설정
        self.QSettings.setValue('MapProvider', int(self.mapProviderComboBox.currentIndex()))
        self.QSettings.setValue('label_2',self.label_2.text())
        self.QSettings.setValue('MapProviderRight', int(self.mapProviderRComboBox.currentIndex()))
        self.QSettings.setValue('label_3',self.label_3.text())
        self.QSettings.setValue('checkBox_placemark_1', self.checkBox_placemark_1.checkState())
        self.QSettings.setValue('checkBox_placemark_2', self.checkBox_placemark_2.checkState())
        self.QSettings.setValue('zoomSpinBox_1', int(self.zoomSpinBox_1.value()))
        self.QSettings.setValue('zoomSpinBox_2', int(self.zoomSpinBox_2.value()))
        self.QSettings.setValue('markerColorButton_2',self.markerColorButton_2.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_2', self.markerColorButton_2.color().alpha())
        self.QSettings.setValue('markerColorButton_3',self.markerColorButton_3.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_3', self.markerColorButton_3.color().alpha())

        self.QSettings.setValue('checkBox_Capture', self.checkBox_Capture.checkState())
        self.QSettings.setValue('checkBox_Zoom', self.checkBox_Zoom.checkState())
        self.QSettings.setValue('checkBox_RoadView', self.checkBox_RoadView.checkState())
        self.QSettings.setValue('checkBox_SpeedFS', self.checkBox_SpeedFS.checkState())
        self.QSettings.setValue('checkBox_address', self.checkBox_address.checkState())
        
        # 주소 설정
        self.QSettings.setValue('AddressSearchComboBox', int(self.AddressSearchComboBox.currentIndex()))
        self.QSettings.setValue('addressMsgBox', self.addressMsgBox.checkState())
        self.QSettings.setValue('markerColorButton_4',self.markerColorButton_4.color().name())
        self.QSettings.setValue('markerColorButtonOpacity_4', self.markerColorButton_4.color().alpha())
        
        # 인증키 값 설정(API키 복호화 암호)
        if self.lineEdit_pluginKey.text() != '':
            self.QSettings.setValue('lineEdit_pluginKey', self.lineEdit_pluginKey.text())
        self.lineEdit_pluginKey.setText('')
        
        self.QSettings.setValue('spinBox', int(self.spinBox.value()))
        self.QSettings.setValue('markerColorButton_5',self.markerColorButton_5.color().name())
        self.QSettings.setValue('markerColorButton_6',self.markerColorButton_6.color().name())
        self.QSettings.setValue('markerColorButton_7',self.markerColorButton_7.color().name())
        self.QSettings.setValue('markerColorButton_8',self.markerColorButton_8.color().name())

        # 마크컬러 설정
        self.mkColorButton_0 = QColor(self.QSettings.value('markerColorButton_0', '#ff0000'))
        self.mkColorButton_0.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_0', 255)))
        
        self.mkColorButton_1 = QColor(self.QSettings.value('markerColorButton_1', '#ff0000'))
        self.mkColorButton_1.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_1', 255)))

        self.mkColorButton_2 = QColor(self.QSettings.value('markerColorButton_2', '#ff0000'))
        self.mkColorButton_2.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_2', 255)))

        self.mkColorButton_3 = QColor(self.QSettings.value('markerColorButton_3', '#ff0000'))
        self.mkColorButton_3.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_3', 255)))
        
        self.mkColorButton_4 = QColor(self.QSettings.value('markerColorButton_4', '#ff0000'))
        self.mkColorButton_4.setAlpha(int(self.QSettings.value('markerColorButtonOpacity_4', 255)))
        
        self.mkColorButton_5 = QColor(self.QSettings.value('markerColorButton_5', '#ff0000'))

        self.mkColorButton_6 = QColor(self.QSettings.value('markerColorButton_6', '#ffffff'))

        self.mkColorButton_7 = QColor(self.QSettings.value('markerColorButton_7', '#00ff00'))

        self.mkColorButton_8 = QColor(self.QSettings.value('markerColorButton_8', '#ffffff'))

        self.QSettings.setValue('background_checkBox', self.background_checkBox.checkState())

        self.QSettings.setValue('background_checkBox_2', self.background_checkBox_2.checkState())

        self.GColorButton_1 = QColor(self.QSettings.value('GridColorButton_1', '#ff00ff'))
        self.GColorButton_1.setAlpha(int(self.QSettings.value('GridColorButtonOpacity_1', 255)))
        
        self.close()
        
    # 외부맵 추가시 해당 함수 실행
    def addUserProvider(self):
        name = self.userProviderNameLineEdit.text().strip()
        url = self.userProviderUrlLineEdit.text().strip()
        if name and url:
            self.userMapProviders.append([name, url])
            if self.userMapProviders:
                self.QSettings.setValue('UserMapProviders', self.userMapProviders)
            else:
                self.QSettings.setValue('UserMapProviders', 0)
            names = []
            for item in self.userMapProviders:
                names.append(item[0])
            self.userMapProviderComboBox.clear()
            self.userProviderNameLineEdit.clear()
            self.userProviderUrlLineEdit.clear()
            self.userMapProviderComboBox.addItems(names)
            self.updateMapProviderComboBoxes()
    # 외부맵 삭제시 해당 함수 실행  
    def deleteUserProvider(self):
        if self.userMapProviderComboBox.count() > 0:
            index = self.userMapProviderComboBox.currentIndex()
            if index >= 0:
                del self.userMapProviders[index]
            if self.userMapProviders:
                self.QSettings.setValue('UserMapProviders', self.userMapProviders)
            else:
                self.QSettings.setValue('UserMapProviders', 0)
            names = []
            for item in self.userMapProviders:
                names.append(item[0])
            self.userMapProviderComboBox.clear()
            # self.userProviderNameLineEdit.clear()
            # self.userProviderUrlLineEdit.clear()
            self.userProviderUrlLineEdit_2.clear()
            self.userMapProviderComboBox.addItems(names)
            # Since we deleted an entry just reset the selected map to
            # be the first one - Open Street Map
            # self.mapProvider = 0
            # self.mapProviderRight = 0
            self.updateMapProviderComboBoxes()
    # 외부맵 추가,삭제 후 외부맵 리스트 재정렬  
    def updateMapProviderComboBoxes(self):
            # Update the selected map provider lists
            curindex = self.mapProvider
            self.mapProviderComboBox.clear()
            self.mapProviderComboBox.addItems(self.mapProviderNames())
            if curindex >= len(self.mapProviderNames()):
                curindex = 0
            self.mapProviderComboBox.setCurrentIndex(curindex)

            curindex = self.mapProviderRight
            self.mapProviderRComboBox.clear()
            self.mapProviderRComboBox.addItems(self.mapProviderNames())
            if curindex >= len(self.mapProviderNames()):
                curindex = 0
            self.mapProviderRComboBox.setCurrentIndex(curindex)
    # 기본 외부맵 리스트
    def mapProviderNames(self):
        plist = []
        for x in Coordinate_Tool_data.MAP_PROVIDERS:
            plist.append(x[0])
        # plist.append('Google Earth (If Installed)')
        for entry in self.userMapProviders:
            plist.append(entry[0])
        return plist
    
    def checkBoxMMS1(self):
        if self.chkk == 0:
            if self.checkBox_MMS_1.isChecked():
                self.coordOrderComboBox.setCurrentIndex(0)
                self.coordOrderComboBox.setEnabled(False)
                self.checkBox_Fs_1.setChecked(False)
            else:
                self.checkBox_Fs_1.setChecked(True)
        
    def checkBoxMMS2(self):
        if self.chkk == 0:
            if self.checkBox_MMS_2.isChecked():
                self.coordOrderComboBox_2.setCurrentIndex(0)
                self.coordOrderComboBox_2.setEnabled(False)
                self.checkBox_Fs_2.setChecked(False)
            else:
                self.checkBox_Fs_2.setChecked(True)
                
    def checkBoxFs1(self):
        if self.chkk == 0:
            if self.checkBox_Fs_1.isChecked():
                self.coordOrderComboBox.setCurrentIndex(0)
                self.coordOrderComboBox.setEnabled(False)
                self.checkBox_MMS_1.setChecked(False)
            else:
                self.checkBox_MMS_1.setChecked(True)
            
    def checkBoxFs2(self):
        if self.chkk == 0:
            if self.checkBox_Fs_2.isChecked():
                self.checkBox_MMS_2.setChecked(False)
                self.coordOrderComboBox_2.setCurrentIndex(0)
                self.coordOrderComboBox_2.setEnabled(False)
            else:
                self.checkBox_MMS_2.setChecked(True)

    def background(self):
        if self.background_checkBox.isChecked():
            self.markerColorButton_6.setEnabled(True)
        else:
            self.markerColorButton_6.setEnabled(False)

        if self.background_checkBox_2.isChecked():
            self.markerColorButton_8.setEnabled(True)
        else:
            self.markerColorButton_8.setEnabled(False)

# 복사 좌표계 수정시 해당 함수 실행=================================================================================================================================================================   
    # 좌클릭 복사 좌표계
    def setEnabled(self):
        crs=int(self.mQgsProjectionSelectionWidget.crs().authid().split(':')[1])
        self.chkk=1
        if int(crs)<int(100000):
            self.coordOrderComboBox.setEnabled(True)
            self.checkBox_Fs_1.setChecked(False)
            self.checkBox_MMS_1.setChecked(False)
            self.checkBox_Fs_1.setEnabled(False)
            self.checkBox_MMS_1.setEnabled(False)
        else:
            self.coordOrderComboBox.setEnabled(False)
            self.coordOrderComboBox.setCurrentIndex(0)
            self.checkBox_Fs_1.setEnabled(True)
            self.checkBox_MMS_1.setEnabled(True)
            self.checkBox_Fs_1.setChecked(True)
        self.chkk=0
    # 우클릭 복사 좌표계
    def setEnabled1(self):
        self.chkk=1
        crs=int(self.mQgsProjectionSelectionWidget_2.crs().authid().split(':')[1])
        if int(crs)<int(100000):
            self.coordOrderComboBox_2.setEnabled(True)
            self.checkBox_Fs_2.setChecked(False)
            self.checkBox_MMS_2.setChecked(False)
            self.checkBox_Fs_2.setEnabled(False)
            self.checkBox_MMS_2.setEnabled(False)
        else:
            self.coordOrderComboBox_2.setEnabled(False)
            self.coordOrderComboBox_2.setCurrentIndex(0)
            self.checkBox_Fs_2.setEnabled(True)
            self.checkBox_MMS_2.setEnabled(True)
            self.checkBox_Fs_2.setChecked(True)
        self.chkk=0
# 이동 좌표계 수정시 해당 함수 실행=================================================================================================================================================================   
    # 이동1 좌표계
    def setEnabled2(self):
        crs=int(self.mQgsProjectionSelectionWidget_3.crs().authid().split(':')[1])
        self.coordOrderComboBox_3.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_3.setCurrentIndex(0)
    # 이동2 좌표계
    def setEnabled3(self):
        crs=int(self.mQgsProjectionSelectionWidget_4.crs().authid().split(':')[1])
        self.coordOrderComboBox_4.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_4.setCurrentIndex(0)
    # 이동3 좌표계
    def setEnabled4(self):
        crs=int(self.mQgsProjectionSelectionWidget_5.crs().authid().split(':')[1])
        self.coordOrderComboBox_5.setEnabled(int(crs)<int(100000))
        self.coordOrderComboBox_5.setCurrentIndex(0)
        
    def mapComboBox(self,objact,label,checkBox):
        map = int(objact.currentIndex())
        if checkBox.isChecked():
            ms = Coordinate_Tool_data.MAP_PROVIDERS[map][2]
        else:
            ms = Coordinate_Tool_data.MAP_PROVIDERS[map][1]
        label.setText(ms)
        
    # def checkBoxplacemark(self,objact,label,checkBox):
    #     map = int(objact.currentIndex())
    #     if checkBox.isChecked():
    #         ms = Coordinate_Tool_data.MAP_PROVIDERS[map][2]
    #     else:
    #         ms = Coordinate_Tool_data.MAP_PROVIDERS[map][1]
    #     label.setText(ms)
        
    # 추가 외부맵 콤보박스 수정시 
    def userMapComboBox(self):
        idx=int(self.userMapProviderComboBox.currentIndex())
        if idx >= 0:
            self.userProviderUrlLineEdit_2.setText(str(self.userMapProviders[idx][1]))

    # def delpipModule(self):
    #     try:
    #         # pip 삭제 콜
    #         python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
    #         subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pyautogui','-y'])
    #         # self.QSettings.setValue('pyautogui_'+str(VERSION), 0)
    #         subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pyperclip','-y'])
    #         # self.QSettings.setValue('pyperclip_'+str(VERSION), 0)
    #         subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'polyline','-y'])
    #         # self.QSettings.setValue('polyline_'+str(VERSION), 0)
    #         subprocess.check_call(['python', '-m', 'pip', 'uninstall', 'pycryptodome ','-y'])
    #         # self.QSettings.setValue('pycryptodome _'+str(VERSION), 0)

    #         unloadPlugin(self.Plugin)
    #         loadPlugin(self.Plugin)
    #         startPlugin(self.Plugin)
    #     except:
    #         QMessageBox.critical(self.iface.mainWindow(), "Error", "모듈 삭제 실패 관리자에게 문의 바람")

    # def addpipModule(self):
    #     try:
    #         # pip 설치 콜
    #         python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
    #         subprocess.check_call(['python', '-m', 'pip', 'install', 'pyautogui'])
    #         # self.QSettings.setValue('pyautogui_'+str(VERSION), 1)
    #         subprocess.check_call(['python', '-m', 'pip', 'install', 'pyperclip'])
    #         # self.QSettings.setValue('pyperclip_'+str(VERSION), 1)
    #         subprocess.check_call(['python','-m', 'pip', 'install', 'polyline'])
    #         # self.QSettings.setValue('polyline_'+str(VERSION), 1)
    #         subprocess.check_call(['python','-m', 'pip', 'install', 'pycryptodome'])
    #         # self.QSettings.setValue('pycryptodome_'+str(VERSION), 1)
            
    #         unloadPlugin(self.Plugin)
    #         loadPlugin(self.Plugin)
    #         startPlugin(self.Plugin)
    #     except:
    #         QMessageBox.critical(self.iface.mainWindow(), "Error", "모듈 설치 실패 관리자에게 문의 바람")


