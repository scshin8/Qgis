# -*- coding: utf-8 -*-
import os
from collections import deque
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsVectorLayer,
    QgsRectangle,
    QgsPointXY,
    QgsGeometry,
    QgsFeatureRequest,
    QgsWkbTypes,
    Qgis
)
from qgis.gui import QgsRubberBand
from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QFileDialog, QInputDialog

# ═══════════════════════════════════════════════════════════════
# 회전정보 색상 표시 기능
#   - 1차: 선택 링크의 시/종점 모든 회전 방향 표시
#   - 직진 연장: STRAIGHT_DEPTH (0~5) 단계까지 직진(d=3) 링크 연속 탐색
#   - 회전정보는 '미리 만든 .pkl 캐시파일'을 직접 지정해 로드한다.
#     (노드파일을 읽어 캐시를 생성하지 않는다 → pkl 버전 관리로 배포)
# ═══════════════════════════════════════════════════════════════

class CoordinateToolTurn:
    TURN_SNAP_TOL = 1.0                    # 노드-끝점 접속 허용오차(m, EPSG:5179)
    TURN_GRID = 1.0                        # 좌표 딕셔너리 격자 크기(m)
    TURN_COLORS = {
        'left': "#40DCFF", 
        'straight': "#A00050",
        'right': "#64FF40", 
        'unprotected': '#FFD740',
        'blocked': "#FA1616"
    }

    def __init__(self, main_tool, iface):
        self.main = main_tool
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.TurnSymbol = []          # 회전정보 색상 마커
        self.turn_run_chk = False     # 회전정보 표시 on/off

        self.turn_cache = None        # 로드된 캐시(버킷키 → [rec,...]), 없으면 None
        self._cache_path = None       # 현재 로드된 pkl 경로

        # [추가] QGIS 시작 시, 저장된 pkl 경로가 있으면 미리 로드해 둔다.
        #   pkl은 '읽기'만 하므로 빠르다 → turn 켤 때 즉시 표시됨.
        saved = self.QSettings.value('turn_pkl_path', '')
        if saved and os.path.exists(saved):
            cache = self._load_pkl_cache(saved)
            if cache is not None:
                self.turn_cache = cache
                self._cache_path = saved

    def _turn_code_str(v):
        s = str(v if v is not None else '').strip()
        if s.endswith('.0'):
            s = s[:-2]
        return s.zfill(8) if s.isdigit() else s

    @staticmethod
    def _turn_digit(s, j):
        return int(s[len(s) - j]) if len(s) >= j and s[len(s) - j].isdigit() else None

    @staticmethod
    def _turn_norm(v):
        if v is None:
            return ''
        if isinstance(v, str) and not v.strip().lstrip('-').isdigit():
            return v.strip()
        try:
            return str(int(float(v)))
        except (TypeError, ValueError):
            return str(v).strip()

    def _load_pkl_cache(self, pkl_path):
        """미리 만든 .pkl(gzip) 캐시파일을 로드해 캐시 dict를 돌려준다.
           실패 시 None. pkl 구조: {'snap_tol': float, 'cache': {버킷키:[rec,...]}}
           저장은 버킷당 1개만 → 조회는 _query_node_at에서 3x3 인접버킷을 훑는다."""
        import pickle, gzip
        try:
            # self.iface.statusBarIface().showMessage("회전정보 캐시 파일 읽는 중...")
            with gzip.open(pkl_path, 'rb') as fp:   # [변경] gzip.open
                blob = pickle.load(fp)
            cache = blob.get('cache')
            if not isinstance(cache, dict):
                return None
            return cache
        except Exception as e:
            self.iface.messageBar().pushMessage(
                '회전정보', f'캐시파일을 읽을 수 없습니다: {e}',
                level=Qgis.Warning, duration=5)
            return None
    
    def _query_node_at(self, x5179, y5179):
        # [변경] 저장이 버킷당 1개이므로, 조회 시 3x3 인접 버킷을 모두 훑는다.
        cache = getattr(self, 'turn_cache', None)
        if not cache:
            return None
        g_grid = self.TURN_SNAP_TOL
        bx, by = round(x5179 / g_grid), round(y5179 / g_grid)
        best, best_d = None, self.TURN_SNAP_TOL ** 2   # 기존과 동일한 허용오차(제곱)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for rec in cache.get((bx + dx, by + dy), ()):
                    d = (rec['_x'] - x5179) ** 2 + (rec['_y'] - y5179) ** 2
                    if d <= best_d:
                        best, best_d = rec, d
        return best
    
    def _turn_color(self, rec, entry_lid, exit_lid):
        n = rec['n']
        i = j = None
        for k in range(1, min(n, 8) + 1):
            if rec[f'L{k}'] == entry_lid:
                i = k
            if rec[f'L{k}'] == exit_lid:
                j = k
        if i is None or j is None:
            return None
        t = self._turn_digit(rec[f't{i-1}'], j)
        d = self._turn_digit(rec[f'd{i-1}'], j)
        
        if t == 3 and d == 0:
            return self.TURN_COLORS['unprotected']
        if t == 2 and d == 0:
            return self.TURN_COLORS['blocked']
        if d == 1:
            return self.TURN_COLORS['left']
        if d == 3:
            return self.TURN_COLORS['straight']
        if d == 2:
            return self.TURN_COLORS['right']
        return None

    def turn_run(self, *args):
        if self.main.turn.isChecked():
            # [B방식] 노드파일이 아니라 '미리 만든 pkl 캐시파일'을 지정한다.
            pkl = self.QSettings.value('turn_pkl_path', '')
            # 0: 직진 연장 없음(1차만), 1: 1차 직진까지 ... 최대 5
            self.straight_depth = int(self.QSettings.value('turn_straight_depth', 2))

            if not pkl:
                self.iface.messageBar().pushMessage(
                    '회전정보', f'캐시파일 경로가 없습니다.',
                    level=Qgis.Warning, duration=5)
                self.main.turn.setChecked(False)
                self.turn_cache = None        # 로드된 캐시(버킷키 → [rec,...]), 없으면 None
                self._cache_path = None       # 현재 로드된 pkl 경로
                return
            if not os.path.exists(pkl):
                self.iface.messageBar().pushMessage(
                    '회전정보', f'캐시파일 경로에 파일이 다릅니다.',
                    level=Qgis.Warning, duration=5)
                self.turn_cache = None        # 로드된 캐시(버킷키 → [rec,...]), 없으면 None
                self._cache_path = None       # 현재 로드된 pkl 경로
                self.main.turn.setChecked(False)
                return
            
            # 아직 로드 안 됐거나 다른 pkl이면 로드
            if self.turn_cache is None or self._cache_path != pkl:
                cache = self._load_pkl_cache(pkl)
                if cache is None:
                    self.main.turn.setChecked(False)
                    return
                self.turn_cache = cache
                self._cache_path = pkl

            self.canvas.selectionChanged.connect(self.turndisplay)
            self.turn_run_chk = True
            self.turndisplay()
        else:
            try:
                self.canvas.selectionChanged.disconnect(self.turndisplay)
            except Exception:
                pass
            self.remove_Turn()
            self.turn_run_chk = False

    def turndisplay(self, *args):
        if not self.turn_run_chk:
            self.remove_Turn()
            return
        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            return
        if layer.geometryType() != QgsWkbTypes.LineGeometry:
            self.remove_Turn()
            return
        if layer.selectedFeatureCount() != 1:
            self.remove_Turn()
            return

        self.remove_Turn()
        selected_feature = layer.selectedFeatures()[0]
        geometry = selected_feature.geometry()
        if geometry is None or geometry.isEmpty():
            return
        parts = geometry.asGeometryCollection()
        if len(parts) != 1:
            return
        pts = (geometry.asMultiPolyline()[0] if geometry.isMultipart()
               else geometry.asPolyline())
        if len(pts) < 2:
            return
        
        sel_start = pts[0]
        sel_end = pts[-1]
        fid = selected_feature.id()

        entry_lid = self._turn_norm(selected_feature['Link_Id']) \
            if layer.fields().lookupField('Link_Id') != -1 else None
        if not entry_lid:
            self.iface.messageBar().pushMessage(
                '회전정보', "선택 링크에 'Link_Id' 필드가 없습니다.",
                level=Qgis.Warning, duration=3)
            return

        # 좌표계 변환 설정
        map_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs = layer.crs()
        angle_crs = QgsCoordinateReferenceSystem('EPSG:5179')
        to_5179 = (None if layer_crs == angle_crs
                   else QgsCoordinateTransform(layer_crs, angle_crs, QgsProject.instance()))

        # 화면 범위 내 후보 피처 조회
        transform_back = QgsCoordinateTransform(map_crs, layer_crs, QgsProject.instance())
        extent = transform_back.transformBoundingBox(self.canvas.extent())
        # extent.grow(500)   # [추가] 사방 500m 여백 확장(레이어 좌표단위, 5179면 m)
        extent.scale(3)  # [추가] 화면 범위를 중심 기준 300% 확대
        request = QgsFeatureRequest().setFilterRect(extent)

        # 기존 코드
        # candidate_features = [f for f in layer.getFeatures(request)]

        # ── [개선] 후보를 한 번만 훑어 '끝점좌표 버킷 → 링크들' 인덱스 구성 ──
        #   기존: 매 노드마다 candidate_features 전체를 선형 순회 → O(노드수 × 후보수)
        #   개선: 끝점 좌표를 격자 버킷으로 키잉해 두면 base_point에서 O(1) 근처로 조회
        #   좌표 비교 오차를 흡수하려 TURN_GRID(1m) 단위로 반올림해 버킷팅한다.
        
        def _bucket(pt):
            g = self.TURN_GRID
            return (round(pt.x() / g), round(pt.y() / g))

        node_index = {}          # 버킷키 → [(feat, 반대편끝점), ...]
        feat_cache = {}          # fid → (feat, fpts) 재사용용
        for feat in layer.getFeatures(request):
            fg = feat.geometry()
            if fg is None or fg.isEmpty():
                continue
            fpts = (fg.asMultiPolyline()[0] if fg.isMultipart() else fg.asPolyline())
            if len(fpts) < 2:
                continue
            feat_cache[feat.id()] = (feat, fpts)
            k0 = _bucket(fpts[0])
            k1 = _bucket(fpts[-1])
            node_index.setdefault(k0, []).append((feat, fpts[-1]))   # 시점에 붙음 → 반대편은 종점
            node_index.setdefault(k1, []).append((feat, fpts[0]))    # 종점에 붙음 → 반대편은 시점
        # ── [개선] 후보를 한 번만 훑어 '끝점좌표 버킷 → 링크들' 인덱스 구성 ──

        results = []             # [(QgsGeometry, color)]
        visited_fids = {fid}     # 무한 루프 방지용 방문 기록
        
        # BFS 탐색 큐: (current_feat, node_pt, current_depth)
        # current_depth: 0 (1차 회전 탐색), 1~5 (N차 직진 탐색)
        queue = deque()

        # 시점 및 종점을 큐에 초기 등록
        endpoints = [sel_start, sel_end] if sel_start != sel_end else [sel_start]
        for pt in endpoints:
            queue.append((selected_feature, pt, 0))

        # ─────────────────────────────────────────────────────────────
        # 파라미터 기반 BFS 탐색 (0 ~ straight_depth)
        # ─────────────────────────────────────────────────────────────
        
        while queue:
            curr_feat, base_point, depth = queue.popleft()

            curr_lid = self._turn_norm(curr_feat['Link_Id']) \
                if layer.fields().lookupField('Link_Id') != -1 else None
            if not curr_lid:
                continue

            bp5179 = to_5179.transform(base_point) if to_5179 else base_point
            node_rec = self._query_node_at(bp5179.x(), bp5179.y())
            if node_rec is None:
                continue

            # ── [개선] 전체 순회 대신 base_point 버킷에 붙은 링크만 조회 ──
            for feat, next_node_pt in node_index.get(_bucket(base_point), []):
                if feat.id() in visited_fids:
                    continue

                exit_lid = self._turn_norm(feat['Link_Id']) \
                    if layer.fields().lookupField('Link_Id') != -1 else None
                if not exit_lid:
                    continue

                color = self._turn_color(node_rec, curr_lid, exit_lid)
                if color is None:
                    continue

                fg = feat.geometry()   # 러버밴드용 도형(캐시 fpts와 별개로 필요)

                if depth == 0:
                    results.append((QgsGeometry(fg), color))
                    visited_fids.add(feat.id())
                    if color == self.TURN_COLORS['straight'] and self.straight_depth > 0:
                        queue.append((feat, next_node_pt, depth + 1))

                elif depth > 0 and color == self.TURN_COLORS['straight']:
                    results.append((QgsGeometry(fg), color))
                    visited_fids.add(feat.id())
                    if depth < self.straight_depth:
                        queue.append((feat, next_node_pt, depth + 1))

        # 러버밴드 렌더링
        for geom, color in results:
            rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            rb.setToGeometry(geom, layer)
            rb.setColor(QColor(color))
            rb.setWidth(4)
            self.TurnSymbol.append(rb)
        self.canvas.refresh()

    def remove_Turn(self, *args):
        if len(self.TurnSymbol) > 0:
            for rb in self.TurnSymbol:
                self.canvas.scene().removeItem(rb)
        self.TurnSymbol = []
        self.canvas.refresh()