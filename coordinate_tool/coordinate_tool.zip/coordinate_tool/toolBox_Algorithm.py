from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsWkbTypes
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox
import os

class CreateGPSLayerAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """

    # 입력 파라미터 ID 정의
    PARAM_LAYER_NAME = "LAYER_NAME"
    PARAM_STYLE_FILE = 'STYLE_FILE'

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        # 기본 레이어 이름 = "GPS_YYYYMMDD"
        default_layer_name = f"Log_{QDateTime.currentDateTime().toString('yyyyMMdd')}"

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LAYER_NAME,
                "생성할 레이어 이름",
                defaultValue=default_layer_name  # 기본값 설정
            )
        )

        self.addParameter(
            QgsProcessingParameterFile(
                self.PARAM_STYLE_FILE,
                "QML 스타일 파일 (선택)",
                extension="qml",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 사용자가 입력한 레이어 이름 가져오기 (기본값: "GPS_Log_Layer")
        layer_name = self.parameterAsString(parameters, self.PARAM_LAYER_NAME, context)
        style_file = self.parameterAsString(parameters, self.PARAM_STYLE_FILE, context)

        if not layer_name:
            layer_name = f"Log_{QDateTime.currentDateTime().toString('yyyyMMdd')}"

        crs = QgsCoordinateReferenceSystem("EPSG:4326")  # 좌표계 설정
        new_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", layer_name, "memory")

        QgsProject.instance().addMapLayer(new_layer)
        provider = new_layer.dataProvider()

        # 추가할 필드와 기본값 정의
        fields_and_expressions = [
            ("speed", "round((@position_ground_speed * 3600) / 1000, 0)", QVariant.Int),
            ("angle", "round(@position_direction,0)", QVariant.Int),
            ("x", "x(@position_coordinate)", QVariant.Double),
            ("y", "y(@position_coordinate)", QVariant.Double),
            ("z", "z(@position_coordinate)", QVariant.Double),
            ("grs_lon", 'round("x" * 360000, 0)', QVariant.Int),
            ("grs_lat", 'round("y" * 360000, 0)', QVariant.Int),
            ("bes_x", 'x(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
            ("bes_y", 'y(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
            ("bes_lon", 'round("bes_x" * 360000,0)', QVariant.Int),
            ("bes_lat", 'round("bes_y" * 360000,0)', QVariant.Int),
            ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
            ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
            ("username", "@cloud_username", QVariant.String),
            ("useremail", "@cloud_useremail", QVariant.String),
            ("source_name", "@position_source_name", QVariant.String),
            ("quality_description", "@position_quality_description", QVariant.String),
            ("h_accuracy", "@position_horizontal_accuracy", QVariant.Double),
            ("v_accuracy", "@position_vertical_accuracy", QVariant.Double),
            ("3d_accuracy", "@position_3d_accuracy", QVariant.Double),
            ("orientation", "@position_orientation", QVariant.Double),
            ("magnetic_variation", "@position_magnetic_variation", QVariant.Double),
            ("vertical_speed", "@position_vertical_speed", QVariant.Double),
            ("averaged_count", "@position_averaged_count", QVariant.Int),
            ("pdop", "@position_pdop", QVariant.Double),
            ("hdop", "@position_hdop", QVariant.Double),
            ("vdop", "@position_vdop", QVariant.Double),
            ("number_of_used_satellites", "@position_number_of_used_satellites", QVariant.Int),
            ("used_satellites", "@position_used_satellites", QVariant.String),
            ("fix_status_description", "@position_fix_status_description", QVariant.String),
            ("fix_mode", "@position_fix_mode", QVariant.String)
        ]

        # 편집 모드 시작
        new_layer.startEditing()

        # 필드 추가
        for field_name, expr, field_type in fields_and_expressions:
            provider.addAttributes([QgsField(field_name, field_type)])
        new_layer.updateFields()

        # 기본값(표현식) 설정
        for field_name, expr, field_type in fields_and_expressions:
            idx = new_layer.fields().indexOf(field_name)
            if idx != -1:
                default = QgsDefaultValue(expr, True)
                new_layer.setDefaultValueDefinition(idx, default)

        # 스키마 갱신 및 저장
        new_layer.updateFields()
        new_layer.commitChanges()

        # ✅ 스타일 적용
        if style_file and os.path.exists(style_file):
            applied = new_layer.loadNamedStyle(style_file)
            if applied:
                feedback.pushInfo(f'레이어 "{layer_name}"에 스타일 적용 완료: {style_file}')
            else:
                feedback.pushWarning(f'레이어 "{layer_name}" 스타일 적용 실패')
        else:
            feedback.pushWarning("스타일 파일이 제공되지 않았거나 찾을 수 없습니다.")


        feedback.pushInfo(f'신규 레이어 "{layer_name}" 생성 완료')
        return {}

    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "create_log_layer"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Log 신규 레이어 생성"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return CreateGPSLayerAlgorithm()

class CopyAttributesByLocationAlgorithm(QgsProcessingAlgorithm):
    """
    원본 피처의 지정 필드 값을 대상 피처의 지정 필드로 복사하는 알고리즘으로,
    사용자가 기존 필드를 선택하거나 신규 필드를 생성할 수 있습니다.
    """

    # 입력 파라미터 ID 정의
    INPUT_SOURCE = 'INPUT_SOURCE'
    FIELD_SOURCE = 'FIELD_SOURCE'
    INPUT_TARGET = 'INPUT_TARGET'
    FIELD_TARGET = 'FIELD_TARGET'
    NEW_FIELD_NAME = 'NEW_FIELD_NAME'
    SPATIAL_RELATION = 'SPATIAL_RELATION'

    # 공간 관계 옵션 (라벨을 한글+영어로 설정)
    SPATIAL_RELATIONS = [
        "교차 (intersects)",
        "중첩 (overlaps)",
        "포함 (contains)",
        "내부 (within)",
        "동등 (equals)",
        "접촉 (touches)",
        "공간 교차 (crosses)"
    ]

    def initAlgorithm(self, config=None):
        """
        알고리즘의 입력 파라미터를 정의합니다.
        """
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_SOURCE,
                '원본 레이어 (속성 복사할 레이어)',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.FIELD_SOURCE,
                '원본 필드',
                parentLayerParameterName=self.INPUT_SOURCE,
                type=QgsProcessingParameterField.Any
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.SPATIAL_RELATION,
                '공간 관계 선택 (복수 선택 가능)',
                options=self.SPATIAL_RELATIONS,
                defaultValue=[0],  # 기본값: "교차 (intersects)"
                allowMultiple=True  # ✅ 다중 선택 활성화
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_TARGET,
                '대상 레이어 (속성 복사될 레이어)',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.FIELD_TARGET,
                '대상 필드 (기존 필드를 사용하려면 선택)',
                parentLayerParameterName=self.INPUT_TARGET,
                type=QgsProcessingParameterField.Any,
                optional=True  # ✅ 선택 가능하도록 변경
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.NEW_FIELD_NAME,
                '신규 필드 이름 (신규 필드를 만들 경우 입력)',
                optional=True  # ✅ 선택 가능하도록 변경
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """
        알고리즘의 핵심 기능을 구현합니다.
        """
        # 파라미터에서 입력값 추출
        source_layer = self.parameterAsVectorLayer(parameters, self.INPUT_SOURCE, context)
        source_field = self.parameterAsString(parameters, self.FIELD_SOURCE, context)
        target_layer = self.parameterAsVectorLayer(parameters, self.INPUT_TARGET, context)
        target_field = self.parameterAsString(parameters, self.FIELD_TARGET, context)
        new_field_name = self.parameterAsString(parameters, self.NEW_FIELD_NAME, context)
        selected_relation_indexes = self.parameterAsEnums(parameters, self.SPATIAL_RELATION, context)

        if source_layer is None or target_layer is None:
            raise QgsProcessingException('입력 레이어를 확인하세요.')

        # 선택한 공간 관계 목록 가져오기
        selected_relations = [self.SPATIAL_RELATIONS[i].split(" ")[1][1:-1] for i in selected_relation_indexes]
        feedback.pushInfo("선택한 공간 관계: {}".format(", ".join(selected_relations)))

        # 대상 필드 결정 (기존 필드를 사용하거나, 새 필드를 생성)
        if not target_field and not new_field_name:
            raise QgsProcessingException('대상 필드를 선택하거나 새 필드 이름을 입력해야 합니다.')

        # 대상 필드가 없는 경우 새 필드 추가
        if new_field_name:
            target_field = new_field_name
            if target_field in [field.name() for field in target_layer.fields()]:
                QMessageBox.critical(None, "오류", f"신규 필드 '{target_field}'가 이미 존재합니다. 실행이 중단됩니다.")
                raise QgsProcessingException(f"신규 필드 '{target_field}'가 이미 존재합니다. 실행이 중단됩니다.")
            else:
                # 신규 필드 추가
                target_layer.startEditing()
                target_layer.addAttribute(QgsField(target_field, QVariant.String))  # 문자열 타입 필드 추가
                target_layer.updateFields()
                feedback.pushInfo(f"새 필드 '{target_field}'을(를) 생성했습니다.")

        # 대상 레이어가 편집 모드가 아니면 편집 모드 전환
        if not target_layer.isEditable():
            target_layer.startEditing()

        # 원본 레이어의 공간 색인 생성 (검색 속도 향상)
        index = QgsSpatialIndex(source_layer.getFeatures())

        # 필드 인덱스 찾기
        source_field_idx = source_layer.fields().lookupField(source_field)
        target_field_idx = target_layer.fields().lookupField(target_field)

        if source_field_idx == -1:
            raise QgsProcessingException('원본 필드명이 올바르지 않습니다.')
        if target_field_idx == -1:
            raise QgsProcessingException('대상 필드가 존재하지 않습니다.')

        # 관계 판별 함수 정의 (선택된 모든 관계 중 하나라도 만족하면 True 반환)
        def check_relation(source_geom, target_geom):
            for relation in selected_relations:
                if relation == "equals" and source_geom.equals(target_geom):
                    return True
                elif relation == "intersects" and source_geom.intersects(target_geom):
                    return True
                elif relation == "contains" and source_geom.contains(target_geom):
                    return True
                elif relation == "within" and source_geom.within(target_geom):
                    return True
                elif relation == "overlaps" and source_geom.overlaps(target_geom):
                    return True
                elif relation == "touches" and source_geom.touches(target_geom):
                    return True
                elif relation == "crosses" and source_geom.crosses(target_geom):
                    return True
            return False

        # 대상 레이어의 각 피처에 대해 복사 실행
        count = 0
        for target_feat in target_layer.getFeatures():
            target_geom = target_feat.geometry()
            if not target_geom:
                continue

            # 대상 피처의 경계 상자와 교차하는 원본 피처 후보 찾기
            candidate_ids = index.intersects(target_geom.boundingBox())
            for fid in candidate_ids:
                source_feat = source_layer.getFeature(fid)
                if not source_feat.geometry():
                    continue
                if check_relation(source_feat.geometry(), target_geom):
                    value = source_feat[source_field_idx]
                    target_layer.changeAttributeValue(target_feat.id(), target_field_idx, value)
                    count += 1
                    break  # 매칭 피처를 찾으면 다음 대상 피처로 넘어감

            # 진행 상황 피드백 (예: 1000개마다)
            if count % 1000 == 0:
                feedback.pushInfo("처리한 피처 수: {}".format(count))
                if feedback.isCanceled():
                    break

        # 변경 내용 저장
        target_layer.commitChanges()
        feedback.pushInfo('속성 복사가 완료되었습니다. 총 {}개 피처 처리됨.'.format(count))
        return {}


    def name(self):
        """
        내부적으로 사용되는 알고리즘의 이름 (영문, 고유값)
        """
        return "copy_attributes_by_location"

    def displayName(self):
        """
        사용자에게 보여질 알고리즘의 이름
        """
        return "위치로 속성 복사"

    def group(self):
        """
        도구 상자에서 표시될 그룹 이름
        """
        return "백터 일반"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "vector_general"

    def createInstance(self):
        """
        알고리즘의 새로운 인스턴스를 반환합니다.
        """
        return CopyAttributesByLocationAlgorithm()

class ListSubfoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """폴더의 하위 디렉터리 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        subfolders = [f for f in os.listdir(input_folder) if os.path.isdir(os.path.join(input_folder, f))]

        feedback.pushInfo(f"총 {len(subfolders)}개의 하위 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for subfolder in subfolders:
            feature = QgsFeature()
            feature.setAttributes([subfolder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_subfolders"

    def displayName(self):
        return "하위 폴더 목록 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListSubfoldersAlgorithm()

class ListAllFoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """전체 하위 폴더 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        # 🔹 전체 폴더 목록 가져오기
        all_folders = []
        for root, dirs, _ in os.walk(input_folder):
            for directory in dirs:
                full_path = os.path.join(root, directory)
                all_folders.append(full_path)

        feedback.pushInfo(f"총 {len(all_folders)}개의 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))
        fields.append(QgsField("Folder_Path", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for folder in all_folders:
            feature = QgsFeature()
            feature.setAttributes([os.path.basename(folder), folder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_all_folders"

    def displayName(self):
        return "모든 하위 폴더 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListAllFoldersAlgorithm()
