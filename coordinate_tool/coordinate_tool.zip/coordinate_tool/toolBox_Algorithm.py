from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsWkbTypes
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox
import os

class CreateGPSLayerAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """

    # 입력 파라미터 ID 정의
    PARAM_LAYER_NAME = "LAYER_NAME"
    PARAM_STYLE_FILE = 'STYLE_FILE'

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        # 기본 레이어 이름 = "GPS_YYYYMMDD"
        default_layer_name = f"Log_{QDateTime.currentDateTime().toString('yyyyMMdd')}"

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LAYER_NAME,
                "생성할 레이어 이름",
                defaultValue=default_layer_name  # 기본값 설정
            )
        )

        # self.addParameter(
        #     QgsProcessingParameterFile(
        #         self.PARAM_STYLE_FILE,
        #         "QML 스타일 파일 (선택)",
        #         extension="qml",
        #         optional=True
        #     )
        # )

    def processAlgorithm(self, parameters, context, feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 사용자가 입력한 레이어 이름 가져오기 (기본값: "GPS_Log_Layer")
        layer_name = self.parameterAsString(parameters, self.PARAM_LAYER_NAME, context)
        # style_file = self.parameterAsString(parameters, self.PARAM_STYLE_FILE, context)

        if not layer_name:
            layer_name = f"Log_{QDateTime.currentDateTime().toString('yyyyMMdd')}"

        crs = QgsCoordinateReferenceSystem("EPSG:4326")  # 좌표계 설정
        new_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", layer_name, "memory")

        QgsProject.instance().addMapLayer(new_layer)
        provider = new_layer.dataProvider()

        # 추가할 필드와 기본값 정의
        fields_and_expressions = [
            ("speed", "round((@position_ground_speed * 3600) / 1000, 0)", QVariant.Int),
            ("angle", "round(@position_direction,0)", QVariant.Int),
            ("x", "x(@position_coordinate)", QVariant.Double),
            ("y", "y(@position_coordinate)", QVariant.Double),
            ("z", "z(@position_coordinate)", QVariant.Double),
            ("grs_lon", 'round("x" * 360000, 0)', QVariant.Int),
            ("grs_lat", 'round("y" * 360000, 0)', QVariant.Int),
            ("bes_x", 'x(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
            ("bes_y", 'y(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
            ("bes_lon", 'round("bes_x" * 360000,0)', QVariant.Int),
            ("bes_lat", 'round("bes_y" * 360000,0)', QVariant.Int),
            ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
            ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
            ("username", "@cloud_username", QVariant.String),
            ("useremail", "@cloud_useremail", QVariant.String),
            ("source_name", "@position_source_name", QVariant.String),
            ("quality_description", "@position_quality_description", QVariant.String),
            ("h_accuracy", "@position_horizontal_accuracy", QVariant.Double),
            ("v_accuracy", "@position_vertical_accuracy", QVariant.Double),
            ("3d_accuracy", "@position_3d_accuracy", QVariant.Double),
            ("orientation", "@position_orientation", QVariant.Double),
            ("magnetic_variation", "@position_magnetic_variation", QVariant.Double),
            ("vertical_speed", "@position_vertical_speed", QVariant.Double),
            ("averaged_count", "@position_averaged_count", QVariant.Int),
            ("pdop", "@position_pdop", QVariant.Double),
            ("hdop", "@position_hdop", QVariant.Double),
            ("vdop", "@position_vdop", QVariant.Double),
            ("number_of_used_satellites", "@position_number_of_used_satellites", QVariant.Int),
            ("used_satellites", "@position_used_satellites", QVariant.String),
            ("fix_status_description", "@position_fix_status_description", QVariant.String),
            ("fix_mode", "@position_fix_mode", QVariant.String),
            ("Log_flag", "@visible_flag ", QVariant.String)
        ]

        # 편집 모드 시작
        new_layer.startEditing()

        # 필드 추가
        for field_name, expr, field_type in fields_and_expressions:
            provider.addAttributes([QgsField(field_name, field_type)])
        new_layer.updateFields()

        # 기본값(표현식) 설정
        for field_name, expr, field_type in fields_and_expressions:
            idx = new_layer.fields().indexOf(field_name)
            if idx != -1:
                default = QgsDefaultValue(expr, True)
                new_layer.setDefaultValueDefinition(idx, default)

        # 스키마 갱신 및 저장
        new_layer.updateFields()
        new_layer.commitChanges()

        # ✅ 스타일 적용

        style_file = os.path.dirname(__file__) + '/style/Qfield_LogStyle.qml'
        if style_file and os.path.exists(style_file):
            applied = new_layer.loadNamedStyle(style_file)
            if applied:
                feedback.pushInfo(f'레이어 "{layer_name}"에 스타일 적용 완료: {style_file}')
            else:
                feedback.pushWarning(f'레이어 "{layer_name}" 스타일 적용 실패')
        else:
            feedback.pushWarning("스타일 파일이 제공되지 않았거나 찾을 수 없습니다.")


        feedback.pushInfo(f'신규 레이어 "{layer_name}" 생성 완료')
        return {}

    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "create_log_layer"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Log 신규 레이어 생성"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return CreateGPSLayerAlgorithm()

class ListSubfoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """폴더의 하위 디렉터리 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        subfolders = [f for f in os.listdir(input_folder) if os.path.isdir(os.path.join(input_folder, f))]

        feedback.pushInfo(f"총 {len(subfolders)}개의 하위 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for subfolder in subfolders:
            feature = QgsFeature()
            feature.setAttributes([subfolder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_subfolders"

    def displayName(self):
        return "하위 폴더 목록 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListSubfoldersAlgorithm()

class ListAllFoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """전체 하위 폴더 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        # 🔹 전체 폴더 목록 가져오기
        all_folders = []
        for root, dirs, _ in os.walk(input_folder):
            for directory in dirs:
                full_path = os.path.join(root, directory)
                all_folders.append(full_path)

        feedback.pushInfo(f"총 {len(all_folders)}개의 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))
        fields.append(QgsField("Folder_Path", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for folder in all_folders:
            feature = QgsFeature()
            feature.setAttributes([os.path.basename(folder), folder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_all_folders"

    def displayName(self):
        return "모든 하위 폴더 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListAllFoldersAlgorithm()
