from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingOutputLayerDefinition,
    QgsProcessingUtils,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMarkerSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsFields,
    QgsField,
    QgsDefaultValue,
    QgsFeatureSink,
    QgsProject,
    QgsFeature,
    QgsCoordinateReferenceSystem,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsWkbTypes,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsProperty,
    QgsGeometry
)

from qgis.PyQt.QtCore import QVariant, QDateTime
from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtWidgets import QApplication

from PyQt5.QtCore import (QTimer,
                          Qt,
                          QSettings,
                          QPointF,
                          QSizeF)

from qgis.utils import iface

import os, shutil, processing, glob
import pandas as pd


class servey_shp_merge(QgsProcessingAlgorithm):
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        input_Folder = self.Qsettings.value('조사등록폴더', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '주차 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        
        # self.addParameter(
        #         QgsProcessingParameterBoolean(
        #             'ADD_TO_CANVAS',
        #             '결과 레이어를 화면에 추가',
        #             defaultValue = False
        #         )
        #     )
        # self.addParameter(QgsProcessingParameterFeatureSink('2', '조사등록', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):

        input_Folder = self.parameterAsFile(parameters, '1', context)
        weekNum = input_Folder.split('\\')[-1]
        self.Qsettings.setValue('조사등록폴더', input_Folder)

        feedback = QgsProcessingMultiStepFeedback(6, model_feedback)

        # 1. 하위 모든 SHP 경로 수집
        for subFolder in os.listdir(input_Folder):
            results = {}
            outputs = {}
            subFolder_Path = os.path.join(input_Folder, subFolder)
            fileName =f'{weekNum}_{subFolder}_조사등록'
            result_path = f'{input_Folder}/{fileName}.shp'
            if not os.path.isdir(subFolder_Path):
                continue
            all_shp_paths = []
            for logFolder in os.listdir(subFolder_Path):
                logFolder_Path = os.path.join(subFolder_Path, logFolder)
                if not os.path.isdir(logFolder_Path):
                    continue

                shp_files = glob.glob(os.path.join(logFolder_Path, '*.shp'))
                all_shp_paths.extend(shp_files)

            if not all_shp_paths:
                model_feedback.pushInfo('병합할 SHP 파일이 없습니다.')
                return {}

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS': None,
                'LAYERS': all_shp_paths,
                'OUTPUT': 'memory:'
            }
            outputs['1'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1)
            if feedback.isCanceled():
                return {}
            
            # 2_필드 계산기 path
            split_index = len(all_shp_paths[0].split('\\')) - 2
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': 'LOG_NAME',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f"string_to_array( \"path\" ,'\\\\')[{split_index}]",
                'INPUT': outputs['1']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['2'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2)
            if feedback.isCanceled():
                return {}
            
            # 3_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 254,
                'FIELD_NAME': '차수',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': f"replace( replace( \"layer\",'차','일차'),'일일차','일차')",
                'INPUT': outputs['2']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3)
            if feedback.isCanceled():
                return {}

            # 4_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['3']['OUTPUT'],
                'OUTPUT':  'memory:'
            }
            outputs['4'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4)
            if feedback.isCanceled():
                return {}
    
            # 5_중복 도형 삭제
            alg_params = {
                'INPUT': outputs['4']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['5'] = processing.run('native:deleteduplicategeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5)
            if feedback.isCanceled():
                return {}

            # 6_필드 계산기
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Length',
                'FIELD_PRECISION': 3,
                'FIELD_TYPE': 0,  # 텍스트 (string)
                'FORMULA': "Length(transform( $geometry, @layer_crs, 'EPSG:5179' ))/1000",
                'INPUT': outputs['5']['OUTPUT'],
                'OUTPUT': result_path
            }
            outputs['6'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6)
            if feedback.isCanceled():
                return {}

        return {}

    def name(self):
        return '조사등록SHP_병합'

    def displayName(self):
        return '조사등록SHP_병합'

    # def group(self):
    #     return 'wkt_geom_TO_shp'

    # def groupId(self):
    #     return 'wkt_geom_TO_shp'

    def createInstance(self):
        return servey_shp_merge()
    
class create_shp_from_wkt(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
    
    def initAlgorithm(self, config=None):
        excel_file = self.Qsettings.value('엑셀문서', '')
        crs = self.Qsettings.value('CRS', '')
        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    "변환 문서",
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'XLSX files (*.xlsx);;CSV files (*.csv);;XLTM files (*.xltm)',
                    defaultValue = excel_file
                )
            )
            
        self.addParameter(
            QgsProcessingParameterCrs(
                'CRS',
                '좌표계 지정',
                defaultValue=crs  # 기본값 설정 가능
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model

        """전체 하위 폴더 목록을 가져오는 로직"""
        excel_file = self.parameterAsFile(parameters, '1', context)
        crs = self.parameterAsCrs(parameters, 'CRS', context)

        self.Qsettings.setValue('엑셀문서', excel_file)
        self.Qsettings.setValue('CRS', crs.authid())

        feedback = QgsProcessingMultiStepFeedback(1, model_feedback)

        def detect_geometry_type(wkt_string: str) -> str:
            """
            주어진 WKT 문자열을 기반으로 QGIS에서 사용할 geometry 타입을 반환합니다.
            예: 'POINT', 'LINESTRING', 'MULTIPOLYGON' 등

            QGIS의 QgsVectorLayer에 사용할 수 있는 문자열 형식으로 반환됩니다.
            """
            if not wkt_string:
                return None

            wkt_upper = wkt_string.strip().upper()

            if wkt_upper.startswith("POINT"):
                return "Point"
            elif wkt_upper.startswith("LINESTRING"):
                return "LineString"
            elif wkt_upper.startswith("POLYGON"):
                return "Polygon"
            elif wkt_upper.startswith("MULTIPOINT"):
                return "MultiPoint"
            elif wkt_upper.startswith("MULTILINESTRING"):
                return "MultiLineString"
            elif wkt_upper.startswith("MULTIPOLYGON"):
                return "MultiPolygon"
            else:
                return None  # 알 수 없는 형식

        def create_shp(excel_path, save_path):

            # 엑셀 읽기
            df = pd.read_excel(excel_path)

            if 'wkt_geom' not in df.columns:
                raise ValueError("wkt_geom 필드가 없습니다.")

            geometry_type = detect_geometry_type(df['wkt_geom'].iloc[0])  # 첫 번째 행으로 판별

            # 필드 정의
            fields = QgsFields()
            fields.append(QgsField("id", QVariant.String))
            for col in df.columns:
                if col != 'wkt_geom':
                    fields.append(QgsField(col, QVariant.String))

            # LineString 레이어 생성
            layer = QgsVectorLayer(f"{geometry_type}?crs={crs.authid()}", "auto_layer", "memory")
            layer_data = layer.dataProvider()
            layer_data.addAttributes(fields)
            layer.updateFields()

            # 피처 생성
            for i, row in df.iterrows():
                geom = QgsGeometry.fromWkt(row['wkt_geom'])
                if not geom or geom.isEmpty():
                    continue

                feat = QgsFeature()
                feat.setGeometry(geom)


                # attr = [str(i)] + [str(row[col]) for col in df.columns if col != 'wkt_geom']

                # NaN 값을 None으로 변환
                attr = [str(i)]
                for col in df.columns:
                    if col == 'wkt_geom':
                        continue
                    val = row[col]
                    if pd.isna(val):
                        attr.append(None)
                    else:
                        attr.append(str(val))

                feat.setAttributes(attr)
                layer_data.addFeature(feat)

            layer.updateExtents()
            # QgsProject.instance().addMapLayer(layer)
            # SHP 저장
            result = QgsVectorFileWriter.writeAsVectorFormat(
                layer, save_path, "System", crs, "ESRI Shapefile"
            )
            # QGIS 버전에 따라 튜플 또는 정수 처리
            if isinstance(result, tuple):
                error_code = result[0]
            else:
                error_code = result

            print(error_code)
            if error_code == QgsVectorFileWriter.NoError:
                print("저장 성공:", save_path)
                return True
            else:
                print("저장 실패")
                return False

        excel_file.split('.')[0]
        output_shp = f"{excel_file.split('.')[0]}.shp"



        excel_file.split('.')[0]
        output_shp = f"{excel_file.split('.')[0]}.shp"

        create_shp(excel_file, output_shp)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}
        
        return {}
    
    def name(self):
        return 'Excel_To_Shp'

    def displayName(self):
        return 'Excel_To_Shp'

    # def group(self):
    #     return 'wkt_geom_TO_shp'

    # def groupId(self):
    #     return 'wkt_geom_TO_shp'

    def createInstance(self):
        return create_shp_from_wkt()
    
class GuidedLine_Extraction(QgsProcessingAlgorithm):

    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def initAlgorithm(self, config=None):

        input_Folder = self.Qsettings.value('로그폴더', '')
        guideLine_shp = self.Qsettings.value('유도선shp', '')
        partner_shp = self.Qsettings.value('협력사shp', '')
        TG_shp = self.Qsettings.value('톨게이트shp', '')
        exc_shp = self.Qsettings.value('기반영shp', '')

        self.addParameter(
                QgsProcessingParameterFile(
                    '1',
                    '로그 폴더',
                    behavior = QgsProcessingParameterFile.Folder,
                    defaultValue = input_Folder
                )
            )
        self.addParameter(
                QgsProcessingParameterFile(
                    '2',
                    "주단위 유도선shp",
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = guideLine_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '3',
                    '협력사shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = partner_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '4',
                    '톨게이트shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = TG_shp
                )
            )
        
        self.addParameter(
                QgsProcessingParameterFile(
                    '5',
                    '기반영shp',
                    behavior = QgsProcessingParameterFile.File,
                    fileFilter = 'SHP files (*.shp)',
                    defaultValue = exc_shp,
                    optional=True  # 선택 입력으로 설정
                )
            )
        
        self.addParameter(
                QgsProcessingParameterBoolean(
                    'ADD_TO_CANVAS',
                    '결과 레이어를 화면에 추가',
                    defaultValue = False
                )
            )
        
    def processAlgorithm(self, parameters, context, model_feedback):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model


        """전체 하위 폴더 목록을 가져오는 로직"""
        input_Folder = self.parameterAsFile(parameters, '1', context)
        guideLine_shp = self.parameterAsFile(parameters, '2', context)
        partner_shp = self.parameterAsFile(parameters, '3', context)
        TG_shp = self.parameterAsFile(parameters, '4', context)
        exc_shp = self.parameterAsFile(parameters, '5', context)
        
        self.Qsettings.setValue('로그폴더', input_Folder)
        self.Qsettings.setValue('유도선shp', guideLine_shp)
        self.Qsettings.setValue('협력사shp', partner_shp)
        self.Qsettings.setValue('톨게이트shp', TG_shp)
        self.Qsettings.setValue('기반영shp', exc_shp)

        if not os.path.isdir(input_Folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        weekNum = input_Folder.split('\\')[-1]
        Result_Shp = f'{input_Folder}/{weekNum}.shp'

        """하위 폴더 목록을 가져오는 로직"""
        subfolders = [f for f in os.listdir(input_Folder) if os.path.isdir(os.path.join(input_Folder, f))]

        # for root, dirs, _ in os.walk(input_folder):
        #     for directory in dirs:
        #         full_path = os.path.join(root, directory)
        #         all_folders.append(full_path)

        feedback = QgsProcessingMultiStepFeedback(94 * len(subfolders) + 2, model_feedback)
        feedback.pushInfo(f"총 {len(subfolders)}개의 폴더를 찾았습니다.")
        feedback.pushInfo(f"{subfolders}")

        detectResult=[]
        idx = 0
        for logFolder in subfolders:
            Stepnum = 94 * idx
            results = {}
            outputs = {}
            # 1_문자열 연결_로그
            # E:\Survey_Log\   로그명 앞 경로 설정 필요
            alg_params = {
                'INPUT_1': input_Folder,
                'INPUT_2': f'/{logFolder}'
            }
            outputs['1'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(1 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 2_문자열 연결_3_detection_results_clust_END
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/3_detection_results_clust_END.csv'
            }
            outputs['2'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(2 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 3_문자열 연결_RESULT
            alg_params = {
                'INPUT_1': outputs['1']['CONCATENATION'],
                'INPUT_2': '/RESULT'
            }
            outputs['3'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(3 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 4_디렉터리 생성
            path_to_create = outputs['3']['CONCATENATION']
            if not os.path.exists(path_to_create):
                os.makedirs(path_to_create)

            # alg_params = {
            #     'PATH': outputs['3']['CONCATENATION']
            # }
            # outputs['4'] = processing.run('native:createdirectory', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(4 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 5_문자열 연결_00_Detection_Results.shp
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/00_Detection_Results.shp'
            }
            outputs['5'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(5 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 6_문자열 연결_00_Detection_Results.qml
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/00_Detection_Results.qml'
            }
            outputs['6'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(6 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 7_문자열 연결_00_Detection_Results_END.shp
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}.shp'
            }
            outputs['7'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(7 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 8_문자열 연결_00_Detection_Results_END.qml
            alg_params = {
                'INPUT_1': outputs['3']['CONCATENATION'],
                'INPUT_2': f'/{logFolder}.qml'
            }
            outputs['8'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(8 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 9_파일 다운로드
            alg_params = {
                'DATA': '',
                'METHOD': 0,  # GET
                'OUTPUT': outputs['6']['CONCATENATION'],
                'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results.qml'
            }
            outputs['9'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(9 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 10_파일 다운로드
            alg_params = {
                'DATA': '',
                'METHOD': 0,  # GET
                'OUTPUT': outputs['8']['CONCATENATION'],
                'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results_END.qml'
            }
            outputs['10'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 11_테이블에서 포인트 생성
            alg_params = {
                'INPUT': outputs['2']['CONCATENATION'],
                'MFIELD': '',
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                'XFIELD': 'x',
                'YFIELD': 'y',
                'ZFIELD': '',
                'OUTPUT': 'memory:'
            }
            outputs['11'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(11 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 12_필드 계산기 group
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'group',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': ' "id_mod" ||\'_\'|| "color_mod" ',
                'INPUT': outputs['11']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['12'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(12 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 13_표현식으로 추출
            alg_params = {
                'EXPRESSION': '"color_mod" <> \'단일\' and "color_mod" <> \'enemy\'',
                'INPUT': outputs['12']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['13'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(13 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 14_포인트를 경로로
            alg_params = {
                'CLOSE_PATH': False,
                'GROUP_EXPRESSION': ' "id_mod" ||\'_\'|| "color_mod" ',
                'INPUT': outputs['13']['OUTPUT'],
                'NATURAL_SORT': False,
                'ORDER_EXPRESSION': ' "NO" ',
                'OUTPUT': 'memory:'
            }
            outputs['14'] = processing.run('native:pointstopath', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(14 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 15_중복 꼭짓점 제거
            alg_params = {
                'INPUT': outputs['14']['OUTPUT'],
                'TOLERANCE': 1e-06,
                'USE_Z_VALUE': False,
                'OUTPUT': 'memory:'
            }
            outputs['15'] = processing.run('native:removeduplicatevertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(15 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 16_필드 계산기 len
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'len',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round($length,0)',
                'INPUT': outputs['15']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['16'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(16 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 17_표현식으로 추출
            alg_params = {
                'EXPRESSION': '"len">0',
                'INPUT': outputs['16']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['17'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(17 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 18_필드 계산기 ang
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Angle_Sur',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round(line_interpolate_angle($geometry,distance:=0),0)',
                'INPUT': outputs['17']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['18'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(18 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 19_필드 계산기 영상_컬러
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'Color_Sur',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': 'substr( "group",strpos( "group" ,\'_\')+1,10)',
                'INPUT': outputs['18']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['19'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(19 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 20_꼭짓점 추출
            alg_params = {
                'INPUT': outputs['19']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['20'] = processing.run('native:extractvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(20 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 21_범주 별 통계
            alg_params = {
                'CATEGORIES_FIELD_NAME': ['group'],
                'INPUT': outputs['20']['OUTPUT'],
                'VALUES_FIELD_NAME': '',
                'OUTPUT': 'memory:'
            }
            outputs['21'] = processing.run('qgis:statisticsbycategories', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(21 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 22_필드 값으로 속성 결합 count
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['count'],
                'FIELD_2': 'group',
                'INPUT': outputs['12']['OUTPUT'],
                'INPUT_2': outputs['21']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['22'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(22 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 23_벡터 피처를 파일로 저장_1
            # 00_Detection_Results.shp
            alg_params = {
                'DATASOURCE_OPTIONS': '',
                'INPUT': outputs['22']['OUTPUT'],
                'LAYER_NAME': '',
                'LAYER_OPTIONS': '',
                'OUTPUT': outputs['5']['CONCATENATION'],
            }
            outputs['23'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(23 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 24_필드 값으로 속성 결합 count
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['count'],
                'FIELD_2': 'group',
                'INPUT': outputs['19']['OUTPUT'],
                'INPUT_2': outputs['21']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['24'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(24 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 25_표현식으로 추출 확인대상
            alg_params = {
                'EXPRESSION': '"len"<> 0 and "Color_Sur"<>\'enemy\' and "count">=4',
                'INPUT': outputs['24']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['25'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(25 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 26_특정 꼭짓점 추출
            alg_params = {
                'INPUT': outputs['25']['OUTPUT'],
                'VERTICES': '0',
                'OUTPUT': 'memory:'
            }
            outputs['26'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(26 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 27_위치에 따라 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['26']['OUTPUT'],
                'JOIN': outputs['13']['OUTPUT'],
                'JOIN_FIELDS': ['NO','score','date','time','mask','RESULT_IMG','filepath','Coordinate','file'],
                'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['27'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(27 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 28_표현식으로 추출  NO
            alg_params = {
                'EXPRESSION': ' "begin" = "NO" ',
                'INPUT': outputs['27']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['28'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(28 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 29_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['NO','score','date','time','mask','RESULT_IMG','filepath','Coordinate','file'],
                'FIELD_2': 'group',
                'INPUT': outputs['25']['OUTPUT'],
                'INPUT_2': outputs['28']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['29'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(29 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 30_위치에 따라 속성 결합 _ 인덱스 결합
            # 협력사 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['29']['OUTPUT'],
                # 'JOIN': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/협력사_22년.shp',
                'JOIN': partner_shp,
                'JOIN_FIELDS': ['Area'],
                'METHOD': 2,  # 최대 중첩 영역을 가진 피처의 속성만 가져오기 (1대1)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['30'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(30 + Stepnum)
            if feedback.isCanceled():
                return {}

            # # 31_문자열 연결_유도선
            # alg_params = {
            #     # 'INPUT_1': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/2025/',
            #     'INPUT_1': guideLine_shp,
            #     'INPUT_2': ''
            # }
            # outputs['31'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            # feedback.setCurrentStep(31)
            # if feedback.isCanceled():
            #     return {}
            # feedback.pushInfo(f"31")
            # # 32_문자열 연결_유도선2
            # alg_params = {
            #     'INPUT_1': outputs['31']['CONCATENATION'],
            #     'INPUT_2': ''
            # }
            # outputs['32'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            # feedback.setCurrentStep(32)
            # if feedback.isCanceled():
            #     return {}

            # 33_필드 계산기 ang_2
            # 주단위_유도선.shp
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Angle_Gui',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 1,  # Integer (32 bit)
                'FORMULA': 'round(line_interpolate_angle($geometry,distance:=0),0)',
                'INPUT': guideLine_shp,
                'OUTPUT': 'memory:'
            }
            outputs['33'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(33 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 34_필드 계산기 유도선_컬러
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': 'Color_Gui',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': 'if("컬러"=\'1\',\'pink\',if("컬러"=\'3\',\'green\',if("컬러"=\'6\',\'blue\',\'\')))',
                'INPUT': outputs['33']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['34'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(34 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 35_공간 인덱스 생성_유도선
            alg_params = {
                'INPUT': outputs['34']['OUTPUT']
            }
            outputs['35'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(35 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 36_벡터 피처를 파일로 저장
            # # 11_Detection_Point_Line.shp
            # alg_params = {
            #     'DATASOURCE_OPTIONS': '',
            #     'INPUT': outputs['30']['OUTPUT'],
            #     'LAYER_NAME': '',
            #     'LAYER_OPTIONS': '',
            #     'OUTPUT': 'F:/RESULT/11_Detection_Point_Line.shp',
            #     'OUTPUT': 'memory:'
            # }
            # outputs['36'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(36 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 37_라인 오프셋
            alg_params = {
                'DISTANCE': QgsProperty.fromExpression('if ( "Color_Sur" = \'pink\' , -1 , if ( "Color_Sur" = \'blue\' , 1 , 3 ))'),
                'INPUT': outputs['30']['OUTPUT'],
                'JOIN_STYLE': 1,  # 마이터(miter)
                'MITER_LIMIT': 2,
                'SEGMENTS': 8,
                'OUTPUT': 'memory:'
            }
            outputs['37'] = processing.run('native:offsetline', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(37 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 38_버퍼
            alg_params = {
                'DISSOLVE': False,
                'DISTANCE': 50,
                'END_CAP_STYLE': 0,  # 둥글게
                'INPUT': outputs['30']['OUTPUT'],
                'JOIN_STYLE': 0,  # 둥글게
                'MITER_LIMIT': 2,
                'SEGMENTS': 8,
                'OUTPUT': 'memory:'
            }
            outputs['38'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(38 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 39_공간 인덱스 생성_버퍼
            alg_params = {
                'INPUT': outputs['38']['OUTPUT']
            }
            outputs['39'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(39 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 40_위치에 따라 속성 결합 유도선 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'INPUT': outputs['39']['OUTPUT'],
                'JOIN': outputs['35']['OUTPUT'],
                'JOIN_FIELDS': ['Angle_Gui','Color_Gui'],
                'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                'PREDICATE': [0],  # intersect
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['40'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        
            feedback.setCurrentStep(40 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 41_표현식으로 추출 색상일치
            alg_params = {
                'EXPRESSION': '("Color_Sur" = "Color_Gui") \nand \r\nabs(\r\nwith_variable(\'ang\',abs(("Angle_Gui" - "Angle_Sur") % 360), if( @ang > 180, 360-(@ang), @ang))\r\n) <= 45\r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['41'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(41 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 42_속성으로 중복 삭제 색상일치
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['41']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['42'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(42 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 43_필드 계산기 Match
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'01_일치'",
                'INPUT': outputs['42']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['43'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(43 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 44 비활성화
            feedback.setCurrentStep(44 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 45_표현식으로 추출 색상일치 각도확인
            alg_params = {
                'EXPRESSION': '"Color_Sur" = "Color_Gui" \r\nAND\r\nabs( if(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360-abs(("Angle_Gui" - "Angle_Sur") % 360), abs(("Angle_Gui" - "Angle_Sur") % 360))) > 45\r\nAND \r\n"Color_Sur" <> \'enemy\' \r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['45'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(45 + Stepnum)
            if feedback.isCanceled():
                return {}


            # 46_필드 값으로 속성 결합 색상일치 각도확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['45']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['46'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(46 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 47_속성으로 중복 삭제 색상일치 각도확인
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['46']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['47'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(47 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 48_필드 계산기 색상일치 각도확인
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Error_Type',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'각도확인'",
                'INPUT': outputs['47']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['48'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(48 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 49_필드 계산기 Mismatch1
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'02_불일치'",
                'INPUT': outputs['48']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['49'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(49 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 50_표현식으로 추출 각도일치 색상확인
            alg_params = {
                'EXPRESSION': '"Color_Sur" <> "Color_Gui"\r\nAND \r\nabs(if(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360 - abs(("Angle_Gui" - "Angle_Sur") % 360), ("Angle_Gui" - "Angle_Sur") % 360)) <= 45 \r\nAND \r\n"Color_Sur" <> \'enemy\' \r\n\n',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['50'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(50 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 51_필드 값으로 속성 결합 각도일치 색상확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['50']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['51'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(51 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 52_필드 값으로 속성 결합 각도일치 색상확인
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['51']['NON_MATCHING'],
                'INPUT_2': outputs['45']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['52'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(52 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 53_필드 계산기 각도일치 색상확인
            alg_params = {
                'FIELD_LENGTH': 10,
                'FIELD_NAME': 'Error_Type',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'색상확인'",
                'INPUT': outputs['52']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['53'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(53 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 54_필드 계산기 Mismatch2
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'02_불일치'",
                'INPUT': outputs['53']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['54'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(54 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 55_벡터 레이어 병합 Mismatch
            alg_params = {
                'CRS': None,
                'LAYERS': [outputs['49']['OUTPUT'],outputs['54']['OUTPUT']],
                'OUTPUT': 'memory:'
            }
            outputs['55'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(55 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 56_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path'],
                'INPUT': outputs['55']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['56'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(56 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 57 비활성화
            feedback.setCurrentStep(57 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 58_표현식으로 추출 색상비매칭
            alg_params = {
                'EXPRESSION': '"Color_Gui" is Null and  "Color_Sur" <> \'enemy\' \r\nor\r\n("Color_Sur" <> "Color_Gui"\r\nand \r\nabs(\r\nif(abs(("Angle_Gui" - "Angle_Sur") % 360) > 180, 360 - abs(("Angle_Gui" - "Angle_Sur") % 360), ("Angle_Gui" - "Angle_Sur") % 360)\r\n) > 45)',
                'INPUT': outputs['40']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['58'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(58 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 59_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['58']['OUTPUT'],
                'INPUT_2': outputs['41']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['59'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(59 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 60_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['59']['NON_MATCHING'],
                'INPUT_2': outputs['45']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['60'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(60 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 61_필드 값으로 속성 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': ['1'],
                'FIELD_2': 'group',
                'INPUT': outputs['60']['NON_MATCHING'],
                'INPUT_2': outputs['50']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'NON_MATCHING': 'memory:'
            }
            outputs['61'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(61 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 62_속성으로 중복 삭제
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['61']['NON_MATCHING'],
                'OUTPUT': 'memory:'
            }
            outputs['62'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(62 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 63_속성으로 추출 other
            alg_params = {
                'FIELD': 'Area',
                'INPUT': outputs['62']['OUTPUT'],
                'OPERATOR': 1,  # ≠
                'VALUE': '매스코',
                'FAIL_OUTPUT': 'memory:',
                'OUTPUT': 'memory:'
            }
            outputs['63'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(63 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 64_필드 삭제 other
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['63']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['64'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(64 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 65_필드 계산기 비매칭
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'05_타권역'",
                'INPUT': outputs['64']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['65'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(65 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 66 비활성화
            feedback.setCurrentStep(66 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 67_최근접 거리를 이용하여 속성을 결합
            # 톨게이트 취근접 결합
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELDS_TO_COPY': ['1'],
                'INPUT': outputs['63']['FAIL_OUTPUT'],
                # 'INPUT_2': 'F:/OneDrive - Masco/일반 - 주단위_DB/주단위_유도선/톨게이트.shp',
                'INPUT_2': TG_shp,
                'MAX_DISTANCE': None,
                'NEIGHBORS': 1,
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['67'] = processing.run('native:joinbynearest', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(67 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 68_속성으로 추출 색상비매칭
            alg_params = {
                'FIELD': 'distance',
                'INPUT': outputs['67']['OUTPUT'],
                'OPERATOR': 4,  # <
                'VALUE': '70',
                'FAIL_OUTPUT': 'memory:',
                'OUTPUT': 'memory:'
            }
            outputs['68'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(68 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 69_필드 삭제 색상불일치 TG
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['68']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['69'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(69 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 70_속성으로 중복 삭제 TG
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['69']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['70'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(70 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 71_필드 계산기 TG
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'04_톨게이트'",
                'INPUT': outputs['70']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['71'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(71 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 72 비활성화
            feedback.setCurrentStep(72 + Stepnum)
            if feedback.isCanceled():
                return {}
            
            # 73_필드 삭제 색상불일치 masco
            alg_params = {
                'COLUMN': ['TYPE','ang_2','유도선_컬러','22년','n','distance','feature_x','feature_y','nearest_x','nearest_y'],
                'INPUT': outputs['68']['FAIL_OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['73'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(73 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 74_속성으로 중복 삭제 masco
            alg_params = {
                'FIELDS': ['group'],
                'INPUT': outputs['73']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['74'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(74 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 75_필드 계산기 masco
            alg_params = {
                'FIELD_LENGTH': 30,
                'FIELD_NAME': 'Class',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'FORMULA': "'03_비매칭'",
                'INPUT': outputs['74']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['75'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(75 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 76 비활성화
            feedback.setCurrentStep(76 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 기반영shp 있다면 > 기반영 객체 이상없으로 처리
            if os.path.exists(exc_shp):
                feedback.pushInfo(f"기반영 예외처리")
                # 77_벡터 레이어 병합 불일치
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['49']['OUTPUT'],outputs['54']['OUTPUT'],outputs['65']['OUTPUT'],outputs['71']['OUTPUT'],outputs['75']['OUTPUT']],
                    'OUTPUT': 'memory:'
                }
                outputs['77'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(77 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 78_위치에 따라 속성 결합 예외 유도선 결합
                # 기반영.shp
                alg_params = {
                    'DISCARD_NONMATCHING': False,
                    'INPUT': outputs['77']['OUTPUT'],
                    'JOIN': exc_shp,
                    'JOIN_FIELDS': ['영상_각도','영상_색상'],
                    'METHOD': 0,  # 일치하는 객체에 대해 각각의 객체 만들기 (one-to-many)
                    'PREDICATE': [0],  # intersect
                    'PREFIX': '',
                    'OUTPUT': 'memory:'
                }
                outputs['78'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(78 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 79_표현식으로 추출 예외 색상일치
                alg_params = {
                    'EXPRESSION': '("Color_Sur" = "영상_색상") \nand \r\nabs(\r\nwith_variable(\'ang\',abs(("영상_각도" - "Angle_Sur") % 360), if( @ang > 180, 360-(@ang), @ang))\r\n) <= 45\r\n\n',
                    'INPUT': outputs['78']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['79'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(79 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 80_속성으로 중복 삭제 예외 일치
                alg_params = {
                    'FIELDS': ['group'],
                    'INPUT': outputs['79']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['80'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(75 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 81_필드 계산기 Match
                alg_params = {
                    'FIELD_LENGTH': 30,
                    'FIELD_NAME': 'Class',
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,  # 텍스트 (string)
                    'FORMULA': "'01_일치'",
                    'INPUT': outputs['80']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['81'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(81 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 82_필드 계산기 Match
                alg_params = {
                    'FIELD_LENGTH': 30,
                    'FIELD_NAME': 'Error_Type',
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,  # 텍스트 (string)
                    'FORMULA': "''",
                    'INPUT': outputs['81']['OUTPUT'],
                    'OUTPUT': 'memory:'
                }
                outputs['82'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(82 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 83_필드 값으로 속성 결합 불일치 예외
                alg_params = {
                    'DISCARD_NONMATCHING': False,
                    'FIELD': 'group',
                    'FIELDS_TO_COPY': ['1'],
                    'FIELD_2': 'group',
                    'INPUT': outputs['77']['OUTPUT'],
                    'INPUT_2': outputs['82']['OUTPUT'],
                    'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                    'PREFIX': '',
                    'NON_MATCHING': 'memory:'
                }
                outputs['83'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(83 + Stepnum)
                if feedback.isCanceled():
                    return {}

                # 84_벡터 레이어 병합
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['43']['OUTPUT'],outputs['82']['OUTPUT'],outputs['83']['NON_MATCHING']],
                    'OUTPUT': 'memory:'
                }
                outputs['84'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(84 + Stepnum)
                if feedback.isCanceled():
                    return {}
            else:
                feedback.pushInfo(f"기반영shp 미존재")
                # 84_벡터 레이어 병합
                alg_params = {
                    'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
                    'LAYERS': [outputs['43']['OUTPUT'],outputs['49']['OUTPUT'],outputs['54']['OUTPUT'],outputs['65']['OUTPUT'],outputs['71']['OUTPUT'],outputs['75']['OUTPUT']],
                    'OUTPUT': 'memory:'
                }
                outputs['84'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                feedback.setCurrentStep(84 + Stepnum)
                if feedback.isCanceled():
                    return {}


            # 85_필드 값으로 속성 결합 1
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'group',
                'FIELDS_TO_COPY': [''],
                'FIELD_2': 'group',
                'INPUT': outputs['37']['OUTPUT'],
                'INPUT_2': outputs['84']['OUTPUT'],
                'METHOD': 1,  # 첫 번째로 일치하는 객체의 속성만 가져오기 (1대1)
                'PREFIX': '',
                'OUTPUT': 'memory:'
            }
            outputs['85'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(85 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 86_속성 테이블에 필드 추가 확인결과
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '확인결과',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['85']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['86'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(86 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 87_속성 테이블에 필드 추가 실제색상
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '실제색상',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['86']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['87'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(87 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 88_속성 테이블에 필드 추가 비고
            alg_params = {
                'FIELD_LENGTH': 200,
                'FIELD_NAME': '비고',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['87']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['88'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(88 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 89_속성 테이블에 필드 추가 작업자
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '작업자',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 2,  # 텍스트 (string)
                'INPUT': outputs['88']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['89'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(89 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 90_속성 테이블에 필드 추가 작업일
            alg_params = {
                'FIELD_LENGTH': 50,
                'FIELD_NAME': '작업일',
                'FIELD_PRECISION': 0,
                'FIELD_TYPE': 4,  # 날짜
                'INPUT': outputs['89']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['90'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(90 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 91_필드 삭제
            alg_params = {
                'COLUMN': ['layer','path','group_2','begin_2','end_2','len_2','Color_Sur_2','Angle_Sur_2','index_2','score_2','RESULT_IMG_2','filepath_2','Coordinate_2','Area_2','count_2','NO_2','date_2','time_2','file_2','NO','len','count'],
                'INPUT': outputs['90']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['91'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(91 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 92_표현식으로 정렬
            alg_params = {
                'ASCENDING': True,
                'EXPRESSION': '"Class" ',
                'INPUT': outputs['91']['OUTPUT'],
                'NULLS_FIRST': False,
                'OUTPUT': 'memory:'
            }
            outputs['92'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(92 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 93_필드 재작성
            alg_params = {
                'FIELDS_MAPPING': [{'expression': '"filepath"','length': 254,'name': 'filepath','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"file"','length': 254,'name': 'file','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"group"','length': 254,'name': 'group','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': 'date','length': 0,'name': 'date','precision': 0,'sub_type': 0,'type': 14,'type_name': 'date'},
                                   {'expression': 'time','length': 8,'name': 'time','precision': 0,'sub_type': 0,'type': 15,'type_name': 'time'},
                                   {'expression': '"Coordinate"','length': 254,'name': 'Coordinate','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Area"','length': 10,'name': 'Area','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"score"','length': 3,'name': 'score','precision': 3,'sub_type': 0,'type': 6,'type_name': 'double precision'},
                                   {'expression': '"mask"','length': 10,'name': 'mask','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},
                                   {'expression': '"Angle_Sur"','length': 10,'name': '영상_각도','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},
                                   {'expression': '"Angle_Gui"','length': 10,'name': '유도선_각도','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},
                                   {'expression': '"Color_Sur"','length': 50,'name': '영상_색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Color_Gui"','length': 50,'name': '유도선_색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Class"','length': 30,'name': 'Class','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"Error_Type"','length': 10,'name': 'Error_Type','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"RESULT_IMG"','length': 254,'name': 'RESULT_IMG','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"확인결과"','length': 50,'name': '확인결과','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"실제색상"','length': 50,'name': '실제색상','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"비고"','length': 254,'name': '비고','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"작업자"','length': 50,'name': '작업자','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'},
                                   {'expression': '"작업일"','length': 50,'name': '작업일','precision': 0,'sub_type': 0,'type': 16,'type_name': 'datetime'}],
                'INPUT': outputs['92']['OUTPUT'],
                'OUTPUT': 'memory:'
            }
            outputs['93'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(93 + Stepnum)
            if feedback.isCanceled():
                return {}

            # 94_벡터 피처를 파일로 저장2
            alg_params = {
                'DATASOURCE_OPTIONS': '',
                'INPUT': outputs['93']['OUTPUT'],
                'LAYER_NAME': '',
                'LAYER_OPTIONS': '',
                'OUTPUT': outputs['7']['CONCATENATION']
            }
            outputs['94'] = processing.run('native:savefeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(94 + Stepnum)
            if feedback.isCanceled():
                return {}

            detectResult.append(outputs['94']['OUTPUT'])
            idx += 1
        print(detectResult)
        # 95_파일 다운로드
        alg_params = {
            'DATA': '',
            'METHOD': 0,  # GET
            'OUTPUT': f'{input_Folder}/{weekNum}.qml',
            'URL': 'https://scshin8.github.io/Qgis/style/colorLane/00_Detection_Results_END.qml'
        }
        outputs['95'] = processing.run('native:filedownloader', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(95 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 96_벡터 레이어 병합
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'LAYERS': detectResult,
            'OUTPUT': f'{input_Folder}/{weekNum}.shp'
        }
        outputs['96'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(96 + Stepnum)
        if feedback.isCanceled():
            return {}
        
        # 결과 병합 후 레이어 경로
        result_path = f'{input_Folder}/{weekNum}.shp'

        # 사용자의 체크박스 선택값 읽기
        add_to_canvas = self.parameterAsBool(parameters, 'ADD_TO_CANVAS', context)

        # 조건에 따라 레이어 로드
        if add_to_canvas and os.path.exists(result_path):
            result_layer = QgsVectorLayer(result_path, weekNum, 'ogr')
            if result_layer.isValid():
                # 스타일 적용 (선택)
                qml_path = f'{input_Folder}/{weekNum}.qml'
                if os.path.exists(qml_path):
                    result_layer.loadNamedStyle(qml_path)
                QgsProject.instance().addMapLayer(result_layer)
            else:
                feedback.reportError('결과 레이어가 유효하지 않습니다.')
                return {}

    def name(self):
        return '영상인식_유도선추출'

    def displayName(self):
        return '영상인식_유도선추출'

    # def group(self):
    #     return '영상인식_유도선추출'

    # def groupId(self):
    #     return '영상인식_유도선추출'

    def createInstance(self):
        return GuidedLine_Extraction()
    

class CreateGPSLayerAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    # 입력 파라미터 ID 정의
    PARAM_LOG_NAME = "LOG_NAME"
    PARAM_LOG = "LOG"
    PARAM_USER_NAME = "USER_NAME"
    PARAM_STYLE_FILE = 'STYLE_FILE'

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        logName = self.Qsettings.value('logName', '')
        log = self.Qsettings.value('log', '')
        userName = self.Qsettings.value('userName', '')

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LOG_NAME,
                "로그명",
                defaultValue=logName  # 기본값 설정
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_LOG,
                "로그",
                defaultValue=log  # 기본값 설정
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_USER_NAME,
                "조사자",
                defaultValue=userName  # 기본값 설정
            )
        )

        # self.addParameter(
        #     QgsProcessingParameterFile(
        #         self.PARAM_STYLE_FILE,
        #         "QML 스타일 파일 (선택)",
        #         extension="qml",
        #         optional=True
        #     )
        # )

    def processAlgorithm(self, parameters, context, feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 입력된 값 가져오기기
        log_name = self.parameterAsString(parameters, self.PARAM_LOG_NAME, context)
        log = self.parameterAsString(parameters, self.PARAM_LOG, context)
        user_name = self.parameterAsString(parameters, self.PARAM_USER_NAME, context)
        # style_file = self.parameterAsString(parameters, self.PARAM_STYLE_FILE, context)

        # 바탕화면 경로로
        desktop_path = os.path.join(os.path.expanduser("~"), "desktop")
        date = '20'+log[2:8]

        # 로그 폴더 경로
        save_dir = f"{desktop_path}/survey/{log_name}/로그/{date}"
        # 로그 저장 경로
        file_path = os.path.join(save_dir, f'{log}.shp')

        # 4326좌표계
        crs = QgsCoordinateReferenceSystem("EPSG:4326")  # 좌표계 설정
        
        #로그 폴더 존재 유무 확인 > 없다면 생성성
        if not os.path.exists(save_dir) and not os.path.exists(file_path):
            os.makedirs(save_dir)  # 폴더 생성
        
            # Route 타일맵 추가
            RouteMap = "RouteMap Basic"
            layers = QgsProject.instance().mapLayersByName(RouteMap) # 레이어 목록중 RouteMap 레이어 탐색
            if layers:
                raster_layer = layers[0]   # 레이어가 있다면 
            else:
                url = "type=xyz&url=https://tiles.routo.com/tile/roadmap_image_basic/v1/{z}/{x}/{y}.webp"
                # XYZ 타일 레이어 생성
                raster_layer = QgsRasterLayer(url, RouteMap, "wms")  # 또는 "xyz"도 가능
                # 레이어가 유효한지 확인 후 프로젝트에 추가
                if raster_layer.isValid():
                    QgsProject.instance().addMapLayer(raster_layer)
                else:
                    feedback.pushWarning("RouteMap을을 추가할 수 없습니다. URL 또는 형식을 확인하세요.")

            self.Qsettings.setValue('logName', log_name)
            self.Qsettings.setValue('log', log)
            self.Qsettings.setValue('userName', user_name)

            new_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", log, "memory")
            provider = new_layer.dataProvider()

            # 추가할 필드와 기본값 정의
            fields_and_expressions = [
                ("log_name","@layer_name", QVariant.String),
                ("user_name",f"'{user_name}'", QVariant.String),

                ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
                ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
                
                ("speed", "round((@position_ground_speed * 3600) / 1000, 0)", QVariant.Int),
                ("angle", "round(@position_direction,0)", QVariant.Int),
                ("x", "x(@position_coordinate)", QVariant.Double),
                ("y", "y(@position_coordinate)", QVariant.Double),
                ("z", "z(@position_coordinate)", QVariant.Double),

                ("grs_lon", 'round("x" * 360000, 0)', QVariant.Int),
                ("grs_lat", 'round("y" * 360000, 0)', QVariant.Int),

                ("map_id", '''
                floor(((floor(round((("grs_lon" - 44617500) / 45000), 0)) - 1) / 8) + 2)
                ||
                floor(((floor(round((("grs_lat" - 11865000) / 30000), 0)) - 1) / 8) + 1)
                ||
                floor(floor((round((("grs_lon" - 44617500) / 45000), 0)) + 8) - (ceil(floor(round((("begrs_lon_lon" - 44617500) / 45000), 0)) / 8) * 8))
                ||
                floor(floor((round((("grs_lat" - 11865000) / 30000), 0)) + 8) - (ceil(floor(round((("grs_lat" - 11865000) / 30000), 0)) / 8) * 8))
                ''', QVariant.Int),

                # ("bes_x", 'x(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
                # ("bes_y", 'y(transform(make_point("x", "y"), \'EPSG:4326\', \'EPSG:4162\'))', QVariant.Double),
                # ("bes_lon", 'round("bes_x" * 360000,0)', QVariant.Int),
                # ("bes_lat", 'round("bes_y" * 360000,0)', QVariant.Int),
                # ("bessel", '''
                # "map_id"||\'(000000)(\'||
                # floor("bes_x")||'.'||
                # floor(("bes_x" - floor("bes_x")) * 60)||'.'||
                # round(((("bes_x" - floor("bes_x")) * 60) - floor(("bes_x" - floor("bes_x")) * 60)) * 60, 2)
                # ||'/'||
                # floor("bes_y")||'.'||
                # floor(("bes_y" - floor("bes_y")) * 60)||'.'||
                # round(((("bes_y" - floor("bes_y")) * 60) - floor(("bes_y" - floor("bes_y")) * 60)) * 60, 2)||')'
                # ''', QVariant.String),

                ("date", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'yyyyMMdd')", QVariant.String),
                ("time", "format_date(to_datetime(@position_timestamp) + to_interval('9 hours'), 'hhmmss')", QVariant.String),
                
                # ("username", "@cloud_username", QVariant.String),
                # ("useremail", "@cloud_useremail", QVariant.String),
                # ("source_name", "@position_source_name", QVariant.String),
                # ("quality_description", "@position_quality_description", QVariant.String),
                ("h_acc", "@position_horizontal_accuracy", QVariant.Double),
                ("v_acc", "@position_vertical_accuracy", QVariant.Double),
                ("3d_acc", "@position_3d_accuracy", QVariant.Double),
                # ("orientation", "@position_orientation", QVariant.Double),
                # ("magnetic_variation", "@position_magnetic_variation", QVariant.Double),
                # ("vertical_speed", "@position_vertical_speed", QVariant.Double),
                # ("averaged_count", "@position_averaged_count", QVariant.Int),
                # ("pdop", "@position_pdop", QVariant.Double),
                # ("hdop", "@position_hdop", QVariant.Double),
                # ("vdop", "@position_vdop", QVariant.Double),
                ("number_of", "@position_number_of_used_satellites", QVariant.Int),
                # ("used_satellites", "@position_used_satellites", QVariant.String),
                # ("fix_status_description", "@position_fix_status_description", QVariant.String),
                # ("fix_mode", "@position_fix_mode", QVariant.String),
                ("flag", "@visible_flag", QVariant.String)
            ]

            # 편집 모드 시작
            new_layer.startEditing()

            # 필드 추가
            for field_name, expr, field_type in fields_and_expressions:
                provider.addAttributes([QgsField(field_name, field_type)])
            new_layer.updateFields()

            # ✅ 스타일 적용
            style_file = os.path.dirname(__file__) + '/style/Qfield_LogStyle.qml'
            if style_file and os.path.exists(style_file):
                applied = new_layer.loadNamedStyle(style_file)
                if applied:
                    feedback.pushInfo(f'레이어 "{log}"에 스타일 적용 완료: {style_file}')
                else:
                    feedback.pushWarning(f'레이어 "{log}" 스타일 적용 실패')
            else:
                feedback.pushWarning("스타일 파일이 제공되지 않았거나 찾을 수 없습니다.")

            # ✅ 기본값(표현식) 설정
            for field_name, expr, field_type in fields_and_expressions:
                idx = new_layer.fields().indexOf(field_name)
                if idx != -1:
                    default = QgsDefaultValue(expr, True)
                    new_layer.setDefaultValueDefinition(idx, default)

            # 스키마 갱신 및 저장
            new_layer.updateFields()
            new_layer.commitChanges()

            file_path = os.path.join(save_dir, f'{log}.shp')  # 파일 경로 설정
            QgsVectorFileWriter.writeAsVectorFormat(new_layer, file_path, "System", new_layer.crs(), "ESRI Shapefile")

            new_qml = os.path.join(save_dir, f'{log}.qml')
            new_layer.saveNamedStyle(new_qml)

            feedback.pushInfo(f'신규 레이어 "{log}" 생성 완료')

            file_path = f"{save_dir}/{log}.shp"  # 불러올 파일의 경로
            layer = QgsVectorLayer(file_path, f"{log}", "ogr")

            pjt = QgsProject.instance()
            pjt.addMapLayer(layer, True)

            # 화면 이동동
            canvas_crs = iface.mapCanvas().mapSettings().destinationCrs()
            transform = QgsCoordinateTransform(crs, canvas_crs, QgsProject.instance())
            x, y = transform.transform(float(128.05235384404628), float(36.241891424775254))
            rect = QgsRectangle(x, y, x, y)
            iface.mapCanvas().setExtent(rect)

            # 축척 1:2000000 로 설정
            iface.mapCanvas().zoomScale(2000000)

            # Qfield 플로그인 복사
            survey_file = os.path.dirname(__file__) + '/style/ONEMAN_SURVEY.qml'
            output_file = f"{save_dir}/{date}_log.qml"
            shutil.copy(survey_file, output_file)

            # 캔버스 새로고침
            iface.mapCanvas().refresh()

            # 현재 캔버스 프로젝트 저장
            project_path = f"{save_dir}/{date}_log.qgz"
            QgsProject.instance().write(project_path)

        else:
            feedback.pushWarning(f'기존파일이 존재합니다.')

        return {}

    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "create_log_layer"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield Log 생성"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return CreateGPSLayerAlgorithm()



class CreateSurveyLinkAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        Daily_GpsLog = self.Qsettings.value('Daily_GpsLog', '')
        Surver_link = self.Qsettings.value('Surver_link', '')

        self.addParameter(QgsProcessingParameterVectorLayer('Gps_log', 'Gps_log', types=[QgsProcessing.TypeVectorPoint], defaultValue=Daily_GpsLog))
        self.addParameter(QgsProcessingParameterVectorLayer('Link_shp', 'Link_shp', types=[QgsProcessing.TypeVectorLine], defaultValue=Surver_link))
        self.addParameter(QgsProcessingParameterFeatureSink('Result', '조사', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Ng', '미조사', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # ——— 출력 레이어 이름 고정 ———
        parameters['Result'].destinationName = '조사'
        parameters['Ng'].destinationName  = '미조사'

        Daily_GpsLog = self.parameterAsVectorLayer(parameters, 'Gps_log', context)
        Surver_link = self.parameterAsVectorLayer(parameters, 'Link_shp', context)

        self.Qsettings.setValue('Daily_GpsLog', Daily_GpsLog)
        self.Qsettings.setValue('Surver_link', Surver_link)

        feedback = QgsProcessingMultiStepFeedback(20, model_feedback)
        results = {}
        outputs = {}

        # 1_�ڵ� ���� �ʵ� �߰�_gps
        alg_params = {
            'FIELD_NAME': 'g_key',
            'GROUP_FIELDS': [''],
            'INPUT': Daily_GpsLog,
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['1'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 2_���̾� ������
        alg_params = {
            'INPUT': outputs['1']['OUTPUT'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'OUTPUT': 'memory:'
        }
        outputs['2'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 3_ǥ�������� ����_���� �α� ����
        alg_params = {
            'EXPRESSION': '"flag" = 1\r\nand\r\n"number_of" >= 5\r\nand\r\n"h_acc" < 20\r\nand\r\n"v_acc" < 20',
            'INPUT': outputs['2']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['3'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}


        # 4_�ڵ� ���� �ʵ� �߰�
        alg_params = {
            'FIELD_NAME': 'l_key',
            'GROUP_FIELDS': [''],
            'INPUT': Surver_link,
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['4'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # 5_���̾� ������
        alg_params = {
            'INPUT': outputs['4']['OUTPUT'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'OUTPUT': 'memory:'
        }
        outputs['5'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # 6_Ư�� ������ ����
        alg_params = {
            'INPUT': outputs['5']['OUTPUT'],
            'VERTICES': '0',
            'OUTPUT': 'memory:'
        }
        outputs['6'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 7_Ư�� ������ ����
        alg_params = {
            'INPUT': outputs['5']['OUTPUT'],
            'VERTICES': '-1',
            'OUTPUT': 'memory:'
        }
        outputs['7'] = processing.run('native:extractspecificvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}
        
        # 8_���� ���̾� ����
        alg_params = {
            'CRS': None,
            'LAYERS': [outputs['6']['OUTPUT'],outputs['7']['OUTPUT']],
            'OUTPUT': 'memory:'
        }
        outputs['8'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}
        
        # 9_����
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 0.01,
            'END_CAP_STYLE': 0,  # �ձ۰�
            'INPUT': outputs['8']['OUTPUT'],
            'JOIN_STYLE': 0,  # �ձ۰�
            'MITER_LIMIT': 2,
            'SEGMENTS': 5,
            'OUTPUT': 'memory:'
        }
        outputs['9'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # 10_�ֱ��� �Ÿ��� �̿��Ͽ� �Ӽ��� ����
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELDS_TO_COPY': ['l_key'],
            'INPUT': outputs['3']['OUTPUT'],
            'INPUT_2': outputs['5']['OUTPUT'],
            'MAX_DISTANCE': 25,
            'NEIGHBORS': 2,
            'PREFIX': '',
            'OUTPUT': 'memory:'
        }
        outputs['10'] = processing.run('native:joinbynearest', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # 11_�ڵ� ���� �ʵ� �߰�_join
        alg_params = {
            'FIELD_NAME': 'j_key',
            'GROUP_FIELDS': [''],
            'INPUT': outputs['10']['OUTPUT'],
            'MODULUS': 0,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': 'memory:'
        }
        outputs['11'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # 12_�ʵ� ����_llnk_angle
        alg_params = {
            'FIELD_LENGTH': 3,
            'FIELD_NAME': 'llnk_angle',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': 'with_variable( \'angle_value\',with_variable(\r\n\t\'angle_deg\',(90-to_int(degrees(atan2( "nearest_y"-"feature_y", "nearest_x"-"feature_x" )))) % 360,if(@angle_deg < 0, @angle_deg + 360 , @angle_deg)),if(@angle_value + 90>360, (@angle_value + 90)-360,(@angle_value + 90)))',
            'INPUT': outputs['11']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['12'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # 13_�ʵ� ����_����
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': '조사',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # �ؽ�Ʈ (string)
            'FORMULA': ' if(abs("angle" - "llnk_angle" ) <= 15 ,\r\n \'조사\',\r\n if(abs("angle" - to_int(("llnk_angle" + 180) % 360))<= 15,\r\n \'조사\',\r\n \'미조사\'))',
            'INPUT': outputs['12']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['13'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # 14_ǥ�������� ����
        alg_params = {
            'EXPRESSION': '"조사" = \'조사\'',
            'INPUT': outputs['13']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['14'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # 15_���̺����� ����Ʈ ����
        alg_params = {
            'INPUT': outputs['14']['OUTPUT'],
            'MFIELD': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:5179'),
            'XFIELD': 'nearest_x',
            'YFIELD': 'nearest_y',
            'ZFIELD': '',
            'OUTPUT':'memory:'
        }
        outputs['15'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}


        # ���� �ε��� ����_15
        alg_params = {
            'INPUT': outputs['15']['OUTPUT']
        }
        outputs['_15'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # ���� �ε��� ����_9
        alg_params = {
            'INPUT': outputs['9']['OUTPUT']
        }
        outputs['_9'] = processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # 16_��ġ�� ����
        alg_params = {
            'INPUT': outputs['_15']['OUTPUT'],
            'INTERSECT': outputs['_9']['OUTPUT'],
            'PREDICATE': [6],  # ����(are within)
            'OUTPUT':'memory:'
        }
        outputs['16'] = processing.run('native:extractbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # 17_�ʵ� ������ �Ӽ� ����
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'j_key',
            'FIELDS_TO_COPY': ['1'],
            'FIELD_2': 'j_key',
            'INPUT': outputs['14']['OUTPUT'],
            'INPUT_2': outputs['16']['OUTPUT'],
            'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
            'PREFIX': '',
            'NON_MATCHING': 'memory:'
        }
        outputs['17'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            return {}

        # 18_�ʵ� ������ �Ӽ� ����
        alg_params = {
            'DISCARD_NONMATCHING': True,
            'FIELD': 'l_key',
            'FIELDS_TO_COPY': ['조사'],
            'FIELD_2': 'l_key',
            'INPUT': outputs['4']['OUTPUT'],
            'INPUT_2': outputs['17']['NON_MATCHING'],
            'METHOD': 1,  # ù ��°�� ��ġ�ϴ� ��ü�� �Ӽ��� �������� (1��1)
            'PREFIX': '',
            'NON_MATCHING': 'memory:',
            'OUTPUT': 'memory:'
        }
        outputs['18'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            return {}

        # 19_�ʵ� ����
        alg_params = {
            'COLUMN': ['l_key'],
            'INPUT': outputs['18']['NON_MATCHING'],
            'OUTPUT': parameters['Ng']
        }
        outputs['_ng'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Ng'] = outputs['_ng']['OUTPUT']

        feedback.setCurrentStep(19)
        if feedback.isCanceled():
            return {}

        # 20_�ʵ� ����
        alg_params = {
            'COLUMN': ['l_key'],
            'INPUT': outputs['18']['OUTPUT'],
            'OUTPUT': parameters['Result']
        }
        outputs['_result'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Result'] = outputs['_result']['OUTPUT']

        # 결과로 넘어온 레이어의 ID
        result_id = results['Result']
        ng_id     = results['Ng']

        # context에서 레이어 객체 꺼내오기
        result_layer = context.getMapLayer(result_id)
        ng_layer     = context.getMapLayer(ng_id)

        # 심벌 정의 (예: 빨간색, 선 두께 0.8)
        sym_result = QgsLineSymbol.createSimple({
            'color': '255,0,0',
            'width': '0.6'
        })
        sym_ng = QgsLineSymbol.createSimple({
            'color': '150,150,150',
            'width': '0.2'
            # 'line_style': 'dash'  # 대시선 스타일 예시 "solid", "dash", "dot", "dashdot", "dashdotdot", "custom" 
            # 'capstyle': 'round',  선 끝 모양. "flat", "square", "round"
            # 'joinstyle': 'bevel',  선이 만나는 모서리 모양. "miter", "bevel", "round"
            # 'offset': '1.0', 선을 원래 위치에서 평행 이동할 거리 (문자열, 기본 단위는 mm)
            # 'offset_unit': 'MM', offset 단위. "MM" 또는 "MapUnit"
            # 'use_custom_dash': '1', customdash 사용 여부. "1" or "0"
            # 'customdash': '4;2;1;2' penstyle이 "custom" 일 때 사용. 대시패턴을 세미콜론으로 구분된 숫자 문자열로 지정 (예: "4;2;1;2")
        })

        # 렌더러 교체
        result_layer.setRenderer(QgsSingleSymbolRenderer(sym_result))
        ng_layer.setRenderer    (QgsSingleSymbolRenderer(sym_ng))

        # 맵 캔버스 갱신
        result_layer.triggerRepaint()
        ng_layer.triggerRepaint()

        return results
    
    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "Daily_Surver_link"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield 조사링크 추출"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return CreateSurveyLinkAlgorithm()



class CopyAttributesByLocationAlgorithm(QgsProcessingAlgorithm):
    """
    원본 피처의 지정 필드 값을 대상 피처의 지정 필드로 복사하는 알고리즘으로,
    사용자가 기존 필드를 선택하거나 신규 필드를 생성할 수 있습니다.
    """

    # 입력 파라미터 ID 정의
    INPUT_SOURCE = 'INPUT_SOURCE'
    FIELD_SOURCE = 'FIELD_SOURCE'
    INPUT_TARGET = 'INPUT_TARGET'
    FIELD_TARGET = 'FIELD_TARGET'
    NEW_FIELD_NAME = 'NEW_FIELD_NAME'
    SPATIAL_RELATION = 'SPATIAL_RELATION'

    # 공간 관계 옵션 (라벨을 한글+영어로 설정)
    SPATIAL_RELATIONS = [
        "교차 (intersects)",
        "중첩 (overlaps)",
        "포함 (contains)",
        "내부 (within)",
        "동등 (equals)",
        "접촉 (touches)",
        "공간 교차 (crosses)"
    ]

    def initAlgorithm(self, config=None):
        """
        알고리즘의 입력 파라미터를 정의합니다.
        """
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_SOURCE,
                '원본 레이어 (속성 복사할 레이어)',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.FIELD_SOURCE,
                '원본 필드',
                parentLayerParameterName=self.INPUT_SOURCE,
                type=QgsProcessingParameterField.Any
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.SPATIAL_RELATION,
                '공간 관계 선택 (복수 선택 가능)',
                options=self.SPATIAL_RELATIONS,
                defaultValue=[0],  # 기본값: "교차 (intersects)"
                allowMultiple=True  # ✅ 다중 선택 활성화
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_TARGET,
                '대상 레이어 (속성 복사될 레이어)',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.FIELD_TARGET,
                '대상 필드 (기존 필드를 사용하려면 선택)',
                parentLayerParameterName=self.INPUT_TARGET,
                type=QgsProcessingParameterField.Any,
                optional=True  # ✅ 선택 가능하도록 변경
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.NEW_FIELD_NAME,
                '신규 필드 이름 (신규 필드를 만들 경우 입력)',
                optional=True  # ✅ 선택 가능하도록 변경
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """
        알고리즘의 핵심 기능을 구현합니다.
        """
        # 파라미터에서 입력값 추출
        source_layer = self.parameterAsVectorLayer(parameters, self.INPUT_SOURCE, context)
        source_field = self.parameterAsString(parameters, self.FIELD_SOURCE, context)
        target_layer = self.parameterAsVectorLayer(parameters, self.INPUT_TARGET, context)
        target_field = self.parameterAsString(parameters, self.FIELD_TARGET, context)
        new_field_name = self.parameterAsString(parameters, self.NEW_FIELD_NAME, context)
        selected_relation_indexes = self.parameterAsEnums(parameters, self.SPATIAL_RELATION, context)

        if source_layer is None or target_layer is None:
            raise QgsProcessingException('입력 레이어를 확인하세요.')

        # 선택한 공간 관계 목록 가져오기
        selected_relations = [self.SPATIAL_RELATIONS[i].split(" ")[1][1:-1] for i in selected_relation_indexes]
        feedback.pushInfo("선택한 공간 관계: {}".format(", ".join(selected_relations)))

        # 대상 필드 결정 (기존 필드를 사용하거나, 새 필드를 생성)
        if not target_field and not new_field_name:
            raise QgsProcessingException('대상 필드를 선택하거나 새 필드 이름을 입력해야 합니다.')

        # 대상 필드가 없는 경우 새 필드 추가
        if new_field_name:
            target_field = new_field_name
            if target_field in [field.name() for field in target_layer.fields()]:
                QMessageBox.critical(None, "오류", f"신규 필드 '{target_field}'가 이미 존재합니다. 실행이 중단됩니다.")
                raise QgsProcessingException(f"신규 필드 '{target_field}'가 이미 존재합니다. 실행이 중단됩니다.")
            else:
                # 신규 필드 추가
                target_layer.startEditing()
                target_layer.addAttribute(QgsField(target_field, QVariant.String))  # 문자열 타입 필드 추가
                target_layer.updateFields()
                feedback.pushInfo(f"새 필드 '{target_field}'을(를) 생성했습니다.")

        # 대상 레이어가 편집 모드가 아니면 편집 모드 전환
        if not target_layer.isEditable():
            target_layer.startEditing()

        # 원본 레이어의 공간 색인 생성 (검색 속도 향상)
        index = QgsSpatialIndex(source_layer.getFeatures())

        # 필드 인덱스 찾기
        source_field_idx = source_layer.fields().lookupField(source_field)
        target_field_idx = target_layer.fields().lookupField(target_field)

        if source_field_idx == -1:
            raise QgsProcessingException('원본 필드명이 올바르지 않습니다.')
        if target_field_idx == -1:
            raise QgsProcessingException('대상 필드가 존재하지 않습니다.')

        # 관계 판별 함수 정의 (선택된 모든 관계 중 하나라도 만족하면 True 반환)
        def check_relation(source_geom, target_geom):
            for relation in selected_relations:
                if relation == "equals" and source_geom.equals(target_geom):
                    return True
                elif relation == "intersects" and source_geom.intersects(target_geom):
                    return True
                elif relation == "contains" and source_geom.contains(target_geom):
                    return True
                elif relation == "within" and source_geom.within(target_geom):
                    return True
                elif relation == "overlaps" and source_geom.overlaps(target_geom):
                    return True
                elif relation == "touches" and source_geom.touches(target_geom):
                    return True
                elif relation == "crosses" and source_geom.crosses(target_geom):
                    return True
            return False

        # 대상 레이어의 각 피처에 대해 복사 실행
        count = 0
        for target_feat in target_layer.getFeatures():
            target_geom = target_feat.geometry()
            if not target_geom:
                continue

            # 대상 피처의 경계 상자와 교차하는 원본 피처 후보 찾기
            candidate_ids = index.intersects(target_geom.boundingBox())
            for fid in candidate_ids:
                source_feat = source_layer.getFeature(fid)
                if not source_feat.geometry():
                    continue
                if check_relation(source_feat.geometry(), target_geom):
                    value = source_feat[source_field_idx]
                    target_layer.changeAttributeValue(target_feat.id(), target_field_idx, value)
                    count += 1
                    break  # 매칭 피처를 찾으면 다음 대상 피처로 넘어감

            # 진행 상황 피드백 (예: 1000개마다)
            if count % 1000 == 0:
                feedback.pushInfo("처리한 피처 수: {}".format(count))
                if feedback.isCanceled():
                    break

        # 변경 내용 저장
        target_layer.commitChanges()
        feedback.pushInfo('속성 복사가 완료되었습니다. 총 {}개 피처 처리됨.'.format(count))
        return {}


    def name(self):
        """
        내부적으로 사용되는 알고리즘의 이름 (영문, 고유값)
        """
        return "copy_attributes_by_location"

    def displayName(self):
        """
        사용자에게 보여질 알고리즘의 이름
        """
        return "위치로 속성 복사"

    def group(self):
        """
        도구 상자에서 표시될 그룹 이름
        """
        return "백터 일반"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "vector_general"

    def createInstance(self):
        """
        알고리즘의 새로운 인스턴스를 반환합니다.
        """
        return CopyAttributesByLocationAlgorithm()

class EVsurveyAlgorithm(QgsProcessingAlgorithm):
    """
    QGIS 툴박스에서 실행 가능한 GPS 신규 레이어 생성 알고리즘
    """
    Qsettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")


    def initAlgorithm(self, config=None):
        """
        툴박스에 표시될 입력 파라미터를 정의
        """
        excel_file = self.Qsettings.value('실사건', '')

        self.addParameter(QgsProcessingParameterFile('1', '실사건 리스트', behavior=QgsProcessingParameterFile.File, fileFilter='XLSX files (*.xlsx);;CSV files (*.csv);;XLTM files (*.xltm)', defaultValue=excel_file))
        self.addParameter(QgsProcessingParameterFeatureSink('Result', '전기차실사건', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))


    def processAlgorithm(self, parameters, context, model_feedback):
        """
        신규 GPS 벡터 레이어를 생성하고 프로젝트에 추가
        """
        # 입력된 값 가져오기기
        excel_file = self.parameterAsFile(parameters, '1', context)
        
        self.Qsettings.setValue('실사건', excel_file)

        parameters['Result'].destinationName = '전기차실사건'

        feedback = QgsProcessingMultiStepFeedback(7, model_feedback)
        results = {}
        outputs = {}


        # 1���ڿ� ���� 01_NODE_STATS.csv
        alg_params = {
            'INPUT_1': excel_file,
            'INPUT_2': '|layername=전기차'
        }
        outputs['01_node_statscsv'] = processing.run('native:stringconcatenation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 2ǥ�������� ����
        alg_params = {
            'EXPRESSION': '"담당" = \'대구\' and "LOG" is Null',
            'INPUT': outputs['01_node_statscsv']['CONCATENATION'],
            'OUTPUT': 'memory:'
        }
        outputs['2'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 3�ʵ� ����
        alg_params = {
            'FIELD_LENGTH': 8,
            'FIELD_NAME': 'Lon',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': ' Fs2Lon( "BESSEL좌표")',
            'INPUT': outputs['2']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['3'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # 4�ʵ� ����
        alg_params = {
            'FIELD_LENGTH': 8,
            'FIELD_NAME': 'Lat',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Integer (32 bit)
            'FORMULA': ' Fs2Lat( "BESSEL좌표")',
            'INPUT': outputs['3']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['4'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # 5�Ӽ� ���̺��� �ʵ� �߰�
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': '조사완료',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # �ؽ�Ʈ (string)
            'INPUT': outputs['4']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['5'] = processing.run('native:addfieldtoattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # 6�ʵ� ����
        alg_params = {
            'COLUMN': ['LOG','층수','실사내역','특이사항','실사완료','입력완료','실사주차(현황용)','보류대상','현황용_1'],
            'INPUT': outputs['5']['OUTPUT'],
            'OUTPUT': 'memory:'
        }
        outputs['6'] = processing.run('native:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 7���̺����� ����Ʈ ����
        alg_params = {
            'INPUT': outputs['6']['OUTPUT'],
            'MFIELD': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('USER:100000'),
            'XFIELD': 'Lon',
            'YFIELD': 'Lat',
            'ZFIELD': '',
            'OUTPUT': parameters['Result']
        }
        outputs['_Result'] = processing.run('native:createpointslayerfromtable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Result'] = outputs['_Result']['OUTPUT']
        return results






    def name(self):
        """
        QGIS에서 고유하게 식별할 알고리즘 이름 (영문)
        """
        return "EV_survey"

    def displayName(self):
        """
        QGIS 툴박스에서 사용자에게 표시될 이름
        """
        return "Qfield 전기차 실사건"

    def group(self):
        """
        QGIS 툴박스에서 속할 그룹 이름
        """
        return "Qfield 도구"

    def groupId(self):
        """
        그룹의 고유 ID (영문)
        """
        return "Qfield_tools"

    def createInstance(self):
        """
        이 클래스를 QGIS에서 인스턴스화할 때 호출되는 메서드
        """
        return EVsurveyAlgorithm()


class ListSubfoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """폴더의 하위 디렉터리 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        subfolders = [f for f in os.listdir(input_folder) if os.path.isdir(os.path.join(input_folder, f))]

        feedback.pushInfo(f"총 {len(subfolders)}개의 하위 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for subfolder in subfolders:
            feature = QgsFeature()
            feature.setAttributes([subfolder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_subfolders"

    def displayName(self):
        return "하위 폴더 목록 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListSubfoldersAlgorithm()

class ListAllFoldersAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        """파라미터 설정"""
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                "폴더 선택",
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "출력 테이블"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """전체 하위 폴더 목록을 가져오는 로직"""
        input_folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        
        if not os.path.isdir(input_folder):
            raise QgsProcessingException("올바른 폴더를 선택하세요.")

        # 🔹 전체 폴더 목록 가져오기
        all_folders = []
        for root, dirs, _ in os.walk(input_folder):
            for directory in dirs:
                full_path = os.path.join(root, directory)
                all_folders.append(full_path)

        feedback.pushInfo(f"총 {len(all_folders)}개의 폴더를 찾았습니다.")

        # 🔹 QGIS 출력 테이블 생성 (필드 정의)
        fields = QgsFields()
        fields.append(QgsField("Folder_Name", QVariant.String))
        fields.append(QgsField("Folder_Path", QVariant.String))

        # 🔹 기본 CRS 설정 (EPSG:4326 사용)
        crs = QgsCoordinateReferenceSystem("EPSG:4326")

        # 🔹 QGIS 처리 결과를 테이블로 출력
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.NoGeometry, crs)

        for folder in all_folders:
            feature = QgsFeature()
            feature.setAttributes([os.path.basename(folder), folder])
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}

    def name(self):
        return "list_all_folders"

    def displayName(self):
        return "모든 하위 폴더 가져오기"

    def group(self):
        return "파일 관리"

    def groupId(self):
        return "file_management"

    def createInstance(self):
        return ListAllFoldersAlgorithm()
