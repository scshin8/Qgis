from qgis.PyQt import uic, QtWidgets

from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsProject)

from PyQt5.QtCore import (QSettings,
                          Qt,
                          QUrl)

from PyQt5.QtGui import QIcon

from PyQt5.QtWidgets import (QApplication,
                             QLineEdit,
                             QToolButton)

from qgis.PyQt.QtWidgets import QMessageBox

import os.path , webbrowser

from .Coordinate_Tool_Function import capture, Coordinate_function

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_info.ui'))

class CoordinateToolinfo(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(CoordinateToolinfo, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.clipboard = QApplication.clipboard()
        self.Function = Coordinate_function(self,iface)
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        # self.conversionSetting = conversionSetting(self,iface)

        self.pushButton.clicked.connect(self.conversion)#(self.valdel)

        self.captureCoordinate = capture(self.canvas)
        self.captureCoordinate.capturePoint.connect(self.capturedPoint)
        self.captureCoordinate.captureStopped.connect(self.stopCapture)
        self.captureCoordinate.captureStopped1.connect(self.stopCapture1)

        # 좌표캡쳐
        self.toolButton_1.setIcon(QIcon(os.path.dirname(__file__) + "/icons/point.png"))
        self.toolButton_1.clicked.connect(self.capture)
        # 변환값 삭제
        self.toolButton_2.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.toolButton_2.clicked.connect(lambda : self.valdel(0))#(self.valdel)
        # 좌표지점 확대
        self.toolButton_3.setIcon(QIcon(os.path.dirname(__file__) + "/icons/move.png"))
        self.toolButton_3.clicked.connect(self.move)
        #설정창 열기
        # self.toolButton_4.setIcon(QIcon(os.path.dirname(__file__) + "/icons/setting.png"))
        # self.toolButton_4.clicked.connect(self.setting)
        
        idx = int(self.QSettings.value('AddressSearchComboBox_2', 0))
        self.AddressSearchComboBox_2.setCurrentIndex(idx)
        self.AddressSearchComboBox_2.currentIndexChanged.connect(self.AddressSearchAPIChange)
        
        # self.lineEdit_24.setClearButtonEnabled(True)
        
        #네이버URL복사,지도열기
        self.toolButton_21.setIcon(QIcon(os.path.dirname(__file__) + "/icons/naver.png"))
        self.toolButton_21.clicked.connect(lambda : self.webbrowseropen(self.lineEdit_21))
        #카카오URL복사,지도열기
        self.toolButton_22.setIcon(QIcon(os.path.dirname(__file__) + "/icons/kakao.png"))
        self.toolButton_22.clicked.connect(lambda : self.webbrowseropen(self.lineEdit_22))
        #카카오로드뷰URL복사,지도열기
        self.toolButton_23.setIcon(QIcon(os.path.dirname(__file__) + "/icons/kakao.png"))
        self.toolButton_23.clicked.connect(lambda : self.webbrowseropen(self.lineEdit_23))
        #좌표,변환값 복사
        icon = QIcon(os.path.dirname(__file__) + "/icons/duplicateALL.png")
        for i in range(5,21):
            self.findChild(QToolButton,'toolButton_'+str(i)).setIcon(icon)
        self.toolButton_5.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_5))
        self.toolButton_6.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_6))
        self.toolButton_7.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_7))
        self.toolButton_8.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_8))
        self.toolButton_9.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_9))
        self.toolButton_10.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_10))
        self.toolButton_11.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_11))
        self.toolButton_12.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_12))
        self.toolButton_13.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_13))
        self.toolButton_14.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_14))
        self.toolButton_15.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_15))
        self.toolButton_16.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_16))
        self.toolButton_17.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_17))
        self.toolButton_18.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_18))
        self.toolButton_19.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_19))
        self.toolButton_20.clicked.connect(lambda : self.toolButtoncopy(self.lineEdit_20))

        self.mQgsProjectionSelectionWidget_2.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('CONinCRS','EPSG:4326')))
        self.mQgsProjectionSelectionWidget.setCrs(QgsCoordinateReferenceSystem(self.QSettings.value('CONcustomCRS','EPSG:4326')))

        self.address_checkBox.setCheckState(int(self.QSettings.value('CONaddress_checkBox', Qt.Checked))) #Qt.Unchecked
        
# 주소 변환 체크시 addresscheckBox 실행
        self.address_checkBox.stateChanged.connect(self.addresscheckBox)
# 입력 좌표계 변환시 inCRS 실행
        self.mQgsProjectionSelectionWidget_2.crsChanged.connect(self.inCRS)
# 커스텀 좌표계 변환시 setcustomCRS 실행
        self.mQgsProjectionSelectionWidget.crsChanged.connect(self.setcustomCRS) 
# 주소 변환 체크시 해당 체크값 저장
    def addresscheckBox(self):
        self.QSettings.setValue('CONaddress_checkBox', self.address_checkBox.checkState())
        
# 입력 좌표계 변환시 해당좌표계 저장
    def inCRS(self):
        self.QSettings.setValue('CONinCRS', self.mQgsProjectionSelectionWidget_2.crs().authid())

# 커스텀 좌표계 변환시 해당좌표계 저장
    def setcustomCRS(self):
        self.QSettings.setValue('CONcustomCRS', self.mQgsProjectionSelectionWidget.crs().authid())
        
    def closeEvent(self, e):
        self.CTool.Delete_Marker()
        if self.savedMapTool:
            self.canvas.setMapTool(self.savedMapTool)
            self.savedMapTool = None
        
# 아이콘 클릭으로 캡쳐 중단
    def stopCapture(self):
        self.CTool.Delete_Marker()
        self.toolButton_1.setChecked(False)

# ESC 눌러서 캡쳐 중단
    def stopCapture1(self):
        self.CTool.Delete_Marker()
        self.toolButton_1.setChecked(False)    
        self.iface.actionPan().trigger()

    def capture(self):
        self.valdel(1)
        if self.toolButton_1.isChecked():
            self.savedMapTool = self.canvas.mapTool()
            self.canvas.setMapTool(self.captureCoordinate)
        else:
            if self.savedMapTool:
                self.canvas.setMapTool(self.savedMapTool)
                self.savedMapTool = None

    def conversion(self):
        self.CTool.Delete_Marker()
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        setCRS = QgsCoordinateReferenceSystem(self.QSettings.value('CONinCRS','EPSG:4326'))
        text=self.lineEdit_24.text()
        if text != '':
            
            lon, lat= self.Function.setval(setCRS,text)
              
            Trans = QgsCoordinateTransform(setCRS, canvas_crs, QgsProject.instance())
            point = Trans.transform(float(lon), float(lat))
            self.capturedPoint(point)
        else:
            pass

# 변환값 삭제
    def valdel(self,idx):
        if idx == 0:
            self.stopCapture1()
            for i in range(5,25):
                self.findChild(QLineEdit,'lineEdit_'+str(i)).clear()
        elif idx == 1:
            self.lineEdit_24.clear()
        elif idx == 2:
            for i in range(5,24):
                self.findChild(QLineEdit,'lineEdit_'+str(i)).clear()

# 변환 지점 이동
    def move(self):
        self.stopCapture1()
        if self.lineEdit_5.text() != '':
            pt=self.lineEdit_5.text()
            lon=pt.split(',')[0]
            lat=pt.split(',')[1]
            setCRS = self.canvas.mapSettings().destinationCrs()
            Order=0
            self.Function.moveto(setCRS, lon, lat, Order)

    def AddressSearchAPIChange(self):  
        idx = int(self.AddressSearchComboBox_2.currentIndex())
        self.QSettings.setValue('AddressSearchComboBox_2', idx)

# 웹지도 열기
    def webbrowseropen(self,lineEdit):
        self.stopCapture1()
        url=lineEdit.text()
        self.clipboard.setText(url)
        self.iface.statusBarIface().showMessage(f"'{url}' copied to the clipboard", 3000)
        url = QUrl(url).toString()
        webbrowser.open(url, new = 0, autoraise=True)#, autoraise = False )

# 변환값 저장
    def toolButtoncopy(self,objectName):
        self.stopCapture1()
        text=objectName.text()
        self.clipboard.setText(text)
        self.iface.statusBarIface().showMessage(f"'{text}' copied to the clipboard", 3000)

# 좌표 값 변환
    def capturedPoint(self, point):
        self.CTool.Draw_Marker(point,1)
        self.valdel(2)
        if self.isVisible():
            # 1.프로젝트좌표값
            self.updatelonlat(1, point)
            
            # 2.커스텀좌표값
            projCRS = self.canvas.mapSettings().destinationCrs()
            customCRS = self.mQgsProjectionSelectionWidget.crs()
            if customCRS == projCRS:
                custompoint = point
            else:
                Trans = QgsCoordinateTransform(projCRS, customCRS, QgsProject.instance())
                custompoint = Trans.transform(point.x(), point.y())
            self.updatelonlat(2, custompoint)
            
            # 3.베셀좌표
            Trans = QgsCoordinateTransform(projCRS, epsg4162, QgsProject.instance())
            besselpoint = Trans.transform(point.x(), point.y())
            Lon , Lat = self.Function.mmscoordinate(besselpoint)
            self.updatelonlat(13, '('+str(Lon)+','+ str(Lat)+')')
            fs = self.Function.fscoordinate(besselpoint)
            self.updatelonlat(3, fs)
            
            # 4.GRS좌표
            Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
            GRSpoint = Trans.transform(point.x(), point.y())
            Lon , Lat = self.Function.mmscoordinate(GRSpoint)
            self.updatelonlat(14, '('+str(Lon)+','+ str(Lat)+')')
            fs = self.Function.fscoordinate(GRSpoint)
            self.updatelonlat(4, fs)
            
            # 5.WGS84_Y,X
            WGS84_x=GRSpoint[0]
            WGS84_y=GRSpoint[1]
            latlon=(str(float(WGS84_y))+','+str(float(WGS84_x)))
            self.updatelonlat(5,latlon)
            
            # 6.네이버URL
            naverURL=f'https://map.naver.com/v5/entry/coordinate/{WGS84_x},{WGS84_y}?c={WGS84_x},{WGS84_y},15,0,0,0,dh'
            self.updatelonlat(6,naverURL)

            # 7.kakaoURL
            kakaoURL=f'https://map.kakao.com/?&map_type=TYPE_MAP&q={WGS84_y},{WGS84_x}'
            self.updatelonlat(7,kakaoURL)

            # 8.kakaoRoadViewURL
            kakaoRoadViewURL=f'https://map.kakao.com/link/roadview/{WGS84_y},{WGS84_x}'
            self.updatelonlat(8,kakaoRoadViewURL)

            # 9.주소
            checkBox=int(self.QSettings.value('CONaddress_checkBox', Qt.Checked))
            if checkBox==2:
                APIidx=int(self.QSettings.value('AddressSearchComboBox_2', 0))
                try:
                    ctp, sig, roadaddress, jibunaddress = (self.Function.kakaojoso(GRSpoint) if APIidx == 0 else 
                                                            self.Function.naverjoso(GRSpoint) if APIidx == 1 else 
                                                            self.Function.vworldjoso(GRSpoint) if APIidx == 2 else 
                                                            self.Function.Routojoso(GRSpoint))
                        
                    self.updatelonlat(9,ctp)
                    self.updatelonlat(10,sig)
                    self.updatelonlat(11,roadaddress)
                    self.updatelonlat(12,jibunaddress)
                except :
                    QMessageBox.critical(self.iface.mainWindow(), "Error")

        self.CTool.Delete_Marker_Shot(1000)
        
# 변환된 값 화면 표시 
    def updatelonlat(self, id, point):
        if id == 1 or id == 2:
            lon = format(point[0])
            lat = format(point[1])
            lonlat=(str(float(lon))+','+str(float(lat)))
            self.lineEdit_5.setText(lonlat) if id == 1 else self.lineEdit_6.setText(lonlat)

        if id == 3:
            self.lineEdit_7.setText(point)
            map, company, team, ctp, sig = self.Function.mapidinfo(point)
            self.lineEdit_12.setText(map)
            self.lineEdit_13.setText(company)
            self.lineEdit_14.setText(team)
            self.lineEdit_15.setText(ctp)
            self.lineEdit_16.setText(sig)
            
        if id == 4: self.lineEdit_9.setText(point)
        elif id == 5: self.lineEdit_11.setText(point)
        elif id == 6: self.lineEdit_21.setText(point) 
        elif id == 7: self.lineEdit_22.setText(point)  
        elif id == 8: self.lineEdit_23.setText(point)
        elif id == 9: self.lineEdit_17.setText(point)  
        elif id == 10: self.lineEdit_18.setText(point)  
        elif id == 11: self.lineEdit_19.setText(point)
        elif id == 12: self.lineEdit_20.setText(point)
        elif id == 13: self.lineEdit_8.setText(point)
        elif id == 14: self.lineEdit_10.setText(point)