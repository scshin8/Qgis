# -*- coding: utf-8 -*-
import os
import logging
from logging.handlers import RotatingFileHandler
import math
from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import (QMainWindow, QWidget, 
                             QMenu, QAction, QMessageBox, QDialog, QApplication, QFileDialog)
from openpyxl import Workbook

from qgis.utils import iface

from qgis.core import *
from qgis.gui import *

# 대시보드 통계 처리를 위해 GroupStats 파일에서 필요한 클래스와 함수를 가져옵니다.
from .Coordinate_Tool_GroupStats import (
    ModelListaPol, ModelRowsColumns, ValueModel, ResultModel,
    Calculations, sort_values_nulls_last, ExcelFilterDialog
)

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/Coordinate_Tool_TaskManager.ui'))

class CoordinateToolTaskManager(QMainWindow):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.ui = FORM_CLASS()
        self.ui.setupUi(self)
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        # 레이어별 캐싱 데이터를 보관할 딕셔너리 생성
        self.all_layers_cache = {}
        self.current_connected_layer = None # --- 새로 추가: 시그널 관리용 변수 ---

        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.ui.layer.currentIndexChanged.connect(self.layerSelection)

        # ==========================================
        # 설정 탭 자동 저장/불러오기 초기화 및 시그널 연결
        # ==========================================
        # 1. 창이 열릴 때 저장된 설정값 불러오기
        self.load_settings()

        # 2. 내용이 변경될 때마다 자동으로 저장되도록 시그널 연결 (QLineEdit)
        self.ui.userField.textChanged.connect(self.save_settings)
        self.ui.completeField.textChanged.connect(self.save_settings)
        self.ui.startField.textChanged.connect(self.save_settings)
        self.ui.endField.textChanged.connect(self.save_settings)

        self.ui.userField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.completeField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.startField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.endField_lineEdit.textChanged.connect(self.save_settings)

        # 3. 콤보박스 선택이 변경될 때마다 자동 저장 (QComboBox)
        self.ui.userField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.completeField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.startField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.endField_type.currentIndexChanged.connect(self.save_settings)

        self.ui.select_pushButton.clicked.connect(self.distribute_selected_features)
        self.ui.type_comboBox.currentIndexChanged.connect(self.save_settings)
        # ==========================================
        # 1. 작업자 관리 (분배 탭) 초기화
        # ==========================================
        user_data = self.QSettings.value('Tesk_User', '')
        user_list = []
        if isinstance(user_data, str) and user_data.strip():
            user_list = [u.strip() for u in user_data.split(',')]
        elif isinstance(user_data, list):
            user_list = [str(u) for u in user_data]
        user_list.sort(reverse=False)
        self.user_model = QStringListModel()
        self.user_model.setStringList(user_list)
        self.ui.user_listView.setModel(self.user_model)

        self.ui.user_add.clicked.connect(self.addUser)
        self.ui.user_del.clicked.connect(self.deleteUser)

        # --- 새로 추가할 클릭 이벤트 연결 ---
        self.ui.user_listView.clicked.connect(self.on_user_clicked)
        
        # [핵심 추가 코드] 키보드 방향키 이동 시에도 클릭과 동일하게 동작하도록 연결
        self.ui.user_listView.selectionModel().currentChanged.connect(
            lambda current, previous: self.on_user_clicked(current)
        )

        self.ui.move_pushButton.clicked.connect(self.move_to_working_objects)
        self.ui.complete_pushButton.clicked.connect(self.complete_working_objects)

        # ==========================================
        # 2. 대시보드(통계 탭) 연동 초기화
        # ==========================================
        self.calculations = Calculations(self)

        # 드래그 앤 드롭 활성화
        self.ui.listHalf.setAcceptDrops(True)
        self.ui.listHalf.setModelColumn(2)
        self.ui.rows.setAcceptDrops(True)
        self.ui.columns.setAcceptDrops(True)
        self.ui.values.setAcceptDrops(True)

        # 필드 리스트 및 구역 모델 세팅
        self.tm1 = ModelListaPol(self)
        self.ui.listHalf.setModel(self.tm1)

        self.tm2 = ModelRowsColumns(self)
        self.ui.rows.setModel(self.tm2)

        self.tm3 = ModelRowsColumns(self)
        self.ui.columns.setModel(self.tm3)

        self.tm4 = ValueModel(self)
        self.ui.values.setModel(self.tm4)

        self.tm2.setOtherModels(self.tm3, self.tm4)
        self.tm3.setOtherModels(self.tm2, self.tm4)
        self.tm4.setOtherModels(self.tm2, self.tm3)

        # 구역 갱신에 따른 계산 버튼 활성화 시그널 연결
        self.tm2.rowsInserted.connect(self.blockCalculations)
        self.tm3.rowsInserted.connect(self.blockCalculations)   
        self.tm4.rowsInserted.connect(self.blockCalculations)   
        self.tm2.rowsRemoved.connect(self.blockCalculations)   
        self.tm3.rowsRemoved.connect(self.blockCalculations)   
        self.tm4.rowsRemoved.connect(self.blockCalculations)

        # 대시보드 주요 버튼 이벤트 연동
        self.ui.calculate.clicked.connect(self.showScore)
        self.ui.filterButton.clicked.connect(self.setFilter)
        self.ui.filter_del.clicked.connect(self.delFilter)

        # 리스트 더블클릭 이벤트 연동
        self.ui.listHalf.doubleClicked.connect(self.addFieldFromList)
        self.ui.rows.doubleClicked.connect(self.removeItemFromList)
        self.ui.columns.doubleClicked.connect(self.removeItemFromList)
        self.ui.values.doubleClicked.connect(self.removeItemFromList)
        
        # 테이블(tableView) 헤더 정렬 시그널
        self.ui.tableView.setSortingEnabled(True)
        self.ui.tableView.verticalHeader().sortIndicatorChanged.connect(self.sortRows)

        # --- 새로 추가: 테이블 우클릭 메뉴 시그널 ---
        self.ui.tableView.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.tableView.customContextMenuRequested.connect(self.show_context_menu)
        self.ui.user_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.user_result.customContextMenuRequested.connect(self.show_user_result_context_menu)
        self.ui.select_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.select_result.customContextMenuRequested.connect(self.show_select_result_context_menu)
        # =========================================================

        # --- [새로 추가] UI 상단 메뉴바 액션 연결 ---
        self.ui.actionCopy.triggered.connect(self.duplication)   
        self.ui.actionCopySelected.triggered.connect(self.copyMarked)   
        self.ui.actionSaveExcel.triggered.connect(self.exportToExcel)   
        self.ui.actionSaveExcelSelected.triggered.connect(self.exportMarkedToExcel)
        self.ui.actionExport.triggered.connect(self.exportToLayer)
        self.ui.actionShowOnMap.triggered.connect(self.showOnMap)

        self.ui.refresh.clicked.connect(self.refresh_layer_cache)

        self.ui.folder_pushButton.clicked.connect(self.open_export_folder)

    def open_export_folder(self):
        """설정된 내보내기 경로의 오늘 날짜 폴더를 윈도우 탐색기에서 엽니다."""
        base_path = self.ui.mQgsFileWidget_export.filePath() # 설정된 기본 경로
        
        if not base_path or not os.path.exists(base_path):
            QMessageBox.warning(self, "경고", "내보내기 경로가 설정되지 않았거나 존재하지 않습니다.")
            return

        # 오늘 날짜 문자열 생성 (기존 분배 로직과 동일하게 yyyyMMdd 사용)
        today_str = QDate.currentDate().toString("yyyyMMdd")
        date_dir = os.path.join(base_path, today_str)

        # 1. 오늘 날짜 폴더가 있으면 해당 폴더를 엶
        if os.path.exists(date_dir):
            target_path = date_dir
        # 2. 오늘 날짜 폴더가 없으면 상위 경로인 base_path를 엶
        else:
            target_path = base_path
            self.statusBar().showMessage(f"오늘 날짜({today_str}) 폴더가 없어 기본 경로를 엽니다.", 3000)

        # 윈도우 탐색기 실행
        os.startfile(os.path.normpath(target_path))
        
    # 3. 레이어 정보 가져오기 (안정성 강화)
    def get_current_layer_info(self):
        layer_index = self.ui.layer.currentIndex()
        if layer_index <= 0:
            return None, None
        
        layer_id = self.ui.layer.itemData(layer_index)
        layer = QgsProject.instance().mapLayer(layer_id)
        
        # 레이어가 유효한지 + 실제로 프로젝트에 존재하는지 이중 체크
        if not layer or not layer.isValid():
            self.statusBar().showMessage("유효하지 않은 레이어입니다.", 3000)
            return None, None
                
        return layer, layer_id
    def refresh_layer_cache(self):
        """새로고침 버튼 클릭 시 대시보드 세팅을 유지한 채 캐시 데이터만 강제로 다시 긁어옵니다."""
        index = self.ui.layer.currentIndex()
        if index == -1:
            self.statusBar().showMessage("새로고침할 레이어가 선택되지 않았습니다.", 3000)
            return
            
        layer_id = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer:
            return
        layer.commitChanges()
        self.statusBar().showMessage("레이어 데이터를 강제로 새로고침 하는 중입니다. 잠시만 기다려주세요...")
        QCoreApplication.processEvents() # UI 프리징 방지
        
        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        provider = layer.dataProvider()
        
        total_features = provider.featureCount()
        if total_features < 0:
            total_features = layer.featureCount()

        new_cache = []
        counter = 0

        # 원본 레이어에서 최신 데이터를 다시 수집
        for f in provider.getFeatures(request):
            new_cache.append({
                'id': f.id(),
                'attributes': f.attributes()
            })
            counter += 1
            if counter % 1000 == 0:
                if total_features > 0:
                    percent = (counter / total_features) * 100
                    self.statusBar().showMessage(f"새로고침 중... {percent:.1f}% ({counter:,} / {total_features:,})")
                else:
                    self.statusBar().showMessage(f"새로고침 중... {counter:,}개 완료")
                QCoreApplication.processEvents()

        # 기존 캐시 변수를 새로운 데이터로 완벽히 덮어쓰기
        self.all_layers_cache[layer_id] = new_cache
        self.cached_features = new_cache
        
        # 1. 만약 대시보드 통계(값 영역)가 설정되어 있다면 즉시 재계산하여 표 갱신
        if hasattr(self, 'tm4') and len(self.tm4._data) > 0:
            self.showScore()
            self.statusBar().showMessage("레이어 캐시가 갱신되었으며, 대시보드 통계가 업데이트되었습니다.", 5000)
        else:
            self.statusBar().showMessage("레이어 캐시 데이터가 강제로 새로고침 되었습니다.", 5000)
            
        # 2. 맵 화면에 선택된 객체가 있다면 우측 하단 '선택 객체 통계'도 즉시 갱신
        self.on_selection_changed()

    # ==========================================
    # 작업자 관리 기능 메서드 (기존 기능 유지)
    # ==========================================
    def addUser(self):
        new_name = self.ui.user_lineEdit.text().strip()
        if not new_name:
            self.statusBar().showMessage("추가할 이름을 입력해주세요.", 3000)
            return
        current_list = self.user_model.stringList()
        if new_name in current_list:
            self.statusBar().showMessage("이미 존재하는 이름입니다.", 3000)
            return
        current_list.append(new_name)
        current_list.sort(reverse=False)

        self.user_model.setStringList(current_list)
        save_data = ",".join(current_list)
        self.QSettings.setValue('Tesk_User', save_data)
        self.ui.user_lineEdit.clear()
        self.statusBar().showMessage(f"'{new_name}' 작업자가 추가되었습니다.", 3000)

    def deleteUser(self):
        target_name = self.ui.user_lineEdit.text().strip()
        current_list = self.user_model.stringList()
        if not target_name:
            self.statusBar().showMessage("삭제할 이름을 입력해주세요.", 3000)
            return
        if target_name in current_list:
            current_list.remove(target_name)
            self.user_model.setStringList(current_list)
            save_data = ",".join(current_list)
            self.QSettings.setValue('Tesk_User', save_data)
            self.ui.user_lineEdit.clear()
            self.statusBar().showMessage(f"'{target_name}' 작업자가 삭제되었습니다.", 3000)
        else:
            self.statusBar().showMessage("삭제할 대상을 찾을 수 없습니다.", 3000)

    def on_user_clicked(self, index):
        """작업자 리스트 클릭 시 통계를 계산하여 테이블에 표시합니다."""
        if not index.isValid(): return

        selected_user = index.data(Qt.DisplayRole)
        val_field_name = self.ui.Field.currentField()
        user_field_name = self.ui.userField.text().strip()
        comp_field_name = self.ui.completeField.text().strip()
        
        if not val_field_name or not user_field_name or not comp_field_name:
            self.statusBar().showMessage("통계를 내기 위한 설정 탭의 필드명을 모두 입력/선택해 주세요.", 5000)
            return

        layer, layer_id = self.get_current_layer_info()
        if not layer: return
        if layer_id not in self.all_layers_cache: return

        stats = {}
        
        self.ui.label_8.setText(f'작업자 통계_{selected_user}')
        for f_dict in self.all_layers_cache[layer_id]:
            attrs = f_dict['attributes']
            try:
                layer = QgsProject.instance().mapLayer(layer_id)
                u_idx = layer.fields().indexOf(user_field_name)
                c_idx = layer.fields().indexOf(comp_field_name)
                v_idx = layer.fields().indexOf(val_field_name)
                
                if u_idx == -1 or c_idx == -1 or v_idx == -1:
                    self.ui.log_textEdit.setPlainText("")
                    return

                raw_user = attrs[u_idx]
                user_val = str(raw_user).strip() if raw_user is not None else ""

                if user_val == selected_user:
                    raw_comp = attrs[c_idx]
                    status = str(raw_comp).strip() if raw_comp is not None else ""
                    
                    # --- 수정된 부분: 값이 없거나 NULL이면 '작업중'으로 간주 ---
                    if not status or status.upper() == 'NULL': 
                        status = "작업중"
                    
                    val = attrs[v_idx]
                    numeric_val = 0.0
                    try: numeric_val = float(val)
                    except (ValueError, TypeError): pass

                    if status not in stats:
                        stats[status] = {'count': 0, 'sum': 0.0, 'ids': []}
                        
                    stats[status]['count'] += 1
                    stats[status]['sum'] += numeric_val
                    stats[status]['ids'].append(f_dict['id']) # ID 수집

            except Exception: pass

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([comp_field_name, 'Count', 'Sum'])
        
        for status, data in stats.items():
            item_status = QStandardItem(status)
            # [핵심] 해당 상태에 속한 모든 객체 ID를 숨겨둠
            item_status.setData(data['ids'], Qt.UserRole)

            item_count = QStandardItem(str(data['count']))
            s_val = data['sum']
            sum_str = f"{int(s_val)}" if s_val.is_integer() else f"{s_val:.2f}"
            item_sum = QStandardItem(sum_str)
            item_count.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item_sum.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            model.appendRow([item_status, item_count, item_sum])
            
        self.ui.user_result.setModel(model)
        self.ui.user_result.setSortingEnabled(True)
        self.ui.user_result.sortByColumn(0, Qt.DescendingOrder)
        self.ui.user_result.resizeColumnsToContents()
        self.statusBar().showMessage(f"'{selected_user}' 작업자의 통계가 갱신되었습니다.", 3000)

        # =========================================================
        # [핵심 수정 코드] 백업된 로그 파일까지 모두 순서대로 읽어와 필터링하여 출력
        # =========================================================
        log_dir = QgsApplication.qgisSettingsDirPath()
        log_messages = []
        
        if log_dir and os.path.exists(log_dir):
            base_log_name = "TaskManager_Log.txt"
            log_files_to_read = []
            
            # 1. 백업 파일들 찾기 (설정한 backupCount=3에 맞춰 역순으로 탐색: .3 -> .2 -> .1)
            for i in range(3, 0, -1):
                backup_file = os.path.join(log_dir, f"{base_log_name}.{i}")
                if os.path.exists(backup_file):
                    log_files_to_read.append(backup_file)
                    
            # 2. 마지막으로 현재 기록 중인 메인 로그 파일 추가
            active_log_file = os.path.join(log_dir, base_log_name)
            if os.path.exists(active_log_file):
                log_files_to_read.append(active_log_file)

            # 3. 수집된 파일들을 과거부터 최신 순으로 읽어들이기
            if log_files_to_read:
                for file_path in log_files_to_read:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            lines = f.readlines()
                            for line in lines:
                                if f"작업자: {selected_user}" in line:
                                    log_messages.append(line.strip())
                    except Exception as e:
                        log_messages.append(f"로그 파일({os.path.basename(file_path)}) 읽기 오류: {e}")
            else:
                log_messages.append("아직 생성된 로그 파일(TaskManager_Log.txt)이 없습니다.")
        else:
            log_messages.append("설정 탭에서 '로그 저장' 경로를 먼저 설정해 주세요.")

        # 추출한 기록을 텍스트 에디터(log_textEdit)에 반영합니다.
        # 오류 메시지나 안내 메시지가 아닌 실제 로그 데이터가 있을 경우에만 최신순(역순) 정렬
        if log_messages and not log_messages[0].startswith("아직") and not log_messages[0].startswith("설정"):
            # 가장 최신 기록이 맨 위로 올라오게 리스트 순서를 뒤집습니다.
            log_messages.reverse() 
            self.ui.log_textEdit.setPlainText("\n".join(log_messages))
        elif log_messages:
            self.ui.log_textEdit.setPlainText(log_messages[0])
        else:
            self.ui.log_textEdit.setPlainText(f"'{selected_user}' 작업자에 대한 분배/취합 로그 기록이 없습니다.")
        # =========================================================

    def move_to_working_objects(self):
        """선택한 작업자의 '작업중' 상태(빈 값 포함)인 객체를 찾아 화면을 이동합니다."""
        selected_indexes = self.ui.user_listView.selectedIndexes()
        if not selected_indexes:
            self.statusBar().showMessage("리스트에서 작업자를 먼저 선택해 주세요.", 3000)
            return
            
        selected_user = selected_indexes[0].data(Qt.DisplayRole)
        user_field_name = self.ui.userField.text().strip()
        comp_field_name = self.ui.completeField.text().strip()
        
        layer, layer_id = self.get_current_layer_info()
        if not layer: return

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer or layer_id not in self.all_layers_cache: return

        u_idx = layer.fields().indexOf(user_field_name)
        c_idx = layer.fields().indexOf(comp_field_name)
        if u_idx == -1 or c_idx == -1: return

        target_ids = []
        for f_dict in self.all_layers_cache[layer_id]:
            attrs = f_dict['attributes']
            
            raw_user = attrs[u_idx]
            raw_comp = attrs[c_idx]
            
            user_val = str(raw_user).strip() if raw_user is not None else ""
            comp_val = str(raw_comp).strip() if raw_comp is not None else ""

            # --- 수정된 부분: 작업자가 일치하고, (완료값이 '작업중' 이거나 비어있으면) 이동 대상 ---
            if user_val == selected_user and (comp_val == '작업중' or not comp_val or comp_val.upper() == 'NULL'):
                target_ids.append(f_dict['id'])

        if not target_ids:
            self.statusBar().showMessage(f"'{selected_user}' 작업자의 '작업중'인 객체가 없습니다.", 3000)
            return

        layer.selectByIds(target_ids)
        iface.mapCanvas().zoomToSelected(layer)
        self.statusBar().showMessage(f"'{selected_user}' 작업자의 작업중인 객체 {len(target_ids)}개로 이동했습니다.", 5000)

    # ==========================================
    # 레이어 데이터 연동 (분배 탭 + 대시보드 탭 통합)
    # ==========================================
    def setLayers (self, layer):
        index = self.ui.layer.currentIndex()
        if index !=-1:
            layerId = self.ui.layer.itemData(index)

        self.ui.layer.blockSignals(True)
        self.ui.layer.clear()
        self.ui.layer.addItem("레이어를 선택하세요...", None)

        for i in layer:
            self.ui.layer.addItem(i[0], i[1])

        if index !=-1:
            index2 = self.ui.layer.findData(layerId)
            if index2 !=-1:
                self.ui.layer.setCurrentIndex(index2)
            else:
                self.ui.layer.setCurrentIndex(0)
        else:
            self.ui.layer.setCurrentIndex(0)

        self.ui.layer.blockSignals(False)

    def layerSelection(self, index):
        if index == -1:
            return
        
        idW = self.ui.layer.itemData(index)
        layer = None if idW is None else QgsProject.instance().mapLayer(idW)
        self.ui.log_textEdit.setPlainText("")
        # ==========================================
        # --- 새로 추가: 레이어 시그널 연결/해제 관리 ---
        # ==========================================
        if getattr(self, 'current_connected_layer', None):
            try:
                self.current_connected_layer.selectionChanged.disconnect(self.on_selection_changed)
            except TypeError:
                pass # 연결되지 않은 경우 무시
                
        self.current_connected_layer = layer
        if self.current_connected_layer:
            self.current_connected_layer.selectionChanged.connect(self.on_selection_changed)
        # ==========================================

        # 레이어 미선택 시 화면 초기화
        if not layer:
            self.statusBar().showMessage("레이어를 선택해 주세요.", 5000)
            self.clearChoice()
            self.tm1 = ModelListaPol(self)
            self.ui.listHalf.setModel(self.tm1)
            return
        
        fields = layer.fields()
        self.ui.Field.setLayer(layer)

        # 1. 대시보드를 위한 필드 리스트 구성 (함수/숫자/텍스트 분류)
        dictionary = {'countAttributes': [], 'attributeTxt': [], 'calculations': []}
        for i in range(fields.count()):
            field = fields.at(i)
            if field.isNumeric():
                dictionary['countAttributes'].append((field.name(), i))
            else:
                dictionary['attributeTxt'].append((field.name(), i))

        obl = self.calculations.list
        for c, b in obl.items():
            dictionary['calculations'].append((b[0], c))

        del(self.tm1)
        self.tm1 = ModelListaPol(self)
        self.ui.listHalf.setModel(self.tm1)
        
        # 함수 목록 삽입
        keys = ['calculations']
        for i in keys:
            j = dictionary[i]
            j.sort(key=lambda x: x[0].lower())
            rows = [(i, k, l) for k, l in j]
            rows.sort(key=lambda x: x[2])
            self.tm1.insertRows(0, len(rows), QModelIndex(), rows)
            
        # 속성 필드 삽입
        keys = ['countAttributes', 'attributeTxt']
        rows = []
        for i in keys:
            j = dictionary[i]
            for k, l in j:
                rows.append((i, k, l))
        rows.sort(key=lambda x: x[2])
        self.tm1.insertRows(0, len(rows), QModelIndex(), rows)

        self.clearChoice()

        # 2. 캐싱 로직: 레이어 정보를 메모리에 보관
        if idW in self.all_layers_cache:
            self.cached_features = self.all_layers_cache[idW]
            self.statusBar().showMessage("레이어 정보 불러오기 완료", 5000)
        else:
            self.statusBar().showMessage("레이어 정보를 가져오는 중입니다. 잠시만 기다려주세요...")
            QCoreApplication.processEvents()

            request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
            provider = layer.dataProvider()

            total_features = provider.featureCount()
            if total_features < 0:
                total_features = layer.featureCount()

            self.cached_features = []
            counter = 0

            for f in provider.getFeatures(request):
                self.cached_features.append({
                    'id': f.id(),
                    'attributes': f.attributes()
                })
                counter += 1
                if counter % 1000 == 0:
                    percent = (counter / total_features) * 100 if total_features > 0 else 0
                    msg = f"데이터 불러오는 중... {percent:.1f}% ({counter:,} / {total_features:,})" if total_features > 0 else f"데이터 불러오는 중... {counter:,}개 완료"
                    self.statusBar().showMessage(msg)
                    QCoreApplication.processEvents()

            self.all_layers_cache[idW] = self.cached_features
            self.statusBar().showMessage("레이어 속성 정보 불러오기 및 캐시 저장 완료.", 5000)

    def on_selection_changed(self):
        """맵 화면에서 객체가 선택되거나 해제될 때 실시간으로 통계를 집계합니다."""
        # [핵심 추가] 프로그램(코드)을 통한 강제 선택 시에는 테이블 갱신을 무시합니다.
        if getattr(self, 'is_programmatic_selection', False):
            return
        
        # if not getattr(self, 'current_connected_layer', None):
        #     return
            
        layer = self.current_connected_layer
        selected_features = layer.selectedFeatures()

        val_field_name = self.ui.Field.currentField()
        user_field_name = self.ui.userField.text().strip()
        comp_field_name = self.ui.completeField.text().strip()

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([user_field_name, comp_field_name, 'Count', 'Sum'])
        
        if not selected_features:
            self.ui.select_result.setModel(model)
            return
        
        stats = {} 

        for f in selected_features:
            attrs = f.attributes()
            user_val, comp_val = "", ""
            
            # 분배(User) 필드 실제 값 추출
            if user_field_name:
                u_idx = layer.fields().indexOf(user_field_name)
                if u_idx != -1:
                    raw_u = attrs[u_idx]
                    # 실제 데이터가 NULL이거나 None인 경우 명시, 그 외에는 실제 텍스트 사용
                    if raw_u is None or str(raw_u).upper() == 'NULL':
                        user_val = "NULL"
                    else:
                        user_val = str(raw_u).strip()

            # 완료(Status) 필드 실제 값 추출
            if comp_field_name:
                c_idx = layer.fields().indexOf(comp_field_name)
                if c_idx != -1:
                    raw_c = attrs[c_idx]
                    # 실제 데이터가 NULL이거나 None인 경우 명시, 그 외에는 실제 텍스트 사용
                    if raw_c is None or str(raw_c).upper() == 'NULL':
                        comp_val = "NULL"
                    else:
                        comp_val = str(raw_c).strip()

            # 기존의 '작업중' 강제 치환 로직 삭제 -> 실제 추출된 값을 상태(status)로 그대로 사용
            status = comp_val

            numeric_val = 0.0
            if val_field_name:
                v_idx = layer.fields().indexOf(val_field_name)
                if v_idx != -1:
                    try: numeric_val = float(attrs[v_idx])
                    except: pass

            key = (user_val, status)
            # [수정 부분] 여기서 'ids' 키를 포함하여 초기화합니다.
            if key not in stats:
                stats[key] = {'count': 0, 'sum': 0.0, 'ids': []} 
            
            stats[key]['count'] += 1
            stats[key]['sum'] += numeric_val
            stats[key]['ids'].append(f.id()) 

        for (u_name, status), data in stats.items():
            item_user = SortableStandardItem(u_name, is_numeric=False)
            item_status = SortableStandardItem(status, is_numeric=False)
            
            # 우클릭 이동 기능을 위해 첫 번째 열에 ID 리스트를 저장
            item_user.setData(data['ids'], Qt.UserRole)
            
            item_count = SortableStandardItem(str(data['count']), is_numeric=True)
            s_val = data['sum']
            sum_str = f"{int(s_val)}" if s_val.is_integer() else f"{s_val:.2f}"
            item_sum = SortableStandardItem(sum_str, is_numeric=True)
            
            item_count.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item_sum.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            model.appendRow([item_user, item_status, item_count, item_sum])
        
        self.ui.select_result.setModel(model)
        # =========================================================
        # [추가 사항] 헤더 클릭 정렬 활성화 및 기본 오름차순 정렬 실행
        self.ui.select_result.setSortingEnabled(True)
        # 0번째 컬럼(분배 필드)을 기준으로 오름차순 정렬 (Null 값이 제일 위로 옴)
        self.ui.select_result.sortByColumn(0, Qt.AscendingOrder)
        # =========================================================
        self.ui.select_result.resizeColumnsToContents()
    # ==========================================
    # 대시보드(GroupStats) 연동 유틸리티 함수들
    # ==========================================
    def clearChoice(self):
        self.tm2.removeRows(0, self.tm2.rowCount(), QModelIndex())
        self.tm3.removeRows(0, self.tm3.rowCount(), QModelIndex())
        self.tm4.removeRows(0, self.tm4.rowCount(), QModelIndex())
        
        try:
            del(self.tm5)
        except AttributeError:
            pass
            
        self.ui.tableView.setModel(None)
        self.ui._filter.setPlainText('')

    def sortRows(self, row, mode):
        if self.ui.tableView.model() is not None:
            self.ui.tableView.model().sortRows(row, mode)

    def addFieldFromList(self, index):
        if not index.isValid(): return
        field_data = self.tm1._data[index.row()]
        field_type, field_name = field_data[0], field_data[1]
        
        if field_type == 'calculations':
            target_model = self.tm3
            target_name_str = "열(Columns)"
        elif field_type == 'attributeTxt':
            target_model = self.tm2
            target_name_str = "행(Rows)"
        else:
            target_model = self.tm4
            target_name_str = "값(Value)"

        if field_data in target_model._data:
            self.statusBar().showMessage(f"'{field_name}' 항목은 이미 {target_name_str}에 있습니다.", 3000)
            return

        if field_type == 'calculations':
            other_areas_types = [x[0] for x in self.tm2._data + self.tm4._data]
            if 'calculations' in other_areas_types:
                self.statusBar().showMessage("함수는 한 영역에서만 사용할 수 있습니다.", 3000)
                return
                
        target_model.insertRows(target_model.rowCount(), 1, QModelIndex(), [field_data])
        self.statusBar().showMessage(f"'{field_name}' 항목이 {target_name_str}에 추가되었습니다.", 3000)

    def removeItemFromList(self, index):
        sender_view = self.sender()
        if sender_view and index.isValid():
            model = sender_view.model()
            if model:
                model.removeRow(index.row())
                self.statusBar().showMessage("항목이 삭제되었습니다.", 3000)

    def blockCalculations(self, x=None, y=None, z=None):
        if len(self.tm4._data) > 0:
            self.ui.calculate.setEnabled(True)
        else:
            self.ui.calculate.setEnabled(False)

    def delFilter(self):
        self.ui._filter.setPlainText('')

    def setFilter(self):
        index = self.ui.layer.currentIndex()
        if index == -1: return
        layerId = self.ui.layer.itemData(index)
        if layerId is None: return
        layer = QgsProject.instance().mapLayer(str(layerId))
        if not layer or layer.fields().count() == 0: return

        dialog = ExcelFilterDialog(layer, self)
        if dialog.exec_() == QDialog.Accepted:
            filter_data = dialog.filter_data
            field_name = filter_data['field']
            is_numeric = filter_data['is_numeric']
            expr = ""
            
            if filter_data['null_status'] == 'null': expr = f'"{field_name}" IS NULL'
            elif filter_data['null_status'] == 'not_null': expr = f'"{field_name}" IS NOT NULL'
            
            if filter_data['null_status'] == 'all':
                if filter_data['type'] == 'value':
                    vals = [f"{str(v)}" if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'" for v in filter_data['values']]
                    if vals: expr = f'"{field_name}" IN ({", ".join(vals)})'
                elif filter_data['type'] == 'condition':
                    op, v1_raw, v2_raw = filter_data['op'], filter_data['val1'], filter_data['val2']
                    def fmt(v): return str(v) if is_numeric else f"'{str(v).replace(chr(39), chr(39)*2)}'"
                    v1, v2 = fmt(v1_raw), fmt(v2_raw)
                    
                    if op == "같음 (=)": expr = f'"{field_name}" = {v1}'
                    elif op == "같지 않음 (≠)": expr = f'"{field_name}" != {v1}'
                    elif op == "포함": expr = f'"{field_name}" LIKE \'%{v1_raw}%\''
                    elif op == "포함하지 않음": expr = f'"{field_name}" NOT LIKE \'%{v1_raw}%\''
                    elif op == "시작 문자": expr = f'"{field_name}" LIKE \'{v1_raw}%\''
                    elif op == "종료 문자": expr = f'"{field_name}" LIKE \'%{v1_raw}\''
                    elif op == "초과 (>)": expr = f'"{field_name}" > {v1}'
                    elif op == "미만 (<)": expr = f'"{field_name}" < {v1}'
                    elif op == "이상 (≥)": expr = f'"{field_name}" >= {v1}'
                    elif op == "이하 (≤)": expr = f'"{field_name}" <= {v1}'
                    elif op == "사이 (포함)": expr = f'"{field_name}" >= {v1} AND "{field_name}" <= {v2}'
                    elif op == "사이에 없음 (포함)": expr = f'"{field_name}" < {v1} OR "{field_name}" > {v2}'

            if expr:
                current_text = self.ui._filter.toPlainText().strip()
                if current_text: self.ui._filter.setPlainText(f"({current_text}) AND ({expr})")
                else: self.ui._filter.setPlainText(expr)

    # ==========================================
    # 피벗 테이블(통계) 계산 로직 (GroupStats 코어 엔진)
    # ==========================================
    def showScore(self):
        chosenRows = tuple(self.tm2._data)
        chosenColumns = tuple(self.tm3._data)
        chosenValues = tuple(self.tm4._data)

        value_fields = [x for x in chosenValues if x[0] != 'calculations']
        if not value_fields:
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', '계산할 값 필드를 먼저 추가해 주세요.'), 5000)
            return

        calc_items = [x for x in chosenColumns + chosenRows + chosenValues if x[0] == 'calculations']
        if not calc_items:
            calc_items = [('calculations', 'sum', 0)]

        chosenRows_no_calc = [x for x in chosenRows if x[0] != 'calculations']
        chosenCols_no_calc = [x for x in chosenColumns if x[0] != 'calculations']

        # 2. NULL 체크 로직 개선
        def is_null_val(val):
            # QGIS 표준 방식 적용
            if val is None or QgsVariantUtils.isNull(val):
                return True
            s = str(val).strip()
            return s == '' or s.upper() == 'NULL'

        valueFunctions = []
        for val in value_fields:
            if val[0] == 'attributeTxt':
                valueFunctions.append(lambda _obj, idx=val[2]: _obj['attributes'][idx])
            elif val[0] == 'countAttributes':
                valueFunctions.append(
                    lambda _obj, idx=val[2]: None if is_null_val(_obj['attributes'][idx]) else (
                        float(_obj['attributes'][idx].value()) if isinstance(_obj['attributes'][idx], QVariant) else float(_obj['attributes'][idx])
                    )
                )

        index = self.ui.layer.currentIndex()
        layerId = self.ui.layer.itemData(index)
        layer = QgsProject.instance().mapLayer(layerId)

        _filter = self.ui._filter.toPlainText()
        valid_ids = None

        if _filter:
            request = QgsFeatureRequest().setFilterExpression(_filter).setFlags(QgsFeatureRequest.NoGeometry).setNoAttributes()
            valid_ids = set([f.id() for f in layer.dataProvider().getFeatures(request)])

        result = {}
        numberOfObjects = len(self.cached_features)
        counter = 0
        NULLcounter = 0
        
        # TaskManager.ui에 체크박스가 있다면 연동하고, 없으면 기본값(False) 적용
        use_null = self.ui.useNULL.isChecked() if hasattr(self.ui, 'useNULL') else False

        for f_dict in self.cached_features:
            f_id = f_dict['id']
            if valid_ids is not None and f_id not in valid_ids: continue

            has_null_key = False
            key_column = []
            for k in chosenCols_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_column.append('' if is_null_val(attr_val) else attr_val)

            key_row = []
            for k in chosenRows_no_calc:
                attr_val = f_dict['attributes'][k[2]]
                if is_null_val(attr_val): has_null_key = True
                key_row.append('' if is_null_val(attr_val) else attr_val)

            vals_to_calc = [vf(f_dict) for vf in valueFunctions]
            all_null_values = all(is_null_val(v) for v in vals_to_calc)

            if not use_null and (has_null_key or all_null_values):
                NULLcounter += 1
                continue

            key = (tuple(key_row), tuple(key_column))
            if key in result:
                result[key][0].append(vals_to_calc)
                result[key][1].append(f_id)
            else:
                result[key] = [[vals_to_calc], [f_id]]

            counter += 1

        self.statusBar().showMessage('결과 테이블 생성 중...')

        # 합계 옵션 (UI 미존재 시 기본 활성화)
        enable_bottom_total = True
        enable_right_total = True
        enable_subtotal = False

        num_val_fields = len(value_fields)
        num_calcs = len(calc_items)
        has_rows = len(chosenRows_no_calc) > 0
        has_cols = len(chosenCols_no_calc) > 0

        add_col_total_key = enable_right_total and has_cols
        add_extra_total_cols = enable_right_total and (num_val_fields >= 2)

        keys = result.keys()

        def sorting_key(tup):
            key_list = []
            for val in tup:
                if val is None or str(val).strip() == '':
                    key_list.append((2, str(val)))
                else:
                    try: key_list.append((0, float(val)))
                    except (ValueError, TypeError): key_list.append((1, str(val)))
            return tuple(key_list)

        base_rows = sorted(list(set([z[0] for z in keys])), key=sorting_key)
        kolu = sorted(list(set([z[1] for z in keys])), key=sorting_key)

        subtotal_rows = set()
        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for i in range(1, len(chosenRows_no_calc)):
                    sub_key = list(r)
                    sub_key[i] = f"[{r[i-1]} 부분합]"
                    for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                    subtotal_rows.add(tuple(sub_key))
        subtotal_rows = list(subtotal_rows)

        if len(calc_items) == 1:
            f_name = calc_items[0][1]
            if f_name == 'sum': dynamic_total = '총합계'
            elif f_name == 'count': dynamic_total = '총 개수'
            elif f_name == 'unique': dynamic_total = '총 고유값'
            elif f_name == 'average': dynamic_total = '전체 평균'
            else: dynamic_total = f"전체 {f_name}"
        else: dynamic_total = '전체 요약'

        ROW_TOTAL_KEY = tuple([dynamic_total] + [''] * (len(chosenRows_no_calc) - 1)) if has_rows else ()
        COL_TOTAL_KEY = tuple(['행합계'] + [''] * (len(chosenCols_no_calc) - 1)) if has_cols else ()

        rows = base_rows[:]
        if enable_subtotal: rows.extend(subtotal_rows)
        if enable_bottom_total and has_rows: rows.append(ROW_TOTAL_KEY)

        columns = kolu[:]
        if add_col_total_key: columns.append(COL_TOTAL_KEY)

        raw_matrix = {r: {c: [] for c in columns} for r in rows}
        id_matrix = {r: {c: [] for c in columns} for r in rows}

        for x in keys:
            r_key, c_key = x[0], x[1]
            raw_matrix[r_key][c_key].extend(result[x][0])
            id_matrix[r_key][c_key].extend(result[x][1])

        if enable_subtotal and len(chosenRows_no_calc) >= 2:
            for r in base_rows:
                for c in kolu:
                    for i in range(1, len(chosenRows_no_calc)):
                        sub_key = list(r)
                        sub_key[i] = f"[{r[i-1]} 부분합]"
                        for j in range(i+1, len(chosenRows_no_calc)): sub_key[j] = ""
                        sub_key = tuple(sub_key)
                        raw_matrix[sub_key][c].extend(raw_matrix[r][c])
                        id_matrix[sub_key][c].extend(id_matrix[r][c])

        if add_col_total_key:
            for r in base_rows + (subtotal_rows if enable_subtotal else []):
                for c in kolu:
                    raw_matrix[r][COL_TOTAL_KEY].extend(raw_matrix[r][c])
                    id_matrix[r][COL_TOTAL_KEY].extend(id_matrix[r][c])

        if enable_bottom_total and has_rows:
            cols_to_sum = kolu[:]
            if add_col_total_key: cols_to_sum.append(COL_TOTAL_KEY)
            for c in cols_to_sum:
                for r in base_rows:
                    raw_matrix[ROW_TOTAL_KEY][c].extend(raw_matrix[r][c])
                    id_matrix[ROW_TOTAL_KEY][c].extend(id_matrix[r][c])

        rowDictionary = {row: nr for nr, row in enumerate(rows)}
        columnDictionary = {col: nr for nr, col in enumerate(columns)}
        cols_count = len(columns) if len(columns) > 0 else 1
        extra_cols = num_calcs if add_extra_total_cols else 0
        total_normal_cols = cols_count * num_val_fields * num_calcs

        data = []
        for x in range(len(rows)): data.append([['', []] for _ in range(total_normal_cols + extra_cols)])

        for r in rows:
            for c in (columns if len(columns) > 0 else [()]):
                nrw = rowDictionary[r]
                nrk = columnDictionary[c] if len(columns) > 0 else 0

                cell_raw_data = raw_matrix[r][c] if len(columns) > 0 else raw_matrix[r][()]
                cell_ids = id_matrix[r][c] if len(columns) > 0 else id_matrix[r][()]

                for v_idx in range(num_val_fields):
                    raw_values = [row[v_idx] for row in cell_raw_data]
                    valid_values = []
                    for v in raw_values:
                        if is_null_val(v):
                            if use_null: valid_values.append(0.0)
                        else:
                            try: valid_values.append(float(v))
                            except (ValueError, TypeError): valid_values.append(str(v))

                    for c_idx, calc in enumerate(calc_items):
                        calc_id = calc[2]
                        calc_name = calc[1]

                        calc_vals = valid_values
                        if calc_name not in ('count', 'unique'):
                            calc_vals = [v for v in valid_values if isinstance(v, (int, float))]

                        if not calc_vals and calc_name not in ('count', 'unique'): s = ''
                        else:
                            try: s = self.calculations.list[calc_id][1](calc_vals)
                            except Exception: s = ''

                        col_idx = nrk * (num_val_fields * num_calcs) + (v_idx * num_calcs) + c_idx
                        data[nrw][col_idx] = [s, cell_ids]

        if add_extra_total_cols:
            for r_idx, r in enumerate(rows):
                for c_idx, calc in enumerate(calc_items):
                    row_val = 0.0
                    has_num = False
                    if add_col_total_key:
                        col_key_idx = columnDictionary[COL_TOTAL_KEY]
                        start_col = col_key_idx * (num_val_fields * num_calcs)
                        indices_to_sum = [start_col + v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    else:
                        indices_to_sum = [v_idx * num_calcs + c_idx for v_idx in range(num_val_fields)]
                    
                    for i in indices_to_sum:
                        val = data[r_idx][i][0]
                        if isinstance(val, (int, float)):
                            row_val += val
                            has_num = True
                            
                    target_col_idx = total_normal_cols + c_idx
                    if has_num: data[r_idx][target_col_idx] = [round(row_val, 4), []]
                    else: data[r_idx][target_col_idx] = ['', []]

        atr = {i: layer.fields().at(i) for i in range(layer.fields().count())}
        rowNames = [atr[x[2]].name() for x in chosenRows_no_calc]
        colNames = [atr[x[2]].name() for x in chosenCols_no_calc]
        valNames = [f"{atr[val[2]].name()} {calc[1]}" for val in value_fields for calc in calc_items]

        columns1 = []
        if len(columns) > 0 and len(columns[0]) > 0:
            for c in columns:
                if c == COL_TOTAL_KEY:
                    for vname in valNames: columns1.append(tuple(['행합계'] + [''] * (len(chosenCols_no_calc) - 1) + [vname]))
                else:
                    for vname in valNames: columns1.append(c + (vname,))
        else: columns1 = [(vname,) for vname in valNames]

        if add_extra_total_cols:
            for calc in calc_items:
                calc_name = calc[1]
                header_len = len(columns1[0]) if len(columns1) > 0 else 1
                if header_len > 1: extra_header = tuple(['행합계'] + [''] * (header_len - 2) + [f"전체 {calc_name}"])
                else: extra_header = (f"총합계 {calc_name}",)
                columns1.append(extra_header)

        rows1 = rows

        if len(rows1) > 0 and len(rows1[0]) > 0: rows1.insert(0, tuple(rowNames))
        if len(columns1) > 0 and len(columns1[0]) > 0: columns1.insert(0, tuple(colNames) + ("값(Value)",))

        if len(rows1) > 0 and len(columns1) > 0:
            self.ui.tableView.setUpdatesEnabled(False)
            self.tm5 = ResultModel(data, rows1, columns1, layer)
            
            # 주의: tableView 객체로 모델 적용
            self.ui.tableView.setModel(self.tm5)

            for i in range(len(columns1[0]), 0, -1):
                self.ui.tableView.verticalHeader().setSortIndicator(i-1, Qt.AscendingOrder)
            for i in range(len(rows1[0]), 0, -1):
                self.ui.tableView.horizontalHeader().setSortIndicator(i-1, Qt.AscendingOrder)

            for i in range(self.tm5.columnCount()):
                self.ui.tableView.resizeColumnToContents(i)

            self.ui.tableView.setUpdatesEnabled(True)

            msg = "계산 완료."
            if NULLcounter > 0 and not use_null: msg += f" (NULL 객체 {NULLcounter}개 제외됨)"
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats', msg), 20000)
        else:
            try: del(self.tm5)
            except AttributeError: pass
            self.ui.tableView.setModel(None)
            self.statusBar().showMessage(QCoreApplication.translate('GroupStats','조건에 맞는 데이터를 찾을 수 없습니다.'), 10000)

    def closeEvent(self, event):
        """창이 닫힐 때 자동으로 실행되는 이벤트 함수입니다."""
        # 혹시 실시간 저장이 누락된 항목(경로 설정 등)이 있을 수 있으니 창 닫힐 때 최종 저장
        self.save_settings()
        # self.all_layers_cache = {}
        # self.cached_features = []
        event.accept()

    def distribute_selected_features(self):
        """선택된 객체 중 미작업 객체를 필터링하여 작업자 할당 후 내보냅니다."""
        selected_user_indexes = self.ui.user_listView.selectedIndexes()
        if not selected_user_indexes:
            QMessageBox.warning(self, "경고", "리스트에서 작업자를 먼저 선택해 주세요.")
            return
        user_name = selected_user_indexes[0].data(Qt.DisplayRole)

        layer, layer_id = self.get_current_layer_info()
        if not layer: return

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer: return

        u_field = self.ui.userField.text().strip()      
        s_field = self.ui.startField.text().strip()     
        c_field = self.ui.completeField.text().strip()  
        base_path = self.ui.mQgsFileWidget_export.filePath()

        if not base_path:
            QMessageBox.warning(self, "경고", "내보내기 경로를 설정해 주세요.")
            return

        # --- 필드명이 있을 때만 인덱스를 찾고, 없으면 -1 처리 ---
        u_idx = layer.fields().indexOf(u_field) if u_field else -1
        c_idx = layer.fields().indexOf(c_field) if c_field else -1
        s_idx = layer.fields().indexOf(s_field) if s_field else -1
        val_field_name = self.ui.Field.currentField()
        v_idx = layer.fields().indexOf(val_field_name) if val_field_name else -1

        selected_features = layer.selectedFeatures()
        target_features = []
        target_sum = 0.0 

        for f in selected_features:
            u_val = str(f.attributes()[u_idx]).strip() if u_idx != -1 and f.attributes()[u_idx] is not None else ""
            c_val = str(f.attributes()[c_idx]).strip() if c_idx != -1 and f.attributes()[c_idx] is not None else ""
            
            u_is_empty = (not u_val or u_val.upper() == 'NULL') if u_idx != -1 else True
            c_is_empty = (not c_val or c_val.upper() == 'NULL') if c_idx != -1 else True

            if u_is_empty and c_is_empty:
                target_features.append(f)
                if v_idx != -1:
                    try:
                        target_sum += float(f.attributes()[v_idx])
                    except (ValueError, TypeError):
                        pass

        if not target_features:
            self.statusBar().showMessage("선택된 객체 중 분배 가능한(미작업) 객체가 없습니다.", 5000)
            return
        
        # 4. 내보내기 경로 생성 (지정경로 > 오늘 날짜 > 분배 폴더)
        today_str = QDate.currentDate().toString("yyyyMMdd")
        date_dir = os.path.join(base_path, today_str)
        if not os.path.exists(date_dir):
            os.makedirs(date_dir)

        # [수정 사항] 폴더명 중복 체크 및 갱신 로직
        base_folder_name = f"{today_str}_{user_name}"
        export_dir = os.path.join(date_dir, base_folder_name)
        
        folder_counter = 1
        # 폴더가 이미 존재하면 숫자를 붙여 새로운 폴더 경로 생성
        while os.path.exists(export_dir):
            new_folder_name = f"{base_folder_name}_{folder_counter}"
            export_dir = os.path.join(date_dir, new_folder_name)
            folder_counter += 1
            
        # 결정된 최종 경로로 폴더 생성
        os.makedirs(export_dir)
        
        # 실제 폴더명 가져오기 (로그 출력용)
        final_folder_name = os.path.basename(export_dir)

        # 4-3. 저장 형식 및 확장자 설정
        export_type = self.ui.type_comboBox.currentText().strip().upper()
        ext = ".shp" if export_type == "SHP" else ".gpkg"
        driver_name = "ESRI Shapefile" if export_type == "SHP" else "GPKG"

        # [수정 사항] 파일명은 생성된 폴더명과 동일하게 설정 (폴더가 고유하므로 파일명 중복 체크는 불필요해짐)
        savefile_name = f"{final_folder_name}{ext}"
        file_path = os.path.join(export_dir, savefile_name)

        assigned_val = self.get_dynamic_value(self.ui.userField_type.currentText(), 
                                               self.ui.userField_lineEdit.text(), user_name)

        start_val = self.get_dynamic_value(self.ui.startField_type.currentText(), 
                                            self.ui.startField_lineEdit.text(), user_name)

        layer.startEditing()

        # --- [수정된 부분] 편집 모드 강제 유지 및 Undo 스택 기록 ---
        if not layer.isEditable():
            layer.startEditing()
        layer.beginEditCommand("선택객체 분배")

        try:
            feature_ids = []
            for f in target_features:
                f_id = f.id()
                feature_ids.append(f_id)
                # --- 유효한 인덱스일 때만 값 입력 (건너뛰기) ---
                if u_idx != -1: layer.changeAttributeValue(f_id, u_idx, assigned_val)
                if s_idx != -1: layer.changeAttributeValue(f_id, s_idx, start_val)
                if c_idx != -1: layer.changeAttributeValue(f_id, c_idx, "작업중")

            layer.endEditCommand() # 속성 수정을 Undo 스택에 저장 (디스크 저장이 아님)

        except Exception as e:
            layer.destroyEditCommand() # 에러 발생 시 편집 상태 롤백
            QMessageBox.critical(self, "오류", f"분배 중 오류가 발생했습니다: {e}")
            return
        
        # -------------------------------------------------------------
        layer.selectByIds(feature_ids)

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.filterExtent = layer.extent()
        options.onlySelectedFeatures = True 

        # --- [추가된 부분] 동적으로 드라이버(포맷) 설정 ---
        options.driverName = driver_name
        if export_type == "SHP":
            options.fileEncoding = "949" # SHP 파일의 경우 한글 깨짐 방지용

        error = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, file_path, QgsProject.instance().transformContext(), options
        )

        if error[0] == QgsVectorFileWriter.NoError:
            
            if layer_id in self.all_layers_cache:
                for f_dict in self.all_layers_cache[layer_id]:
                    if f_dict['id'] in feature_ids:
                        # --- 캐시 덮어쓰기도 유효할 때만 건너뛰기 ---
                        if u_idx != -1: f_dict['attributes'][u_idx] = assigned_val
                        if s_idx != -1: f_dict['attributes'][s_idx] = start_val
                        if c_idx != -1: f_dict['attributes'][c_idx] = "작업중"
            
            # # =========================================================
            # # [추가 사항] 분배된 객체 전체의 중앙 좌표(Centroid) 계산
            # # =========================================================
            # geom_union = QgsGeometry()
            # for f in target_features:
            #     if geom_union.isEmpty():
            #         geom_union = QgsGeometry(f.geometry())
            #     else:
            #         geom_union = geom_union.combine(f.geometry())
                    
            # centroid_str = "좌표 없음"
            # if not geom_union.isEmpty():
            #     centroid = geom_union.centroid().asPoint()
            #     # 소수점 2자리까지 출력 (원하시면 .2f를 .3f 등으로 수정 가능)
            #     centroid_str = f"X: {centroid.x():.2f}, Y: {centroid.y():.2f}"
            # # =========================================================

            sum_str = f"{int(target_sum)}" if target_sum.is_integer() else f"{target_sum:.2f}"
            log_msg = f"[분배 완료] 작업자: {user_name} | 수량: {len(target_features)}개 | 합계({val_field_name}): {sum_str} | 저장파일: {savefile_name}"
            self.write_log(log_msg)

            # =========================================================
            # [핵심 추가 코드] 분배 후 로그 창 및 작업자 통계 즉시 갱신
            if selected_user_indexes:
                self.on_user_clicked(selected_user_indexes[0])
                # [추가] 다른 작업으로 인해 UI가 멈추기 전에 로그 창을 화면에 강제로 먼저 그리도록 지시합니다.
                QCoreApplication.processEvents()
            # =========================================================

            self.statusBar().showMessage(f"{len(target_features)}개 객체 분배 완료 및 내보내기 성공: {file_path}", 10000)
            # self.layerSelection(self.ui.layer.currentIndex()) 
        else:
            layer.rollBack()
            QMessageBox.critical(self, "오류", f"파일 저장 중 오류가 발생했습니다: {error[1]}")

    def get_week_of_month(self, dt):
        """날짜를 입력받아 '월주차(M W)' 형식의 문자열을 반환합니다."""
        # 요일 인덱스: 1(월)~7(일) -> 0(월)~6(일)
        weekday_index = dt.date().dayOfWeek() - 1
        # 주의 시작(월요일) 날짜 계산
        start_of_week = dt.addDays(-weekday_index)
        month = start_of_week.date().month()
        # 해당 월의 몇 번째 주인지 계산
        week_num = math.ceil(start_of_week.date().day() / 7)
        return f"{month}{week_num}"

    def get_dynamic_value(self, type_text, line_edit_val, user_name):
        """콤보박스 설정 타입에 따라 실제 필드에 입력할 값을 반환합니다."""
        now = QDateTime.currentDateTime()
        
        if type_text == "작업자":
            return user_name
        elif type_text == "지정값 사용":
            return line_edit_val
        elif type_text == "날짜 시간":
            return now.toString("yyyy-MM-dd HH:mm:ss")
        elif type_text == "날짜":
            return now.toString("yyyy-MM-dd")
        elif type_text == "주차":
            return self.get_week_of_month(now)
        return None

    def load_settings(self):
        """설정 탭의 UI 값들을 QSettings에서 불러옵니다. (반복문 간소화)"""
        # 1. 텍스트 입력창(QLineEdit) 불러오기
        line_edits = ["userField", "completeField", "startField", "endField", 
                      "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]
        for name in line_edits:
            getattr(self.ui, name).setText(self.QSettings.value(name, ""))

        # 2. 콤보박스(QComboBox) 불러오기
        combo_boxes = ["userField_type", "completeField_type", "startField_type", "endField_type", "type_comboBox"]
        for name in combo_boxes:
            getattr(self.ui, name).setCurrentIndex(int(self.QSettings.value(name, 0)))

        # 3. 경로 설정
        try:
            self.ui.mQgsFileWidget_export.setFilePath(self.QSettings.value("path_export", ""))
        except AttributeError:
            pass

    def save_settings(self):
        """설정 탭의 UI 값들을 실시간으로 QSettings에 저장합니다. (반복문 간소화)"""
        line_edits = ["userField", "completeField", "startField", "endField", 
                      "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]
        for name in line_edits:
            self.QSettings.setValue(name, getattr(self.ui, name).text().strip())

        combo_boxes = ["userField_type", "completeField_type", "startField_type", "endField_type", "type_comboBox"]
        for name in combo_boxes:
            self.QSettings.setValue(name, getattr(self.ui, name).currentIndex())

        try:
            self.QSettings.setValue("path_export", self.ui.mQgsFileWidget_export.filePath())
        except AttributeError:
            pass

    def setup_logger(self):
        """로그 로테이션을 처리할 로거를 초기화합니다."""
        log_dir = QgsApplication.qgisSettingsDirPath()
        if not log_dir or not os.path.exists(log_dir):
            return

        log_file = os.path.join(log_dir, "TaskManager_Log.txt")

        # 1. 로거 생성
        self.logger = logging.getLogger("TaskManagerLogger")
        self.logger.setLevel(logging.INFO)

        # 이미 핸들러가 추가되어 있다면 중복 추가 방지
        if not self.logger.handlers:
            # 2. 로테이션 핸들러 설정
            # maxBytes: 5MB (5 * 1024 * 1024 바이트) 도달 시 파일 교체
            # backupCount: 최신 백업 파일 3개까지만 유지 (나머지는 자동 삭제)
            handler = RotatingFileHandler(
                log_file, 
                maxBytes = 10 * 1024 * 1024, 
                backupCount = 3, 
                encoding = 'utf-8'
            )

            # 3. 로그 출력 포맷 설정 (기존에 작성하시던 포맷과 동일하게 맞춤)
            formatter = logging.Formatter('[%(asctime)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S")
            handler.setFormatter(formatter)

            self.logger.addHandler(handler)

    def write_log(self, message):
        """로그를 기록합니다. 파일 크기가 5MB가 넘으면 자동으로 백업 및 갱신됩니다."""
        # 로거가 아직 세팅되지 않았다면 세팅
        if not hasattr(self, 'logger'):
            self.setup_logger()
            
        try:
            # INFO 레벨로 메시지 기록 (시간은 Formatter가 자동으로 붙여줍니다)
            self.logger.info(message)
        except Exception as e:
            self.statusBar().showMessage(f"로그 파일 저장 실패: {e}", 5000)


    def complete_working_objects(self):
        """선택한 작업자의 '작업중'인 객체를 모두 찾아 '완료' 처리하고 종료 날짜를 입력합니다."""
        # 1. 작업자 선택 여부 확인
        selected_indexes = self.ui.user_listView.selectedIndexes()
        if not selected_indexes:
            QMessageBox.warning(self, "경고", "리스트에서 작업자를 먼저 선택해 주세요.")
            return

        selected_user = selected_indexes[0].data(Qt.DisplayRole)

        layer, layer_id = self.get_current_layer_info()
        if not layer: return

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer or layer_id not in self.all_layers_cache: return

        # 2. 설정 탭의 필드명 가져오기
        user_field_name = self.ui.userField.text().strip()
        comp_field_name = self.ui.completeField.text().strip()
        end_field_name = self.ui.endField.text().strip() 
        val_field_name = self.ui.Field.currentField()

        # --- 필드명이 있을 때만 인덱스를 찾고, 없으면 -1 처리 ---
        u_idx = layer.fields().indexOf(user_field_name) if user_field_name else -1
        c_idx = layer.fields().indexOf(comp_field_name) if comp_field_name else -1
        e_idx = layer.fields().indexOf(end_field_name) if end_field_name else -1
        v_idx = layer.fields().indexOf(val_field_name) if val_field_name else -1

        if u_idx == -1 or c_idx == -1:
            QMessageBox.warning(self, "경고", "레이어에 설정된 분배/완료 필드가 존재하지 않습니다.")
            return
        
        target_ids = []
        target_sum = 0.0 
        
        for f_dict in self.all_layers_cache[layer_id]:
            attrs = f_dict['attributes']
            user_val = str(attrs[u_idx]).strip() if u_idx != -1 and attrs[u_idx] is not None else ""
            comp_val = str(attrs[c_idx]).strip() if c_idx != -1 and attrs[c_idx] is not None else ""

            user_match = (user_val == selected_user) if u_idx != -1 else True
            comp_match = (comp_val == '작업중' or not comp_val or comp_val.upper() == 'NULL') if c_idx != -1 else True

            if user_match and comp_match:
                target_ids.append(f_dict['id'])
                
                if v_idx != -1:
                    try:
                        target_sum += float(attrs[v_idx])
                    except (ValueError, TypeError):
                        pass

        if not target_ids:
            self.statusBar().showMessage(f"'{selected_user}' 작업자의 완료 처리할 '작업중' 객체가 없습니다.", 3000)
            return

        comp_val_dynamic = self.get_dynamic_value(self.ui.completeField_type.currentText(),
                                          self.ui.completeField_lineEdit.text(), selected_user)
        
        # [수정] 이 두 줄을 꼭 추가해 주세요! (작업중 안 지워지는 버그 해결)
        if not comp_val_dynamic:
            comp_val_dynamic = "완료"

        end_val_dynamic = self.get_dynamic_value(self.ui.endField_type.currentText(),
                                         self.ui.endField_lineEdit.text(), selected_user)

        layer.startEditing()

        # --- [수정된 부분] 편집 모드 강제 유지 및 Undo 스택 기록 ---
        if not layer.isEditable():
            layer.startEditing()

        # [안전하게 바꾼 코드]
        layer.beginEditCommand("작업중 완료 처리")
        try:
            for f_id in target_ids:
                if c_idx != -1: layer.changeAttributeValue(f_id, c_idx, comp_val_dynamic)  
                if e_idx != -1: layer.changeAttributeValue(f_id, e_idx, end_val_dynamic)
            layer.endEditCommand()
        except Exception as e:
            layer.destroyEditCommand() # 에러 발생 시 편집 상태 롤백
            QMessageBox.critical(self, "오류", f"완료 처리 중 오류가 발생했습니다: {e}")
            return
        # -------------------------------------------------------------

        for f_dict in self.all_layers_cache[layer_id]:
            if f_dict['id'] in target_ids:
                # --- 캐시 덮어쓰기도 유효할 때만 건너뛰기 ---
                if c_idx != -1: f_dict['attributes'][c_idx] = comp_val_dynamic
                if e_idx != -1: f_dict['attributes'][e_idx] = end_val_dynamic

        sum_str = f"{int(target_sum)}" if target_sum.is_integer() else f"{target_sum:.2f}"
        log_msg = f"[작업 완료] 작업자: {selected_user} | 수량: {len(target_ids)}개 | 합계({val_field_name}): {sum_str}"
        self.write_log(log_msg)

        self.on_user_clicked(selected_indexes[0])
        self.statusBar().showMessage(f"'{selected_user}' 작업자의 {len(target_ids)}개 객체가 완료 처리되었습니다.", 5000)


    # ==========================================
    # 피벗 테이블 우클릭 메뉴 및 내보내기/복사 기능
    # ==========================================
    def show_context_menu(self, pos):
        """테이블 뷰에서 우클릭 시 나타나는 팝업 메뉴를 구성합니다."""
        selectionIndex = self.ui.tableView.indexAt(pos)
        if not selectionIndex.isValid() or selectionIndex.row() < 0 or selectionIndex.column() < 0:
            return
            
        menu = QMenu(self.ui.tableView)
        # 2. '셀 내용 복사' 액션 생성 및 연결
        copyCellAction = QAction('셀 내용 복사', self)
        selectedCell = str(selectionIndex.data(Qt.DisplayRole) or "")
        def copyMarked():
            "선택한 셀을 클립보드에 복사합니다"
            indexList = self.ui.tableView.selectedIndexes()
            if not indexList:
                QMessageBox.information(self, QCoreApplication.translate('GroupStats','Information'),
                    QCoreApplication.translate('GroupStats','선택한 데이터가 없습니다.'))
                return

            # 1. 행(Row)별로 선택된 셀들을 그룹화하여 딕셔너리에 저장
            row_data = {}
            for idx in indexList:
                r = idx.row()
                c = idx.column()
                val = str(idx.data(Qt.DisplayRole) or "")
                
                if r not in row_data:
                    row_data[r] = {}
                row_data[r][c] = val

            # 2. 행과 열의 시각적 순서대로 정렬하여 텍스트 결합 (탭과 줄바꿈)
            text_lines = []
            for r in sorted(row_data.keys()):
                cols = sorted(row_data[r].keys())
                line = "\t".join([row_data[r][c] for c in cols])
                text_lines.append(line)

            text = "\n".join(text_lines)
            
            # 3. 클립보드에 삽입
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.window().statusBar().showMessage('선택한 셀의 내용을 클립보드에 복사했습니다.', 5000)

        copyCellAction.triggered.connect(copyMarked)
        menu.addAction(copyCellAction)

        menu.addSeparator()

        action_copy_marked = QAction("선택 데이터 복사", self)
        action_copy_marked.triggered.connect(self.copyMarked)
        menu.addAction(action_copy_marked)
        
        action_copy_all = QAction("전체 데이터 복사", self)
        action_copy_all.triggered.connect(self.duplication)
        menu.addAction(action_copy_all)
        
        menu.addSeparator()
        
        action_move = QAction("객체 이동", self)
        action_move.triggered.connect(self.showOnMap)
        menu.addAction(action_move)
        
        menu.exec_(self.ui.tableView.viewport().mapToGlobal(pos))

    def duplication(self):
        "결과 테이블 모든 값을 클립보드에 복사합니다."
        text, test = self.downloadDataFromTheTable(True, True)
        if test:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('모든 데이터를 클립보드에 복사했습니다.', 5000)

    def copyMarked(self):
        "결과 테이블에서 선택한 값을 클립보드에 복사합니다."
        text, test = self.downloadDataFromTheTable(False, True)
        if test:
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            self.statusBar().showMessage('선택한 데이터를 클립보드에 복사했습니다.', 5000)

    def exportToExcel(self):
        "결과 테이블의 모든 값을 엑셀파일(*.xlsx)로 저장합니다."
        data, test = self.downloadDataFromTheTable(True, False)
        if test:
            self.saveFileData(data)

    def exportMarkedToExcel(self):
        "결과 테이블에서 선택한 값을 엑셀파일(*.xlsx)로 저장합니다."
        data, test = self.downloadDataFromTheTable(False, False)
        if test:
            self.saveFileData(data)

    def saveFileData(self, data):
        "실제로 openpyxl을 사용하여 엑셀 파일을 디스크에 저장하는 기능"
        fileWindow = QFileDialog()
        fileWindow.setAcceptMode(QFileDialog.AcceptSave)
        fileWindow.setDefaultSuffix("xlsx")
        fileWindow.setNameFilters(["Excel files (*.xlsx)", "All files (*)"])
        if fileWindow.exec_() == 0:
            return
        fileName = fileWindow.selectedFiles()[0]
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Pivot Data"
        for i in data:
            ws.append(i)
        wb.save(fileName)
        self.statusBar().showMessage(f"엑셀 파일 저장이 완료되었습니다: {fileName}", 5000)

    def downloadDataFromTheTable(self, allData=True, controlCharacters=False):
        "ResultModel(tm5)에서 화면에 보이는 데이터를 파이썬 배열이나 클립보드 문자열로 추출합니다."
        if self.ui.tableView.model() is None:
            QMessageBox.information(self, "알림", "저장/복사할 데이터가 없습니다.")
            return None, False

        text = ''
        data = []
        numberOfColumns = self.tm5.columnCount()
        numberOfRows = self.tm5.rowCount()
        rows = []
        columns = []

        if not allData:
            indexList = self.ui.tableView.selectedIndexes()
            if len(indexList) == 0:
                QMessageBox.information(self, "알림", "선택한 데이터가 없습니다.")
                return None, False
            for i in indexList:
                rows.append(i.row())
                columns.append(i.column())

        for i in range(numberOfRows):
            if allData or (i in rows) or (i < self.tm5.offsetY):
                row = []
                for j in range(numberOfColumns):
                    if allData or (j in columns) or (j < self.tm5.offsetX):
                        row.append(str(self.tm5.createIndex(i, j).data() or ""))
                data.append(row)

        if controlCharacters:
            for m, i in enumerate(data):
                if m > 0:
                    text += chr(13) # 줄바꿈
                for n, j in enumerate(i):
                    if n > 0:
                        text += chr(9) # 탭
                    text += j
            return text, True
        else:
            return data, True

    def showOnMap(self):
        "피벗 테이블 셀 객체 이동"
        if self.ui.tableView.model() is None: return
        idList = [j for i in self.ui.tableView.selectedIndexes() for j in (i.data(Qt.UserRole) or [])]
        if not idList:
            QMessageBox.information(self, "알림", "선택한 데이터가 없습니다.")
            return
        self._zoom_to_feature_ids(self.tm5.layer, idList, "선택한 셀의 ")

    def exportToLayer(self):
        """계산된 피벗 테이블 결과를 도형이 없는 QGIS 메모리 테이블 레이어로 생성합니다."""
        if not hasattr(self, 'tm5') or self.tm5 is None:
            QMessageBox.information(self, "알림", "출력할 데이터가 없습니다.")
            return

        layer_name = "피벗테이블_결과"
        mem_layer = QgsVectorLayer("None", layer_name, "memory")
        pr = mem_layer.dataProvider()

        offsetX = self.tm5.offsetX
        offsetY = self.tm5.offsetY
        numberOfRows = self.tm5.rowCount()
        numberOfColumns = self.tm5.columnCount()

        field_names = []
        fields = []

        # 헤더 조립
        for j in range(numberOfColumns):
            if j < offsetX:
                name = str(self.tm5.createIndex(offsetY - 1, j).data() or "").strip()
                if not name: name = f"Field_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.String))
            else:
                name_parts = []
                for i in range(offsetY):
                    part = str(self.tm5.createIndex(i, j).data() or "").strip()
                    if part: name_parts.append(part)
                name = "_".join(name_parts)
                if not name: name = f"Value_{j+1}"
                field_names.append(name)
                fields.append(QgsField(name, QVariant.Double))

        pr.addAttributes(fields)
        mem_layer.updateFields()

        # 데이터 입력
        features = []
        for i in range(offsetY, numberOfRows):
            feat = QgsFeature()
            attrs = []
            for j in range(numberOfColumns):
                val = self.tm5.createIndex(i, j).data()
                if val is None or str(val).strip() == "":
                    attrs.append(None)
                else:
                    if j < offsetX:
                        attrs.append(str(val))
                    else:
                        try:
                            attrs.append(float(val))
                        except ValueError:
                            attrs.append(str(val))
            feat.setAttributes(attrs)
            features.append(feat)

        pr.addFeatures(features)
        mem_layer.updateExtents()
        QgsProject.instance().addMapLayer(mem_layer)
        
        self.statusBar().showMessage("결과가 레이어 패널에 '피벗테이블_결과'로 추가되었습니다.", 10000)

    # ==========================================
    # 작업자 통계(user_result) 우클릭 메뉴 및 복사 기능
    # ==========================================
    def show_user_result_context_menu(self, pos):
        """user_result 테이블 뷰에서 우클릭 시 나타나는 팝업 메뉴를 구성합니다."""
        selectionIndex = self.ui.user_result.indexAt(pos)
        if not selectionIndex.isValid() or selectionIndex.row() < 0 or selectionIndex.column() < 0:
            return
            
        menu = QMenu(self.ui.user_result)

        action_show_map = QAction("객체 이동", self)
        action_show_map.triggered.connect(self.show_user_result_on_map)
        menu.addAction(action_show_map)

        menu.addSeparator()

        action_copy_marked = QAction("선택 데이터 복사", self)
        action_copy_marked.triggered.connect(self.copy_user_result_marked)
        menu.addAction(action_copy_marked)
        
        action_copy_all = QAction("전체 데이터 복사", self)
        action_copy_all.triggered.connect(self.copy_user_result_all)
        menu.addAction(action_copy_all)

        menu.exec_(self.ui.user_result.viewport().mapToGlobal(pos))

    def copy_user_result_marked(self):
        """user_result 테이블에서 드래그한 셀 값을 복사합니다."""
        self._copy_table_selection_to_clipboard(self.ui.user_result, "선택한 작업자 통계 데이터를 복사했습니다.")

    def copy_user_result_all(self):
        """user_result 테이블의 전체 데이터(헤더 포함)를 클립보드에 복사합니다."""
        model = self.ui.user_result.model()
        if not model:
            return

        lines = []
        
        # 1. 상단 헤더(컬럼 이름) 추출
        header = []
        for c in range(model.columnCount()):
            header.append(str(model.headerData(c, Qt.Horizontal, Qt.DisplayRole) or ""))
        lines.append("\t".join(header))

        # 2. 본문 데이터 추출
        for r in range(model.rowCount()):
            row_data = []
            for c in range(model.columnCount()):
                idx = model.index(r, c)
                row_data.append(str(idx.data(Qt.DisplayRole) or ""))
            lines.append("\t".join(row_data))

        QApplication.clipboard().setText("\n".join(lines))
        self.statusBar().showMessage('작업자 통계 전체 데이터를 클립보드에 복사했습니다.', 5000)

    def show_user_result_on_map(self):
        """작업자 통계 창 객체 이동"""
        id_list = [j for i in self.ui.user_result.selectedIndexes() for j in (self.ui.user_result.model().index(i.row(), 0).data(Qt.UserRole) or [])]
        if id_list:
            layer, _ = self.get_current_layer_info()
            self._zoom_to_feature_ids(layer, id_list)

    def show_select_result_context_menu(self, pos):
        """선택 객체 통계 테이블 우클릭 메뉴"""
        menu = QMenu(self)

        # 1. 객체 이동 액션 추가
        zoom_action = QAction("객체 이동", self)
        zoom_action.triggered.connect(self.zoom_to_selected_cell_features)

        copy_action = QAction("선택 데이터 복사", self)
        copy_action.triggered.connect(lambda: self.copy_table_contents(self.ui.select_result))

        menu.addAction(zoom_action)
        menu.addAction(copy_action)
        menu.exec_(self.ui.select_result.viewport().mapToGlobal(pos))

    def copy_table_contents(self, table_view):
        """선택 객체 통계 테이블 복사"""
        self._copy_table_selection_to_clipboard(table_view, "선택 영역 통계 데이터를 복사했습니다.")

    def zoom_to_selected_cell_features(self):
        """선택된 셀(행) 객체 이동"""
        id_list = [j for r in set(idx.row() for idx in self.ui.select_result.selectedIndexes()) for j in (self.ui.select_result.model().index(r, 0).data(Qt.UserRole) or [])]
        if id_list:
            layer, _ = self.get_current_layer_info()
            self._zoom_to_feature_ids(layer, id_list)

    # ==========================================
    # 공통 도우미(Helper) 함수 모음 (중복 제거용)
    # ==========================================
    def _build_layer_cache_data(self, layer):
        """레이어의 속성 데이터를 읽어 캐시 배열을 생성합니다."""
        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        provider = layer.dataProvider()
        total_features = provider.featureCount() if provider.featureCount() >= 0 else layer.featureCount()
        
        cache_data = []
        for counter, f in enumerate(provider.getFeatures(request), 1):
            cache_data.append({'id': f.id(), 'attributes': f.attributes()})
            if counter % 1000 == 0:
                percent = (counter / total_features) * 100 if total_features > 0 else 0
                self.statusBar().showMessage(f"캐시 데이터 수집 중... {percent:.1f}% ({counter:,} / {total_features:,})")
                QCoreApplication.processEvents()
        return cache_data

    def _copy_table_selection_to_clipboard(self, table_view, success_msg="클립보드에 복사되었습니다."):
        """어떤 테이블 뷰든 선택된 영역의 데이터를 클립보드에 복사합니다."""
        model = table_view.model()
        selected = table_view.selectedIndexes()
        if not model or not selected:
            QMessageBox.information(self, "알림", "선택한 데이터가 없습니다.")
            return False

        row_data = {}
        for idx in selected:
            r, c = idx.row(), idx.column()
            val = str(idx.data(Qt.DisplayRole) or "")
            if r not in row_data:
                row_data[r] = {}
            row_data[r][c] = val

        text_lines = ["\t".join([row_data[r][c] for c in sorted(row_data[r].keys())]) for r in sorted(row_data.keys())]
        QApplication.clipboard().setText("\n".join(text_lines))
        self.statusBar().showMessage(success_msg, 5000)
        return True

    def _zoom_to_feature_ids(self, layer, id_list, success_msg_prefix=""):
        """전달받은 ID 리스트에 해당하는 객체들로 맵을 이동하고 선택합니다."""
        unique_ids = list(set(id_list))
        if not unique_ids or not layer: 
            return False
            
        # [핵심 추가] QGIS가 선택 변경을 감지하더라도 우리 테이블은 무시하도록 방어막 켜기  True
        self.is_programmatic_selection = False
        
        try:
            layer.selectByIds(unique_ids)  # 이 순간 selectionChanged 시그널이 발생함
            canvas = iface.mapCanvas()
            canvas.zoomToSelected(layer)
            
            if len(unique_ids) == 1 and layer.geometryType() == QgsWkbTypes.PointGeometry:
                canvas.zoomScale(1000)
        finally:
            # [핵심 추가] 맵 이동 및 선택이 끝나면 다시 마우스 클릭에 반응하도록 방어막 끄기
            self.is_programmatic_selection = False
            
        self.statusBar().showMessage(f"{success_msg_prefix}{len(unique_ids)}개 객체 위치로 이동했습니다.", 5000)
        return True
    
class SortableStandardItem(QStandardItem):
    """테이블 정렬 기능을 커스텀하기 위한 QStandardItem 상속 클래스"""
    def __init__(self, text, is_numeric=False):
        super().__init__(text)
        self.is_numeric = is_numeric

    def __lt__(self, other):
        text1 = self.text().strip()
        text2 = other.text().strip()
        
        # Null로 취급하여 최상단에 올릴 문자열 목록
        null_words = ["", "NULL", "미할당", "작업중"]
        is_null1 = text1.upper() in null_words
        is_null2 = text2.upper() in null_words
        
        # 둘 중 하나만 Null이면 Null을 더 작다고 판단 (오름차순 시 무조건 위로)
        if is_null1 and not is_null2:
            return True
        if not is_null1 and is_null2:
            return False
            
        # 둘 다 Null이 아니거나 둘 다 Null인 경우
        if self.is_numeric:
            try:
                val1 = float(text1.replace(',', ''))
                val2 = float(text2.replace(',', ''))
                return val1 < val2
            except ValueError:
                pass
                
        # 둘 다 일반 문자열인 경우 가나다순 비교
        return text1 < text2