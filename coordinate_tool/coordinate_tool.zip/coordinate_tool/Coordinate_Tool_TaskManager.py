# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
#  수정 이력
#   v1.1   2026-11-05  캐시 편집버퍼 반영, 내보내기 실패 시 이번 분배만 undo,
#                      필드 인덱스(-1) 검증, 로그 필터 구분자, list→set
#   v1.1.1 2026-11-05  선택 통계 Sum 복구, 작업중이동 검증 추가
#   v1.1.2 2026-11-05  완료처리 예외 범위 축소, bare except 축소
#   v1.2   2026-11-05  예외 타입 보정, 분배/완료처리 확인창, 분배 회수,
#                      전체 작업자 현황, 작업자 목록 우클릭·선택 삭제, 자동 저장 옵션
# ----------------------------------------------------------------------
from logging.handlers import RotatingFileHandler
from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import (QMainWindow, QWidget, QMenu, QAction, 
                             QMessageBox, QDialog, QApplication, QFileDialog)
from qgis.utils import iface
from qgis.core import *
from qgis.gui import *

import os, shutil, math, logging

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/Coordinate_Tool_TaskManager.ui'))

# 정렬용 커스텀 클래스 (선택 객체 통계에서 사용)
class SortableStandardItem(QStandardItem):
    def __init__(self, text, is_numeric=False):
        super().__init__(text)
        self.is_numeric = is_numeric

    def __lt__(self, other):
        text1 = self.text().strip()
        text2 = other.text().strip()
        null_words = ["", "NULL", "미할당", "작업중"]
        is_null1 = text1.upper() in null_words
        is_null2 = text2.upper() in null_words
        
        if is_null1 and not is_null2: return True
        if not is_null1 and is_null2: return False
        if self.is_numeric:
            try:
                return float(text1.replace(',', '')) < float(text2.replace(',', ''))
            except ValueError: pass
        return text1 < text2

class CoordinateToolTaskManager(QMainWindow):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.ui = FORM_CLASS()
        self.ui.setupUi(self)
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.all_layers_cache = {}
        self.current_connected_layer = None 
        self.user_index = False
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.ui.layer.currentIndexChanged.connect(self.layerSelection)

        # 설정 탭 자동 저장 초기화
        self.load_settings()

        # 시그널 연결 (QLineEdit & QComboBox)
        self.ui.userField.textChanged.connect(self.save_settings)
        self.ui.completeField.textChanged.connect(self.save_settings)
        self.ui.startField.textChanged.connect(self.save_settings)
        self.ui.endField.textChanged.connect(self.save_settings)
        self.ui.userField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.completeField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.startField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.endField_lineEdit.textChanged.connect(self.save_settings)
        
        self.ui.logMaxLine.currentIndexChanged.connect(self.update_log_viewer)
        self.ui.logMaxLine.currentIndexChanged.connect(self.save_settings)
        self.ui.userField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.completeField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.startField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.endField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.mQgsFileWidget_export.fileChanged.connect(self.save_settings)
        self.ui.format_comboBox.currentIndexChanged.connect(self.save_settings)
        self.ui.type_comboBox.currentIndexChanged.connect(self.save_settings)
        self.ui.autoSave_checkBox.toggled.connect(self.save_settings)   # [v1.2] 자동 저장 옵션

        # 작업자 관리 초기화
        user_data = self.QSettings.value('Tesk_User', '')
        user_list = [u.strip() for u in user_data.split(',')] if isinstance(user_data, str) and user_data.strip() else []
        user_list.sort()
        self.user_model = QStringListModel(user_list)
        self.ui.user_listView.setModel(self.user_model)

        self.ui.user_add.clicked.connect(self.addUser)
        self.ui.user_del.clicked.connect(self.deleteUser)
        self.ui.user_listView.clicked.connect(self.on_user_clicked)
        self.ui.user_listView.selectionModel().currentChanged.connect(lambda current, previous: self.on_user_clicked(current))
        # [v1.2 2026-11-05] 작업자 목록 우클릭 메뉴 활성화 (작업자 삭제 / 전체 작업자 현황)
        self.ui.user_listView.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.user_listView.customContextMenuRequested.connect(self.show_user_listview_context_menu)

        self.ui.move_pushButton.clicked.connect(self.move_to_working_objects)
        self.ui.complete_pushButton.clicked.connect(self.complete_working_objects)
        self.ui.folder_pushButton.clicked.connect(self.open_export_folder)
        self.ui.select_pushButton.clicked.connect(self.distribute_selected_features)
        
        self.ui.refresh.clicked.connect(self.refresh_layer_cache)

        # 우클릭 메뉴 설정
        self.ui.user_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.user_result.customContextMenuRequested.connect(self.show_user_result_context_menu)

        self.ui.select_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.select_result.customContextMenuRequested.connect(self.show_select_result_context_menu)

    # -------------------------------------------------------------
    # 1. 작업 분배 및 폴더 관리 기능
    # -------------------------------------------------------------

    def open_export_folder(self, *args):
        """분배 폴더 파일 탐색기 열기."""
        base_path = self.ui.mQgsFileWidget_export.filePath()
        if not base_path or not os.path.exists(base_path):
            QMessageBox.warning(self, "경고", "내보내기 경로가 설정되지 않았습니다.")
            return
        today_str = QDate.currentDate().toString("yyyyMMdd")
        target_path = os.path.join(base_path, today_str) if os.path.exists(os.path.join(base_path, today_str)) else base_path
        os.startfile(os.path.normpath(target_path))

    def get_current_layer_info(self, *args):
        """레이어 콤보 박스에 선택된 레이어 정보 가져오기"""
        idx = self.ui.layer.currentIndex()
        if idx <= 0: return None, None
        layer_id = self.ui.layer.itemData(idx)
        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer or not layer.isValid(): return None, None
        return layer, layer_id

    # 레이어 정보 새로 고침
    def refresh_layer_cache(self, *args):
        layer, layer_id = self.get_current_layer_info()
        if not layer: return
        # layer.commitChanges()
        self.statusBar().showMessage("데이터 새로고침 중...")
        QCoreApplication.processEvents()
        
        self.all_layers_cache[layer_id] = self._build_layer_cache_data(layer)
        self.on_selection_changed()
        self.statusBar().showMessage("새로고침 완료", 3000)

    # 미작업 객체 작업자에게 분배
    def distribute_selected_features(self, *args):
        selected_user_indexes = self.ui.user_listView.selectedIndexes()
        if not selected_user_indexes:
            QMessageBox.warning(self, "경고", "작업자를 선택해 주세요.")
            return
        user_name = selected_user_indexes[0].data(Qt.DisplayRole)
        layer, layer_id = self.get_current_layer_info()
        if not layer: return

        u_field = self.ui.userField.text().strip()      
        s_field = self.ui.startField.text().strip()     
        c_field = self.ui.completeField.text().strip()  
        base_path = self.ui.mQgsFileWidget_export.filePath()
        if not base_path: return

        u_idx, c_idx, s_idx = layer.fields().indexOf(u_field), layer.fields().indexOf(c_field), layer.fields().indexOf(s_field)

        # [v1.1 2026-11-05] 필드 미존재 시 attrs[-1](마지막 필드)이 읽히는 문제 방지
        if u_idx == -1 or c_idx == -1:
            QMessageBox.warning(self, "경고", "설정 탭의 분배/완료 필드명을 확인해 주세요.")
            return
        
        val_field = self.ui.Field.currentField()
        v_idx = layer.fields().indexOf(val_field)

        target_features = []
        target_sum = 0.0
        for f in layer.selectedFeatures():
            attrs = f.attributes()
            u_val = str(attrs[u_idx]).strip() if u_idx != -1 and attrs[u_idx] is not None else ""
            c_val = str(attrs[c_idx]).strip() if c_idx != -1 and attrs[c_idx] is not None else ""
            if (not u_val or u_val.upper() == 'NULL') and (not c_val or c_val.upper() == 'NULL'):
                target_features.append(f)
                if v_idx != -1:
                    try: target_sum += float(attrs[v_idx])
                    except (TypeError, ValueError): pass   # [v1.2] NULL(None/QVariant)은 TypeError

        if not target_features:
            self.statusBar().showMessage("분배 가능한 객체가 없습니다.", 3000)
            return

        # [v1.2 2026-11-05] 분배 전 확인창 (수량·합계 미리보기, 제외 수량)
        skip_cnt = layer.selectedFeatureCount() - len(target_features)
        preview_sum = f"{int(target_sum)}" if target_sum.is_integer() else f"{target_sum:.2f}"
        msg = f"작업자: {user_name}\n분배 수량: {len(target_features)}개\n합계({val_field or '-'}): {preview_sum}"
        if skip_cnt > 0: msg += f"\n제외(이미 분배/완료): {skip_cnt}개"
        if QMessageBox.question(self, "분배 확인", msg + "\n\n분배하시겠습니까?") != QMessageBox.Yes:
            return

        today_str = QDate.currentDate().toString("yyyyMMdd")
        date_dir = os.path.join(base_path, today_str)
        if not os.path.exists(date_dir): os.makedirs(date_dir)

        base_folder_name = f"{today_str}_{user_name}"
        export_dir = os.path.join(date_dir, base_folder_name)
        
        folder_counter = 1
        while os.path.exists(export_dir) or os.path.exists(f"{export_dir}.zip"):
            export_dir = os.path.join(date_dir, f"{base_folder_name}_{folder_counter}")
            folder_counter += 1
            
        os.makedirs(export_dir)
        final_folder_name = os.path.basename(export_dir)
        export_type = self.ui.format_comboBox.currentText().upper()
        ext = ".shp" if export_type == "SHP" else ".gpkg"
        savefile_name = f"{final_folder_name}{ext}"
        file_path = os.path.join(export_dir, savefile_name)

        assigned_val = self.get_dynamic_value(self.ui.userField_type.currentText(), self.ui.userField_lineEdit.text(), user_name)
        start_val = self.get_dynamic_value(self.ui.startField_type.currentText(), self.ui.startField_lineEdit.text(), user_name)

        if not layer.isEditable(): layer.startEditing()
        layer.beginEditCommand("분배")
        try:
            feature_ids = []
            for f in target_features:
                f_id = f.id()
                feature_ids.append(f_id)
                if u_idx != -1: layer.changeAttributeValue(f_id, u_idx, assigned_val)
                if s_idx != -1: layer.changeAttributeValue(f_id, s_idx, start_val)
                # if c_idx != -1: layer.changeAttributeValue(f_id, c_idx, "작업중")
            layer.endEditCommand()
        except Exception as e:
            layer.destroyEditCommand()
            QMessageBox.critical(self, "오류", f"분배 실패: {e}")
            return
        
        layer.selectByIds(feature_ids)
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.onlySelectedFeatures = True
        options.driverName = "ESRI Shapefile" if export_type == "SHP" else "GPKG"
        if export_type == "SHP": options.fileEncoding = "949"

        # [v1.1 2026-11-05] 결과 튜플 보관(실패 메시지 표시용)
        res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsProject.instance().transformContext(), options)

        if res[0] == QgsVectorFileWriter.NoError:
            if self.ui.type_comboBox.currentIndex() == 0: # 압축 옵션 선택 시
                shutil.make_archive(export_dir, 'zip', export_dir)
                shutil.rmtree(export_dir)
                savefile_name = f"{final_folder_name}.zip"

            if layer_id in self.all_layers_cache:
                id_set = set(feature_ids)                      # [v1.1.1] list→set (속도)
                for f_dict in self.all_layers_cache[layer_id]:
                    if f_dict['id'] in id_set:
                        if u_idx != -1: f_dict['attributes'][u_idx] = assigned_val
                        if s_idx != -1: f_dict['attributes'][s_idx] = start_val
                        # if c_idx != -1: f_dict['attributes'][c_idx] = "작업중"
            
            sum_str = f"{int(target_sum)}" if target_sum.is_integer() else f"{target_sum:.2f}"
            self.write_log(f"[분배 완료] 작업자: {user_name} | 수량: {len(target_features)}개 | 합계({val_field}): {sum_str} | 파일: {savefile_name}")
            self._auto_commit(layer)   # [v1.2] 자동 저장 옵션
            self.on_user_clicked(selected_user_indexes[0])
            QCoreApplication.processEvents()
            self.statusBar().showMessage("분배 완료 및 내보내기 성공", 5000)
        else:
            # layer.rollBack()
            # [v1.1 2026-11-05] rollBack()은 저장 안 된 모든 편집을 폐기 → 이번 '분배' 명령만 취소
            layer.undoStack().undo()
            shutil.rmtree(export_dir, ignore_errors=True)
            QMessageBox.critical(self, "오류", f"내보내기 실패: {res[1]}")
    # -------------------------------------------------------------
    # 2. 통계 및 로그 관리 기능
    # -------------------------------------------------------------

    # 작업자 선택시 해당 작업자에 대한 통계값 출력
    def on_user_clicked(self, index, *args):
        if not index.isValid(): return
        self.user_index = index
        user = index.data(Qt.DisplayRole)
        val_f, user_f, comp_f = self.ui.Field.currentField(), self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        layer, layer_id = self.get_current_layer_info()
        if not layer or layer_id not in self.all_layers_cache: return

        u_idx, c_idx, v_idx = layer.fields().indexOf(user_f), layer.fields().indexOf(comp_f), layer.fields().indexOf(val_f)
        if u_idx == -1 or c_idx == -1: return   # [v1.1] 필드 미존재
        stats = {}
        self.ui.label_8.setText(f'작업자 통계_{user}')

        for f_dict in self.all_layers_cache[layer_id]:
            attrs = f_dict['attributes']
            if str(attrs[u_idx]).strip() == user:
                status = "NULL" if attrs[c_idx] is None or str(attrs[c_idx]).upper() == 'NULL' else str(attrs[c_idx]).strip()
                num_v = 0.0
                try: num_v = float(attrs[v_idx]) if v_idx != -1 else 0.0   # [v1.1] 값 필드 미지정 시 0
                except (TypeError, ValueError): pass   # [v1.2] NULL(None/QVariant)은 TypeError
                if status not in stats: stats[status] = {'count': 0, 'sum': 0.0, 'ids': []}
                stats[status]['count'] += 1
                stats[status]['sum'] += num_v
                stats[status]['ids'].append(f_dict['id'])

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([comp_f, 'Count', 'Sum'])
        for status, data in stats.items():
            s_item = QStandardItem(status)
            s_item.setData(data['ids'], Qt.UserRole)
            sum_str = f"{int(data['sum'])}" if data['sum'].is_integer() else f"{data['sum']:.2f}"
            model.appendRow([s_item, QStandardItem(str(data['count'])), QStandardItem(sum_str)])
            
        self.ui.user_result.setModel(model)
        self.ui.user_result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged(self.ui.user_result))
        self.ui.user_result.setSortingEnabled(True)
        self.ui.user_result.sortByColumn(0, Qt.DescendingOrder)
        self.ui.user_result.resizeColumnsToContents()
        self.update_log_viewer(user)

    # 캠버스에서 객체 선택시 선택 객체에 대한 통계값 출력
    def on_selection_changed(self, *args):
        layer, _ = self.get_current_layer_info()
        if not layer: return
        
        val_f, user_f, comp_f = self.ui.Field.currentField(), self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([user_f, comp_f, 'Count', 'Sum'])
        
        feats = layer.selectedFeatures()
        if not feats:
            self.ui.select_result.setModel(model)
            self.ui.select_result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged(self.ui.select_result))
            return

        u_idx, c_idx, v_idx = layer.fields().indexOf(user_f), layer.fields().indexOf(comp_f), layer.fields().indexOf(val_f)
        stats = {}
        for f in feats:
            attrs = f.attributes()
            u_val = str(attrs[u_idx]).strip() if u_idx != -1 and attrs[u_idx] is not None else "NULL"
            c_val = str(attrs[c_idx]).strip() if c_idx != -1 and attrs[c_idx] is not None else "NULL"
            key = (u_val, c_val)
            if key not in stats: stats[key] = {'count': 0, 'sum': 0.0, 'ids': []}
            stats[key]['count'] += 1

            # [v1.1.1 2026-11-05] target_sum → stats[key]['sum'] 복구 (선택 통계 Sum 0 표시 오류), 값 필드 미지정 시 0
            try: stats[key]['sum'] += float(attrs[v_idx]) if v_idx != -1 else 0.0
            except (TypeError, ValueError): pass   # [v1.2] NULL(None/QVariant)은 TypeError

            stats[key]['ids'].append(f.id())

        for (u, c), data in stats.items():
            row = [SortableStandardItem(u), SortableStandardItem(c), SortableStandardItem(str(data['count']), True)]
            row[0].setData(data['ids'], Qt.UserRole)
            sum_v = f"{int(data['sum'])}" if data['sum'].is_integer() else f"{data['sum']:.2f}"
            row.append(SortableStandardItem(sum_v, True))
            model.appendRow(row)
        
        self.ui.select_result.setModel(model)
        self.ui.select_result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged(self.ui.select_result))
        self.ui.select_result.setSortingEnabled(True)
        self.ui.select_result.sortByColumn(0, Qt.AscendingOrder)
        self.ui.select_result.resizeColumnsToContents()

    # 로그 기록 새로고침
    def update_log_viewer(self, selected_user=None, *args):
        if not selected_user or isinstance(selected_user, int):
            sel = self.ui.user_listView.selectedIndexes()
            if not sel: return
            selected_user = sel[0].data(Qt.DisplayRole)

        log_dir = QgsApplication.qgisSettingsDirPath()
        log_file = os.path.join(log_dir, "TaskManager_Log.txt")
        log_messages = []
        
        files = [f"{log_file}.{i}" for i in range(3, 0, -1) if os.path.exists(f"{log_file}.{i}")] + ([log_file] if os.path.exists(log_file) else [])
        for fp in files:
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    for line in f:
                        # [v1.1 2026-11-05] 구분자 ' |'까지 비교 → '김'이 '김철수' 로그에 걸리는 문제 방지
                        if f"작업자: {selected_user} |" in line: log_messages.append(line.strip())
            except (OSError, ValueError): pass   # [v1.2] 파일 접근 실패(OSError)·인코딩 오류(UnicodeDecodeError⊂ValueError)

        limit = self.ui.logMaxLine.currentText()
        if limit.isdigit(): log_messages = log_messages[-int(limit):]
        log_messages.reverse()
        self.ui.log_textEdit.setPlainText("\n".join(log_messages) if log_messages else f"'{selected_user}'의 로그가 없습니다.")

    # -------------------------------------------------------------
    # 3. 공통 유틸리티 및 설정
    # -------------------------------------------------------------

    # 레이어 정보 캐싱
    def _build_layer_cache_data(self, layer, *args):
        QCoreApplication.processEvents()
        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        provider = layer.dataProvider()

        # 2. 진행률 표시를 위해 레이어의 전체 객체(Feature) 개수 파악
        total_features = provider.featureCount()
        if total_features < 0:
            total_features = layer.featureCount()

        cache = []
        counter = 0
        for f in layer.getFeatures(request):  # for f in provider.getFeatures(request):
            cache.append({'id': f.id(), 'attributes': f.attributes()})
            counter += 1

            # 4. 너무 잦은 업데이트는 오히려 연산 속도를 떨어뜨리므로 1000개 단위로 갱신
            if counter % 1000 == 0:
                if total_features > 0:
                    percent = (counter / total_features) * 100
                    self.statusBar().showMessage(f"데이터 불러오는 중... {percent:.1f}% ({counter:,} / {total_features:,})")
                else:
                    self.statusBar().showMessage(f"데이터 불러오는 중... {counter:,}개 완료")
                QCoreApplication.processEvents() # 화면이 멈추지(프리징) 않도록 주기적으로 숨통 틔우기
        return cache
    # 객체 이동
    def _zoom_to_feature_ids(self, layer, ids, *args):
        if not ids or not layer: return
        layer.selectByIds(list(set(ids)))
        iface.mapCanvas().zoomToSelected(layer)

    # 로그 기록
    def write_log(self, message, *args):
        if not hasattr(self, 'logger'): self.setup_logger()
        try: self.logger.info(message)
        except Exception: pass   # [v1.2] 로그 실패가 작업(분배/완료)을 막지 않도록 전체 예외 무시

    # 로그 기록
    def setup_logger(self, *args):
        log_file = os.path.join(QgsApplication.qgisSettingsDirPath(), "TaskManager_Log.txt")
        self.logger = logging.getLogger("TaskManagerLogger")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            h = RotatingFileHandler(log_file, maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
            h.setFormatter(logging.Formatter('[%(asctime)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S"))
            self.logger.addHandler(h)

    # 작업자 추가
    def addUser(self, *args):
        name = self.ui.user_lineEdit.text().strip()
        if not name: return
        # [v1.2] ','는 작업자 목록 저장 구분자(Tesk_User)이므로 사용 불가
        if ',' in name:
            QMessageBox.warning(self, "경고", "작업자 이름에 ','는 사용할 수 없습니다.")
            return
        names = self.user_model.stringList()
        if name in names: return
        names.append(name)
        names.sort()
        self.user_model.setStringList(names)
        self.QSettings.setValue('Tesk_User', ",".join(names))
        self.ui.user_lineEdit.clear()

    # 작업자 삭제
    def deleteUser(self, *args):
        name = self.ui.user_lineEdit.text().strip()
        # [v1.2 2026-11-05] 입력창이 비어 있으면 목록에서 선택한 작업자를 삭제
        if not name:
            sel = self.ui.user_listView.selectedIndexes()
            if not sel: return
            name = sel[0].data(Qt.DisplayRole)
        names = self.user_model.stringList()
        if name in names:
            # [v1.2] 삭제 확인 (레이어 속성값·로그는 유지)
            if QMessageBox.question(self, "작업자 삭제", f"'{name}' 작업자를 목록에서 삭제하시겠습니까?\n(레이어 속성값과 로그는 유지됩니다)") != QMessageBox.Yes:
                return
            names.remove(name)
            self.user_model.setStringList(names)
            self.QSettings.setValue('Tesk_User', ",".join(names))

    # 작업중 객체 이동
    def move_to_working_objects(self, *args):
        sel = self.ui.user_listView.selectedIndexes()
        if not sel: return
        user = sel[0].data(Qt.DisplayRole)
        
        layer, lid = self.get_current_layer_info()
        if not layer: return                                   # [v1.1.1] 레이어 미선택
        u_f, c_f = self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        u_idx, c_idx = layer.fields().indexOf(u_f), layer.fields().indexOf(c_f)
        if u_idx == -1 or c_idx == -1: return                  # [v1.1.1] 필드 미존재
        
        target_ids = []
        for f_dict in self.all_layers_cache.get(lid, []):
            attrs = f_dict['attributes']
            if str(attrs[u_idx]).strip() == user and (not attrs[c_idx] or str(attrs[c_idx]) in ["작업중", "NULL"]):
                target_ids.append(f_dict['id'])
        self._zoom_to_feature_ids(layer, target_ids)

    # 작업중 객체 완료 처리
    def complete_working_objects(self, *args):
        sel = self.ui.user_listView.selectedIndexes()
        if not sel: return
        user = sel[0].data(Qt.DisplayRole)
        layer, lid = self.get_current_layer_info()
        if not layer: return                                   # [v1.1] 레이어 미선택
        u_f, c_f, e_f = self.ui.userField.text().strip(), self.ui.completeField.text().strip(), self.ui.endField.text().strip()
        u_idx, c_idx, e_idx = layer.fields().indexOf(u_f), layer.fields().indexOf(c_f), layer.fields().indexOf(e_f)
        if u_idx == -1 or c_idx == -1: return                  # [v1.1] 필드 미존재
        ids = [d['id'] for d in self.all_layers_cache.get(lid, []) if str(d['attributes'][u_idx]).strip() == user and (not d['attributes'][c_idx] or str(d['attributes'][c_idx]) == "작업중")]
        if not ids: return

        # [v1.2 2026-11-05] 완료처리 확인창 (분배만 하고 미반납된 건도 함께 완료됨에 유의)
        if QMessageBox.question(self, "완료처리 확인", f"작업자: {user}\n완료처리 대상: {len(ids)}개\n\n완료처리하시겠습니까?") != QMessageBox.Yes:
            return

        val = self.get_dynamic_value(self.ui.completeField_type.currentText(), self.ui.completeField_lineEdit.text(), user) or "완료"
        dt = self.get_dynamic_value(self.ui.endField_type.currentText(), self.ui.endField_lineEdit.text(), user) or QDateTime.currentDateTime().toString("yyyy-MM-dd")

        if not layer.isEditable(): layer.startEditing()
        layer.beginEditCommand("완료처리")
        try:
            for fid in ids:
                if c_idx != -1: layer.changeAttributeValue(fid, c_idx, val)
                if e_idx != -1: layer.changeAttributeValue(fid, e_idx, dt)
            layer.endEditCommand()
        except Exception as e:
            # [v1.1.2 2026-11-05] 편집 명령 구간만 try로 감싸고, 실패 시 메시지 표시
            layer.destroyEditCommand()
            QMessageBox.critical(self, "오류", f"완료처리 실패: {e}")
            return
        
        id_set = set(ids)                                  # [v1.1] list→set (속도)
        for d in self.all_layers_cache[lid]:
            if d['id'] in id_set:
                if c_idx != -1: d['attributes'][c_idx] = val   # [v1.1] -1 덮어쓰기 방지
                if e_idx != -1: d['attributes'][e_idx] = dt
        self.write_log(f"[완료 처리] 작업자: {user} | 수량: {len(ids)}개")   # [v1.2] 완료처리 로그
        self._auto_commit(layer)                                           # [v1.2] 자동 저장 옵션
        self.on_user_clicked(sel[0])

    # [v1.2 2026-11-05] 자동 저장 (설정 탭 '작업 후 레이어 자동 저장' 체크 시)
    #   ※ 이 레이어의 저장 안 된 '모든' 편집(수동 편집 포함)이 함께 저장된다
    #   ※ commitChanges(False): 저장 후 편집모드 유지
    def _auto_commit(self, layer, *args):
        if not self.ui.autoSave_checkBox.isChecked(): return
        if not layer.commitChanges(False):
            QMessageBox.warning(self, "경고", "자동 저장 실패:\n" + "\n".join(layer.commitErrors()))

    # [v1.2 2026-11-05] 선택 객체 분배 회수
    #   캔버스에서 선택한 객체 중 '분배됨 + 미완료(NULL/작업중)' 객체의 작업자·시작 필드를 NULL로 되돌림
    #   ※ 이미 내보낸 분배 파일(zip/폴더)은 삭제하지 않는다
    def recall_selected_features(self, *args):
        layer, layer_id = self.get_current_layer_info()
        if not layer: return
        u_f, s_f, c_f = self.ui.userField.text().strip(), self.ui.startField.text().strip(), self.ui.completeField.text().strip()
        u_idx, s_idx, c_idx = layer.fields().indexOf(u_f), layer.fields().indexOf(s_f), layer.fields().indexOf(c_f)
        if u_idx == -1 or c_idx == -1:
            QMessageBox.warning(self, "경고", "설정 탭의 분배/완료 필드명을 확인해 주세요.")
            return

        per_user = {}   # 작업자 → [fid, ...]
        for f in layer.selectedFeatures():
            attrs = f.attributes()
            u_val = str(attrs[u_idx]).strip() if attrs[u_idx] is not None else ""
            c_val = str(attrs[c_idx]).strip() if attrs[c_idx] is not None else ""
            if u_val and u_val.upper() != 'NULL' and (not c_val or c_val.upper() == 'NULL' or c_val == "작업중"):
                per_user.setdefault(u_val, []).append(f.id())
        if not per_user:
            self.statusBar().showMessage("회수 가능한 객체가 없습니다.", 3000)
            return

        total = sum(len(v) for v in per_user.values())
        detail = "\n".join(f"  {u}: {len(v)}개" for u, v in sorted(per_user.items()))
        if QMessageBox.question(self, "분배 회수 확인", f"회수 대상: {total}개\n{detail}\n\n이미 내보낸 분배 파일은 삭제되지 않습니다.\n회수하시겠습니까?") != QMessageBox.Yes:
            return

        ids = [i for v in per_user.values() for i in v]
        if not layer.isEditable(): layer.startEditing()
        layer.beginEditCommand("분배 회수")
        try:
            for fid in ids:
                layer.changeAttributeValue(fid, u_idx, NULL)
                if s_idx != -1: layer.changeAttributeValue(fid, s_idx, NULL)
            layer.endEditCommand()
        except Exception as e:
            layer.destroyEditCommand()
            QMessageBox.critical(self, "오류", f"분배 회수 실패: {e}")
            return

        id_set = set(ids)
        for d in self.all_layers_cache.get(layer_id, []):
            if d['id'] in id_set:
                d['attributes'][u_idx] = NULL
                if s_idx != -1: d['attributes'][s_idx] = NULL
        for u, v in sorted(per_user.items()):
            self.write_log(f"[분배 회수] 작업자: {u} | 수량: {len(v)}개")
        self._auto_commit(layer)
        self.on_selection_changed()
        sel = self.ui.user_listView.selectedIndexes()
        if sel: self.on_user_clicked(sel[0])
        self.statusBar().showMessage(f"분배 회수 완료: {total}개", 5000)

    # [v1.2 2026-11-05] 전체 작업자 현황 : 작업자 × 완료상태별 수량·합계를 '작업자 통계' 표에 표시
    #   작업자 필드가 비어 있는 객체는 '미할당'으로 집계
    def show_all_user_summary(self, *args):
        layer, layer_id = self.get_current_layer_info()
        if not layer or layer_id not in self.all_layers_cache: return
        val_f, user_f, comp_f = self.ui.Field.currentField(), self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        u_idx, c_idx, v_idx = layer.fields().indexOf(user_f), layer.fields().indexOf(comp_f), layer.fields().indexOf(val_f)
        if u_idx == -1 or c_idx == -1:
            QMessageBox.warning(self, "경고", "설정 탭의 분배/완료 필드명을 확인해 주세요.")
            return

        stats = {}
        for d in self.all_layers_cache[layer_id]:
            attrs = d['attributes']
            u = str(attrs[u_idx]).strip() if attrs[u_idx] is not None else ""
            if not u or u.upper() == 'NULL': u = "미할당"
            c = "NULL" if attrs[c_idx] is None or str(attrs[c_idx]).upper() == 'NULL' else str(attrs[c_idx]).strip()
            key = (u, c)
            if key not in stats: stats[key] = {'count': 0, 'sum': 0.0, 'ids': []}
            stats[key]['count'] += 1
            try: stats[key]['sum'] += float(attrs[v_idx]) if v_idx != -1 else 0.0
            except (TypeError, ValueError): pass
            stats[key]['ids'].append(d['id'])

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([user_f, comp_f, 'Count', 'Sum'])
        for (u, c), data in stats.items():
            row = [SortableStandardItem(u), SortableStandardItem(c), SortableStandardItem(str(data['count']), True)]
            row[0].setData(data['ids'], Qt.UserRole)   # '객체 이동' 우클릭 메뉴용
            sum_v = f"{int(data['sum'])}" if data['sum'].is_integer() else f"{data['sum']:.2f}"
            row.append(SortableStandardItem(sum_v, True))
            model.appendRow(row)

        self.ui.label_8.setText('작업자 통계_전체')
        self.ui.user_result.setModel(model)
        self.ui.user_result.selectionModel().selectionChanged.connect(lambda selected, deselected: self.onSelectionChanged(self.ui.user_result))
        self.ui.user_result.setSortingEnabled(True)
        self.ui.user_result.sortByColumn(0, Qt.AscendingOrder)
        self.ui.user_result.resizeColumnsToContents()

    # 완료 처리, 작업 분배 헬퍼 함수
    def get_dynamic_value(self, t, l, u, *args):
        now = QDateTime.currentDateTime()
        if t == "작업자": return u
        if t == "지정값 사용": return l
        if t == "날짜 시간": return now.toString("yyyy-MM-dd HH:mm:ss")
        if t == "날짜": return now.toString("yyyy-MM-dd")
        if t == "주차": 
            wi = now.date().dayOfWeek() - 1
            sw = now.addDays(-wi)
            return f"{sw.date().month()}{math.ceil(sw.date().day()/7)}"
        return None
    
    # 설정 가져오기
    def load_settings(self, *args):
        for n in ["userField", "completeField", "startField", "endField", "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]:
            getattr(self.ui, n).setText(self.QSettings.value(n, ""))
        for n in ["logMaxLine", "userField_type", "completeField_type", "startField_type", "endField_type", "format_comboBox", "type_comboBox"]:
            getattr(self.ui, n).setCurrentIndex(int(self.QSettings.value(n, 0)))
        self.ui.mQgsFileWidget_export.setFilePath(self.QSettings.value("path_export", ""))
        self.ui.autoSave_checkBox.setChecked(self.QSettings.value("autoSave", False, type=bool))   # [v1.2]

    # 설정 저장
    def save_settings(self, *args):
        for n in ["userField", "completeField", "startField", "endField", "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]:
            self.QSettings.setValue(n, getattr(self.ui, n).text().strip())
        for n in ["logMaxLine", "userField_type", "completeField_type", "startField_type", "endField_type", "format_comboBox", "type_comboBox"]:
            self.QSettings.setValue(n, getattr(self.ui, n).currentIndex())
        self.QSettings.setValue("path_export", self.ui.mQgsFileWidget_export.filePath())
        self.QSettings.setValue("autoSave", self.ui.autoSave_checkBox.isChecked())   # [v1.2]

    # 작업자 리스트 우클릭 메뉴
    def show_user_listview_context_menu(self, pos, *args):
        m = QMenu()
        # 예시: 작업자 삭제 액션 추가
        a1 = QAction("작업자 삭제", self)
        a1.triggered.connect(self.deleteUser)
        m.addAction(a1)
        # [v1.2 2026-11-05] 전체 작업자 현황
        m.addSeparator()
        a2 = QAction("전체 작업자 현황", self)
        a2.triggered.connect(self.show_all_user_summary)
        m.addAction(a2)

        m.exec_(self.ui.user_listView.viewport().mapToGlobal(pos))



    # 작업자 테이블 우클릭 메뉴
    def show_user_result_context_menu(self, pos, *args):
        m = QMenu()
        a1 = QAction("객체 이동", self)
        a1.triggered.connect(lambda: self.result_on_map(self.ui.user_result))
        m.addAction(a1)
        m.addSeparator()
        a2 = QAction("셀 내용 복사", self)
        a2.triggered.connect(lambda: self._copy_table_selection_to_clipboard(self.ui.user_result))
        m.addAction(a2)
        a3 = QAction("전체 내용 복사", self)
        a3.triggered.connect(lambda: self._copy_table_all_clipboard(self.ui.user_result))
        m.addAction(a3)
        m.exec_(self.ui.user_result.viewport().mapToGlobal(pos))

    # 선택 객체 테이블 우클릭 메뉴
    def show_select_result_context_menu(self, pos, *args):
        m = QMenu()
        a1 = QAction("객체 이동", self)
        a1.triggered.connect(lambda: self.result_on_map(self.ui.select_result))
        m.addAction(a1)
        m.addSeparator()
        a2 = QAction("셀 내용 복사", self)
        a2.triggered.connect(lambda: self._copy_table_selection_to_clipboard(self.ui.select_result))
        m.addAction(a2)
        a3 = QAction("전체 내용 복사", self)
        a3.triggered.connect(lambda: self._copy_table_all_clipboard(self.ui.select_result))
        m.addAction(a3)
        # [v1.2 2026-11-05] 선택 객체 분배 회수
        m.addSeparator()
        a4 = QAction("선택 객체 분배 회수", self)
        a4.triggered.connect(self.recall_selected_features)
        m.addAction(a4)
        m.exec_(self.ui.select_result.viewport().mapToGlobal(pos))

    # 테이블 선택된 셀 내용 복사
    def _copy_table_selection_to_clipboard(self, view, *args):
        sel = view.selectedIndexes()
        if not sel: return
        rows = {}
        for i in sel:
            if i.row() not in rows: rows[i.row()] = {}
            rows[i.row()][i.column()] = i.data()
        txt = "\n".join(["\t".join([str(rows[r][c]) for c in sorted(rows[r].keys())]) for r in sorted(rows.keys())])
        QApplication.clipboard().setText(txt)

    # 테이블에서 선택된 셀 합계 출력
    def onSelectionChanged(self, result, *args):
        indexList = result.selectedIndexes()
        total = 0
        count = 0

        for item in indexList:
            text = item.data(Qt.DisplayRole)#.toList()
            try:
                value = float(text)
                total += value
                count += 1
            except ValueError:
                count += 1
                continue
        total = self.format_number(round(total,4))
        if count > 0:
            self.statusBar().showMessage(f"개수: {count}  평균: {self.format_number(round(total/count,4))}  합계: {total}")
        else:
            self.statusBar().showMessage('')

    # 선택된 셀 합계 출력 헬퍼 함수
    def format_number(self, num, *args):
        if isinstance(num, float) and num.is_integer():
            return int(num)
        return round(num, 4)
    
    def _copy_table_all_clipboard(self, result, *args):
        """테이블의 전체 데이터(헤더 포함)를 클립보드에 복사합니다."""
        model = result.model()
        if not model:
            return

        lines = []
        
        # 1. 상단 헤더(컬럼 이름) 추출
        header = []
        for c in range(model.columnCount()):
            header.append(str(model.headerData(c, Qt.Horizontal, Qt.DisplayRole) or ""))
        lines.append("\t".join(header))

        # 2. 본문 데이터 추출
        for r in range(model.rowCount()):
            row_data = []
            for c in range(model.columnCount()):
                idx = model.index(r, c)
                row_data.append(str(idx.data(Qt.DisplayRole) or ""))
            lines.append("\t".join(row_data))

        QApplication.clipboard().setText("\n".join(lines))
        self.statusBar().showMessage('전체 데이터를 클립보드에 복사했습니다.', 5000)
    
    def result_on_map(self, result, *args):
        """테이블에서 선택된 객체 이동"""
        id_list = [j for i in result.selectedIndexes() for j in (result.model().index(i.row(), 0).data(Qt.UserRole) or [])]
        if id_list:
            layer, _ = self.get_current_layer_info()
            self._zoom_to_feature_ids(layer, id_list)

    def layerSelection(self, index, *args):
        """레이어 콤보 박스 수정시 동작 함수"""
        l, lid = self.get_current_layer_info()
        self.ui.log_textEdit.setPlainText("")
        if getattr(self, 'current_connected_layer', None):
            try: self.current_connected_layer.selectionChanged.disconnect(self.on_selection_changed)
            except (TypeError, RuntimeError): pass   # [v1.2] 미연결=TypeError, 삭제된 레이어=RuntimeError
        self.current_connected_layer = l
        if l:
            l.selectionChanged.connect(self.on_selection_changed)
            self.ui.Field.setLayer(l)
            if lid not in self.all_layers_cache:
                self.statusBar().showMessage("레이어 캐싱 중...")
                QCoreApplication.processEvents()
                self.all_layers_cache[lid] = self._build_layer_cache_data(l)
                self.statusBar().showMessage("레이어 캐싱 완료", 3000)
            self.on_selection_changed()    

    def setLayers (self, layer, *args):
        """첫 실행시 동작 함수"""
        index = self.ui.layer.currentIndex()
        if index !=-1:
            layerId = self.ui.layer.itemData(index)

        self.ui.layer.blockSignals(True)
        self.ui.layer.clear()
        self.ui.layer.addItem("레이어를 선택하세요...", None)

        for i in layer:
            self.ui.layer.addItem(i[0], i[1])

        if index !=-1:
            index2 = self.ui.layer.findData(layerId)
            if index2 !=-1:
                self.ui.layer.setCurrentIndex(index2)
            else:
                self.ui.layer.setCurrentIndex(0)
        else:
            self.ui.layer.setCurrentIndex(0)

        self.ui.layer.blockSignals(False)