# -*- coding: utf-8 -*-
import os, shutil
import logging
from logging.handlers import RotatingFileHandler
import math
from PyQt5 import uic
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import (QMainWindow, QWidget, 
                             QMenu, QAction, QMessageBox, QDialog, QApplication, QFileDialog)
from openpyxl import Workbook

from qgis.utils import iface
from qgis.core import *
from qgis.gui import *

# [수정] 피벗 테이블 관련 클래스 제거 (필요한 경우만 남김)
# -------------------------------------------------------------

# 정렬용 커스텀 클래스 (선택 객체 통계에서 계속 사용)
class SortableStandardItem(QStandardItem):
    def __init__(self, text, is_numeric=False):
        super().__init__(text)
        self.is_numeric = is_numeric

    def __lt__(self, other):
        text1 = self.text().strip()
        text2 = other.text().strip()
        null_words = ["", "NULL", "미할당", "작업중"]
        is_null1 = text1.upper() in null_words
        is_null2 = text2.upper() in null_words
        
        if is_null1 and not is_null2: return True
        if not is_null1 and is_null2: return False
        if self.is_numeric:
            try:
                return float(text1.replace(',', '')) < float(text2.replace(',', ''))
            except ValueError: pass
        return text1 < text2

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/Coordinate_Tool_TaskManager.ui'))

class CoordinateToolTaskManager(QMainWindow):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        self.ui = FORM_CLASS()
        self.ui.setupUi(self)
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")

        self.all_layers_cache = {}
        self.current_connected_layer = None 

        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.ui.layer.currentIndexChanged.connect(self.layerSelection)

        # 설정 탭 자동 저장 초기화
        self.load_settings()

        # 시그널 연결 (QLineEdit & QComboBox)
        self.ui.userField.textChanged.connect(self.save_settings)
        self.ui.completeField.textChanged.connect(self.save_settings)
        self.ui.startField.textChanged.connect(self.save_settings)
        self.ui.endField.textChanged.connect(self.save_settings)
        self.ui.userField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.completeField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.startField_lineEdit.textChanged.connect(self.save_settings)
        self.ui.endField_lineEdit.textChanged.connect(self.save_settings)
        
        self.ui.logMaxLine.currentIndexChanged.connect(self.update_log_viewer)
        self.ui.logMaxLine.currentIndexChanged.connect(self.save_settings)
        self.ui.userField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.completeField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.startField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.endField_type.currentIndexChanged.connect(self.save_settings)
        self.ui.mQgsFileWidget_export.fileChanged.connect(self.save_settings)
        self.ui.format_comboBox.currentIndexChanged.connect(self.save_settings)
        self.ui.type_comboBox.currentIndexChanged.connect(self.save_settings)

        # 작업자 관리 초기화
        user_data = self.QSettings.value('Tesk_User', '')
        user_list = [u.strip() for u in user_data.split(',')] if isinstance(user_data, str) and user_data.strip() else []
        user_list.sort()
        self.user_model = QStringListModel(user_list)
        self.ui.user_listView.setModel(self.user_model)

        self.ui.user_add.clicked.connect(self.addUser)
        self.ui.user_del.clicked.connect(self.deleteUser)
        self.ui.user_listView.clicked.connect(self.on_user_clicked)
        self.ui.user_listView.selectionModel().currentChanged.connect(lambda current, previous: self.on_user_clicked(current))

        self.ui.move_pushButton.clicked.connect(self.move_to_working_objects)
        self.ui.complete_pushButton.clicked.connect(self.complete_working_objects)
        self.ui.folder_pushButton.clicked.connect(self.open_export_folder)
        self.ui.select_pushButton.clicked.connect(self.distribute_selected_features)
        
        self.ui.refresh.clicked.connect(self.refresh_layer_cache)

        # 우클릭 메뉴 설정
        self.ui.user_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.user_result.customContextMenuRequested.connect(self.show_user_result_context_menu)
        self.ui.select_result.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ui.select_result.customContextMenuRequested.connect(self.show_select_result_context_menu)

    # -------------------------------------------------------------
    # 1. 작업 분배 및 폴더 관리 기능
    # -------------------------------------------------------------
    def open_export_folder(self):
        base_path = self.ui.mQgsFileWidget_export.filePath()
        if not base_path or not os.path.exists(base_path):
            QMessageBox.warning(self, "경고", "내보내기 경로가 설정되지 않았습니다.")
            return
        today_str = QDate.currentDate().toString("yyyyMMdd")
        target_path = os.path.join(base_path, today_str) if os.path.exists(os.path.join(base_path, today_str)) else base_path
        os.startfile(os.path.normpath(target_path))

    def get_current_layer_info(self):
        idx = self.ui.layer.currentIndex()
        if idx <= 0: return None, None
        layer_id = self.ui.layer.itemData(idx)
        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer or not layer.isValid(): return None, None
        return layer, layer_id

    def refresh_layer_cache(self):
        layer, layer_id = self.get_current_layer_info()
        if not layer: return
        layer.commitChanges()
        self.statusBar().showMessage("데이터 새로고침 중...")
        QCoreApplication.processEvents()
        
        self.all_layers_cache[layer_id] = self._build_layer_cache_data(layer)
        self.on_selection_changed()
        self.statusBar().showMessage("새로고침 완료", 3000)

    def distribute_selected_features(self):
        selected_user_indexes = self.ui.user_listView.selectedIndexes()
        if not selected_user_indexes:
            QMessageBox.warning(self, "경고", "작업자를 선택해 주세요.")
            return
        user_name = selected_user_indexes[0].data(Qt.DisplayRole)
        layer, layer_id = self.get_current_layer_info()
        if not layer: return

        u_field = self.ui.userField.text().strip()      
        s_field = self.ui.startField.text().strip()     
        c_field = self.ui.completeField.text().strip()  
        base_path = self.ui.mQgsFileWidget_export.filePath()
        if not base_path: return

        u_idx, c_idx, s_idx = layer.fields().indexOf(u_field), layer.fields().indexOf(c_field), layer.fields().indexOf(s_field)
        val_field = self.ui.Field.currentField()
        v_idx = layer.fields().indexOf(val_field)

        target_features = []
        target_sum = 0.0
        for f in layer.selectedFeatures():
            attrs = f.attributes()
            u_val = str(attrs[u_idx]).strip() if u_idx != -1 and attrs[u_idx] is not None else ""
            c_val = str(attrs[c_idx]).strip() if c_idx != -1 and attrs[c_idx] is not None else ""
            if (not u_val or u_val.upper() == 'NULL') and (not c_val or c_val.upper() == 'NULL'):
                target_features.append(f)
                if v_idx != -1:
                    try: target_sum += float(attrs[v_idx])
                    except: pass

        if not target_features:
            self.statusBar().showMessage("분배 가능한 객체가 없습니다.", 3000)
            return

        today_str = QDate.currentDate().toString("yyyyMMdd")
        date_dir = os.path.join(base_path, today_str)
        if not os.path.exists(date_dir): os.makedirs(date_dir)

        base_folder_name = f"{today_str}_{user_name}"
        export_dir = os.path.join(date_dir, base_folder_name)
        
        folder_counter = 1
        while os.path.exists(export_dir) or os.path.exists(f"{export_dir}.zip"):
            export_dir = os.path.join(date_dir, f"{base_folder_name}_{folder_counter}")
            folder_counter += 1
            
        os.makedirs(export_dir)
        final_folder_name = os.path.basename(export_dir)
        export_type = self.ui.format_comboBox.currentText().upper()
        ext = ".shp" if export_type == "SHP" else ".gpkg"
        savefile_name = f"{final_folder_name}{ext}"
        file_path = os.path.join(export_dir, savefile_name)

        assigned_val = self.get_dynamic_value(self.ui.userField_type.currentText(), self.ui.userField_lineEdit.text(), user_name)
        start_val = self.get_dynamic_value(self.ui.startField_type.currentText(), self.ui.startField_lineEdit.text(), user_name)

        if not layer.isEditable(): layer.startEditing()
        layer.beginEditCommand("분배")
        try:
            feature_ids = []
            for f in target_features:
                f_id = f.id()
                feature_ids.append(f_id)
                if u_idx != -1: layer.changeAttributeValue(f_id, u_idx, assigned_val)
                if s_idx != -1: layer.changeAttributeValue(f_id, s_idx, start_val)
                # if c_idx != -1: layer.changeAttributeValue(f_id, c_idx, "작업중")
            layer.endEditCommand()
        except Exception as e:
            layer.destroyEditCommand()
            QMessageBox.critical(self, "오류", f"분배 실패: {e}")
            return
        
        layer.selectByIds(feature_ids)
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "ESRI Shapefile" if export_type == "SHP" else "GPKG"
        if export_type == "SHP": options.fileEncoding = "949"

        if QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsProject.instance().transformContext(), options)[0] == QgsVectorFileWriter.NoError:
            if self.ui.type_comboBox.currentIndex() == 0: # 압축 옵션 선택 시
                shutil.make_archive(export_dir, 'zip', export_dir)
                shutil.rmtree(export_dir)
                savefile_name = f"{final_folder_name}.zip"

            if layer_id in self.all_layers_cache:
                for f_dict in self.all_layers_cache[layer_id]:
                    if f_dict['id'] in feature_ids:
                        if u_idx != -1: f_dict['attributes'][u_idx] = assigned_val
                        if s_idx != -1: f_dict['attributes'][s_idx] = start_val
                        # if c_idx != -1: f_dict['attributes'][c_idx] = "작업중"
            
            sum_str = f"{int(target_sum)}" if target_sum.is_integer() else f"{target_sum:.2f}"
            self.write_log(f"[분배 완료] 작업자: {user_name} | 수량: {len(target_features)}개 | 합계({val_field}): {sum_str} | 파일: {savefile_name}")
            self.on_user_clicked(selected_user_indexes[0])
            QCoreApplication.processEvents()
            self.statusBar().showMessage("분배 완료 및 내보내기 성공", 5000)
        else:
            layer.rollBack()

    # -------------------------------------------------------------
    # 2. 통계 및 로그 관리 기능
    # -------------------------------------------------------------
    def on_user_clicked(self, index):
        if not index.isValid(): return
        user = index.data(Qt.DisplayRole)
        val_f, user_f, comp_f = self.ui.Field.currentField(), self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        layer, layer_id = self.get_current_layer_info()
        if not layer or layer_id not in self.all_layers_cache: return

        u_idx, c_idx, v_idx = layer.fields().indexOf(user_f), layer.fields().indexOf(comp_f), layer.fields().indexOf(val_f)
        stats = {}
        self.ui.label_8.setText(f'작업자 통계_{user}')

        for f_dict in self.all_layers_cache[layer_id]:
            attrs = f_dict['attributes']
            if str(attrs[u_idx]).strip() == user:
                status = "NULL" if attrs[c_idx] is None or str(attrs[c_idx]).upper() == 'NULL' else str(attrs[c_idx]).strip()
                num_v = 0.0
                try: num_v = float(attrs[v_idx])
                except: pass
                if status not in stats: stats[status] = {'count': 0, 'sum': 0.0, 'ids': []}
                stats[status]['count'] += 1
                stats[status]['sum'] += num_v
                stats[status]['ids'].append(f_dict['id'])

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([comp_f, 'Count', 'Sum'])
        for status, data in stats.items():
            s_item = QStandardItem(status)
            s_item.setData(data['ids'], Qt.UserRole)
            sum_str = f"{int(data['sum'])}" if data['sum'].is_integer() else f"{data['sum']:.2f}"
            model.appendRow([s_item, QStandardItem(str(data['count'])), QStandardItem(sum_str)])
            
        self.ui.user_result.setModel(model)
        self.ui.user_result.setSortingEnabled(True)
        self.ui.user_result.sortByColumn(0, Qt.DescendingOrder)
        self.update_log_viewer(user)

    def on_selection_changed(self):
        layer, _ = self.get_current_layer_info()
        if not layer: return
        
        val_f, user_f, comp_f = self.ui.Field.currentField(), self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([user_f, comp_f, 'Count', 'Sum'])
        
        feats = layer.selectedFeatures()
        if not feats:
            self.ui.select_result.setModel(model)
            return

        u_idx, c_idx, v_idx = layer.fields().indexOf(user_f), layer.fields().indexOf(comp_f), layer.fields().indexOf(val_f)
        stats = {}
        for f in feats:
            attrs = f.attributes()
            u_val = str(attrs[u_idx]).strip() if u_idx != -1 and attrs[u_idx] is not None else "NULL"
            c_val = str(attrs[c_idx]).strip() if c_idx != -1 and attrs[c_idx] is not None else "NULL"
            key = (u_val, c_val)
            if key not in stats: stats[key] = {'count': 0, 'sum': 0.0, 'ids': []}
            stats[key]['count'] += 1
            try: stats[key]['sum'] += float(attrs[v_idx])
            except: pass
            stats[key]['ids'].append(f.id())

        for (u, c), data in stats.items():
            row = [SortableStandardItem(u), SortableStandardItem(c), SortableStandardItem(str(data['count']), True)]
            row[0].setData(data['ids'], Qt.UserRole)
            sum_v = f"{int(data['sum'])}" if data['sum'].is_integer() else f"{data['sum']:.2f}"
            row.append(SortableStandardItem(sum_v, True))
            model.appendRow(row)
        
        self.ui.select_result.setModel(model)
        self.ui.select_result.setSortingEnabled(True)
        self.ui.select_result.sortByColumn(0, Qt.AscendingOrder)

    def update_log_viewer(self, selected_user=None):
        if not selected_user or isinstance(selected_user, int):
            sel = self.ui.user_listView.selectedIndexes()
            if not sel: return
            selected_user = sel[0].data(Qt.DisplayRole)

        log_dir = QgsApplication.qgisSettingsDirPath()
        log_file = os.path.join(log_dir, "TaskManager_Log.txt")
        log_messages = []
        
        files = [f"{log_file}.{i}" for i in range(3, 0, -1) if os.path.exists(f"{log_file}.{i}")] + ([log_file] if os.path.exists(log_file) else [])
        for fp in files:
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    for line in f:
                        if f"작업자: {selected_user}" in line: log_messages.append(line.strip())
            except: pass

        limit = self.ui.logMaxLine.currentText()
        if limit.isdigit(): log_messages = log_messages[-int(limit):]
        log_messages.reverse()
        self.ui.log_textEdit.setPlainText("\n".join(log_messages) if log_messages else f"'{selected_user}'의 로그가 없습니다.")

    # -------------------------------------------------------------
    # 3. 공통 유틸리티 및 설정
    # -------------------------------------------------------------
    def _build_layer_cache_data(self, layer):
        cache = []
        for f in layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
            cache.append({'id': f.id(), 'attributes': f.attributes()})
        return cache

    def _zoom_to_feature_ids(self, layer, ids):
        if not ids or not layer: return
        layer.selectByIds(list(set(ids)))
        iface.mapCanvas().zoomToSelected(layer)

    def write_log(self, message):
        if not hasattr(self, 'logger'): self.setup_logger()
        try: self.logger.info(message)
        except: pass

    def setup_logger(self):
        log_file = os.path.join(QgsApplication.qgisSettingsDirPath(), "TaskManager_Log.txt")
        self.logger = logging.getLogger("TaskManagerLogger")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            h = RotatingFileHandler(log_file, maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
            h.setFormatter(logging.Formatter('[%(asctime)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S"))
            self.logger.addHandler(h)

    def addUser(self):
        name = self.ui.user_lineEdit.text().strip()
        if not name: return
        names = self.user_model.stringList()
        if name in names: return
        names.append(name)
        names.sort()
        self.user_model.setStringList(names)
        self.QSettings.setValue('Tesk_User', ",".join(names))
        self.ui.user_lineEdit.clear()

    def deleteUser(self):
        name = self.ui.user_lineEdit.text().strip()
        names = self.user_model.stringList()
        if name in names:
            names.remove(name)
            self.user_model.setStringList(names)
            self.QSettings.setValue('Tesk_User', ",".join(names))

    def move_to_working_objects(self):
        sel = self.ui.user_listView.selectedIndexes()
        if not sel: return
        user = sel[0].data(Qt.DisplayRole)
        layer, lid = self.get_current_layer_info()
        u_f, c_f = self.ui.userField.text().strip(), self.ui.completeField.text().strip()
        u_idx, c_idx = layer.fields().indexOf(u_f), layer.fields().indexOf(c_f)
        
        target_ids = []
        for f_dict in self.all_layers_cache.get(lid, []):
            attrs = f_dict['attributes']
            if str(attrs[u_idx]).strip() == user and (not attrs[c_idx] or str(attrs[c_idx]) in ["작업중", "NULL"]):
                target_ids.append(f_dict['id'])
        self._zoom_to_feature_ids(layer, target_ids)

    def complete_working_objects(self):
        sel = self.ui.user_listView.selectedIndexes()
        if not sel: return
        user = sel[0].data(Qt.DisplayRole)
        layer, lid = self.get_current_layer_info()
        u_f, c_f, e_f = self.ui.userField.text().strip(), self.ui.completeField.text().strip(), self.ui.endField.text().strip()
        u_idx, c_idx, e_idx = layer.fields().indexOf(u_f), layer.fields().indexOf(c_f), layer.fields().indexOf(e_f)

        ids = [d['id'] for d in self.all_layers_cache.get(lid, []) if str(d['attributes'][u_idx]).strip() == user and (not d['attributes'][c_idx] or str(d['attributes'][c_idx]) == "작업중")]
        if not ids: return

        val = self.get_dynamic_value(self.ui.completeField_type.currentText(), self.ui.completeField_lineEdit.text(), user) or "완료"
        dt = self.get_dynamic_value(self.ui.endField_type.currentText(), self.ui.endField_lineEdit.text(), user) or QDateTime.currentDateTime().toString("yyyy-MM-dd")

        if not layer.isEditable(): layer.startEditing()
        layer.beginEditCommand("완료처리")
        try:
            for fid in ids:
                if c_idx != -1: layer.changeAttributeValue(fid, c_idx, val)
                if e_idx != -1: layer.changeAttributeValue(fid, e_idx, dt)
            layer.endEditCommand()
            for d in self.all_layers_cache[lid]:
                if d['id'] in ids:
                    d['attributes'][c_idx], d['attributes'][e_idx] = val, dt
            self.on_user_clicked(sel[0])
        except: layer.destroyEditCommand()

    def get_dynamic_value(self, t, l, u):
        now = QDateTime.currentDateTime()
        if t == "작업자": return u
        if t == "지정값 사용": return l
        if t == "날짜 시간": return now.toString("yyyy-MM-dd HH:mm:ss")
        if t == "날짜": return now.toString("yyyy-MM-dd")
        if t == "주차": 
            wi = now.date().dayOfWeek() - 1
            sw = now.addDays(-wi)
            return f"{sw.date().month()}{math.ceil(sw.date().day()/7)}"
        return None

    def load_settings(self):
        for n in ["userField", "completeField", "startField", "endField", "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]:
            getattr(self.ui, n).setText(self.QSettings.value(n, ""))
        for n in ["logMaxLine", "userField_type", "completeField_type", "startField_type", "endField_type", "format_comboBox", "type_comboBox"]:
            getattr(self.ui, n).setCurrentIndex(int(self.QSettings.value(n, 0)))
        self.ui.mQgsFileWidget_export.setFilePath(self.QSettings.value("path_export", ""))

    def save_settings(self):
        for n in ["userField", "completeField", "startField", "endField", "userField_lineEdit", "completeField_lineEdit", "startField_lineEdit", "endField_lineEdit"]:
            self.QSettings.setValue(n, getattr(self.ui, n).text().strip())
        for n in ["logMaxLine", "userField_type", "completeField_type", "startField_type", "endField_type", "format_comboBox", "type_comboBox"]:
            self.QSettings.setValue(n, getattr(self.ui, n).currentIndex())
        self.QSettings.setValue("path_export", self.ui.mQgsFileWidget_export.filePath())

    def show_user_result_context_menu(self, pos):
        m = QMenu()
        a1 = QAction("객체 이동", self)
        a1.triggered.connect(lambda: self.result_on_map(self.ui.user_result))
        m.addAction(a1)
        m.addSeparator()
        a2 = QAction("셀 내용 복사", self)
        a2.triggered.connect(lambda: self._copy_table_selection_to_clipboard(self.ui.user_result))
        m.addAction(a2)
        a3 = QAction("전체 내용 복사", self)
        a3.triggered.connect(lambda: self._copy_table_all_clipboard(self.ui.user_result))
        m.addAction(a3)
        m.exec_(self.ui.user_result.viewport().mapToGlobal(pos))

    def show_select_result_context_menu(self, pos):
        m = QMenu()
        a1 = QAction("객체 이동", self)
        a1.triggered.connect(lambda: self.result_on_map(self.ui.select_result))
        m.addAction(a1)
        a2 = QAction("셀 내용 복사", self)
        a2.triggered.connect(lambda: self._copy_table_selection_to_clipboard(self.ui.select_result))
        m.addAction(a2)
        a3 = QAction("전체 내용 복사", self)
        a3.triggered.connect(lambda: self._copy_table_all_clipboard(self.ui.select_result))
        m.addAction(a3)
        m.exec_(self.ui.select_result.viewport().mapToGlobal(pos))

    def _copy_table_selection_to_clipboard(self, view):
        sel = view.selectedIndexes()
        if not sel: return
        rows = {}
        for i in sel:
            if i.row() not in rows: rows[i.row()] = {}
            rows[i.row()][i.column()] = i.data()
        txt = "\n".join(["\t".join([str(rows[r][c]) for c in sorted(rows[r].keys())]) for r in sorted(rows.keys())])
        QApplication.clipboard().setText(txt)
    
    def _copy_table_all_clipboard(self, result):
        """테이블의 전체 데이터(헤더 포함)를 클립보드에 복사합니다."""
        model = result.model()
        if not model:
            return

        lines = []
        
        # 1. 상단 헤더(컬럼 이름) 추출
        header = []
        for c in range(model.columnCount()):
            header.append(str(model.headerData(c, Qt.Horizontal, Qt.DisplayRole) or ""))
        lines.append("\t".join(header))

        # 2. 본문 데이터 추출
        for r in range(model.rowCount()):
            row_data = []
            for c in range(model.columnCount()):
                idx = model.index(r, c)
                row_data.append(str(idx.data(Qt.DisplayRole) or ""))
            lines.append("\t".join(row_data))

        QApplication.clipboard().setText("\n".join(lines))
        self.statusBar().showMessage('전체 데이터를 클립보드에 복사했습니다.', 5000)
    
    def result_on_map(self, result):
        id_list = [j for i in result.selectedIndexes() for j in (result.model().index(i.row(), 0).data(Qt.UserRole) or [])]
        if id_list:
            layer, _ = self.get_current_layer_info()
            self._zoom_to_feature_ids(layer, id_list)

    def layerSelection(self, index):
        l, lid = self.get_current_layer_info()
        self.ui.log_textEdit.setPlainText("")
        if getattr(self, 'current_connected_layer', None):
            try: self.current_connected_layer.selectionChanged.disconnect(self.on_selection_changed)
            except: pass
        self.current_connected_layer = l
        if l:
            l.selectionChanged.connect(self.on_selection_changed)
            self.ui.Field.setLayer(l)
            if lid not in self.all_layers_cache:
                self.statusBar().showMessage("레이어 캐싱 중...")
                QCoreApplication.processEvents()
                self.all_layers_cache[lid] = self._build_layer_cache_data(l)
                self.statusBar().showMessage("캐싱 완료", 3000)
            self.on_selection_changed()    

    def setLayers (self, layer):
        index = self.ui.layer.currentIndex()
        if index !=-1:
            layerId = self.ui.layer.itemData(index)

        self.ui.layer.blockSignals(True)
        self.ui.layer.clear()
        self.ui.layer.addItem("레이어를 선택하세요...", None)

        for i in layer:
            self.ui.layer.addItem(i[0], i[1])

        if index !=-1:
            index2 = self.ui.layer.findData(layerId)
            if index2 !=-1:
                self.ui.layer.setCurrentIndex(index2)
            else:
                self.ui.layer.setCurrentIndex(0)
        else:
            self.ui.layer.setCurrentIndex(0)

        self.ui.layer.blockSignals(False)