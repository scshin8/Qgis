from qgis.PyQt import uic, QtWidgets

from qgis.core import (Qgis,
                       QgsField,
                       QgsProject,
                       QgsFeature,
                       QgsWkbTypes,
                       QgsVectorLayer,
                       QgsMarkerSymbol,
                       QgsTextAnnotation,
                       QgsCoordinateTransform,
                       QgsCoordinateReferenceSystem)

from qgis.PyQt.QtCore import (QSizeF,
                          QPointF,
                          QSettings,
                          QVariant,
                          QTimer)

from qgis.gui import (QgsRubberBand,
                      QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from qgis.PyQt.QtGui import (QKeySequence, 
                         QTextDocument, 
                         QColor, 
                         QIcon)

from qgis.PyQt.QtWidgets import (QMessageBox,
                                QApplication, 
                                QPushButton, 
                                QComboBox,
                                QTableWidgetItem, 
                                QLineEdit)
import re
import os.path 
import requests
import datetime
import subprocess
import sys
import platform

VERSION = Qgis.QGIS_VERSION_INT

try:
    import polyline
except:
    # 운영 체제에 따른 처리
    if platform.system() == "Darwin":
        qgis_python_path = "/Applications/QGIS.app/Contents/MacOS/bin/python3"
        if qgis_python_path not in sys.executable:
            sys.path.append(qgis_python_path)
        subprocess.check_call([qgis_python_path, '-m', 'pip', 'install', 'polyline'])
    else:
        python_path = sys.executable  # QGIS에서 사용 중인 python 실행파일 경로
        subprocess.check_call(['python', '-m', 'pip', 'install', 'polyline', '--no-cache-dir'])
    import polyline

# try:
#     from googletrans import Translator
# except:
#     subprocess.check_call(['python','-m', 'pip', 'install', 'googletrans==4.0.0-rc1'])
#     QSettings().setValue('googletrans_'+str(VERSION), 1)
#     from googletrans import Translator

from . import Coordinate_Tool_data
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Function import Coordinate_function, Pathcapture
from .Coordinate_Tool_decryptKey import AESCipher
from . import Coordinate_Tool_data

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326') # wgs84
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181') 
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162') # bessel

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Path_Search.ui'))

class CoordinateToolPathSearch(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(CoordinateToolPathSearch, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.clipboard = QApplication.clipboard()
        # self.QSettings=QSettings()
        self.QSettings = QSettings(QSettings.NativeFormat, QSettings.UserScope, "masco", "coordinateTool")
        self.lineEdit=None
        
        self.Symbol_Routo=None
        self.Symbol_Google=None
        
        self.table_Routo=None
        self.table_Google=None
        
        self.MarkerSymbol_Routo=[]
        self.MarkerSymbol_Google=[]
        
        self.VertexMarker_Search=[]
        self.MarkerSymbol_Search=[]

        self.rb_Routo = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_Routo.setWidth(7)  # 라인 너비
        
        self.rb_Google = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_Google.setWidth(7)  # 라인 너비

        self.mColorButton_1.colorChanged.connect(self.colorchk1)
        self.mColorButton_3.colorChanged.connect(self.colorchk3)
        
        self.TurnCODE = Coordinate_Tool_data.TurnCODE
        self.GuideCode = Coordinate_Tool_data.GuideCode
        self.Search = CoordinateToolSearch(self,iface)
        self.Function = Coordinate_function(self,iface)
        self.AESCipher = AESCipher(self)
        self.apikeys = Coordinate_Tool_data.API_KEYS

        self.remove_tableWidget_All()
        self.remove_Marker_All()
        self.tabWidget.setCurrentIndex(0)

        self.tabWidget.currentChanged.connect(self.tabCha)
        
        self.path_search_pushButton.clicked.connect(self.path_search)#(self.valdel)
        
        self.tableWidget_Routo_Delete.clicked.connect(self.remove_Routo)#(self.valdel)
        self.tableWidget_Google_Delete.clicked.connect(self.remove_Google)#(self.valdel)

        self.captureCoordinate = Pathcapture(self.canvas)
        self.captureCoordinate.capturePoint.connect(self.capturedPoint)
        self.captureCoordinate.captureStopped.connect(self.stopCapture)
        self.captureCoordinate.captureStopped1.connect(self.stopCapture1)
        
        self.capture_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/capture.png"))
        self.capture_toolButton.clicked.connect(self.capture)

        self.delete_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.delete_toolButton.clicked.connect(self.delete)
        
        self.switch_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/switch.png"))
        self.switch_toolButton.clicked.connect(self.switch)
        
        self.rb_Routo_Color = QColor(self.QSettings.value('mColorButton_1', '#7e2cff'))
        self.rb_Routo_Color.setAlpha(int(self.QSettings.value('mColorButtonOpacity_1', 200)))
        self.mColorButton_1.setColor( self.rb_Routo_Color)
        self.rb_Routo_Color1 = QColor(self.QSettings.value('mColorButton_1', '#7e2cff'))
        self.rb_Routo_Color1.setAlpha(int(40))
        
        self.rb_Google_Color = QColor(self.QSettings.value('mColorButton_3', '#fab405'))
        self.rb_Google_Color.setAlpha(int(self.QSettings.value('mColorButtonOpacity_1', 200)))
        self.mColorButton_3.setColor( self.rb_Google_Color)
        self.rb_Google_Color1 = QColor(self.QSettings.value('mColorButton_3', '#fab405'))
        self.rb_Google_Color1.setAlpha(int(40))
        
    def colorchk1(self):
        self.QSettings.setValue('mColorButton_1',self.mColorButton_1.color().name())
        self.QSettings.setValue('mColorButtonOpacity_1', self.mColorButton_1.color().alpha())
        self.rb_Routo_Color = QColor(self.mColorButton_1.color().name())
        self.rb_Routo_Color.setAlpha(self.mColorButton_1.color().alpha())
        self.rb_Routo_Color1 = QColor(self.mColorButton_1.color().name())
        self.rb_Routo_Color1.setAlpha(40)
        if self.Symbol_Routo is not None:
            self.rb_Routo.setColor(self.rb_Routo_Color)
                
    def colorchk3(self):
        self.QSettings.setValue('mColorButton_3',self.mColorButton_3.color().name())
        self.QSettings.setValue('mColorButtonOpacity_3', self.mColorButton_3.color().alpha())
        self.rb_Google_Color = QColor(self.mColorButton_3.color().name())
        self.rb_Google_Color.setAlpha(self.mColorButton_3.color().alpha())
        self.rb_Google_Color1 = QColor(self.mColorButton_3.color().name())
        self.rb_Google_Color1.setAlpha(40)
        if self.Symbol_Google is not None:
            self.rb_Google.setColor(self.rb_Google_Color)
                

    def tabCha(self, *args):
        t = self.tabWidget.currentIndex()
        if t == 0:
            if self.Symbol_Routo is not None:
                self.rb_Routo.setColor(self.rb_Routo_Color) 
                for item in self.Symbol_Routo:
                    self.Marker_table_Symbol(self.tableWidget_Routo,
                                            self.Buttons_Routo,
                                            self.MarkerSymbol_Routo,
                                            self.RoutoRowCount,
                                            item[0],
                                            item[1],
                                            item[2],
                                            item[3],
                                            item[4],
                                            item[5],
                                            1)

            if self.Symbol_Google is not None:
                self.rb_Google.setColor(self.rb_Google_Color1)
                self.remove_Marker_Google()
                # for item in self.Symbol_Google:
                #     self.Marker_table_Symbol_Google(item[0],item[1],item[2],item[3],item[4],item[5])
                    
        elif t == 1:
            if self.Symbol_Routo is not None:
                self.rb_Routo.setColor(self.rb_Routo_Color1)  
                self.remove_Marker_Routo()
                # for item in self.Symbol_Routo:
                #     self.Marker_table_Symbol_Routo(item[0],item[1],item[2],item[3],item[4],item[5])

            if self.Symbol_Google is not None:
                self.rb_Google.setColor(self.rb_Google_Color)
                for item in self.Symbol_Google:
                    # self.Marker_table_Symbol_Google(item[0],item[1],item[2],item[3],item[4],item[5])
                    self.Marker_table_Symbol(self.tableWidget_Google,
                                            self.Buttons_Google,
                                            self.MarkerSymbol_Google,
                                            self.GoogleRowCount,
                                            item[0],
                                            item[1],
                                            item[2],
                                            item[3],
                                            item[4],
                                            item[5],
                                            1)

        self.canvas.refresh()

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.InsertParagraphSeparator):
            self.listsetup()

# 입력값 삭제
    def delete(self, *args):
        self.remove_tableWidget_All()
        self.remove_Marker_All()
        self.remove_rb_All()
        self.Symbol_Routo=None
        self.Symbol_Google=None
        self.Buttons_Routo=[]
        self.Buttons_Google=[]
        self.SPoint_lineEdit.clear()
        self.PPoint_lineEdit_1.clear()
        self.PPoint_lineEdit_2.clear()
        self.PPoint_lineEdit_3.clear()
        self.PPoint_lineEdit_4.clear()
        self.EPoint_lineEdit.clear()
        self.stopCapture1()
    
    def remove_Routo(self, *args):
        self.remove_Marker_Routo()
        self.remove_tableWidget_Routo()
        self.remove_rb_Routo()
        self.Symbol_Routo=None
        self.Buttons_Routo=[]
        
    def remove_Google(self, *args):
        self.remove_Marker_Google()
        self.remove_tableWidget_Google()
        self.remove_rb_Google()
        self.Symbol_Google=None
        self.Buttons_Google=[]
    
    def remove_rb_All(self):
        self.rb_Routo.reset()
        self.rb_Google.reset()
        
    def remove_rb_Routo(self):
        self.rb_Routo.reset()

    def remove_rb_Google(self):
        self.rb_Google.reset()

# 마커 리스트 삭제
    def remove_Symbol_Routo(self):
        self.Symbol_Routo=None

    def remove_Symbol_Google(self):
        self.Symbol_Google=None
        
# 화면의 마커 삭제 전체
    def remove_Marker_All(self):
        self.remove_Marker_Routo()
        self.remove_Marker_Google()

# 화면의 마커 삭제 
    def remove_Marker_Routo(self):
        if len(self.MarkerSymbol_Routo) > 0:  
            for mark in self.MarkerSymbol_Routo:
                self.canvas.scene().removeItem(mark)

    def remove_Marker_Google(self):
        if len(self.MarkerSymbol_Google) > 0:  
            for mark in self.MarkerSymbol_Google:
                self.canvas.scene().removeItem(mark)  

    # 경탐안내 테이블 초기화 
    def remove_tableWidget_All(self):
        self.remove_tableWidget_Routo()
        self.remove_tableWidget_Google()
    
    def remove_tableWidget_Routo(self):
        self.tableWidget_Routo.setColumnCount(4)
        table_column=["이동" , "안내" , "x" , "y"]
        self.tableWidget_Routo.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Routo.setRowCount(0)
        self.tableWidget_Routo.resizeColumnsToContents()
        self.TotalDistance_label_Routo.setText('')
        self.TotalTime_label_Routo.setText('')

    def remove_tableWidget_Google(self):
        self.tableWidget_Google.setColumnCount(4)
        table_column=["이동" , "안내" , "x" , "y"]
        self.tableWidget_Google.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Google.setRowCount(0)
        self.tableWidget_Google.resizeColumnsToContents()
        self.TotalDistance_label_Google.setText('')
        self.TotalTime_label_Google.setText('')  

# 시종점 반전
    def switch(self, *args):
        SPoint=self.SPoint_lineEdit.text()
        EPoint=self.EPoint_lineEdit.text()
        self.SPoint_lineEdit.clear()
        self.EPoint_lineEdit.clear()
        self.SPoint_lineEdit.setText(EPoint)
        self.EPoint_lineEdit.setText(SPoint)

# 좌표캡쳐 시작
    def capture(self, *args):
        if self.capture_toolButton.isChecked():
            self.savedMapTool = self.canvas.mapTool()
            self.canvas.setMapTool(self.captureCoordinate)
        else:
            if self.savedMapTool:
                self.canvas.setMapTool(self.savedMapTool)
                self.savedMapTool = None

# 아이콘 클릭으로 캡쳐 중단
    def stopCapture(self):
        self.CTool.Delete_Marker()
        self.capture_toolButton.setChecked(False)
        
# ESC 눌러서 캡쳐 중단
    def stopCapture1(self):
        self.CTool.Delete_Marker()
        self.capture_toolButton.setChecked(False)    
        self.iface.actionPan().trigger()

        
# 캡쳐좌표 입력
    def capturedPoint(self, point,chk):
        self.CTool.Draw_Marker(point,4)
        if self.isVisible():
            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
            point = Trans.transform(point.x(), point.y())
            
            # 위치정보
            wgs = self.Function.fscoordinate(point)
            map, company, team, ctp, sig = self.Function.mapidinfo(wgs)
            self.iface.statusBarIface().showMessage(f"{company} / {team} / {ctp} / {sig} / {map} / {wgs}", 4000)
            
            x=point[0]
            y=point[1]
            GRSpoint=(str(float(x))+','+str(float(y)))
            if chk== 'str':
                self.SPoint_lineEdit.setText(str(GRSpoint))
            elif chk== 'end':
                self.EPoint_lineEdit.setText(str(GRSpoint))
            elif chk== 'pass':
                for i in range(1,5):
                    if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()=='':
                        self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).setText(str(GRSpoint))
                        break
            else:
                pass
        self.CTool.Delete_Marker_Shot(1000)

# 경탐 시작 =======================================================================================================================
    def path_search(self, *args):
        self.stopCapture1()
        self.drawShape = 'lineString'
        # 루토
        if self.radioButton_Routo.isChecked() == True :
            self.path_search_Routo()
        # # 네이버
        # elif self.radioButton_Naver.isChecked() == True :
        #     self.path_search_Naver()
        # 구글
        elif self.radioButton_Google.isChecked() == True :
            self.path_search_Google()

# 루토 경탐=========================================================================================================================
    def path_search_Routo(self):
        self.tabWidget.setCurrentIndex(0)
        self.cmtName = "경탐_라인_Routo"
        self.Buttons_Routo=[]
        self.chk=0
        # self.tableWidget=self.tableWidget_Routo
        # MarkerSymbol=self.MarkerSymbol_Routo
        # self.rb=self.rb_Routo
        self.remove_Marker_Routo()
        self.remove_tableWidget_Routo()
        self.rb_Routo.reset()
        
        SPoint = self.SPoint_lineEdit.text()
        EPoint = self.EPoint_lineEdit.text()

        if SPoint!='':
            if EPoint!='':
                if self.SPoint_lineEdit.text() != self.EPoint_lineEdit.text():

                    if self.PPoint_lineEdit_1.text() == '':
                        # 단일

                        SPointX=SPoint.split(',')[0]
                        SPointY=SPoint.split(',')[1]
                        SPoint={"YPos" : float(SPointY),"XPos" : float(SPointX),"Name" : "출발지"}
                        EPointX=EPoint.split(',')[0]
                        EPointY=EPoint.split(',')[1]
                        EPoint={"YPos": float(EPointY),"XPos" : float(EPointX),"Name" : "도착지"}

                        if self.radioButton_0.isChecked() == True :
                            RouteOption = 0
                        elif self.radioButton_2.isChecked() == True :
                            RouteOption = 2
                        elif self.radioButton_3.isChecked() == True :
                            RouteOption = 3

                        params = {
                            'RPOption' : [{
                                "FeeOption": 0, #요금옵션  (0: 모든도로 , 1: 무료도로)
                                "RoadOption": 1, #우선도로 옵션 (0: 모든도로 , 1: 고속도로우선 ,2:고속도로회피 , 3: 자동차전용도로회피)
                                "RouteOption": RouteOption # 탐색옵션 ( 0: 최소시간, 1:(미정의) 2: 최단, 3:추천 )
                            }],
                            'CoordType' : 2 , # 좌표계 타입 (1:Bessel, 2:WGS84)
                            'CarType' : 0, # 단말 차종 (0:미선택, 1:승용차/소형합차, 2:중혐승합차, 3:대형승합차, 4:대형화물차, 5:특수화물차, 6:경차)
                            'StartPoint' : SPoint,
                            'GoalPoint' :EPoint, 
                            }  
                            # 'SPointList': SPointList
                            # }
                        url = 'https://api.routo.com/v1/directions/basic?key='
                    else:
                        # 경유지
                        SPointX=SPoint.split(',')[0]
                        SPointY=SPoint.split(',')[1]
                        SPoint={"x" : float(SPointX),"y" : float(SPointY)}

                        EPointX=EPoint.split(',')[0]
                        EPointY=EPoint.split(',')[1]
                        EPoint={"x" : float(EPointX),"y": float(EPointY)}

                        PPoints=[]
                        for i in range(1,5):
                            text = self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
                            if text != '':
                                PPointX=text.split(',')[0]
                                PPointY=text.split(',')[1]
                                PPointt={"x" : float(PPointX),"y": float(PPointY)}
                                PPoints.append(PPointt)
                        SPointList = {"nodes": PPoints}

                        if self.radioButton_0.isChecked() == True :
                            RouteOption=0
                        elif self.radioButton_2.isChecked() == True :
                            RouteOption=2
                        elif self.radioButton_3.isChecked() == True :
                            RouteOption=3

                        params = {
                            "SPoint" : SPoint,
                            "RPOption" : [{
                                "FeeOption": 0, # 요금옵션  (0: 모든도로 , 1: 무료도로)
                                "RoadOption": 0, # 우선도로 옵션 (0: 모든도로 , 1: 고속도로우선 ,2:고속도로회피 , 3: 자동차전용도로회피)
                                "RouteOption": RouteOption # 탐색옵션 ( 0: 최소시간, 1:(미정의) 2: 최단, 3:추천 )
                            }],
                            "EPoint" :EPoint,
                            "SPointList": SPointList
                            }
                        url = 'https://api.routo.com/v1/directions/multi-stop?key='

                    try:
                        apikey = self.apikeys[str('routo경탐')][0]
                        key = self.AESCipher.decrypt(apikey)

                        url = f'{url}{key}'
                        headers = {'Content-Type': 'application/json'}
                        response = requests.post(url , json=params , headers=headers , verify=False)
                        # response = requests.post(url=url, datas = json.dumps(params), headers=headers)

                        if response.status_code == 200:
                            data = response.json()
                            print(data)
                            # print(data)
                            # print(data[0]['FeeInfo']) # 톨게이트 정보
                            # print(data[0]['PosList']) # 링크좌표정보
                            # print(data[0]['RgData']) # 안내정보
                            # print(data[0]['RpOpt']) # 검색 옵션 정보
                            # print(data[0]['Summary']) # 총 거리, 비용, 시간
                            # print(data[0]['TraInfo']) # 교통정보
                            
                            # FeeOption=data[0]['RpOpt']['FeeOption'] # 0: 모든도로, 1: 무료도로
                            # RoadOption=data[0]['RpOpt']['RoadOption'] # 0: 모든도로, 1: 고속도로우선 2: 고속도로회피 3: 자동차전용도로회피
                            RouteOption=data[0]['RpOpt']['RouteOption'] # 0: 최소시간, 1:(미정의) 2: 최단, 3:추천
                            RouteOption = '최소시간' if RouteOption == 0  else '최단' if RouteOption == 2 else '추천' if RouteOption == 3 else 'None'
                 
                            TotalDistance=data[0]['Summary']['TotalDistance'] # 총 거리 (단위 m)
                            TotalDistance=round((TotalDistance/1000),1)
                            TotalFee=data[0]['Summary']['TotalFee'] # 주행 비용(단위 원)
                            TotalTime=data[0]['Summary']['TotalTime'] # 총 시간 (단위 초)
                            Time = divmod(TotalTime, 3600)
                            Time = str(str(int(Time[0])).zfill(2) + ':' + str(int(int(Time[1])//60)).zfill(2)) # 총 시간 (시:분)
                            
                            PosList=data[0]['PosList']
                            RgData=data[0]['RgData']
                            
                            self.TotalDistance_label_Routo.setText('거리 : '+ str(TotalDistance) + 'km')
                            self.TotalTime_label_Routo.setText('시간 : '+ str(Time))
                            
                            projCRS = self.canvas.mapSettings().destinationCrs()
                            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                            
                            # 경탐안내 테이블, 심볼 생성
                            self.Marker_Routo(PosList,RgData,Trans)
                            #print(self.DrawLine_checkBox.checkState())
                            if self.SaveLine_checkBox.isChecked() == True:
                                
                                layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
                                if layers:
                                    layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
                                else:
                                    layer = self.Addlayer() # 코멘트 레이어가 없다면 레이어 추가
                                    
                                # 경탐라인 생성
                                geometry = self.DrawLine(self.rb_Routo, self.rb_Routo_Color, PosList, Trans)

                                # 레이어편집모드
                                layer.startEditing()
                                
                                now = datetime.datetime.now() # 입력 날짜,시간 저장
                                now = now.strftime("%Y-%m-%d %H:%M:%S")

                                Points=[]
                                if self.PPoint_lineEdit_1.text() == '':
                                    for i in range(4):
                                        P={"x" : float(0),"y": float(0)}
                                        Points.append(P)
                                else:
                                    for i in range(4):
                                        if i <= len(PPoints)-1:
                                            Points.append(PPoints[i])
                                        else:
                                            P={"x" : float(0),"y": float(0)}
                                            Points.append(P)

                                pr = layer.dataProvider()
                                f = QgsFeature()
                                f.setAttributes([SPointX,SPointY,
                                                EPointX,EPointY,
                                                Points[0]['x'],Points[0]['y'],
                                                Points[1]['x'],Points[1]['y'],
                                                Points[2]['x'],Points[2]['y'],
                                                Points[3]['x'],Points[3]['y'],
                                                TotalDistance,
                                                TotalFee,
                                                Time,
                                                RouteOption,
                                                # FeeOption,
                                                # RoadOption,
                                                now])
                            
                                f.setGeometry(geometry)
                                pr.addFeature(f)
                                layer.commitChanges()
                                layer.updateExtents()
                                
                                # 레이어편집모드
                                layer.startEditing()
                                
                                layer.renderer().symbol().setColor(self.rb_Routo_Color)
                                if self.drawShape == 'lineString':
                                    layer.renderer().symbol().setWidth(2)
                                layer.triggerRepaint()
                            elif self.DrawLine_checkBox.isChecked() == True:
                                self.DrawLine(self.rb_Routo, self.rb_Routo_Color, PosList, Trans)
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "Routo", "경로탐색 실패 입력좌표 확인")
                            print("Routo Error Code : " , response.status_code)
                    except Exception as e:
                        print(" Routo Error : ", e)
                else:
                    self.iface.messageBar().pushMessage("", "출발지와 도착지가 동일합니다. 확인 후 다시 지정해 주세요", level=Qgis.Warning, duration=4)          
            else:
                self.iface.messageBar().pushMessage("", "도착지 좌표가 비였습니다.", level=Qgis.Warning, duration=4) 
        else:
            self.iface.messageBar().pushMessage("", "출발지 좌표가 비였습니다.", level=Qgis.Warning, duration=4)

# 루토 경탐 리스트 정리==================================================================================================================
    def Marker_Routo(self,PosList,RgData,Trans):
        self.Symbol_Routo=[]
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        if table_Box is True or Symbol_Box is True:
            if table_Box is True:
                table_column=["이동" , "안내" , "x" , "y"]
                self.tableWidget_Routo.setHorizontalHeaderLabels(table_column)
                self.RoutoRowCount=len(RgData)
            RgDistance=0
            if self.radioButton_Routo.isChecked() == True :
                i=0
                for Pos in PosList :
                    x=Pos['X']
                    y=Pos['Y']
                    index=Pos['index']
                    for Rg in RgData :
                        if index == Rg['EndIdx']:
                            projpoint = Trans.transform(float(x), float(y))
                            TurnName= Rg.get('TurnName')
                            TurnCODE= Rg['TurnCODE']
                            if TurnName is not None:
                                Name= Rg['TurnName'][0].get('Name')
                                
                                if TurnCODE==0:
                                    Turn=''
                                else:
                                    Turn=self.TurnCODE.get(str(TurnCODE))
                                    if Turn is not None:
                                        Turn=Turn[0]
                                    else:
                                        Turn = ''
                                        
                                if RgDistance > 999 :
                                    RgDistance = str(RgDistance/1000) + 'km 앞 '
                                else:
                                    RgDistance = str(RgDistance) + 'm 앞 '
                                
                                if i == 0:
                                    msg = '출발지'
                                elif i == len(RgData)-1:
                                    msg = RgDistance + "목적지"
                                elif TurnCODE > 30000:
                                    msg = RgDistance + Turn
                                else:
                                    msg = RgDistance + Name + '에서 ' + Turn
                            else:
                                Name=i+1
                                if TurnCODE==0:
                                    Turn=''
                                else:
                                    Turn=self.TurnCODE.get(str(TurnCODE))
                                    if Turn is not None:
                                        Turn=Turn[0]
                                    else:
                                        Turn = ''
                                if RgDistance > 999 :
                                    RgDistance = str(RgDistance/1000) + 'km 앞'
                                else:
                                    RgDistance = str(RgDistance) + 'm 앞'
                                if i == 0:
                                    msg = '출발지'
                                elif i == len(RgData)-1:
                                    msg = RgDistance + " 목적지"
                                else:
                                    msg = RgDistance + '에서 ' + Turn
                            
                            self.Symbol_Routo.append([i,Name,msg,x,y,projpoint])
                            # self.Marker_table_Symbol_Routo(i,Name,msg,x,y,projpoint)
                            self.Marker_table_Symbol(self.tableWidget_Routo, 
                                                    self.Buttons_Routo, 
                                                    self.MarkerSymbol_Routo,
                                                    self.RoutoRowCount,
                                                    i,
                                                    Name,
                                                    msg,
                                                    x,
                                                    y,
                                                    projpoint,
                                                    0)

                            RgDistance= Rg['RgDistance']
                            i+=1
                        elif index < Rg['EndIdx']:
                            break
                if table_Box is True:
                    self.tableWidget_Routo.setAlternatingRowColors(True)
                    for i in range(1,3):
                        self.tableWidget_Routo.resizeColumnToContents(i) 

# # 네이버 경탐 ===========================================================================================================
#     def path_search_Naver(self):
#         self.tabWidget.setCurrentIndex(1)
#         apikey1 = self.apikeys[str('naver_client_id')][0]
#         client_id = self.AESCipher.decrypt(apikey1)
#         apikey2 = self.apikeys[str('naver_client_secret')][0]
#         client_secret = self.AESCipher.decrypt(apikey2)
#         if client_secret is None:
#             return
#         if apikey1 != '' or apikey2 != '':
#             self.cmtName = "경탐_라인_Naver"
#             self.Buttons_Naver=[]
#             # self.DrawLineNaver=[]
#             self.chk=1
#             self.remove_Marker_Naver()
#             self.remove_tableWidget_Naver()
#             self.rb_Naver.reset()
#             # self.tableWidget=self.tableWidget_Naver
#             # MarkerSymbol=self.MarkerSymbol_Naver
#             # self.rb=self.rb_Naver
#             if self.SPoint_lineEdit.text() != '':
#                 SPoint = self.SPoint_lineEdit.text()
#                 SPointX=SPoint.split(',')[0]
#                 SPointY=SPoint.split(',')[1]

#                 if self.EPoint_lineEdit.text() != '':
#                     EPoint = self.EPoint_lineEdit.text()
#                     EPointX=EPoint.split(',')[0]
#                     EPointY=EPoint.split(',')[1]
                    
#                     PPoints=''
#                     if self.PPoint_lineEdit_1.text() != '':
#                         PPoint=self.PPoint_lineEdit_1.text()
#                         PPoints=PPoint
#                         for i in range(2,5):
#                             if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text() != '':
                                
#                                 PPoint='|' + self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
#                                 PPoints += PPoint
#                     else:
#                         waypoints=''
                                
#                     if self.radioButton_3.isChecked() == True :
#                         option = 'traoptimal'   # 실시간최적
#                         optiontxt = '실시간최적'   # 실시간최적
#                     elif self.radioButton_2.isChecked() == True :
#                         option = 'tracomfort'   # 실시간편한길
#                         optiontxt = '실시간편한길'   # 실시간편한길
#                     elif self.radioButton_0.isChecked() == True :
#                         option = 'trafast'      # 실시간빠른길
#                         optiontxt = '실시간빠른길'   # 실시간빠른길
            
#                     # Option Code
#                     # 탐색 옵션을 나타내는 코드입니다.(모든 경로는 교통정보를 반영하므로 출발지, 목적지, 옵션이 같더라도 같은 경로가 보장되지 않습니다.)
#                     # 스트링 코드        탐색 종류
#                     # trafast           실시간 빠른길
#                     # tracomfort        실시간 편한길
#                     # traoptimal        실시간 최적     ----기본값----
#                     # traavoidtoll      무료 우선
#                     # traavoidcaronly   자동차 전용도로 회피 우선
            
#                     cartype = '1'
#                     # Cartype Code
#                     # 톨게이트 요금 계산용 차종 정보를 나타내는 코드입니다.
#                     # 코드  설명
#                     # 1	    1종(소형차) 2축 차량: 윤폭 279.4mm 이하 승용차, 소형승합차, 소형화물차     ----기본값----
#                     # 2     2종(중형차) 2축 차량: 윤폭 279.4mm 초과, 윤거 1,800mm 이하 중형승합차, 중형화물차
#                     # 3     3종(대형차) 2축 차량: 윤폭 279.4mm 초과, 윤거 1,800mm 초과 대형승합차, 2축 대형화물차
#                     # 4     4종(대형화물차) 3축 대형화물차
#                     # 5     5종(특수화물차) 4축 이상 특수화물차
#                     # 6     1종(경형자동차) 배기량 1000cc 미만으로 길이 3.6m, 너비 1.6m, 높이 2.0m 이하
                    
#                     fueltype = 'gasoline'
#                     # Fueltype Code
#                     # 유류비 계산용 유종을 나타내는 코드입니다.
#                     # 스트링 코드        설명
#                     # gasoline          휘발유. 유류비 계산 시 사용     ----기본값----
#                     # highgradegasoline	고급 휘발유. 유류비 계산 시 사용
#                     # diesel	        경유. 유류비 계산 시 사용
#                     # lpg	            LPG. 유류비 계산 시 사용

#                     url = "https://naveropenapi.apigw.ntruss.com/map-direction/v1/driving?"
#                     url = url + f"start={SPoint}&"
#                     url = url + f"goal={EPoint}&"
#                     if self.PPoint_lineEdit_1.text() != '':
#                         url = url + f"waypoints={PPoints}&"
#                     url = url + f"option={option}"
#                     # url = url + f"cartype={cartype}"
#                     # url = url + f"fueltype={fueltype}"

#                     headers = {'X-NCP-APIGW-API-KEY-ID': client_id,
#                             'X-NCP-APIGW-API-KEY': client_secret}
#                     try:
#                         response = requests.get(url, headers=headers)
#                         if response.status_code == 200:
#                             data = response.json()
#                             code=data['code']
#                             msg=data['message']
#                             if code == 0:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Info, duration=4)  
#                                 # print(data) # 응답결과
#                                 # print(data['code']) # 응답결과'code'
#                                 # print(data['messge']) # 응답 결과 문자열
#                                 # print(data['currentDateTime']) # 탐색 시점 시간 정보
#                                 # print(data['route']) # 응답결과 'route'
#                                     # print(data['route']['summary']) # 요약 정보
#                                         # 출발지 좌표
#                                         # print(data['route'][option][idx]['summary']['start']['location'])
#                                         # 목적지 좌표
#                                         # print(data['route'][option][idx]['summary']['goal']['location'])
#                                         # print(data['route'][option][idx]['summary']['goal']['dir']) # 경로상에서 location 좌표를 바라보는 방향. 경유지와 목적지에 대해서만 존재 가능 0:전방, 1:왼쪽, 2:오른쪽
#                                         # print(data['route'][option][idx]['summary']['waypoints']['location']) # 경유지 경유하는 순서대로 array에 기록
#                                         # print(data['route'][option][idx]['summary']['distance']) # 전체 경로 거리(meters)
#                                         # print(data['route'][option][idx]['summary']['duration']) # 전체 경로 소요 시간(millisecond(1/1000초))
#                                         # print(data['route'][option][idx]['summary']['bbox']) # 전체 경로 경계 영역. left bottom point와 right top point 두 개의 point array로 제공
#                                         # print(data['route'][option][idx]['summary']['tollFare']) # 통행 요금(톨게이트)
#                                         # print(data['route'][option][idx]['summary']['taxiFare']) # 택시 요금(지자체별, 심야, 시경계, 복합, 콜비 감안)
#                                         # print(data['route'][option][idx]['summary']['fuelPrice']) # 해당 시점의 전국 평균 유류비와 연비를 감안한 유류비
                                
#                                     # print(data['route'][option][idx]['path']) # 경로를 구성하는 모든 좌표열 / 해당 좌표들에는 0번부터 시작되는 index가 있음 이 index는 경로 정보를 표현하기 위한 pointIndex라는 명칭으로 활용됨
                                    
#                                     # print(data['route'][option][idx]['section']) # 해당 경로를 구성하는 주요 도로에 관한 정보열(모든 경로를 포함하는 정보는 아님)
#                                         # print(data['route'][option][idx]['section'][idx]['pointIndex']) # 경로를 구성하는 좌표의 인덱스
#                                         # print(data['route'][option][idx]['section'][idx]['pointCount']) # 형상점 수
#                                         # print(data['route'][option][idx]['section'][idx]['pointCount']) # 거리(meters)
#                                         # print(data['route'][option][idx]['section'][idx]['name']) # 도로명
#                                         # print(data['route'][option][idx]['section'][idx]['congestion'])   # 구간 혼잡도 1:원활, 2:서행, 3:혼잡
#                                                                                                             # (km/h)	일반도로	국도        도시고속	고속도로
#                                                                                                             # 원활	    30 이상	    40 이상     60 이상	    70 이상
#                                                                                                             # 서행	    15~30	    20~40       0~60	    40~70
#                                                                                                             # 혼잡	    15 미만	    20 미만     30 미만	    40 미만
#                                         # print(data['route'][option]['section'][idx]['speed']) # 평균 속도(km/h)
                                
#                                     # print(data['route'][option]['guide']) # 안내 정보열
#                                         # print(data['route'][option][idx]['guide'][idx]['pointIndex']) # 경로를 구성하는 좌표의 인덱스
#                                         # print(data['route'][option][idx]['guide'][idx]['type']) # 안내 종류
#                                         # print(data['route'][option][idx]['guide'][idx]['instructions']) # 	안내 문구
#                                         # print(data['route'][option][idx]['guide'][idx]['distance']) # 	이전 guide unit의 경로 구성 좌표 인덱스로부터 해당 guide unit의 경로 구성 좌표 인덱스까지의 거리(meters)
#                                         # print(data['route'][option][idx]['guide'][idx]['duration']) # 	이전 guide unit의 경로 구성 좌표 인덱스로부터 해당 guide unit의 경로 구성 좌표 인덱스까지의 소요 시간(millisecond(1/1000초))
                                
#                                 # 탐색 옵션
#                                 RouteOption=optiontxt   # trafast	실시간 빠른길
#                                                         # tracomfort	실시간 편한길
#                                                         # traoptimal	실시간 최적
#                                                         # traavoidtoll	무료 우선
#                                                         # traavoidcaronly	자동차 전용도로 회피 우선
                                
#                                 TotalDistance=data['route'][option][0]['summary']['distance'] # 전체 경로 거리(meters)
#                                 TotalDistance=round((TotalDistance/1000),1)
#                                 TotalFee=data['route'][option][0]['summary']['tollFare'] # 통행 요금(톨게이트)
#                                 TotalTime=data['route'][option][0]['summary']['duration'] # 전체 경로 소요 시간(millisecond(1/1000초))
#                                 Time = int(TotalTime)/1000 # millisecond to second
#                                 Time = divmod(Time, 3600) # 시간으로 변환
#                                 Time = str(str(int(Time[0])).zfill(2) + ':' + str(int(int(Time[1])//60)).zfill(2)) # 총 시간 (시:분)
#                                 PosList=data['route'][option][0]['path'] # 경로를 구성하는 모든 좌표열
#                                 RgData=data['route'][option][0]['guide'] # 안내 정보열
#                                 RgData.insert(0,{'pointIndex': 0, 'type': 0, 'instructions': "출발지", 'distance': 0, 'duration': 0}) # 출발지 정보 추가
                                
#                                 self.TotalDistance_label_Naver.setText('거리 : '+ str(TotalDistance) + 'km')
#                                 self.TotalTime_label_Naver.setText('시간 : '+ str(Time))
                                
#                                 projCRS = self.canvas.mapSettings().destinationCrs()
#                                 Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                                
#                                 # 경탐안내 테이블, 심볼 생성
#                                 # self.DrawLineNaver=[PosList,Trans]
#                                 self.Marker_Naver(PosList,RgData,Trans)
                                
#                                 if self.SaveLine_checkBox.isChecked() == True:
#                                     layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
#                                     if layers:
#                                         layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
#                                     else:
#                                         layer = self.Addlayer() # 코멘트 레이어가 없다면 레이어 추가
                                        
#                                     # 경탐라인 생성
#                                     # geometry = self.shp_DrawLine_Naver(PosList,Trans)
#                                     geometry = self.DrawLine(self.rb_Naver, self.rb_Naver_Color, PosList, Trans)
#                                     # 레이어편집모드
#                                     layer.startEditing()
                                    
#                                     now = datetime.datetime.now() # 입력 날짜,시간 저장
#                                     now = now.strftime("%Y-%m-%d %H:%M:%S") 

#                                     Points=[]

#                                     if PPoints != '':
#                                         sPPoints=PPoints.split('|')
#                                         for i in range(4):
#                                             if i <= len(sPPoints)-1:
#                                                 Points.append([float(sPPoints[i].split(',')[0]),float(sPPoints[i].split(',')[1])])
#                                             else:
#                                                 P=[int(0),int(0)]
#                                                 Points.append(P)
#                                     else:
#                                         for i in range(4):
#                                             P=[int(0),int(0)]
#                                             Points.append(P)    
                                        
#                                     pr = layer.dataProvider()
#                                     f = QgsFeature()
#                                     f.setAttributes([SPointX,SPointY,
#                                                     EPointX,EPointY,
#                                                     Points[0][0],Points[0][1],
#                                                     Points[1][0],Points[1][1],
#                                                     Points[2][0],Points[2][1],
#                                                     Points[3][0],Points[3][1],
#                                                     TotalDistance,
#                                                     TotalFee,
#                                                     Time,
#                                                     RouteOption,
#                                                     # FeeOption,
#                                                     # RoadOption,
#                                                     now])
                                
#                                     f.setGeometry(geometry)
#                                     pr.addFeature(f)
#                                     layer.commitChanges()
#                                     layer.updateExtents()
                                    
#                                     # 레이어편집모드
#                                     layer.startEditing()
                                    
#                                     layer.renderer().symbol().setColor(self.rb_Naver_Color )
#                                     if self.drawShape == 'lineString':
#                                         layer.renderer().symbol().setWidth(2)
#                                     layer.triggerRepaint()
    
#                                 elif self.DrawLine_checkBox.isChecked() == True:
#                                     # self.DrawLine_Naver(PosList,Trans)
#                                     self.DrawLine(self.rb_Naver, self.rb_Naver_Color, PosList, Trans)
#                             elif code == 1:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4) 
#                             elif code == 2:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
#                             elif code == 4:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
#                             elif code == 3:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)     
#                             elif code == 5:
#                                 self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
#                         else:
#                             QMessageBox.critical(self.iface.mainWindow(), "Naver", "경로탐색 실패 API KEY, 입력좌표 확인")
#                     except:
#                         QMessageBox.critical(self.iface.mainWindow(), "Naver", "경로탐색 실패 API KEY, 입력좌표 확인")
#                 else:
#                     self.iface.messageBar().pushMessage("", "도착지 좌표가 비였습니다.", level=Qgis.Warning, duration=4) 
#             else:
#                 self.iface.messageBar().pushMessage("", "출발지 좌표가 비였습니다.", level=Qgis.Warning, duration=4)
#         else:
#             QMessageBox.critical(self.iface.mainWindow(), "Naver", "경로탐색 실패 API KEY Null")

# # 네이버 경탐 리스트 정리
#     def Marker_Naver(self,PosList,RgData,Trans):
#         self.Symbol_Naver=[]
#         Symbol_Box=self.Symbol_checkBox.isChecked()
#         table_Box=self.tableWidget_checkBox.isChecked()
#         if table_Box is True or Symbol_Box is True:
#             if table_Box is True:
#                 table_column=["이동" , "안내" , "x" , "y"]
#                 self.tableWidget_Naver.setHorizontalHeaderLabels(table_column)
#                 self.NaverRowCount=len(RgData)
#             RgDistance=0
#             i=0
#             ir=1
#             x=PosList[0][0]
#             y=PosList[0][1]

#             for idx , Pos in enumerate(PosList) :
#                 x=Pos[0]
#                 y=Pos[1]
#                 for Rg in RgData :
#                     if idx == Rg['pointIndex']:
#                         projpoint = Trans.transform(float(x), float(y))
#                         TurnCODE= Rg['type']
#                         Turninfo= Rg['instructions']
#                         RgDistance= Rg['distance']
#                         Name=i+1
#                         # if TurnCODE==0:
#                         #     Turn=''
#                         # else:
#                         #     Turn=self.GuideCode.get(str(TurnCODE))
#                         #     if Turn is not None:
#                         #         Turn=Turn[0]
#                         #     else:
#                         #         Turn = ''
#                         if RgDistance > 999 :
#                             RgDistance = str(RgDistance/1000) + 'km 앞'
#                         else:
#                             RgDistance = str(RgDistance) + 'm 앞'
#                         if i == len(RgData)-1:
#                             Name = '목적지'
#                         msg = RgDistance + '에서 ' + Turninfo
#                         if idx == 0:
#                             Name = '출발지'
#                             msg='출발지'
#                         if Turninfo == '경유지':
#                             Name=f'제{ir}경유지'
#                             ir += 1
#                         self.Symbol_Naver.append([i,Name,msg,x,y,projpoint])
#                         # self.Marker_table_Symbol_Naver(i,Name,msg,x,y,projpoint)
#                         self.Marker_table_Symbol(self.tableWidget_Naver, 
#                                                 self.Buttons_Naver, 
#                                                 self.MarkerSymbol_Naver,
#                                                 self.NaverRowCount,
#                                                 i,
#                                                 Name,
#                                                 msg,
#                                                 x,
#                                                 y,
#                                                 projpoint,
#                                                 0)
#                         i+=1
#                     elif idx < Rg['pointIndex']:
#                         break
#             if table_Box is True:
#                 self.tableWidget_Naver.setAlternatingRowColors(True)
#                 for i in range(1,3):
#                     self.tableWidget_Naver.resizeColumnToContents(i) 

# 구글 경탐 ===========================================================================================================
    def path_search_Google(self):
        self.tabWidget.setCurrentIndex(2)
        apikey = self.apikeys[str('google_APIkey')][0]
        google_apiKey = self.AESCipher.decrypt(apikey)

        if google_apiKey is None:
            return
        
        if apikey != '':
            self.cmtName = "경탐_라인_Google"
            self.Buttons_Google=[]
            self.chk=2
            self.remove_Marker_Google()
            self.remove_tableWidget_Google()
            self.rb_Google.reset()
            
            if self.SPoint_lineEdit.text() != '':
                SPoint = self.SPoint_lineEdit.text()
                SPointX=SPoint.split(',')[0]
                SPointY=SPoint.split(',')[1]
                SPoints=f'{SPointY},{SPointX}'

                if self.EPoint_lineEdit.text() != '':
                    EPoint = self.EPoint_lineEdit.text()
                    EPointX=EPoint.split(',')[0]
                    EPointY=EPoint.split(',')[1]
                    EPoints=f'{EPointY},{EPointX}'
                    
                    PPoints=''
                    if self.PPoint_lineEdit_1.text() != '':
                        PPoint=self.PPoint_lineEdit_1.text()
                        PPointX=PPoint.split(',')[0]
                        PPointY=PPoint.split(',')[1]
                        PPoints=f'{PPointY},{PPointX}'
                        for i in range(2,5):
                            if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text() != '':
                                PPoint=self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
                                PPointX=PPoint.split(',')[0]
                                PPointY=PPoint.split(',')[1]
                                PPoint=f'{PPointY},{PPointX}'
                                PPoints=PPoints + '|' +PPoint
                    else:
                        waypoints=''
                    # if self.radioButton_3.isChecked() == True :
                    #     option = 'traoptimal'   # 실시간최적
                    #     optiontxt = '실시간최적'   # 실시간최적
                    # elif self.radioButton_2.isChecked() == True :
                    #     option = 'tracomfort'   # 실시간편한길
                    #     optiontxt = '실시간편한길'   # 실시간편한길
                    # elif self.radioButton_0.isChecked() == True :
                    #     option = 'trafast'      # 실시간빠른길
                    #     optiontxt = '실시간빠른길'   # 실시간빠른길
                
                    payload={}
                    headers = {}
            url = "https://maps.googleapis.com/maps/api/directions/json?"
            url = url + f"origin={SPoints}&"
            url = url + f"destination={EPoints}&"
            if self.PPoint_lineEdit_1.text() != '':
                url = url + f"waypoints={PPoints}"
            url = url + f"&key={google_apiKey}"
            try:
                response = requests.request("GET", url, headers=headers, data=payload)
                data=response.json()
                point=[]
                PosList=[]
                RgData=[]
                TotalDistance=0
                TotalTime=0
                routes_legs=data['routes'][0]['legs']
                for id , legs in enumerate(routes_legs):
                    routes_steps=legs['steps']
                    TotalDistance=TotalDistance+legs['distance']['value']
                    TotalTime=TotalTime+legs['duration']['value']
                    for id , p in enumerate(routes_steps):
                        def remove_html(Rg) :
                            Rg = re.sub('(<([^>]+)>)', '', Rg)
                            # translator = Translator()
                            # result = translator.translate(str(Rg)) # , src="en", dest="ko")
                            # Rg=result[0].text
                            return Rg
                        
                        Rg = p.get('html_instructions')
                        Rg = remove_html(Rg)
                        RgData.append(Rg)
                        # Rg = p.get('maneuver')
                        x = p['start_location']['lng']
                        y = p['start_location']['lat']
                        xy=[x,y]
                        PosList.append(xy)
                        point.append(xy)
                        # example polyline string
                        polylinepoints=p['polyline']['points']
                        # decode polyline
                        points = polyline.decode(polylinepoints)
                        # print coordinates
                        for y, x in points:
                            xy=[x,y]
                            point.append(xy)
                Rg = data['routes'][0].get('summary')      
                RgData.append(Rg)
                x=p['end_location']['lng']
                y=p['end_location']['lat']
                xy=[x,y]
                PosList.append(xy)
                point.append(xy)
                    
                Distance=round((TotalDistance/1000),1)
                Time = divmod(TotalTime, 3600) # 시간으로 변환
                Time = str(str(int(Time[0])).zfill(2) + ':' + str(int(int(Time[1])//60)).zfill(2)) # 총 시간 (시:분)
                
                self.TotalDistance_label_Google.setText('거리 : '+ str(Distance) + 'km')
                self.TotalTime_label_Google.setText('시간 : '+ str(Time))
        
                projCRS = self.canvas.mapSettings().destinationCrs()
                Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                
                self.Marker_Google(PosList,RgData,Trans)
                
                if self.SaveLine_checkBox.isChecked() == True:
                    layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
                    if layers:
                        layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
                    else:
                        layer = self.Addlayer() # 코멘트 레이어가 없다면 레이어 추가
                        
                    # 경탐라인 생성
                    # geometry = self.shp_DrawLine_Google(point,Trans)
                    geometry = self.DrawLine(self.rb_Google, self.rb_Google_Color, point, Trans)
                    # 레이어편집모드
                    layer.startEditing()
                    
                    now = datetime.datetime.now() # 입력 날짜,시간 저장
                    now = now.strftime("%Y-%m-%d %H:%M:%S") 

                    Points=[]

                    if PPoints != '':
                        sPPoints=PPoints.split('|')
                        for i in range(4):
                            if i <= len(sPPoints)-1:
                                Points.append([float(sPPoints[i].split(',')[0]),float(sPPoints[i].split(',')[1])])
                            else:
                                P=[int(0),int(0)]
                                Points.append(P)
                    else:
                        for i in range(4):
                            P=[int(0),int(0)]
                            Points.append(P)    
                            
                    pr = layer.dataProvider()
                    f = QgsFeature()
                    f.setAttributes([SPointX,SPointY,
                                    EPointX,EPointY,
                                    Points[0][0],Points[0][1],
                                    Points[1][0],Points[1][1],
                                    Points[2][0],Points[2][1],
                                    Points[3][0],Points[3][1],
                                    TotalDistance,
                                    0,
                                    Time,
                                    'NONE',
                                    # FeeOption,
                                    # RoadOption,
                                    now])
                
                    f.setGeometry(geometry)
                    pr.addFeature(f)
                    layer.commitChanges()
                    layer.updateExtents()
                    layer.startEditing() # 레이어편집모드
                    layer.renderer().symbol().setColor(self.rb_Google_Color)
                    if self.drawShape == 'lineString':
                        layer.renderer().symbol().setWidth(2)
                    layer.triggerRepaint()
                                    
                elif self.DrawLine_checkBox.isChecked() == True:
                    # self.DrawLine_Google(point,Trans)
                    self.DrawLine(self.rb_Google, self.rb_Google_Color, point, Trans)
            except:
                QMessageBox.critical(self.iface.mainWindow(), "Google", "경로탐색 실패 API KEY,입력 좌표 확인") 
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Google", "경로탐색 실패 API KEY Null")

# 구글 경탐 리스트 정리===============================================================================================================
    def Marker_Google(self,PosList,RgData,Trans):
        self.Symbol_Google=[]
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        if table_Box is True or Symbol_Box is True:
            if table_Box is True:
                table_column=["이동" , "안내" , "x" , "y"]
                self.tableWidget_Google.setHorizontalHeaderLabels(table_column)
                self.GoogleRowCount=len(PosList)
            for i, Pos in enumerate(PosList) :
                x = Pos[0]
                y = Pos[1]
                projpoint = Trans.transform(float(x), float(y))
                if i == 0:
                    msg = '출발지_' + RgData[i]
                    Name = '1.출발지'
                elif i == len(PosList)-1:
                    msg = '목적지_' + RgData[i]
                    Name = str(len(PosList)) + '.목적지'
                else:
                    msg = RgData[i]
                    Name = i + 1
                self.Symbol_Google.append([i,Name,msg,x,y,projpoint])
                # self.Marker_table_Symbol_Google(idx,Name,msg,x,y,projpoint)
                self.Marker_table_Symbol(self.tableWidget_Google, 
                                        self.Buttons_Google, 
                                        self.MarkerSymbol_Google,
                                        self.GoogleRowCount,
                                        i,
                                        Name,
                                        msg,
                                        x,
                                        y,
                                        projpoint,
                                        0)

            if table_Box is True:
                self.tableWidget_Google.setAlternatingRowColors(True)
                for i in range(1,3):
                    self.tableWidget_Google.resizeColumnToContents(i)  

# 코멘트 레이어 생성 ===========================================================================================================
    def Addlayer(self):
        layer = QgsVectorLayer(self.drawShape, self.cmtName, "memory")
        pr = layer.dataProvider() 
        pr.addAttributes([  
                        QgsField("시점_X", QVariant.Double),
                        QgsField("시점_Y",  QVariant.Double),
                        QgsField("종점_X", QVariant.Double),
                        QgsField("종점_Y",  QVariant.Double),
                        QgsField("경유1_X", QVariant.Double),
                        QgsField("경유1_Y",  QVariant.Double),
                        QgsField("경유2_X", QVariant.Double),
                        QgsField("경유2_Y",  QVariant.Double),
                        QgsField("경유3_X", QVariant.Double),
                        QgsField("경유3_Y",  QVariant.Double),
                        QgsField("경유4_X", QVariant.Double),
                        QgsField("경유4_Y",  QVariant.Double),
                        QgsField("거리(m)", QVariant.Double),
                        QgsField("요금(원)", QVariant.Double),
                        QgsField("시간", QVariant.String),
                        QgsField("탐색옵션", QVariant.String),  # 0: 최소시간, 1:(미정의) 2: 최단, 3:추천
                        # QgsField("요금옵션", QVariant.Double),  # 0: 모든도로, 1: 무료도로
                        # QgsField("우선도로", QVariant.Double),  # 0: 모든도로, 1: 고속도로우선 2: 고속도로회피 3: 자동차전용도로회피
                        QgsField("Update_Date", QVariant.DateTime)])
        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)
        map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
        # CRSid=map_crs.authid()
        layer.setCrs(map_crs)
        return layer

# 경탐라인생성 ===============================================================================================
    def DrawLine(self, RubberBand, Color, PosList, Trans):
        RubberBand.setColor(Color) 
        RubberBand.reset(QgsWkbTypes.LineGeometry)
        for pos in PosList:
            print(pos)
            try: # 네이버, 구글 XY 추출
                x = pos[0]
                y = pos[1]
            except: # 루토 XY 추출
                x=pos['X']
                y=pos['Y']

            point = Trans.transform(float(x), float(y))
            print(point)
            RubberBand.addPoint(point)
        self.canvas.refresh()
        geometry = RubberBand.asGeometry() # 입력한 포인트, 폴리라인, 폴리곤의 도형값 저장

        if self.DrawLine_checkBox.isChecked() == False:
            RubberBand.reset()
        if self.SaveLine_checkBox.isChecked() == True:
            return geometry

# 경탐 결과 심볼 만들기===============================================================================================
    def Marker_table_Symbol(self, table, Buttons, Symbols, RowCount, i, Name, msg, x, y, projpoint, chk):
        Symbol_Box = self.Symbol_checkBox.isChecked() # 심볼 표출 확인
        table_Box = self.tableWidget_checkBox.isChecked()  # 테이블 표출 확인
        table.setRowCount(RowCount)
        if table_Box is True and chk == 0:
            btn=QPushButton("이동")
            btn.resize(16, 16)
            Buttons.append(btn)
            Buttons[i].clicked.connect(lambda : self.btn_fun(table))
            table.setCellWidget(i,0,Buttons[i])
            table.setItem(i, 1, QTableWidgetItem(msg))
            table.setItem(i, 2, QTableWidgetItem(str(x)))
            table.setItem(i, 3, QTableWidgetItem(str(y)))
        
        if Symbol_Box is True:
            sym = QgsMarkerSymbol()
            sym.setSize(0)
            txt = QTextDocument(str(Name))
            lbl = QgsTextAnnotation(self.canvas)
            # if self.chk==0:
            lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,255))
            lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,255))
            lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.2)
            # else:
            #     lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,50))
            #     lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,50)) 
            #     txt.setHtml('<p style="color : #b4b4b4">'+str(Name)+'</p>')
            #     lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.1)
            lbl.setDocument(txt)
            lbl.setFrameSize(QSizeF(50.0, 25.0))
            lbl.setMapPosition(projpoint)
            lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
            lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
            lbl.setMarkerSymbol(sym)
            Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
            Symbols.append(Symbol)

    def btn_fun(self, table):
        button = table.sender()
        item = table.indexAt(button.pos())   
        idx = int(item.row())
        lon = table.item( idx,2 ).text()
        lat = table.item( idx,3 ).text()
        self.Function.moveto(epsg4326, lon, lat, 0)