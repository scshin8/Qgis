from qgis.PyQt import uic, QtWidgets

from qgis.core import (Qgis,
                       QgsField,
                       QgsProject,
                       QgsFeature,
                       QgsWkbTypes,
                       QgsVectorLayer,
                       QgsMarkerSymbol,
                       QgsTextAnnotation,
                       QgsCoordinateTransform,
                       QgsCoordinateReferenceSystem)

from PyQt5.QtCore import (QSizeF,
                          QPointF,
                          QSettings,
                          QVariant,
                          QTimer)

from qgis.gui import (QgsRubberBand,
                      QgsMapCanvasAnnotationItem,
                      QgsVertexMarker)

from PyQt5.QtGui import (QKeySequence, 
                         QTextDocument, 
                         QColor, 
                         QIcon)

from qgis.PyQt.QtWidgets import QMessageBox
from PyQt5.QtWidgets import (QApplication, 
                             QPushButton, 
                             QComboBox,
                             QTableWidgetItem, 
                             QLineEdit)

import os.path 
import requests
import datetime

from . import Coordinate_Tool_data
from .Coordinate_Tool_Search import CoordinateToolSearch
from .Coordinate_Tool_Funtion import Coordinate_funtion, Pathcapture

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326') # wgs84
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181') 
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162') # bessel

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_Path_Search.ui'))

class CoordinateToolPathSearch(QtWidgets.QWidget, FORM_CLASS):
    def __init__(self, CTool, iface, parent=None):
        super(CoordinateToolPathSearch, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.savedMapTool = None
        self.CTool=CTool
        self.clipboard = QApplication.clipboard()
        self.locale=QSettings()
        self.Routo=0
        self.Naver=0
        
        self.lineEdit=None
        
        self.Symbol_Routo=None
        self.Symbol_Naver=None
        
        self.table_Routo=None
        self.table_Naver=None
        
        self.MarkerSymbol_Routo=[]
        self.MarkerSymbol_Naver=[]
        
        self.VertexMarker_Search=[]
        self.MarkerSymbol_Search=[]

        self.rb_Routo = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_Routo.setWidth(7)  # 라인 너비
        
        self.rb_Naver = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_Naver.setWidth(7)  # 라인 너비

        self.rb_Google = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb_Google.setWidth(7)  # 라인 너비

        self.TurnCODE = Coordinate_Tool_data.TurnCODE
        self.GuideCode = Coordinate_Tool_data.GuideCode
        self.Search = CoordinateToolSearch(self,iface)
        self.Funtion = Coordinate_funtion(self,iface)
        
        self.remove_tableWidget_All()
        self.remove_Marker_All()
        self.tabWidget.setCurrentIndex(0)

        self.tabWidget.currentChanged.connect(self.tabCha)
        
        # t=self.dlg.tabWidget_2.currentIndex()+1
        
        self.path_search_pushButton.clicked.connect(self.path_search)#(self.valdel)
        
        self.tableWidget_Routo_Delete.clicked.connect(self.remove_Routo)#(self.valdel)
        self.tableWidget_Naver_Delete.clicked.connect(self.remove_Naver)#(self.valdel)
        
        self.Search_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/kakaosearch.png"))
        self.Search_toolButton.clicked.connect(self.listsetup)
        self.SearchDel_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.SearchDel_toolButton.clicked.connect(self.remove_Search)#(self.valdel)
        
        idx = int(self.locale.value('locale/coordinate_tool/Search_ComboBox', 0))
        self.Search_ComboBox.setCurrentIndex(idx)
        self.Search_ComboBox.currentIndexChanged.connect(self.SearchAPIChange)
        
        self.captureCoordinate = Pathcapture(self.canvas)
        self.captureCoordinate.capturePoint.connect(self.capturedPoint)
        self.captureCoordinate.captureStopped.connect(self.stopCapture)
        self.captureCoordinate.captureStopped1.connect(self.stopCapture1)
        
        self.capture_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/capture1.png"))
        self.capture_toolButton.clicked.connect(self.capture)

        self.delete_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/delete.png"))
        self.delete_toolButton.clicked.connect(self.delete)
        
        self.switch_toolButton.setIcon(QIcon(os.path.dirname(__file__) + "/icons/switch.png"))
        self.switch_toolButton.clicked.connect(self.switch)
        
        self.radioButton_Naver.toggled.connect(self.Naverswitch)

    def SearchAPIChange(self):
        idx = int(self.Search_ComboBox.currentIndex())
        self.locale.setValue('locale/coordinate_tool/Search_ComboBox', idx)

    def tabCha(self):
        t = self.tabWidget.currentIndex()
        if t == 0:
            self.chk=0

            if self.Symbol_Naver is not None:
                
                self.rb_Naver.setColor(QColor(4, 207, 92, 40))
                
                for item in self.Symbol_Naver:
                    self.Marker_table_Symbol_Naver(item[0],item[1],item[2],item[3],item[4],item[5])

            if self.Symbol_Routo is not None:
                self.rb_Routo.setColor(QColor(126, 44, 255, 200)) 
                
                for item in self.Symbol_Routo:
                    self.Marker_table_Symbol_Routo(item[0],item[1],item[2],item[3],item[4],item[5])
                
        elif t == 1:
            self.chk=1

            if self.Symbol_Routo is not None:
                
                self.rb_Routo.setColor(QColor(126, 44, 255, 40))  
                
                for item in self.Symbol_Routo:
                    self.Marker_table_Symbol_Routo(item[0],item[1],item[2],item[3],item[4],item[5])
                  
            if self.Symbol_Naver is not None:
                
                self.rb_Naver.setColor(QColor(4, 207, 92, 200)) # 네이버 라인 색깔
                
                for item in self.Symbol_Naver:
                    self.Marker_table_Symbol_Naver(item[0],item[1],item[2],item[3],item[4],item[5])

        self.canvas.refresh()
            
    def Naverswitch(self):
        if self.radioButton_Naver.isChecked() ==True :
            # self.tabWidget.setCurrentIndex(1)
            self.radioButton_0.setText('빠른길')
            self.radioButton_2.setText('편한길')
            self.radioButton_3.setText('최적')
        else:
            # self.tabWidget.setCurrentIndex(0)
            self.radioButton_0.setText('최소시간')
            self.radioButton_2.setText('최단')
            self.radioButton_3.setText('추천')
            
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.InsertParagraphSeparator):
            self.listsetup()

# 입력값 삭제
    def delete(self):
        self.remove_tableWidget_All()
        self.remove_Marker_All()
        self.remove_rb_All()
        self.Symbol_Routo=None
        self.Symbol_Naver=None
        self.Buttons_Naver=[]
        self.Buttons_Routo=[]
        
        self.SPoint_lineEdit.clear()
        self.PPoint_lineEdit_1.clear()
        self.PPoint_lineEdit_2.clear()
        self.PPoint_lineEdit_3.clear()
        self.PPoint_lineEdit_4.clear()
        self.EPoint_lineEdit.clear()
        self.Naver=0
        self.Routo=0
        self.stopCapture1()
    
    def remove_Routo(self):
        self.remove_Marker_Routo()
        self.remove_tableWidget_Routo()
        self.remove_rb_Routo()
        self.Symbol_Routo=None
        self.Buttons_Routo=[]
        self.Routo=0

    def remove_Naver(self):
        self.remove_Marker_Naver()
        self.remove_tableWidget_Naver()
        self.remove_rb_Naver()
        self.Symbol_Naver=None
        self.Buttons_Naver=[]
        self.Naver=0
        
    def remove_Search(self):
        self.remove_Marker_Search()
        self.remove_tableWidget_Search()
    
    def remove_rb_All(self):
        self.rb_Routo.reset(True)
        self.rb_Naver.reset(True)
        self.rb_Google.reset(True)
        
    def remove_rb_Naver(self):
        self.rb_Naver.reset(True)
        
    def remove_rb_Routo(self):
        self.rb_Routo.reset(True)

    def remove_rb_Google(self):
        self.rb_Google.reset(True)

# 마커 리스트 삭제
    def remove_Symbol_Routo(self):
        self.Symbol_Routo=None
        
    def remove_Symbol_Naver(self):
        self.Symbol_Naver=None

# 화면의 마커 삭제 전체
    def remove_Marker_All(self):
        self.remove_Marker_Routo()
        self.remove_Marker_Naver()
        self.remove_Marker_Search()

# 화면의 마커 삭제 
    def remove_Marker_Routo(self):
        if len(self.MarkerSymbol_Routo) > 0:  
            for mark in self.MarkerSymbol_Routo:
                self.canvas.scene().removeItem(mark)
        
    def remove_Marker_Naver(self):
        if len(self.MarkerSymbol_Naver) > 0:  
            for mark in self.MarkerSymbol_Naver:
                self.canvas.scene().removeItem(mark)
        
    def remove_Marker_Search(self):
        if len(self.VertexMarker_Search) > 0:
            for mark in self.VertexMarker_Search:
                self.canvas.scene().removeItem(mark)
        self.VertexMarker_Search = []
        
        if len(self.MarkerSymbol_Search) > 0:  
            for mark in self.MarkerSymbol_Search:
                self.canvas.scene().removeItem(mark)
        self.MarkerSymbol_Search = []
        
    # 경탐안내 테이블 초기화 
    def remove_tableWidget_All(self):
        self.remove_tableWidget_Routo()
        self.remove_tableWidget_Naver()
        self.remove_tableWidget_Search()
    
    def remove_tableWidget_Routo(self):
        self.tableWidget_Routo.setColumnCount(4)
        table_column=["이동" , "안내" , "x" , "y"]
        self.tableWidget_Routo.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Routo.setRowCount(0)
        self.tableWidget_Routo.resizeColumnsToContents()
        self.TotalDistance_label_Routo.setText('')
        self.TotalTime_label_Routo.setText('')
        
    def remove_tableWidget_Naver(self):
        self.tableWidget_Naver.setColumnCount(4)
        table_column=["이동" , "안내" , "x" , "y"]
        self.tableWidget_Naver.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Naver.setRowCount(0)
        self.tableWidget_Naver.resizeColumnsToContents()
        self.TotalDistance_label_Naver.setText('')
        self.TotalTime_label_Naver.setText('')  
        
    def remove_tableWidget_Search(self):
        self.Search_LineEdit.clear()
        self.tableWidget_Search.setColumnCount(6)
        table_column=["이동" ,"선택" , "명칭" , "주소" , "x" , "y"]
        self.tableWidget_Search.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Search.setRowCount(0)
        self.tableWidget_Search.resizeColumnsToContents()   
         
# 시종점 반전
    def switch(self):
        SPoint=self.SPoint_lineEdit.text()
        EPoint=self.EPoint_lineEdit.text()
        self.SPoint_lineEdit.clear()
        self.EPoint_lineEdit.clear()
        self.SPoint_lineEdit.setText(EPoint)
        self.EPoint_lineEdit.setText(SPoint)

# 좌표캡쳐 시작
    def capture(self):
        if self.capture_toolButton.isChecked():
            self.savedMapTool = self.canvas.mapTool()
            self.canvas.setMapTool(self.captureCoordinate)
        else:
            if self.savedMapTool:
                self.canvas.setMapTool(self.savedMapTool)
                self.savedMapTool = None

# 아이콘 클릭으로 캡쳐 중단
    def stopCapture(self):
        self.CTool.Delete_Marker()
        self.capture_toolButton.setChecked(False)
        
# ESC 눌러서 캡쳐 중단
    def stopCapture1(self):
        self.CTool.Delete_Marker()
        self.capture_toolButton.setChecked(False)    
        self.iface.actionPan().trigger()

    def listsetup(self):
        keyword=self.Search_LineEdit.text()
        searchidx = int(self.Search_ComboBox.currentIndex())
        
        self.tableWidget_Search.setColumnCount(6)
        table_column=["이동" ,"선택" , "명칭" , "주소" , "x" , "y"]
        self.tableWidget_Search.setHorizontalHeaderLabels(table_column)
        self.tableWidget_Search.setRowCount(0)
        self.tableWidget_Search.resizeColumnsToContents() 
        
        if searchidx == 0 and keyword != '':
            Q1=None
            Q2=None
            places = self.Search.Search_kakao (keyword,1)
            totals = places['meta']['pageable_count']
            if totals > 0 :
                if totals > 30:
                    total=30
                    Q1=15
                    Q2=15
                else:
                    total=totals
                    if total > 15:
                        Q1=15
                        Q2=total-15
                    else:
                        Q1=total
                self.remove_Marker_Search()
                self.Buttons1=[]
                self.ComboBox=[]
                self.tableWidget_Search.setRowCount(total)

                for i in range(total):
                    btn1=QPushButton("이동")
                    btn1.resize(16, 16)
                    self.Buttons1.append(btn1)
                    self.Buttons1[i].clicked.connect(self.btn1_fun)
                    self.tableWidget_Search.setCellWidget(i,0,self.Buttons1[i])
                    box = QComboBox()
                    box.addItem("선택")
                    box.addItem("출발지")
                    box.addItem("도착지")
                    box.addItem("경유지1")
                    box.addItem("경유지2")
                    box.addItem("경유지3")
                    box.addItem("경유지4")
                    self.ComboBox.append(box)
                    self.ComboBox[i].currentIndexChanged.connect(self.ComboBox_fun)
                    self.tableWidget_Search.setCellWidget(i,1,self.ComboBox[i])
    
                if Q1 is not None:
                    for i in range(Q1):
                        self.tableWidget_Search.setItem(i, 2, QTableWidgetItem(places['documents'][i]['place_name']))
                        if places['documents'][i]['road_address_name'] == '':
                            address=places['documents'][i]['address_name']
                        else:
                            address=places['documents'][i]['road_address_name']
                        self.tableWidget_Search.setItem(i, 3, QTableWidgetItem(address))
                        self.tableWidget_Search.setItem(i, 4, QTableWidgetItem(places['documents'][i]['x']))
                        self.tableWidget_Search.setItem(i, 5, QTableWidgetItem(places['documents'][i]['y']))
                        
                        projCRS = self.canvas.mapSettings().destinationCrs()
                        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                        
                        projpoint = Trans.transform(float(places['documents'][i]['x']), float(places['documents'][i]['y']))
                        m = QgsVertexMarker(self.canvas)
                        m.setCenter(projpoint)
                        if i == 0:
                            m.setColor(QColor(255, 200, 0))
                            m.setPenWidth(3)
                        else:
                            m.setColor(QColor(255, 225, 80))
                            m.setPenWidth(2)
                        m.setIconSize(12)
                        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                        self.VertexMarker_Search.append(m)
                        
                        sym = QgsMarkerSymbol()
                        sym.setSize(0)
                        txt = QTextDocument(places['documents'][i]['place_name'])
                        lbl = QgsTextAnnotation(self.canvas)
                        lbl.setDocument(txt)
                        lbl.setFrameSize(QSizeF(50.0, 25.0))
                        lbl.setMapPosition(projpoint)
                        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                        lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                        lbl.setMarkerSymbol(sym)
                        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                        self.MarkerSymbol_Search.append(Symbol)
                        
                    lon=float(places['documents'][0]['x'])
                    lat=float(places['documents'][0]['y'])
                    self.Funtion.moveto(epsg4326, lon, lat, 0)  
                    
                if Q2 is not None:
                    places = self.Search.Search_kakao (keyword,2)
                    total2 = places['meta']['pageable_count']
                    if total2 < total:
                        self.tableWidget_Search.setRowCount(total2)
                        Q2= total2 - 15

                    for i in range(Q2):
                        self.tableWidget_Search.setItem(i+15, 2, QTableWidgetItem(places['documents'][i]['place_name']))
                        if places['documents'][i]['road_address_name'] == '':
                            address=places['documents'][i]['address_name']
                        else:
                            address=places['documents'][i]['road_address_name']
                        self.tableWidget_Search.setItem(i+15, 3, QTableWidgetItem(address))
                        self.tableWidget_Search.setItem(i+15, 4, QTableWidgetItem(places['documents'][i]['x']))
                        self.tableWidget_Search.setItem(i+15, 5, QTableWidgetItem(places['documents'][i]['y']))
                
                        projCRS = self.canvas.mapSettings().destinationCrs()
                        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                        projpoint = Trans.transform(float(places['documents'][i]['x']), float(places['documents'][i]['y']))
                        m = QgsVertexMarker(self.canvas)
                        m.setCenter(projpoint)
                        m.setColor(QColor(255, 225, 80))
                        m.setPenWidth(2)
                        m.setIconSize(12)
                        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                        self.VertexMarker_Search.append(m)
                        
                        sym = QgsMarkerSymbol()
                        sym.setSize(0)
                        txt = QTextDocument(places['documents'][i]['place_name'])
                        lbl = QgsTextAnnotation(self.canvas)
                        lbl.setDocument(txt)
                        lbl.setFrameSize(QSizeF(50.0, 25.0))
                        lbl.setMapPosition(projpoint)
                        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                        lbl.setFrameOffsetFromReferencePoint(QPointF(10, 5))
                        lbl.setMarkerSymbol(sym)
                        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                        self.MarkerSymbol_Search.append(Symbol)
            else:
                QMessageBox.critical(self.iface.mainWindow(), "kakao", "검색 결과 없음")
                
            self.tableWidget_Search.setAlternatingRowColors(True)
            for i in range(1,6):
                self.tableWidget_Search.resizeColumnToContents(i) 

                    
        elif searchidx == 1 and keyword != '':
            data = self.Search.Search_routo(keyword)
            if data['total']>0:
                if data['total']>30:
                    total = 30
                else:
                    total = data['total']
                self.remove_Marker_Search()
                self.Buttons1=[]
                self.ComboBox=[]
                self.tableWidget_Search.setRowCount(total)
    
                for i in range(total):
                    btn1=QPushButton("이동")
                    btn1.resize(16, 16)
                    self.Buttons1.append(btn1)
                    self.Buttons1[i].clicked.connect(self.btn1_fun)
                    self.tableWidget_Search.setCellWidget(i,0,self.Buttons1[i])
                    box = QComboBox()
                    box.addItem("선택")
                    box.addItem("출발지")
                    box.addItem("도착지")
                    box.addItem("경유지1")
                    box.addItem("경유지2")
                    box.addItem("경유지3")
                    box.addItem("경유지4")
                    self.ComboBox.append(box)
                    self.ComboBox[i].currentIndexChanged.connect(self.ComboBox_fun)
                    self.tableWidget_Search.setCellWidget(i,1,self.ComboBox[i])
                    
                    # print(data['result'][i])
                    self.tableWidget_Search.setItem(i, 2, QTableWidgetItem(data['result'][i]['title']))
                    address='Null'
                    if data['result'][i]['addrRoad'] == '':
                        address=data['result'][i]['addr']
                    else:
                        address=data['result'][i]['addrRoad']
                    self.tableWidget_Search.setItem(i, 3, QTableWidgetItem(address))
                    self.tableWidget_Search.setItem(i, 4, QTableWidgetItem(str(data['result'][i]['guide']['lon'])))
                    self.tableWidget_Search.setItem(i, 5, QTableWidgetItem(str(data['result'][i]['guide']['lat'])))
                    
                    projCRS = self.canvas.mapSettings().destinationCrs()
                    Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                    projpoint = Trans.transform(float(data['result'][i]['guide']['lon']), float(data['result'][i]['guide']['lat']))
                    m = QgsVertexMarker(self.canvas)
                    m.setCenter(projpoint)
                    if i == 0:
                        m.setColor(QColor(126, 44, 255))
                        m.setPenWidth(3)
                    else:
                        m.setColor(QColor(180, 133, 255))
                        m.setPenWidth(2)
                    m.setIconSize(12)
                    m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                    self.VertexMarker_Search.append(m)
                    
                    sym = QgsMarkerSymbol()
                    sym.setSize(0)
                    txt = QTextDocument(data['result'][i]['title'])
                    lbl = QgsTextAnnotation(self.canvas)
                    lbl.setDocument(txt)
                    lbl.setFrameSize(QSizeF(50.0, 25.0))
                    lbl.setMapPosition(projpoint)
                    lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                    lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
                    lbl.setMarkerSymbol(sym)
                    Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                    self.MarkerSymbol_Search.append(Symbol)
                    
                lon=float(data['result'][0]['guide']['lon'])
                lat=float(data['result'][0]['guide']['lat'])
                self.Funtion.moveto(epsg4326, lon, lat, 0)  
            else:
                QMessageBox.critical(self.iface.mainWindow(), "Routo", "검색 결과 없음")
                
            self.tableWidget_Search.setAlternatingRowColors(True)
            for i in range(1,6):
                self.tableWidget_Search.resizeColumnToContents(i) 

    def btn1_fun(self):
        button1 = self.tableWidget_Search.sender()
        item = self.tableWidget_Search.indexAt(button1.pos())   
        idx = int(item.row())
        rowCount=self.tableWidget_Search.rowCount()
        lon=self.tableWidget_Search.item( idx,4 ).text()
        lat=self.tableWidget_Search.item( idx,5 ).text()
        self.Funtion.moveto(epsg4326, lon, lat, 0)
        
        projCRS = self.canvas.mapSettings().destinationCrs()
        Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
        projpoint = Trans.transform(float(lon), float(lat))
        
        self.remove_Marker_Search()
        
        searchidx = int(self.Search_ComboBox.currentIndex())
        if searchidx == 0:
            Color1 = QColor(255, 225, 80)
            Color2 = QColor(255, 200, 0)
        else:
            Color1 = QColor(180, 133, 255)
            Color2 = QColor(126, 44, 255)
        
        for i in range(rowCount):
            
            if idx != i :
                lon=self.tableWidget_Search.item( i,4 ).text()
                lat=self.tableWidget_Search.item( i,5 ).text()
                projpoint1 = Trans.transform(float(lon), float(lat))
                
                m = QgsVertexMarker(self.canvas)
                m.setCenter(projpoint1)

                m.setColor(Color1)

                m.setPenWidth(2)
                m.setIconSize(12)
                m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
                self.VertexMarker_Search.append(m)

                sym = QgsMarkerSymbol()
                sym.setSize(0)
                txt = QTextDocument(str(self.tableWidget_Search.item( i,2 ).text()))
                lbl = QgsTextAnnotation(self.canvas)
                lbl.setDocument(txt)
                lbl.setFrameSize(QSizeF(50.0, 20.0))
                lbl.setMapPosition(projpoint1)
                lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
                lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
                lbl.setMarkerSymbol(sym)
                Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
                self.MarkerSymbol_Search.append(Symbol)
                
        m = QgsVertexMarker(self.canvas)
        m.setCenter(projpoint)
        m.setColor(Color2)
        m.setPenWidth(3)
        m.setIconSize(12)
        m.setIconType(QgsVertexMarker.ICON_BOX) # ICON_BOX, ICON_CROSS, ICON_X
        self.VertexMarker_Search.append(m)
        
        lbl = QgsTextAnnotation(self.canvas)
        txt = QTextDocument(str(self.tableWidget_Search.item( idx,2 ).text()))
        sym = QgsMarkerSymbol()
        sym.setSize(0)
        lbl.setDocument(txt)
        lbl.setFrameSize(QSizeF(50.0, 20.0))
        lbl.setMapPosition(projpoint)
        lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
        lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
        lbl.setMarkerSymbol(sym)
        Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
        self.MarkerSymbol_Search.append(Symbol)
        self.canvas.refresh() 
        
    def ComboBox_fun(self):
        button2 = self.tableWidget_Search.sender()
        item = self.tableWidget_Search.indexAt(button2.pos())  
        idx = int(item.row())
        lon=self.tableWidget_Search.item( idx,4 ).text()
        lat=self.tableWidget_Search.item( idx,5 ).text()
        point = str(lon) + ',' + str(lat)
        Box=int(self.ComboBox[idx].currentIndex())
        if Box == 1:
            self.SPoint_lineEdit.setText(point)
        elif Box == 2:
            self.EPoint_lineEdit.setText(point)
        elif Box == 3:
            self.PPoint_lineEdit_1.setText(point)
        elif Box == 4:
            self.PPoint_lineEdit_2.setText(point)
        elif Box == 5:
            self.PPoint_lineEdit_3.setText(point)
        elif Box == 6:
            self.PPoint_lineEdit_4.setText(point)
        
# 캡쳐좌표 입력
    def capturedPoint(self, point,chk):
        self.CTool.Draw_Marker(point,4)
        if self.isVisible():
            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(projCRS, epsg4326, QgsProject.instance())
            point = Trans.transform(point.x(), point.y())
            
            # 위치정보
            wgs = self.Funtion.fscoordinate(point)
            map, company, team, ctp, sig = self.Funtion.mapidinfo(wgs)
            self.iface.statusBarIface().showMessage(f"{company} / {team} / {ctp} / {sig} / {map} / {wgs}", 4000)
            
            x=point[0]
            y=point[1]
            GRSpoint=(str(float(x))+','+str(float(y)))
            if chk== 'str':
                self.SPoint_lineEdit.setText(str(GRSpoint))
            elif chk== 'end':
                self.EPoint_lineEdit.setText(str(GRSpoint))
            elif chk== 'pass':
                for i in range(1,5):
                    if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()=='':
                        self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).setText(str(GRSpoint))
                        break
            else:
                pass
        self.CTool.Delete_Marker_Shot(1000)
        
# 경탐
    def path_search(self):
        self.stopCapture1()

        self.drawShape = 'lineString'
        
        if self.radioButton_Routo.isChecked() == True :
            self.Routo=1
            self.tabWidget.setCurrentIndex(0)
            self.cmtName = "경탐_라인_Routo"
            self.Buttons_Routo=[]
            self.DrawLineRouto=[]
            self.chk=0
            # self.tableWidget=self.tableWidget_Routo
            # MarkerSymbol=self.MarkerSymbol_Routo
            # self.rb=self.rb_Routo
            self.remove_Marker_Routo()
            self.remove_tableWidget_Routo()
            self.rb_Routo.reset(True)
            
            SPoint = self.SPoint_lineEdit.text()
            if SPoint!='':
                SPointX=SPoint.split(',')[0]
                SPointY=SPoint.split(',')[1]
                SPoint={"x" : float(SPointX),"y" : float(SPointY),"Name" : "출발지"}
                
                EPoint = self.EPoint_lineEdit.text()
                if EPoint!='':
                    if self.SPoint_lineEdit.text() != self.EPoint_lineEdit.text():
                        EPointX=EPoint.split(',')[0]
                        EPointY=EPoint.split(',')[1]
                        EPoint={"x" : float(EPointX),"y": float(EPointY),"Name" : "목적지"}

                        PPoints=[]
                        for i in range(1,5):
                            text = self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
                            if text != '':
                                PPointX=text.split(',')[0]
                                PPointY=text.split(',')[1]
                                PPointt={"x" : float(PPointX),"y": float(PPointY)}
                                PPoints.append(PPointt)

                        SPointList = {"nodes": PPoints }
                        
                        if self.radioButton_0.isChecked() == True :
                            RouteOption='0'
                        elif self.radioButton_2.isChecked() == True :
                            RouteOption='2'
                        elif self.radioButton_3.isChecked() == True :
                            RouteOption='3'

                        params = {
                            'RPOption' : [{
                                "FeeOption": "0", #요금옵션  (0: 모든도로 , 1: 무료도로)
                                "RoadOption": "1", #우선도로 옵션 (0: 모든도로 , 1: 고속도로우선 ,2:고속도로회피 , 3: 자동차전용도로회피)
                                "RouteOption": RouteOption # 탐색옵션 ( 0: 최소시간, 1:(미정의) 2: 최단, 3:추천 )
                            }],
                            'CoordType' : "2" , # 좌표계 타입 (1:Bessel, 2:WGS84)
                            'CarType' : "0", # 단말 차종 (0:미선택, 1:승용차/소형합차, 2:중혐승합차, 3:대형승합차, 4:대형화물차, 5:특수화물차, 6:경차)
                            'SPoint' : SPoint,
                            'EPoint' :EPoint,   
                            'SPointList': SPointList
                            }

                        url = '	https://mlp.hyundai-mnsoft.com:9144/mlp/tsprp'

                        headers = {
                            'contentType': "application/json; charset=UTF-8",
                            'AuthCode': 'AB7B15940E89447C',
                            'UniqueId': '01012345678',
                            'Version': '1.1.0',
                            'ServiceId': '5000',
                            'MsgId': 'RCH03',
                            'coordinate': 'G',
                            'ReqCompression': 'A',
                            'ReqEncription': 'B',
                            'ReqFormat': 'J',
                            'RespCompression': '0',
                            'RespEncription': '0',
                            'RespFormat': 'J',
                            'Country': '1'
                            }

                        response = requests.post(url , json=params , headers=headers , verify=False)
                        # response = requests.post(url=url, datas = json.dumps(params), headers=headers)
                        if response.status_code == 200:
                            data = response.json()
                            # print(data)
                            # print(data[0]['FeeInfo']) # 톨게이트 정보
                            # print(data[0]['PosList']) # 링크좌표정보
                            # print(data[0]['RgData']) # 안내정보
                            # print(data[0]['RpOpt']) # 검색 옵션 정보
                            # print(data[0]['Summary']) # 총 거리, 비용, 시간
                            # print(data[0]['TraInfo']) # 교통정보
                            
                            # FeeOption=data[0]['RpOpt']['FeeOption'] # 0: 모든도로, 1: 무료도로
                            # RoadOption=data[0]['RpOpt']['RoadOption'] # 0: 모든도로, 1: 고속도로우선 2: 고속도로회피 3: 자동차전용도로회피
                            RouteOption=data[0]['RpOpt']['RouteOption'] # 0: 최소시간, 1:(미정의) 2: 최단, 3:추천
                            if RouteOption == 0:
                                RouteOption='최소시간'
                            elif RouteOption == 2:
                                RouteOption='최단'
                            elif RouteOption == 3:
                                RouteOption='추천'
                            TotalDistance=data[0]['Summary']['TotalDistance'] # 총 거리 (단위 m)
                            TotalDistance=round((TotalDistance/1000),1)
                            TotalFee=data[0]['Summary']['TotalFee'] # 주행 비용(단위 원)
                            TotalTime=data[0]['Summary']['TotalTime'] # 총 시간 (단위 초)
                            Time = divmod(TotalTime, 3600)
                            Time = str(str(int(Time[0])).zfill(2) + ':' + str(int(int(Time[1])//60)).zfill(2)) # 총 시간 (시:분)
                            
                            PosList=data[0]['PosList']
                            RgData=data[0]['RgData']
                            
                            self.TotalDistance_label_Routo.setText('거리 : '+ str(TotalDistance) + 'km')
                            self.TotalTime_label_Routo.setText('시간 : '+ str(Time))
                            
                            projCRS = self.canvas.mapSettings().destinationCrs()
                            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                            
                            # 경탐안내 테이블, 심볼 생성
                            self.DrawLineRouto=[PosList,Trans]
                            self.Marker_Routo(PosList,RgData,Trans)
                            #print(self.DrawLine_checkBox.checkState())
                            if self.SaveLine_checkBox.isChecked() == True:
                                
                                layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
                                if layers:
                                    layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
                                else:
                                    layer = self.Addlayer() # 코멘트 레이어가 없다면 레이어 추가
                                    
                                # 경탐라인 생성
                                geometry = self.shp_DrawLine_Routo(PosList,Trans)
                                
                                # 레이어편집모드
                                layer.startEditing()
                                
                                now = datetime.datetime.now() # 입력 날짜,시간 저장
                                now = now.strftime("%Y-%m-%d %H:%M:%S") 

                                Points=[]
                                for i in range(4):
                                    if i <= len(PPoints)-1:
                                        Points.append(PPoints[i])
                                    else:
                                        P={"x" : float(0),"y": float(0)}
                                        Points.append(P)
                                        
                                pr = layer.dataProvider()
                                f = QgsFeature()
                                f.setAttributes([SPointX,SPointY,
                                                EPointX,EPointY,
                                                Points[0]['x'],Points[0]['y'],
                                                Points[1]['x'],Points[1]['y'],
                                                Points[2]['x'],Points[2]['y'],
                                                Points[3]['x'],Points[3]['y'],
                                                TotalDistance,
                                                TotalFee,
                                                Time,
                                                RouteOption,
                                                # FeeOption,
                                                # RoadOption,
                                                now])
                            
                                f.setGeometry(geometry)
                                pr.addFeature(f)
                                layer.commitChanges()
                                layer.updateExtents()
                                
                                # 레이어편집모드
                                layer.startEditing()
                                
                                layer.renderer().symbol().setColor(QColor(126, 44, 255, 200))
                                if self.drawShape == 'lineString':
                                    layer.renderer().symbol().setWidth(2)
                                layer.triggerRepaint()
                            elif self.DrawLine_checkBox.isChecked() == True:
                                self.DrawLine_Routo(PosList,Trans)
                        else:
                            QMessageBox.critical(self.iface.mainWindow(), "Routo", "Error Code : " + str(response.status_code))
                            print("Routo Error Code : " , response.status_code)
                    else:
                        self.iface.messageBar().pushMessage("", "출발지와 도착지가 동일합니다. 확인 후 다시 지정해 주세요", level=Qgis.Warning, duration=4)          
                else:
                    self.iface.messageBar().pushMessage("", "도착지 좌표가 비였습니다.", level=Qgis.Warning, duration=4) 
            else:
                self.iface.messageBar().pushMessage("", "출발지 좌표가 비였습니다.", level=Qgis.Warning, duration=4)
        # 네이버 경탐 
        elif self.radioButton_Naver.isChecked() == True :
            self.Naver=1
            locale=QSettings()
            self.tabWidget.setCurrentIndex(1)
            client_id=str(locale.value('locale/coordinate_tool/client_id',''))
            client_secret=str(locale.value('locale/coordinate_tool/client_secret',''))
            self.cmtName = "경탐_라인_Naver"
            self.Buttons_Naver=[]
            self.DrawLineNaver=[]
            self.chk=1
            self.remove_Marker_Naver()
            self.remove_tableWidget_Naver()
            # self.tableWidget=self.tableWidget_Naver
            # MarkerSymbol=self.MarkerSymbol_Naver
            # self.rb=self.rb_Naver
            if self.SPoint_lineEdit.text() != '':
                SPoint = self.SPoint_lineEdit.text()
                SPointX=SPoint.split(',')[0]
                SPointY=SPoint.split(',')[1]

                if self.EPoint_lineEdit.text() != '':
                    EPoint = self.EPoint_lineEdit.text()
                    EPointX=EPoint.split(',')[0]
                    EPointY=EPoint.split(',')[1]
                    
                    PPoints=''
                    if self.PPoint_lineEdit_1.text() != '':
                        PPoint=self.PPoint_lineEdit_1.text()
                        PPoints=PPoint
                        for i in range(2,5):
                            if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text() != '':
                                
                                PPoint='|' + self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
                                PPoints += PPoint
                    else:
                        waypoints=''
                                
                    if self.radioButton_3.isChecked() == True :
                        option = 'traoptimal'   # 실시간최적
                        optiontxt = '실시간최적'   # 실시간최적
                    elif self.radioButton_2.isChecked() == True :
                        option = 'tracomfort'   # 실시간편한길
                        optiontxt = '실시간편한길'   # 실시간편한길
                    elif self.radioButton_0.isChecked() == True :
                        option = 'trafast'      # 실시간빠른길
                        optiontxt = '실시간빠른길'   # 실시간빠른길
            
                    # Option Code
                    # 탐색 옵션을 나타내는 코드입니다.(모든 경로는 교통정보를 반영하므로 출발지, 목적지, 옵션이 같더라도 같은 경로가 보장되지 않습니다.)
                    # 스트링 코드        탐색 종류
                    # trafast           실시간 빠른길
                    # tracomfort        실시간 편한길
                    # traoptimal        실시간 최적     ----기본값----
                    # traavoidtoll      무료 우선
                    # traavoidcaronly   자동차 전용도로 회피 우선
            
                    cartype = '1'
                    # Cartype Code
                    # 톨게이트 요금 계산용 차종 정보를 나타내는 코드입니다.
                    # 코드  설명
                    # 1	    1종(소형차) 2축 차량: 윤폭 279.4mm 이하 승용차, 소형승합차, 소형화물차     ----기본값----
                    # 2     2종(중형차) 2축 차량: 윤폭 279.4mm 초과, 윤거 1,800mm 이하 중형승합차, 중형화물차
                    # 3     3종(대형차) 2축 차량: 윤폭 279.4mm 초과, 윤거 1,800mm 초과 대형승합차, 2축 대형화물차
                    # 4     4종(대형화물차) 3축 대형화물차
                    # 5     5종(특수화물차) 4축 이상 특수화물차
                    # 6     1종(경형자동차) 배기량 1000cc 미만으로 길이 3.6m, 너비 1.6m, 높이 2.0m 이하
                    
                    fueltype = 'gasoline'
                    # Fueltype Code
                    # 유류비 계산용 유종을 나타내는 코드입니다.
                    # 스트링 코드        설명
                    # gasoline          휘발유. 유류비 계산 시 사용     ----기본값----
                    # highgradegasoline	고급 휘발유. 유류비 계산 시 사용
                    # diesel	        경유. 유류비 계산 시 사용
                    # lpg	            LPG. 유류비 계산 시 사용

                    url = "https://naveropenapi.apigw.ntruss.com/map-direction/v1/driving?"
                    url = url + f"start={SPoint}&"
                    url = url + f"goal={EPoint}&"
                    if self.PPoint_lineEdit_1.text() != '':
                        url = url + f"waypoints={PPoints}&"
                    url = url + f"option={option}"
                    # url = url + f"cartype={cartype}"
                    # url = url + f"fueltype={fueltype}"

                    headers = {'X-NCP-APIGW-API-KEY-ID': client_id,
                            'X-NCP-APIGW-API-KEY': client_secret}
                    response = requests.get(url, headers=headers)
                    if response.status_code == 200:
                        data = response.json()
                        code=data['code']
                        msg=data['message']
                        if code == 0:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Info, duration=4)  
                            # print(data) # 응답결과
                            # print(data['code']) # 응답결과'code'
                            # print(data['messge']) # 응답 결과 문자열
                            # print(data['currentDateTime']) # 탐색 시점 시간 정보
                            # print(data['route']) # 응답결과 'route'
                                # print(data['route']['summary']) # 요약 정보
                                    # 출발지 좌표
                                    # print(data['route'][option][idx]['summary']['start']['location'])
                                    # 목적지 좌표
                                    # print(data['route'][option][idx]['summary']['goal']['location'])
                                    # print(data['route'][option][idx]['summary']['goal']['dir']) # 경로상에서 location 좌표를 바라보는 방향. 경유지와 목적지에 대해서만 존재 가능 0:전방, 1:왼쪽, 2:오른쪽
                                    # print(data['route'][option][idx]['summary']['waypoints']['location']) # 경유지 경유하는 순서대로 array에 기록
                                    # print(data['route'][option][idx]['summary']['distance']) # 전체 경로 거리(meters)
                                    # print(data['route'][option][idx]['summary']['duration']) # 전체 경로 소요 시간(millisecond(1/1000초))
                                    # print(data['route'][option][idx]['summary']['bbox']) # 전체 경로 경계 영역. left bottom point와 right top point 두 개의 point array로 제공
                                    # print(data['route'][option][idx]['summary']['tollFare']) # 통행 요금(톨게이트)
                                    # print(data['route'][option][idx]['summary']['taxiFare']) # 택시 요금(지자체별, 심야, 시경계, 복합, 콜비 감안)
                                    # print(data['route'][option][idx]['summary']['fuelPrice']) # 해당 시점의 전국 평균 유류비와 연비를 감안한 유류비
                            
                                # print(data['route'][option][idx]['path']) # 경로를 구성하는 모든 좌표열 / 해당 좌표들에는 0번부터 시작되는 index가 있음 이 index는 경로 정보를 표현하기 위한 pointIndex라는 명칭으로 활용됨
                                
                                # print(data['route'][option][idx]['section']) # 해당 경로를 구성하는 주요 도로에 관한 정보열(모든 경로를 포함하는 정보는 아님)
                                    # print(data['route'][option][idx]['section'][idx]['pointIndex']) # 경로를 구성하는 좌표의 인덱스
                                    # print(data['route'][option][idx]['section'][idx]['pointCount']) # 형상점 수
                                    # print(data['route'][option][idx]['section'][idx]['pointCount']) # 거리(meters)
                                    # print(data['route'][option][idx]['section'][idx]['name']) # 도로명
                                    # print(data['route'][option][idx]['section'][idx]['congestion'])   # 구간 혼잡도 1:원활, 2:서행, 3:혼잡
                                                                                                        # (km/h)	일반도로	국도        도시고속	고속도로
                                                                                                        # 원활	    30 이상	    40 이상     60 이상	    70 이상
                                                                                                        # 서행	    15~30	    20~40       0~60	    40~70
                                                                                                        # 혼잡	    15 미만	    20 미만     30 미만	    40 미만
                                    # print(data['route'][option]['section'][idx]['speed']) # 평균 속도(km/h)
                            
                                # print(data['route'][option]['guide']) # 안내 정보열
                                    # print(data['route'][option][idx]['guide'][idx]['pointIndex']) # 경로를 구성하는 좌표의 인덱스
                                    # print(data['route'][option][idx]['guide'][idx]['type']) # 안내 종류
                                    # print(data['route'][option][idx]['guide'][idx]['instructions']) # 	안내 문구
                                    # print(data['route'][option][idx]['guide'][idx]['distance']) # 	이전 guide unit의 경로 구성 좌표 인덱스로부터 해당 guide unit의 경로 구성 좌표 인덱스까지의 거리(meters)
                                    # print(data['route'][option][idx]['guide'][idx]['duration']) # 	이전 guide unit의 경로 구성 좌표 인덱스로부터 해당 guide unit의 경로 구성 좌표 인덱스까지의 소요 시간(millisecond(1/1000초))
                            
                            # 탐색 옵션
                            RouteOption=optiontxt   # trafast	실시간 빠른길
                                                    # tracomfort	실시간 편한길
                                                    # traoptimal	실시간 최적
                                                    # traavoidtoll	무료 우선
                                                    # traavoidcaronly	자동차 전용도로 회피 우선
                            
                            TotalDistance=data['route'][option][0]['summary']['distance'] # 전체 경로 거리(meters)
                            TotalDistance=round((TotalDistance/1000),1)
                            TotalFee=data['route'][option][0]['summary']['tollFare'] # 통행 요금(톨게이트)
                            TotalTime=data['route'][option][0]['summary']['duration'] # 전체 경로 소요 시간(millisecond(1/1000초))
                            Time = int(TotalTime)/1000 # millisecond to second
                            Time = divmod(Time, 3600) # 시간으로 변환
                            Time = str(str(int(Time[0])).zfill(2) + ':' + str(int(int(Time[1])//60)).zfill(2)) # 총 시간 (시:분)
                            PosList=data['route'][option][0]['path'] # 경로를 구성하는 모든 좌표열
                            RgData=data['route'][option][0]['guide'] # 안내 정보열
                            RgData.insert(0,{'pointIndex': 0, 'type': 0, 'instructions': "출발지", 'distance': 0, 'duration': 0}) # 출발지 정보 추가
                            
                            self.TotalDistance_label_Naver.setText('거리 : '+ str(TotalDistance) + 'km')
                            self.TotalTime_label_Naver.setText('시간 : '+ str(Time))
                            
                            projCRS = self.canvas.mapSettings().destinationCrs()
                            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
                            
                            # 경탐안내 테이블, 심볼 생성
                            self.DrawLineNaver=[PosList,Trans]
                            self.Marker_Naver(PosList,RgData,Trans)
                            
                            if self.SaveLine_checkBox.isChecked() == True:
                                layers = QgsProject.instance().mapLayersByName(self.cmtName) # 레이어 목록중 코멘트 레이어 탐색
                                if layers:
                                    layer = layers[0]   # 코멘트 레이어가 있다면. 해당 레이어를 'layer' 변수로 저장
                                else:
                                    layer = self.Addlayer() # 코멘트 레이어가 없다면 레이어 추가
                                    
                                # 경탐라인 생성
                                geometry = self.shp_DrawLine_Naver(PosList,Trans)
                                # 레이어편집모드
                                layer.startEditing()
                                
                                now = datetime.datetime.now() # 입력 날짜,시간 저장
                                now = now.strftime("%Y-%m-%d %H:%M:%S") 

                                Points=[]

                                if PPoints != '':
                                    sPPoints=PPoints.split('|')
                                    for i in range(4):
                                        if i <= len(sPPoints)-1:
                                            Points.append([float(sPPoints[i].split(',')[0]),float(sPPoints[i].split(',')[1])])
                                        else:
                                            P=[int(0),int(0)]
                                            Points.append(P)
                                else:
                                    for i in range(4):
                                        P=[int(0),int(0)]
                                        Points.append(P)    
                                       
                                pr = layer.dataProvider()
                                f = QgsFeature()
                                f.setAttributes([SPointX,SPointY,
                                                EPointX,EPointY,
                                                Points[0][0],Points[0][1],
                                                Points[1][0],Points[1][1],
                                                Points[2][0],Points[2][1],
                                                Points[3][0],Points[3][1],
                                                TotalDistance,
                                                TotalFee,
                                                Time,
                                                RouteOption,
                                                # FeeOption,
                                                # RoadOption,
                                                now])
                            
                                f.setGeometry(geometry)
                                pr.addFeature(f)
                                layer.commitChanges()
                                layer.updateExtents()
                                
                                # 레이어편집모드
                                layer.startEditing()
                                
                                layer.renderer().symbol().setColor(QColor(4, 207, 92, 200))
                                if self.drawShape == 'lineString':
                                    layer.renderer().symbol().setWidth(2)
                                layer.triggerRepaint()
 
                            elif self.DrawLine_checkBox.isChecked() == True:
                                self.DrawLine_Naver(PosList,Trans)
                        elif code == 1:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4) 
                        elif code == 2:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
                        elif code == 4:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
                        elif code == 3:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)     
                        elif code == 5:
                            self.iface.messageBar().pushMessage("", msg, level=Qgis.Warning, duration=4)      
                    else:
                        QMessageBox.critical(self.iface.mainWindow(), "Naver", "Error Code : " + str(response.status_code))
                        print("Naver Error Code : " , response.status_code)
                else:
                    self.iface.messageBar().pushMessage("", "도착지 좌표가 비였습니다.", level=Qgis.Warning, duration=4) 
            else:
                self.iface.messageBar().pushMessage("", "출발지 좌표가 비였습니다.", level=Qgis.Warning, duration=4)
        
        elif self.radioButton_Google.isChecked() == True :
            locale=QSettings()
            google_apiKey=str(locale.value('locale/coordinate_tool/google_apiKey',''))
            if self.SPoint_lineEdit.text() != '':
                SPoint = self.SPoint_lineEdit.text()
                SPointX=SPoint.split(',')[0]
                SPointY=SPoint.split(',')[1]
                SPoints=f'{SPointY},{SPointX}'

                if self.EPoint_lineEdit.text() != '':
                    EPoint = self.EPoint_lineEdit.text()
                    EPointX=EPoint.split(',')[0]
                    EPointY=EPoint.split(',')[1]
                    EPoints=f'{EPointY},{EPointX}'
                    
                    PPoints=''
                    if self.PPoint_lineEdit_1.text() != '':
                        PPoint=self.PPoint_lineEdit_1.text()
                        PPoints=PPoint
                        for i in range(2,5):
                            if self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text() != '':
                                
                                PPoint='|' + self.findChild(QLineEdit,'PPoint_lineEdit_'+str(i)).text()
                                PPoints += PPoint
                    else:
                        waypoints=''
                    # if self.radioButton_3.isChecked() == True :
                    #     option = 'traoptimal'   # 실시간최적
                    #     optiontxt = '실시간최적'   # 실시간최적
                    # elif self.radioButton_2.isChecked() == True :
                    #     option = 'tracomfort'   # 실시간편한길
                    #     optiontxt = '실시간편한길'   # 실시간편한길
                    # elif self.radioButton_0.isChecked() == True :
                    #     option = 'trafast'      # 실시간빠른길
                    #     optiontxt = '실시간빠른길'   # 실시간빠른길
                    
                    payload={}
                    headers = {}
            
            url = "https://maps.googleapis.com/maps/api/directions/json?"
            url = url + f"origin={SPoints}&"
            url = url + f"destination={EPoints}&"
            if self.PPoint_lineEdit_1.text() != '':
                url = url + f"waypoints={PPoints}&"
            url = url + f"&key={google_apiKey}" 
            
            response = requests.request("GET", url, headers=headers, data=payload)
            
            data=response.json()
            data=data['routes'][0]['legs'][0]['steps']
            point=[]
            for id , p in enumerate(data):
                x=p['start_location']['lng']
                y=p['start_location']['lat']
                xy=[x,y]
                point.append(xy)
            x=p['end_location']['lng']
            y=p['end_location']['lat']
            xy=[x,y]
            point.append(xy)
            
            projCRS = self.canvas.mapSettings().destinationCrs()
            Trans = QgsCoordinateTransform(epsg4326, projCRS, QgsProject.instance())
            
            self.DrawLine_Google(point,Trans)
            
    def Addlayer(self):
        layer = QgsVectorLayer(self.drawShape, self.cmtName, "memory") # 코멘트 레이어 생성
        pr = layer.dataProvider() 
        pr.addAttributes([  
                        QgsField("시점_X", QVariant.Double),
                        QgsField("시점_Y",  QVariant.Double),
                        QgsField("종점_X", QVariant.Double),
                        QgsField("종점_Y",  QVariant.Double),
                        QgsField("경유1_X", QVariant.Double),
                        QgsField("경유1_Y",  QVariant.Double),
                        QgsField("경유2_X", QVariant.Double),
                        QgsField("경유2_Y",  QVariant.Double),
                        QgsField("경유3_X", QVariant.Double),
                        QgsField("경유3_Y",  QVariant.Double),
                        QgsField("경유4_X", QVariant.Double),
                        QgsField("경유4_Y",  QVariant.Double),
                        QgsField("거리(m)", QVariant.Double),
                        QgsField("요금(원)", QVariant.Double),
                        QgsField("시간", QVariant.String),
                        QgsField("탐색옵션", QVariant.String),  # 0: 최소시간, 1:(미정의) 2: 최단, 3:추천
                        # QgsField("요금옵션", QVariant.Double),  # 0: 모든도로, 1: 무료도로
                        # QgsField("우선도로", QVariant.Double),  # 0: 모든도로, 1: 고속도로우선 2: 고속도로회피 3: 자동차전용도로회피
                        QgsField("Update_Date", QVariant.DateTime)])
        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)
        map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
        # CRSid=map_crs.authid()
        layer.setCrs(map_crs)
        return layer
    
    def shp_DrawLine_Routo(self,PosList,Trans):
        self.rb_Routo.setColor(QColor(126, 44, 255, 200)) # 루토 라인 색깔
        self.rb_Routo.reset(QgsWkbTypes.LineGeometry)
        for pos in PosList:
            x=pos['X']
            y=pos['Y']
            point = Trans.transform(float(x), float(y))
            self.rb_Routo.addPoint(point)
        self.canvas.refresh()    
        geometry = self.rb_Routo.asGeometry() # 입력한 포인트, 폴리라인, 폴리곤의 도형값 저장
        if self.DrawLine_checkBox.isChecked() == False:
            self.rb_Routo.reset(True)
        return geometry
    
    def DrawLine_Routo(self,PosList,Trans):
        if self.DrawLine_checkBox.isChecked() ==True:
            self.rb_Routo.setColor(QColor(126, 44, 255, 200)) # 루토 라인 색깔
            self.rb_Routo.reset(QgsWkbTypes.LineGeometry)
            for pos in PosList:
                x=pos['X']
                y=pos['Y']
                point = Trans.transform(float(x), float(y))
                self.rb_Routo.addPoint(point)

        if self.Naver == 1:
            self.rb_Naver.setColor(QColor(4, 207, 92, 40))
            
        self.canvas.refresh()
        
    def Marker_Routo(self,PosList,RgData,Trans):
        self.Symbol_Routo=[]
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        if table_Box is True or Symbol_Box is True:
            if table_Box is True:
                table_column=["이동" , "안내" , "x" , "y"]
                self.tableWidget_Routo.setHorizontalHeaderLabels(table_column)
                self.RoutoRowCount=len(RgData)
            RgDistance=0
            if self.radioButton_Routo.isChecked() == True :
                i=0
                for Pos in PosList :
                    x=Pos['X']
                    y=Pos['Y']
                    index=Pos['index']
                    for Rg in RgData :
                        if index == Rg['EndIdx']:
                            projpoint = Trans.transform(float(x), float(y))
                            TurnName= Rg.get('TurnName')
                            TurnCODE= Rg['TurnCODE']
                            if TurnName is not None:
                                Name= Rg['TurnName'][0].get('Name')
                                
                                if TurnCODE==0:
                                    Turn=''
                                else:
                                    Turn=self.TurnCODE.get(str(TurnCODE))
                                    if Turn is not None:
                                        Turn=Turn[0]
                                    else:
                                        Turn = ''
                                        
                                if RgDistance > 999 :
                                    RgDistance = str(RgDistance/1000) + 'km 앞 '
                                else:
                                    RgDistance = str(RgDistance) + 'm 앞 '
                                
                                if i == 0:
                                    msg = '출발지'
                                elif i == len(RgData)-1:
                                    msg = RgDistance + "목적지"
                                elif TurnCODE > 30000:
                                    msg = RgDistance + Turn
                                else:
                                    msg = RgDistance + Name + '에서 ' + Turn
                            else:
                                Name=i+1
                                if TurnCODE==0:
                                    Turn=''
                                else:
                                    Turn=self.TurnCODE.get(str(TurnCODE))
                                    if Turn is not None:
                                        Turn=Turn[0]
                                    else:
                                        Turn = ''
                                if RgDistance > 999 :
                                    RgDistance = str(RgDistance/1000) + 'km 앞'
                                else:
                                    RgDistance = str(RgDistance) + 'm 앞'
                                if i == 0:
                                    msg = '출발지'
                                elif i == len(RgData)-1:
                                    msg = RgDistance + " 목적지"
                                else:
                                    msg = RgDistance + '에서 ' + Turn
                            
                            self.Symbol_Routo.append([i,Name,msg,x,y,projpoint])
                            self.Marker_table_Symbol_Routo(i,Name,msg,x,y,projpoint)
                            
                            RgDistance= Rg['RgDistance']
                            i+=1
                        elif index < Rg['EndIdx']:
                            break
                if table_Box is True:
                    self.tableWidget_Routo.setAlternatingRowColors(True)
                    for i in range(1,3):
                        self.tableWidget_Routo.resizeColumnToContents(i) 

    def Marker_table_Symbol_Routo(self,i,Name,msg,x,y,projpoint):
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        self.tableWidget_Routo.setRowCount(self.RoutoRowCount)
        if table_Box is True:
            btn=QPushButton("이동")
            btn.resize(16, 16)
            self.Buttons_Routo.append(btn)
            self.Buttons_Routo[i].clicked.connect(self.btn_fun_Routo)
            self.tableWidget_Routo.setCellWidget(i,0,self.Buttons_Routo[i])
            self.tableWidget_Routo.setItem(i, 1, QTableWidgetItem(msg))
            self.tableWidget_Routo.setItem(i, 2, QTableWidgetItem(str(x)))
            self.tableWidget_Routo.setItem(i, 3, QTableWidgetItem(str(y)))
        
        if Symbol_Box is True:
            sym = QgsMarkerSymbol()
            sym.setSize(0)
            txt = QTextDocument(str(Name))
            lbl = QgsTextAnnotation(self.canvas)
            if self.chk==0:
                lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,255))
                lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,255))
                lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.2)
            else:
                lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,50))
                lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,50)) 
                txt.setHtml('<p style="color : #b4b4b4">'+str(Name)+'</p>')
                lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.1)
            lbl.setDocument(txt)
            lbl.setFrameSize(QSizeF(50.0, 25.0))
            lbl.setMapPosition(projpoint)
            lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
            lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
            lbl.setMarkerSymbol(sym)
            Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
            self.MarkerSymbol_Routo.append(Symbol)

    def btn_fun_Routo(self):
        button = self.tableWidget_Routo.sender()
        item = self.tableWidget_Routo.indexAt(button.pos())   
        idx = int(item.row())
        lon=self.tableWidget_Routo.item( idx,2 ).text()
        lat=self.tableWidget_Routo.item( idx,3 ).text()
        self.Funtion.moveto(epsg4326, lon, lat, 0)
    
    
    
    def shp_DrawLine_Naver(self,PosList,Trans):
        self.rb_Naver.setColor(QColor(4, 207, 92, 200)) # 네이버 라인 색깔
        self.rb_Naver.reset(QgsWkbTypes.LineGeometry)
        for pos in PosList:
            x=pos[0]
            y=pos[1]
            point = Trans.transform(float(x), float(y))
            self.rb_Naver.addPoint(point)
        self.canvas.refresh()
        geometry = self.rb_Naver.asGeometry() # 입력한 포인트, 폴리라인, 폴리곤의 도형값 저장
        if self.DrawLine_checkBox.isChecked() == False:
            self.rb_Naver.reset(True)
        return geometry
        
    def DrawLine_Naver(self,PosList,Trans):
        if self.DrawLine_checkBox.isChecked() ==True:
            self.rb_Naver.setColor(QColor(4, 207, 92, 200)) # 네이버 라인 색깔
            self.rb_Naver.reset(QgsWkbTypes.LineGeometry)
            for pos in PosList:
                x=pos[0]
                y=pos[1]
                point = Trans.transform(float(x), float(y))
                self.rb_Naver.addPoint(point)
                
        if self.Routo == 1:
            self.rb_Routo.setColor(QColor(126, 44, 255, 40))  
            
        self.canvas.refresh()
        
    def Marker_Naver(self,PosList,RgData,Trans):
        self.Symbol_Naver=[]
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        if table_Box is True or Symbol_Box is True:
            if table_Box is True:
                table_column=["이동" , "안내" , "x" , "y"]
                self.tableWidget_Naver.setHorizontalHeaderLabels(table_column)
                self.NaverRowCount=len(RgData)
            RgDistance=0
            i=0
            ir=1
            x=PosList[0][0]
            y=PosList[0][1]

            for idx , Pos in enumerate(PosList) :
                x=Pos[0]
                y=Pos[1]
                
                for Rg in RgData :

                    if idx == Rg['pointIndex']:
                        projpoint = Trans.transform(float(x), float(y))
                        TurnCODE= Rg['type']
                        Turninfo= Rg['instructions']
                        RgDistance= Rg['distance']
                        Name=i+1
                        
                        # if TurnCODE==0:
                        #     Turn=''
                        # else:
                        #     Turn=self.GuideCode.get(str(TurnCODE))
                        #     if Turn is not None:
                        #         Turn=Turn[0]
                        #     else:
                        #         Turn = ''
                        
                        if RgDistance > 999 :
                            RgDistance = str(RgDistance/1000) + 'km 앞'
                        else:
                            RgDistance = str(RgDistance) + 'm 앞'

                        if i == len(RgData)-1:
                            Name = '목적지'
                        msg = RgDistance + '에서 ' + Turninfo
                        
                        if idx == 0:
                            Name = '출발지'
                            msg='출발지'
                        if Turninfo == '경유지':
                            Name=f'제{ir}경유지'
                            ir += 1
                        self.Symbol_Naver.append([i,Name,msg,x,y,projpoint])
                        self.Marker_table_Symbol_Naver(i,Name,msg,x,y,projpoint)

                        i+=1
                    elif idx < Rg['pointIndex']:
                        break
                    
            if table_Box is True:
                self.tableWidget_Naver.setAlternatingRowColors(True)
                for i in range(1,3):
                    self.tableWidget_Naver.resizeColumnToContents(i) 

    def Marker_table_Symbol_Naver(self,i,Name,msg,x,y,projpoint):
        Symbol_Box=self.Symbol_checkBox.isChecked()
        table_Box=self.tableWidget_checkBox.isChecked()
        self.tableWidget_Naver.setRowCount(self.NaverRowCount)
        if table_Box is True:
            btn=QPushButton("이동")
            btn.resize(16, 16)
            self.Buttons_Naver.append(btn)
            self.Buttons_Naver[i].clicked.connect(self.btn_fun_Naver)
            self.tableWidget_Naver.setCellWidget(i,0,self.Buttons_Naver[i])
            self.tableWidget_Naver.setItem(i, 1, QTableWidgetItem(msg))
            self.tableWidget_Naver.setItem(i, 2, QTableWidgetItem(str(x)))
            self.tableWidget_Naver.setItem(i, 3, QTableWidgetItem(str(y)))
        
        if Symbol_Box is True:
            sym = QgsMarkerSymbol()
            sym.setSize(0)
            txt = QTextDocument(str(Name))
            lbl = QgsTextAnnotation(self.canvas)
            if self.chk==1:
                lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,255))
                lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,255))
                lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.2)
            else:
                lbl.fillSymbol().symbolLayer(0).setColor(QColor(255, 255, 255,50))
                lbl.fillSymbol().symbolLayer(0).setStrokeColor(QColor(0, 0, 0,50)) 
                txt.setHtml('<p style="color : #b4b4b4">'+str(Name)+'</p>')
                lbl.fillSymbol().symbolLayer(0).setStrokeWidth(0.1)
            lbl.setDocument(txt)
            lbl.setFrameSize(QSizeF(50.0, 25.0))
            lbl.setMapPosition(projpoint)
            lbl.setFrameSize(QSizeF(txt.size().width(),txt.size().height()))
            lbl.setFrameOffsetFromReferencePoint(QPointF(10, -25))
            lbl.setMarkerSymbol(sym)
            Symbol = QgsMapCanvasAnnotationItem(lbl, self.canvas)
            self.MarkerSymbol_Naver.append(Symbol)

    def btn_fun_Naver(self):
        button = self.tableWidget_Naver.sender()
        item = self.tableWidget_Naver.indexAt(button.pos())   
        idx = int(item.row())
        lon=self.tableWidget_Naver.item( idx,2 ).text()
        lat=self.tableWidget_Naver.item( idx,3 ).text()
        self.Funtion.moveto(epsg4326, lon, lat, 0)
        
        
    def DrawLine_Google(self,PosList,Trans):
        if self.DrawLine_checkBox.isChecked() ==True:
            self.rb_Google.setColor(QColor(251, 188, 4, 200)) # 구글 라인 색깔
            self.rb_Google.reset(QgsWkbTypes.LineGeometry)
            for pos in PosList:
                x=pos[0]
                y=pos[1]
                point = Trans.transform(float(x), float(y))
                self.rb_Google.addPoint(point)
            self.canvas.refresh()