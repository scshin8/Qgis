import os
from qgis.core import QgsField, QgsFields, QgsProject, QgsVectorLayer, QgsFeature, QgsPointXY, QgsGeometry
from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSignal, QThread, QVariant
from qgis.PyQt.QtWidgets import QDialog, QFileDialog

import datetime
from .Coordinate_Tool_mdbManager import *

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_mdbToShp.ui'))

class Worker(QThread):
    progress = pyqtSignal(int, str)  # Progress value, message
    finished = pyqtSignal()  # Signal when the thread is finished
    stopped = pyqtSignal()  # Signal when the thread is stopped

    def __init__(self, mdb, table_name, lon_index, lat_index, fields, datas, layer, provider, is_table_only=False):
        super().__init__()
        self.mdb = mdb
        self.table_name = table_name
        self.lon_index = lon_index
        self.lat_index = lat_index
        self.fields = fields
        self.datas = datas
        self.layer = layer
        self.provider = provider
        self.is_table_only = is_table_only # 테이블 전용 모드 추가
        self._is_running = True  # Running flag

    def run(self):
        features = []
        count = 0
        total = len(self.datas)
        if total == 0:
            # 시그널 정의가 (int, str)이므로 두 인자 모두 전달
            self.progress.emit(100, "데이터 없음 (0/0)")
            self.finished.emit()
            return

        for row in self.datas:
            if not self._is_running:  # Check if the thread should stop
                self.stopped.emit()  # Emit stopped signal
                return

            new_feature = QgsFeature()
            new_feature.setFields(self.fields)

            if not self.is_table_only:
                try:
                    x = row[self.lon_index] if 0 <= self.lon_index < len(row) else 0
                    y = row[self.lat_index] if 0 <= self.lat_index < len(row) else 0

                    # 좌표 값이 None / 빈 문자열 / 이상한 문자열인 경우 대비
                    if x in (None, '') or y in (None, ''):
                        # 필요하면 continue로 그 행만 스킵하거나, 0,0으로 처리
                        # 여기서는 그냥 건너뛰는 예
                        continue
                    
                    point = QgsPointXY(float(x), float(y))
                    geom = QgsGeometry.fromPointXY(point)
                    new_feature.setGeometry(geom)

                except Exception as e:
                    # 어떤 파일/행에서 깨지는지 디버그용 로그
                    print(f"좌표 변환 오류: {e}, row={row}")
                    continue  # 문제 행만 건너뛰고 계속

            attributes = []
            for i, value in enumerate(row):
                qvariant_type = self.fields.field(i).type()
                if qvariant_type == QVariant.DateTime and value is not None:
                    value = datetime.datetime.isoformat(value)
                attributes.append(value)
            new_feature.setAttributes(attributes)
            features.append(new_feature)

            count += 1
            percent = int((count / total) * 100)
            self.progress.emit(percent, f"[{count}/{total}] {percent}%")  # Emit progress signal

        self.provider.addFeatures(features)
        self.layer.updateExtents()
        self.finished.emit()  # Emit finished signal

    def stop(self):
        """Stop the thread."""
        self._is_running = False


class CoordinateToolmdbToShp(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(CoordinateToolmdbToShp, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.MdbPathBTN.clicked.connect(self.OpenMDBFile)
        self.OkBTN.clicked.connect(self.clickedOkBTN)
        self.CancelBTN.clicked.connect(self.close)  # Connect Cancel button to cancel_worker
        self.TableCBX.currentIndexChanged.connect(self.updateFields)
        # [추가] 필터용 필드 선택이 바뀌면 해당 필드의 값 목록을 채움
        self.FieldCBX.currentIndexChanged.connect(self.updateValues)

        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(False)
        self.label_5.setText('')
        self.mdb = AddMdbManager()
        self.worker_thread = None  # Worker thread reference

        self.worker_threads = []   # [추가] 미리 초기화 (안전)

        # [추가] 필터에 사용할 현재 테이블의 컬럼명 목록 보관
        self._field_names = []

    def initControlValue(self):
        self.TableCBX.clear()
        self.mdbpathEdit.clear()
        self.LonCBX.clear()
        self.LatCBX.clear()

        # [추가] 필터 콤보도 초기화
        self.FieldCBX.clear()
        self.valCheckCBX.clear()

    def convert_type_code_to_qvariant(self, type_code):
        type_code_to_qvariant = {
            int: QVariant.Int,
            str: QVariant.String,
            float: QVariant.Double,
            bool: QVariant.Bool,
            bytes: QVariant.ByteArray,
            datetime.date: QVariant.Date,
            datetime.time: QVariant.Time,
            datetime.datetime: QVariant.DateTime
        }
        return type_code_to_qvariant.get(type_code, QVariant.Invalid)
        #return QVariant.Int


    def get_selected_filter(self):
        """[수정] (필드명, 선택된 값 리스트) 반환.
        선택 없으면 (None, None) → 전체 처리."""
        field_index = self.FieldCBX.currentIndex()
        if field_index <= 0:        # [수정] 빈칸(0번)도 필터 미사용으로 처리
            return None, None

        field_name = self.FieldCBX.currentText()
        try:
            checked = self.valCheckCBX.checkedItems()
        except Exception:
            checked = []

        if not field_name or not checked:
            return None, None

        return field_name, list(checked)


    def filter_datas(self, datas, field_index, selected_values):
        """[추가] 선택된 필드 값이 체크 목록에 포함되는 행만 남긴다."""
        if field_index is None or not selected_values:
            return datas  # 필터 미적용 → 전체 반환

        filtered = []
        for row in datas:
            if 0 <= field_index < len(row):
                if str(row[field_index]) in selected_values:
                    filtered.append(row)
        return filtered
    

    def clickedOkBTN(self, *args):
        self.progressBar.setTextVisible(True)
        self.CancelBTN.clicked.disconnect()
        self.CancelBTN.clicked.connect(self.cancel_worker)
        self.CancelBTN.setText('Cancel')

        table_name = self.TableCBX.currentText()
        if table_name == "":
            return

        is_table_only = self.checkBox_TableOnly.isChecked()

        # [수정] 필터 조건 계산 (필드명, 값 리스트)
        field_name, selected_values = self.get_selected_filter()

        self.worker_threads = []
        for file in self.fileNames:
            self.mdb.OpenFile(file)
            self.mdbName, ext = os.path.splitext(os.path.basename(file))

            query = "*"
            # [수정] 파이썬 필터링 대신 SQL WHERE 로 필터링된 데이터를 바로 읽음
            self.mdb.ReadDatasFiltered(query, table_name, field_name, selected_values)
            datas = self.mdb.GetDatas()

            fields = QgsFields()
            columns = self.mdb.GetColumns()
            lon_index = self.LonCBX.currentIndex()
            lat_index = self.LatCBX.currentIndex()

            if is_table_only:
                # "None"은 지오메트리가 없는 속성 테이블 레이어를 의미합니다.
                layer = QgsVectorLayer("None", f'{self.mdbName}_{table_name}', "memory")
            else:
                layer_crs = self.mQgsProjectionSelectionWidget.crs()
                layer = QgsVectorLayer(f"Point?crs={layer_crs.authid()}", f'{self.mdbName}_{table_name}', "memory")

            provider = layer.dataProvider()

            for col in columns:
                qvariant_type = self.convert_type_code_to_qvariant(col[1])
                fields.append(QgsField(col[0], qvariant_type))

            provider.addAttributes(fields)
            layer.updateFields()

            self.worker_thread = Worker(self.mdb, table_name, lon_index, lat_index, fields, datas, layer, provider, is_table_only)
            self.worker_thread.progress.connect(self.updateProgress)
            self.worker_thread.finished.connect(lambda w=self.worker_thread: self.threadFinished(w))
            self.worker_thread.stopped.connect(lambda w=self.worker_thread: self.threadStopped(w))
            self.worker_thread.start()
            self.worker_threads.append(self.worker_thread)

    def updateProgress(self, value, message):
        self.progressBar.setValue(value)
        self.label_5.setText(message)

    def threadFinished(self, worker):
        # 각 Worker의 레이어를 추가합니다.
        QgsProject.instance().addMapLayer(worker.layer)
        # 작업 완료된 Worker를 리스트에서 제거할 수 있습니다.
        if worker in self.worker_threads:
            self.worker_threads.remove(worker)
        # 모든 Worker가 완료되면 초기화합니다.
        if not self.worker_threads:
            self.initControlValue()
            self.progressBar.setTextVisible(False)
            self.colse_set()

    def threadStopped(self, worker):
        # Worker가 중단된 경우 처리
        if worker in self.worker_threads:
            self.worker_threads.remove(worker)
        self.initControlValue()
        self.progressBar.setTextVisible(False)
        self.label_5.setText("작업이 중단되었습니다.")
        self.colse_set()
        
    def cancel_worker(self, *args):
        """Cancel the worker thread."""
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.stop()  # Stop the worker thread
            self.worker_thread.wait()  # Wait for the thread to finish
            self.worker_thread = None
        self.colse_set()

    def colse_set(self):
        self.CancelBTN.setText('Close')
        self.CancelBTN.clicked.disconnect()
        self.CancelBTN.clicked.connect(self.close)

    def OpenMDBFile(self, *args):
        self.mdbpathEdit.clear()
        # 여러 파일 선택 (리스트 형태로 반환)
        self.fileNames = QFileDialog.getOpenFileNames(None, 'Open file', r"", "mdbFile (*.mdb);;All files (*)")[0]
        # self.fileName = QFileDialog.getOpenFileName(None, 'Open file', r"", "mdbFile (*.mdb);;All files (*)")[0]

        self.mdbpathEdit.setText(", ".join(self.fileNames))
        # self.mdbpathEdit.setText(self.fileName)

        if self.fileNames == "" or self.fileNames == []:
            return

        self.TableCBX.clear()
        self.mdb.OpenFile(self.fileNames[0])
        tables = self.mdb.GetTables()

        if len(tables) > 0:
            self.TableCBX.addItems(tables)
        else:
            return

    def updateFields(self, *args):
        table_name = self.TableCBX.currentText()
        if len(table_name) == 0:
            return

        self.mdb.ReadColumns(table_name)
        columns = self.mdb.GetColumns()

        self.LonCBX.clear()
        self.LatCBX.clear()
        # [추가] 필터 콤보도 함께 초기화
        self.FieldCBX.clear()
        self.valCheckCBX.clear()

        if columns:
            field_names = [field[0] for field in columns]
            self._field_names = field_names  # [추가] 인덱스 매핑용 보관
            
            self.LonCBX.addItems(field_names)
            self.LatCBX.addItems(field_names)

            # [수정] 필터용 필드 콤보: 채우는 동안 시그널을 막아 updateValues 자동 실행 방지
            self.FieldCBX.blockSignals(True)
            self.FieldCBX.clear()          # 위에서 이미 clear 했지만 안전하게 한 번 더
            self.FieldCBX.addItem("")      # 맨 위 빈칸 (필터 미사용 기본값)
            self.FieldCBX.addItems(field_names)
            self.FieldCBX.setCurrentIndex(0)   # 빈칸을 기본 선택
            self.FieldCBX.blockSignals(False)
            # 빈칸이 선택된 상태이므로 값 목록도 비워둠
            self.valCheckCBX.clear()

            def setComboboxWithText(combobox, text):
                index = next((idx for idx, name in enumerate(field_names) if name == text), -1)
                combobox.setCurrentIndex(index)
            
            setComboboxWithText(self.LonCBX, 'Lon_Tune')
            setComboboxWithText(self.LatCBX, 'Lat_Tune')

        else:
            print('빈컬럼입니다.')
            return
        
    def _natural_sort_key(self, v):
        """[추가] 숫자면 숫자로, 아니면 문자열로 정렬하기 위한 키.
        (1, 2, 10 순서가 되도록. 1, 10, 2 방지)"""
        s = str(v)
        try:
            # 정수/실수 모두 대응
            return (0, float(s))
        except (ValueError, TypeError):
            return (1, s)

    def updateValues(self, *args):
        """[수정] FieldCBX 필드의 고유값을 DISTINCT 쿼리로 빠르게 가져와
        valCheckCBX 채운다. (행 루프 제거)"""
        self.valCheckCBX.clear()

        table_name = self.TableCBX.currentText()
        field_index = self.FieldCBX.currentIndex()
        if not table_name or field_index <= 0:
            self.valCheckCBX.clear()
            return

        field_name = self.FieldCBX.currentText()
        if not field_name:
            return

        try:
            values = self.mdb.GetDistinctValues(table_name, field_name)
        except Exception as e:
            print(f"값 목록 로딩 오류: {e}")
            return

        # 숫자 자연 정렬
        try:
            values.sort(key=self._natural_sort_key)
        except Exception:
            pass

        # 콤보박스는 문자열만 받으므로 str 변환
        str_values = [str(v) for v in values]
        if str_values:
            self.valCheckCBX.addItems(str_values)