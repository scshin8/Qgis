import os
from qgis.core import QgsField, QgsFields, QgsProject, QgsVectorLayer, QgsFeature, QgsPointXY, QgsGeometry
from qgis.PyQt.QtCore import QSettings, QVariant
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from PyQt5.QtCore import QSettings, pyqtSignal, QObject, QThread
from PyQt5.QtWidgets import QFileDialog
from qgis.PyQt.QtWidgets import QDialog

import datetime
from .Coordinate_Tool_mdbManager import *

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_mdbToShp.ui'))

class Worker(QThread):
    progress = pyqtSignal(int, str)  # Progress value, message
    finished = pyqtSignal()  # Signal when the thread is finished
    stopped = pyqtSignal()  # Signal when the thread is stopped

    def __init__(self, mdb, table_name, lon_index, lat_index, fields, datas, layer, provider):
        super().__init__()
        self.mdb = mdb
        self.table_name = table_name
        self.lon_index = lon_index
        self.lat_index = lat_index
        self.fields = fields
        self.datas = datas
        self.layer = layer
        self.provider = provider
        self._is_running = True  # Running flag

    def run(self):
        features = []
        count = 0
        total = len(self.datas)

        for row in self.datas:
            if not self._is_running:  # Check if the thread should stop
                self.stopped.emit()  # Emit stopped signal
                return

            new_feature = QgsFeature()
            new_feature.setFields(self.fields)

            x = row[self.lon_index] if 0 <= self.lon_index < len(row) else 0
            y = row[self.lat_index] if 0 <= self.lat_index < len(row) else 0

            point = QgsPointXY(float(x), float(y))
            geom = QgsGeometry.fromPointXY(point)
            new_feature.setGeometry(geom)

            attributes = []
            for i, value in enumerate(row):
                qvariant_type = self.fields.field(i).type()
                if qvariant_type == QVariant.DateTime and value is not None:
                    value = datetime.datetime.isoformat(value)
                attributes.append(value)
            new_feature.setAttributes(attributes)
            features.append(new_feature)

            count += 1
            percent = int((count / total) * 100)
            self.progress.emit(percent, f"[{count}/{total}] {percent}%")  # Emit progress signal

        self.provider.addFeatures(features)
        self.layer.updateExtents()
        self.finished.emit()  # Emit finished signal

    def stop(self):
        """Stop the thread."""
        self._is_running = False


class CoordinateToolmdbToShp(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(CoordinateToolmdbToShp, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.MdbPathBTN.clicked.connect(self.OpenMDBFile)
        self.OkBTN.clicked.connect(self.clickedOkBTN)
        self.CancelBTN.clicked.connect(self.close)  # Connect Cancel button to cancel_worker
        self.TableCBX.currentIndexChanged.connect(self.updateFields)
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(False)
        self.label_5.setText('')
        self.mdb = AddMdbManager()
        self.worker_thread = None  # Worker thread reference

    def initControlValue(self):
        self.TableCBX.clear()
        self.mdbpathEdit.clear()
        self.LonCBX.clear()
        self.LatCBX.clear()
        
    def convert_type_code_to_qvariant(self, type_code):
        type_code_to_qvariant = {
            int: QVariant.Int,
            str: QVariant.String,
            float: QVariant.Double,
            bool: QVariant.Bool,
            bytes: QVariant.ByteArray,
            datetime.date: QVariant.Date,
            datetime.time: QVariant.Time,
            datetime.datetime: QVariant.DateTime
        }
        return type_code_to_qvariant.get(type_code, QVariant.Invalid)
        #return QVariant.Int

    def clickedOkBTN(self):
        self.progressBar.setTextVisible(True)
        self.CancelBTN.clicked.disconnect()  # Connect Cancel button to cancel_worker
        self.CancelBTN.clicked.connect(self.cancel_worker)  # Connect Cancel button to cancel_worker
        self.CancelBTN.setText('Cancel')

        table_name = self.TableCBX.currentText()
        if table_name == "":
            return

        # Worker 객체들을 저장할 리스트를 생성합니다.
        self.worker_threads = []
        for file in self.fileNames:
            print("선택한 파일:", file)
            self.mdb.OpenFile(file)
            # self.mdbName = os.path.basename(file)
            self.mdbName, ext = os.path.splitext(os.path.basename(file))
            
            query = "*"      
            self.mdb.ReadDatas(query, table_name)
            datas = self.mdb.GetDatas()

            fields = QgsFields()
            columns = self.mdb.GetColumns()
            lon_index = self.LonCBX.currentIndex()
            lat_index = self.LatCBX.currentIndex()

            layer_crs = self.mQgsProjectionSelectionWidget.crs()
            layer = QgsVectorLayer(f"Point?crs={layer_crs.authid()}", self.mdbName, "memory")
            provider = layer.dataProvider()

            for col in columns:
                qvariant_type = self.convert_type_code_to_qvariant(col[1])
                fields.append(QgsField(col[0], qvariant_type))
            
            provider.addAttributes(fields)
            layer.updateFields()

            # Start worker thread
            self.worker_thread = Worker(self.mdb, table_name, lon_index, lat_index, fields, datas, layer, provider)
            self.worker_thread.progress.connect(self.updateProgress)
             # lambda를 사용하여 각 Worker를 개별적으로 인자로 넘깁니다.
            self.worker_thread.finished.connect(lambda w=self.worker_thread: self.threadFinished(w))
            self.worker_thread.stopped.connect(lambda w=self.worker_thread: self.threadStopped(w))
            self.worker_thread.start()
            # 생성한 Worker를 리스트에 추가합니다.
            self.worker_threads.append(self.worker_thread)

    def updateProgress(self, value, message):
        self.progressBar.setValue(value)
        self.label_5.setText(message)

    def threadFinished(self, worker):
        # 각 Worker의 레이어를 추가합니다.
        QgsProject.instance().addMapLayer(worker.layer)
        # 작업 완료된 Worker를 리스트에서 제거할 수 있습니다.
        self.worker_threads.remove(worker)
        # 모든 Worker가 완료되면 초기화합니다.
        if not self.worker_threads:
            self.initControlValue()
            self.progressBar.setTextVisible(False)
            self.colse_set()

    def threadStopped(self, worker):
        # Worker가 중단된 경우 처리
        if worker in self.worker_threads:
            self.worker_threads.remove(worker)
        self.initControlValue()
        self.progressBar.setTextVisible(False)
        self.label_5.setText("작업이 중단되었습니다.")
        self.colse_set()
        
    def cancel_worker(self):
        """Cancel the worker thread."""
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.stop()  # Stop the worker thread
            self.worker_thread.wait()  # Wait for the thread to finish
            self.worker_thread = None
        self.colse_set()

    def colse_set(self):
        self.CancelBTN.setText('Close')
        self.CancelBTN.clicked.disconnect()
        self.CancelBTN.clicked.connect(self.close)

    def OpenMDBFile(self):
        self.mdbpathEdit.clear()
        # 여러 파일 선택 (리스트 형태로 반환)
        self.fileNames = QFileDialog.getOpenFileNames(None, 'Open file', r"", "mdbFile (*.mdb);;All files (*)")[0]
        # self.fileName = QFileDialog.getOpenFileName(None, 'Open file', r"", "mdbFile (*.mdb);;All files (*)")[0]

        self.mdbpathEdit.setText(", ".join(self.fileNames))
        # self.mdbpathEdit.setText(self.fileName)
        if self.fileNames == "":
            return

        self.TableCBX.clear()
        self.mdb.OpenFile(self.fileNames[0])
        tables = self.mdb.GetTables()

        if len(tables) > 0:
            self.TableCBX.addItems(tables)
        else:
            return

    def updateFields(self):
        table_name = self.TableCBX.currentText()
        if len(table_name) == 0:
            return

        self.mdb.ReadColumns(table_name)
        columns = self.mdb.GetColumns()

        self.LonCBX.clear()
        self.LatCBX.clear()

        if columns:
            field_names = [field[0] for field in columns]
            self.LonCBX.addItems(field_names)
            self.LatCBX.addItems(field_names)

            def setComboboxWithText(combobox, text):
                index = next((idx for idx, name in enumerate(field_names) if name == text), -1)
                combobox.setCurrentIndex(index)
            
            setComboboxWithText(self.LonCBX, 'Lon_Tune')
            setComboboxWithText(self.LatCBX, 'Lat_Tune')

        else:
            print('빈컬럼입니다.')
            return
