import os
from qgis.core import QgsField, QgsFields, QgsProject, QgsVectorLayer, QgsFeature, QgsPointXY, QgsGeometry
from qgis.PyQt.QtCore import QSettings, QVariant
from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import QFileDialog
from qgis.PyQt.QtWidgets import QDialog

import datetime
from .Coordinate_Tool_mdbManager import *

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/Coordinate_Tool_mdbToShp.ui'))

class CoordinateToolmdbToShp(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(CoordinateToolmdbToShp, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.MdbPathBTN.clicked.connect(self.OpenMDBFile)
        self.OkBTN.clicked.connect(self.clickedOkBTN)
        self.CancelBTN.clicked.connect(self.close)
        self.TableCBX.currentIndexChanged.connect(self.updateFields)
        # self.progressBar.setValue(0)
        # self.progressBar.setTextVisible(False)
        self.label_5.setText('')
        self.mdb = AddMdbManager()

    def initControlValue(self):
        self.TableCBX.clear()
        self.mdbpathEdit.clear()
        self.LonCBX.clear()
        self.LatCBX.clear()

    def convert_type_code_to_qvariant(self, type_code):
        type_code_to_qvariant = {
            int: QVariant.Int,
            str: QVariant.String,
            float: QVariant.Double,
            bool: QVariant.Bool,
            bytes: QVariant.ByteArray,
            datetime.date: QVariant.Date,
            datetime.time: QVariant.Time,
            datetime.datetime: QVariant.DateTime
        }
        return type_code_to_qvariant.get(type_code, QVariant.Invalid)
        #return QVariant.Int

    def clickedOkBTN(self):
        tableName = self.TableCBX.currentText()
        if tableName == "":
            return
        
        query = "*"      
        self.mdb.ReadDatas(query, tableName)
        datas = self.mdb.GetDatas()

        #create field
        fields = QgsFields()
        columns = self.mdb.GetColumns()
        lon_index = self.LonCBX.currentIndex()
        lat_index = self.LatCBX.currentIndex()

        crs = QgsProject.instance().crs()
        layer_crs = self.mQgsProjectionSelectionWidget.crs()
        layer = QgsVectorLayer(f"Point?crs={layer_crs.authid()}", tableName, "memory")  # MDBPoint
        provider = layer.dataProvider()
        #provider.addAttributes(fields)

        #layer.startEditing()
        for col in columns:
            qvariant_type = self.convert_type_code_to_qvariant(col[1])
            fields.append(QgsField(col[0], qvariant_type))
            #QMessageBox.about(self, 'Message', f"name{col[0]}, type{qvariant_type}")
            #print(f"Column: {col[0]}, Type Code: {col[1]}, QVariant Type: {qvariant_type}")  # Debugging line
        
        provider.addAttributes(fields)
        layer.updateFields()
        
        features = []
        count = 0

        for row in datas:
            new_feature = QgsFeature()
            new_feature.setFields(fields)

            x = row[lon_index] if 0 <= lon_index < len(row) else 0
            y = row[lat_index] if 0 <= lat_index < len(row) else 0

            point = QgsPointXY(x, y)
            geom = QgsGeometry.fromPointXY(point)
            new_feature.setGeometry(geom)

            attributes = []
            for i, value in enumerate(row):
                print(f"i{i}, value{value}")
                qvariant_type = fields.field(i).type()
                if qvariant_type == QVariant.DateTime:
                    #mdb 값을 그대로 전달할 경우 오류 발생 됨. isoformat으로 QVariant.DateTime 형식으로 변환
                    if value is not None:
                        value = datetime.datetime.isoformat(value)

                attributes.append(value)
            new_feature.setAttributes(attributes)
            features.append(new_feature)

            count += 1
            percent = (count/len(datas)) * 100
            # self..progressBar.setValue(percent)
            self.label_5.setText("[{}/{}] {}%".format(len(datas), count, percent))

        provider.addFeatures(features)
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

        self.initControlValue()
        self.close()
        return

    def OpenMDBFile(self):
        # filename = QFileDialog
        self.mdbpathEdit.clear()
        
        self.fileName = QFileDialog.getOpenFileName(None, 'Open file', r"", "mdbFile (*.mdb);;All files (*)")[0]
        self.mdbpathEdit.setText(self.fileName)
        if self.fileName == "":
            return

        self.TableCBX.clear()
        self.mdb.OpenFile(self.fileName)
        tables = self.mdb.GetTables()
        
        if len(tables) > 0:
            self.TableCBX.addItems(tables)
        else:
            return
    
    def updateFields(self):
        #Field명 읽어와서 콤보박스에 뿌리기
        tableName = self.TableCBX.currentText()
        
        #콤보박스가 클리어 되는 순간도 콤보박스 체인지 이벤트가 작동하는것을 대비
        if len(tableName) == 0:
            return

        self.mdb.ReadColumns(tableName)
        columns = self.mdb.GetColumns()

        self.LonCBX.clear()
        self.LatCBX.clear()

        if columns:
            field_names = [field[0] for field in columns]
            self.LonCBX.addItems(field_names)
            self.LatCBX.addItems(field_names)

            def setComboboxWithText(combobox, text):
                index = next((idx for idx, name in enumerate(field_names) if name == text), -1)
                combobox.setCurrentIndex(index)
            
            #Lon_Tune, Lat_Tune 값이 있으면 해당 값으로 콤보박스값 설정하고 없으면 -1 인덱스 설정
            setComboboxWithText(self.LonCBX, 'Lon_Tune')
            setComboboxWithText(self.LatCBX, 'Lat_Tune')

        else:
            print('빈컬럼입니다.')
            return