from qgis.core import (QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, 
                       QgsProject, 
                       Qgis)

from PyQt5.QtCore import (QSettings,
                          QTimer, 
                          Qt,
                          QUrl)

from qgis.gui import QgsMapToolEmitPoint

from PyQt5.QtGui import QKeySequence

from qgis.PyQt.QtWidgets import QMessageBox

import webbrowser , requests , json

from . import Coordinate_Tool_data

epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg3857 = QgsCoordinateReferenceSystem('EPSG:3857')

class CoordinateToolShowOnMap(QgsMapToolEmitPoint):

    def __init__(self, CTool, iface):
        QgsMapToolEmitPoint.__init__(self, iface.mapCanvas())
        self.iface = iface
        self.CTool = CTool
        self.canvas = iface.mapCanvas()
        self.externalBasemapCnt = len(Coordinate_Tool_data.MAP_PROVIDERS)
        self.locale=QSettings()
        
    def activate(self):
        '''When activated set the cursor to a crosshair.'''
        self.canvas.setCursor(Qt.CrossCursor)
        # self.snapcolor = QgsSettings().value( "/qgis/digitizing/snap_color" , QColor( Qt.magenta ) )

    def deactivate(self):
        self.CTool.Delete_Marker_Shot(1000)
        action = self.action()
        if action:
            action.setChecked(False)
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.CTool.Delete_Marker()
            self.iface.actionPan().trigger()

    def canvasPressEvent(self, event):
        button = event.button()
        canvasCRS = self.canvas.mapSettings().destinationCrs()
        pt=self.toMapCoordinates(self.canvas.mouseLastXY())
        self.show(button,pt,canvasCRS)
        
    def show(self,button,pt,canvasCRS):
        self.mapProviderLeft = int(self.locale.value('locale/coordinate_tool/MapProvider', 0))
        self.mapProviderRight = int(self.locale.value('locale/coordinate_tool/MapProviderRight', 0))
        self.userMapProviders = self.locale.value('locale/coordinate_tool/UserMapProviders', 0)
        transform = QgsCoordinateTransform(canvasCRS, epsg4326, QgsProject.instance())
        pt4326 = transform.transform(pt.x(), pt.y())
        lat = pt4326.y()
        lon = pt4326.x()
        try:
            if button == Qt.RightButton:
                mapProvider = self.mapProviderRight
                placemark=int(self.locale.value('locale/coordinate_tool/checkBox_placemark_2', Qt.Checked))
                self.CTool.Draw_Marker(pt,3)
                self.mapZoom=int(self.locale.value('locale/coordinate_tool/zoomSpinBox_2', 15))
            elif button == Qt.LeftButton:
                mapProvider = self.mapProviderLeft
                placemark=int(self.locale.value('locale/coordinate_tool/checkBox_placemark_1', Qt.Checked))
                self.CTool.Draw_Marker(pt,2)
                self.mapZoom=int(self.locale.value('locale/coordinate_tool/zoomSpinBox_1', 15))
                
            if mapProvider >= self.externalBasemapCnt:
                # These are the optional user basemaps
                ms = self.userMapProviders[mapProvider - self.externalBasemapCnt][1]
                na = self.userMapProviders[mapProvider - self.externalBasemapCnt][0]
                
                ms = ms.replace('{lon}', str(lon))
                ms = ms.replace('{lat}', str(lat))
                
            else:
                if placemark == 2:
                    ms = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][2]
                    na = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][0]
                    # 카카오 로드뷰
                    if str(na) == '카카오 로드뷰(일반)' or str(na) == '카카오 로드뷰(위성)' or str(na) == '카카오 로드뷰(Hybrid)':
                        lon, lat, id = self.kakaoURL(pt,canvasCRS)
                        ms = ms.replace('{id}', str(id))
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                    # 네이버거리뷰
                    elif str(na) == '네이버 거리뷰(일반)' or str(na) == '네이버 거리뷰(위성)' or str(na) == '네이버 거리뷰(Hybrid)':
                        lon, lat, id = self.naverURL(pt,canvasCRS)
                        ms = ms.replace('{id}', str(id))
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                    else:
                    
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                else:
                    ms = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][1]
                    na = Coordinate_Tool_data.MAP_PROVIDERS[mapProvider][0]
                    # 카카오맵 로드뷰
                    if str(na) == '카카오 일반' or str(na) == '카카오 위성' or str(na) == '카카오 Hybrid'  or str(na) == '카카오 로드뷰(일반)' or str(na) == '카카오 로드뷰(위성)' or str(na) == '카카오 로드뷰(Hybrid)':
                        lon, lat, id = self.kakaoURL(pt,canvasCRS)
                        if str(na) == '카카오 로드뷰(일반)' or str(na) == '카카오 로드뷰(위성)' or str(na) == '카카오 로드뷰(Hybrid)':
                            ms = ms.replace('{id}', str(id))
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                    # 네이버거리뷰
                    elif str(na) == '네이버 거리뷰(일반)' or str(na) == '네이버 거리뷰(위성)' or str(na) == '네이버 거리뷰(Hybrid)':
                        lon, lat, id = self.naverURL(pt,canvasCRS)
                        ms = ms.replace('{id}', str(id))
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                    else:
                        ms = ms.replace('{lon}', str(lon))
                        ms = ms.replace('{lat}', str(lat))
                        
            if int(self.locale.value('locale/coordinate_tool/checkBox_placemark', Qt.Checked))==2:
                ms = ms.replace('{zoom}', str(self.mapZoom))
            elif str(na) == '카카오 일반' or str(na) == '카카오 위성' or str(na) == '카카오 Hybrid': # or str(na) == 'Kakao RoadView Satellite' or str(na) == 'Kakao RoadView Hybrid':
                ms = ms.replace('{zoom}',str(abs(self.mapZoom-19)))
            else:
                ms = ms.replace('{zoom}', str(self.mapZoom))
            url = QUrl(ms).toString()
            webbrowser.open(url, new = 0, autoraise=True)#, autoraise = False )
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushMessage("", "Viewing Coordinate %f , %f in external map" % (lat, lon), level=Qgis.Info, duration=5)
            self.CTool.Delete_Marker_Shot(2000)
            QTimer.singleShot(1000, self.remove)

        except Exception as e:
            print("show Error : ", e)
            QMessageBox.critical(self.iface.mainWindow(), "Error", "네이버 거리뷰 불러오기 실패")

    def kakaoURL(self,pt,canvasCRS):
        transform = QgsCoordinateTransform(canvasCRS, epsg5181, QgsProject.instance())
        pt5181 = transform.transform(pt.x(), pt.y())
        lat = float(pt5181.y())
        lon = float(pt5181.x())
        url = f'https://rv.map.kakao.com/roadview-search/v2/nodes?PX={float(lon)}&PY={float(lat)}&RAD=35&PAGE_SIZE=50&INPUT=wtm&TYPE=w&SERVICE=glpano'
        response = requests.get(url=url, verify=False)
        text = json.loads(response.text)
        data = text['street_view']['streetList'][0]
        id = data['id']
        lon=data['wcongx']
        lat=data['wcongy']
        return lon, lat, id

    def naverURL(self,pt,canvasCRS):
        transform = QgsCoordinateTransform(canvasCRS, epsg4326, QgsProject.instance())
        pt4326= transform.transform(pt.x(), pt.y())
        lon = pt4326.x()
        lat = pt4326.y()
        url = f'https://m.map.naver.com/viewer/panorama.naver?lng={float(lon)}&lat={float(lat)}'
        for i in range(10):

            response = requests.post(url, verify=False)
            if response.status_code == 200:
                try:
                    text= response.text
                    idx = text.find('"panorama"') + 12
                    end_idx = text[idx:].find("}")
                    pano = text[idx:idx + end_idx + 1]
                    pr = json.loads(pano)
                    transform = QgsCoordinateTransform(epsg4326, epsg3857, QgsProject.instance())
                    pt3857 = transform.transform(lon, lat)
                    lat = float(pt3857.y())
                    lon = float(pt3857.x())
                    id = pr["id"]
                    tilt =pr['tilt']
                    return lon, lat, id
                except Exception as e:
                    print("naverURL Error : ", e)
                    pass
            elif i == 9 :
                # QMessageBox.critical(self.iface.mainWindow(), "Error", "네이버 거리뷰 불러오기 실패")
                self.deactivate()
                return None
    def remove(self):
        self.iface.actionPan().trigger()