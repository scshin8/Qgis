'''
도형계산기 코드
'''
from qgis.PyQt import uic, QtWidgets

from qgis.core import   (Qgis,
                         QgsDefaultValue,
                         QgsExpression,
                         QgsExpressionContextUtils,
                         QgsExpressionContext,
                         QgsFields,
                         QgsUnitTypes,
                         QgsMapLayerType,
                         QgsCoordinateTransformContext,
                         QgsCoordinateReferenceSystem,
                         QgsWkbTypes,
                         QgsCoordinateTransform,
                         QgsField,
                         QgsPointXY,
                         QgsVectorLayer,
                         QgsGeometry)

from PyQt5.QtCore import (QSettings,
                          QVariant,
                          Qt)

from qgis.PyQt.QtWidgets import QMessageBox

from PyQt5.QtGui import QKeySequence

from PyQt5.QtWidgets import (QCompleter,
                             QDialogButtonBox,
                             QComboBox,
                             QCheckBox)

import os

crsNone = QgsCoordinateReferenceSystem()
epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
epsg5181 = QgsCoordinateReferenceSystem('EPSG:5181')
epsg4162 = QgsCoordinateReferenceSystem('EPSG:4162')
epsg4301 = QgsCoordinateReferenceSystem('EPSG:4301')
epsg4004 = QgsCoordinateReferenceSystem('EPSG:4004')
epsg3857 = QgsCoordinateReferenceSystem('EPSG:3857')
epsg5179 = QgsCoordinateReferenceSystem('EPSG:5179')

distance_units = (QgsUnitTypes.DistanceMeters,
                  QgsUnitTypes.DistanceKilometers,
                  QgsUnitTypes.DistanceFeet,
                  QgsUnitTypes.DistanceYards,
                  QgsUnitTypes.DistanceMiles,
                  QgsUnitTypes.DistanceNauticalMiles,
                  QgsUnitTypes.DistanceCentimeters,
                  QgsUnitTypes.DistanceMillimeters,
                  QgsUnitTypes.DistanceDegrees,
                  QgsUnitTypes.DistanceUnknownUnit)
area_units     = (QgsUnitTypes.AreaSquareMeters,
                  QgsUnitTypes.AreaSquareKilometers,
                  QgsUnitTypes.AreaSquareFeet,
                  QgsUnitTypes.AreaSquareYards,
                  QgsUnitTypes.AreaSquareMiles,
                  QgsUnitTypes.AreaHectares,
                  QgsUnitTypes.AreaAcres,
                  QgsUnitTypes.AreaSquareNauticalMiles,
                  QgsUnitTypes.AreaSquareCentimeters,
                  QgsUnitTypes.AreaSquareMillimeters,
                  QgsUnitTypes.AreaSquareDegrees,
                  QgsUnitTypes.AreaUnknownUnit) 

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'Coordinate_Tool_Geometry.ui'))

class CoordinateToolGeometry(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self,CTool,iface, parent=None):
        
        super(CoordinateToolGeometry, self).__init__(parent,Qt.WindowStaysOnTopHint)
        self.setupUi(self)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.CTool=CTool
        self.locale=QSettings()
        
        self.iface.currentLayerChanged["QgsMapLayer *"].connect(self.toggle)
        self.canvas.selectionChanged.connect(self.toggle)
        
        self.mMapLayerComboBox.layerChanged.connect(self.LayerChange)
        self.mMapLayerComboBox.setAllowEmptyLayer(True)
        self.mMapLayerComboBox.setCurrentIndex(0)
        
        self.Line_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_0,'Line','0'))
        self.Line_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_1,'Line','1'))
        self.Line_checkBox_2.stateChanged.connect(lambda : self.chkset(self.Line_checkBox_2,'Line','2'))
        self.Polygon_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_0,'Polygon','0'))
        self.Polygon_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_1,'Polygon','1'))
        self.Polygon_checkBox_2.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_2,'Polygon','2'))
        self.Polygon_checkBox_3.stateChanged.connect(lambda : self.chkset(self.Polygon_checkBox_3,'Polygon','3'))
        self.Point_checkBox_0.stateChanged.connect(lambda : self.chkset(self.Point_checkBox_0,'Point','0'))
        self.Point_checkBox_1.stateChanged.connect(lambda : self.chkset(self.Point_checkBox_1,'Point','1'))
        
        self.Transform_checkBox.stateChanged.connect(self.Transformchk)
        
        self.Line_UnitsComboBox_1.currentIndexChanged.connect(lambda : self.ComboBoxChange('1'))
        self.Line_UnitsComboBox_2.currentIndexChanged.connect(lambda : self.ComboBoxChange('2'))
        
        self.buttonBox.button(QDialogButtonBox.Ok).clicked.connect(self.run)
        self.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.close)
        
        self.setMouseTracking(True)
        
    def Transformchk(self): 
        if self.Transform_checkBox.isChecked():
            self.mQgsProjectionSelectionWidget.setEnabled(True)
            self.mQgsProjectionSelectionWidget.setCrs(self.layer.crs())
        else:
            self.mQgsProjectionSelectionWidget.setEnabled(False)
            self.mQgsProjectionSelectionWidget.setCrs(crsNone)
        
    def ComboBoxChange(self, idx):
        if idx=='1' :
            self.Line_FieldComboBox_1.setEditText(str(self.Line_UnitsComboBox_1.currentText()[:3])+'_X')
        if idx=='2' :
            self.Line_FieldComboBox_2.setEditText(str(self.Line_UnitsComboBox_2.currentText()[:3])+'_Y')
    
    def chkset(self, checkBox, obj, idx):
        val = True if checkBox.isChecked() else False
        if obj== 'Line':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)
            self.findChild(QComboBox,obj+'_UnitsComboBox_'+idx).setEnabled(val)
            if idx=='1' :
                self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEditText(str(self.Line_UnitsComboBox_1.currentText()[:3])+'_X')
            if idx=='2' :
                self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEditText(str(self.Line_UnitsComboBox_2.currentText()[:3])+'_Y')
                
        if obj== 'Polygon':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)
            if idx=='0' or idx=='1':
                self.findChild(QComboBox,obj+'_UnitsComboBox_'+idx).setEnabled(val)
        if obj== 'Point':
            self.findChild(QComboBox,obj+'_FieldComboBox_'+idx).setEnabled(val)

    def keyPressEvent(self, e):
        # ESC 누를때 이벤트 발생
        if e.matches(QKeySequence.Cancel):
            self.close()
        if e.matches(QKeySequence.InsertParagraphSeparator):
            self.run()
            
    def toggle(self):
        # 현재 레이어층 가져오기
        # layer = self.canvas.currentLayer()
        layer = self.mMapLayerComboBox.currentLayer()
        
        if layer and layer.type() == layer.VectorLayer:
            try:
                layer.editingStarted.disconnect(self.toggle)
            except:
                pass
            try:
                layer.editingStopped.disconnect(self.toggle)
            except:
                pass
            
            # 현재 도면층이 편집 가능하고 선택한 피쳐가 있는지 확인
            # 그리고 플러그인 버튼을 활성화할지 비활성화할지 결정합니다.
            # 도면층 편집 활성화
            # if layer.isEditable():
            if layer.selectedFeatureCount() > 0:
                self.checkBox_0.setEnabled(True)
                self.checkBox_0.setChecked(True)
            else:
                self.checkBox_0.setChecked(False)
                self.checkBox_0.setEnabled(False)
            layer.editingStopped.connect(self.toggle)
            # 도면층을 편집 비활성화
            # else:
            #     for i in range(len(self.actions)-1):
            #         self.actions[i].setEnabled(False)
            #     layer.editingStarted.connect(self.toggle)
        else:
            self.checkBox_0.setChecked(False)
            self.checkBox_0.setEnabled(False)
             
    def closeEvent(self,e):
        self.CTool.coordinateGeometry.setChecked(False)
        
    def showEvent(self,e):
        self.CTool.coordinateGeometry.setChecked(True)
        self.tab_1.setEnabled(False)
        self.tab_2.setEnabled(False)
        self.tab_3.setEnabled(False)
        self.Transform_checkBox.setEnabled(False)
        self.mQgsProjectionSelectionWidget.setEnabled(False)
        self.mMapLayerComboBox.setCurrentIndex(0)      
        for checkstate in self.findChildren(QCheckBox):
            checkstate.setChecked(False)

    def LayerChange(self):
        self.layer = self.mMapLayerComboBox.currentLayer()
        fields=[]
        # print(layer.type())
        # print(layer.geometryType())
        # print(layer .wkbType())
        # print(QgsWkbTypes.displayString(layer .wkbType()))
        
        for checkstate in self.findChildren(QCheckBox):
            checkstate.setChecked(False)
        
        if self.mMapLayerComboBox.currentIndex() > 0 and self.layer.type() == QgsMapLayerType.VectorLayer:
            self.laytype=self.layer.geometryType()
            self.Transform_checkBox.setEnabled(True)
            
            self.checkBox_0.setEnabled(True) if self.layer.selectedFeatureCount() > 0 else self.checkBox_0.setChecked(False)
            self.checkBox_0.setChecked(True) if self.layer.selectedFeatureCount() > 0 else self.checkBox_0.setChecked(False)
                
            for x in self.layer.fields():
                fields.append(x.name())
                
            self.tab_1.setEnabled(False)
            self.tab_2.setEnabled(False)
            self.tab_3.setEnabled(False)
                
            def combo(combobox):
                for ComboBox in combobox:
                    text = ComboBox.currentText()
                    ComboBox.clear()
                    ComboBox.addItems(fields)
                    ComboBox.setCompleter(QCompleter(fields))
                    ComboBox.setEditText(text)
                    
            if self.laytype ==  QgsWkbTypes.LineGeometry:
                self.tabWidget.setCurrentIndex(0)
                combobox=[self.Line_FieldComboBox_0,self.Line_FieldComboBox_1,self.Line_FieldComboBox_2]
                combo(combobox)
                self.tab_1.setEnabled(True) 
                
            elif self.laytype ==  QgsWkbTypes.PolygonGeometry:
                self.tabWidget.setCurrentIndex(1)
                combobox=[self.Polygon_FieldComboBox_0,self.Polygon_FieldComboBox_1,self.Polygon_FieldComboBox_2,self.Polygon_FieldComboBox_2]
                combo(combobox)
                self.tab_2.setEnabled(True)

            elif self.laytype ==  QgsWkbTypes.PointGeometry:
                self.tabWidget.setCurrentIndex(2)
                combobox=[self.Point_FieldComboBox_0,self.Point_FieldComboBox_1]
                combo(combobox)
                self.tab_3.setEnabled(True)
        else:
            self.Transform_checkBox.setEnabled(False)
            self.tabWidget.setCurrentIndex(0)
            self.tab_1.setEnabled(False)
            self.tab_2.setEnabled(False)
            self.tab_3.setEnabled(False)
    
    def run(self):
        self.layer.beginEditCommand("Feature Start Editing")
        self.layer.undoStack().beginMacro('도형계산기')
        addfieldnames=[]
        expression=[]
        TransCrs = self.mQgsProjectionSelectionWidget.crs().authid()
        TransCrs=f"'{TransCrs}'"
        Transform=self.Transform_checkBox.isChecked()
        setCrs = TransCrs if Transform else '@layer_crs'
        
        if self.laytype ==  QgsWkbTypes.LineGeometry:
            if self.Line_checkBox_0.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_0.currentText())
                expression.append('$length' if self.Line_UnitsComboBox_0.currentIndex()==0 else '$length/1000')
                
            if self.Line_checkBox_1.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_1.currentText())
                if self.Line_UnitsComboBox_1.currentIndex()==0:
                    expression.append(f'x(transform(start_point($geometry),@layer_crs,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==1:
                    expression.append(f'x(transform(line_interpolate_point(geometry:=$geometry,distance:=length(geom_from_wkt( geom_to_wkt( $geometry)))/2),@layer_crs ,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==2:
                    expression.append(f'x(transform(end_point($geometry),@layer_crs,{setCrs}))')
            if self.Line_checkBox_2.isChecked():
                addfieldnames.append(self.Line_FieldComboBox_2.currentText())
                if self.Line_UnitsComboBox_1.currentIndex()==0:
                    expression.append(f'y(transform(start_point($geometry),@layer_crs,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==1:
                    expression.append(f'y(transform(line_interpolate_point(geometry:=$geometry,distance:=length(geom_from_wkt( geom_to_wkt( $geometry)))/2),@layer_crs ,{setCrs}))')
                if self.Line_UnitsComboBox_1.currentIndex()==2:
                    expression.append(f'y(transform(start_point($geometry),@layer_crs,{setCrs}))')
        elif self.laytype ==  QgsWkbTypes.PolygonGeometry:
            if self.Polygon_checkBox_0.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_0.currentText())
                expression.append(('$area' if self.Polygon_UnitsComboBox_0.currentIndex()==0 else '$area/1000000'))
            if self.Polygon_checkBox_1.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_1.currentText())
                expression.append(('$Perimeter' if self.Polygon_UnitsComboBox_1.currentIndex()==0 else '$Perimeter/1000'))
            if self.Polygon_checkBox_2.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_2.currentText())
                expression.append(f'x( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
            if self.Polygon_checkBox_3.isChecked():
                addfieldnames.append(self.Polygon_FieldComboBox_3.currentText())
                expression.append(f'y( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
        elif self.laytype ==  QgsWkbTypes.PointGeometry:
            if self.Point_checkBox_0.isChecked():
                addfieldnames.append(self.Point_FieldComboBox_0.currentText())
                expression.append(f'x( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
            if self.Point_checkBox_1.isChecked():
                addfieldnames.append(self.Point_FieldComboBox_1.currentText())
                expression.append(f'y( transform( centroid( $geometry ),@layer_crs, {setCrs} ))')
        else:
            return 
        
        # 편집모드 활성화
        self.layer.startEditing()
        # 에러 유무 판별
        try:
            # 필드명과, 표현식 순환 
            for name , expre in zip(addfieldnames , expression):
                # 만들 필드명이 기존에 있는지 판별 있다면. 필드 번호 반환 없다면 -1 값 반환
                idx = self.layer.fields().indexOf(name)
                # 필드가 없다면
                if idx == -1: 
                    # 가상필드생성 체크 했다면.
                    if self.checkBox_1.isChecked():
                        # 가상필드 생성 및 표현식으로 값 넣기
                        self.layer.addExpressionField(expre,
                                        QgsField(name, QVariant.Double))
                        
                    # 가상필드생성 체크 안했다면.
                    else:
                        # 필드생성
                        self.layer.addAttribute(QgsField(name, QVariant.Double))
                        # 필드번호 찾기
                        idx = self.layer.fields().indexOf(name)
                        
                        context = QgsExpressionContext(QgsExpressionContextUtils.
                                                       globalProjectLayerScopes(self.layer))
                        # 객체 확인
                        features = (self.layer.selectedFeatures() # 선택한 객체만
                                    if self.checkBox_0.isChecked() # 선택한 객체만 체크가 되었다면
                                    else self.layer.getFeatures()) # 레이어의 모든 객체
                        
                        res = True
                        # 객체 순환
                        for f in features:
                            context.setFeature(f)
                            res &= self.layer.changeAttributeValue(f.id(), # 객체 ID
                                                                   idx,    # 필드번호
                                                                   QgsExpression(expre).evaluate(context), # 표현식으로 새로운 값 넣기
                                                                   None,
                                                                   True)
                        
                        # 기본값 으로 저장
                        #     default = QgsDefaultValue(expre, True)
                        #     self.layer.setDefaultValueDefinition(idx, default) 
                                       
                # 필드가 있다면
                else:
                    # 입력 필드가 가상 필드 일때 True
                    if self.layer.fields().fieldOrigin(idx) == QgsFields.OriginExpression:
                        # 표현식으로 새로운값 업데이트
                        self.layer.updateExpressionField(idx, expre)
                        
                    # 입력 필드가 일반 필드 일때 True
                    elif self.layer.fields().fieldOrigin(idx) in (
                            QgsFields.OriginProvider, QgsFields.OriginEdit):
                        
                        context = QgsExpressionContext(
                                QgsExpressionContextUtils.globalProjectLayerScopes(self.layer))
                        # 객체 확인
                        features = (self.layer.selectedFeatures() # 선택한 객체만
                                    if self.checkBox_0.isChecked() # 선택한 객체만 체크가 되었다면
                                    else self.layer.getFeatures()) # 레이어의 모든 객체
                        
                        res = True
                        # 객체 순환
                        for f in features:
                            context.setFeature(f)
                            res &= self.layer.changeAttributeValue(f.id(), # 객체 ID
                                                                   idx,    # 필드번호
                                                                   QgsExpression(expre).evaluate(context), # 표현식으로 새로운 값 넣기
                                                                   None,
                                                                   True)
                        # 기본값 으로 저장
                        #     default = QgsDefaultValue(expre, True)
                        #     self.layer.setDefaultValueDefinition(idx, default)    
            # 변환 완료        
            self.iface.messageBar().pushMessage("도형 계산기 처리 완료", level=Qgis.Info, duration=4)
        # 에러가 있다면
        except Exception as e:
            self.iface.messageBar().pushMessage(f"Error : {e}, '{name}' 필드 처리 불가", level=Qgis.Warning, duration=4)

        # self.layer.commitChanges()
        # self.layer.startEditing()
        # self.layer.endEditCommand()
        
        # self.layer.updateExtents()
        
        self.CTool.coordinateGeometry.setChecked(False)
        self.layer.undoStack().endMacro()
        self.layer.endEditCommand()