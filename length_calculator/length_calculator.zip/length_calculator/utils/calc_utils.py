import logging
import sqlite3
from typing import List, Optional, Tuple
from qgis.core import QgsVectorLayer

logger = logging.getLogger(__name__)


def find_layer_by_name(layers: List[QgsVectorLayer], name: str) -> Optional[QgsVectorLayer]:
    for layer in layers:
        if layer.name() == name:
            return layer
    return None


def get_gpkg_connection(layer: QgsVectorLayer) -> Optional[Tuple[str, str]]:
    source = layer.source()
    if '.gpkg' not in source:
        return None
    
    if '|' in source:
        parts = source.split('|')
        gpkg_path = parts[0]
        for part in parts[1:]:
            if part.startswith('layername='):
                table_name = part.split('=')[1]
                return gpkg_path, table_name
    
    return source, layer.name()


def execute_gpkg_query(gpkg_path: str, query: str, params: tuple = None) -> list:
    try:
        conn = sqlite3.connect(gpkg_path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        
        results = cursor.fetchall()
        conn.close()
        
        return results
        
    except Exception as e:
        logger.error(f"GPKG 쿼리 실행 오류: {str(e)}")
        return []


def create_gpkg_index(gpkg_path: str, table_name: str, fields: List[str]) -> bool:
    try:
        conn = sqlite3.connect(gpkg_path)
        cursor = conn.cursor()
        
        for field in fields:
            index_name = f"idx_{table_name}_{field}"
            try:
                cursor.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name}({field})")
            except:
                pass    
        conn.commit()
        conn.close()
        
        logger.info(f"GPKG 인덱스 생성 완료: {fields}")
        return True
        
    except Exception as e:
        logger.error(f"GPKG 인덱스 생성 오류: {str(e)}")
        return False


def optimize_gpkg(gpkg_path: str) -> bool:
    try:
        conn = sqlite3.connect(gpkg_path)
        cursor = conn.cursor()
        
        cursor.execute("ANALYZE")
        
        cursor.execute("VACUUM")
        
        conn.close()
        
        logger.info("GPKG 최적화 완료")
        return True
        
    except Exception as e:
        logger.error(f"GPKG 최적화 오류: {str(e)}")
        return False


def batch_update_gpkg(gpkg_path: str, table_name: str, updates: dict, batch_size: int = 1000) -> Tuple[bool, int]:
    try:
        conn = sqlite3.connect(gpkg_path)
        cursor = conn.cursor()
        
        updated_count = 0
        keys = list(updates.keys())
        
        for i in range(0, len(keys), batch_size):
            batch_keys = keys[i:i + batch_size]
            
            cursor.execute("BEGIN TRANSACTION")
            
            try:
                for key in batch_keys:
                    fields = updates[key]
                    
                    set_clauses = []
                    values = []
                    
                    for field, value in fields.items():
                        set_clauses.append(f"{field} = ?")
                        values.append(value)
                    
                    query = f"UPDATE {table_name} SET {', '.join(set_clauses)} WHERE key = ?"
                    values.append(key)
                    
                    cursor.execute(query, values)
                    updated_count += cursor.rowcount
                
                conn.commit()
                
            except Exception as e:
                conn.rollback()
                logger.error(f"배치 업데이트 오류: {str(e)}")
                raise
        
        conn.close()
        
        return True, updated_count
        
    except Exception as e:
        logger.error(f"GPKG 업데이트 오류: {str(e)}")
        return False, 0


class GPKGCache: 
    
    def __init__(self, cache_duration: int = 60):
        self._cache = {}
        self._timestamps = {}
        self.cache_duration = cache_duration
    
    def get(self, key: str):
        import time
        
        if key in self._cache:
            if time.time() - self._timestamps[key] < self.cache_duration:
                return self._cache[key]
            else:
                del self._cache[key]
                del self._timestamps[key]
        
        return None
    
    def set(self, key: str, value):
        import time
        
        self._cache[key] = value
        self._timestamps[key] = time.time()
    
    def clear(self):
        self._cache.clear()
        self._timestamps.clear()


gpkg_cache = GPKGCache()