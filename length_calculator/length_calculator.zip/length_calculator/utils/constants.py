from PyQt5.QtCore import QDate

OPERATOR_LIST = ["박상철","김민구","주예진","이나라","이정희","이담","김유림","김윤아","신현영","안유진","정다은","최선영","남해솔","이호평","김지의","박은비","성예은","강주영"]

PROGRESS_LIST = ["예정","입력","속성","측위","완료","LAS"]

REQ7 = ["key", "operator", "Progress", "st_date", "ed_date", "length", "ONEWAY", "조사거리Km", "Group", "Report"]

HOLIDAYS_2025 = [
    QDate(2025, 1, 1),   # 신정
    QDate(2025, 2, 1),   # 설날
    QDate(2025, 3, 1),   # 삼일절
    QDate(2025, 5, 5),   # 어린이날
    QDate(2025, 5, 6),   # 대체공휴일일
    QDate(2025, 5, 8),   # 석가탄신일
    QDate(2025, 6, 2),   # 대통령
    QDate(2025, 6, 6),   # 현충일
    QDate(2025, 8, 15),  # 광복절
    QDate(2025, 9, 10),  # 추석
    QDate(2025, 10, 3),  # 개천절
    QDate(2025, 10, 9),  # 한글날
    QDate(2025, 12, 25)  # 크리스마스
]
