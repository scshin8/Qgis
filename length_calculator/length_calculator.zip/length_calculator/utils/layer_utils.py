import os
import logging
from typing import List
from PyQt5.QtCore import Qt
from qgis.core import (
    Qgis, QgsProject, QgsVectorFileWriter, QgsVectorLayer,
    QgsFeature, QgsField, QgsFields, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsFeatureRequest
)

logger = logging.getLogger(__name__)


def get_field_mapping(layer, required_list: List[str]) -> dict:
    from PyQt5.QtCore import QSettings

    mapping = {}
    settings = QSettings()
    for req in required_list:
        if layer.fields().indexFromName(req) != -1:
            mapping[req] = req
        else:
            key = f"VariousTools/FieldMapping/{layer.name()}/{req}"
            user_mapping = settings.value(key, "")
            if user_mapping and layer.fields().indexFromName(user_mapping) != -1:
                mapping[req] = user_mapping
            else:
                mapping[req] = None
    return mapping


def process_attributes(layer: QgsVectorLayer, fields: QgsFields, process_func=None) -> List[dict]:
    result = []

    if not layer:
        return result

    for feature in layer.getFeatures():
        attrs = {}
        for field in fields:
            idx = layer.fields().indexFromName(field.name())
            if idx != -1:
                attrs[field.name()] = feature.attribute(field.name())
            else:
                attrs[field.name()] = None

        if process_func:
            attrs = process_func(attrs)

        if attrs:
            result.append(attrs)

    return result


def write_vector(layer: QgsVectorLayer, path: str, opts, only_sel: bool = False):
    if Qgis.QGIS_VERSION_INT >= 32600:
        return QgsVectorFileWriter.writeAsVectorFormatV2(layer, path, QgsProject.instance().transformContext(), opts)
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception as e:
            logger.error(f"Error removing file: {e}")
    return QgsVectorFileWriter.writeAsVectorFormat(layer, path, "utf-8", layer.crs(), opts.driverName,
                                                   onlySelected=only_sel)


def find_layer_by_name(layers: List[QgsVectorLayer], name: str) -> QgsVectorLayer:
    for lyr in layers:
        if lyr.name() == name:
            return lyr
    return None


def get_selected_features(layer: QgsVectorLayer, use_selection: bool = True) -> List[QgsFeature]:
    if use_selection:
        return list(layer.selectedFeatures())
    return list(layer.getFeatures())


def filter_features_by_condition(features: List[QgsFeature], field_name: str, values: List[str]) -> List[QgsFeature]:
    result = []
    for feature in features:
        value = str(feature.attribute(field_name) or "").strip()
        if not values or value in values:
            result.append(feature)
    return result


def filter_features_for_daegu(features: List[QgsFeature]) -> List[QgsFeature]:
    return [ft for ft in features if str(ft.attribute("Group")).strip() == '대구']


def calculate_feature_distance(feature: QgsFeature) -> tuple:
    try:
        length = float(feature.attribute("length") or 0)
        oneway = feature.attribute("ONEWAY")
        cs_km = float(feature.attribute("조사거리Km") or 0)

        mult = 2 if (oneway in (1, 2)) else 1
        dg_km = (length * mult) / 1000.0

        return dg_km, cs_km
    except (ValueError, TypeError):
        return 0.0, 0.0


def clone_layer_structure(layer: QgsVectorLayer, name: str) -> List[dict]:

    return []


def apply_attributes_to_layer(layer: QgsVectorLayer, attrs_list: List[dict]) -> bool:

    if not layer or not attrs_list:
        return False

    try:
        data_provider = layer.dataProvider()
        features = []

        for attrs in attrs_list:
            feature = QgsFeature()
            for field_name, value in attrs.items():
                idx = layer.fields().indexFromName(field_name)
                if idx != -1:
                    feature.setAttribute(idx, value)
            features.append(feature)

        return data_provider.addFeatures(features)
    except Exception as e:
        logger.error(f"속성 적용 중 오류: {str(e)}")
        return False