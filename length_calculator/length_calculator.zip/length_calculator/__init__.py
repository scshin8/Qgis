from __future__ import annotations
import os, logging
from typing import List, Optional
from PyQt5.QtCore import Qt, QSettings, QStandardPaths, QDate
from PyQt5.QtGui import QKeySequence, QColor, QIcon
from PyQt5.QtWidgets import (
    QAction, QDockWidget, QMessageBox, QInputDialog, QLineEdit, QWidget,
    QVBoxLayout, QHBoxLayout, QScrollArea, QFrame, QLabel, QPushButton, QComboBox, QTabWidget
)
from qgis.core import QgsProject, QgsVectorLayer, QgsApplication
from qgis.utils import iface

from .ui.progress_tab import ProgressTab
from .ui.filter_tab import build_tab_filter
from .ui.distance_tab import DistanceTab
from .ui.export_tab import build_tab_export
from .ui.update_tab import build_tab_update
from .utils.constants import OPERATOR_LIST

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class LengthCalculatorPlugin:
    PLUGIN_NAME = "length_calculator"
    REQUIRED_LAYER_NAME = "ING"
    DOCK_OBJECT_NAME = "LengthCalcDock"
    SETTINGS_SHORTCUT = f"{PLUGIN_NAME}/shortcut"

    def __init__(self, iface):
        self.iface = iface
        self.dock: Optional[QDockWidget] = None
        self.action_toggle: Optional[QAction] = None
        self.action_shortcut: Optional[QAction] = None
        self.layers: List[QgsVectorLayer] = []
        self.selected_operator = QSettings().value("VariousTools/SelectedOperator", "")

    def initGui(self) -> None:
        mw = self.iface.mainWindow()

        icon_path = os.path.join(os.path.dirname(__file__), "icons", "icon.png")

        self.action_toggle = QAction(QIcon(icon_path), "이것저것모음", mw)
        self.action_toggle.triggered.connect(self.toggle_dock)
        self.iface.addToolBarIcon(self.action_toggle)
        self.iface.addPluginToMenu(self.PLUGIN_NAME, self.action_toggle)

        self.action_shortcut = QAction("단축키 설정…", mw)
        self.action_shortcut.triggered.connect(self.configure_shortcut)
        self.iface.addPluginToMenu(self.PLUGIN_NAME, self.action_shortcut)

        self._apply_saved_shortcut()

        QgsProject.instance().layersAdded.connect(self._refresh_layers)
        QgsProject.instance().layersRemoved.connect(self._refresh_layers)

        try:
            self._refresh_layers()
        except Exception:
            pass

        app = QgsApplication.instance()
        app.setStyleSheet("*{font-family:'현대하모니L';}")

    def unload(self) -> None:
        if self.dock:
            self.iface.removeDockWidget(self.dock)
        if self.action_toggle:
            self.iface.removeToolBarIcon(self.action_toggle)
            self.iface.removePluginMenu(self.PLUGIN_NAME, self.action_toggle)
        if self.action_shortcut:
            self.iface.removePluginMenu(self.PLUGIN_NAME, self.action_shortcut)

    def build_dock(self) -> None:
        docs = QStandardPaths.writableLocation(QStandardPaths.DocumentsLocation)
        self.default_dir = os.path.join(docs, "민군데요")
        QSettings().setValue("VariousTools/default_dir", self.default_dir)
        os.makedirs(self.default_dir, exist_ok=True)

        main = QWidget()
        lay_main = QVBoxLayout(main)
        lay_main.setContentsMargins(0, 0, 0, 0)
        lay_main.setSpacing(0)

        operator_toolbar = QWidget()
        operator_layout = QHBoxLayout(operator_toolbar)
        operator_layout.setContentsMargins(5, 5, 5, 5)

        operator_label = QLabel("작업자")
        operator_label.setStyleSheet("font-weight: bold;")

        self.op_combo = QComboBox()
        self.op_combo.addItems(OPERATOR_LIST)
        self.op_combo.setStyleSheet("""
            QComboBox {
                padding: 4px;
                border: 1px solid #d0d0d0;
                border-radius: 3px;
                background-color: white;
                min-width: 100px;
            }
        """)

        self.btn_save_op = QPushButton("저장")
        self.btn_save_op.setStyleSheet("""
            QPushButton {
                background-color: #0078d7;
                color: white;
                border-radius: 3px;
                padding: 4px 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
        """)

        self.current_op_label = QLabel("")
        current_op = QSettings().value("VariousTools/SelectedOperator", "")
        if current_op:
            self.current_op_label.setText(current_op)
            idx = OPERATOR_LIST.index(current_op) if current_op in OPERATOR_LIST else 0
            self.op_combo.setCurrentIndex(idx)

        operator_layout.addWidget(operator_label)
        operator_layout.addWidget(self.op_combo)
        operator_layout.addWidget(self.btn_save_op)
        operator_layout.addWidget(self.current_op_label)
        operator_layout.addStretch()

        lay_main.addWidget(operator_toolbar)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        container = QWidget()
        lay_container = QVBoxLayout(container)
        lay_container.setContentsMargins(5, 5, 5, 5)
        lay_container.setSpacing(5)

        self.tab_widget = QTabWidget()
        self.tab_widget.setUsesScrollButtons(True)

        lay_container.addWidget(self.tab_widget)

        scroll_area.setWidget(container)
        lay_main.addWidget(scroll_area)

        self.layers = []
        try:
            self.layers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                           if hasattr(lyr, "type") and lyr.type() == lyr.VectorLayer]
        except Exception as e:
            logger.warning(f"로딩 중 오류: {str(e)}")

        names = [lyr.name() for lyr in self.layers]
        def_idx = next((i for i, n in enumerate(names) if n == "ING"), 0) if names else 0

        self.progress_tab = ProgressTab(main, layers=self.layers)
        self.distance_tab = DistanceTab()
        self.distance_tab.setLayerNames(names, def_idx)
        self.distance_tab.setLayerList(self.layers)
        self.filter_tab = build_tab_filter(names, def_idx, self.layers)
        self.export_tab = build_tab_export(names, def_idx, self.default_dir)
        self.update_tab = build_tab_update(names, def_idx)

        self.tab_widget.addTab(self.progress_tab, "진행")
        self.tab_widget.addTab(self.distance_tab, "계산")
        self.tab_widget.addTab(self.filter_tab, "필터링")
        self.tab_widget.addTab(self.export_tab, "내보내기")
        self.tab_widget.addTab(self.update_tab, "취합하기")

        colors = {
            0: "#4CAF50",  
            1: "#4CAF50",  
            2: "#2196F3",  
            3: "#FF9800",  
            4: "#FF9800",  
        }

        for i in range(self.tab_widget.count()):
            self.tab_widget.tabBar().setTabTextColor(i, QColor(colors[i]))

        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #cccccc;
                border-radius: 3px;
                top: -1px;
            }
            QTabBar::tab {
                background-color: #f0f0f0;
                border: 1px solid #cccccc;
                border-bottom-color: #cccccc;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                min-width: 8ex;
                padding: 6px 10px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: white;
                border-bottom-color: white;
                font-weight: bold;
            }
        """)

        self.btn_save_op.clicked.connect(self.save_operator)
        self.distance_tab.btn_dist.clicked.connect(self.do_distance)
        self.filter_tab.btn_filter.clicked.connect(self.do_filter)
        self.filter_tab.btn_clear.clicked.connect(self.do_clear_filter)
        self.export_tab.btn_exp.clicked.connect(self.do_export)
        self.export_tab.btn_null_check.clicked.connect(lambda: self.do_check_null())
        self.export_tab.btn_null_select.clicked.connect(lambda: self.do_select_null())
        self.export_tab.shp_btn.clicked.connect(
            lambda: self.browse_export_file(
                self.export_tab.shp_edit, "SHP저장", "Shapefile (*.shp)", ".shp"
            )
        )
        self.export_tab.gpkg_btn.clicked.connect(
            lambda: self.browse_export_file(
                self.export_tab.gpkg_edit, "GPKG저장", "GeoPackage (*.gpkg)", ".gpkg"
            )
        )
        self.update_tab.btn_upd.clicked.connect(self.do_update)
        self.update_tab.u_btn.clicked.connect(
            lambda: self.browse_open_file(
                self.update_tab.u_edit, "GPKG 열기", "GeoPackage (*.gpkg)"
            )
        )

        self.selected_operator = QSettings().value("VariousTools/SelectedOperator", "")
        self.progress_tab.update_operator_label()
        self.do_save_operator_as_default()

        self.dock = QDockWidget("이것저것모음", self.iface.mainWindow())
        self.dock.setObjectName(self.DOCK_OBJECT_NAME)
        self.dock.setFloating(True)
        self.dock.setAllowedAreas(Qt.AllDockWidgetAreas)
        self.dock.setWidget(main)

        self.dock.resize(360, 480)

        self.dock.setFeatures(
            QDockWidget.DockWidgetClosable |
            QDockWidget.DockWidgetMovable |
            QDockWidget.DockWidgetFloatable
        )

        main.setStyleSheet("""
            * { font-family: '현대하모니L'; font-size: 9pt; }
            QScrollBar:vertical {
                width: 10px;
                background: transparent;
            }
            QScrollBar::handle:vertical {
                background: #c0c0c0;
                border-radius: 5px;
                min-height: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QScrollBar:horizontal {
                height: 10px;
                background: transparent;
            }
            QScrollBar::handle:horizontal {
                background: #c0c0c0;
                border-radius: 5px;
                min-width: 20px;
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px;
            }
        """)

        self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dock)

    def toggle_dock(self) -> None:
        if self.dock and self.dock.isVisible():
            self.dock.close()
            return

        if not self.dock:
            self.build_dock()

        if self.dock.isFloating():
            self.dock.resize(600, 720)

        self.dock.show()
        self.dock.raise_()

    def _apply_saved_shortcut(self) -> None:
        seq = QSettings().value(self.SETTINGS_SHORTCUT, "")
        if self.action_toggle:
            self.action_toggle.setShortcut(QKeySequence(seq))

    def _refresh_layers(self, *args) -> None:
        try:
            self.layers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                           if hasattr(lyr, "type") and lyr.type() == lyr.VectorLayer]

            self.ing_layer = None
            for lyr in self.layers:
                if lyr.name() == "ING":
                    self.ing_layer = lyr
                    break

            if self.ing_layer and hasattr(self, "progress_tab"):
                self.progress_tab.layers = self.layers
        except Exception as e:
            logger.warning(f"레이어 새로고침 중 오류: {str(e)}")

    def configure_shortcut(self) -> None:
        current = QSettings().value(self.SETTINGS_SHORTCUT, "")
        seq, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "단축키 설정",
            "단축키 입력 (예: Ctrl+L):",
            QLineEdit.Normal,
            current
        )
        if ok:
            QSettings().setValue(self.SETTINGS_SHORTCUT, seq)
            self._apply_saved_shortcut()

    def do_save_operator_as_default(self) -> None:
        today = QDate.currentDate().toString("yyyy-MM-dd")
        op = self.selected_operator if self.selected_operator else OPERATOR_LIST[0]
        default_fname = f"{today}_{op}"

        if hasattr(self, "export_tab"):
            self.export_tab.base_fname.setText(default_fname)
            self.export_tab.shp_edit.setText(os.path.join(self.default_dir, default_fname + ".shp"))
            self.export_tab.gpkg_edit.setText(os.path.join(self.default_dir, default_fname + ".gpkg"))

    def do_filter(self) -> None:
        from .ui.filter_tab import apply_filter
        apply_filter(self.filter_tab, self.layers)
    
    def do_clear_filter(self) -> None:
        from .ui.filter_tab import clear_filter
        clear_filter(self.filter_tab, self.layers)

    def do_distance(self) -> None:
        self.distance_tab.calculate_distance()

    def do_export(self) -> None:
        from .ui.export_tab import export_layer
        export_layer(self.export_tab, self.layers, self.default_dir)

    def do_update(self) -> None:
        from .ui.update_tab import update_from_gpkg
        update_from_gpkg(self.update_tab, self.layers, self.progress_tab)

    def browse_export_file(self, edit_widget, title, filter_str, default_ext=None):
        from PyQt5.QtWidgets import QFileDialog

        current_path = edit_widget.text().strip()

        if not current_path or not os.path.exists(os.path.dirname(current_path)):
            base_name = self.export_tab.base_fname.text().strip()
            if not base_name:
                from PyQt5.QtCore import QDate
                today = QDate.currentDate().toString("yyyy-MM-dd")
                op = self.selected_operator if self.selected_operator else OPERATOR_LIST[0]
                base_name = f"{today}_{op}"

            current_path = os.path.join(self.default_dir, f"{base_name}{default_ext}")

        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), title, current_path, filter_str
        )

        if path:
            edit_widget.setText(path)

    def do_check_null(self) -> None:
        from .ui.export_tab import check_null_values_simple
        check_null_values_simple(self.export_tab, self.layers)

    def do_select_null(self) -> None:
        from .ui.export_tab import select_null_features_simple
        select_null_features_simple(self.export_tab, self.layers)

    def browse_open_file(self, edit_widget, title, filter_str):
        from PyQt5.QtWidgets import QFileDialog

        current = edit_widget.text().strip()
        if not current and hasattr(self, 'default_dir'):
            current = self.default_dir

        path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(), title, current, filter_str
        )
        if path:
            edit_widget.setText(path)

    def save_operator(self) -> None:
        from PyQt5.QtWidgets import QMessageBox

        op = self.op_combo.currentText()
        QSettings().setValue("VariousTools/SelectedOperator", op)
        self.current_op_label.setText(op)
        QMessageBox.information(None, "설정", f"주인이 '{op}'로 설정되었습니다")

        self.selected_operator = op
        self.progress_tab.update_operator_label()

        self.do_save_operator_as_default()


def classFactory(iface):
    return LengthCalculatorPlugin(iface)
