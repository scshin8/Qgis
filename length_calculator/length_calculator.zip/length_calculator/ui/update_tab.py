import os
import logging
from typing import List, Set
from PyQt5.QtCore import QDate, QDateTime, Qt
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QLineEdit, QMessageBox,
    QListWidget, QListWidgetItem, QGroupBox, QFrame, QDateEdit,
    QCheckBox
)
from qgis.core import QgsVectorLayer
from ..utils.constants import REQ7
from ..utils.layer_utils import get_field_mapping

logger = logging.getLogger(__name__)


def build_tab_update(names: List[str], def_idx: int) -> QWidget:
    tab = QWidget()
    main_layout = QVBoxLayout(tab)
    main_layout.setSpacing(10)
    main_layout.setContentsMargins(8, 10, 8, 10)
    
    # 기본 설정 프레임
    basic_frame = QFrame()
    basic_frame.setFrameShape(QFrame.StyledPanel)
    basic_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)
    
    basic_layout = QFormLayout(basic_frame)
    basic_layout.setContentsMargins(10, 10, 10, 10)
    basic_layout.setSpacing(8)
    
    u_layer = QComboBox()
    u_layer.addItems(names)
    u_layer.setCurrentIndex(def_idx)
    u_layer.setStyleSheet("""
        QComboBox {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-height: 22px;
        }
    """)
    basic_layout.addRow("레이어", u_layer)
    
    u_edit = QLineEdit()
    u_edit.setStyleSheet("""
        QLineEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
        }
    """)
    
    u_btn = QPushButton("...")
    u_btn.setFixedWidth(28)
    u_btn.setStyleSheet("""
        QPushButton {
            background-color: #f0f0f0;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
        }
        QPushButton:hover {
            background-color: #e0e0e0;
        }
    """)
    
    h_u = QHBoxLayout()
    h_u.addWidget(u_edit)
    h_u.addWidget(u_btn)
    basic_layout.addRow("GPKG", h_u)
    
    main_layout.addWidget(basic_frame)
    
    filter_frame = QFrame()
    filter_frame.setFrameShape(QFrame.StyledPanel)
    filter_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)
    
    filter_layout = QVBoxLayout(filter_frame)
    filter_layout.setSpacing(10)
    
    filter_title = QLabel("<b>취합 조건</b>")
    filter_title.setStyleSheet("font-size: 12px; margin-bottom: 5px;")
    filter_layout.addWidget(filter_title)
    
    condition_grid = QHBoxLayout()
    condition_grid.setSpacing(15)
    
    op_group = QGroupBox("OP 선택")
    op_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)
    
    op_layout = QVBoxLayout(op_group)
    op_layout.setContentsMargins(10, 15, 10, 10)
    op_layout.setSpacing(5)
    
    op_buttons = QHBoxLayout()
    op_select_all = QPushButton("전체 선택")
    op_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_select_none = QPushButton("전체 해제")
    op_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_load = QPushButton("값 불러오기")
    op_load.setStyleSheet("padding: 3px 5px; font-size: 10px; background-color: #28a745; color: white;")
    op_buttons.addWidget(op_select_all)
    op_buttons.addWidget(op_select_none)
    op_buttons.addWidget(op_load)
    op_layout.addLayout(op_buttons)
    

    op_list = QListWidget()
    op_list.setSelectionMode(QListWidget.MultiSelection)
    op_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 120px;
            max-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)
    op_layout.addWidget(op_list)
    
    pr_group = QGroupBox("진행상태 선택")
    pr_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)
    
    pr_layout = QVBoxLayout(pr_group)
    pr_layout.setContentsMargins(10, 15, 10, 10)
    pr_layout.setSpacing(5)
    
    pr_buttons = QHBoxLayout()
    pr_select_all = QPushButton("전체 선택")
    pr_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_select_none = QPushButton("전체 해제")
    pr_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_load = QPushButton("값 불러오기")
    pr_load.setStyleSheet("padding: 3px 5px; font-size: 10px; background-color: #28a745; color: white;")
    pr_buttons.addWidget(pr_select_all)
    pr_buttons.addWidget(pr_select_none)
    pr_buttons.addWidget(pr_load)
    pr_layout.addLayout(pr_buttons)
    
    pr_list = QListWidget()
    pr_list.setSelectionMode(QListWidget.MultiSelection)
    pr_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 120px;
            max-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)
    pr_layout.addWidget(pr_list)
    
    condition_grid.addWidget(op_group)
    condition_grid.addWidget(pr_group)
    filter_layout.addLayout(condition_grid)
    
    date_frame = QFrame()
    date_frame.setStyleSheet("""
        QFrame {
            background-color: #f0f0f0;
            border-radius: 3px;
            padding: 10px;
            margin-top: 10px;
        }
    """)
    date_layout = QVBoxLayout(date_frame)
    
    date_title = QLabel("<b>기간 설정</b>")
    date_title.setStyleSheet("font-size: 11px; margin-bottom: 5px;")
    date_layout.addWidget(date_title)
    
    date_grid = QGridLayout()
    date_grid.setColumnStretch(1, 1)
    date_grid.setColumnStretch(3, 1)
    
    chk_use_date = QCheckBox("날짜필터")
    chk_use_date.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    date_grid.addWidget(chk_use_date, 0, 0, 1, 4)
    
    start_date_label = QLabel("시작")
    start_date_label.setEnabled(False)
    start_date_edit = QDateEdit()
    start_date_edit.setCalendarPopup(True)
    start_date_edit.setDisplayFormat("yyyy-MM-dd")
    start_date_edit.setDate(QDate.currentDate().addDays(-30))
    start_date_edit.setEnabled(False)
    start_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    end_date_label = QLabel("종료")
    end_date_label.setEnabled(False)
    end_date_edit = QDateEdit()
    end_date_edit.setCalendarPopup(True)
    end_date_edit.setDisplayFormat("yyyy-MM-dd")
    end_date_edit.setDate(QDate.currentDate())
    end_date_edit.setEnabled(False)
    end_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    date_grid.addWidget(start_date_label, 1, 0)
    date_grid.addWidget(start_date_edit, 1, 1)
    date_grid.addWidget(end_date_label, 1, 2)
    date_grid.addWidget(end_date_edit, 1, 3)
    

    def toggle_date_controls(state):
        enabled = state == Qt.Checked
        start_date_label.setEnabled(enabled)
        start_date_edit.setEnabled(enabled)
        end_date_label.setEnabled(enabled)
        end_date_edit.setEnabled(enabled)
    
    chk_use_date.stateChanged.connect(toggle_date_controls)
    
    date_layout.addLayout(date_grid)
    filter_layout.addWidget(date_frame)
    
    main_layout.addWidget(filter_frame)
    
    btn_upd = QPushButton("취합")
    btn_upd.setMinimumHeight(40)
    btn_upd.setStyleSheet("""
        QPushButton {
            background-color: #0078d7;
            color: white;
            border-radius: 5px;
            padding: 10px 15px;
            font-weight: bold;
            font-size: 11pt;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
    """)
    
    main_layout.addWidget(btn_upd)
    main_layout.addStretch()
    

    def set_list_check_state(list_widget, state):
        for i in range(list_widget.count()):
            list_widget.item(i).setCheckState(state)
    

    def load_operator_click():
        load_operator_values(tab, layers)
    
    def load_progress_click():
        load_progress_values(tab, layers)
    
    op_select_all.clicked.connect(lambda: set_list_check_state(op_list, Qt.Checked))
    op_select_none.clicked.connect(lambda: set_list_check_state(op_list, Qt.Unchecked))
    pr_select_all.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Checked))
    pr_select_none.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Unchecked))
    op_load.clicked.connect(lambda: load_operator_click())
    pr_load.clicked.connect(lambda: load_progress_click())
    

    tab.u_layer = u_layer
    tab.u_edit = u_edit
    tab.u_btn = u_btn
    tab.btn_upd = btn_upd
    tab.op_list = op_list
    tab.pr_list = pr_list
    tab.op_load = op_load
    tab.pr_load = pr_load
    tab.chk_use_date = chk_use_date
    tab.start_date_edit = start_date_edit
    tab.end_date_edit = end_date_edit
    
    return tab


def load_unique_values(layer: QgsVectorLayer, field_name: str) -> Set[str]:
    unique_values = set()
    
    if not layer or not layer.isValid():
        return unique_values
    
    field_idx = layer.fields().indexFromName(field_name)
    if field_idx == -1:
        return unique_values
    
    for feature in layer.getFeatures():
        value = feature.attribute(field_name)
        if value is not None:
            unique_values.add(str(value).strip())
    
    return unique_values


def update_from_gpkg(update_tab, layers, progress_tab=None):
    lyr_idx = update_tab.u_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요")
        return

    lyr = layers[lyr_idx]
    
    was_editable = lyr.isEditable()
    
    if was_editable:
        logger.info("레이어저장")
        lyr.commitChanges()
    
    if lyr.isEditable():
        logger.info("편집모드종료")
        lyr.rollBack()
    
    p = update_tab.u_edit.text().strip()
    if not p or not os.path.exists(p):
        QMessageBox.warning(None, "오류", "GPKG 경로 오류")
        return

    import sqlite3
    try:
        conn = sqlite3.connect(p)
        cursor = conn.cursor()
        cursor.execute("SELECT table_name FROM gpkg_contents WHERE data_type='features'")
        available_layers = [row[0] for row in cursor.fetchall()]
        conn.close()
    except Exception as e:
        QMessageBox.critical(None, "오류", f"GPKG 파일 읽기 오류 {str(e)}")
        return

    if not available_layers:
        QMessageBox.critical(None, "오류", "GPKG 파일에 사용 가능한 레이어가 없습니다")
        return

    uri = f"{p}|layername={available_layers[0]}"
    gpkg_layer = QgsVectorLayer(uri, "upd_layer", "ogr")
    
    if not gpkg_layer.isValid():
        QMessageBox.critical(None, "오류", f"레이어 로드 실패 {available_layers[0]}")
        return

    if gpkg_layer.fields().indexFromName("key") == -1:
        QMessageBox.critical(None, "오류", "GPKG 'key' 필드 없음")
        return

    mapping = get_field_mapping(gpkg_layer, REQ7[1:])
    missing = [req for req, mapped in mapping.items() if mapped is None]
    if missing:
        QMessageBox.critical(None, "오류", "필드 누락" + ", ".join(missing))
        return

    selected_operators = []
    for i in range(update_tab.op_list.count()):
        item = update_tab.op_list.item(i)
        if item.checkState() == Qt.Checked:
            selected_operators.append(item.text())
    
    selected_progress = []
    for i in range(update_tab.pr_list.count()):
        item = update_tab.pr_list.item(i)
        if item.checkState() == Qt.Checked:
            selected_progress.append(item.text())
    
    use_date_filter = update_tab.chk_use_date.isChecked()
    start_date = update_tab.start_date_edit.date() if use_date_filter else None
    end_date = update_tab.end_date_edit.date() if use_date_filter else None
    
    updates = {}
    for f in gpkg_layer.getFeatures():
        key = str(f["key"]).strip()
        if key:
            updates[key] = {k: f[mapping[k]] for k in REQ7[1:]}

    if not updates:
        QMessageBox.warning(None, "취합", "데이터 없음")
        return

    attr_updates = {}
    matched_count = 0
    
    for ft in lyr.getFeatures():
        k = str(ft["key"]).strip()
        if k not in updates:
            continue
        
        operator = str(ft.attribute("operator") or "").strip()
        progress = str(ft.attribute("Progress") or "").strip()
        
        if selected_operators and operator not in selected_operators:
            continue
        
        if selected_progress and progress not in selected_progress:
            continue
        
        if use_date_filter:
            st_date_val = ft.attribute("st_date")
            ed_date_val = ft.attribute("ed_date")
            
            if isinstance(st_date_val, QDate):
                ft_st_date = st_date_val
            elif hasattr(st_date_val, 'date'):
                ft_st_date = st_date_val.date()
            else:
                ft_st_date = QDate.fromString(str(st_date_val), "yyyy-MM-dd")
            
            if isinstance(ed_date_val, QDate):
                ft_ed_date = ed_date_val
            elif hasattr(ed_date_val, 'date'):
                ft_ed_date = ed_date_val.date()
            else:
                ft_ed_date = QDate.fromString(str(ed_date_val), "yyyy-MM-dd")
            
            if ft_st_date.isValid() and ft_st_date < start_date:
                continue
            if ft_ed_date.isValid() and ft_ed_date > end_date:
                continue
        
        c_map = {}
        for req in REQ7[1:]:
            idx = lyr.fields().indexFromName(req)
            new_val = updates[k][req]
            
            if req == "Group":
                if new_val is None or str(new_val).strip() == "":
                    new_val = "대구"
            
            if lyr.fields()[idx].typeName().lower().startswith("date"):
                if isinstance(new_val, QDate):
                    new_val = new_val.toString("yyyy-MM-dd")
                elif isinstance(new_val, QDateTime):
                    new_val = new_val.date().toString("yyyy-MM-dd")
                elif new_val in (None, ""):
                    new_val = ""
                else:
                    qd = QDate.fromString(str(new_val), "yyyy-MM-dd")
                    if not qd.isValid():
                        qd = QDate.fromString(str(new_val), "yyyyMMdd")
                    new_val = qd.toString("yyyy-MM-dd") if qd.isValid() else ""
            
            c_map[idx] = new_val
        
        if c_map:
            attr_updates[ft.id()] = c_map
            matched_count += 1

    if not attr_updates:
        QMessageBox.warning(None, "업데이트", "조건에 맞는 피처가 없음")
        return

    conditions_str = []
    if selected_operators:
        conditions_str.append(f"작업자: {', '.join(selected_operators)}")
    if selected_progress:
        conditions_str.append(f"진행상태: {', '.join(selected_progress)}")
    if use_date_filter:
        conditions_str.append(f"기간: {start_date.toString('yyyy-MM-dd')} ~ {end_date.toString('yyyy-MM-dd')}")
    
    conditions_text = "\n".join(conditions_str) if conditions_str else "조건 없음"
    
    reply = QMessageBox.question(
        None, 
        "업데이트 확인",
        f"다음 조건에 해당하는 {matched_count}개 피처를 업데이트합니다:\n\n"
        f"{conditions_text}\n\n"
        f"계속하시겠습니까?",
        QMessageBox.Yes | QMessageBox.No,
        QMessageBox.No
    )
    
    if reply == QMessageBox.No:
        if was_editable:
            lyr.startEditing()
        return

    ok = lyr.dataProvider().changeAttributeValues(attr_updates)
    if ok:
        lyr.triggerRepaint()
        QMessageBox.information(None, "업데이트 완료", 
                              f"조건에 맞는 {matched_count}개 피처가 성공적으로 업데이트되었습니다")
    else:
        QMessageBox.critical(None, "오류", "속성 업데이트 실패")
    
    if was_editable:
        logger.info("이전 편집 모드 상태 복원")
        lyr.startEditing()


def load_operator_values(update_tab, layers):
    lyr_idx = update_tab.u_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요")
        return
    
    lyr = layers[lyr_idx]
    unique_values = load_unique_values(lyr, "operator")
    
    update_tab.op_list.clear()
    for value in sorted(unique_values):
        if value: 
            item = QListWidgetItem(value)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            update_tab.op_list.addItem(item)
    
    QMessageBox.information(None, "값 불러오기", f"{len(unique_values)}명 불러왔음")


def load_progress_values(update_tab, layers):
    """현재 레이어에서 Progress 유일값 불러오기"""
    lyr_idx = update_tab.u_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요.")
        return
    
    lyr = layers[lyr_idx]
    unique_values = load_unique_values(lyr, "Progress")
    
    update_tab.pr_list.clear()
    for value in sorted(unique_values):
        if value:
            item = QListWidgetItem(value)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            update_tab.pr_list.addItem(item)
    
    QMessageBox.information(None, "값 불러오기", f"{len(unique_values)}개 상태를 불러왔음")