from typing import List, Optional
import sqlite3
import logging
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QPushButton, QComboBox, QListWidget, QListWidgetItem,
    QCheckBox, QGroupBox, QFrame, QMessageBox, QDateEdit
)
from qgis.core import QgsVectorLayer, QgsExpression
from ..utils.constants import OPERATOR_LIST, PROGRESS_LIST

logger = logging.getLogger(__name__)


def build_tab_filter(names: List[str], def_idx: int, layers: List[QgsVectorLayer]) -> QWidget:
    tab = QWidget()
    main_layout = QVBoxLayout(tab)
    main_layout.setSpacing(10)
    main_layout.setContentsMargins(8, 10, 8, 10)

    layer_frame = QFrame()
    layer_frame.setFrameShape(QFrame.StyledPanel)
    layer_frame.setFrameShadow(QFrame.Raised)
    layer_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)

    layer_layout = QFormLayout(layer_frame)
    layer_layout.setContentsMargins(10, 10, 10, 10)
    layer_layout.setSpacing(8)

    f_layer = QComboBox()
    f_layer.addItems(names)
    f_layer.setCurrentIndex(def_idx)
    f_layer.setStyleSheet("""
        QComboBox {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-height: 22px;
        }
        QComboBox::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)

    f_sel = QCheckBox("선택한 객체만 필터링")
    f_sel.setChecked(True) 
    f_sel.setStyleSheet("""
        QCheckBox {
            padding: 2px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    f_daegu = QCheckBox("대구만 선택")
    f_daegu.setChecked(True) 
    f_daegu.setStyleSheet("""
        QCheckBox {
            padding: 2px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    use_sql_filter = QCheckBox("많이선택모드")
    use_sql_filter.setStyleSheet("""
        QCheckBox {
            padding: 2px;
            color: #0078d7;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    use_sql_filter.setToolTip(
        "많이선택했을때만효과적임일반적인건같음"
    )

    layer_layout.addRow("<b>레이어 선택:</b>", f_layer)
    layer_layout.addRow("", f_sel)
    layer_layout.addRow("", f_daegu)
    layer_layout.addRow("", use_sql_filter)

    main_layout.addWidget(layer_frame)

    filter_frame = QFrame()
    filter_frame.setFrameShape(QFrame.StyledPanel)
    filter_frame.setFrameShadow(QFrame.Raised)
    filter_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)

    filter_layout = QVBoxLayout(filter_frame)
    filter_layout.setSpacing(10)

    filter_title = QLabel("<b>필터링 조건</b>")
    filter_title.setStyleSheet("font-size: 12px; margin-bottom: 5px;")
    filter_layout.addWidget(filter_title)

    filter_grid = QHBoxLayout()
    filter_grid.setSpacing(15)

    op_group = QGroupBox("op")
    op_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)

    op_layout = QVBoxLayout(op_group)
    op_layout.setContentsMargins(10, 15, 10, 10)
    op_layout.setSpacing(5)

    op_buttons = QHBoxLayout()
    op_select_all = QPushButton("전체 선택")
    op_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_select_none = QPushButton("전체 해제")
    op_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_buttons.addWidget(op_select_all)
    op_buttons.addWidget(op_select_none)
    op_layout.addLayout(op_buttons)

    op_list = QListWidget()
    op_list.setSelectionMode(QListWidget.MultiSelection)
    op_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)

    for op in OPERATOR_LIST:
        it = QListWidgetItem(op)
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Unchecked)
        op_list.addItem(it)

    op_layout.addWidget(op_list)

    pr_group = QGroupBox("Progress")
    pr_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)

    pr_layout = QVBoxLayout(pr_group)
    pr_layout.setContentsMargins(10, 15, 10, 10)
    pr_layout.setSpacing(5)

    pr_buttons = QHBoxLayout()
    pr_select_all = QPushButton("전체 선택")
    pr_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_select_none = QPushButton("전체 해제")
    pr_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_buttons.addWidget(pr_select_all)
    pr_buttons.addWidget(pr_select_none)
    pr_layout.addLayout(pr_buttons)

    pr_list = QListWidget()
    pr_list.setSelectionMode(QListWidget.MultiSelection)
    pr_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)

    for pr in PROGRESS_LIST:
        it = QListWidgetItem(pr)
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Unchecked)
        pr_list.addItem(it)

    pr_layout.addWidget(pr_list)

    filter_grid.addWidget(op_group)
    filter_grid.addWidget(pr_group)
    filter_layout.addLayout(filter_grid)

    date_frame = QFrame()
    date_frame.setStyleSheet("""
        QFrame {
            background-color: #f0f0f0;
            border-radius: 3px;
            padding: 10px;
            margin-top: 10px;
        }
    """)
    date_layout = QVBoxLayout(date_frame)
    
    date_title = QLabel("<b>날짜 필터</b>")
    date_title.setStyleSheet("font-size: 11px; margin-bottom: 5px;")
    date_layout.addWidget(date_title)
    
    date_grid = QHBoxLayout()
    
    chk_start_date = QCheckBox("시작일")
    chk_start_date.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    
    start_date_edit = QDateEdit()
    start_date_edit.setCalendarPopup(True)
    start_date_edit.setDisplayFormat("yyyy-MM-dd")
    start_date_edit.setDate(QDate.currentDate())
    start_date_edit.setEnabled(False)
    start_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    chk_end_date = QCheckBox("종료일")
    chk_end_date.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    
    end_date_edit = QDateEdit()
    end_date_edit.setCalendarPopup(True)
    end_date_edit.setDisplayFormat("yyyy-MM-dd")
    end_date_edit.setDate(QDate.currentDate())
    end_date_edit.setEnabled(False)
    end_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    chk_start_date.stateChanged.connect(lambda s: start_date_edit.setEnabled(s == Qt.Checked))
    chk_end_date.stateChanged.connect(lambda s: end_date_edit.setEnabled(s == Qt.Checked))
    
    date_grid.addWidget(chk_start_date)
    date_grid.addWidget(start_date_edit)
    date_grid.addSpacing(20)
    date_grid.addWidget(chk_end_date)
    date_grid.addWidget(end_date_edit)
    date_grid.addStretch()
    
    date_layout.addLayout(date_grid)
    filter_layout.addWidget(date_frame)

    main_layout.addWidget(filter_frame)

    button_layout = QHBoxLayout()
    
    btn_filter = QPushButton("필터 적용")
    btn_filter.setMinimumHeight(35)
    btn_filter.setStyleSheet("""
        QPushButton {
            background-color: #0078d7;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
    """)
    
    btn_clear = QPushButton("필터 초기화")
    btn_clear.setMinimumHeight(35)
    btn_clear.setStyleSheet("""
        QPushButton {
            background-color: #dc3545;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #c82333;
        }
        QPushButton:pressed {
            background-color: #bd2130;
        }
    """)
    
    button_layout.addWidget(btn_filter)
    button_layout.addWidget(btn_clear)
    
    main_layout.addLayout(button_layout)
    main_layout.addStretch()

    op_select_all.clicked.connect(lambda: set_list_check_state(op_list, Qt.Checked))
    op_select_none.clicked.connect(lambda: set_list_check_state(op_list, Qt.Unchecked))
    pr_select_all.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Checked))
    pr_select_none.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Unchecked))

    tab.op_list = op_list
    tab.pr_list = pr_list
    tab.f_layer = f_layer
    tab.f_sel = f_sel
    tab.f_daegu = f_daegu
    tab.btn_filter = btn_filter
    tab.btn_clear = btn_clear
    tab.chk_start_date = chk_start_date
    tab.start_date_edit = start_date_edit
    tab.chk_end_date = chk_end_date
    tab.end_date_edit = end_date_edit
    tab.use_sql_filter = use_sql_filter

    return tab


def set_list_check_state(list_widget, state):
    for i in range(list_widget.count()):
        list_widget.item(i).setCheckState(state)


def apply_filter(filter_tab, layers):
    lyr = layers[filter_tab.f_layer.currentIndex()]
    
    use_fast_filter = filter_tab.use_sql_filter.isChecked()
    
    if use_fast_filter:
        apply_filter_fast(filter_tab, lyr)
    else:
        apply_filter_standard(filter_tab, lyr)


def apply_filter_fast(filter_tab, lyr):
    import time
    from qgis.core import QgsExpression, QgsFeatureRequest
    
    start_time = time.time()
    
    conditions = []
    
    if filter_tab.f_daegu.isChecked():
        conditions.append("\"Group\" = '대구'")
    
    op_sel = [filter_tab.op_list.item(i).text() for i in range(filter_tab.op_list.count())
              if filter_tab.op_list.item(i).checkState() == Qt.Checked]
    
    if op_sel:
        op_list = "','".join(op_sel)
        conditions.append(f"\"operator\" IN ('{op_list}')")
    
    pr_sel = [filter_tab.pr_list.item(i).text() for i in range(filter_tab.pr_list.count())
              if filter_tab.pr_list.item(i).checkState() == Qt.Checked]
    
    if pr_sel:
        pr_list = "','".join(pr_sel)
        conditions.append(f"\"Progress\" IN ('{pr_list}')")
    
    if filter_tab.chk_start_date.isChecked():
        start_date = filter_tab.start_date_edit.date().toString("yyyy-MM-dd")
        conditions.append(f"\"st_date\" >= '{start_date}'")
    
    if filter_tab.chk_end_date.isChecked():
        end_date = filter_tab.end_date_edit.date().toString("yyyy-MM-dd")
        conditions.append(f"\"ed_date\" <= '{end_date}'")
    
    if not conditions:
        lyr.removeSelection()
        QMessageBox.information(None, "필터 적용", "필터 조건이 없습니다.")
        return
    
    where_clause = " AND ".join(conditions)
    
    if filter_tab.f_sel.isChecked() and lyr.selectedFeatureCount() > 0:
        selected_ids = [f.id() for f in lyr.selectedFeatures()]
        
        expression = QgsExpression(where_clause)
        request = QgsFeatureRequest(expression)
        request.setFlags(QgsFeatureRequest.NoGeometry)
        
        filtered_ids = []
        for feature in lyr.getFeatures(request):
            if feature.id() in selected_ids:
                filtered_ids.append(feature.id())
        
        lyr.removeSelection()
        if filtered_ids:
            lyr.selectByIds(filtered_ids)
    else:
        expression = QgsExpression(where_clause)
        request = QgsFeatureRequest(expression)
        request.setFlags(QgsFeatureRequest.NoGeometry)
        

        feature_ids = [f.id() for f in lyr.getFeatures(request)]
        
        lyr.removeSelection()
        if feature_ids:
            lyr.selectByIds(feature_ids)
    
    selected_count = lyr.selectedFeatureCount()
    elapsed = time.time() - start_time
    
    if selected_count > 0:
        QMessageBox.information(None, "필터완료", 
                              f"총 {selected_count:,}개 객체가 선택되었습니다")
    else:
        QMessageBox.information(None, "필터 결과", "조건에 맞는 객체가 없습니다.")


def apply_filter_standard(filter_tab, lyr):
    if filter_tab.f_sel.isChecked():
        feats = list(lyr.selectedFeatures())
    else:
        feats = list(lyr.getFeatures())

    if filter_tab.f_daegu.isChecked():
        feats = [ft for ft in feats if str(ft.attribute("Group") or "").strip() == "대구"]

    op_sel = [filter_tab.op_list.item(i).text() for i in range(filter_tab.op_list.count())
              if filter_tab.op_list.item(i).checkState() == Qt.Checked]
    
    pr_sel = [filter_tab.pr_list.item(i).text() for i in range(filter_tab.pr_list.count())
              if filter_tab.pr_list.item(i).checkState() == Qt.Checked]

    use_start_date = filter_tab.chk_start_date.isChecked()
    use_end_date = filter_tab.chk_end_date.isChecked()
    start_date = filter_tab.start_date_edit.date() if use_start_date else None
    end_date = filter_tab.end_date_edit.date() if use_end_date else None

    sel_ids = []

    for ft in feats:
        op_val = str(ft.attribute("operator") or "").strip()
        prog_val = str(ft.attribute("Progress") or "").strip()

        operator_match = not op_sel or op_val in op_sel
        progress_match = not pr_sel or prog_val in pr_sel

        date_match = True
        
        if use_start_date or use_end_date:
            st_date_val = ft.attribute("st_date")
            ed_date_val = ft.attribute("ed_date")
            
            if isinstance(st_date_val, QDate):
                ft_st_date = st_date_val
            elif hasattr(st_date_val, 'date'):
                ft_st_date = st_date_val.date()
            else:
                ft_st_date = QDate.fromString(str(st_date_val), "yyyy-MM-dd")
            
            if isinstance(ed_date_val, QDate):
                ft_ed_date = ed_date_val
            elif hasattr(ed_date_val, 'date'):
                ft_ed_date = ed_date_val.date()
            else:
                ft_ed_date = QDate.fromString(str(ed_date_val), "yyyy-MM-dd")
            
            if use_start_date and ft_st_date.isValid():
                if ft_st_date < start_date:
                    date_match = False
            
            if use_end_date and ft_ed_date.isValid():
                if ft_ed_date > end_date:
                    date_match = False

        if operator_match and progress_match and date_match:
            sel_ids.append(ft.id())

    lyr.removeSelection()
    if sel_ids:
        lyr.selectByIds(sel_ids)

    QMessageBox.information(None, "필터 적용 완료", f"총 {len(sel_ids)}개 객체가 선택되었습니다.")


def clear_filter(filter_tab, layers):
    lyr = layers[filter_tab.f_layer.currentIndex()]
    
    if lyr.subsetString():
        lyr.setSubsetString("")
    
    if lyr.selectedFeatureCount() > 0:
        lyr.removeSelection()
    
    set_list_check_state(filter_tab.op_list, Qt.Unchecked)
    set_list_check_state(filter_tab.pr_list, Qt.Unchecked)
    filter_tab.chk_start_date.setChecked(False)
    filter_tab.chk_end_date.setChecked(False)
    filter_tab.f_sel.setChecked(True)
    filter_tab.f_daegu.setChecked(True)
    filter_tab.use_sql_filter.setChecked(False)
    
    QMessageBox.information(None, "필터 초기화", 
                          "모든 필터가 초기화되었습니다.\n"
                          "- 선택 해제\n"
                          "- 필터 조건 초기화\n"
                          "- 기본값 복원")


def get_gpkg_info(layer):
    source = layer.source()
    
    logger.info(f"레이어 소스: {source}")
    logger.info(f"데이터 제공자: {layer.dataProvider().name()}")
    
    gpkg_path = None
    table_name = None
    
    if '|' in source:
        parts = source.split('|')
        gpkg_path = parts[0]
        
        for part in parts[1:]:
            if part.startswith('layername='):
                table_name = part.split('=')[1]
                break
            elif part.startswith('layer='):
                table_name = part.split('=')[1]
                break
    else:
        gpkg_path = source
    
    if gpkg_path and gpkg_path.lower().endswith('.gpkg'):
        try:
            conn = sqlite3.connect(gpkg_path)
            cursor = conn.cursor()
            
            cursor.execute("SELECT table_name FROM gpkg_contents WHERE data_type='features'")
            tables = [row[0] for row in cursor.fetchall()]
            
            logger.info(f"GPKG 내 테이블 목록: {tables}")
            
            if not table_name or table_name not in tables:
                layer_name = layer.name()
                if layer_name in tables:
                    table_name = layer_name
                elif 'ing' in tables:
                    table_name = 'ing'
                elif 'ING' in tables:
                    table_name = 'ING'
                elif tables:
                    table_name = tables[0]
                    logger.warning(f"테이블명을 찾을 수 없어 첫 번째 테이블 사용: {table_name}")
            
            conn.close()
            
        except Exception as e:
            logger.error(f"GPKG 테이블 확인 오류: {str(e)}")
            if not table_name:
                table_name = layer.name()
    
    if not table_name:
        table_name = layer.name()
    
    logger.info(f"최종 GPKG 경로: {gpkg_path}, 테이블명: {table_name}")
    return gpkg_path, table_name