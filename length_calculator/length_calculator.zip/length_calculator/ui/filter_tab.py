from typing import List, Optional
import sqlite3
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QPushButton, QComboBox, QListWidget, QListWidgetItem,
    QCheckBox, QGroupBox, QFrame, QMessageBox, QDateEdit
)
from qgis.core import QgsVectorLayer, QgsExpression
from ..utils.constants import OPERATOR_LIST, PROGRESS_LIST


def build_tab_filter(names: List[str], def_idx: int, layers: List[QgsVectorLayer]) -> QWidget:
    tab = QWidget()
    main_layout = QVBoxLayout(tab)
    main_layout.setSpacing(10)
    main_layout.setContentsMargins(8, 10, 8, 10)

    # 레이어 선택 프레임
    layer_frame = QFrame()
    layer_frame.setFrameShape(QFrame.StyledPanel)
    layer_frame.setFrameShadow(QFrame.Raised)
    layer_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)

    layer_layout = QFormLayout(layer_frame)
    layer_layout.setContentsMargins(10, 10, 10, 10)
    layer_layout.setSpacing(8)

    f_layer = QComboBox()
    f_layer.addItems(names)
    f_layer.setCurrentIndex(def_idx)
    f_layer.setStyleSheet("""
        QComboBox {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-height: 22px;
        }
        QComboBox::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)

    f_sel = QCheckBox("선택한 객체만 필터링")
    f_sel.setChecked(True) # 기본값 설정
    f_sel.setStyleSheet("""
        QCheckBox {
            padding: 2px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    f_daegu = QCheckBox("대구만 선택")
    f_daegu.setChecked(True) # 기본값 설정
    f_daegu.setStyleSheet("""
        QCheckBox {
            padding: 2px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    # GPKG 최적화 옵션
    use_sql_filter = QCheckBox("쿼리")
    use_sql_filter.setStyleSheet("""
        QCheckBox {
            padding: 2px;
            color: #0078d7;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    layer_layout.addRow("<b>레이어 선택:</b>", f_layer)
    layer_layout.addRow("", f_sel)
    layer_layout.addRow("", f_daegu)
    layer_layout.addRow("", use_sql_filter)

    main_layout.addWidget(layer_frame)

    # 필터링 조건 프레임
    filter_frame = QFrame()
    filter_frame.setFrameShape(QFrame.StyledPanel)
    filter_frame.setFrameShadow(QFrame.Raised)
    filter_frame.setStyleSheet("""
        QFrame {
            background-color: #f8f8f8;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
            padding: 8px;
        }
    """)

    filter_layout = QVBoxLayout(filter_frame)
    filter_layout.setSpacing(10)

    filter_title = QLabel("<b>필터링</b>")
    filter_title.setStyleSheet("font-size: 12px; margin-bottom: 5px;")
    filter_layout.addWidget(filter_title)

    filter_grid = QHBoxLayout()
    filter_grid.setSpacing(15)

    # 작업자 그룹
    op_group = QGroupBox("작업자")
    op_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)

    op_layout = QVBoxLayout(op_group)
    op_layout.setContentsMargins(10, 15, 10, 10)
    op_layout.setSpacing(5)

    op_buttons = QHBoxLayout()
    op_select_all = QPushButton("전체 선택")
    op_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_select_none = QPushButton("전체 해제")
    op_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    op_buttons.addWidget(op_select_all)
    op_buttons.addWidget(op_select_none)
    op_layout.addLayout(op_buttons)

    op_list = QListWidget()
    op_list.setSelectionMode(QListWidget.MultiSelection)
    op_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)

    for op in OPERATOR_LIST:
        it = QListWidgetItem(op)
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Unchecked)
        op_list.addItem(it)

    op_layout.addWidget(op_list)

    # 진행 상태 그룹
    pr_group = QGroupBox("진행")
    pr_group.setStyleSheet("""
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 3px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
    """)

    pr_layout = QVBoxLayout(pr_group)
    pr_layout.setContentsMargins(10, 15, 10, 10)
    pr_layout.setSpacing(5)

    pr_buttons = QHBoxLayout()
    pr_select_all = QPushButton("전체 선택")
    pr_select_all.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_select_none = QPushButton("전체 해제")
    pr_select_none.setStyleSheet("padding: 3px 5px; font-size: 10px;")
    pr_buttons.addWidget(pr_select_all)
    pr_buttons.addWidget(pr_select_none)
    pr_layout.addLayout(pr_buttons)

    pr_list = QListWidget()
    pr_list.setSelectionMode(QListWidget.MultiSelection)
    pr_list.setStyleSheet("""
        QListWidget {
            border: 1px solid #ddd;
            border-radius: 3px;
            background-color: white;
            min-height: 150px;
        }
        QListWidget::item {
            padding: 3px 5px;
        }
        QListWidget::item:selected {
            background-color: #e6f2ff;
            color: black;
        }
    """)

    for pr in PROGRESS_LIST:
        it = QListWidgetItem(pr)
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(Qt.Unchecked)
        pr_list.addItem(it)

    pr_layout.addWidget(pr_list)

    filter_grid.addWidget(op_group)
    filter_grid.addWidget(pr_group)
    filter_layout.addLayout(filter_grid)

    # 날짜 필터 섹션 추가
    date_frame = QFrame()
    date_frame.setStyleSheet("""
        QFrame {
            background-color: #f0f0f0;
            border-radius: 3px;
            padding: 10px;
            margin-top: 10px;
        }
    """)
    date_layout = QVBoxLayout(date_frame)
    
    date_title = QLabel("<b>날짜 필터</b>")
    date_title.setStyleSheet("font-size: 11px; margin-bottom: 5px;")
    date_layout.addWidget(date_title)
    
    date_grid = QHBoxLayout()
    
    # 시작일 체크박스와 DateEdit
    chk_start_date = QCheckBox("시작일")
    chk_start_date.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    
    start_date_edit = QDateEdit()
    start_date_edit.setCalendarPopup(True)
    start_date_edit.setDisplayFormat("yyyy-MM-dd")
    start_date_edit.setDate(QDate.currentDate())
    start_date_edit.setEnabled(False)
    start_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    # 종료일 체크박스와 DateEdit
    chk_end_date = QCheckBox("종료일")
    chk_end_date.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)
    
    end_date_edit = QDateEdit()
    end_date_edit.setCalendarPopup(True)
    end_date_edit.setDisplayFormat("yyyy-MM-dd")
    end_date_edit.setDate(QDate.currentDate())
    end_date_edit.setEnabled(False)
    end_date_edit.setStyleSheet("""
        QDateEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-width: 100px;
        }
        QDateEdit::drop-down {
            width: 20px;
            border-left: 1px solid #d0d0d0;
        }
    """)
    
    # 체크박스 상태에 따라 DateEdit 활성화/비활성화
    chk_start_date.stateChanged.connect(lambda s: start_date_edit.setEnabled(s == Qt.Checked))
    chk_end_date.stateChanged.connect(lambda s: end_date_edit.setEnabled(s == Qt.Checked))
    
    date_grid.addWidget(chk_start_date)
    date_grid.addWidget(start_date_edit)
    date_grid.addSpacing(20)
    date_grid.addWidget(chk_end_date)
    date_grid.addWidget(end_date_edit)
    date_grid.addStretch()
    
    date_layout.addLayout(date_grid)
    filter_layout.addWidget(date_frame)

    main_layout.addWidget(filter_frame)

    # 필터 적용 버튼
    button_layout = QHBoxLayout()
    
    btn_filter = QPushButton("필터 적용")
    btn_filter.setMinimumHeight(35)
    btn_filter.setStyleSheet("""
        QPushButton {
            background-color: #0078d7;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
    """)
    
    btn_clear = QPushButton("필터 초기화")
    btn_clear.setMinimumHeight(35)
    btn_clear.setStyleSheet("""
        QPushButton {
            background-color: #dc3545;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #c82333;
        }
        QPushButton:pressed {
            background-color: #bd2130;
        }
    """)
    
    button_layout.addWidget(btn_filter)
    button_layout.addWidget(btn_clear)
    
    main_layout.addLayout(button_layout)
    main_layout.addStretch()

    # 이벤트 연결
    op_select_all.clicked.connect(lambda: set_list_check_state(op_list, Qt.Checked))
    op_select_none.clicked.connect(lambda: set_list_check_state(op_list, Qt.Unchecked))
    pr_select_all.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Checked))
    pr_select_none.clicked.connect(lambda: set_list_check_state(pr_list, Qt.Unchecked))

    # 탭 속성 설정
    tab.op_list = op_list
    tab.pr_list = pr_list
    tab.f_layer = f_layer
    tab.f_sel = f_sel
    tab.f_daegu = f_daegu
    tab.btn_filter = btn_filter
    tab.btn_clear = btn_clear
    tab.chk_start_date = chk_start_date
    tab.start_date_edit = start_date_edit
    tab.chk_end_date = chk_end_date
    tab.end_date_edit = end_date_edit
    tab.use_sql_filter = use_sql_filter

    return tab


def set_list_check_state(list_widget, state):
    """리스트 위젯의 모든 항목 체크 상태 설정"""
    for i in range(list_widget.count()):
        list_widget.item(i).setCheckState(state)


def apply_filter(filter_tab, layers):
    """필터 적용 - GPKG 최적화 버전"""
    lyr = layers[filter_tab.f_layer.currentIndex()]
    
    # SQL 필터 사용 여부 확인
    use_sql = filter_tab.use_sql_filter.isChecked() and '.gpkg' in lyr.source()
    
    if use_sql:
        apply_filter_sql(filter_tab, lyr)
    else:
        apply_filter_standard(filter_tab, lyr)


def apply_filter_sql(filter_tab, lyr):
    """SQL WHERE 절을 사용한 고속 필터링 (GPKG)"""
    conditions = []
    
    # 대구만 선택
    if filter_tab.f_daegu.isChecked():
        conditions.append("\"Group\" = '대구'")
    
    # 작업자 필터
    op_sel = [filter_tab.op_list.item(i).text() for i in range(filter_tab.op_list.count())
              if filter_tab.op_list.item(i).checkState() == Qt.Checked]
    
    if op_sel:
        op_list = "','".join(op_sel)
        conditions.append(f"\"operator\" IN ('{op_list}')")
    
    # 진행상태 필터
    pr_sel = [filter_tab.pr_list.item(i).text() for i in range(filter_tab.pr_list.count())
              if filter_tab.pr_list.item(i).checkState() == Qt.Checked]
    
    if pr_sel:
        pr_list = "','".join(pr_sel)
        conditions.append(f"\"Progress\" IN ('{pr_list}')")
    
    # 날짜 필터
    if filter_tab.chk_start_date.isChecked():
        start_date = filter_tab.start_date_edit.date().toString("yyyy-MM-dd")
        conditions.append(f"\"st_date\" >= '{start_date}'")
    
    if filter_tab.chk_end_date.isChecked():
        end_date = filter_tab.end_date_edit.date().toString("yyyy-MM-dd")
        conditions.append(f"\"ed_date\" <= '{end_date}'")
    
    # WHERE 절 구성
    if conditions:
        where_clause = " AND ".join(conditions)
        
        # 기존 필터와 결합
        if filter_tab.f_sel.isChecked() and lyr.selectedFeatureCount() > 0:
            # 선택된 객체의 ID 목록 가져오기
            selected_ids = [str(f.id()) for f in lyr.selectedFeatures()]
            id_list = ",".join(selected_ids)
            where_clause = f"fid IN ({id_list}) AND ({where_clause})"
    else:
        where_clause = ""
    
    # 서브셋 스트링 적용 (매우 빠름)
    lyr.setSubsetString(where_clause)
    
    # 직접 쿼리로 결과 개수 확인
    if where_clause:
        gpkg_path, table_name = get_gpkg_info(lyr)
        conn = sqlite3.connect(gpkg_path)
        cursor = conn.cursor()
        
        cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE {where_clause}")
        count = cursor.fetchone()[0]
        
        conn.close()
        
        QMessageBox.information(None, "필터 적용 완료", 
                              f"SQL 필터 적용됨\n총 {count:,}개 객체가 필터링되었습니다.")
    else:
        lyr.setSubsetString("")
        QMessageBox.information(None, "필터 초기화", "모든 필터가 제거되었습니다.")


def apply_filter_standard(filter_tab, lyr):
    """기존 방식 필터링 (Shapefile 등)"""
    # 선택된 객체 또는 전체 객체 가져오기
    if filter_tab.f_sel.isChecked():
        feats = list(lyr.selectedFeatures())
    else:
        feats = list(lyr.getFeatures())

    # 대구만 선택 필터
    if filter_tab.f_daegu.isChecked():
        feats = [ft for ft in feats if str(ft.attribute("Group") or "").strip() == "대구"]

    # 선택된 작업자 목록
    op_sel = [filter_tab.op_list.item(i).text() for i in range(filter_tab.op_list.count())
              if filter_tab.op_list.item(i).checkState() == Qt.Checked]

    # 선택된 진행상태 목록
    pr_sel = [filter_tab.pr_list.item(i).text() for i in range(filter_tab.pr_list.count())
              if filter_tab.pr_list.item(i).checkState() == Qt.Checked]

    # 날짜 필터 설정
    use_start_date = filter_tab.chk_start_date.isChecked()
    use_end_date = filter_tab.chk_end_date.isChecked()
    start_date = filter_tab.start_date_edit.date() if use_start_date else None
    end_date = filter_tab.end_date_edit.date() if use_end_date else None

    # 필터링
    sel_ids = []

    for ft in feats:
        op_val = str(ft.attribute("operator") or "").strip()
        prog_val = str(ft.attribute("Progress") or "").strip()

        # 작업자 필터
        operator_match = not op_sel or op_val in op_sel
        # 진행상태 필터
        progress_match = not pr_sel or prog_val in pr_sel

        # 날짜 필터 (시작일 및 종료일 포함)
        date_match = True
        
        if use_start_date or use_end_date:
            # st_date 또는 ed_date 값 가져오기
            st_date_val = ft.attribute("st_date")
            ed_date_val = ft.attribute("ed_date")
            
            # QDate 객체로 변환
            if isinstance(st_date_val, QDate):
                ft_st_date = st_date_val
            elif hasattr(st_date_val, 'date'):
                ft_st_date = st_date_val.date()
            else:
                ft_st_date = QDate.fromString(str(st_date_val), "yyyy-MM-dd")
            
            if isinstance(ed_date_val, QDate):
                ft_ed_date = ed_date_val
            elif hasattr(ed_date_val, 'date'):
                ft_ed_date = ed_date_val.date()
            else:
                ft_ed_date = QDate.fromString(str(ed_date_val), "yyyy-MM-dd")
            
            # 시작일 필터 (inclusive)
            if use_start_date and ft_st_date.isValid():
                if ft_st_date < start_date:
                    date_match = False
            
            # 종료일 필터 (inclusive)
            if use_end_date and ft_ed_date.isValid():
                if ft_ed_date > end_date:
                    date_match = False

        # 모든 조건을 만족하는 경우만 선택
        if operator_match and progress_match and date_match:
            sel_ids.append(ft.id())

    # 레이어에서 선택 적용
    lyr.removeSelection()
    if sel_ids:
        lyr.selectByIds(sel_ids)

    QMessageBox.information(None, "필터 적용 완료", f"총 {len(sel_ids)}개 객체가 선택되었습니다.")


def clear_filter(filter_tab, layers):
    """필터 초기화"""
    lyr = layers[filter_tab.f_layer.currentIndex()]
    
    # 서브셋 스트링 제거
    lyr.setSubsetString("")
    
    # 선택 해제
    lyr.removeSelection()
    
    # UI 초기화
    set_list_check_state(filter_tab.op_list, Qt.Unchecked)
    set_list_check_state(filter_tab.pr_list, Qt.Unchecked)
    filter_tab.chk_start_date.setChecked(False)
    filter_tab.chk_end_date.setChecked(False)
    filter_tab.f_sel.setChecked(True)
    filter_tab.f_daegu.setChecked(True)
    
    QMessageBox.information(None, "필터 초기화", "모든 필터가 초기화되었습니다.")


def get_gpkg_info(layer):
    """레이어에서 GPKG 경로와 테이블명 추출"""
    source = layer.source()
    if '|' in source:
        parts = source.split('|')
        gpkg_path = parts[0]
        for part in parts[1:]:
            if part.startswith('layername='):
                table_name = part.split('=')[1]
                return gpkg_path, table_name
    return source, layer.name()