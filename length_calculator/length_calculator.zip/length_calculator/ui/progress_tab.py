from __future__ import annotations
import logging
import sqlite3
import time
from typing import Optional, List, Dict, Tuple
from PyQt5.QtCore import Qt, QSettings, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFrame, QProgressBar
)
from qgis.core import QgsVectorLayer
from ..utils.layer_utils import find_layer_by_name

logger = logging.getLogger(__name__)


class CalculationThread(QThread):
    """백그라운드 계산을 위한 스레드"""
    result_ready = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, gpkg_path: str, table_name: str, operator: str):
        super().__init__()
        self.gpkg_path = gpkg_path
        self.table_name = table_name
        self.operator = operator
    
    def run(self):
        try:
            result = self._calculate_stats()
            self.result_ready.emit(result)
        except Exception as e:
            self.error_occurred.emit(str(e))
    
    def _calculate_stats(self) -> dict:
        """GPKG에서 직접 통계 계산"""
        conn = sqlite3.connect(self.gpkg_path)
        cursor = conn.cursor()
        
        try:
            # 한 번의 쿼리로 모든 통계 계산 (초고속)
            query = """
            SELECT 
                -- 전체 모집단
                SUM(CASE WHEN road_kind IN ('8','9') AND IFNULL(작업분류, '') != '해안' 
                    THEN CAST(length AS REAL) ELSE 0 END) as total_population,
                
                -- Progress별 집계
                SUM(CASE WHEN Progress = '입력' THEN CAST(length AS REAL) ELSE 0 END) as input_len,
                SUM(CASE WHEN Progress = '속성' THEN CAST(length AS REAL) ELSE 0 END) as attr_len,
                SUM(CASE WHEN Progress = '측위' THEN CAST(length AS REAL) ELSE 0 END) as position_len,
                SUM(CASE WHEN Progress = '완료' THEN CAST(length AS REAL) ELSE 0 END) as complete_len,
                SUM(CASE WHEN Progress = 'LAS' THEN CAST(length AS REAL) ELSE 0 END) as las_len,
                
                -- 개인 진행상황
                SUM(CASE WHEN operator = ? AND Progress IN ('입력', '속성', '측위') 
                    THEN CAST(length AS REAL) ELSE 0 END) as personal_progress,
                
                -- 추가 통계
                COUNT(DISTINCT operator) as operator_count,
                COUNT(*) as total_features
            FROM {}
            """.format(self.table_name)
            
            cursor.execute(query, (self.operator,))
            result = cursor.fetchone()
            
            return {
                'total_population': result[0] or 0,
                'progress_by_type': {
                    '입력': result[1] or 0,
                    '속성': result[2] or 0,
                    '측위': result[3] or 0,
                    '완료': result[4] or 0,
                    'LAS': result[5] or 0
                },
                'personal_progress': result[6] or 0,
                'operator_count': result[7] or 0,
                'total_features': result[8] or 0
            }
            
        finally:
            conn.close()


class ProgressTab(QWidget):
    def __init__(self, parent: Optional[QWidget] = None, layers: Optional[List[QgsVectorLayer]] = None):
        super().__init__(parent)
        self.parent = parent
        self.layers = layers or []
        self.calculation_thread = None
        self.cache = {}
        self.cache_timestamp = 0
        self.cache_duration = 30 # 30초 캐시
        self.init_ui()

    def init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(8, 10, 8, 10)

        # 작업자 표시
        self.operator_label = QLabel("현재 작업자: (미설정)")
        self.operator_label.setStyleSheet("font-size: 11pt; font-weight: bold; color: #0078d7;")
        layout.addWidget(self.operator_label)

        # 진행상황 프레임
        progress_frame = QFrame()
        progress_frame.setFrameShape(QFrame.StyledPanel)
        progress_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f8f8;
                border-radius: 5px;
                border: 1px solid #e0e0e0;
                padding: 10px;
            }
        """)
        progress_layout = QVBoxLayout(progress_frame)

        # 전체 모집단 거리
        self.total_population_label = QLabel("전체 모집단 거리: 계산 필요")
        self.total_population_label.setStyleSheet("font-size: 10pt; font-weight: bold;")
        progress_layout.addWidget(self.total_population_label)

        # 전체 진행상황 총합
        self.total_progress_label = QLabel("전체 진행상황: 계산 필요")
        self.total_progress_label.setStyleSheet("font-size: 10pt; margin-top: 10px;")
        progress_layout.addWidget(self.total_progress_label)

        # 진행상황 상세
        self.progress_detail_label = QLabel("")
        self.progress_detail_label.setStyleSheet("font-size: 9pt; color: #555; margin-left: 20px;")
        self.progress_detail_label.setWordWrap(True)
        progress_layout.addWidget(self.progress_detail_label)

        # 진행률 표시
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #ddd;
                border-radius: 4px;
                text-align: center;
                height: 24px;
                background-color: white;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                border-radius: 3px;
            }
        """)
        self.progress_bar.setFormat("%p%")
        progress_layout.addWidget(self.progress_bar)

        # 성능 정보
        self.performance_label = QLabel("")
        self.performance_label.setStyleSheet("font-size: 8pt; color: #888; text-align: right;")
        progress_layout.addWidget(self.performance_label)

        layout.addWidget(progress_frame)

        # 개인 진행상황 프레임
        personal_frame = QFrame()
        personal_frame.setFrameShape(QFrame.StyledPanel)
        personal_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f8f8;
                border-radius: 5px;
                border: 1px solid #e0e0e0;
                padding: 10px;
            }
        """)
        personal_layout = QVBoxLayout(personal_frame)

        personal_title = QLabel("개인 진행상황")
        personal_title.setStyleSheet("font-weight: bold; font-size: 11pt; margin-bottom: 5px;")
        personal_layout.addWidget(personal_title)

        # 개인 진행상황
        self.personal_progress_label = QLabel("개인 진행상황: 계산 필요")
        self.personal_progress_label.setStyleSheet("font-size: 10pt;")
        personal_layout.addWidget(self.personal_progress_label)

        # 남은 거리
        self.remaining_distance_label = QLabel("남은 거리: 계산 필요")
        self.remaining_distance_label.setStyleSheet("font-size: 10pt; color: #dc3545; font-weight: bold;")
        personal_layout.addWidget(self.remaining_distance_label)

        layout.addWidget(personal_frame)

        # 버튼
        button_layout = QHBoxLayout()
        self.btn_calculate = QPushButton("진행상황 계산")
        self.btn_calculate.setMinimumHeight(36)
        self.btn_calculate.setStyleSheet("""
            QPushButton {
                background-color: #0078d7;
                color: white;
                border-radius: 4px;
                padding: 8px 12px;
                font-weight: bold;
                font-size: 10pt;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
            QPushButton:pressed {
                background-color: #005a9e;
            }
        """)
        button_layout.addWidget(self.btn_calculate)
        layout.addLayout(button_layout)

        layout.addStretch()

        # 이벤트 연결
        self.btn_calculate.clicked.connect(self.calculate_progress)
        self.update_operator_label()

    def update_operator_label(self) -> None:
        """작업자 레이블 업데이트"""
        op = QSettings().value("VariousTools/SelectedOperator", "")
        if op:
            self.operator_label.setText(f"현재 작업자: {op}")
        else:
            self.operator_label.setText("현재 작업자: (미설정)")

    def get_gpkg_info(self, layer: QgsVectorLayer) -> Tuple[str, str]:
        """레이어에서 GPKG 경로와 테이블명 추출"""
        source = layer.source()
        if '|' in source:
            parts = source.split('|')
            gpkg_path = parts[0]
            # layername= 찾기
            for part in parts[1:]:
                if part.startswith('layername='):
                    table_name = part.split('=')[1]
                    return gpkg_path, table_name
        return source, layer.name()

    def calculate_progress(self) -> None:
        """진행상황 계산 - GPKG 최적화 버전"""
        start_time = time.time()
        
        # 캐시 확인
        if self.cache and (time.time() - self.cache_timestamp) < self.cache_duration:
            self._update_ui_from_cache()
            self.performance_label.setText("캐시에서 로드 (0.001초)")
            return
        
        try:
            ing_layer = find_layer_by_name(self.layers, "ING")
            if not ing_layer:
                logger.warning("ING 레이어가 없습니다.")
                self.total_population_label.setText("전체 모집단 거리: ING 레이어 없음")
                self.progress_bar.setValue(0)
                return

            # 현재 작업자
            current_operator = QSettings().value("VariousTools/SelectedOperator", "")
            if not current_operator:
                logger.warning("작업자가 설정되지 않았습니다.")
                self.personal_progress_label.setText("개인 진행상황: 작업자 미설정")

            # GPKG 정보 추출
            gpkg_path, table_name = self.get_gpkg_info(ing_layer)
            
            # GPKG 파일인 경우 최적화된 방식 사용
            if gpkg_path.endswith('.gpkg'):
                self._calculate_gpkg_optimized(gpkg_path, table_name, current_operator)
            else:
                # 기존 방식 (Shapefile 등)
                self._calculate_standard(ing_layer, current_operator)
            
            # 성능 측정
            elapsed = time.time() - start_time
            self.performance_label.setText(f"계산 시간: {elapsed:.3f}초")

        except Exception as e:
            logger.error(f"진행상황 계산 중 오류: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            self.total_population_label.setText("계산 중 오류 발생")

    def _calculate_gpkg_optimized(self, gpkg_path: str, table_name: str, operator: str) -> None:
        """GPKG 직접 쿼리를 통한 초고속 계산"""
        if self.calculation_thread and self.calculation_thread.isRunning():
            return
        
        self.btn_calculate.setEnabled(False)
        self.btn_calculate.setText("계산 중...")
        
        # 백그라운드 스레드에서 계산
        self.calculation_thread = CalculationThread(gpkg_path, table_name, operator)
        self.calculation_thread.result_ready.connect(self._on_calculation_complete)
        self.calculation_thread.error_occurred.connect(self._on_calculation_error)
        self.calculation_thread.start()

    def _on_calculation_complete(self, result: dict) -> None:
        """계산 완료 시 UI 업데이트"""
        self.cache = result
        self.cache_timestamp = time.time()
        
        # UI 업데이트
        total_population = result['total_population']
        progress_by_type = result['progress_by_type']
        personal_progress = result['personal_progress']
        
        # 전체 진행상황
        total_progress = sum(progress_by_type.values())
        remaining_distance = total_population - total_progress
        
        # 라벨 업데이트
        self.total_population_label.setText(f"전체 모집단 거리: {total_population:,.2f} km")
        self.total_progress_label.setText(f"전체 진행상황: {total_progress:,.2f} km")
        
        # Progress별 상세 (0이 아닌 것만)
        detail_parts = []
        for progress_type, value in progress_by_type.items():
            if value > 0:
                percentage = (value / total_population * 100) if total_population > 0 else 0
                detail_parts.append(f"{progress_type}: {value:,.2f} km ({percentage:.1f}%)")
        
        self.progress_detail_label.setText(" | ".join(detail_parts))
        
        # 개인 정보
        self.personal_progress_label.setText(f"개인 진행상황: {personal_progress:,.2f} km")
        self.remaining_distance_label.setText(f"남은 거리: {remaining_distance:,.2f} km")
        
        # 진행률
        if total_population > 0:
            progress_percentage = (total_progress / total_population) * 100
            self.progress_bar.setValue(int(progress_percentage))
        else:
            self.progress_bar.setValue(0)
        
        # 추가 정보
        self.performance_label.setText(
            f"피처 수: {result['total_features']:,} | "
            f"작업자 수: {result['operator_count']}"
        )
        
        self.btn_calculate.setEnabled(True)
        self.btn_calculate.setText("진행상황 계산")

    def _on_calculation_error(self, error_msg: str) -> None:
        """계산 오류 시 처리"""
        logger.error(f"계산 오류: {error_msg}")
        self.total_population_label.setText(f"오류: {error_msg}")
        self.btn_calculate.setEnabled(True)
        self.btn_calculate.setText("진행상황 계산")

    def _update_ui_from_cache(self) -> None:
        """캐시에서 UI 업데이트"""
        if self.cache:
            self._on_calculation_complete(self.cache)

    def _calculate_standard(self, ing_layer: QgsVectorLayer, current_operator: str) -> None:
        """기존 방식 계산 (Shapefile 등)"""
        # 기존 코드와 동일한 로직
        total_population = 0.0
        progress_totals = {
            '입력': 0.0,
            '속성': 0.0,
            '측위': 0.0,
            '완료': 0.0,
            'LAS': 0.0
        }
        personal_progress = 0.0
        
        # 필드 인덱스 캐싱
        road_kind_idx = ing_layer.fields().indexFromName("road_kind")
        work_class_idx = ing_layer.fields().indexFromName("작업분류")
        length_idx = ing_layer.fields().indexFromName("length")
        progress_idx = ing_layer.fields().indexFromName("Progress")
        operator_idx = ing_layer.fields().indexFromName("operator")
        
        feature_count = 0
        for feature in ing_layer.getFeatures():
            feature_count += 1
            
            # 속성 접근
            road_kind = feature[road_kind_idx] if road_kind_idx != -1 else None
            work_class = feature[work_class_idx] if work_class_idx != -1 else None
            length = feature[length_idx] if length_idx != -1 else 0
            progress = feature[progress_idx] if progress_idx != -1 else None
            operator = feature[operator_idx] if operator_idx != -1 else None
            
            try:
                length_val = float(length) if length else 0.0
            except:
                length_val = 0.0
            
            # 계산
            if str(road_kind) in ['8', '9'] and str(work_class) != '해안':
                total_population += length_val
            
            progress_str = str(progress) if progress else ""
            if progress_str in progress_totals:
                progress_totals[progress_str] += length_val
            
            if current_operator and str(operator) == current_operator:
                if progress_str in ['입력', '속성', '측위']:
                    personal_progress += length_val
        
        # 결과를 캐시 형식으로 저장
        result = {
            'total_population': total_population,
            'progress_by_type': progress_totals,
            'personal_progress': personal_progress,
            'operator_count': 0,
            'total_features': feature_count
        }
        
        self._on_calculation_complete(result)