from typing import Dict, Optional, List
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QCheckBox, QDateEdit, QSizePolicy,
    QScrollArea, QSpacerItem, QMessageBox, QFrame
)
from qgis.core import QgsVectorLayer
from ..utils.constants import OPERATOR_LIST, PROGRESS_LIST
from ..utils.layer_utils import find_layer_by_name

class INGBatchUpdateWidget(QWidget):
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setup_ui()

        # 크기 정책 설정
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(300, 300)  # 적절한 최소 크기 설정

    def create_compact_combobox(self, items, default_text=None):
        combobox = QComboBox()
        combobox.addItems(items)

        combobox.setStyleSheet("""
            QComboBox {
                text-align: right;
                padding: 4px 8px;
                min-width: 30px;
                max-width: 60px;
                border: 1px solid #d0d0d0;
                border-radius: 3px;
                background-color: white;
            }
            QComboBox::drop-down {
                width: 20px;
                border-left: 1px solid #d0d0d0;
            }
            QComboBox::down-arrow {
                width: 12px;
                height: 12px;
            }
        """)

        combobox.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        combobox.setMinimumContentsLength(1)

        if default_text and default_text in items:
            combobox.setCurrentText(default_text)

        return combobox

    def setup_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(1, 1, 1, 1)
        main_layout.setSpacing(1)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        scroll_area.setMinimumHeight(125)
        scroll_area.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        scroll_area.setStyleSheet("""
            QScrollBar:vertical {
                width: 10px;
                background: #f0f0f0;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #c0c0c0;
                border-radius: 5px;
                min-height: 30px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(1, 1, 1, 1)
        container_layout.setSpacing(15)

        scroll_area.setWidget(container)
        main_layout.addWidget(scroll_area, 1)

        header_frame = QFrame()
        header_frame.setStyleSheet("background-color: LightGray; border-radius: 5px; padding: 10px;")
        header_layout = QVBoxLayout(header_frame)

        title_label = QLabel("시작할때시작만🏁<p>종료할때종료만🔚")
        title_label.setStyleSheet("font-family: '현대하모니L'; font-size: 9pt; font-weight: bold; color: #ff0000;")
        header_layout.addWidget(title_label)

        # desc_label = QLabel("")
        # desc_label.setWordWrap(True)
        # desc_label.setStyleSheet("font-family: '현대하모니L'; color: #ff1212;")
        # header_layout.addWidget(desc_label)

        container_layout.addWidget(header_frame)

        content_frame = QFrame()
        content_frame.setFrameShape(QFrame.StyledPanel)
        content_frame.setFrameShadow(QFrame.Raised)
        content_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f8f8;
                border-radius: 8px;
                border: 1px solid #e0e0e0;
            }
        """)

        content_layout = QVBoxLayout(content_frame)
        content_layout.setContentsMargins(1, 1, 1, 1)
        content_layout.setSpacing(1)

        COLOR_PRIMARY = "#0078d7"
        COLOR_DANGER = "#e74c3c"

        grid_layout = QGridLayout()
        grid_layout.setColumnStretch(0, 0)
        grid_layout.setColumnStretch(1, 1)
        grid_layout.setColumnStretch(2, 1)
        grid_layout.setColumnMinimumWidth(1, 25)
        grid_layout.setHorizontalSpacing(15)
        grid_layout.setVerticalSpacing(15)

        self.field_widgets = {}
        self.checkboxes = {}

        field_display_names = {
            "operator": "이름",
            "st_date": "시작",
            "ed_date": "종료",
            "Progress": "진행",
            "Report": "난이도"
        }

        fields = [
            {"name": "operator", "section": "시작"},
            {"name": "st_date", "section": "시작"},
            {"name": "Report", "section": "시작"},
            {"name": "Progress", "section": "시작", "id": "Progress_start"},
            {"name": "---", "section": "구분선"},
            {"name": "ed_date", "section": "종료"},
            {"name": "Progress", "section": "종료", "id": "Progress_end"},
            {"name": "Report", "section": "종료", "id": "Report_end"}
        ]

        row = 0

        start_header = QLabel("▶ 시작 설정")
        start_header.setStyleSheet(f"""
            font-family: '현대하모니L';
            color: {COLOR_PRIMARY};
            font-weight: bold;
            font-size: 11pt;
            padding: 3px 0;
            border-bottom: 1px solid {COLOR_PRIMARY};
        """)
        grid_layout.addWidget(start_header, row, 0, 1, 3, Qt.AlignLeft)
        row += 1

        for field_info in fields:
            field = field_info["name"]

            if field == "---":
                spacer = QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Fixed)
                grid_layout.addItem(spacer, row, 0, 1, 3)
                row += 1

                end_header = QLabel("▶ 종료 설정")
                end_header.setStyleSheet(f"""
                    font-family: '현대하모니L';
                    color: {COLOR_DANGER};
                    font-weight: bold;
                    font-size: 11pt;
                    padding: 3px 0;
                    border-bottom: 1px solid {COLOR_DANGER};
                """)
                grid_layout.addWidget(end_header, row, 0, 1, 3, Qt.AlignLeft)
                row += 1
                continue

            field_id = field_info.get("id", field)

            checkbox = QCheckBox()
            checkbox.setChecked(False)
            checkbox.setStyleSheet("""
                QCheckBox::indicator {
                    width: 18px;
                    height: 18px;
                }
                QCheckBox::indicator:unchecked {
                    border: 1px solid #d0d0d0;
                    background-color: white;
                    border-radius: 3px;
                }
                QCheckBox::indicator:checked {
                    background-color: #0078d7;
                    border: 1px solid #0078d7;
                    border-radius: 3px;
                }
            """)

            section = field_info.get("section", "")
            display_name = field_display_names.get(field, field)
            label = QLabel(display_name)
            label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            label.setStyleSheet("font-family: '현대하모니L';")

            if section == "시작":
                label.setStyleSheet(f"font-family: '현대하모니L'; color: {COLOR_PRIMARY};")
            elif section == "종료":
                label.setStyleSheet(f"font-family: '현대하모니L'; color: {COLOR_DANGER};")

            if field == "operator":
                from PyQt5.QtCore import QSettings
                current_operator = QSettings().value("VariousTools/SelectedOperator", "")
                input_widget = self.create_compact_combobox(OPERATOR_LIST, current_operator)
            elif field == "Progress":
                default_value = "입력" if section == "시작" else "측위"
                input_widget = self.create_compact_combobox(PROGRESS_LIST, default_value)
            elif field == "Report":
                input_widget = self.create_compact_combobox(["상", "중", "하"], "중")
            elif field in ["st_date", "ed_date"]:
                input_widget = QDateEdit()
                input_widget.setCalendarPopup(True)
                input_widget.setDisplayFormat("yyyy-MM-dd")

                input_widget.setStyleSheet("""
                    QDateEdit {
                        padding: 4px 8px;
                        min-width: 100px;
                        max-width: 140px;
                        border: 1px solid #d0d0d0;
                        border-radius: 3px;
                        background-color: white;
                    }
                    QDateEdit::drop-down {
                        width: 20px;
                        border-left: 1px solid #d0d0d0;
                    }
                """)

                if field == "st_date":
                    input_widget.setDate(QDate.currentDate())
                else:
                    input_widget.setDate(QDate.currentDate().addDays(7))

                input_widget.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            else:
                from PyQt5.QtWidgets import QLineEdit
                input_widget = QLineEdit()
                input_widget.setStyleSheet("""
                    QLineEdit {
                        padding: 4px 8px;
                        min-width: 100px;
                        max-width: 140px;
                        border: 1px solid #d0d0d0;
                        border-radius: 3px;
                        background-color: white;
                    }
                """)

            checkbox.stateChanged.connect(
                lambda state, w=input_widget: w.setEnabled(state == Qt.Checked)
            )
            input_widget.setEnabled(False)

            grid_layout.addWidget(checkbox, row, 0, Qt.AlignCenter)
            grid_layout.addWidget(label, row, 1, Qt.AlignLeft | Qt.AlignVCenter)
            grid_layout.addWidget(input_widget, row, 2)

            self.field_widgets[field_id] = input_widget
            self.checkboxes[field_id] = checkbox

            row += 1

        content_layout.addLayout(grid_layout)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        separator.setStyleSheet("background-color: #e0e0e0;")
        content_layout.addWidget(separator)

        quick_select_frame = QFrame()
        quick_select_frame.setStyleSheet("background-color: #f0f0f0; border-radius: 5px;")
        quick_select_layout = QVBoxLayout(quick_select_frame)

        quick_select_label = QLabel("빠른 선택")
        quick_select_label.setStyleSheet("font-family: '현대하모니L'; font-weight: bold;")
        quick_select_layout.addWidget(quick_select_label)

        quick_buttons_layout = QHBoxLayout()
        quick_buttons_layout.setSpacing(10)

        self.btn_start_only = QPushButton("시작만")
        self.btn_start_only.clicked.connect(self.select_start_only)
        self.style_button(self.btn_start_only, color=COLOR_PRIMARY)

        self.btn_end_only = QPushButton("종료만")
        self.btn_end_only.clicked.connect(self.select_end_only)
        self.style_button(self.btn_end_only, color=COLOR_DANGER)

        self.btn_all = QPushButton("⭕")
        self.btn_all.clicked.connect(self.select_all)
        self.style_button(self.btn_all)

        self.btn_none = QPushButton("❌")
        self.btn_none.clicked.connect(self.select_none)
        self.style_button(self.btn_none)

        quick_buttons_layout.addWidget(self.btn_start_only)
        quick_buttons_layout.addWidget(self.btn_end_only)
        quick_buttons_layout.addWidget(self.btn_all)
        quick_buttons_layout.addWidget(self.btn_none)

        quick_select_layout.addLayout(quick_buttons_layout)
        content_layout.addWidget(quick_select_frame)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.update_button = QPushButton("업데업데")
        self.update_button.setMinimumWidth(50)
        self.update_button.setMinimumHeight(30)
        self.style_button(self.update_button, primary=True)
        button_layout.addWidget(self.update_button)

        content_layout.addLayout(button_layout)
        container_layout.addWidget(content_frame)

        container_layout.addStretch()

        scroll_area.setWidget(container)

        main_layout.addWidget(scroll_area)

        self.setMinimumSize(300, 300)

    def style_button(self, button: QPushButton, primary: bool = False, color: str = None) -> None:
        COLOR_PRIMARY = "#0078d7"

        if primary:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLOR_PRIMARY};
                    color: white;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-family: '현대하모니L';
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: #3498db;
                }}
                QPushButton:pressed {{
                    background-color: #1c6ea4;
                }}
            """)
        elif color:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: white;
                    color: {color};
                    border: 1px solid {color};
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-family: '현대하모니L';
                }}
                QPushButton:hover {{
                    background-color: #f0f0f0;
                }}
                QPushButton:pressed {{
                    background-color: #e0e0e0;
                }}
            """)
        else:
            button.setStyleSheet("""
                QPushButton {
                    background-color: white;
                    border: 1px solid #d0d0d0;
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-family: '현대하모니L';
                }
                QPushButton:hover {
                    background-color: #f0f0f0;
                }
                QPushButton:pressed {
                    background-color: #e0e0e0;
                }
            """)

        button.setMinimumHeight(30)

    def select_start_only(self) -> None:
        for field_id, checkbox in self.checkboxes.items():
            if field_id in ["operator", "st_date", "Report", "Progress_start"]:
                checkbox.setChecked(True)
            else:
                checkbox.setChecked(False)

    def select_end_only(self) -> None:
        for field_id, checkbox in self.checkboxes.items():
            if field_id in ["ed_date", "Progress_end", "Report_end"]:
                checkbox.setChecked(True)
            else:
                checkbox.setChecked(False)

    def select_all(self) -> None:
        for checkbox in self.checkboxes.values():
            checkbox.setChecked(True)

    def select_none(self) -> None:
        for checkbox in self.checkboxes.values():
            checkbox.setChecked(False)

    def get_updates(self) -> Dict[str, str]:
        updates = {}

        field_mapping = {
            "Progress_start": "Progress",
            "Progress_end": "Progress",
            "Report_end": "Report"
        }

        for field_id, widget in self.field_widgets.items():
            if not self.checkboxes[field_id].isChecked():
                continue

            actual_field = field_mapping.get(field_id, field_id)

            if isinstance(widget, QDateEdit):
                updates[actual_field] = widget.date().toString("yyyy-MM-dd")
            elif isinstance(widget, QComboBox):
                updates[actual_field] = widget.currentText()
            elif hasattr(widget, 'text'):
                value = widget.text().strip()
                if value:
                    updates[actual_field] = value

        return updates

def apply_batch_update(ing_update_tab, layers):
    ing_layer = find_layer_by_name(layers, "ING")
    if not ing_layer:
        QMessageBox.warning(None, "오류", "ING 레이어 없음")
        return

    updates = ing_update_tab.get_updates()
    if not updates:
        QMessageBox.warning(None, "오류", "업데이트 값 없음")
        return

    selected_features = list(ing_layer.selectedFeatures())
    if not selected_features:
        QMessageBox.warning(None, "오류", "선택 객체 없음")
        return

    fld_indices = {}
    for field, value in updates.items():
        idx = ing_layer.fields().indexFromName(field)
        if idx == -1:
            QMessageBox.critical(None, "오류", f"{field} 필드 없음")
            return
        fld_indices[field] = idx

    update_dict = {}
    for ft in selected_features:
        update_values = {}
        for field, idx in fld_indices.items():
            update_values[idx] = updates[field]
        update_dict[ft.id()] = update_values

    res = ing_layer.dataProvider().changeAttributeValues(update_dict)
    if res:
        ing_layer.triggerRepaint()
        QMessageBox.information(None, "업데이트", "ING 필드 업데이트 성공")
    else:
        QMessageBox.critical(None, "오류", "ING 필드 업데이트 실패")
