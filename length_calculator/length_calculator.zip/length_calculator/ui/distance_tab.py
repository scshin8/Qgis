from typing import List, Optional, Dict
import sqlite3
import time
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QPushButton,
    QComboBox, QCheckBox, QHeaderView, QTableWidget, QTableWidgetItem,
    QMessageBox, QFrame
)
from qgis.core import QgsVectorLayer


class DistanceCalculationThread(QThread):
    result_ready = pyqtSignal(float, float, dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, layer: QgsVectorLayer, only_selected: bool, group_by_operator: bool):
        super().__init__()
        self.layer = layer
        self.only_selected = only_selected
        self.group_by_operator = group_by_operator
        
    def run(self):
        try:
            if self._is_gpkg():
                self._calculate_gpkg()
            else:
                self._calculate_standard()
        except Exception as e:
            self.error_occurred.emit(str(e))
    
    def _is_gpkg(self) -> bool:
        return '.gpkg' in self.layer.source()
    
    def _get_gpkg_info(self) -> tuple:
        source = self.layer.source()
        if '|' in source:
            parts = source.split('|')
            gpkg_path = parts[0]
            for part in parts[1:]:
                if part.startswith('layername='):
                    table_name = part.split('=')[1]
                    return gpkg_path, table_name
        return source, self.layer.name()
    
    def _calculate_gpkg(self):
        gpkg_path, table_name = self._get_gpkg_info()
        conn = sqlite3.connect(gpkg_path)
        cursor = conn.cursor()
        
        try:
            if self.only_selected:
                selected_ids = [f.id() for f in self.layer.selectedFeatures()]
                if not selected_ids:
                    self.result_ready.emit(0.0, 0.0, {})
                    return
                
                id_list = ','.join(map(str, selected_ids))
                where_clause = f"WHERE fid IN ({id_list})"
            else:
                where_clause = ""
            
            query = f"""
            SELECT 
                SUM(CAST(length AS REAL)) as total_length,
                SUM(CAST(조사거리Km AS REAL)) as total_cs
            FROM {table_name}
            {where_clause}
            """
            
            cursor.execute(query)
            result = cursor.fetchone()
            dg_total = result[0] or 0.0
            cs_total = result[1] or 0.0
            
            operators = {}
            if self.group_by_operator:
                query = f"""
                SELECT 
                    IFNULL(operator, '미지정') as op,
                    SUM(CAST(length AS REAL)) as total_length,
                    SUM(CAST(조사거리Km AS REAL)) as total_cs
                FROM {table_name}
                {where_clause}
                GROUP BY operator
                HAVING total_length > 0 OR total_cs > 0
                ORDER BY total_length DESC
                """
                
                cursor.execute(query)
                for row in cursor.fetchall():
                    operators[row[0]] = {
                        'dg': row[1] or 0.0,
                        'cs': row[2] or 0.0
                    }
            
            self.result_ready.emit(dg_total, cs_total, operators)
            
        finally:
            conn.close()
    
    def _calculate_standard(self):
        features = list(self.layer.selectedFeatures()) if self.only_selected else list(self.layer.getFeatures())
        
        if not features:
            self.result_ready.emit(0.0, 0.0, {})
            return
        
        length_idx = self.layer.fields().indexFromName("length")
        cs_idx = self.layer.fields().indexFromName("조사거리Km")
        op_idx = self.layer.fields().indexFromName("operator") if self.group_by_operator else -1
        
        dg_total = 0.0
        cs_total = 0.0
        operators = {}
        
        for feature in features:
            try:
                length = float(feature[length_idx] or 0) if length_idx != -1 else 0
                cs_km = float(feature[cs_idx] or 0) if cs_idx != -1 else 0
                
                dg_total += length
                cs_total += cs_km
                
                if self.group_by_operator and op_idx != -1:
                    operator = str(feature[op_idx] or "미지정")
                    if operator not in operators:
                        operators[operator] = {"dg": 0.0, "cs": 0.0}
                    operators[operator]["dg"] += length
                    operators[operator]["cs"] += cs_km
                    
            except (ValueError, TypeError):
                continue
        
        self.result_ready.emit(dg_total, cs_total, operators)


class DistanceTab(QWidget):
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.layer_list: List[QgsVectorLayer] = []
        self.calculation_thread = None
        self.init_ui()

    def init_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(8, 10, 8, 10)

        options_frame = QFrame()
        options_frame.setFrameShape(QFrame.StyledPanel)
        options_frame.setFrameShadow(QFrame.Raised)
        options_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f8f8;
                border-radius: 5px;
                border: 1px solid #e0e0e0;
                padding: 5px;
            }
            QLabel {
                font-size: 11px;
            }
        """)

        options_layout = QVBoxLayout(options_frame)
        options_layout.setContentsMargins(10, 10, 10, 10)
        options_layout.setSpacing(10)

        options_title = QLabel("<b>거리 계산 설정</b>")
        options_title.setStyleSheet("font-size: 12px; margin-bottom: 3px;")
        options_layout.addWidget(options_title)

        form_layout = QFormLayout()
        form_layout.setLabelAlignment(Qt.AlignLeft)
        form_layout.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        form_layout.setSpacing(8)

        self.d_layer = QComboBox()
        self.d_layer.setStyleSheet("""
            QComboBox {
                padding: 4px 8px;
                border: 1px solid #d0d0d0;
                border-radius: 3px;
                background-color: white;
                min-height: 22px;
            }
            QComboBox::drop-down {
                width: 20px;
                border-left: 1px solid #d0d0d0;
            }
        """)

        self.d_sel = QCheckBox("선택한 객체만 포함")
        self.d_sel.setChecked(True)
        self.d_sel.setStyleSheet("""
            QCheckBox {
                padding: 2px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)

        self.chk_group_by_operator = QCheckBox("인원별 구분 결과 표시")
        self.chk_group_by_operator.setChecked(True)
        self.chk_group_by_operator.setStyleSheet("""
            QCheckBox {
                padding: 2px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)

        form_layout.addRow("<b>레이어 선택:</b>", self.d_layer)
        form_layout.addRow("", self.d_sel)
        form_layout.addRow("", self.chk_group_by_operator)

        options_layout.addLayout(form_layout)
        main_layout.addWidget(options_frame)

        result_frame = QFrame()
        result_frame.setFrameShape(QFrame.StyledPanel)
        result_frame.setFrameShadow(QFrame.Raised)
        result_frame.setStyleSheet("""
            QFrame {
                background-color: #f8f8f8;
                border-radius: 5px;
                border: 1px solid #e0e0e0;
                padding: 5px;
            }
        """)

        result_layout = QVBoxLayout(result_frame)
        result_layout.setContentsMargins(10, 10, 10, 10)
        result_layout.setSpacing(10)

        result_title = QLabel("<b>계산 결과</b>")
        result_title.setStyleSheet("font-size: 12px; margin-bottom: 3px;")
        result_layout.addWidget(result_title)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("background-color: #e0e0e0;")
        result_layout.addWidget(line)

        summary_layout = QVBoxLayout()
        summary_layout.setSpacing(5)

        self.lab_dg = QLabel("대구합계: 0.00 km")
        self.lab_dg.setStyleSheet("""
            QLabel {
                font-size: 12px;
                font-weight: bold;
                color: #0078d7;
                padding: 2px;
            }
        """)

        self.lab_cs = QLabel("조사거리합계: 0.00 km")
        self.lab_cs.setStyleSheet("""
            QLabel {
                font-size: 12px;
                font-weight: bold;
                color: #107c10;
                padding: 2px;
            }
        """)

        summary_layout.addWidget(self.lab_dg)
        summary_layout.addWidget(self.lab_cs)

        result_layout.addLayout(summary_layout)

        self.performance_label = QLabel("")
        self.performance_label.setStyleSheet("font-size: 8pt; color: #888;")
        result_layout.addWidget(self.performance_label)

        self.operator_results_label = QLabel("인원별")
        self.operator_results_label.setStyleSheet("font-weight: bold; margin-top: 5px;")
        result_layout.addWidget(self.operator_results_label)

        self.group_table = QTableWidget()
        self.group_table.setColumnCount(3)
        self.group_table.setHorizontalHeaderLabels(["인원", "링크", "조사"])
        self.group_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.group_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.group_table.setMinimumHeight(200)
        self.group_table.verticalHeader().setDefaultSectionSize(35)
        self.group_table.horizontalHeader().setMinimumHeight(40)

        header_font = QFont()
        header_font.setPointSize(10)
        header_font.setBold(True)
        self.group_table.horizontalHeader().setFont(header_font)

        self.group_table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #ddd;
                border-radius: 3px;
                background-color: white;
                gridline-color: #f0f0f0;
            }
            QHeaderView::section {
                background-color: #f0f0f0;
                padding: 8px;
                border: none;
                border-right: 1px solid #ddd;
                border-bottom: 1px solid #ddd;
                font-weight: bold;
                min-height: 40px;
            }
            QTableWidget::item {
                padding: 8px;
                min-height: 35px;
            }
            QTableWidget::item:selected {
                background-color: #e6f2ff;
                color: black;
            }
        """)

        result_layout.addWidget(self.group_table)
        main_layout.addWidget(result_frame, 1)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        self.btn_dist = QPushButton("거리 계산")
        self.btn_dist.setMinimumHeight(40)
        self.btn_dist.setStyleSheet("""
            QPushButton {
                background-color: #0078d7;
                color: white;
                border-radius: 5px;
                padding: 8px 15px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
            QPushButton:pressed {
                background-color: #005a9e;
            }
        """)

        button_layout.addWidget(self.btn_dist)
        main_layout.addLayout(button_layout)
        main_layout.addStretch()

        self.update_ui_state()
        self.chk_group_by_operator.stateChanged.connect(self.update_ui_state)

    def update_ui_state(self):
        show_operators = self.chk_group_by_operator.isChecked()
        self.operator_results_label.setVisible(show_operators)
        self.group_table.setVisible(show_operators)

    def setLayerNames(self, names: List[str], def_idx: int) -> None:
        self.d_layer.clear()
        self.d_layer.addItems(names)
        self.d_layer.setCurrentIndex(def_idx)

    def setLayerList(self, layer_list: List[QgsVectorLayer]) -> None:
        self.layer_list = layer_list

    def calculate_distance(self) -> None:
        start_time = time.time()
        
        idx = self.d_layer.currentIndex()
        if idx < 0 or idx >= len(self.layer_list):
            QMessageBox.warning(None, "오류", "레이어를 선택하세요")
            return

        layer = self.layer_list[idx]
        only_sel = self.d_sel.isChecked()
        group_by_operator = self.chk_group_by_operator.isChecked()

        self.btn_dist.setEnabled(False)
        self.btn_dist.setText("계산 중...")
        
        self.calculation_thread = DistanceCalculationThread(layer, only_sel, group_by_operator)
        self.calculation_thread.result_ready.connect(self._on_calculation_complete)
        self.calculation_thread.error_occurred.connect(self._on_calculation_error)
        self.calculation_thread.start()

    def _on_calculation_complete(self, dg_total: float, cs_total: float, operators: dict):
        self.lab_dg.setText(f"링크합계: {dg_total:,.2f} km")
        self.lab_cs.setText(f"조사거리합계: {cs_total:,.2f} km")
        
        if self.chk_group_by_operator.isChecked() and operators:
            self.displayOperatorResults(operators)
        
        if hasattr(self, '_start_time'):
            elapsed = time.time() - self._start_time
            self.performance_label.setText(f"계산 시간: {elapsed:.3f}초")
        
        self.btn_dist.setEnabled(True)
        self.btn_dist.setText("거리 계산")
        
        QMessageBox.information(None, "거리 계산", 
                              f"계산 완료\n대구합계: {dg_total:,.2f} km\n조사거리합계: {cs_total:,.2f} km")

    def _on_calculation_error(self, error_msg: str):
        QMessageBox.critical(None, "오류", f"계산 중 오류 발생: {error_msg}")
        self.btn_dist.setEnabled(True)
        self.btn_dist.setText("거리 계산")

    def displayOperatorResults(self, operators: dict) -> None:
        self.group_table.setRowCount(0)

        if not operators:
            return

        total_dg = sum(values['dg'] for values in operators.values())
        total_cs = sum(values['cs'] for values in operators.values())

        self.group_table.setRowCount(len(operators) + 1)

        for i, (operator_name, values) in enumerate(sorted(operators.items(), key=lambda x: x[1]['dg'], reverse=True)):
            name_item = QTableWidgetItem(str(operator_name))
            name_item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.group_table.setItem(i, 0, name_item)

            dg_item = QTableWidgetItem(f"{values['dg']:,.2f}")
            dg_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.group_table.setItem(i, 1, dg_item)

            cs_item = QTableWidgetItem(f"{values['cs']:,.2f}")
            cs_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.group_table.setItem(i, 2, cs_item)

            self.group_table.setRowHeight(i, 35)

        total_row = len(operators)

        total_label = QTableWidgetItem("합계")
        total_label.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        total_label.setFont(QFont("", -1, QFont.Bold))

        total_dg_item = QTableWidgetItem(f"{total_dg:,.2f}")
        total_dg_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        total_dg_item.setFont(QFont("", -1, QFont.Bold))

        total_cs_item = QTableWidgetItem(f"{total_cs:,.2f}")
        total_cs_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        total_cs_item.setFont(QFont("", -1, QFont.Bold))

        self.group_table.setItem(total_row, 0, total_label)
        self.group_table.setItem(total_row, 1, total_dg_item)
        self.group_table.setItem(total_row, 2, total_cs_item)

        self.group_table.setRowHeight(total_row, 40)

        for col in range(3):
            item = self.group_table.item(total_row, col)
            item.setBackground(QColor("#f0f0f0"))