import os
import logging
from typing import List
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QCheckBox, QLineEdit, QMessageBox,
    QFileDialog, QFrame
)
from qgis.core import QgsProject, QgsVectorFileWriter, QgsVectorLayer
from ..utils.constants import REQ7
from ..utils.layer_utils import get_field_mapping

logger = logging.getLogger(__name__)

def build_tab_export(names: List[str], def_idx: int, default_dir: str) -> QWidget:
    tab = QWidget()
    layout = QVBoxLayout(tab)
    form = QFormLayout()

    e_layer = QComboBox()
    e_layer.addItems(names)
    e_layer.setCurrentIndex(def_idx)
    e_layer.setStyleSheet("""
        QComboBox {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
            min-height: 22px;
        }
    """)

    e_sel = QCheckBox("선택한것만")
    e_sel.setChecked(True)
    e_sel.setStyleSheet("""
        QCheckBox {
            padding: 2px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    form.addRow("레이어 선택:", e_layer)
    form.addRow("", e_sel)

    base_fname = QLineEdit()
    base_fname.setStyleSheet("""
        QLineEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
        }
    """)
    form.addRow("기본 파일명:", base_fname)

    path_label = QLabel(f"기본 저장 폴더: {default_dir}")
    path_label.setWordWrap(True)
    form.addRow(path_label)

    grid = QGridLayout()
    grid.setColumnStretch(1, 1)
    grid.setVerticalSpacing(15)

    chk_shp = QCheckBox("SHP")
    chk_shp.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    shp_edit = QLineEdit()
    shp_edit.setMinimumHeight(30)
    shp_edit.setStyleSheet("""
        QLineEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
            background-color: white;
        }
    """)

    shp_btn = QPushButton("...")
    shp_btn.setFixedWidth(28)
    shp_btn.setMinimumHeight(30)
    shp_btn.setStyleSheet("""
        QPushButton {
            background-color: #f0f0f0;
            border: 1px solid #d0d0d0;
            border-radius: 2px;
        }
        QPushButton:hover {
            background-color: #e0e0e0;
        }
    """)

    grid.addWidget(chk_shp, 0, 0)
    grid.addWidget(shp_edit, 0, 1)
    grid.addWidget(shp_btn, 0, 2)

    chk_gpkg = QCheckBox("GPKG")
    chk_gpkg.setStyleSheet("""
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
    """)

    gpkg_edit = QLineEdit()
    gpkg_edit.setMinimumHeight(30)
    gpkg_edit.setStyleSheet("""
        QLineEdit {
            padding: 4px 8px;
            border: 1px solid #d0d0d0;
            border-radius: 2px;
            background-color: white;
        }
    """)

    gpkg_btn = QPushButton("...")
    gpkg_btn.setFixedWidth(28)
    gpkg_btn.setMinimumHeight(30)
    gpkg_btn.setStyleSheet("""
        QPushButton {
            background-color: #f0f0f0;
            border: 1px solid #d0d0d0;
            border-radius: 3px;
        }
        QPushButton:hover {
            background-color: #e0e0e0;
        }
    """)

    grid.addWidget(chk_gpkg, 1, 0)
    grid.addWidget(gpkg_edit, 1, 1)
    grid.addWidget(gpkg_btn, 1, 2)

    form.addRow(grid)
    layout.addLayout(form)

    btn_exp = QPushButton("내보내기")
    btn_exp.setMinimumHeight(35)
    btn_exp.setStyleSheet("""
        QPushButton {
            background-color: #0078d7;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
    """)

    null_check_frame = QFrame()
    null_check_frame.setFrameShape(QFrame.StyledPanel)
    null_check_frame.setFrameShadow(QFrame.Raised)
    null_check_frame.setStyleSheet("background-color: #f5f5f5; border: 1px solid #e0e0e0; border-radius: 5px; padding: 10px;")

    null_check_layout = QVBoxLayout(null_check_frame)
    null_check_layout.setContentsMargins(10, 10, 10, 10)
    null_check_layout.setSpacing(10)

    null_title = QLabel("<b>NULL 값 확인 및 선택</b>")
    null_title.setStyleSheet("margin-bottom: 5px;")
    null_check_layout.addWidget(null_title)

    btn_null_check = QPushButton("선택한 객체의 NULL 값 확인")
    btn_null_check.setStyleSheet("""
        QPushButton {
            background-color: #3498db;
            color: white;
            border-radius: 4px;
            padding: 6px 10px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #2980b9;
        }
    """)
    null_check_layout.addWidget(btn_null_check)

    btn_null_select = QPushButton("NULL 값이 있는 객체 선택")
    btn_null_select.setStyleSheet("""
        QPushButton {
            background-color: #9b59b6;
            color: white;
            border-radius: 4px;
            padding: 6px 10px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #8e44ad;
        }
    """)
    null_check_layout.addWidget(btn_null_select)

    layout.addWidget(null_check_frame)


    layout.addWidget(btn_exp)
    layout.addStretch()

    tab.e_layer = e_layer
    tab.e_sel = e_sel
    tab.base_fname = base_fname
    tab.path_label = path_label
    tab.chk_shp = chk_shp
    tab.shp_edit = shp_edit
    tab.shp_btn = shp_btn
    tab.chk_gpkg = chk_gpkg
    tab.gpkg_edit = gpkg_edit
    tab.gpkg_btn = gpkg_btn
    tab.btn_exp = btn_exp
    tab.btn_null_check = btn_null_check
    tab.btn_null_select = btn_null_select
    tab.default_dir = default_dir

    return tab

def export_layer(export_tab, layers, default_dir):
    lyr_idx = export_tab.e_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요.")
        return

    lyr = layers[lyr_idx]

    was_editable = lyr.isEditable()
    if was_editable:
        logger.info("레이어 편집 모드를 종료합니다.")
        lyr.commitChanges() # 저장
        lyr.rollBack() # 편집 모드 종료

    only_sel = export_tab.e_sel.isChecked()

    if only_sel and lyr.selectedFeatureCount() == 0:
        QMessageBox.warning(None, "오류", "선택된 객체가 없습니다.")
        return

    mapping = get_field_mapping(lyr, REQ7)
    missing = [req for req, mapped in mapping.items() if mapped is None]
    if missing:
        QMessageBox.critical(None, "오류", f"필드 누락: {', '.join(missing)}")
        return

    try:
        important_fields = ["Progress", "Group", "Report", "operator", "st_date", "ed_date"]
        
        features_to_check = list(lyr.selectedFeatures() if only_sel else lyr.getFeatures())
        if not features_to_check:
            logger.warning("No features to check for NULL values")
        
        null_fields = set()
        for ft in features_to_check:
            for field in important_fields:
                # Skip fields that don't exist
                if lyr.fields().indexFromName(field) == -1:
                    continue
                    
                val = ft.attribute(field)
                if val is None or (isinstance(val, str) and val.strip() == ""):
                    null_fields.add(field)
                    # Add debug output
                    logger.info(f"Found NULL in field: {field}")
        
        if null_fields:
            null_list = ", ".join(sorted(null_fields))
            logger.info(f"빈값: {null_list}")
            reply = QMessageBox.question(None, "범인은너야",
                                       f"[{null_list}] NULL값있는데 상관없으면 YES",
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No:
                return
    except Exception as e:
        logger.error(f"NULL check error: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())

    if export_tab.chk_shp.isChecked():
        p = export_tab.shp_edit.text().strip()
        if not p:
            QMessageBox.warning(None, "오류", "Shapefile 경로를 지정하세요.")
            return

        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)

            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.fileEncoding = "UTF-8"
            options.onlySelectedFeatures = only_sel

            error, msg = QgsVectorFileWriter.writeAsVectorFormatV2(
                lyr, p, QgsProject.instance().transformContext(), options
            )

            if error == QgsVectorFileWriter.NoError:
                QMessageBox.information(None, "내보내기", f"Shapefile로 내보내기 완료:\n{p}")
            else:
                QMessageBox.critical(None, "오류", f"Shapefile 내보내기 실패:\n{msg}")

        except Exception as e:
            logger.error(f"Shapefile 내보내기 오류: {e}")
            QMessageBox.critical(None, "오류", f"Shapefile 내보내기 중 오류 발생:\n{str(e)}")

    if export_tab.chk_gpkg.isChecked():
        p = export_tab.gpkg_edit.text().strip()
        if not p:
            QMessageBox.warning(None, "오류", "GeoPackage 경로를 지정하세요.")
            return
     
        # 선택한 객체의 operator 확인
        only_sel = export_tab.e_sel.isChecked()
        if only_sel:
            from PyQt5.QtCore import QSettings
            current_operator = QSettings().value("VariousTools/SelectedOperator", "")
            if current_operator:
                selected_features = list(lyr.selectedFeatures())
                different_operators = set()
                for feature in selected_features:
                    feature_operator = str(feature.attribute("operator") or "").strip()
                    if feature_operator != current_operator and feature_operator:
                        different_operators.add(feature_operator)
                if different_operators:
                    operators_list = ", ".join(sorted(different_operators))
                    reply = QMessageBox.question(
                        None, 
                        "작업자 불일치 경고",
                        f"선택한 객체 중 일부가 현재 설정된 작업자({current_operator})와 다른 작업자의 데이터입니다.\n\n"
                        f"다른 작업자: {operators_list}\n\n"
                        f"계속 진행하시겠습니까?",
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.No
                    )
                    if reply == QMessageBox.No:
                        return
     
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
     
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.fileEncoding = "UTF-8"
            options.onlySelectedFeatures = only_sel
     
            from os.path import basename, splitext
            options.layerName = splitext(basename(p))[0]
     
            if os.path.exists(p):
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                options.layerOptions = ["OVERWRITE=YES"]
     
            error, msg = QgsVectorFileWriter.writeAsVectorFormatV2(
                lyr, p, QgsProject.instance().transformContext(), options
            )
     
            if error == QgsVectorFileWriter.NoError:
                QMessageBox.information(None, "내보내기", f"GeoPackage로 내보내기 완료:\n{p}")
            else:
                QMessageBox.critical(None, "오류", f"GeoPackage 내보내기 실패:\n{msg}")
     
        except Exception as e:
            logger.error(f"GeoPackage 내보내기 오류: {e}")
            QMessageBox.critical(None, "오류", f"GeoPackage 내보내기 중 오류 발생:\n{str(e)}")

    if was_editable:
        logger.info("이전 편집 모드 상태 복원")
        lyr.startEditing()







def browse_export_file(main_plugin, edit_widget, title, filter_str, default_ext=None):
    from PyQt5.QtCore import QDate, QSettings
    from PyQt5.QtWidgets import QFileDialog

    current_path = edit_widget.text().strip()

    if not current_path or not os.path.exists(os.path.dirname(current_path)):
        base_name = main_plugin.export_tab.base_fname.text().strip()
        if not base_name:
            today = QDate.currentDate().toString("yyyy-MM-dd")
            op = QSettings().value("VariousTools/SelectedOperator", "")
            base_name = f"{today}_{op}"

        current_path = os.path.join(main_plugin.default_dir, f"{base_name}{default_ext}")

    path, _ = QFileDialog.getSaveFileName(
        main_plugin.iface.mainWindow(), title, current_path, filter_str
    )

    if path:
        edit_widget.setText(path)


def check_null_values_simple(export_tab, layers):
    """단순화된 NULL 또는 빈 값 확인"""
    # 선택된 레이어 확인
    lyr_idx = export_tab.e_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요.")
        return
    
    lyr = layers[lyr_idx]
    
    # 선택된 객체 확인
    selected_features = list(lyr.selectedFeatures())
    if not selected_features:
        QMessageBox.warning(None, "오류", "선택된 객체가 없습니다.")
        return
    
    # 체크할 필드들
    fields_to_check = ["Progress", "Group", "Report", "operator", "st_date", "ed_date"]
    
    # NULL 또는 빈 값 확인
    null_info = {}
    
    # 각 객체의 필드 확인
    for feature in selected_features:
        for field in fields_to_check:
            # 필드가 존재하는지 확인
            field_idx = feature.fields().indexFromName(field)
            if field_idx == -1:
                continue
                
            # 값 추출
            value = feature[field]
            
            # NULL 또는 빈 값 확인 (단순화된 로직)
            is_empty = False
            
            # None 체크
            if value is None:
                is_empty = True
            # 문자열인 경우 빈 값 체크
            elif isinstance(value, str) and value.strip() == "":
                is_empty = True
            # 빈 날짜 체크
            elif str(value) == "NULL" or str(value) == "null":
                is_empty = True
            
            # NULL 또는 빈 값이 있으면 카운트 증가
            if is_empty:
                if field not in null_info:
                    null_info[field] = []
                null_info[field].append(feature.id())
    
    # 결과 표시
    if not null_info:
        QMessageBox.information(None, "NULL/빈 값 확인", "선택된 객체에서 NULL 또는 빈 값이 없습니다.")
    else:
        result = "NULL 또는 빈 값이 있는 필드:\n\n"
        for field, feature_ids in null_info.items():
            result += f"{field}: {len(feature_ids)}개 객체\n"
            # 객체 ID 표시 (최대 5개)
            if feature_ids:
                ids_to_show = feature_ids[:5]
                result += f" - 객체 ID 예시: {', '.join(map(str, ids_to_show))}"
                if len(feature_ids) > 5:
                    result += f" 외 {len(feature_ids) - 5}개\n"
                else:
                    result += "\n"
        
        # NULL 값이 있는 객체를 선택할지 묻기
        reply = QMessageBox.question(None, "NULL/빈 값 확인", 
                                    result + "\n이 객체들을 선택하시겠습니까?",
                                    QMessageBox.Yes | QMessageBox.No, 
                                    QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            # 모든 NULL 객체 ID 수집
            all_null_ids = set()
            for ids in null_info.values():
                all_null_ids.update(ids)
            
            # 객체 선택
            lyr.selectByIds(list(all_null_ids))
            QMessageBox.information(None, "선택 완료", f"{len(all_null_ids)}개 객체가 선택되었습니다.")

def select_null_features_simple(export_tab, layers):
    """단순화된 NULL 또는 빈 값이 있는 객체 선택"""
    # 선택된 레이어 확인
    lyr_idx = export_tab.e_layer.currentIndex()
    if lyr_idx < 0 or lyr_idx >= len(layers):
        QMessageBox.warning(None, "오류", "레이어를 선택하세요.")
        return
    
    lyr = layers[lyr_idx]
    
    # 모든 객체 또는 선택된 객체
    only_selected = export_tab.e_sel.isChecked()
    features_to_check = list(lyr.selectedFeatures()) if only_selected else list(lyr.getFeatures())
    
    if only_selected and not features_to_check:
        QMessageBox.warning(None, "오류", "선택된 객체가 없습니다.")
        return
    
    # 체크할 필드들
    all_fields = ["Progress", "Group", "Report", "operator", "st_date", "ed_date"]
    fields_to_check = []
    
    # 필드 선택 대화상자
    from PyQt5.QtWidgets import QDialog, QVBoxLayout, QCheckBox, QDialogButtonBox
    
    dialog = QDialog()
    dialog.setWindowTitle("NULL/빈 값 검색할 필드 선택")
    dialog.setMinimumWidth(300)
    dialog_layout = QVBoxLayout(dialog)
    
    checkboxes = {}
    for field in all_fields:
        if lyr.fields().indexFromName(field) != -1:
            cb = QCheckBox(field)
            cb.setChecked(True)
            checkboxes[field] = cb
            dialog_layout.addWidget(cb)
    
    if not checkboxes:
        QMessageBox.warning(None, "오류", "검색할 수 있는 필드가 없습니다.")
        return
    
    buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    dialog_layout.addWidget(buttons)
    
    if not dialog.exec_():
        return
    
    # 선택된 필드 확인
    for field, cb in checkboxes.items():
        if cb.isChecked():
            fields_to_check.append(field)
    
    if not fields_to_check:
        QMessageBox.warning(None, "오류", "선택된 필드가 없습니다.")
        return
    
    # NULL 또는 빈 값이 있는 객체 검색
    null_ids = set()
    null_counts = {field: 0 for field in fields_to_check}
    
    for feature in features_to_check:
        for field in fields_to_check:
            # 값 추출
            value = feature[field]
            
            # NULL 또는 빈 값 확인 (단순화된 로직)
            is_empty = False
            
            # None 체크
            if value is None:
                is_empty = True
            # 문자열인 경우 빈 값 체크
            elif isinstance(value, str) and value.strip() == "":
                is_empty = True
            # 빈 날짜 체크
            elif str(value) == "NULL" or str(value) == "null":
                is_empty = True
            
            # NULL 또는 빈 값이 있으면 ID 추가
            if is_empty:
                null_ids.add(feature.id())
                null_counts[field] += 1
    
    # 결과 처리
    if not null_ids:
        QMessageBox.information(None, "검색 결과", "NULL 또는 빈 값이 있는 객체가 없습니다.")
        return
    
    # 객체 선택
    lyr.selectByIds(list(null_ids))
    
    # 결과 메시지
    result = f"총 {len(null_ids)}개 객체가 선택되었습니다.\n\n"
    result += "필드별 NULL/빈 값 개수:\n"
    for field, count in null_counts.items():
        if count > 0:
            result += f"{field}: {count}개\n"
    
    QMessageBox.information(None, "검색 완료", result)