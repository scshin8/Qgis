from qgis.PyQt.QtCore import Qt, pyqtSignal, QVariant
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import *
from qgis.gui import *

# import traceback
class CommentManagerTool(QgsMapToolEmitPoint):
    selectionDone = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rb.setWidth(3)
        self.rb.setColor(QColor(60, 151, 255, 255))
    
    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            Point=self.toMapCoordinates(e.pos())
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
            self.selectionDone.emit()

    def reset(self):
        self.rb.reset(QgsWkbTypes.PointGeometry)
        # self.rb.reset(True)
    def deactivate(self):
        # self.rb.reset(QgsWkbTypes.PointGeometry)
        self.rb.reset(True)
        QgsMapTool.deactivate(self)
 
class DrawLineComment(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rb.setColor(QColor(60, 151, 255, 150)) # 라인 색깔
        self.rb.setWidth(5)  # 라인 너비
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None   
    
    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.LineGeometry)
                self.status = 1
            Point=self.toMapCoordinates(e.pos())
            print(Point)
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        else:
            if self.rb.numberOfVertices() > 2:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
            # else:
            #     self.reset()
        return None

    def canvasMoveEvent(self, e):
        if self.rb.numberOfVertices() > 0 and self.status == 1:
            self.rb.removeLastPoint(0)
            Point=self.toMapCoordinates(e.pos())
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        self.move.emit()
        return None

    def reset(self):
        self.status = 0
        # self.rb.reset(QgsWkbTypes.LineGeometry)
        self.rb.reset(True)

    def deactivate(self):
        # self.status = 0
        # self.rb.reset(QgsWkbTypes.LineGeometry)
        self.rb.reset(True)
        QgsMapTool.deactivate(self)

        
class DrawpolygonComment(QgsMapTool):
    selectionDone = pyqtSignal()
    move = pyqtSignal()

    def __init__(self, iface):
        canvas = iface.mapCanvas()
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.iface = iface
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setColor(QColor(60, 151, 255, 150)) # 라인 색깔
        return None

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()
        if e.matches(QKeySequence.Cancel):
            self.reset()
            self.iface.actionPan().trigger()
        return None
    
    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
            Point=self.toMapCoordinates(e.pos())
            print(Point)
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        else:
            if self.rb.numberOfVertices() > 3:
                self.rb.removeLastPoint()
                self.status = 0
                self.selectionDone.emit()
            # else:
            #     self.reset()
        return None

    def canvasMoveEvent(self, e):
        if self.rb.numberOfVertices() > 0 and self.status == 1:
            self.rb.removeLastPoint(0)
            Point=self.toMapCoordinates(e.pos())
            # map_crs = self.canvas.mapSettings().destinationCrs() # 프로젝트 좌표계 저장
            # CRSname=map_crs.description() #authid()
            # epsg4326 = QgsCoordinateReferenceSystem('EPSG:4326')
            # transform = QgsCoordinateTransform(map_crs, epsg4326, QgsProject.instance())
            # Point = transform.transform(Point)
            self.rb.addPoint(Point)
        self.move.emit()
        return None

    def reset(self):
        self.status = 0
        self.rb.reset(True)

    def deactivate(self):
        self.status = 0
        self.rb.reset(True)
        QgsMapTool.deactivate(self)